<?php
class IndexController{
	private $_aUser = '';
	private $_userId = 0;
	
	public function __construct(){
		$this->_aUser = checkTeacherLogin();
		$this->_userId = $this->_aUser['id'];
	}
	
	public function index(){
		header('uid:' . $this->_aUser['id']);
		$oTeacher = m('Teacher');
		$aUserInfo = $oTeacher->getTeacherInfoById($this->_aUser['id']);
		assign('aUserInfo', $aUserInfo);
		displayHeader('学生成绩', $this->_aUser['name']);
		display('index/student_mark.html.php');
		displayFooter();
	}
	
	public function showEsStats(){
		$oTeacher = new TeacherModel();
		displayHeader('教学参考数据', $this->_aUser['name']);
		display('index/es_stats.html.php');
		displayFooter();
	}
	
	public function getEsDetail(){
		$id = intval(Xxtea::decrypt(post('id')));
		$aEs = Teacher::getEsDetail($id);
		if(!$aEs){
			alert('题目不存在', -1);
		}
		alert('题目详细', 1, $aEs);
	}
	
	
	public function addGroup(){
		$groupName = post('group_name');
		$oTeacher = new TeacherModel();
		$groupId = $oTeacher->addGroup($this->_aUser['id'], $groupName);
		if($groupId){
			$aNewGroup = array(
				'id' => $groupId,
				'name' => $groupName,
				'member_count' => 0,
			);
			alert('添加分组成功', 1, $aNewGroup);
		}else{
			alert('添加分组失败', 0);
		}
	}
	
	public function deleteStudent(){
		$aDeleteIds = post('delete_ids');
		$oTeacher = new TeacherModel();
		$aGroupList = $oTeacher->getGroupStudentIds($this->_aUser['id']);
		foreach($aDeleteIds as $studentId){
			if(!in_array($studentId, $aGroupList)){
				alert('ID为 ' . $studentId . ' 的学生不在您的关注中', -1);
			}
		}
		if($oTeacher->cancelAttentionStudent($this->_aUser['id'], $aDeleteIds)){
			$aGroupList = $this->_getGroupList($this->_aUser['id']);
			alert('删除成功', 1, $aGroupList);
		}else{
			alert('删除失败', 0);
		}
	}
	
	private function _getGroupList($teacherId){
		$oTeacher = new TeacherModel();
		return $oTeacher->getGroupList($this->_aUser['id']);
	}
	
	public function moveStudentToGroup(){
		$moveToGroupId = intval(post('move_to_group_id'));
		$aMoveStudentIds = post('move_student_ids');
		if(!$moveToGroupId){
			alert('参数错误', -1);
		}
		$oTeacher = new TeacherModel();
		$aMyGrooupIds = $oTeacher->getGroupIds($this->_aUser['id']);
		if(!in_array($moveToGroupId, $aMyGrooupIds)){
			alert('分组不存在', -1);
		}
		$aGroupList = $oTeacher->getGroupStudentIds($this->_aUser['id']);
		foreach($aMoveStudentIds as $studentId){
			if(!in_array($studentId, $aGroupList)){
				alert('ID为 ' . $studentId . ' 的学生不在您的关注中', -1);
			}
		}
		$result = $oTeacher->moveStudentToGroup($this->_aUser['id'], $aMoveStudentIds, $moveToGroupId);
		if($result){
			$aGroupList = $this->_getGroupList($this->_aUser['id']);
			alert('移动成功', 1, $aGroupList);
		}else{
			alert('移动失败', 0);
		}
	}
	
	public function deleteStudentGroup(){
		$groupId = intval(post('group_id'));
		if(!$groupId){
			alert('参数错误', -1);
		}
		$oTeacher = new TeacherModel();
		if($oTeacher->deleteGroup($this->_aUser['id'], $groupId)){
			$aGroupList = $this->_getGroupList($this->_aUser['id']);
			alert('删除分组成功', 1, $aGroupList);
		}else{
			alert('删除失败', 0);
		}
	}
	
	public function getStudentList(){
		$page = intval(post('page'));
		if($page < 1){
			$page = 1;
		}
		$groupId = intval(post('group_id'));
		
		$oTeacher = new TeacherModel();
		$aStudentList = $oTeacher->getGroupStudentList($this->_aUser['id'], $page, 9, $groupId);
		alert('OK', 1, $aStudentList);
	}
	
	public function getMissionList(){
		$gradeId = intval(post('gradeId', 5));
		$subjectId = intval(post('subjectId', 1));
		$aMissionList = Teacher::getMissionList($gradeId, $subjectId);
		alert('关卡列表', 1, $aMissionList);
	}
	
	public function getStudentMarkList(){
		$page = intval(post('page', 1));
		$missionId = (int)post('missionId');
		$aUserIds = explode(',', post('ids'));
		foreach($aUserIds as $id){
			if(!is_numeric($id)){
				alert('非法的查询参数', 0);
			}
		}
		
		$aStudent = Teacher::getStudentMarkList($page, $missionId, $aUserIds);
		if(!$aStudent){
			alert('参数错误', -1);
		}
		alert('学生列表', 1, $aStudent);
	}
	
	public function getEsList(){
		$page = intval(post('page', 1));
		$missionId = intval(post('missionId'));
		$type = intval(post('type'));
		$aEs = Teacher::getEsList($page, $missionId, $type);
		alert('题目列表', 1, $aEs);
	}
	
	public function getWantStudentList(){
		$page = intval(post('addPage'));
		if($page < 1){
			$page = 1;
		}
		$gradeId = intval(post('gradeId'));
		$classId = intval(post('classId'));
		$oTeacher = new TeacherModel();
		$aStudentList = $oTeacher->getStuentListInSchool($this->_aUser['id'], $this->_aUser['school_id'], $gradeId, $classId, $page, 9);
		alert('OK', 1, $aStudentList);
	}
	
	public function atttendtionStudent(){
		$aWantStudentIds = post('aWantStudentIds');
		if(!is_array($aWantStudentIds)){
			alert('参数错误', -1);
		}
		$toGroup = post('toGroup');
		if(!$toGroup){
			alert('参数错误', -1);
		}
		$oTeacher = new TeacherModel();
		$aGroupIds = $oTeacher->getGroupStudentIds($this->_aUser['id']);
		foreach($aWantStudentIds as $id){
			if(!intval($id)){
				alert('参数错误', -1);
			}
			if(in_array($id, $aGroupIds)){
				alert('您已经关注了ID为 ' . $id . ' 的学生', -1);
			}
		}
		$result = $oTeacher->attentionStudent($this->_aUser['id'], $aWantStudentIds, $toGroup);
		if($result){
			$aNewGroupList = $this->_getGroupList($this->_aUser['id']);
			alert('关注成功', 1, $aNewGroupList);
		}else{
			alert('关注失败', 0);
		}
	}
}