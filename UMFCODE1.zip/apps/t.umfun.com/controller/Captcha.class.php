<?php
class CaptchaController{

	public function __construct(){}

	public function display(){
		$name = get('name');
		echo Verify::display($name);
	}
}
