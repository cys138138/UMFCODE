<?php
define('TITLE', ' - 优满分(UMFun) - 游戏你的学习！');
header("Content-type: text/html; charset=utf-8");
$GLOBALS['VIEW']= new View(APP_VIEW_PATH);
if(get('sf')){
	Cookie::set('sf', get('sf'), time()+30*24*3600);
}
function displayHeader($title, $name){
	echo getHeader($title, $name);
}

function getHeader($title = '', $name){
	$title .= TITLE;
	assign('name', $name);
	assign('title', $title);
	return fetch('header.html.php');
}


function displayFooter(){
	echo getFooter();
}

function getFooter(){
	return fetch('footer.html.php');
}

function showNav($type){
	assign('type', $type);
	display('nav.html.php');
}