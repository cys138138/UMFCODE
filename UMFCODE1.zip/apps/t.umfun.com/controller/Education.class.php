<?php

class EducationController{
	
	private $_aUser = '';
	
	public function __construct(){
		$this->_aUser = checkTeacherLogin();
	}
	
	/*
	 * 输出文章列表
	 * 
	 */	
	public function educationList(){
		Teacher::showEducation($this->_aUser['name']);
	}
	
	/*
	 * 文章内容
	 * 
	 */	
	public function article(){
		$id = $_GET['id'];
		Teacher::showArticle($id, $this->_aUser['name']);
	}
}
