<?php
class AccountController{
	public function showLogin(){
		assign('validateJs',j('mobile,password,captcha', 'checkForm', 'showCheckFormError'));
		assign('validateJs2',j('mobileCode', 'checkForm2', 'showCheckFormError2'));
		display('account/login_register.html.php');
	}
	
	//登陆
	public function login(){
		$mobile = post('mobile',0);
		if(!$mobile ){
			header('Location:' . url('m=Account&a=showLogin'));
			exit;
		}
		
		$vResult = v('mobile');
		if($vResult){
			alert($vResult, 0);
		}
		
		$vResult2 = v('password');
		if($vResult2){
			alert($vResult, 0);
		}
		
		$password = post('password');
		//默认记住登陆密码
		$autoLogin = post('autoLogin') ? 1 : 0;
		$teacherLoginCaptcha = post('captcha');
		if(!Verify::match('teacherLoginCaptcha', $teacherLoginCaptcha)){
			alert('验证码错误！', 0);
		}
		
		$oTeacher = m('Teacher');
		$aTeacher = $oTeacher->getTeacherInfoByMobileAndPassword($mobile, $password);
		if($aTeacher === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aTeacher){
			alert('账号或密码输入有误！', 0);
		}
		
		Cookie::setEncrypt('teacherId', $aTeacher['id'], time() + 31536000);
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$autoLoginCode = md5($userAgent . $aTeacher['id']);
		if($autoLogin == 1){
			Cookie::setXcrypt('teacherAutoLogin', $autoLoginCode, time() + 31536000);
		}else{
			Cookie::setXcrypt('teacherAutoLogin', $autoLoginCode);
		}
		
		alert('登陆成功！', 1);
	}
	
	public function logout(){
		Cookie::delete('teacherAutoLogin');
		Cookie::delete('teacherMobile');
		header('location:' . url('m=Account&a=showLogin'));
	}
	
	public function register(){
		$mobile = post('mobile');
		if(!$mobile ){
			header('Location:' . url('m=Parents&a=showRegister'));
			exit;
		}
		$mResult = v('mobile');
		if($mResult){
			alert($mResult, -1);
		}
		
		$mobileCode = post('mobileCode');
		$mcResult = v('mobileCode');
		if($mcResult){
			alert($mcResult, -1);
		}
		
		$cookieName = Xxtea::xcrypt('TeacherRegister' . $mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('网络可能有点慢，请重新获取手机校验码!',-1);
		}
		
		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('网络可能有点慢，请重新获取手机校验码!',-1);
		}
		
		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('网络可能有点慢，请重新获取手机校验码!', -1);
		}
		
		if($mobileCode != $verifyArray[0]){
			alert('手机校验码输入错误!', -1);
		}
		
		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}
		
		$oTeacher = m('Teacher');
		//生成随机密码
		$password = rand(10000000,99999999);
		
		$msgText = '恭喜您在优满分注册成功，您的登陆密码是：' . $password . '，为了您的账号安全，请及时登陆网址是：t.umfun.com，修改您的密码！';
		$sendResult = sendMobileMessage($mobile, $msgText);
		if(!$sendResult){
			alert('信息发送失败！未注册成功！', 0);
		}
		
		$aData['mobile'] = $mobile;
		$aData['password'] = $password;
		$aData['create_time'] = time();
		$result = $oTeacher->addTeacher($aData);
		if($result === false){
			alert('网络可能有点慢！请稍后再试！', 0);
		}elseif(!$result){
			alert('注册失败！',0);
		}else{
			alert('注册成功，密码已发送至您的手机！',1);
		}
		
	}
	
	//发送手机校验码---用于注册和找回密码
	public function sendTeacherMobileVerify(){
		$mobile = post('mobile');
		$type = post('type',0);
		if(!$mobile ){
			header('Location:' . url('m=Parents&a=showRegister'));
			exit;
		}
		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}
		
		$oTeacher = m('Teacher');
		$aTeacher = $oTeacher->getTeacherInfoByMobile($mobile);
		if($aTeacher === false){
			alert('网络可能有点慢，请稍后再试！', -1);
		}elseif($aTeacher && !$type){
			alert('此手机号码已经被注册！', -1);
		}elseif(!$aTeacher && $type){
			alert('不存在此手机账号！', -1);
		}
		
		$nextVerify =  Xxtea::xcrypt('nextVerify_t');
		//验证发送验证码时间超过一分钟没
		if(Cookie::isSetted($nextVerify)){
			$nextTime = Cookie::getDecrypt($nextVerify);
			if(time() < $nextTime){
				alert('请稍后再试', 0);
			}
		}
		
		//取得6位数的手机验证码
		$time = str_replace('.', '', microtime(true));
		$start = rand(0, strlen($time)-6);
		$code = substr($time, $start, 6);
		$msgText = urlencode('您好，您在优满分系统申请注册，您的验证码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作');
		$returnStatus = sendMobileMessage($mobile, $msgText);
		
		if($returnStatus > 0){
			//下次发送时间　60秒以后
			Cookie::setEncrypt($nextVerify , time()+60);
			$cookieName = Xxtea::xcrypt('TeacherRegister'.$mobile);
			$endTime = time()+900;
			Cookie::setEncrypt($cookieName, $code . '|' . $endTime);
		}
		
		alert('校验码已发送，请及时查看手机短信以便完成操作！', 1);
	}

	//显示忘记密码界面
	public function showFindPassword(){
		assign('validateJs',j('mobile'));
		display('account/find_password.html.php');
	}
	
	//找回密码
	public function findPassword(){
		$mobile = post('mobile');
		if(!$mobile ){
			header('Location:' . url('m=Account&a=showFindPassword'));
			exit;
		}
		$mobileCode = post('mobileCode');
		$vResult = w('isNumber(6)', $mobileCode);
		if(!$vResult){
			alert('手机校验码格式不正确！', -1);
		}
		$oTeacher = m('Teacher');
		
		//手机校验码不存在
		$cookieName = Xxtea::xcrypt('TeacherRegister' . $mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('手机校验码错误', -1);
		}
		
		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('手机校验码错误', -1);
		}
		
		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('手机校验码错误', -1);
		}
		
		if($mobileCode != $verifyArray[0]){
			alert('手机校验码错误', -1);
		}
		
		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}
		
		$password = rand(10000000,99999999);
		//找回成功后发一条信息通知家长
		$msgText = urlencode('您好，您在优满分系统成功找回了密码：'. $password .'，为了您的账号安全，请您尽快登陆：t.umfun.com，修改您的密码');
		$sendResult = sendMobileMessage($mobile, $msgText);
		if(!$sendResult > 0){
			alert('信息发送失败！', -1);
		}
		
		$aData['password'] = md5($password);
		$isSetSuccess = $oTeacher->setTeacherInfoByMobile($aData, $mobile);
		
		if($isSetSuccess === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}elseif(!$isSetSuccess){
			alert('找回密码失败！', -1);
		}else{
			alert('找回密码成功！', 1);
		}	
	}
	
	/**
	 *完善资料页面
	 */
	public function showCompleteUserInfo(){
		$aUser = isTeacherLogin();
		displayHeader('家长版', $aUser['mobile']);
		display('index/complete_user_info.html.php');
		displayFooter();
	}
	
	/**
	 *完善资料
	 */
	public function completeUserInfo(){
		$aUser = isTeacherLogin();
		$subject = post('subject');
		$schoolId = intval(post('school_id'));
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('科目不存在', -1);
		}
		$oUser = new UserModel();
		$aSchoolInfo = $oUser->getSchoolInfoBySchoolId($schoolId);
		if(!$aSchoolInfo){
			alert('学校不存在', -1);
		}
		$oUser = new UserModel();
		$oTeacher = new TeacherModel();
		$aTeacher = array(
			'id' => $aUser['id'],
			'school_id' => $schoolId,
			'subject_id' => $subject
		);
		if($oTeacher->setTeacher($aTeacher)){
			alert('OK', 1);
		}else{
			alert('修改资料失败', 0);
		}
	}
	
	/**
	 *根据地区id获取学校信息
	 */
	public function schoolInfo(){
		isTeacherLogin();
		$oUser = m('User');
		$areaId = post('areaId');
		$isAreaId = w('range(110101, 659004)', $areaId);
		if(!$isAreaId){
			alert('请选择所在的地区', 0);
		}
		$aSchoolList = $oUser->getSchoolListByAreaId($areaId);
		if($aSchoolList === false){
			alert('网络可能有点慢,请稍后再试!', 0);
		}elseif($aSchoolList){
			alert('获取成功', 1, $aSchoolList);
		}
	}
	
	/**
	 *修改资料
	 */
	public function showEditUserInfo(){
		$aUser = isTeacherLogin();
		$mobile = substr($aUser['mobile'], 0, 3) . '****' . substr($aUser['mobile'], 7, 4);
		assign('validateJs', j('password,captcha'));
		assign('mobile', $mobile);
		displayHeader('账户设置', $aUser['mobile'], $aUser['subject_id']);
		display('account/edit_user.html.php');
		displayFooter();
	}
	
	//修改密码
	public function updatePassword(){
		$aUser = isTeacherLogin();
		$curPassword = post('curPassword');
		$newPassword = post('newPassword');
		$captcha = post('captcha');
		$mobile = $aUser['mobile'];
		$vResult = v('newPassword');
		if($vResult){
			alert($vResult, -1);
		}
		
		if($newPassword == $curPassword){
			alert('当前密码与新输入密码一样！',-1);
		}
		
		$oTeacher = m('Teacher');
		$aTeacher = $oTeacher->getTeacherInfoByMobileAndPassword($mobile,$curPassword);
		if($aTeacher === false){
			alert('网络可能有点慢，请稍后再试！',-1);
		}elseif(!$aTeacher){
			alert('账号信息不正确,可能密码不正确！',-1);
		}
	
		if(!Verify::match('setTeacherCaptcha',$captcha)){
			alert('验证码错误!',-1);
		}
		
		$aData['password'] = $newPassword;
		$aData['id'] = $aTeacher['id'];
		
		$result = $oTeacher->setTeacher($aData);
		
		if($result === false){
			alert('网络可能有点慢，请稍后再试！',-1);
		}elseif(!$result){
			alert('修改密码失败！请稍后再试！',-1);
		}else{
			alert('修改密码成功！',1);
		}	
	}
	
	//发送手机验证码---修改手机号码
	public function sendSetTeacherMobileCode(){
		$aUser = isTeacherLogin();
		//验证密码
		$curPassword = post('curPassword');
		$isPassword = w('length(6,16)', $curPassword);
		if(!$isPassword){
			alert('当前密码格式不正确', -1);
		}
		//验证手机号
		$mobile = post('mobile');
		$curMobile = $aUser['mobile'];
		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}
		
		if($mobile == $curMobile){
			alert('新输入的手机和当前登陆的手机一致！', -1);
		}
		
		$oTeacher = m('Teacher');
		$aTeacher = $oTeacher->getTeacherInfoByMobileAndPassword($curMobile,$curPassword);
		if($aTeacher === false){
			alert('网络可能有点慢，请稍后再试！', -1);
		}elseif(!$aTeacher){
			alert('账号信息不正确，可能密码填写错误！', -1);
		}
		
		$aTeacher2 = $oTeacher->getTeacherInfoByMobile($mobile);
		if($aTeacher2 === false){
			alert('网络可能有点慢，请稍后再试！', -1);
		}elseif($aTeacher2){
			alert('此用户账号已经存在系统中！', -1);
		}
		
		 
		$nextVerify =  Xxtea::xcrypt('nextVerify_setTeacher');
		//验证发送验证码时间超过一分钟没
		if(Cookie::isSetted($nextVerify)){
			$nextTime = Cookie::getDecrypt($nextVerify);
			if(time() < $nextTime){
				alert('请稍后再试', 0);
			}
		}
		
		//取得6位数的手机验证码
		$time = str_replace('.', '', microtime(true));
		$start = rand(0, strlen($time)-6);
		$code = substr($time, $start, 6);
		$msgText = urlencode('您好，您在优满分系统申请更换用户手机号，的手机校验码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作！');
		$returnStatus = sendMobileMessage($mobile, $msgText);
		if($returnStatus > 0){
			//下次发送时间　60秒以后
			Cookie::setEncrypt($nextVerify , time()+60);
			$cookieName = Xxtea::xcrypt('TeacherSetPhone'.$mobile);
			$endTime = time()+900;
			Cookie::setEncrypt($cookieName, $code . '|' . $endTime);
			alert('校验码已发送，请及时查看手机短信以便完成操作！', 1);
		}else{
			alert('校验码发送失败，请一分钟后重新发送！', -1);
		}	
	}
	
	//修改手机号码
	public function updatePhone(){
		$aUser = isTeacherLogin();
		//验证手机号
		$mobile = post('mobile');
		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}
		
		$mobileCode = post('mobileCode');
		//验证手机校验码
		$cookieName = Xxtea::xcrypt('TeacherSetPhone'.$mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('网络可能有点慢，请重新获取手机校验码!',-1);
		}
		
		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('网络可能有点慢，请重新获取手机校验码!',-1);
		}
		
		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('网络可能有点慢，请重新获取手机校验码!', -1);
		}
		
		if($mobileCode != $verifyArray[0]){
			alert('手机校验码输入错误!', -1);
		}
		
		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}
		
		$oTeacher = m('Teacher');
		$curMobile = $aUser['mobile'];
		$aData['mobile'] = $mobile;
		$isSetSuccess = $oTeacher->setTeacherInfoByMobile($aData, $curMobile);
		if($isSetSuccess === false){
			alert('网络可能有点慢，请稍后再试!', -1);
		}elseif(!$isSetSuccess){
			alert('修改手机号码失败!', -1);
		}else{
			alert('修改手机号码成功!', 1);
		}
	}
}
