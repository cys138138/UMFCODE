<?php display('account/header.html.php');?>

    <!--主体 [-->
    <div class="t_main">
        <div class="column">

            <!--找回密码 [-->
            <div class="forgot_mod">
                <div class="hd">
                    <i class="ent_ico ent_ico_forgot"></i>
                    <h2 class="row">找回密码</h2>
                </div>
                <div class="bd">
                    <div class="edit_full">
                        <p class="item">
                            <span class="tit">请输入您的手机：</span>
                            <input class="text" type="text" name="mobile" id="mobile"/>
                        </p>
                       
                        <p class="item">
                            <span class="tit">手机校验码：</span>
                            <input class="text code" type="text" name="mobileCode" id="mobileCode"/>
                            <a class="getcaptcha" id="sendMobileCode" onclick="getTeacherMobileCode();" href="javascript:;">免费获取校验码</a>
                        </p>
                        <p class="item btnbox">
                            <input class="btn" onclick="sureFind();" id="findButton" type="button" value="立刻找回密码"/>
                        </p>
                    </div>
                </div>
            </div>
            <!--找回密码 ]-->


        </div>
    </div>
    <!--主体 [-->
<script>
	<?php echo $validateJs; ?>

	//60秒倒计时
	var X = 0, T = 0;
	function afterSendVerify(){
		if(X < 61){
			T = setTimeout("X++;$('#sendMobileCode').text('"+(60-X)+"秒后可再次发送');afterSendVerify();", 1000);
		}else{
			X = 0;
			clearTimeout(T);
			$('#sendMobileCode').text('再次发送校验码').attr("onclick", 'getTeacherMobileCode();');
			$('#mobile').removeAttr('disabled');
		}
	}
	
	function getTeacherMobileCode(){
		if(!checkForm()){
			return false;
		}
		var mobile = $('#mobile').val();
		$('#mobile').attr('disabled',true);
		$('#sendMobileCode').attr("onclick", '').css('color','#f30');
		$.ajax({
			type : 'post',
			url : '<?php echo url("m=Account&a=sendTeacherMobileVerify"); ?>',
			data : {mobile : mobile, type : 1},
			success : function(aResult){
				if(aResult.status == 1){
					afterSendVerify();
					$('#mobileCode').focus();
				}else{
					$('#sendMobileCode').text('再次发送校验码').bind("click", getTeacherMobileCode);
					$('#mobile').removeAttr('disabled');
				}
				UBox.show(aResult.msg, aResult.status);
			}
		});
	}
	
	function sureFind(){
		if(!checkForm()){
			return false;
		}
		var oMobileCode = new Validater('mobileCode'),
		isMobileCode = oMobileCode.isNumber(6),
		mobile = $('#mobile').val(),
		mobileCode = $('#mobileCode').val();
		if(isMobileCode != true){
			oMobileCode.errorCallBack("请填写正确的校验码!", isMobileCode);
			return;
		}
		$('#findButton').attr('disabled', true).attr('style', 'background-color:#ccc;margin-left:5px;');
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=findPassword'); ?>',
			data : {mobile : mobile, mobileCode : mobileCode},
			success : function(result){
				$('#findButton').removeAttr('disabled').attr('style', 'background-color:#0099CC;');
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Account&a=showLogin'); ?>');
				}else{
					$('#mobile').removeAttr('disabled');
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍后再试！', -1);
			}
		});
	}

</script>

<?php display('account/footer.html.php');?>