
    <!--底部 [-->
    <div class="t_footer">
        <div class="column">
            <div class="copyright">
                <p>
                    <a href="http://www.umfun.test">首页</a>|
                    <a href="http://pay.umfun.test">充值中心</a>|
                    <a href="http://about.umfun.test/contract.html">服务条款</a>|
                    <a href="http://about.umfun.test/statement.html">法律声明</a>|
                    <a href="http://about.umfun.test/contact.html">联系我们</a>|
                    <a href="http://about.umfun.test/contact.html">商务合作</a>
                </p>
                <p>Copyright &copy; 优满分(UMFun.com) 2013 All Rights Reserved 工信部ICP备案号：粤ICP备13000602号</p>
            </div>
        </div>
    </div>
    <!--底部 ]-->



</div>
<!--家长版 ]-->


<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>