 <script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['validater']; ?>"></script>   
	<!--主体 [-->
    <div class="t_main">
        <div class="column">

            <!--账户设置 [-->
            <div class="mod acc_mod">
                <div class="hd">
                    <h2>账户设置</h2>
                </div>
                <div class="bd c">

                    <div class="side">
                        <div class="mobile">
                            <h3 class="title">当前登陆手机号</h3>
                            <p class="num"><?php echo $mobile; ?></p>
                        </div>
                    </div>

                    <div class="cont">
                        <div class="menu">
                            <a class="cur" href="#">修改登陆密码</a>
                            <a href="#">修改登陆手机号</a>
                        </div>
                        <div class="list">
                            <div class="edit_full">
                                <p class="item">
                                    <span class="tit">当前登陆密码：</span>
                                    <input class="text" type="password" name="cur_password" id="cur_password"/>
                                </p>
                                <p class="item">
                                    <span class="tit">新登陆密码：</span>
                                    <input class="text" type="password" id="new_password" name="password"/>
                                    <em class="tips">至少6位.</em>
                                </p>
                                <p class="item">
                                    <span class="tit">重复新密码：</span>
                                    <input class="text" type="password" id="repeat_password" name="repeat_password"/>
                                </p>
                                <p class="item">
                                    <span class="tit">验证码：</span>
                                    <input class="text code" type="text"  name="captcha" id="setTeacherCaptcha" />
                                    <a class="captcha" onclick="refreshCatcph();" href="javascript:;"><img src="<?php echo url('m=Captcha&a=display&name=setTeacherCaptcha'); ?>" width="90" id="verify_Img" height="40" alt=""/></a>
                                </p>
                                <p class="item">
                                    <input class="btn" onclick="updatePassword();" type="button" value="立刻修改登陆密码"/>
                                </p>
                            </div>
                            <div class="edit_full">
                                <p class="item">
                                    <span class="tit">当前登陆密码：</span>
                                    <input class="text" type="password" name="password2" id="cur_password2" />
                                </p>
                                <p class="item">
                                    <span class="tit">新手机号码：</span>
                                    <input class="text" type="text" id="mobile" name="mobile"/>
                                    <a class="act" href="javascript:;" id="sendMobileCode" onclick="getSetTeaMobileCode();">获取手机验证码</a>
                                </p>
                                <p class="item">
                                    <span class="tit">手机验证码：</span>
                                    <input class="text" type="text" id="mobileCode" name="mobileCode"/>
                                </p>
                                <p class="item">
                                    <input class="btn" type="button" value="立刻修改手机号码" onclick="updatePhone();" id="updatePhoneBut"/>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--账户设置 ]-->
        </div>
    </div>
    <!--主体 [-->
	
<script type="text/javascript">
	<?php echo $validateJs; ?>
	function refreshCatcph(){
		var setTeacherCaptcha = "<?php echo url('m=Captcha&a=display&name=setTeacherCaptcha'); ?>?" + Math.floor(Math.random() * 10000);
		$('#verify_Img').attr('src', setTeacherCaptcha);
		$('#setTeacherCaptcha').val('');
	}
	
	function updatePassword(){
		var captcha = $('#setTeacherCaptcha').val(),
		curPassword = $('#cur_password').val(),
		repeatPassword = $('#repeat_password').val(),
		newPassword = $('#new_password').val();
		var oCurPassword = new Validater('cur_password');
		var isPassword = oCurPassword.length(6,16);
		if(isPassword != true){
			oCurPassword.errorCallBack('请填写正确的密码！',isPassword);
			return ;
		}
		if(newPassword == curPassword){
			UBox.show('当前密码与新输入密码一致！',-1);
			return;
		}
		if(repeatPassword != newPassword){
			UBox.show('新密码与重复密码输入不一致！', -1);
			return;
		}
		if(!checkForm()){
			return false;
		}
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=updatePassword'); ?>',
			data : {
				newPassword : newPassword,
				curPassword : curPassword,
				captcha : captcha
			},
			success : function(result){
				if(result.status == 1){
					refreshCatcph();
					UBox.show(result.msg, result.status, '<?php echo url('m=Account&a=showEditUserInfo'); ?>');
				}else{
					refreshCatcph();
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再进行修改!');
			}
		});
	}
	
	//60秒倒计时
	var X = 0, T = 0;
	function afterSendVerify(){
		if(X < 61){
			T = setTimeout("X++;$('#sendMobileCode').text('"+(60-X)+"秒后可再次发送');afterSendVerify();", 1000);
		}else{
			X = 0;
			clearTimeout(T);
			$('#sendMobileCode').text('再次发送校验码').attr("onclick", 'getSetTeaMobileCode();');
			$('#mobile').removeAttr('disabled');
		}
	}
	
	function getSetTeaMobileCode(){
		var curPassword = $('#cur_password2').val();
		var mobile = $('#mobile').val();
		var oPassword = new Validater('password2');
		isPassword = oPassword.length(6, 16);
		
		if(isPassword != true){
			oPassword.errorCallBack('请填写正确的密码',isPassword);
			return;
		}
		
		var oMobile = new Validater('mobile');
		isMobile = oMobile.isPhone();
		
		if(isMobile != true){
			oMobile.errorCallBack('请填写正确的手机号码',isMobile);
			return;
		}
		
		$('#mobile').attr('disabled',true);
		$('#sendMobileCode').attr("onclick", '').css('color','#f30');
		$.ajax({
			url : '<?php echo url("m=Account&a=sendSetTeacherMobileCode"); ?>',
			type : 'POST',
			data : {curPassword : curPassword, mobile : mobile},
			success : function(aResult){
				if(aResult.status == 1){
					afterSendVerify();
					$('#mobileCode').focus();
				}else{
					$('#sendMobileCode').text('再次发送校验码').bind("click", getSetTeaMobileCode);
					$('#mobile').removeAttr('disabled');
				}
				UBox.show(aResult.msg, aResult.status);
			},
			error : function(){
				alert('网络可能有点慢！请稍后发送验证码！',-1);
			}
		});
	}
	
	function updatePhone(){
		var curPassword = $('#cur_password2').val();
		var mobile = $('#mobile').val();
		var oPassword = new Validater('password2');
		isPassword2 = oPassword.length(6, 16);
		
		if(isPassword2 != true){
			oPassword.errorCallBack('请填写正确的密码！',isPassword2);
			return;
		}
		
		var oMobile = new Validater('mobile');
		isMobile = oMobile.isPhone();
		
		if(isMobile != true){
			oMobile.errorCallBack('请填写正确的手机号码',isMobile);
			return;
		}
		
		var oMobileCode = new Validater('mobileCode'),
		isMobileCode = oMobileCode.isNumber(6),
		mobileCode = $('#mobileCode').val();

		if(isMobileCode != true){
			oMobileCode.errorCallBack('请填写正确的校验码！',isMobileCode);
			return;
		}
		
		$('#updatePhoneBut').attr('disabled', true).attr('style', 'background-color:#ccc;margin-left:5px;');
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=updatePhone'); ?>',
			data : {mobile : mobile, mobileCode : mobileCode},
			success : function(result){
				$('#updatePhoneBut').removeAttr('disabled').attr('style', 'background-color:#0099CC;');
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Account&a=showEditUserInfo'); ?>');
				}else{
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再进行修改!');
			}
		});
	}
	
	
</script>