<?php display('account/header.html.php');?>
    <!--主体 [-->
    <div class="t_main t_index">
        <div class="column">

            <div id="t_static" class="static_mod">
            	<div class="xxt_login">
            		<a href="<?php echo PC_API_LOGIN_URL; ?>" class="xxt_login_btn"></a>
            	</div>
                <!-- <div class="hd_mod">
                    <ul class="hd">
                        <li class="fl cur">教师登陆</li>
                        <li class="fr">教师注册</li>
                    </ul>
                    <div class="arrow"></div>
                </div>
                <div class="bd_mod">
                    <div class="bd c"> -->
                        <!--登陆 [-->
                        <!-- <div class="list login_mod">
                            <p class="item">
                                <label class="tit"><i class="ent_ico ent_ico_username2"></i></label>
                                <input class="text" type="text" name="mobile" id="mobile" placeholder="请输入手机号码"/>
                            </p>
                            <p class="item">
                                <label class="tit"><i class="ent_ico ent_ico_password2"></i></label>
                                <input class="text" name="password" id="password" type="password" placeholder="请输入密码"/>
                            </p>
                            <p class="item">
                                <label class="tit"><i class="ent_ico ent_ico_captcha2"></i></label>
                                <input class="text code" name="captcha" id="loginCaptcha" type="text" placeholder="验证码"/>
                                <a class="captcha" onclick="refreshCatcph();" href="javascript:;"><img width="85" height="40" src="<?php echo url('m=Captcha&a=display&name=teacherLoginCaptcha'); ?>" id="verify_Img" alt=""/></a>
                            </p>
                            <p class="error" id="error" style="display:none;"><i class="ent_ico ent_ico_error"></i></p>
                            <p class="item btnbox">
                                <input class="btn" onclick="teacherLogin();" id="loginButton" type="button" value="登 录"/>
                            </p>
                            <p class="item actbox">
                            <span class="fl">
                                <span class="custom_checkbox"><input type="checkbox"  name="autoLogin" id="autoLogin" checked="checked" value="1"/></span>
                                <label for="rempass">记住密码</label>
                            </span>
                            <span class="fr">
                                <i class="ent_ico ent_ico_help2"></i>
                                <a class="act" href="<?php echo url('m=Account&a=showFindPassword'); ?>">忘记密码</a>
                            </span>
                            </p>
                        </div> -->
                        <!--登陆 ]-->

                        <!--注册 [-->
                        <!-- <div class="list reg_mod">
                            <p class="item">
                                <input class="text" name="mobile2" id="mobile2" type="text" placeholder="请输入手机号码"/>
                            </p>
                            <p class="item">
                                <input class="text code" name="mobileCode" id="mobileCode"  type="text" placeholder="手机校验码"/>
								<a class="getcaptcha" id="sendMobileCode" onclick="getMobileCode();" href="javascript:;">获取校验码</a>
                            </p>
							<p class="error" id="error2" style="display:none;"><i class="ent_ico ent_ico_error"></i></p>
                            <p class="item btnbox">
                                <input class="btn"  onclick="teacherRegister();" id="loginButton" type="button" value="立刻注册"/>
                            </p>
                        </div> -->
                        <!--注册 ]-->
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!--主体 [-->
<script>
	<?php echo $validateJs; ?>
	<?php echo $validateJs2; ?>
	
	function refreshCatcph(){
		var loginCaptcha = "<?php echo url('m=Captcha&a=display&name=teacherLoginCaptcha'); ?>?" + Math.floor(Math.random() * 10000);
		$('#verify_Img').attr('src', loginCaptcha);
		$('#loginCaptcha').val('');
	}
	
	//60秒倒计时
	var X = 0, T = 0;
	function afterSendVerify(){
		if(X < 61){
			T = setTimeout("X++;$('#sendMobileCode').text('"+(60-X)+"秒后发送');afterSendVerify();", 1000);
		}else{
			X = 0;
			clearTimeout(T);
			$('#sendMobileCode').text('发送校验码').attr("onclick", 'getMobileCode();').attr('style', 'background-color:#f30');
			$('#mobile').removeAttr('disabled');
		}
	}
	
	function teacherLogin(){
		if(!checkForm()){
			return false;
		}
		var mobile = $('#mobile').val();
		var password = $('#password').val();
		var captcha = $('#loginCaptcha').val();
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=login'); ?>',
			data : {mobile : mobile, password : password, captcha : captcha},
			success : function(result){
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Index&a=showEsStats'); ?>');
				}else{
					$('#error').slideDown('fast').empty().append('<i class="ent_ico ent_ico_error"></i>' + result.msg);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再登陆!');
			}
		});
	}
	
	//获取手机校验码
	function getMobileCode(){
		var mobile = $('#mobile2').val();
		
		var oMobile = new Validater('mobile2');
		isMobile = oMobile.isPhone();
		if(isMobile != true){
			$('#error2').slideDown('fast').empty().append('<i class="ent_ico ent_ico_error"></i>请输入正确的手机号码！');
			return;
		}

		$('#sendMobileCode').attr('onclick', '').attr('style', 'background-color:#ccc');
		
		$.ajax({
			url : '<?php echo url("m=Account&a=sendTeacherMobileVerify"); ?>',
			type : 'post',
			data : {mobile : mobile},
			success : function(aResult){
				
				if(aResult.status == 1){
					afterSendVerify();
					$('#mobileCode').focus();
				}else{
					$('#sendMobileCode').text('发送校验码').bind("click", getMobileCode).attr('style', 'background-color:#f30');
				}
				UBox.show(aResult.msg, aResult.status);
			},
			error : function(){
				alert('网络可能有点慢！请稍后发送验证码！',-1);
			}
		});
	}
	
	function showCheckFormError(message){
		$('#error').slideDown('fast').empty().append('<i class="ent_ico ent_ico_error"></i>' + message);
	}
	
	function showCheckFormError2(message){
		$('#error2').slideDown('fast').empty().append('<i class="ent_ico ent_ico_error"></i>' + message);
	}
	function teacherRegister(){
		var oMobile = new Validater('mobile2');
		isMobile = oMobile.isPhone();
		if(isMobile != true){
			$('#error2').slideDown('fast').empty().append('<i class="ent_ico ent_ico_error"></i>请输入正确的手机号码！');
			return;
		}
		if(!checkForm2()){
			return false;
		}
		var mobile = $('#mobile2').val();
		var mobileCode = $('#mobileCode').val();
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=register'); ?>',
			data : {mobile : mobile, mobileCode : mobileCode},
			success : function(result){
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Login&a=showLogin', '', APP_LOGIN); ?>');
				}else{
					$('#error2').slideDown('fast').empty().append('<i class="ent_ico ent_ico_error"></i>' + result.msg);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再登陆!');
			}
		});
	}

</script>
<?php display('account/footer.html.php');?>