<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['validater']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<title>教师登陆</title>
</head>
<style type="text/css">
	.main{ width:500px; height:500px; border:1px solid #ccc; margin:0 auto;}
	.column{width:200px; height:100px; margin:0 auto;}
	.item{ width:500px;height:40px;}
	.code_active{ cursor:pointer;}
</style>
<body>
    <!--主体 [-->
    <div class="main reg_main">
		
        <div class="column">
			<form method="post" class="loginForm">
			   <div class="login c">
				   <div class="login_mod">
					   <div class="title c">
						   <h2>教师登陆</h2>
					   </div>
					   <br />
					   <div class="item c">
							用户账号：
						   <input type="text"  name="mobile" id="mobile" class="text"/>
						   <span class="iconbox"><i class="reg_icon icon_reg_name"></i></span>
					   </div>
					   <div class="item c">
							登陆密码：
						   <input type="password"  name="password" id="password" class="text"/>
						   <span class="iconbox"><i class="reg_icon icon_reg_pass"></i></span>
					   </div>
					   <div class="item c">
							验证码：
						   <input type="text" name="captcha" id="loginCaptcha" class="text code"/>
						   <span class="iconbox"><i class="reg_icon icon_reg_code"></i></span>
						   <a onclick="refreshCatcph();" class="code_active"><img src="<?php echo url('m=Captcha&a=display&name=teacherLoginCaptcha'); ?>" width="100" height="30" id="verify_Img" alt=""/></a>
					   </div>
					   <br />
					   <div class="item c">
						   <label class="keep">
							   <input type="checkbox" name="autoLogin" id="autoLogin" checked="checked" value="1" />
							   记住登陆
						   </label>
						   <a href="<?php echo url('m=Account&a=showFindPassword'); ?>" class="active">忘记密码？</a>
					   </div>
					   <div class="item c">
						   <input class="reg_icon reg_btn_01" type="button" onclick="teacherLogin();" id="loginButton" value="立即登陆"/>
						   <div id="error" class="error"><i class="reg_icon icon_reg_error"></i><em id="errorText"></em></div>
					   </div>
				   </div>
			   </div>
			</form>
        </div>
    </div>
    <!--主体 ]-->
<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>
<script>
	<?php echo $validateJs; ?>

	function refreshCatcph(){
		var loginCaptcha = "<?php echo url('m=Captcha&a=display&name=teacherLoginCaptcha'); ?>?" + Math.floor(Math.random() * 10000);
		$('#verify_Img').attr('src', loginCaptcha);
		$('#loginCaptcha').val('');
	}

	function teacherLogin(){
		if(!checkForm()){
			return false;
		}
		var mobile = $('#mobile').val();
		var password = $('#password').val();
		var captcha = $('#loginCaptcha').val();
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=login'); ?>',
			data : {mobile : mobile, password : password, captcha : captcha},
			success : function(result){
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Account&a=index'); ?>');
				}else{
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再登陆!');
			}
		});
	}



</script>