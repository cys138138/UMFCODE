<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>优满分(UMFun) - 游戏你的学习！ - 优满分(UMFun) - 中国最大中小学生在线游戏化学习平台！</title>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['validater']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['library']; ?>"></script>
<link rel="shortcut icon" href="<?php echo $GLOBALS['RESOURCE']['favicon']; ?>" />
<!--[if lte IE 6]><script src="<?php echo $GLOBALS['RESOURCE']['dd_belated_png']; ?>"></script><![endif]-->
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_global2']; ?>" />
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_entrance2']; ?>" />
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_global2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_entrance2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery_easydropdown2']; ?>"></script>
</head>
<body>


<!--家长版 [-->
<div class="teacher">


    <!--头部 [-->
    <div class="t_header">
        <div class="column">
            <h1 class="ent_ico logo"><a class="hidetxt" href="<?php echo url('m=index&a=index');?>">优满分(UMFun) - 家长版</a></h1>
        </div>
    </div>
    <!--头部 [-->