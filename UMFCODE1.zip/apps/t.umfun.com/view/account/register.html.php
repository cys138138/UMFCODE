<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['validater']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<title>教师注册</title>
</head>
<style type="text/css">
	.main{ width:500px; height:500px; border:1px solid #ccc; margin:0 auto;}
	.column{width:200px; height:100px; margin:0 auto;}
	.item{ width:500px;height:40px;}
	.code_active{ cursor:pointer;}
</style>
<body>
    <!--主体 [-->
    <div class="main reg_main">
        <div class="column">
			<form method="post" class="loginForm">
			   <div class="login c">
				   <div class="login_mod">
					   <div class="title c">
						   <h2>教师注册</h2>
					   </div>
					   <br />
					   <div class="item c">
							手机号码：
						   <input type="text"  name="mobile" id="mobile" class="text"/>
						   <span class="iconbox"><i class="reg_icon icon_reg_name"></i></span>
					   </div>
					   <div class="item c">
							手机校验码：
						   <input type="text"  name="mobileCode" id="mobileCode" class="text"/>
						   <span class="iconbox"><i class="reg_icon icon_reg_pass"></i></span>
					   </div>
					   <div class="item c">
							验证码：
						   <input type="text" name="captcha" id="registerCaptcha" class="text code"/>
						   <span class="iconbox"><i class="reg_icon icon_reg_code"></i></span>
						   <a onclick="refreshCatcph();" class="code_active"><img src="<?php echo url('m=Captcha&a=display&name=registerCaptcha'); ?>" width="100" height="30" id="verify_Img" alt=""/></a>
					   </div>
					   <br />
					   <div class="item c">
							<input type="button" class="use_btn" id="sendMobileCode" value="免费获取校验码" onclick="getRegisterMobileCode();" />
							<input class="reg_icon reg_btn_01" type="button" onclick="teacherRegister();" id="loginButton" value="立即注册"/>
							<div id="error" class="error"><i class="reg_icon icon_reg_error"></i><em id="errorText"></em></div>
					   </div>
				   </div>
			   </div>
			</form>
        </div>
    </div>
    <!--主体 ]-->
<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>
<script>
	<?php echo $validateJs; ?>

	function refreshCatcph(){
		var registerCaptcha = "<?php echo url('m=Captcha&a=display&name=registerCaptcha'); ?>?" + Math.floor(Math.random() * 10000);
		$('#verify_Img').attr('src', registerCaptcha);
		$('#registerCaptcha').val('');
	}
	
	//60秒倒计时
	var X = 0, T = 0;
	function afterSendVerify(){
		if(X < 61){
			T = setTimeout("X++;$('#sendMobileCode').val('"+(60-X)+"秒后可再次发送');afterSendVerify();", 1000);
		}else{
			X = 0;
			clearTimeout(T);
			$('#sendMobileCode').val('再次发送校验码').attr("onclick", 'getRegisterMobileCode();').removeAttr('disabled').attr('style', 'background-color:#f30');
			$('#mobile').removeAttr('disabled');
		}
	}
	
	//获取手机校验码
	function getRegisterMobileCode(){
		var mobile = $('#mobile').val();
		var captcha = $('#registerCaptcha').val();
		if(mobile == ''){
			UBox.show('请输入手机号码！',-1);
			return;
		}
		if(captcha == ''){
			UBox.show('请输入验证码！',-1);
			return;
		}

		var oMobile = new Validater('mobile');
		isMobile = oMobile.isPhone();
		
		if(isMobile != true){
			UBox.show('请填写正确的手机号码!', -1);
			return;
		}
		
		var oCaptcha = new Validater('captcha');
		isCaptcha = oCaptcha.length(5, 5);
		if(isMobile != true){
			UBox.show('请填写正确的验证码!', -1);
			return;
		}
		$('#sendMobileCode').attr('disabled', true).attr('style', 'background-color:#ccc');
		$.ajax({
			url : '<?php echo url("m=Account&a=sendTeacherMobileVerify"); ?>',
			type : 'POST',
			data : {mobile : mobile, captcha : captcha},
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status == 1){
					afterSendVerify();
					$('#mobileCode').focus();
				}else{
					$('#sendMobileCode').val('再次发送校验码').bind("click", getRegisterMobileCode).attr('style', 'background-color:#f30').removeAttr('disabled');
				}
			},
			error : function(){
				alert('网络可能有点慢！请稍后发送验证码！',-1);
			}
		});
	}
	
	
	function teacherRegister(){
		if(!checkForm()){
			return false;
		}
		var mobile = $('#mobile').val();
		var mobileCode = $('#mobileCode').val();
		var captcha = $('#registerCaptcha').val();
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=register'); ?>',
			data : {mobile : mobile, mobileCode : mobileCode, captcha : captcha},
			success : function(result){
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Account&a=showLogin'); ?>');
				}else{
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再登陆!');
			}
		});
	}



</script>