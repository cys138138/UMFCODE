<a <?php if($type == 2){ ?> class="cur" <?php } ?> href="<?php echo url('m=Index&a=index'); ?>">学生成绩</a>
<a <?php if($type == 1){ ?> class="cur" <?php } ?> href="<?php echo url('m=Index&a=showEsStats'); ?>">教学参考数据</a>
<a <?php if($type == 3){ ?> class="cur" <?php } ?> href="<?php echo url('m=Education&a=educationList'); ?>">教育资讯</a>