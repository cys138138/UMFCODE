<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_education_main']; ?>" />
    
<section id="container">
        <div class="hd">
            <h2>教育资讯</h2>
            <a href="<?php echo url('m=Index&a=index'); ?>" class="backHome">返回首页</a>
        </div>
        <section id="content" class="clearfix">
        <?php
		foreach($aNewsContentList as $key => $plateTitle){
		?>
            <div class="listInfo">
                <div class="listTitle">
                    <h2><?php echo $plateTitle['name']?></h2>
                </div>
                <ul>
					<?php
					foreach($plateTitle['content_list'] as $key => $titleList){
					?>
                    <li><a href="<?php echo url('m=Education&a=article&id='.$titleList['id']);?>"><?php echo $titleList['title'];?></a></li>
					<?php
					}
					?>
                </ul>
            </div>	
		<?php 
		}
		?>	
        </section>
    </section>
  