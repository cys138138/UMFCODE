<!DOCTYPE html>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_education_main']; ?>" />
    <section id="container">
        <div class="hd">
            <h2>教育资讯</h2>
            <a href="<?php echo url('m=Index&a=index'); ?>" class="backHome">返回首页</a>
        </div>
        <article>
            <h1><?php echo $aNewsContentInfo['title']; ?></h1>
            <div class="entry">
                <p><?php echo $aNewsContentInfo['content'];?></p>
            </div>
        </article>
    </section>
