<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $title; ?></title>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_global2']; ?>" />
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_entrance2']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_global2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_entrance2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['library']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<script type="text/javascript">
var DOMAIN = '<?php echo DOMAIN_EXTEND; ?>',
DEFAULT_HEAD_IMG = '<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>',
DEFAULT_IMG = '<?php echo $GLOBALS['RESOURCE']['image_error']; ?>';
</script>
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>

<iframe style="width:100%; height:48px;" src="http://2012.edu.gd.chinamobile.com/extsys.do?action=appheader&utype=1&css=3" frameborder="0"></iframe>
<!--教师版 [-->
<div class="teacher">

    <!--头部 [-->
    <div class="t_header">
        <div class="column">
            <h1 class="ent_ico logo"><a class="hidetxt" href="<?php echo url('m=Index&a=showEsStats'); ?>">优满分(UMFun) - 家长版</a></h1>
            <div class="user">
                <div class="profile">
                    欢迎你，<b><?php echo $name; ?></b>
                </div>
                <div class="set">
                    <ul class="list">
                        <!--<li><a href="<?php echo url('m=Account&a=showEditUserInfo'); ?>">账户设置</a></li>-->
                        <li><a href="<?php echo url('m=Account&a=logout'); ?>">安全退出</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--头部 [-->

    <div class="activity_teacher" id="activityTeacher">
        <div class="column por">
            <div class="activity_inner">
                <a href="http://www.umfun.com/activity/study_tour.html" target="_blank"><img src="<?php echo $GLOBALS['RESOURCE']['activity_adv_s']; ?>" class="activity_img" alt="" id="activityIMGS"></a>
                <a href="http://www.umfun.com/activity/mission.html" target="_blank"><img src="<?php echo $GLOBALS['RESOURCE']['activity_adv_s1']; ?>" class="activity_img" alt="" id="activityIMGS1"></a>
            </div>
        </div>
    </div>