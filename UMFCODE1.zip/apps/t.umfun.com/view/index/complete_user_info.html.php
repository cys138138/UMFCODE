  <!--主体 [-->
    <div class="t_main">
        <div class="column">

            <!--请完善你的资料 [-->
            <div class="improve_mod">
                <div class="hd">
                    <i class="ent_ico ent_ico_improve"></i>
                    <h2 class="row">请完善你的资料</h2>
                </div>
                <div class="bd">
                    <div class="edit_full">
                        <div class="item subjects_item">
                            <span class="tit"><i class="ent_ico ent_ico_subject"></i>科目:</span>
                            <input name="subject" id="subject" onclick="showSubject()" class="text" type="text" />
                            <i class="arrow"></i>
                            <div id="subjectList" class="choose_subjects"><!--弹窗-->
								<?php
								foreach($GLOBALS['SUBJECT'] as $id => $name){
									if($id <= 3){
								?>
									<a href="javascript:" onclick="selectSubject(this, <?php echo $id; ?>)"><?php echo $name; ?></a>
								<?php
									}
								}
								?>
                            </div>
                        </div>
                        <div class="item school_item">
                            <span class="tit"><i class="ent_ico ent_ico_school"></i>学校:</span>
                            <input class="text" type="text" id="schoolName" name="schoolName" onclick="loadArea();"/>
                            <i class="arrow"></i>
                            <div id="schoolList" class="choose_school"><!--弹窗-->
                                <div class="title">
                                    <h3>请选择学校信息</h3>
                                    <a class="close" href="javascript:;" onclick="hideSchool()" title="关闭">&times;</a>
                                </div>
                                <div class="site">
                                    <div class="c_item">
                                        <select name="province" id="province">
                                        </select>
                                    </div>
                                    <div class="c_item">
                                        <select name="city" id="city">
                                        </select>
                                    </div>
                                    <div class="c_item">
                                        <select name="area" id="area">
                                        </select>
                                    </div>
                                </div>
                                <div class="school">
                                    <div class="c_item">
                                        <select onchange="copySchoolName();" name="school_id" id="school_id">
                                        </select>
                                    </div>
                                    <div class="c_item">
                                        <input class="c_btn" type="button" value="确定" onclick="selectSchool();"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item btnbox">
                            <input onclick="submitUserInfo()" class="btn" type="button" value="立刻进入系统"/>
                        </div>
                    </div>
                </div>
            </div>
            <!--请完善你的资料 ]-->


        </div>
    </div>
    <!--主体 [-->

<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['class_selector2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['school_selector2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector2']; ?>"></script>
<script type="text/javascript">
	var subject = 0;
	
	function selectSubject(obj, id){
		subject = id;
		$('#subject').val($(obj).text());
		$('#subjectList').hide();
	}
	
	function showSubject(){
		$('#subjectList').show();
	}
	
	function showSchool(){
		$('#schoolList').show();
	}
	
	function hideSchool(){
		$('#schoolList').hide();
	}
	
	
	function showSchoolList(aSchoolList){
		var html = '';
		for(var i = 0; i < aSchoolList.length; i++){
			html += '<option value="' + aSchoolList[i].id + '" >' + aSchoolList[i].name + '</option>';	
		}
		oSchoolList.oWrapSchoolList.html(html);
	}
	
	function copySchoolName(){
		var schoolName = $('#school_id option:selected').text();
		$('#schoolName').val(schoolName);
	}
	
	function selectSchool(){
		var area = $('#area').val();
		if(area <= 0){
			UBox.show('请选择省市区再选择学校', -1);
			return;
		}
		copySchoolName();
		hideSchool();
	}
	
	function loadSchoolCallBack(areaId){
		if(areaId > 0){
			oSchoolList.load(areaId);
		}
	}
	
	var oSchoolList = new SchoolList('school_id', '<?php echo url('m=Account&a=schoolInfo'); ?>', $.noop, showSchoolList);
	oSchoolList.initStyle();
	var oPleaseSelecter = new PleaseSelecter('province', 'city', 'area', 0, 0, 0, loadSchoolCallBack, 0);
	
	function loadArea(){
		var province = $('#province option').length;
		var city = $('#city option').length;
		var area = $('#area option').length;
		if(province <= 0 || city <= 0 || area <= 0){
			oPleaseSelecter.load();
		}
		$('#schoolList').fadeIn('fast');
	}
	
	function submitUserInfo(){
		if(subject <= 0){
			UBox.show('请选择所教科目', -1);
			return;
		}
		var school_id = $('#school_id').val();
		if(school_id <= 0){
			UBox.show('请选择学校', -1);
			return;
		}
		
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=completeUserInfo'); ?>',
			data : {
				school_id : school_id,
				subject : subject
			},
			success : function(result){
				if(result.status == 1){
					window.location.href = '<?php echo url('m=Index&a=index'); ?>';
				}else{
					UBox.show(result.msg, result.status);
				}
			}
		});
	}
</script>