<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" type="text/css" rel="stylesheet">
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
 <!--主体 [-->
    <div class="t_main">
        <div class="column">

            <!--教学参考数据 [-->
            <div class="educate_mod">
                <div class="hd">
					<?php showNav(1); ?>
                </div>
                <div class="bd c">
                    <div class="grade">
                        <div class="title">
							<div class="choose">
                                <a id="curSubject" class="act" href="javascript:void(0)">语文</a>
                                <i class="arrow"></i>
                                <ul>
                                    <li><a onclick="setSubject(1, this)" href="javascript:void(0)">语文</a></li>
                                    <li><a onclick="setSubject(2, this)" href="javascript:void(0)">数学</a></li>
                                    <li><a onclick="setSubject(3, this)" href="javascript:void(0)">英语</a></li>
                                </ul>
                            </div>
							
                            <div class="choose">
                                <a id="curGrade" class="act" href="javascript:void(0)">五年级</a>
                                <i class="arrow"></i>
                                <ul>
                                    <li><a onclick="setGrade(5, this)" href="javascript:void(0)">五年级</a></li>
                                    <li><a onclick="setGrade(6, this)" href="javascript:void(0)">六年级</a></li>
                                    <li><a onclick="setGrade(7, this)" href="javascript:void(0)">七年级</a></li>
                                    <li><a onclick="setGrade(8, this)" href="javascript:void(0)">八年级</a></li>
									<li><a onclick="setGrade(9, this)" href="javascript:void(0)">九年级</a></li>
                                </ul>
                            </div>
                        </div>
                        <ul class="list" id="missionList">
                        </ul>
                    </div>
                    <div class="fault">
                        <div class="title">
                            <div class="choose">
                                <a id="curEsType" class="act" href="javascript:void(0)">易错题</a>
                                <i class="arrow"></i>
                                <ul>
                                    <li onclick="selectEsType(1, this)"><a href="javascript:void(0)">易错题</a></li>
									<li onclick="selectEsType(2, this)"><a href="javascript:void(0)">易掌握题</a></li>
                                </ul>
                            </div>
                        </div>
						<div id="tite" class="air">
							<p>请先在左栏选择关卡</p>
						</div>
                        <ul class="list" id="esList">

                        </ul>
                        <div style="display:none" id="pageList" class="educate_page">
                            <a onclick="getEsList(false)" href="javascript:void(0)">上一页</a>
                            <a id="curPage" class="cur" href="javascript:void(0)">0</a>/
                            <a id="totalPage" href="javascript:void(0)">0</a>
                            <a onclick="getEsList(true)" href="javascript:void(0)">下一页</a>
                        </div>
                    </div>
                </div>
            </div>
            <!--教学参考数据 ]-->
        </div>
    </div>
    <!--主体 [-->
	
<script type="text/javascript">
	var gradeId = 5;
	var subjectId = 1;
	
	function setGrade(thisGrade, obj){
		gradeId = thisGrade;
		if(obj){
			$('#curGrade').text($(obj).text());
		}
		getMissionList(obj);
	}
	
	function setSubject(thisSubject, obj){
		subjectId = thisSubject;
		if(obj){
			$('#curSubject').text($(obj).text());
		}
		getMissionList(obj);
	}
	
	function getMissionList(obj){
		ajax({
			url : '<?php echo url("m=Index&a=getMissionList"); ?>',
			data : {
				gradeId : gradeId,
				subjectId : subjectId
			},
			success : function(aResult){
				var data = aResult.data;
				if(data.length > 0){
					var html = '';
					for(var i = 0; i < data.length; i++){
						html += '<li onclick="selectMission(' + data[i].id + ', this)"><a class="ellipsis" href="javascript:void(0)">' + data[i].name + '</a></li>';
					}
					$('#missionList').html(html);
				}else{
					UBox.show('抱歉，暂时没有该年级的关卡数据', -1);
				}
			}
		});
	}
	
	var esType = 1;
	var curMissionId = 0;
	var page = 0;
	var totalPage = 1;
	function selectMission(id, obj){
		$('#missionList li').removeClass('selected');
		$(obj).addClass('selected');
		curMissionId = id;
		page = 0;
		getEsList(true);
	}
	
	function selectEsType(type, obj){
		$('#curEsType').text($(obj).text());
		esType = type;
		page = 0;
		getEsList(true);
	}
	
	function getEsList(isNext){
		$('#pageList').show();
		$('#tite').hide();
		if(isNext){
			page++;
		}else{
			page--;
		}
		if(page > totalPage && totalPage > 0){
			page = totalPage;
			UBox.show('最后一页啦', -1);
			return;
		}else if(page < 1){
			page = 1;
			UBox.show('已经到第一页啦', -1);
			return;
		}
		var data = {missionId : curMissionId, type : esType, page : page};
		ajax({
			url : '<?php echo url("m=Index&a=getEsList"); ?>',
			data : data,
			success : function(aResult){
				var data = aResult.data.list;
				if(data.length > 0){
					var html = '';
					if(esType == 1){
						var orderName = '错误率';
					}else{
						var orderName = '正确率';
					}
					for(var i = 0; i < data.length; i++){
						if(esType == 1){
							var percent = 100 - data[i].correct_percent;
						}else{
							var percent = data[i].correct_percent;
						}
						if(data[i].type_id == 1){
							var typeName = '单选题';
						}else if(data[i].type_id == 2){
							var typeName = '多选题';
						}else if(data[i].type_id == 3){
							var typeName = '判断题';
						}else if(data[i].type_id == 4){
							var typeName = '填空题';
						}else if(data[i].type_id == 5){
							var typeName = '选词(项)填空题';
						}else if(data[i].type_id == 6){
							var typeName = '阅读理解';
						}else if(data[i].type_id == 7){
							var typeName = '完型填空';
						}
						html += '<li onclick="showDetailEs(\'' + data[i].id + '\')">\
                                <a href="javascript:void(0)">\
                                    <span class="ellipsis subject">[' + typeName + ']' + data[i].content_text + '</span>\
                                    <span class="rate">' + orderName + '<b>' + percent + '%</b></span>\
                                </a>\
                            </li>';
					}
					$('#esList').html(html);
					ES.drawMathExpression($('#esList'));
				}else{
					UBox.show('抱歉，暂时没有更多的题目数据', -1);
					$('#esList').html('');
				}
				totalPage = aResult.data.total_page;
				$('#totalPage').text(totalPage);
				$('#curPage').text(page);
			}
		});
	}
	
	function showDetailEs(id){
		ajax({
			url : '<?php echo url('m=Index&a=getEsDetail'); ?>',
			data : {
				id : id
			},
			success : function(aResult){
				if(aResult.status == 1){
					var oEsDom = ES.buildDetail(aResult.data);
					popEasyDialog({
						title : '完整题目',
						width : 720,
						height : 400,
						content : '<div id="wrapPreview" class="wrapEsPreview es_content" style="height:400px; overflow-y:scroll;"></div>',
						confirmCallBack : $.noop
					});
					oEsDom.appendTo('#wrapPreview');
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			}
		});
	}
	
	$(function(){
		getMissionList(5, false);
	});
</script>