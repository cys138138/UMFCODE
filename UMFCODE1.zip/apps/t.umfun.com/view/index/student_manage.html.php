
<!--主体 [-->
<div class="t_main">
	<div class="column">

		<!--学生管理 [-->
		<div class="student_mod">
			<div class="hd">
				<?php showNav(3); ?>
			</div>
			<div class="bd c">
				<div class="inner">
					<div class="side">
						<div class="title">
							<h2>学生分组</h2>
							<a class="add_btn" href="javascript:showAddStudent();"><i class="ent_ico ent_ico_add_btn"></i>添加学生</a>
						</div>
						<div class="groupbox">
							<ul class="list" id="studentGroupList"></ul>
							<ul class="create">
								<li>
									<a class="create_btn" href="javascript:addGroup();">添加分组</span></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="cont" id="wrapAddStudent">
						
						<div id="wrapStudentManage">
							<div class="title">
								<div class="move enabled" id="topWrapMoveToGroup">
									<a class="g_act">移动到<i class="arrow"></i></a>
									<ul class="list" id="topMoveToGroupList"></ul>
								</div>
								<div class="off enabled"><a class="g_act" href="javascript:deleteStudent();">取消关注</a></div>
								<div class="effect">
									已经选择<b id="selectedStudentCount">0</b>人
									<a class="act" href="javascript:clearSelectedStudent();">取消选择</a>
								</div>
							</div>
							<div class="manage">
								<ul class="list c" id="studentList"></ul>
								<div class="loadmore" id="btnLoadMoreStudent"><a href="javascript:loadStudentList()">加载更多</a></div>
							</div>
						</div>
						
						<div class="wrapStudentAdd" id="wrapStudentAdd">
                            <div class="title">
                                <div class="grade">
                                    <a class="g_act" href="javascript:;"><span id="gradeName">全部年级</span><i class="arrow"></i></a>
                                    <ul class="list" id="filterGradeList">
										<li onclick="selectGrade(0, this)"><a href="javascript:void(0)">全部年级</a></li>
										<li onclick="selectGrade(5, this)"><a href="javascript:void(0)">五年级</a></li>
                                        <li onclick="selectGrade(6, this)"><a href="javascript:void(0)">六年级</a></li>
                                        <li onclick="selectGrade(7, this)"><a href="javascript:void(0)">七年级</a></li>
										<li onclick="selectGrade(8, this)"><a href="javascript:void(0)">八年级</a></li>
										<li onclick="selectGrade(9, this)"><a href="javascript:void(0)">九年级</a></li>
									</ul>
                                </div>
                                <div class="grade">
                                    <a class="g_act" href="javascript:;"><span id="className">全部班级</span><i class="arrow"></i></a>
                                    <ul class="list" id="filterClassList">
										<li onclick="selectClass(0, this)"><a href="javascript:void(0)">全部班级</a></li>
										<li onclick="selectClass(1, this)"><a href="javascript:void(0)">1班</a></li>
										<li onclick="selectClass(2, this)"><a href="javascript:void(0)">2班</a></li>
										<li onclick="selectClass(3, this)"><a href="javascript:void(0)">3班</a></li>
										<li onclick="selectClass(4, this)"><a href="javascript:void(0)">4班</a></li>
										<li onclick="selectClass(5, this)"><a href="javascript:void(0)">5班</a></li>
										<li onclick="selectClass(6, this)"><a href="javascript:void(0)">6班</a></li>
										<li onclick="selectClass(7, this)"><a href="javascript:void(0)">7班</a></li>
										<li onclick="selectClass(8, this)"><a href="javascript:void(0)">8班</a></li>
										<li onclick="selectClass(9, this)"><a href="javascript:void(0)">9班</a></li>
										<li onclick="selectClass(10, this)"><a href="javascript:void(0)">10班</a></li>
										<li onclick="selectClass(11, this)"><a href="javascript:void(0)">11班</a></li>
										<li onclick="selectClass(12, this)"><a href="javascript:void(0)">12班</a></li>
										<li onclick="selectClass(13, this)"><a href="javascript:void(0)">13班</a></li>
										<li onclick="selectClass(14, this)"><a href="javascript:void(0)">14班</a></li>
										<li onclick="selectClass(15, this)"><a href="javascript:void(0)">15班</a></li>
										<li onclick="selectClass(16, this)"><a href="javascript:void(0)">16班</a></li>
										<li onclick="selectClass(17, this)"><a href="javascript:void(0)">17班</a></li>
										<li onclick="selectClass(18, this)"><a href="javascript:void(0)">18班</a></li>
										<li onclick="selectClass(19, this)"><a href="javascript:void(0)">19班</a></li>
										<li onclick="selectClass(20, this)"><a href="javascript:void(0)">20班</a></li>
									</ul>
                                </div>
                                <div class="move enabled" id="wrapAddToClassList">
                                    <a class="g_act" href="javascript:;">添加到<i class="arrow"></i></a>
                                    <ul class="list" id="addToClassList">

									</ul>
                                </div>
                                <div class="effect">
                                    已经选择<b id="addStudentNums">0</b>人
                                    <a class="act" href="javascript:void(0);" onclick="clearSelect()">取消选择</a>
                                </div>
                            </div>
							
                            <div class="manage add_student">
                                <ul id="searchStudentWrap" class="list c">
                                </ul>
                                <div class="loadmore" id="loadMore"><a href="javascript:void(0)" onclick="getWantStudentList(true)">加载更多</a></div>
                            </div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--学生管理 ]-->


	</div>
</div>
<!--主体 [-->

<script type="text/javascript">
function decGroupMember(groupId){
	for(var i = 0; i < aStudentGroupList.length; i++){
		if(aStudentGroupList[i].id == groupId){
			aStudentGroupList[i].member_count--;
			return;
		}		
	}
}

function incGroupMember(groupId){
	for(var i = 0; i < aStudentGroupList.length; i++){
		if(aStudentGroupList[i].id == groupId){
			aStudentGroupList[i].member_count++;
			return;
		}		
	}
}

function deleteGroup(groupId){
	for(var i = 0; i < aStudentGroupList.length; i++){
		if(aStudentGroupList[i].id == groupId){
			aStudentGroupList[0].member_count += aStudentGroupList[i].member_count;
			delete aStudentGroupList[i];
			aStudentGroupList.sort();
			aStudentGroupList.length--;
			return aStudentGroupList;
		}
	}
}

function removeStudentFromGroup(studentId, aStudentList){
	for(var i in aStudentList){
		if(studentId == aStudentList[i].id){
			var aStudent = aStudentList[i];
			delete aStudentList[i];
			aStudentList.length--;
			return aStudent;
		}
	}
}
	
/**
 * 显示学生分组列表
 * @param {type} aStudentGroupList 分组列表
 */
function showStudentGroupList(aStudentGroupList){
	var currentGroupId = getCurrentDisplayGroupId();
	if(!currentGroupId){
		currentGroupId = aStudentGroupList[0].id;
	}
	
	var $oWrapStudentGroupList = $('#studentGroupList').empty();
	//显示学生分组列表
	var aListItems = [];
	for(var i in aStudentGroupList){
		if(!/^[0-9]+$/.test(i)){
			continue;
		}
		var groupId = aStudentGroupList[i].id
		,groupName = aStudentGroupList[i].name
		,studentCount = aStudentGroupList[i].member_count;
		
		if(i == 0){
			aListItems.unshift('<li class="own" xid="group" data-group_id="' + groupId + '">\n\
				<a class="act ellipsis" href="javascript:;" xid="groupName">\n\
					' + groupName + '\
					<b>(<span xid="memberCount">' + studentCount + '</span>)</b>\n\
				</a>\n\
			</li>');
		}else{
			aListItems.push('<li class="item" xid="group" data-group_id="' + groupId + '">\
				<a class="act ellipsis" href="javascript:;" xid="groupName">' + groupName + '(<span xid="memberCount">' + studentCount + '</span>)</a>\
				<a class="edit" href="javascript:;" title="编辑" xid="btnEditGroupName"><i class="ico ico_edit"></i></a>\
				<a class="del" href="javascript:;" title="删除" xid="btnDeleteGroup"><i class="ico ico_del"></i></a>\
			</li>');
		}
	}
	var $oStudentGroupList = $(aListItems.join('')).appendTo($oWrapStudentGroupList);
	$oStudentGroupList.each(function(){
		var $this = $(this);
		//绑定切换查看分组
		$this.find('[xid="groupName"]').click(function(){
			var $oWrapAddStudent = $('#wrapAddStudent');
			if($oWrapAddStudent.data('currentMode') != 'manageStudent'){
				$oContentStudentAdd.detach();
				$oWrapAddStudent.empty().append($oContentStudentManage);
				$oWrapAddStudent.data('currentMode', 'manageStudent');
			}

			var groupId = $this.data('group_id');
			if($('#studentList').data('current_group_id') != groupId){
				isHasStudent(groupId) ? $oBtnLoadMoreStudent.show() : $oBtnLoadMoreStudent.hide();
				loadStudentList($this.data('group_id'));
				$oStudentGroupList.removeClass('selected').eq($this.index()).addClass('selected');
			}
		});

		//绑定删除分组
		$this.find('[xid="btnDeleteGroup"]').click(function(){
			UBox.confirm('真的要删除该分组吗?', function(){
				var deleteGroupId = $this.data('group_id');
				ajax({
					url : '<?php echo url('m=Index&a=deleteStudentGroup'); ?>'
					,data : {
						group_id : deleteGroupId
					}
					,success : function(aResult){
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status == 1){
							showStudentGroupList(deleteGroup(deleteGroupId));
							showGroupStudentList(-1);
						}							
					}
				});
			});
			return false;
		});
		
		$this.find('[xid="btnEditGroupName"]').click(function(){
			var newGroupName = $.trim(prompt('请输入新的分组名称'));
			if(!newGroupName){
				return false;
			}
			
			var groupId = $this.data('group_id');
			ajax({
				url : 'm=Index&a=editGroupName'
				,data : {
					group_id : groupId
					,group_name : newGroupName
				}
				,success : function(aResult){
					if(aResult.status == 0){
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					
					for(var i = 0; i < aStudentGroupList.length; i++){
						if(aStudentGroupList[i].id == groupId){
							aStudentGroupList.name = newGroupName;
							break;
						}
					}
					
					showStudentGroupList(aStudentGroupList);
				}
			});
		});
	});
	$oWrapStudentGroupList.find('[xid="group"][data-group_id="' + currentGroupId + '"]').addClass('selected');
}

function showGroupStudentList(defaultShowGroupId){
	$('#studentGroupList').find('[xid="group"][data-group_id="' + defaultShowGroupId + '"] [xid="groupName"]').trigger('click');
}

function showStudentList(aStudentList){	
	var aListItems = []
	,aGroupNameCache = [];
	for(var i in aStudentList){		
		var aStudent = aStudentList[i];
		var groupName = aStudent.group_id == aGroupNameCache[aStudent.group_id] ? aGroupNameCache[aStudent.group_id] : (function(aStudentGroupList){
			for(var j = 0; j < aStudentGroupList.length; j++){
				if(aStudentGroupList[j].id == aStudent.group_id){
					aGroupNameCache[aStudent.group_id] = aStudentGroupList[j].name;
					return aGroupNameCache[aStudent.group_id];
				}
			}
		})(aStudentGroupList);

		aListItems.push('<li class="item" data-id="' + aStudent.id + '" data-group_id="' + aStudent.group_id + '" xid="student">\
			<p class="head">\n\
				<a href="javascript:;">\n\
					<img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" width="50" height="50" real="<?php echo SYSTEM_RESOURCE_URL; ?>' + aStudent.profile + '" onload="h(this)" />\n\
				</a>\n\
			</p>\
			<p class="part">\
				<span class="name"><a href="javascript:;" xid="studentName">' + aStudent.name + '</a></span>\
				<span class="status"><a href="javascript:;" xid="deleteStudent">取消关注</a></span>\
				<span class="group" xid="moveToGroup">\
					<a class="act" xid="groupName" href="javascript:;">' + groupName + '</a>\
					<i class="arrow"></i>\
					<span class="g_list" xid="moveToGroupList"></span>\
				</span>\
			</p>\
			<p class="total">\
				<span class="class">班级：' + aStudent.class + '</span>\
				<span class="integral">经验：<em>' + aStudent.accumulate_points + '</em></span>\
			</p>\
			<span class="tag">\
				<i class="arrow"></i>\
				<i class="ico ico_then"></i>\
			</span>\
		</li>');
	}
	
	$(aListItems.join('')).appendTo('#studentList').each(function(){
		var $oStudent = $(this);
		//实现选中效果
		$oStudent.click(function(){
			$(this).toggleClass('selected');
			$oSelectedStudentCount.refreshCount();
		});

		//实现取消关注单个学生
		$oStudent.find('[xid="deleteStudent"]').click(function(){
			UBox.confirm(
				'确定要取消对 ' + $oStudent.find('[xid="studentName"]').text() + ' 的关注吗？'
				,function(){
					ajax({
						url : '<?php echo url('m=Index&a=deleteStudent'); ?>'
						,data : {
							delete_ids : [$oStudent.data('id')]
						}
						,success : function(aResult){
							UBox.show(aResult.msg, aResult.status);
							if(aResult.status == 0){
								return;
							}
							_afterDeleteStudent($oStudent);
						}
					});
				}
			);
			return false;
		});

		//实现移动单个学生的分组
		$oStudent.find('[xid="moveToGroup"]').hover(
			function(){
				if(aStudentGroupList.length == 1){
					return;
				}
				$(this).find('[xid="moveToGroupList"]').html(function(){
					var aGroupListHtml = []
					,currentGroupId = $oStudent.data('group_id');
					for(var i = 0; i < aStudentGroupList.length; i++){
						if(currentGroupId == aStudentGroupList[i].id){
							continue;
						}

						aGroupListHtml.push('<a data-id="' + aStudentGroupList[i].id + '" href="javascript:;">' + aStudentGroupList[i].name + '</li>');
					}
					return aGroupListHtml.join('');
				})
					.children().click(function(){
						//实现移动单个学生分组
						moveToGroup($(this).data('id'), $oStudent);
						return false;
					});
			}
			).click(function(){
				return false;
			});
	});
	
	$oSelectedStudentCount.refreshCount();
};

/**
 * 加载学生分组列表
 * @param {type} loadGroupId 要加载的分组ID
 *
 */
function loadStudentList(loadGroupId){
	var $oStudentList = $('#studentList');
	if(loadGroupId == undefined){
		loadGroupId = $oStudentList.data('current_group_id');
	}	
	
	var currentGroupId = $oStudentList.data('current_group_id');
	if(currentGroupId != loadGroupId){
		$oStudentList.empty();
		//如果切换了查看的分组
		$oStudentList.data('current_group_id', loadGroupId);
		currentStudentListPage = 0;
		
		if(aStudentGroupListData[loadGroupId] != undefined){
			showStudentList(aStudentGroupListData[loadGroupId]);
			return;
		}
	}
	
	if(!isHasStudent(loadGroupId)){
		return;
	}
	
	ajax({
		url : '<?php echo url('m=Index&a=getStudentList'); ?>'
		,data : {
			group_id : loadGroupId
			,page : currentStudentListPage + 1
			,test_param : $.now()
		}
		,success : function(aResult){
			if(aResult.status == 0){
				UBox.show(aResult.msg, aResult.status);
				return;
			}else if(aResult.data.length == 0){
				markHasStudent(loadGroupId, false);
				$oBtnLoadMoreStudent.hide();
				return;
			}else if(aResult.data.length < 9){
				markHasStudent(loadGroupId, false);
				$oBtnLoadMoreStudent.hide();
			}
			
			//缓存学生数据列表
			if(aStudentGroupListData[loadGroupId] == undefined){
				aStudentGroupListData[loadGroupId] = aResult.data;
			}else{
				aStudentGroupListData[loadGroupId] = $.merge(aStudentGroupListData[loadGroupId], aResult.data);
			}
			currentStudentListPage++;			
			showStudentList(aResult.data);
		}
	});
}

/**
 * 标记一个分组是否有学生
 */
function markHasStudent(groupId, hasStudent){
	$('#studentGroupList [xid="group"][data-group_id="' + groupId + '"]').data('has_student', hasStudent);
}

/**
 * 判断一个分组是否还有学生
 */
function isHasStudent(groupId){
	return $('#studentGroupList [xid="group"][data-group_id="' + groupId + '"]').data('has_student') === false ? false : true;
}

/**
 * 添加分组
 */
function addGroup(){
    var groupName = $.trim(prompt('请输入分组名称'));
	if(!groupName){
		return;
	}
	
	for(var i in aStudentGroupList){
		if(aStudentGroupList[i].name == groupName){
			UBox.show('该分组名称已存在', -1);
			return;
		}
	}
	
	ajax({
		url : '<?php echo url('m=Index&a=addGroup'); ?>'
		,data : {
			group_name : groupName
		}
		,success : function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 0){
				return;
			}
			
			aStudentGroupList.push(aResult.data);
			showStudentGroupList(aStudentGroupList);
		}
	});
}

/**
 * 获得选中的学生对象集
 * @returns 学生的dom对象集
 */
function getSelectedStudents(){
    var aDeleteStudentNames = []	//要删除的学生姓名集
	,$oDeleteStudents = $('xxxxxxxx');	//用不存在标签创建空的fn对象作为删除成功后移除的DOM对象集
    $('#studentList [xid="student"]').each(function(){
		var $this = $(this);
		if($this.hasClass('selected')){
			$oDeleteStudents.push(this);
			aDeleteStudentNames.push($this.find('[xid="studentName"]').text());
		}
	});
	return $oDeleteStudents;
}

function clearSelectedStudent(){
    $('#studentList [xid="student"]').removeClass('selected');
	$oSelectedStudentCount.refreshCount();
}

/**
 * 取消关注学生
 */
function deleteStudent(){
	//收集要删除的学生ID和DOM
	var $oDeleteStudents = getSelectedStudents();	//用不存在标签创建空的fn对象作为删除成功后移除的DOM对象集
	if(!$oDeleteStudents.length){
		UBox.show('请勾选要取消关注的学生', -1);
		return;
	}
	
	var aDeleteStudentNames = [];	//要删除的学生姓名集
	for(var i = 0; i < $oDeleteStudents.length; i++){
		aDeleteStudentNames.push(
			$($oDeleteStudents[i])
				.find('[xid="studentName"]')
					.text()
		);
	}
	UBox.confirm('确定要取消关注 ' + aDeleteStudentNames.join('、') + ' 这' + aDeleteStudentNames.length + '名学生吗？', function(){
		ajax({
			url : '<?php echo url('m=Index&a=deleteStudent'); ?>'
			,data : {
				delete_ids : (function(){
					var aIds = [];
					for(var i = 0; i < $oDeleteStudents.length; i++){
						aIds.push($($oDeleteStudents[i]).data('id'));
					}
					return aIds;
				})()
			}
			,success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status == 0){
					return;
				}
				
				_afterDeleteStudent($oDeleteStudents);
			}
		});
	});
}

/**
 * 取消关注学生的回调
 * @param {type} isLoadMore
 */
function _afterDeleteStudent($oDeleteStudents){
	for(var i = 0; i < $oDeleteStudents.length; i++){
		var studentGroupId = $($oDeleteStudents[i]).data('group_id')
		,studentId = $($oDeleteStudents[i]).data('id');
		//更新分组人数
		decGroupMember(studentGroupId);		
		showStudentGroupList(aStudentGroupList);

		$('#studentList').empty();
		if(aStudentGroupListData[studentGroupId] != undefined){
			removeStudentFromGroup(studentId, aStudentGroupListData[studentGroupId]);
		}
		showStudentList(aStudentGroupListData[getCurrentDisplayGroupId()]);		
	}
}

/**
 * 移动学生到指定分组
 * @param {type} moveToGroupId
 */
function moveToGroup(moveToGroupId, $oDeleteStudents){
	var aIds = [];
	for (var i = 0; i < $oDeleteStudents.length; i++) {
		aIds.push(
			$($oDeleteStudents[i]).data('id')
		);
	}
	ajax({
		url : '<?php echo url('m=Index&a=moveStudentToGroup'); ?>',
		data : {
			move_to_group_id : moveToGroupId,
			move_student_ids : aIds
		},
		success : function(aResult){
			for(var i = 0; i < $oDeleteStudents.length; i++){
				var studentGroupId = $($oDeleteStudents[i]).data('group_id')
				,studentId = $($oDeleteStudents[i]).data('id');
				for(var j in aStudentGroupListData[studentGroupId]){					
					if(studentId == aStudentGroupListData[studentGroupId][j].id){
						if(aStudentGroupListData[moveToGroupId] != undefined){
							aStudentGroupListData[moveToGroupId].push(aStudentGroupListData[studentGroupId][j]);
						}
						
						//更新分组人数
						delete aStudentGroupListData[studentGroupId][j];
						decGroupMember(studentGroupId);
						incGroupMember(moveToGroupId);
						markHasStudent(moveToGroupId, true);
						
						$('#studentList').empty();
						showStudentGroupList(aStudentGroupList);
						showStudentList(aStudentGroupListData[studentGroupId]);
						break;
					}
				}
			}			
		}
	});
}

function showAddStudent(){
    var $oWrapAddStudent = $('#wrapAddStudent');
	if($oWrapAddStudent.data('currentMode') != 'addStudent'){
		$oContentStudentManage.detach();
		$oWrapAddStudent.empty()
		.append($oContentStudentAdd)
		.data('currentMode', 'addStudent');
	}
	var length = $('#searchStudentWrap li').length;
	if(length <= 0){
		getWantStudentList(false);
	}
}

function getCurrentDisplayGroupId(){
    return $('#studentGroupList [xid="group"].selected').data('group_id');
}
	
var aStudentGroupList = <?php echo json_encode($aStudentGroupList); ?>
,aStudentGroupListData = []
,currentStudentListPage = 0
,$oBtnLoadMoreStudent = $('#btnLoadMoreStudent')
,$oContentStudentManage = $('#wrapStudentManage')	//管理学生的DOM内容
,$oContentStudentAdd = $('#wrapStudentAdd')	//添加学生的DOM内容
,$oSelectedStudentCount = $('#selectedStudentCount');	//选中的用户数量

$(function(){	
	var addStudentGroupHtml = '';
	for(var i = 0; i < aStudentGroupList.length; i++){
		addStudentGroupHtml += '<li onclick="batchAttentationStudent(' + aStudentGroupList[i].id + ')"><a href="javascript:;">' + aStudentGroupList[i].name + '</a></li>';
	}
	$('#addToClassList').html(addStudentGroupHtml);
	
	
	$oSelectedStudentCount.refreshCount = function(){
		//刷新选中用户数量
		$(this).text(getSelectedStudents().length);;
	};
	
    showStudentGroupList(aStudentGroupList);
	showGroupStudentList(-1);
	
	//添加到分组列表
	$('#topWrapMoveToGroup').hover(
		function(){
			$('#topMoveToGroupList').html(function(){
				var aGroupListHtml = [];
				for(var i = 0; i < aStudentGroupList.length; i++){
					aGroupListHtml.push('<li data-id="' + aStudentGroupList[i].id + '">\n\
						<a href="javascript:;">' + aStudentGroupList[i].name + '</a>\n\
					</li>');
				}
				return aGroupListHtml.join('');
			}).children().click(function(){
				var moveToGroupId = $(this).data('id');
				var $oDeleteStudents = getSelectedStudents();	//用不存在标签创建空的fn对象作为删除成功后移除的DOM对象集
				if(!$oDeleteStudents.length){
					UBox.show('请勾选要移动分组的学生', -1);
					return;
				}
				moveToGroup(moveToGroupId, $oDeleteStudents);
			});
		}
	);
	$oContentStudentAdd.detach().show()
});



//添加学生Start
var selectGradeId = 0;
var selectClassId = 0;
var addPage = 1;

function getWantStudentList(isLoadMore){
	if(isLoadMore){
		addPage++;
	}else{
		addPage = 1;
		aWantStudentIds = [];
		$('#addStudentNums').text(aWantStudentIds.length);
	}
	ajax({
		url : '<?php echo url('m=Index&a=getWantStudentList'); ?>',
		data : {
			addPage : addPage,
			gradeId : selectGradeId,
			classId : selectClassId
		},
		success : function(aResult){
			var html = '';
			var data = aResult.data;
			var baseUrl = '<?php echo url('m=Zone&a=showHome&userId=_userId', '', APP_HOME); ?>';
			if(data.length > 0){
				$('#loadMore').show();
				for(var i = 0; i < data.length; i++){
					var homeUrl = baseUrl.replace('_userId', data[i].id);
					if(data[i].grade == 5){
						data[i].grade = '五';
					}else if(data[i].grade == 6){
						data[i].grade = '六';
					}else if(data[i].grade == 7){
						data[i].grade = '七';
					}else if(data[i].grade == 8){
						data[i].grade = '八';
					}else if(data[i].grade == 9){
						data[i].grade = '九';
					}
					html += '<li onclick="selectWantStudent(' + data[i].id + ', this)" class="item">\
								<p class="head"><a href="' + homeUrl + '"><img real="<?php echo SYSTEM_RESOURCE_URL; ?>' + data[i].profile +'" onload="h(this)" src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" width="50" height="50" alt=""/></a></p>\
								<p class="part">\
									<span class="name"><a href="' + homeUrl + '">' + data[i].name + '</a></span>\
									<span class="status"><a href="javascript:void(0)" onclick="atttendtion(' + data[i].id + ', this)">关注</a></span>\
									<span class="integral"><em>' + data[i].accumulate_points + '</em>经验</span>\
								</p>\
								<p class="total">\
									<span class="class">班级：' + data[i].grade + '年级' + data[i].class + '</span>\
								</p>\
								<span class="tag">\
									<i class="arrow"></i>\
									<i class="ico ico_then"></i>\
								</span>\
							</li>';
				}
				if(isLoadMore){
					$('#searchStudentWrap').append(html);
				}else{
					$('#searchStudentWrap').html(html);
				}
			}else{
				if(isLoadMore){
					UBox.show('没有更多的学生啦', -1);
					$('#searchStudentWrap').append(html);
				}else{
					html = '<li>没有找到相关的学生</li>';
					$('#searchStudentWrap').html(html);
				}
				$('#loadMore').hide();
			}
		}
	});
}

var aWantStudentIds = [];
function arrRemove(arr, val){
　　for(var i = 0,n = 0;i < arr.length; i++){
　　　　if(arr[i] != val){
			arr[n++] = arr[i];
　　　　}
　　}
	arr.length -= 1;
	return arr;
}


function selectWantStudent(id, obj){
	if($(obj).hasClass('selected')){
		$(obj).removeClass('selected');
		aWantStudentIds = arrRemove(aWantStudentIds, id);
	}else{
		$(obj).addClass('selected');
		aWantStudentIds.push(id);
	}
	$('#addStudentNums').text(aWantStudentIds.length);
	//console.log(aWantStudentIds);
}

function clearSelect(){
	aWantStudentIds = [];
	$('#addStudentNums').text(aWantStudentIds.length);
	$('#searchStudentWrap li').removeClass('selected');
	//console.log(aWantStudentIds);
}

function selectGrade(gradeId, obj){
	selectGradeId = gradeId;
	$('#gradeName').text($(obj).find('a').text());
	getWantStudentList(false);
}

function selectClass(classId, obj){
	selectClassId = classId;
	$('#className').text($(obj).find('a').text());
	getWantStudentList(false);
}

function atttendtion(id, obj){
	ajax({
		url : '<?php echo url('m=Index&a=atttendtionStudent'); ?>',
		data : {
			aWantStudentIds : [id],
			toGroup : -1
		},
		success : function(aResult){
			if(aResult.status == 1){
				$(obj).parents('li').slideUp('normal', function(){
					$(this).remove();
				});
				aWantStudentIds = arrRemove(aWantStudentIds, id);
				$('#addStudentNums').text(aWantStudentIds.length);
				showStudentGroupList(aResult.data);
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function batchAttentationStudent(group){
	if(aWantStudentIds.length <= 0){
		UBox.show('请选择要关注的学生', -1);
		return;
	}
	ajax({
		url : '<?php echo url('m=Index&a=atttendtionStudent'); ?>',
		data : {
			aWantStudentIds : aWantStudentIds,
			toGroup : group
		},
		success : function(aResult){
			if(aResult.status == 1){
				$('#searchStudentWrap li.selected').slideUp('normal', function(){
					$(this).remove();
				});
				aWantStudentIds = [];
				$('#addStudentNums').text(aWantStudentIds.length);
				showStudentGroupList(aResult.data);
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}
//添加学生End

</script>