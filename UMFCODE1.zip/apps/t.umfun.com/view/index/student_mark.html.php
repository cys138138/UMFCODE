 <!--主体 [-->
    <div class="t_main">
        <div class="column">

            <!--教学参考数据 [-->
            <div class="educate_mod">
                <div class="hd">
					<?php showNav(2); ?>
                </div>
                <div class="bd c">
                    <div class="group">
                        <div class="title">
                            <h2>班级选择</h2>
                        </div>
                        <ul class="list" id="groupList">
							<?php
							$firstClass = 0;
							$fisrtClassStudent = '';
							if(count($aUserInfo['relations']) > 0){
								foreach($aUserInfo['relations'] as $key => $aGroup){
									$aStudentIds = array();
									foreach($aGroup['student_list'] as $aStudentList){
										array_push($aStudentIds, $aStudentList['uf_id']);
									}
									$strStudentIds = implode(',', $aStudentIds);
									if($key == 0){
										$fisrtClassStudent = $strStudentIds;
									}
								?>
									<li <?php if($key == 0){ echo 'class="selected"'; $firstClass = $key; } ?> onclick="selectGroup('<?php echo $strStudentIds; ?>', <?php echo $key; ?>, this)"><a href="javascript:void(0)"><?php echo $aGroup['ClassName']; ?>（<?php echo count($aGroup['student_list']); ?>）</a></li>
							<?php
								}
							}else{
							?>
								<p class="btnbox"><a style="color:#003366" class="btn" href="javascript:void(0)">您还没有班级喔</a></p>
							<?php
							}
							?>
                        </ul>
                        
                    </div>
                    <div class="grade">
                        <div class="title">
                            <h2>科目：</h2>
                            <div class="choose" id="subjectContent">
                            </div>
                        </div>
                        <ul class="list" id="missionList">
                        </ul>
                    </div>
                    <div class="track">
                        <div class="title">
                            <h2>学习跟踪</h2>
                            <div class="choose">
                                <a id="curOrder" class="act" href="javascript:void(0)">得分由高到低排序</a>
                                <i class="arrow"></i>
                                <ul>
									<li><a onclick="changeOrder(1, this)" href="javascript:void(0)">得分由高到低排序</a></li>
                                    <li><a onclick="changeOrder(2, this)" href="javascript:void(0)">得分由低到高排序</a></li>
                                </ul>
                            </div>
                        </div>
						<div id="tite" class="air">
							<p>请先选择关卡后查看各学生得分及正确率情况</p>
						</div>
                        <ul class="list" id="studentList">

                        </ul>
                        <div style="display:none" id="pageList" class="educate_page">
                            <a onclick="getStudentList(false)" href="javascript:void(0)">上一页</a>
                            <a id="curPage" class="cur" href="javascript:void(0)">0</a>/
                            <a id="totalPage" href="javascript:void(0)">0</a>
                            <a onclick="getStudentList(true)" href="javascript:void(0)">下一页</a>
                        </div>
                    </div>
                </div>
            </div>
            <!--教学参考数据 ]-->
        </div>
    </div>
    <!--主体 [-->

<script type="text/javascript">
	var studentIds = '<?php echo $fisrtClassStudent; ?>';
	var grade = <?php if(isset($aUserInfo['relations'][$firstClass]['Bank'])){ echo $aUserInfo['relations'][$firstClass]['Bank']; }else{ echo 0; }; ?>;
	var aRelation = <?php echo json_encode($aUserInfo['relations']); ?>;
	var subjectId = 0;
	var subjectName = '';
	
	function selectGroup(ids, ClassIndex, obj){
		if(!ids){
			alert('该班级没有学生');
			return;
		}
		studentIds = ids;
		$('#groupList li').removeClass('selected');
		$(obj).addClass('selected');
		var thisClass = aRelation[ClassIndex];
		if(thisClass == undefined){
			UBox.show('班级不存在', -1);
			return;
		}
		if(thisClass.SubjectList.Subject == undefined){
			UBox.show('您还没有可操作的科目', -1);
			return;
		}
		
		grade = thisClass.Bank;
		if(thisClass.SubjectList.Subject[0].SubjectId != undefined){
			subjectId = thisClass.SubjectList.Subject[0].SubjectId;
		}else{
			subjectId = 0;
		}
		if(thisClass.SubjectList.Subject[0].SubjectName != undefined){
			subjectName = thisClass.SubjectList.Subject[0].SubjectName;
		}else{
			subjectName = '无科目';
		}
		setSubjectList(ClassIndex, subjectId, subjectName);
	}
	
	function setSubjectList(ClassIndex, subjectId, subjectName){
		var thisClass = aRelation[ClassIndex];
		if(thisClass == undefined){
			UBox.show('班级不存在', -1);
			return;
		}
		var html = '<a id="curGrade" class="act" href="javascript:void(0)">' + subjectName + '</a><i class="arrow"></i><ul id="subjectList">';
		for(var i = 0; i < thisClass.SubjectList.Subject.length; i++){
			html += '<li onclick="getMissionList(' + thisClass.SubjectList.Subject[i].SubjectId + ', this)"><a href="javascript:void(0)">' + thisClass.SubjectList.Subject[i].SubjectName + '</a></li>';
		}
		html += '</ul>';
		$('#subjectContent').html(html);
		$('#subjectList').find('li').get(0).click();
	}
	
	
	function getMissionList(subjectId, obj){
		$('#curGrade').text($(obj).text());
		subjectId = subjectId;
		ajax({
			url : '<?php echo url("m=Index&a=getMissionList"); ?>',
			data : {
				gradeId : grade,
				subjectId : subjectId
			},
			success : function(aResult){
				var data = aResult.data;
				if(data.length > 0){
					var html = '';
					for(var i = 0; i < data.length; i++){
						html += '<li onclick="selectMission(' + data[i].id + ', this)"><a class="ellipsis" href="javascript:void(0)">' + data[i].name + '</a></li>';
					}
					$('#missionList').html(html);
				}else{
					UBox.show('抱歉，暂时没有该年级的关卡数据', -1);
				}
			}
		});
	}
	
	var curMissionId = 0;
	var page = 0;
	var totalPage = 1;
	function selectMission(id, obj){
		$('#missionList li').removeClass('selected');
		$(obj).addClass('selected');
		curMissionId = id;
		page = 0;
		getStudentList(true);
	}
	
	function getStudentList(isNext){
		if(curMissionId <= 0){
			UBox.show('请先选择关卡', -1);
			return;
		}
		$('#pageList').show();
		$('#tite').hide();
		if(isNext){
			page++;
		}else{
			page--;
		}
		if(page > totalPage && totalPage > 0){
			page = totalPage;
			UBox.show('最后一页啦', -1);
			return;
		}else if(page < 1){
			page = 1;
			UBox.show('已经到第一页啦', -1);
			return;
		}
		var data = {ids : studentIds, missionId : curMissionId, orderType : orderType, page : page};
		ajax({
			url : '<?php echo url("m=Index&a=getStudentMarkList"); ?>',
			data : data,
			success : function(aResult){
				var data = aResult.data.list;
				if(data.length > 0){
					var html = '';
					for(var i = 0; i < data.length; i++){
						if(data[i].is_pass == 1){
							var status = '已过关';
							var score = data[i].score / 100;
						}else{
							var status = '未过关';
							var score = '--';
						}
						var correctPercent = data[i].es_correct_count / data[i].es_count * 100;
						var numObj = new Number(correctPercent);
						html += '<li>\
                                <a href="javascript:void(0)">\
                                    <span class="head"><img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php echo SYSTEM_RESOURCE_URL; ?>' + data[i].user_info.profile +'" onload="h(this);" width="25" height="25" alt=""/></span>\
                                    <span class="name">' + data[i].user_info.name +'</span>\
                                    <span class="fraction">' + status + '<b>' + score +'</b>分</span>\
                                    <span class="rate">正确率<b>' + numObj.toFixed(2) + '%</b></span>\
                                </a>\
                            </li>';
					}
					$('#studentList').html(html);
				}else{
					UBox.show('抱歉，暂时没有更多的学生数据', -1);
					$('#studentList').html('');
				}
				totalPage = aResult.data.total_page;
				$('#totalPage').text(totalPage);
				$('#curPage').text(page);
			}
		});
		
	}
	
	var orderType = 1;
	function changeOrder(type, obj){
		orderType = type;
		$('#curOrder').text($(obj).text());
		page = 0;
		getStudentList(true);
	}
	
	$(function(){
		selectGroup(studentIds, 0, $('#groupList li').get(0));
	});
</script>