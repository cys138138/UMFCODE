<?php
$GLOBALS['URL'] = array(
	APP_LOGIN => array(
		'index.html' => 'm=Site&a=index',
		'^xxt/parent_switch_children$'					=> 	'm=Index&a=loginChildren',
		'login'											=> 	'm=Login&a=showLogin',
	),

	APP_HOME => array(
		//首页
		'^feed$'										=>	'm=Index&a=index&type=2',
		'^notice$'										=>	'm=Index&a=index&type=3',
		'^ $'											=>	'm=Index&a=index',
		'^captcha/(.*)/$'								=>	'm=Captcha&a=display&name=$1',	//通用的验证码
		'^ABOUT.HTML$'									=>	'm=Index&a=index',

		//首页用户邮件来路统计
		'^notice/mreferer/(.+?)$'						=>	'm=Index&a=index&type=3&mreferer=$1',

		//用户注册登录填写人个信息
		'^login$'										=>	'm=Account&a=showLogin',
		'^login/$'										=>	'm=Index&a=direct301',
		'^dologin$'										=>	'm=Account&a=login',
		'^youxihuaxuexi.html$'							=>	'm=Account&a=showMoreIntroduce',
		'^jiazhang.html$'								=>	'm=Account&a=showParentIntroduce',
		'^mastery-learning.html$'						=>	'm=Account&a=showMastery',
		'^register.html$'								=>	'm=Account&a=showLogin&action=register',
		'^register$'									=>	'm=Account&a=showLogin&action=register',
		'^doregister$'									=>	'm=Account&a=register',
		'^mission_x/logout$'							=>	'm=Account&a=logout',
		'^account/down_load_txt$'						=>	'm=Account&a=downLoadAccountInfo',
		'^account/perfect_information.html?from=(.*)&code=(.*)$'		=>	'm=Account&a=showPerfectUserInformation&from=$1&code=$2',
		'^account/perfect_information.html$'		=>	'm=Account&a=showPerfectUserInformation',
		'^account/rotate.html$'							=>	'm=Account&a=rotate',
		'^account/check_account_exist$'					=>	'm=Account&a=checkAccountExist',
		'^account/getLoginInformation$'					=>	'm=Account&a=getLoginInformation',

		'^account/perfect_user_information/$'			=>	'm=Account&a=perfectUserInformation',
		'^account/school_info.html$'					=>	'm=Account&a=showSchoolInfo',
		'^account/school_info/action/(.*)/$'			=>	'm=Account&a=schoolInfo&action=$1',
		'^account/school_info/$'						=>	'm=Account&a=schoolInfo',
		'^account/school_info_handle/$'					=>	'm=Acc`ount&a=schoolInfoHandle',
		'^account/get_class_data/action/(.*)/$'			=>	'm=Account&a=getClassData&action=$1',
		'^account/get_class_data/$'						=>	'm=Account&a=getClassData',
		'^account/upload_image/aj(.*)$'					=>	'm=Account&a=uploadImage&action=$1',
		'^account/upload_image/$'						=>	'm=Account&a=uploadImage',
		'^account/forgot_password.html$'				=>	'm=Account&a=showForgotPassword',
		'^account/forgot_password/$'					=>	'm=Account&a=forgotPassword',
		'^account/reset_password.html$'					=>	'm=Account&a=showResetPassword',
		'^account/reset_password/$'						=>	'm=Account&a=resetPassword',
		'^account/setting_information.html$'			=>	'm=Account&a=showSettingInformation',
		'^account/edit_user_information/$'				=>	'm=Account&a=editUserInformation',
		'^account/edit_profile/action/(.*)/$'			=>	'm=Account&a=editProfile&action=$1',
		'^account/edit_profile/$'						=>	'm=Account&a=editProfile',
		'^account/school_list.html$'					=>	'm=Account&a=showSchoolList',
		'^account/school_list/$'						=>	'm=Account&a=schoolList',
		'^account/action_class/$'						=>	'm=Account&a=actionClass',
		'^account/check_email_exist/$'					=>	'm=Account&a=checkEmailExist',
		'^account/upload_profile.html$'					=>	'm=Account&a=showUploadProfile',
		'^account/upload_profile/$'						=>	'm=Account&a=uploadProfile',
		'^account/skip_upload_profile/$'				=>	'm=Account&a=skipUploadProfile',
		'^account/send_email.html$'						=>	'm=Account&a=showSettingEmail',
		'^account/send_email/$'							=>	'm=Account&a=sendEmail',
		'^account/setting_account.html$'				=>	'm=Account&a=showSettingAccount',
		'^account/setting_account/$'					=>	'm=Account&a=settingAccount',
		'^account/setting_password.html$'				=>	'm=Account&a=showSettingPassword',
		'^account/setting_password/$'					=>	'm=Account&a=settingPassword',
		'^account/setting_picture.html$'				=>	'm=Account&a=showSettingPicture',
		'^account/setting_style.html$'					=>	'm=Account&a=showSettingStyle',
		'^account/game_setting.html$'					=>	'm=Account&a=showGameSetting',
		'^account/edit_game_setting.html$'				=>	'm=Account&a=editGameSetting',
		'^account/recommend_friend.html$'				=>	'm=Account&a=recommendFriendRegister',
		'^account/user_info.html$'						=>	'm=Account&a=getUserInfo',
		'^account/friend_list$'							=>	'm=Account&a=getFriendList',
		'^account/setting_email_account$'				=>	'm=Account&a=settingEmailAccount',
		'^account/send_mobile.html$'					=>	'm=Account&a=sendMobileMessage',
		'^account/verify_mobile.html$'					=>	'm=Account&a=verifyMobileMessage',
		'^account/password_mobile.html$'				=>	'm=Account&a=resetPasswordByMobile',
		'^account/show_setting_mobile.html$'			=>	'm=Account&a=showMobileSetting',
		'^account/setting_mobile.html$'					=>	'm=Account&a=settingMobileAccount',
		'^account/un_setting/$'							=>	'm=Account&a=unSettingNameOrProfile',
		'^account/user_setting/$'						=>	'm=Account&a=showUserSetting',
		'^account/send_verify_email/$'					=>	'm=Account&a=sendActiveEmail',

		'^login/user_is_login/$'						=>	'm=Account&a=getLoginInformation',
		'^account/select_start_mission.html$'			=>	'm=Account&a=showSelectStartMission',
		'^account/select_start_mission/$'				=>	'm=Account&a=selectStartMission',
		'^account/task/$'								=>	'm=Account&a=getTaskStatus',
		'^account/show_qq_login.html$'					=>	'm=Account&a=showQQLogin',
		'^account/qq_login.html$'						=>	'm=Account&a=qqAccountLogin',
		'^account/do_qq_login.html$'					=>	'm=Account&a=doQQAccountLogin',
		'^account/bind_qq.html$'						=>	'm=Account&a=bindQQaccount',
		'^mission_x/student/rotate.html$'				=>	'm=Account&a=getRotateParameter',
		'^account/loginParent/(.*).html$'				=>	'm=Account&a=loginParent&parentId=$1',
		'^account/send_app_msg.html$'					=>	'm=Account&a=sendWeiboWhenConditionMeet',
		'^account/share_sign_to_class.html$'			=>	'm=Account&a=shareSignToClass',

		'^help/guide/$'									=>	'm=Help&a=checkIsNeedGuide',


		//关卡
		'^mission_x/challenge/(.*).html$'				=>	'm=Mission&a=showMissionChallenge&id=$1',
		'^mission_x/practice/(.*).html$'					=>	'm=Mission&a=showExecuteMission&id=$1',
		'^mission/pk/(.*).html$'						=>	'm=Mission&a=showPkMission&id=$1',
		'^mission/result/(.*).html$'					=>	'm=Mission&a=showMissionResult&id=$1',
		'^marking_exercise$'							=>	'm=Mission&a=markingUserExerciseAnswer',
		'^marking_chanllenge$'							=>	'm=Mission&a=markingUserChallengeAnswer',
		'^mission_x/analysis/(.*).html$'				=>	'm=Mission&a=showMissionAnalysis&id=$1',
		'^next_mission_es.json$'						=>	'm=Mission&a=getNextEs',
		'^mission/welcome/$'							=>	'm=Mission&a=showSetMission',
		'^mission/init/chinese/$'						=>	'm=Mission&a=showInitMission&subject_id=1',
		'^mission/init/math/$'							=>	'm=Mission&a=showInitMission&subject_id=2',
		'^mission/init/english/$'						=>	'm=Mission&a=showInitMission&subject_id=3',
		'^mission/init/$'								=>	'm=Mission&a=showInitMission',
		'^mission_x/home.html?subject_id=1$'			=>	'm=Mission&a=showMissionList&subject_id=1',
		'^mission_x/home.html?subject_id=2$'			=>	'm=Mission&a=showMissionList&subject_id=2',
		'^mission_x/home.html?subject_id=3$'			=>	'm=Mission&a=showMissionList&subject_id=3',
		'^mission_x/home.html$'							=>	'm=Mission&a=showMissionList',
		'^mission/detail/$'								=>	'm=Mission&a=getUserMissionDetail',
		'^mission/probaly_friend/$'						=>	'm=Mission&a=getUserProbalyFriendList',
		'^mission/welcome/$'							=>	'm=Mission&a=showSelectStartMissionWelcome',
		'^mission/init/chinese/$'						=>	'm=Mission&a=initMission&subject_id=1',
		'^mission/init/math/$'							=>	'm=Mission&a=initMission&subject_id=2',
		'^mission/init/english/$'						=>	'm=Mission&a=initMission&subject_id=3',
		'^mission/set_init/$'							=>	'm=Mission&a=setSelectStartMission',
		'^mission/challenge_event/$'					=>	'm=Mission&a=getChallengeEventList',
		'^mission/challenge_rank/$'						=>	'm=Mission&a=getChallengeRankList',

		//题目评论、问问
		'^comment/e(.*)-t(.*)/(.*).html$'               => 	'm=EsComment&a=showEsComment&es_id=$1&type=$2&page=$3',
		'^comment/e(.*)-t(.*).html$'                    => 	'm=EsComment&a=showEsComment&es_id=$1&type=$2',
		'^comment/add.html$'                            => 	'm=EsComment&a=addComment',
		'^comment/(.*)/index.html$'                     => 	'm=EsComment&a=index&es_id=$1',
		'^comment/index.html$'                          => 	'm=EsComment&a=index',

		//题目反馈
		'^es/feedback.html$'							=>	'm=Es&a=addFeedback',

		//错题集、收藏题
		'^es/wrong_mission_list/$'                      => 	'm=Es&a=getWongEsMissionList',
		'^es/wrong/(\w+).html$'                         => 	'm=Es&a=showWrongEsList&missionId=$1',
		'^es/wrong_list.html$'                          => 	'm=Es&a=showWrongEsList',
		'^es/wrong/more/$'		                        => 	'm=Es&a=getWrongEsListByCondition',
		'^es/wrong_del/$'		                        => 	'm=Es&a=delWrongEs',

		'^es/favourite_mission_list/$'                	=> 	'm=Es&a=getFavouriteEsMissionList',
		'^es/favourite/(\w+).html$'		          		=> 	'm=Es&a=showFavouriteEsList&missionId=$1',
		'^es/favourite_list.html$'		                => 	'm=Es&a=showFavouriteEsList',
		'^es/favourite/more/$'		                    => 	'm=Es&a=getFavouriteEsListByCondition',
		'^es/favourite/favourite_status/$'		        => 	'm=Es&a=getEsFavouriteStatus',
		'^es/wrong_statis/$'		      				=> 	'm=Es&a=showWrongStatis',
		'^es/checkVip/$'		      				    => 	'm=Es&a=checkVip',
		'^es/wrong_mission/$'		      				=> 	'm=Es&a=getWrongMissionList',
		'^es/repair_wrong/$'		      				=> 	'm=Es&a=showRepairWrong',
		'^es/marking_fixEs/$'		      				=> 	'm=Es&a=markingFixEs',




		//错题与收藏
		'^es/get_wrong_list$'                      => 	'm=Es&a=getWrongEsList',
		'^es/delete_wrong_es$'                     => 	'm=Es&a=deleteWrongEs',
		'^es/delete_batch_wrong_es$'               => 	'm=Es&a=deleteBatchWrongEs',
		'^es/wrong_detail/(.*).html$'              => 	'm=Es&a=showWrongEsDetail&id=$1',
		'^es/get_favourite_list$'                  => 	'm=Es&a=getMyFavouriteEsList',
		'^es/favourite_detail/(.*).html$'          => 	'm=Es&a=showMyFavouriteEsDetail&id=$1',
		'^es/add_favourite_es$'                    => 	'm=Es&a=addFavouriteEs',
		'^es/delete_favourite_es$'                 => 	'm=Es&a=deleteFavouriteEs',
		'^es/delete_batch_favourite_es$'           => 	'm=Es&a=deleteBatchFavouriteEs',
		'^es/ignore_wrong_es$'                     => 	'm=Es&a=ignoreWrongEs',
		'^es/ignore_batch_wrong_es$'               => 	'm=Es&a=ignoreBatchWrongEs',


		//总战绩
		'^grade/index.html$'						=> 	'm=Grade&a=showGrade',
		'^grade/mission_list/$'						=> 	'm=Grade&a=getHistoryMissionList',
		'^grade/friend_list/$'						=> 	'm=Grade&a=getFriendList',
		'^grade/month_list/$'						=> 	'm=Grade&a=getUserMonthGradeList',
		//排行榜
		'^ranking.html$'							=> 	'm=Grade&a=showRankingList',
		'^mission_x/ranking.html$'					=> 	'm=Grade&a=showNewRankingList',

		//签到
		'^mission_x/get-mark.json$'					=> 	'm=Mark&a=showMarkButton',
		'^mark/marking/$'							=> 	'm=Mark&a=mark',
		'^mark/list/$'								=> 	'm=Mark&a=showMarkList',

		//勋章
		'^my_medal.html$'							=> 	'm=Medalandhonor&a=showMyMedal',
		'^medal.html$'								=> 	'm=Medalandhonor&a=showMedal',
		'^medal/get_event$'							=> 	'm=Medalandhonor&a=getFriendMedalEventList',
		'^(\w+)/medal/show$'						=> 	'm=Medalandhonor&a=showMedal&userId=$1',
		'^medal/ranking$'							=> 	'm=Medalandhonor&a=medalRanking',

		//赛事
		'^match/event/$'							=>  'm=Match&a=showMatchEventList',
		'^match/my/$'								=>  'm=Match&a=showMyCenter',
		'^mission_x/match.html$'					=>  'm=Match&a=showCenter',
		'^match/user_match/$'						=>  'm=Match&a=getMatchListByUser',

		'^match/join.html$'							=>  'm=Match&a=join',
		'^match/rejoin.html$'						=>  'm=Match&a=reJoin',
		'^match/match_event.html$'					=>  'm=Match&a=matchEvent',
		'^match/match_event_list.html$'				=>  'm=Match&a=getMatchEvenList',
		'^match/check_join.html$'					=>  'm=Match&a=checkUserJoinStatus',
		'^match/moreMatchList.html$'				=>  'm=Match&a=moreMatchList',
		'^match/match_ranking.html$'				=>  'm=Match&a=matchRankingList',
		'^match/reJoin_list.html$'					=>  'm=Match&a=getReJoinUserList',
		'^mission_x/match/detail/(.*).html/(.*)/$'			=>  'm=Match&a=showDetail&match_id=$1&type=$2',
		'^mission_x/match/detail/(.*).html$'				=>  'm=Match&a=showDetail&match_id=$1',
		'^match/accept_prize.html$'					=>  'm=Match&a=acceptPrize',
		'^match/start_match.html$'					=>  'm=Match&a=startMatch',
		'^match/submit_answer.html$'				=>  'm=Match&a=markingMatchAnswer',
		'^match/(.*).html$'							=>  'm=Match&a=showMatch&id=$1',
		'^match/medal/$'							=>	'm=Match&a=getMedalRandkingList',
		'^match.html$'								=>	'm=Match&a=showNewCenter',

		//PK
		'^pk/square$'								=>	'm=Pk&a=showPkSquare',
		'^pk/square/friend/(\d+)/gold/(\d+)$'		=>	'm=Pk&a=showPkSquare&friend=$1&gold=$2',
		'^pk/user_pk_list/$'						=>	'm=Pk&a=getUserPkList',
		'^pk/user_list/$'							=>	'm=Pk&a=getPkUserList',
		'^pk/pass_mission_list/$'					=>	'm=Pk&a=getPassMissionList',
		'^pk/pass_mission_pk_list/$'				=>	'm=Pk&a=getPassMissionPkList',
		'^pk/pk_list/$'								=>	'm=Pk&a=getPkUserList',
		'^pk/my_pk_list/$'							=>	'm=Pk&a=showList',
		'^pk/my_more_pk_list/$'						=>	'm=Pk&a=morePkList',
		'^pk/pk_rank/$'								=>	'm=Pk&a=showPkRanking',
		'^pk/pk_rank_list/$'						=>	'm=Pk&a=getPkRankingList',

		'^pk/add_2_(\w+).html$'						=>	'm=Pk&a=showAdd&type=2&mission_id=$1',
		'^pk/add_(\d+)_(\w+).html$'					=>	'm=Pk&a=showAdd&type=$1&mission_id=$2',
		'^pk/add_(\d+)_(\w+).html$'					=>	'm=Pk&a=showAdd&type=$1&user_id=$2',
		'^pk/add_(\d+).html$'						=>	'm=Pk&a=showAdd&type=$1',
		'^pk/add.html$'								=>	'm=Pk&a=showAdd',
		'^pk/add/$'									=>	'm=Pk&a=add',
		'^pk/friend_list/$'							=>	'm=Pk&a=getFriendList',
		'^pk/mission_list/$'						=>	'm=Pk&a=getCommonMissionList',
		'^pk/my_mission_list/$'						=>	'm=Pk&a=getMyMissionList',
		'^pk/misson_friend_list/$'					=>	'm=Pk&a=getFriendListByMissionId',
		'^pk/$'										=>	'm=Pk&a=showList',
		'^pk/morelist/$'							=>	'm=Pk&a=morePkList',
		'^pk/my_pk_list/$'							=>	'm=Pk&a=myPkList',
		'^pk/detail/(.*)_(.*).html$'						=>	'm=Pk&a=showDetail&pk_id=$1&from=$2',
		'^pk/detail/(.*).html$'						=>	'm=Pk&a=showDetail&pk_id=$1',
		'^pk/rank.html$'							=>	'm=Pk&a=pkRankList',
		'^pk/event.html$'							=>	'm=Pk&a=pkEventList',
		'^pk/make_answer.html$'						=>	'm=Pk&a=markingPKAnswer',
		'^pk/mission_pk_event.html$'				=>	'm=Pk&a=getMissionPkEventList',
		'^pk/mission_pk_rank.html$'					=>	'm=Pk&a=getMissionPkRanking',
		'^pk/start.html$'							=>	'm=Pk&a=startPk',
		'^pk/accept_prize.html$'					=>	'm=Pk&a=acceptPrize',
		'^pk/es_detail.html$'						=>	'm=Pk&a=getEsDetail',
		'^pk/killer.html$'							=>	'm=Pk&a=execOverTimePkJudgment',
		'^pk/pk_user.html$'							=>	'm=Pk&a=getPkUserGroupList',
		'^pk/mission_pk_user.html$'					=>	'm=Pk&a=getUserListByPassMissionId',
		'^pk/mission_pk_list.html$'					=>	'm=Pk&a=getUserPkListByMissionId',
		'^pk/get_detail.html$'						=>	'm=Pk&a=getPkDetail',
		'^pk/deal_gold.html$'						=>	'm=Pk&a=acceptPkGold',
		'^pk/pk_event.html$'						=>	'm=Pk&a=showPkTrends',
		'^pk/pk_page$'                              =>  'm=Pk&a=getMyMissionListByPage',
		'^pk/at_once$'                              =>  'm=Pk&a=atOncePk',


		'^(\w+)/shuoshuo/$'							=>	'm=ShuoShuo&a=showShuoshuo&userId=$1',
		'^shuoshuo$'								=>	'm=ShuoShuo&a=showShuoShuo',
		'^shuoshuo/send/$'					  		=>	'm=ShuoShuo&a=publish',
		'^shuoshuo/comment/$'						=>	'm=ShuoShuo&a=comment',
		'^shuoshuo/forward/$'						=>	'm=ShuoShuo&a=forward',
		'^shuoshuo/support/$'						=>	'm=ShuoShuo&a=support',
		'^shuoshuo/allcomments/$'					=>	'm=ShuoShuo&a=getAllComment',
		'^shuoshuo/allreplys/$'						=>	'm=ShuoShuo&a=getAllCommentReply',
		'^shuoshuo/upload_image/$'					=>	'm=ShuoShuo&a=uploadImage',
		'^shuoshuo/list/$'							=>	'm=ShuoShuo&a=getShuoShuoList',
		'^shuoshuo/lastReplyList/$'					=>	'm=ShuoShuo&a=getLastReplyList',
		'^shuoshuo/detail/$'						=>	'm=ShuoShuo&a=showDetail&shuo_id=_shuoshuo_id',
		'^shuoshuo/allComment/$'					=>	'm=ShuoShuo&a=getAllComment&id=_id',
		'^shuoshuo/reply/$'							=>	'm=ShuoShuo&a=getAllCommentReply&id=_id',
		'^shuoshuo/delete/$'						=>	'm=ShuoShuo&a=deleteComment',


		//留言
		'^guestbook/delete$'						=>	'm=GuestBook&a=delete',
		'^guestbook/list.html$'						=>	'm=GuestBook&a=getGuestBookList',
		'^(\w+)/guestbook/list.html$'				=>	'm=GuestBook&a=getGuestBookList&userId=$1',
		'^guestbook/last_message_list.html$'		=>	'm=GuestBook&a=getLastMessageUserList',
		'^guestbook/last_message_reply_list.html$'	=>	'm=GuestBook&a=getLastMessageReplyList',
		'^guestbook/reply$'							=>	'm=GuestBook&a=reply',
		'^(\w+)/guestbook/show$'					=>	'm=GuestBook&a=showGuestBook&userId=$1',
		'^guestbook/show$'							=>	'm=GuestBook&a=showGuestBook',
		'^guestbook/all_reply.html$'				=>	'm=GuestBook&a=getAllReply',

		//得到当前会员的各科目关卡列表
		'^my_mission/$'								=>	'm=Mission&a=getUserMissionList',

		//他的好友
		'^(\w+)/friend$'					=>	'm=Friend&a=showFriend&userId=$1',
		'^friend/more/$'					=>	'm=Friend&a=showFriendListByFriendIdMore',
		'^friend/apply$'					=>	'm=Friend&a=apply',
		'^friend/show_proably$'				=>	'm=Friend&a=showProablyFriend',
		'^friend/proably_friend$'			=>	'm=Friend&a=getProablyFriend',
		'^friend/proably_friend_page$'		=>	'm=Friend&a=getProablyFriendByPage',
		'^friend/search.html$'				=>	'm=Friend&a=searchFriend',
		'^friend/list.html$'				=>	'm=Friend&a=loadFriendList',
		'^friend/search_result.html$'		=>	'm=Friend&a=showSearchFriend',
		'^friend/manage$'					=>	'm=Friend&a=manage',
		'^friend/show_apply$'				=>	'm=Friend&a=showFriendApply',
		'^friend/my_apply$'					=>	'm=Friend&a=getApplyToMeFriend',
		'^friend/agree$'					=>	'm=Friend&a=agreeFriend',
		'^friend/ignore$'					=>	'm=Friend&a=ignoreFriend',
		'^friend/new_friend$'				=>	'm=Friend&a=getAgreeFriend',
		'^friend/delete$'					=>	'm=Friend&a=delete',

		'^friend/show_recommend$'			=>	'm=Friend&a=showRecommendFriend',
		'^recommend/list/$'					=>	'm=Friend&a=getRecommendListByPage',
		'^recommend/get_ub/$'				=>	'm=Friend&a=getRecommendUb',

		//小纸条
		'^message$'						=>	'm=Message&a=showMessage',
		'^message/delete/$'					=>	'm=Message&a=delete',
		'^message/send$'					=>	'm=Message&a=send',
		'^message/more/$'					=>	'm=Message&a=loadMore',
		'^message/reload/$'					=>	'm=Message&a=reloadMessage',
		'^message/del/$'					=>	'm=Message&a=delMessage',
		'^message/friend_list/$'			=>	'm=Message&a=getUserFriendList',


		//好友个人主页
		'^home.html$'						=>	'm=Zone&a=showHome',
		'^home/(.+)$'						=>	'm=Zone&a=showHome&groupId=$1',
		'^(\d+)/(.+)$'						=>	'm=Zone&a=showHome&userId=$1&groupId=$2',

		//事件
		'events'							=>	'm=Event&a=getEventList',
		'notices'							=>	'm=Event&a=getPersonalMessageList',
		'event/delete'						=>	'm=Event&a=delete',
		'event/more_user_list'				=>	'm=Event&a=getMoreUserList',
		'event/match_pk_statistics'			=>	'm=Event&a=matchAndPKStatistics',
		'^mission_x/_userId$'				=>	'm=Zone&a=showHome&userId=_userId',
		'^mission_x/(\d{8})$'				=>	'm=Zone&a=showHome&userId=$1',

		//皮肤风格
		'^style/list.html$'					=>	'm=Style&a=showList',
		'^style/set/$'						=>	'm=Style&a=setStyle',

		//视频模块
		'^video/$'							=>	'm=Video&a=showVideoHome',
		'^video/category/(\w+)/$'			=>	'm=Video&a=showVideoHome&categoryId=$1',
		'^video/(\w+)/$'					=>	'm=Video&a=videoPlay&id=$1',

		//家长绑定模块
		'^account/setting$'					=>	'm=Account&a=showParentMobileSetting',
		'^account/settingMobile$'			=>	'm=Account&a=settingParentMobileAccount',
		'^account/sendCode'					=>	'm=Account&a=sendParentMobileVerify',

		//兑换商城
		'^exchange/goods_list'				=>	'm=Exchange&a=getGoodsList',
		'^mission_x/exchange/detail_(\w+).html$'		=>	'm=Exchange&a=getGoodsDetail&goods_id=$1',
		'^mission_x/exchange/exchange.json'			=>	'm=Exchange&a=exchange',
		'^exchange/check_exchange/'			=>	'm=Exchange&a=checkExchange',
		'^exchange/my_exchange/'			=>	'm=Exchange&a=getMyExchangeList',
		'^mission_x/exchange/support.json'				=>	'm=Exchange&a=supportGoods',
		'^exchange/(\d+).html'				=>	'm=Exchange&a=showList&goodsId=$1',
		'^mission_x/exchange/home.html'						=>	'm=Exchange&a=showList',
		'^exchange/$'						=>	'm=Index&a=direct301',
		'^newexchange'						=>	'm=Exchange&a=index',

		//道具
		'^prop/getPropList/$'				=>	'm=Prop&a=getPropList',
		'^prop/getCartInfo/$'				=>	'm=Prop&a=getCartInfo',
		'^prop/getNumerical/$'				=>	'm=Prop&a=getNumerical',
		'^prop/putCart/$'					=>	'm=Prop&a=putCart',
		'^prop/cancelCart/$'				=>	'm=Prop&a=cancelCart',
		'^prop/buyOneKind/$'				=>	'm=Prop&a=buyOneKind',
		'^prop/buyFromCart/$'				=>	'm=Prop&a=buyFromCart',
		'^prop/getPackageInfo/$'			=>	'm=Prop&a=getPackageInfo',
		'^prop/discardProp/$'				=>	'm=Prop&a=discardProp',
		'^prop/sendProp/$'					=>	'm=Prop&a=sendProp',
		'^prop/getToolBar/$'				=>	'm=Prop&a=getToolBar',
		'^prop/countCartGold/$'				=>	'm=Prop&a=countCartGold',
		'^prop/getSendProp/$'				=>	'm=Prop&a=getSendProp',
		'^prop/getProp/$'					=>	'm=Prop&a=getProp',
		'^prop/ignoreProp/$'				=>	'm=Prop&a=ignoreProp',
		'^prop/useProp/$'					=>	'm=Prop&a=useProp',
		'^prop/propCartList$'				=>	'm=Prop&a=getPropCartList',

		//2014教师节
		'^teachers_day.html$'				=>	'm=TeachersDay&a=showActivity',
		'^teachers_day/share$'				=>	'm=TeachersDay&a=share',
		'^teachers_day/giving$'				=>	'm=TeachersDay&a=giving',

		//活动大厅
		'^activity.html$'					=>	'm=Activity&a=showActivity',
		'^activity/mission.html$'			=>	'm=Activity&a=showMission',



		//赛事Q币活动----已经作废,由于网址可能发到了其他网站上,暂时重定向到首页
		'^activity/QB.html$'				=>  'm=Index&a=index',

		//争分夺宝活动
		'^activity/study_tour.html$'		=>  'm=Takejewels&a=showActivity',
		'^activity/study_tour_m.html$'		=>  'm=Takejewels&a=showMactivity',
		'^activity/study_tour_do.html$'		=>  'm=Takejewels&a=showDoactivity',

		//团队赛活动
		'^activity/team_intro.html$'		=>  'm=Team&a=showActivity',
		'^activity/team_intro_m.html$'		=>  'm=Team&a=showMactivity',
		'^activity/team_intro_do.html$'		=>  'm=Team&a=showDoMactivity',
		'^activity/team_intro_do-(.*).html$' =>  'm=Team&a=showDoMactivity&id=$1',
		'^activity/team_intro_p.html$'		=>  'm=Team&a=showActivityP',
		'^activity/team_adv.html$'			=>  'm=Team&a=showAdv',
		'^activity/team_award.html$'		=>  'm=Team&a=showAward',
		'^activity/team_award-(.*).html$'	=>  'm=Team&a=showAward&id=$1',

		//2014年末新版获取旧版大礼包
		'^account/get_vip_privitege.html$'	=>  'm=Account&a=getVipPrivitege',
		'^get_daily_task.json$'				=>  'm=Index&a=getDailyTask',
		'^get_daily_task_prize.json$'		=>  'm=Index&a=getDailyTaskPrize',

		//新BBS
		'^mission_x/forum-0-1-0-2.html$'			=>  'm=Thread&a=index',
		'^mission_x/article/(.*).html$'		=>  'm=Thread&a=article&id=$1',

		'^mission_x/red_packet.html$'		=>	'm=Activity&a=showRedPacket',
		'^mission_x/event.html'				=>	'm=Event&a=showEventList',
		'^(\d{8})$'							=>	'm=Zone&a=showHome&userId=$1',

		//帮助中心
		'^help/signin.html'					=>	'm=Help&a=showHome&tag=signin',
		'^mission_x/match/yh_guide.html'	=>	'm=Match&a=showYhGuide',
	),

	APP_MANAGE => array(
		'^tools.html$'						=>	'm=Tools&a=showTools',
	),

	APP_PROXY => array(
		'^captcha/(.*)/$'			=>	'm=Captcha&a=display&name=$1',

		'^account/register.html$'	=>	'm=Account&a=showRegister',
		'^account/register/$'		=>	'm=Account&a=register',
		'^account/check/$'			=>	'm=Account&a=checkMail',
		'^account/verify/$'			=>	'm=Account&a=sendVerify',
		'^account/login.html$'		=>	'm=Account&a=showLogin',
		'^account/login/$'			=>	'm=Account&a=login',
		'^account/logout/$'			=>	'm=Account&a=logout',
		'^account/personal.html$'	=>	'm=Account&a=showPersonalInfo',
		'^account/personal/$'		=>	'm=Account&a=getUserInfoByEmailOrUserId',



		'^recharge/recharge.html$'	=>	'm=Recharge&a=showRecharge',
		'^recharge/recharge/$'		=>	'm=Recharge&a=recharge',
		'^recharge/p(.*).html$'		=>	'm=Recharge&a=showList&page=$1',
		'^recharge/d(.*).html$'		=>	'm=Recharge&a=showDetail&id=$1',

		'^announcement.html$'		=>	'm=Announcement&a=showList',
		'^announcement/p(.*).html$' =>	'm=Announcement&a=showList&page=$1',
		'^announcement/d(.*).html$'	=>	'm=Announcement&a=showDetail&id=$1',

		'^apply.html$'				=>	'm=Apply&a=showApply',
		'^explanation.html$'		=>	'm=Apply&a=showExplanation',
		'^apply/send/$'				=>	'm=Apply&a=apply',
		'^apply/upload/$'			=>	'm=Apply&a=uploadInfo',

		'^api.html$'				=>	'm=Api&a=showDetail',
		'^api/d(.*).html$'			=>	'm=Api&a=showDetail&id=$1',

		'^pay/ub_pay.html$'			=>	'm=Pay&a=showUbPay',
		'^pay/month_pay.html$'		=>	'm=Pay&a=showMonthPay',
		'^pay/pay/$'				=>	'm=Pay&a=pay',
		'^pay/month_pay/$'			=>	'm=Pay&a=monthPay',
		'^pay/jump/(.*).html$'		=>  'm=Pay&a=successJump&id=$1',
		'^pay/success/(.*).html$'	=>  'm=Pay&a=showSuccess&id=$1',
		'^pay/notify/$'				=>	'm=Pay&a=notifyAlipay',
		'^pay/list.html$'			=>	'm=Pay&a=showList',
		'^pay/list/t(\d+).html$'	=>	'm=Pay&a=showList&type=$1',
		'^pay/list/t(\d+)/p(.*).html$'	=>	'm=Pay&a=showList&type=$1&page=$2',
	),

	APP_PAY => array(
		'^index.html$'						=>	'm=Index&a=index',
		'^pay/ubpay.html$'					=>	'm=Pay&a=showUbPay',
		'^pay/ubpay/$'						=>	'm=Pay&a=ubPay',
		'^pay/month_pay.html$'				=>	'm=Pay&a=showMonthPay',
		'^pay/month_pay/$'					=>	'm=Pay&a=monthPay',
		'^pay/notify/$'						=>	'm=Pay&a=notifyAfterPay',
		'^account/personal/$'				=>	'm=Account&a=getUserInfoByEmailOrNumberId',
		'^account/index.html$'				=>	'm=Account&a=showList',
		'^account/list/t(\d+).html$'		=>	'm=Account&a=showList&type=$1',
		'^account/list/t(\d+)/p(.*).html$'	=>	'm=Account&a=showList&type=$1&page=$2',
		'^pay/jump/(.*).html$'				=>  'm=Pay&a=successJump&id=$1',
		'^pay/success/(.*).html$'			=>  'm=Pay&a=showSuccess&id=$1',
		'^open/pay/$'						=>	'm=OpenRecharge&a=pay',
		'^account/(.*)/(.*)/userInfo.html$'=>	'm=Account&a=getUserInfoByEmailOrUserId&account=$1&get_vip=$2',
		'^account/(.*)/userInfo.html$'		=>	'm=Account&a=getUserInfoByEmailOrUserId&account=$1',

		//VIP充值
		'^pay/vip.html$'					=>	'm=Pay&a=showVipPay',
		'^pay/vip_pay/$'					=>	'm=Pay&a=vipPay',
		'^pay/vip_notify/$'					=>	'm=Pay&a=vipNotifyAfterPay',
		'^pay/vip_jump/(.*).html$'			=>  'm=Pay&a=vipSuccessJump&id=$1',
		'^pay/vip_success/(.*).html$'		=>  'm=Pay&a=showVipSuccess&id=$1',
	),

	APP_PARENT => array(
		'^ $'								=>	'm=Index&a=index',
		'^captcha/(.*)/$'					=>	'm=Captcha&a=display&name=$1',
		'^show_login.html$'					=>	'm=Parents&a=showLogin',
		'^login.html$'						=>	'm=Parents&a=login',
		'^logout.html$'						=>	'm=Parents&a=logout',
		'^(\d{8})$'							=>	'm=Parents&a=showHome&userId=$1',
		'^index.html$'						=>	'm=Parents&a=showHome',
		'^findpw.html$'						=> 	'm=Parents&a=showFindPassword',
		'^find_password.html$'				=> 	'm=Parents&a=findPassword',
		'^setting.html$'					=> 	'm=Parents&a=showParentSetting',
		'^send_verify.html$'				=> 	'm=Parents&a=sendParentMobileVerify',
		'^send_verify2.html$'				=> 	'm=Parents&a=sendParentMobileVerify2',
		'^children/month_grade.html$'		=> 	'm=Parents&a=getUserMonthGradeList',
		'^set_password.html$'				=> 	'm=Parents&a=updatePassword',
		'^set_phone.html$'					=> 	'm=Parents&a=updatePhone',
		'^education_information.html$'		=> 	'm=Parents&a=educationInformation',
		'^education_information/(.*).html$'	=> 	'm=Parents&a=educationInformationDetail&id=$1',
		'^login_children.html$'				=> 	'm=Parents&a=loginChildren',
		'^notice.html$'						=>	'm=Index&a=notice',
		'^register.html$'					=>	'm=Index&a=doXxtAccountRegister',
	),

	APP_TEACHER => array(
		'^show_login.html$'		=>	'm=Account&a=showLogin',
		'^student_mark.html$'	=>	'm=Index&a=showStudentMark',
		'^mission_list.html$'	=>	'm=Index&a=getMissionList',
		'^student_list.html$'	=>	'm=Index&a=getMissionStudentList',
		'^es_list.html$'		=>	'm=Index&a=getEsList',
		'^es_stats.html$'		=>	'm=Index&a=showEsStats',
		'^student.html$'		=>	'm=Index&a=index',
		'^education_list.html$'	=> 	'm=Education&a=educationList',
		'^article/(.*).html$'	=> 	'm=Education&a=article&id=$1',
	),

	APP_VIP => array(
		'^ $'				=>	'm=Index&a=index',
		'^ $'				=>	'm=Index&a=index&getVipGift=1',
		'^vip/$'			=>	'm=Index&a=showVipType&type=1',
		'^white_gold/$'		=>	'm=Index&a=showVipType&type=2',
		'^diamond/$'		=>	'm=Index&a=showVipType&type=3',
		'^vipInfo/$'		=>	'm=Index&a=getVipInfo',
		'^get_package/$'	=>	'm=Index&a=getDayPackage',
		'^get_gift/$'		=>	'm=Index&a=getVipGift',
	),

	APP_XXT => array(
		'^x/index.html$'					=> 'm=Index&a=index',
		'^x/forum.html$'					=> 'm=Bbs&a=index',
		'^x/article/(\d+).html$'			=> 'm=Bbs&a=detail&id=$1',
		'^x/student/show_edit_info.html$'	=> 'm=Account&a=editInfo',
		'^x/home.html$'						=> 'm=Account&a=showHome',
		'^account/send_app_msg.html$'		=> 'm=Account&a=sendWeiboWhenConditionMeet',
		'^center.html$'						=> 'm=Index&a=showCenter',
		'^x/mission/home.html$'				=> 'm=Mission&a=index',
		'^lottery_cards.html'				=> 'm=Mission&a=showLotteryCards',
		'^my_cards.html'					=> 'm=Mission&a=showMyCards',
		'^random_lottery_cards.html'		=> 'm=Mission&a=getRandomLotteryCard',
		'^login.html'						=> 'm=Account&a=doXxtAccountLogin',
		//'^dologin.html'						=> 'm=Account&a=doXxtAccountLogin',
		'^account_login.html$'				=> 'm=Account&a=showLogin',
		'^ranking.html$'					=> 'm=Grade&a=showRankingList',
		'^Match/Detail/(\d+)$'				=> 'm=Match&a=showDetail&match_id=$1',
		'^x/match.html$'					=>	'm=Match&a=list',

		//2014教师节
		'^teachers_day/intro.html$'			=> 'm=TeachersDay&a=intro',
		//活动大厅
		'^activity.html$'					=>	'm=Activity&a=showActivity',
		'^activity/mission.html$'			=>	'm=Activity&a=showMission',
		'^activity/exchange_activity.html$'	=>	'm=Index&a=showExchange',
		'^x/activity/scholarshipguess/home.html$'	=>	'm=Activity&a=showScholarShipGuess',

		'^activity/teacher_activity.html$'	=>	'm=TeachersDay&a=showActivity',
		'^x/red_packet.html$'				=>	'm=Activity&a=showRedPacket',

		'^activity/study_tour_do.html$'		=>  'm=Takejewels&a=showDoactivity',
		'^x/activity/scholarshipguess/home.html$'		=>  'm=Activity&a=scholarshipGuess',
		'^x/activity/scholarshipguess/preview.html$'		=>  'm=Activity&a=scholarshipGuessPreview',
		'^x/exchange/all_list.html$'		=>  'm=Exchange&a=showHome',

	),

	APP_P_XXT => array(
		'^ $'								=>	'm=Index&a=index',
		'^month.html$'						=>	'm=Index&a=getUserMonthGradeList',
		'^notice.html$'						=>	'm=Index&a=notice',
		'^register.html$'					=>	'm=Index&a=doXxtAccountRegister',
	),

	APP_T_XXT => array(
		'^ $'								=>	'm=Index&a=index',
		'^app_education_list.html$'				=> 	'm=Education&a=educationList',
		'^app_article/(.*).html$'				=> 	'm=Education&a=article&id=$1',
	),

	APP_BBS => array(

		'^article/(\w+)-(\w+)-(\w+).html$'	=> 'm=Thread&a=article&id=$1&notify=$2&page=$3',
		'^thread-(\d+).html$'				=> 'm=Thread&a=index&categoryId=$1',

		'^thread-(\d+)-1.html$'				=> 'm=Thread&a=index&categoryId=$1&recommend=1',
		'^thread-(\d+)-2.html$'				=> 'm=Thread&a=index&categoryId=$1&top=1',

		'^article/(\w+).html$'				=> 'm=Thread&a=article&id=$1',
		'^article.html$'					=> 'm=Thread&a=article',
		'^publish-article.html$'			=> 'm=Thread&a=showAdd',
		'^publish-article-(\d+).html$'		=> 'm=Thread&a=showAdd&categoryId=$1',

		'^article/edit/(\d+).html$'			=> 'm=Thread&a=showEdit&id=$1',
		'^article/save$'					=> 'm=Thread&a=articleDo',
		'^article/count/(\d+)$'				=> 'm=Thread&a=upArticleCount&id=$1',

		'^comment/add$'						=> 'm=Thread&a=addComment',
		'^support/add$'						=> 'm=Thread&a=support',
		'^upload$'							=> 'm=Thread&a=uploadFile',

		'^my-article.html$'					=> 'm=Thread&a=myArticle',
		'^my-comment.html$'					=> 'm=Thread&a=myComment',
		'^my-notification.html$'			=> 'm=Thread&a=myNotification',
	),
);