<?php
$GLOBALS['VAILDATE'] = array(
	'email' => array(
		array('isEmail()', '邮箱格式错误'),
	),
	'username' => array(
		array('isAllChinese()', '姓名必须由2-6位中文组成!'),
		array('length(2, 6)', '姓名必须由2-6位中文组成!'),
	),
	'group_name' => array(
		array('length(2, 16)', '权限组名称必须为2到8位'),
		array('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_\"?\'\/\=,\|")', '抱歉，权限组名称不能包含特殊字符'),
	),
	'password' => array(
		array('length(6, 16)', '密码长度必须为6到16位'),
	),
	'captcha' => array(
		array('length(5, 5)', '验证码长度不正确'),
	),
	'oldPassword' => array(
		array('length(6, 16)', '密码长度必须为6到16位'),
	),
	'newPassword' => array(
		array('length(6, 16)', '密码长度必须为6到16位'),
	),
	'emailCode' => array(
		array('length(6, 6)', '新邮箱验证码长度不正确'),
	),

	//注册
	'email_register' => array(
		array('isEmail()', '邮箱格式错误'),
	),
	'password_register' => array(
		array('length(6, 16)', '密码长度必须为6到16位'),
	),
	'repeatPassword_register' => array(
		array('length(6, 16)', '重复密码，密码长度必须为6到16位'),
	),
	'invitation_register' => array(
		array('length(5, 8)', '邀请码长度不正确'),
	),
	'captcha_register' => array(
		array('length(5, 5)', '验证码长度不正确'),
	),
	'is_read_register' => array(
		array('eq("1")', '请先阅读并同意遵守'),
	),
	'trueName_register' => array(
		array('isAllChinese()', '请填写您的真实姓名,姓名必须由2-6位中文组成!'),
		array('length(2, 6)', '请填写您的真实姓名,姓名必须由2-6位中文组成!'),
	),
	'provinceId_register' => array(
		array('range(110000, 650000)', '请选择所在的省份!'),
	),
	'cityId_register' => array(
		array('range(110100, 659000)', '请选择所在的城市!'),
	),
	'areaId_register' => array(
		array('range(110101, 659004)', '请选择所在的地区!'),
	),
	'schoolId_register' => array(
		array('isNumber()', '请选择所在的学校')
	),
	'gradeId_register' => array(
		array('range(1,9)', '请选择所在的年级!'),
	),
	'className_register' => array(
		array('notNull()', '请选择所在的班级')
	),
	'addClassName_register' => array(
		array('notNull()', '请选择所在的班级'),
	),
	'mobileCode' =>array(
		array('isNumber(6)', '请输入正确的的手机校验码！')
	),

	//用户个人信息
	'trueName' => array(
		array('isAllChinese()', '姓名必须由2-6位中文组成!'),
		array('length(2, 6)', '姓名必须由2-6位中文组成!'),
	),
	'provinceId' => array(
		array('range(110000, 650000)', '请选择所在的省份!'),
	),
	'cityId' => array(
		array('range(110100, 659000)', '请选择所在的城市!'),
	),
	'areaId' => array(
		array('range(110101, 659004)', '请选择所在的地区!'),
	),
	'saveAreaId' => array(
		array('range(110101, 659004)', '请选择所在的地区!'),
	),
	'year' => array(
		array('notNull()', '请选择生日年份'),
		array('range(1980, 2013)', '请选择生日年份'),
	),
	'month' => array(
		array('notNull()', '请选择生日月份'),
		array('range(1, 12)', '请选择生日月份'),
	),
	'day' => array(
		array('notNull()', '请选择生日日期'),
		array('range(1, 31)', '请选择生日日期'),
	),
	'birthDate' => array(
		array('isDate()', '请填写正确的出生日期!'),
	),
	'detailedPlace' => array(
		array('notNull()', '请填写街道地址!'),
	),
	'gradeId' => array(
		array('range(1,9)', '请选择所在的年级!'),
	),
	'className' => array(
		array('notNull()', '请选择所在的班级'),
		array('neq("-1")', '请选择所在的班级'),
	),
	'gender' => array(
		array('_in(1,2)', '请填写真实的姓别!'),
	),
	'mobile' => array(
		array('isPhone()', '请填写正确的手机号码!'),
	),
	'schoolId' => array(
		array('notNull()', '请选择所在的学校!'),
	),
	'signature' => array(
		array('length(1, 35)', '个性签名必须在1-35个字内!'),
	),

	//代理商登录注册验证
	'numberId' => array(
		array('isNumber()','数字帐号错误'),
		array('length(5,5)','数字帐号错误'),
	),
	'registerPassword' => array(
		array('length(6,18)', '密码由6到20位数字及字母组成'),
		array('isStr(3)', '密码由6到20位数字及字母组成'),
	),
	'mobileVerify' => array(
		array('isNumber()','校验码错误'),
		array('length(6,6)','校验码错误'),
	),

	'loginPassword' => array(
		array('length(6,18)', '密码错误'),
		array('isStr(3)', '密码错误'),
	),

	'proxyLoginCatcph' => array(
		array('length(5, 5)', '验证码错误'),
	),
	//代理商登录注册验证结束

	'announcementTitle' => array(
		array('notNull()','公告标题不能为空'),
	),

	'userEmail' => array(
		array('isEmail()','帐号为会员邮箱'),
	),
	'ub' => array(
		array('notNull()', 'ub为1到10000之间的正整数'),
		array('isNumber()', 'ub为1到10000之间的正整数'),
		array('range(1,10000)', 'ub为1到10000之间的正整数'),
	),

	//充值卡模块
	'batch_id' => array(
		array('notNull()', '批号为10位正整数'),
		array('isNumber(10)', '批号为10位正整数'),
	),
	'money'	=> array(
		array('notNull()', '金额为1到10000之间的正整数'),
		array('isNumber()', '金额为1到10000之间的正整数'),
		array('range(1,10000)', '金额为1到10000之间的正整数'),
	),
	'quantity' => array(
		array('notNull()', '数量为1到10000之间的正整数'),
		array('isNumber()', '数量为1到10000之间的正整数'),
		array('range(1,10000)', '数量为1到10000之间的正整数'),
	),
	'over_time' => array(
		array('notNull()', '请选择过期时间'),
	),

	//学校管理
	'school_name' => array(
		array('length(2, 30)', '学校长度为2到30个字符'),
		array('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_\"?\'\/\=,\|")', '抱歉，学校名字不能含有特殊字符!'),
	),
	'class_name' => array(
		array('length(1, 10)', '班级长度为1到10个字符'),
		array('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_\"?\'\/\=,\|")', '抱歉，班级名字不能含有特殊字符!'),
	),

	'age' => array(
		array('isNumber()', '年龄必须为一个数字'),
		array('range(5,100)', '年龄为5到100之间的正整数'),
	),
	'gender' => array(
		array('_in(1,2)', '请填写真实的姓别!'),
	),
	'address' => array(
		array('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_\"?\'\/\=,\|")', '抱歉，地址不能包含特殊字符'),
	),
	'comment' => array(
		array('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_\"?\'\/\=,\|")', '抱歉，备注不能包含特殊字符'),
	),

	//关卡管理
	'missionName' => array(
		array('length(1, 255)', '关卡名字长度为1到255个字符'),
		array('noStr("\<\>\(\)`\\+\[\]\{\}~@#\$%\^;:&\*\-_\/\=\|")', '抱歉，关卡名字不能含有特殊字符!'),
	),
	'missionCorrectCounts' => array(
		array('notNull()', '题数不能为空'),
		array('isNumber()', '题数为正整数'),
		array('range(1,1000)', '题数为1到1000之间的正整数'),
	),
	'missionDuration' => array(
		array('notNull()', '时间不能为空'),
		array('isNumber()', '时间必须是正整数'),
		array('range(1,300)', '时间值为1到300之间的正整数'),
	),
	'missionBlood' => array(
		array('notNull()', '血量不能为空'),
		array('isNumber()', '血量必须是正整数'),
		array('range(1,10)', '血量值为1到10之间的正整数'),
	),
	'missionOrders' => array(
		array('notNull()', '排序不能为空'),
		array('isNumber()', '排序必须是正整数'),
		array('range(1,10000)', '排序值为1到10000之间的正整数'),
	),
	'missionCategoryIds' => array(
		array('notNull()', '请添加知识点'),
		array('isNumber()', '请输入真整数'),
	),

	//设置起始关卡
	'chineseStartMission' => array(
		array('notNull()', '请设置语文科目的起始关卡'),
		array('isNumber()', '请设置语文科目的起始关卡'),
	),
	'englishStartMission' => array(
		array('notNull()', '请设置数学科目的起始关卡'),
		array('isNumber()', '请设置数学科目的起始关卡'),
	),
	'mathStartMission' => array(
		array('notNull()', '请设置英语科目的起始关卡'),
		array('isNumber()', '请设置英语科目的起始关卡'),
	),

	//系统设置
	'is_open_system_m' => array(
		array('in(0,1)', '非法的开关设置'),
	),
	'm_close_tip' => array(
		array('length(0,256)'),
	),
	'is_open_system_www' => array(
		array('in(0,1)', '非法的开关设置'),
	),
	'www_close_tip' => array(
		array('length(0,256)'),
	),
	'is_open_system_sns' => array(
		array('in(0,1)', '非法的开关设置'),
	),
	'sns_close_tip' => array(
		array('length(0,256)'),
	),
	'is_open_system_pay' => array(
		array('in(0,1)', '非法的开关设置'),
	),
	'pay_close_tip' => array(
		array('length(0,256)'),
	),
	'is_open_system_proxy' => array(
		array('in(0,1)', '非法的开关设置'),
	),
	'proxy_close_tip' => array(
		array('length(0,256)'),
	),


	//赛事添加和编辑
	'match_name'	=>	array(
		array('notNull()', '赛事名称不能为空'),
	),
	'description'	=>	array(
		array('length(1, 100)', '奖品描述长度为1到100个字符'),
		array('noStr("\<\>\(\)`\\+\[\]\{\}~@#\$%\^;:&\*\-_\/\=\|")', '抱歉，关卡名字不能含有特殊字符!'),
	),
	'match_start_time'	=>	array(
		array('notNull()', '开始时间不能为空'),
	),
	'match_end_time'	=>	array(
		array('notNull()', '结束时间不能为空'),
	),
	'registration_start_time'	=>	array(
		array('notNull()', '报名开始时间不能为空'),
	),
	'registration_end_time'	=>	array(
		array('notNull()', '报名结束时间不能为空'),
	),
	'limit_players'	=>	array(
		array('range(1,10000)', '报名人数为1到10000人'),
	),

	'registration_fee'	=>	array(
		array('range(0,100)', '报名费为0到100金币'),
	),
	'rejoin_fee'	=>	array(
		array('range(0,10000)', '续场费为0到10000金币'),
	),
	'duration'	=>	array(
		array('_in(5,10,20,30,45,60,90,120)', '请选择赛事时长'),
	),
	'limit_level'	=>	array(
		array('range(0,60)', '请选择最小报名等级'),
	),
	'limit_times'	=>	array(
		array('range(0,5)', '请选择参赛次数'),
	),
	'limit_grades'	=>	array(
		array('range(0,12)', '请选择年级限制'),
	),
	'limit_xxt'	=>	array(
		array('range(0,1)', '请选择参赛用户类型'),
	),
	'grade_id'	=>	array(
		array('range(1,11)', '请选择年级'),
	),
	'subject_id'	=>	array(
		array('_in(1,2,3,4,99)', '请选择科目'),
	),

	//PK添加
	'pk_receiver_user_id'	=> array(
		array('range(1,"n")', '请选择PK用户'),
	),
	'pk_mission_id'	=> array(
		array('range(1,"n")', '请选择PK关卡'),
	),
	'pk_duration' => array(
		array('_in(3,4,5,6,7,8)', '请选择PK时长'),
	),
	'pk_over_time' => array(
		array('_in(3,5,7)', '请选择PK过期天数'),
	),
	'pk_es_counts' => array(
		array('range(1,10)', '亲，必须有PK的题目数量哦！'),
	),
	'pk_attachment_gold' => array(
		array('range(0,10)', '附加金币只能在1~10的范围内哦!'),
	),

	//游戏设置
	'accept_pk_count' => array(
		array('range(0,5)', '亲，每天接受PK次数不正确哦！'),
	),

	//皮肤
	'style_name'=> array(
		array('notNull()', '风格名称不能为空'),
	),
	'style_price'	=> array(
		array('range(0,100)', '使用价格为0到100金币'),
	),
	'style_orders'	=> array(
		array('range(1,99999)', '显示顺序为1-99999之间的数字'),
	),
	'style_img'=> array(
		array('notNull()', '预览图片不能为空'),
	),
	'style_pack_name'	=> array(
		array('notNull()', '请填写皮肤的包名'),
	),
	'style_status'	=> array(
		array('_in(0,1)', '错误的启用状态'),
	),
	'style_level_limit'	=> array(
		array('range(0,"n")', '错误的等级限制'),
	),
	'category_id'	=> array(
		array('range(0,"n")', '错误的皮肤分类'),
	),
	'style_is_default'	=> array(
		array('_in(0,1)', '错误的默认设置'),
	),
	'style_vip_limit'	=> array(
		array('_in(0,1,2,3)', '错误的默认设置'),
	),

	//视频模块
	'category_name'=> array(
		array('length(2, 8)', '分类名称必须为2到8位'),
		array('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_\"?\'\/\=,\|")', '抱歉，分类名称不能包含特殊字符'),
	),

	'video_title'=> array(
		array('notNull()', '视频标题不能为空'),
	),
	'thumb_url'=> array(
		array('notNull()', '图片路径不能为空'),
	),
	'video_url'=> array(
		array('notNull()', '视频文件路径不能为空'),
	),
	'umelook_id'=> array(
		array('notNull()', 'UMELOOK ID 不能为空'),
		array('isNumber()', 'UMELOOK ID 为不小于0的整数'),
	),
	'video_duration'=> array(
		array('notNull()', '播放时长不能为空'),
		array('isNumber()', '播放时长为不小于0的整数'),
	),
	'video_views'=> array(
		array('notNull()', '播放次数不能为空'),
		array('isNumber()', '播放次数为正不小于0的整数'),
	),
	'category_id'=> array(
		array('notNull()', '请选择视频分类'),
		array('isNumber()', '请选择视频分类'),
	),
	'video_status'=> array(
		array('_in(0,1)', '请选择视频发布状态'),
	),
	'is_recommend'=> array(
		array('_in(0,1)', '请选择视频推荐状态'),
	),
	'video_description'=> array(
		array('notNull()', '视频描述不能为空'),
	),

	//兑换商城添加和编辑
	'exchange_name'	=>	array(
		array('notNull()', '兑换物品名称不能为空'),
	),
	'exchange_profile'	=>	array(
		array('notNull()', '请上传兑换物品截图'),
	),
	'exchange_level'	=>	array(
		array('range(0,60)', '请选择兑换物品的等级'),
	),
	'exchange_gold'	=>	array(
		array('range(0,9999999)', '请填写兑换物品的金币'),
	),
	'exchange_stock'	=>	array(
		array('range(0,9999999)', '请填写兑换物品的库存'),
	),
	'exchange_orders'	=>	array(
		array('range(0,9999999)', '请填写兑换物品的默认排序'),
	),
	'exchange_type'	=>	array(
		array('range(0,3)', '请选择兑换物品的类型'),
	),
	'exchange_release'	=>	array(
		array('range(1,2)', '请选择兑换物品的上架状态'),
	),
	'exchange_summary'	=>	array(
		array('notNull()', '请填写兑换物品的简介'),
	),
	'exchange_description'	=>	array(
		array('notNull()', '请填写兑换物品的描述'),
	),
);