<html>
<head>
	<meta http-equiv="Content-Language" content="zh-cn">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>UmFun后台管理系统</title>
</head>
<frameset rows="50,*" framespacing="0" border="0" frameborder="0">
	<frame name="topFrame" scrolling="no" noresize target="main" src="?m=Index&a=showTop" marginwidth="0" marginheight="0">
	<frameset cols="140,*">
		<frame name="leftFrame" target="main" src="?m=Index&a=showLeft" marginwidth="0" marginheight="0" scrolling="no" noresize >
		<frame name="main" src="?m=Index&a=showMain" scrolling="auto">
	</frameset>
</frameset>
<noframes></noframes>

</html>