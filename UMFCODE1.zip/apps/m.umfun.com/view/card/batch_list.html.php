<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('card/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>

	<form>
		<div class="item">
			<div class="name">批次：</div>
			<div class="control"><input type="text" name="batch_id" id="batch_id" value="<?php if($batchId){echo $batchId;}?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="batchSearch(1);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">金额/月数：</div>
			<div class="control"><input type="text" name="money" id="money" value="<?php if($money > 0){echo $money;} ?>" /></div>
			<div class="name width80">过期时间：</div>
			<div class="control"><input type="text" name="over_time" id="over_time" value="<?php if($overTime){echo $overTime;} ?>" onclick="WdatePicker({dateFmt:'yyyy-MM-dd'})" /></div>
			<div class="name width80">创建时间：</div>
			<div class="control"><input type="text" name="create_time" id="create_time" value="<?php if($createTime){echo $createTime;} ?>"  onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">卡类型：</div>
			<div class="control">
				<select name="card_type" id="card_type">
					<option value="">请选择</option>
					<option value="1" <?php if($cardType == 1){echo 'selected="selected"'; }?>>UB充值卡</option>
					<option value="2"<?php if($cardType == 2){echo 'selected="selected"'; }?>>月费充值卡</option>
					<option value="3"<?php if($cardType == 3){echo 'selected="selected"'; }?>>月费体验卡</option>
				</select>
			</div>
			<div class="name width80">发行状态：</div>
			<div class="control">
				<select name="is_release" id="is_release">
					<option value="">请选择</option>
					<option value="0" <?php if($isRelease == '0'){echo 'selected="selected"'; }?>>未发行</option>
					<option value="1" <?php if($isRelease == '1'){echo 'selected="selected"'; }?>>己发行</option>
				</select>
			</div>

			<div class="name width80">回收状态：</div>
			<div class="control">
				<select name="is_recycle" id="is_recycle">
					<option value="">请选择</option>
					<option value="0" <?php if($isRecycle == '0'){echo 'selected="selected"'; }?>>未回收</option>
					<option value="1" <?php if($isRecycle == '1'){echo 'selected="selected"'; }?>>己回收</option>
				</select>
			</div>
			<div class="name width80">代理商：</div>
			<div class="control">
				<select name="proxy_id" id="proxy_id">
					<option value="">请选择</option>
					<?php if($proxyList){
						foreach($proxyList as $proxyKey=> $proxyInfo){
							if($proxyId == $proxyInfo['id']){
								 echo '<option selected="selected" value=' . $proxyInfo['id'] . '>' . $proxyInfo['name'].'</option>';	
							}else{
								echo '<option value=' . $proxyInfo['id'] . '>' . $proxyInfo['name'] . '</option>';
							}
						}
					}?>
					
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="batchSearch(2);">筛选</a>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
	function batchSearch(type){
		var url = '?m=Card&a=showBatchList';
		if(type == 1){
			var batchId = $.trim($('#batch_id').val());
			if(batchId){
				var batchReg = /^\d{10}$/;
				if(!batchReg.test(batchId)){
					UBox.show('批次为10位正整数',-1);
					$('#batch_id').select();
					return false;
				}else{
					url += '&batchId='+batchId;
				}
			}
			window.location.href= url;
		}else if(type == 2){
			
			var money = $('#money').val();
			
			if(money){
				var moneyReg = /^[1-9]{1}\d{0,}$/;
				if(!moneyReg.test(money)){
					UBox.show('金额为大于0的正整数',-1);
					$('#money').select();
					return false;
				}else{
					url += '&money='+money;
				}
				
			}
			
			var overTime = $.trim($('#over_time').val());
			if(overTime){
				url += '&overTime='+overTime;
			}
			
			var createTime = $.trim($('#create_time').val());
			if(createTime){
				url += '&createTime='+createTime;
			}

			var cardType = $('#card_type').val();
			if(cardType){
				url += '&cardType='+cardType;
			}
			
			var isRelease = $('#is_release').val();
			if(isRelease){
				url += '&isRelease='+isRelease;
			}

			var isRecycle = $('#is_recycle').val();
			if(isRecycle){
				url += '&isRecycle='+isRecycle;
			}
			var proxyId = $('#proxy_id').val();
			if(proxyId){
				url += '&proxyId='+proxyId;
			}

			window.location.href= url;
			/*
			if(money || overTime || createTime || cardType || isRelease || isRecycle || proxyId){
				
			}
			*/
		}
		
	}
</script>

<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
		._userList .list .c1{width:100px;}
		._userList .list .c2{width:60px;}
		._userList .list .c3{width:70px;}
		._userList .list .c4{width:100px;}
		._userList .list .c5{width:70px;}
		._userList .list .c6{width:70px;}
		._userList .list .c7{width:90px;}
		._userList .list .c8{width:120px;}
		._userList .list .c10{width:120px;}
		._userList .list .row .c9 a{padding-right:5px;}
		._userList .list .row .recycle{color:red}
	</style>
	<div class="title">批次列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">批次</div>
			<div class="c2">金额/月数</div>
			<div class="c3">数量</div>
			<div class="c3">卡类型</div>
			<div class="c4">代理商</div>
			<div class="c5">是否发行</div>
			<div class="c6">是否回收</div>
			<div class="c7">过期时间</div>
			<div class="c8">创建时间</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aBatchList){
			foreach($aBatchList as $aBatchInfo){ ?>
			<div class="row">
				<div class="c1"><?php echo $aBatchInfo['batch_id'] ? $aBatchInfo['batch_id'] : '&nbsp;'; ?></div>
				<div class="c2"><?php if($aBatchInfo['card_type'] == 1){echo $aBatchInfo['card_money'] . ' U币';}else{echo $aBatchInfo['card_money'].' 个月';} ?></div>
				<div class="c3"><?php echo $aBatchInfo['card_quantity'] ? $aBatchInfo['card_quantity'] : '&nbsp;'; ?></div>
				<div class="c3"><?php if($aBatchInfo['card_type'] == 1){echo 'UB充值卡';}elseif($aBatchInfo['card_type'] == 2){echo '月费充值卡';}else{echo '月费体验卡';} ?></div>
				<div class="c4"><?php echo $aBatchInfo['proxyName'] ? '<a href="#id='.$aBatchInfo['proxy_id'].'">'.$aBatchInfo['proxyName'].'</a>' : '未指定'; ?></div>
				<div class="c5"><?php echo $aBatchInfo['is_release'] == 1 ? '<a>己发行</a>' : '未发行'; ?></div>
				<div class="c6"><?php echo $aBatchInfo['is_recycle'] == 1 ? '<span class="recycle">己回收</span>' : '未回收'; ?></div>
				<div class="c7"><?php echo date('Y-m-d',$aBatchInfo['over_time']); ?></div>
				<div class="c8"><?php echo date('Y-m-d H:i:s',$aBatchInfo['create_time']); ?></div>
				<div class="c10 right">
					<?php if($aBatchInfo['is_release'] == 1){ ?>
						<a>己发行</a>
					<?php }else{ ?>	
						<a href="/?m=Card&a=showBatchRelease&id=<?php echo $aBatchInfo['id']?>">批量发行</a>
					<?php }?>
										
					<?php if($aBatchInfo['is_recycle'] == 1){ ?>
						<a class="recycle">己回收</a>
					<?php }else{ ?>
						<a onclick="javascript:batchRecycle(<?php echo $aBatchInfo['id']?>)">批量回收</a>	
					 <?php }?>
				</div>
			</div>
		<?php } 
		}else{
			echo '<font color="red">抱歉，暂时缺乏数据！</font>'; 
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	//批量回收
	function batchRecycle(_id){
		if(parseInt(_id)>0){
			UBox.confirm('确定执行此操作吗', function(){
				$.ajax({
					url : '?m=Card&a=batchRecycle',
					data : {id : _id},
					type : 'POST',
					dataType : 'json',
					success : function(result){
						UBox.show(result.msg, result.status, 'reload');
					},
					error:function(){
						UBox.show('请求失败', -1);
					}
				})	
			})
		}
	}		
</script>