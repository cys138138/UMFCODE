<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<?php display('card/nav.html.php'); ?>
<style type="text/css">
.unbind{
	background-color:#ccc;
}
</style>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._subject span{margin-right:15px; display:inline-block;}
	</style>
	<form id="ubCardAdd" class="addForm">
		<div class="title">充值卡批量发行</div>
		<?php if($aBatchInfo){?>
		<div class="item">
			<div class="name">批次号：</div>
			<div class="control"><?php echo $aBatchInfo['batch_id'];?></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">代理商：</div>
			<div class="control">
				<select name="proxy_id" id="proxy_id">
					<option value="0">-请选择代理商-</option>
					<?php if($aProxyList){
						foreach($aProxyList as $aProxyInfo){
							echo '<option value="'.$aProxyInfo['id'].'">'.$aProxyInfo['name'].'</option>';
						}
					}?>
				</select>
			</div>
		</div>
		<div class="clear"></div>		
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<a class="button" id="submitButton"/>确定</a>
			</div>
		</div>
		<div class="clear"></div>
		<?php }else{
			echo '无此记录';
		}?>
		
	</form>
</div>


<script type="text/javascript">

$("#submitButton").bind("click", formSubmit);

function formSubmit(){
	var _proxy_id = parseInt($('#proxy_id').val());
	if(_proxy_id >0){
		$.ajax({
			url : '?m=Card&a=BatchRelease',
			data : {batch_id : "<?php echo $aBatchInfo['batch_id']?>", proxy_id : _proxy_id},
			type : 'POST',
			dataType : 'json',
			success : function(result){
				if(result.status == 1){
					returnUrl = '<?php echo getReferer(); ?>';
					window.location.href = returnUrl;
				}else{
					UBox.show(result.msg, -1);
				}
			},
			error : function(){
				UBox.show('请求失败', -1);
			}
		});
	}else{
		UBox.show('请选择代理商', -1);
	}
	
}
</script>