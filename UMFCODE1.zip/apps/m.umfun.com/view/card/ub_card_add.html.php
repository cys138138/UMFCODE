<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<?php display('card/nav.html.php'); ?>
<style type="text/css">
.unbind{
	background-color:#ccc;
}
</style>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._subject span{margin-right:15px; display:inline-block;}
	</style>
	<form id="ubCardAdd" class="addForm">
		<div class="title">新增U币充值卡</div>
		<div class="item">
			<div class="name">批号：</div>
			<div class="control"><input type="text" name="batch_id" id="batch_id" value="<?php echo time()?>" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">金额：</div>
			<div class="control"><input type="text" name="money" id="money" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">数量：</div>
			<div class="control"><input type="text" name="quantity" id="quantity" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">过期时间：</div>
			<div class="control"><input type="text" name="over_time" id="over_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd'})" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">是否发行：</div>
			<div class="control">
				<select name="is_release" id="is_release" onchange="getProxy(this.value)">
					<option value="0">-稍后发行-</option>
					<option value="1">-现在发行-</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">代理商：</div>
			<div class="control">
				<select name="proxy_id" id="proxy_id" disabled="disabled">
					<option value="0">-请选择代理商-</option>
					<?php if($aProxyList){
						foreach($aProxyList as $aProxyInfo){
							echo '<option value="'.$aProxyInfo['id'].'">'.$aProxyInfo['name'].'</option>';
						}
					}?>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<a class="button" id="submitButton"/>发布</a>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>

<script type="text/javascript">
<?php echo $validateAddAnnouncementJs; ?>

function getProxy(release){
	if(release == 1){
		document.getElementById('proxy_id').disabled = '';
	}else{
		$('#proxy_id').val(0);
		document.getElementById('proxy_id').disabled = 'disabled';
	}
}

function _after_money(){
 	var _money = $.trim($('#money').val());
 	var _arr = _money.split('.')
 	if(_arr.length > 1){
		UBox.show('金额为1到10000之间的正整数',-1);
		$('#money').select();
		return false;
 	 }
}


function _after_quantity(){
 	var _quantity = $.trim($('#quantity').val());
 	var _arr = _quantity.split('.')
 	if(_arr.length > 1){
		UBox.show('数量为1到10000之间的正整数',-1);
		$('#quantity').select();
		return false;
 	 }
}


function _after_checkForm(){
	var _is_release = parseInt($('#is_release').val());
	var _proxy_id = parseInt($('#proxy_id').val());
	if(_is_release == 1){
		if(!_proxy_id>0){
			UBox.show('请指定代理商后发行',-1);
			return false;
		}
	}
}


$("#submitButton").bind("click", formSubmit);

function formSubmit(){
	if(checkForm() === true){
		var oUBox = null;
		$.ajax({
			type : 'post',
			url : '?m=Card&a=ubCardAdd',
			data : $('form').serialize(),
			beforeSend:function(){
				oUBox = UBox.show('处理中...', 1, '', 9999);
				oUBox.unbind('click');
				$("#submitButton").attr('style', 'background-color:#ccc').unbind('click', formSubmit);
			},
			complex : function(){
				oUBox.remove();
				$("#submitButton").attr('style', '').bind('click', formSubmit);
			},
			success : function(result){
				UBox.show(result.msg, result.status, result.data);
			},
			error : function(aRequest){
				UBox.show(aRequest.responseText, -1);
			}
		});
	}
}
</script>