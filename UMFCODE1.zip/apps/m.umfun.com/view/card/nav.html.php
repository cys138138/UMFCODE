<div class="nav">
	<a <?php if(get('a') == 'showBatchList'){ ?>class="on"<?php } ?> href="?m=Card&a=showBatchList">批次列表</a>
	<a <?php if(get('a') == 'showUbCardList'){ ?>class="on"<?php } ?> href="?m=Card&a=showUbCardList">UB卡列表</a>
	<a <?php if(get('a') == 'showMonthCardList'){ ?>class="on"<?php } ?> href="?m=Card&a=showMonthCardList">月费卡列表</a>
	<a <?php if(get('a') == 'showUbCardAdd'){  ?>class="on"<?php } ?> href="?m=Card&a=showUbCardAdd">添加U币卡</a>
	<a <?php if(get('a') == 'showMonthCardAdd'){  ?>class="on"<?php } ?> href="?m=Card&a=showMonthCardAdd">添加月费卡</a>
	<?php if(str_replace('\\', '', get('a')) == 'showBatchRelease'){echo '<a class="on">批量发行</a>';}?>
	<?php if(get('a') == 'showUbCardRelease'){echo '<a class="on">UB充值卡发行</a>';}?>
	<?php if(get('a') == 'showMonthCardRelease'){echo '<a class="on">月费充值卡发行</a>';}?>
</div>

<div class="br"></div>
