<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('card/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>

	<form>
		<div class="item">
			<div class="name">卡号：</div>
			<div class="control"><input type="text" name="card_id" id="card_id" value="<?php if($cardId){echo $cardId;}?>" /></div>
			<div class="name">批次：</div>
			<div class="control"><input type="text" name="batch_id" id="batch_id" value="<?php if($batchId){echo $batchId;}?>" /></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="cardSearch(1);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">金额：</div>
			<div class="control"><input type="text" name="money" id="money" value="<?php if($money){echo $money;}?>"/></div>
			<div class="name width80">过期时间：</div>
			<div class="control"><input type="text" name="over_time" id="over_time" value="<?php if($overTime){echo $overTime;}?>" onclick="WdatePicker({dateFmt:'yyyy-MM-dd'})" /></div>
			<div class="name width80">创建时间：</div>
			<div class="control"><input type="text" name="create_time" id="create_time" value="<?php if($createTime){echo $createTime;}?>" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">发行状态：</div>
			<div class="control">
				<select name="is_release" id="is_release">
					<option value="">请选择</option>
					<option value="0" <?php if($isRelease=== '0'){echo 'selected="selected"';}?> >未发行</option>
					<option value="1" <?php if($isRelease == '1'){echo 'selected="selected"';}?>>己发行</option>
				</select>
			</div>
			<div class="name width80">充值状态：</div>
			<div class="control">
				<select name="is_payed" id="is_payed">
					<option value="">请选择</option>
					<option value="0" <?php if($isPayed == '0'){echo 'selected="selected"';}?> >未充值</option>
					<option value="1" <?php if($isPayed == '1'){echo 'selected="selected"';}?> >己充值</option>

				</select>
			</div>
			<div class="name width80">回收状态：</div>
			<div class="control">
				<select name="is_recycle" id="is_recycle">
					<option value="">请选择</option>
					<option value="0" <?php if($isRecycle == '0'){echo 'selected="selected"';}?>>未回收</option>
					<option value="1" <?php if($isRecycle == '1'){echo 'selected="selected"';}?>>己回收</option>
				</select>
			</div>
			<div class="name width80">代理商：</div>
			<div class="control">
				<select name="proxy_id" id="proxy_id">
					<option value="">请选择</option>
					<?php if($proxyList){
						foreach($proxyList as $proxyKey=> $proxyInfo){
							if($proxyId == $proxyInfo['id']){
								 echo '<option selected="selected" value='.$proxyInfo['id'].'>'.$proxyInfo['name'].'</option>';
							}else{
								echo '<option value='.$proxyInfo['id'].'>'.$proxyInfo['name'].'</option>';
							}
						}
					}?>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="cardSearch(2);">筛选</a>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
 		._userList .list .c1{width:200px;}
		._userList .list .c2{width:100px;}
		._userList .list .c3{width:60px;}
		._userList .list .c4{width:100px;}
		._userList .list .c5{width:65px;}
		._userList .list .c6{width:65px;}
		._userList .list .c7{width:65px;}
		._userList .list .c8{width:80px;}
		._userList .list .c9{width:120px;}
		._userList .list .row .recycle{color:red}
	</style>
	<div class="title">UB卡列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">卡号</div>
			<div class="c2">批次</div>
			<div class="c3">金额</div>
			<div class="c4">代理商</div>
			<div class="c5">是否发行</div>
			<div class="c6">是否充值</div>
			<div class="c7">是否回收</div>
			<div class="c8">过期时间</div>
			<div class="c9">创建时间</div>
		</div>
		<?php if($aCardList){
			foreach($aCardList as $aCardInfo){ ?>
			<div class="row">
				<div class="c1"><?php echo $aCardInfo['card_id'] . $aCardInfo['password']; ?></div>
				<div class="c2"><?php echo $aCardInfo['batch_id'] ? '<a href="/?m=Card&a=showUbCardList&batchId='.$aCardInfo['batch_id'].'">'. $aCardInfo['batch_id'] . '</a>' : '&nbsp;'; ?></div>
				<div class="c3"><?php echo $aCardInfo['money'] ? $aCardInfo['money'] : '&nbsp;'; ?></div>
				<div class="c4"><?php echo $aCardInfo['proxyName'] ? '<a href="/?m=Card&a=showUbCardList&proxyId=' . $aCardInfo['proxy_id'].'">' . $aCardInfo['proxyName'] . '</a>' : '未指定'; ?></div>
				<div class="c5"><?php echo $aCardInfo['is_release'] == 1 ? '<a>己发行</a>' : '未发行'; ?></div>
				<div class="c6"><?php echo $aCardInfo['is_payed'] == 1? '<span class="recycle">己充值</span>' : '未充值'; ?></div>
				<div class="c7"><?php echo $aCardInfo['is_recycle'] == 1 ? '<span class="recycle">己回收</span>' : '未回收'; ?></div>
				<div class="c8"><?php echo date('Y-m-d', $aCardInfo['over_time']); ?></div>
				<div class="c9"><?php echo date('Y-m-d H:i:s', $aCardInfo['create_time']); ?></div>
			</div>
		<?php }
		}else{
			echo '<font color=red>抱歉，暂时缺乏数据！</font>';
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
function cardSearch(type){
	var url = '?m=Card&a=showUbCardList';
	if(type == 1){
		var cardId = $.trim($('#card_id').val());
		if(cardId){
			var cardReg = /^[0-9A-Z]{20}$/;
			if(!cardReg.test(cardId)){
				UBox.show('卡号为20位数字和大写字母组合', -1);
				$('#card_id').select();
				return false;
			}
			url += '&cardId=' + cardId;
		}

		var batchId = $.trim($('#batch_id').val());
		if(batchId){
			var batchReg = /^\d{10}$/;
			if(!batchReg.test(batchId)){
				UBox.show('批次为10位正整数', -1);
				$('#batch_id').select();
				return false;
			}
			url += '&batchId=' + batchId;
		}
		location.href = url;
	}else if(type == 2){
		var money = $.trim($('#money').val());
		if(money){
			var moneyReg = /^[1-9]{1}\d{0,4}$/;
			if(!moneyReg.test(money)){
				UBox.show('金额为1到10000的正整数', -1);
				$('#money').select();
				return false;
			}
			money = parseInt(money);
			if(money < 1 || money > 10000){
				UBox.show('金额为1到10000的正整数', -1);
				$('#money').select();
				return false;
			}
			url += '&money=' + money;
		}

		var overTime = $('#over_time').val();
		if(overTime){
			url += '&overTime=' + overTime;
		}

		var createTime = $('#create_time').val();
		if(createTime){
			url += '&createTime=' + createTime;
		}

		var isRelease = $('#is_release').val();
		if(isRelease == '0' || isRelease == '1'){
			url += '&isRelease=' + isRelease;
		}

		var isPayed = $('#is_payed').val();
		if(isPayed == '0' || isPayed == '1'){
			url += '&isPayed=' + isPayed;
		}

		var isRecycle = $('#is_recycle').val();
		if(isRecycle == '0' || isRecycle == '1'){
			url += '&isRecycle=' + isRecycle;
		}

		var proxyId = $('#proxy_id').val();
		if(proxyId > 0){
			url += '&proxyId=' + proxyId;
		}

		location.href = url;
	}
}
</script>