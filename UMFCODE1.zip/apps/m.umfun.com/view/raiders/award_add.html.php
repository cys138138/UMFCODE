<?php display('raiders/nav.html.php'); ?>

<style type="text/css">
	._main .name{width: 100px;}
	.tips{font-style:normal;color: red;}
	.button{border: none;  display:inline; margin-right:10px;}
	.fl{float: left;}
	.nofloat{float: none;}
</style>

<div class="module _main">
	<form id="awardAdd" class="addForm">
	<div class="title">新增奖品</div>
	
	<div class="item">
		<div class="name">用户ID：</div>
		<div class="control"><input type="text" name="userId" id="userId"/><i id="userTips" class="tips"></i></div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">奖品：</div>
		<div class="control">
			<select name="prizesId" id="prizesId">
				<option value="-1">-请选择-</option>
				<?php foreach($aPrizeList as $key => $aPrizeInfo){
					echo '<option value="' . $aPrizeInfo['id'] . '">' . $aPrizeInfo['name'] . '</option>';
				}?>
				
			</select>
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">收奖人姓名：</div>
		<div class="control"><input type="text" name="toName" id="toName"/></div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">收奖人电话：</div>
		<div class="control"><input type="text" name="toPhone" id="toPhone"/></div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">收奖人地址：</div>
		<div class="control"><input type="text" name="toAddress" id="toAddress" style="width:400px;"/></div>
	</div>
	<div class="clear"></div>


	<div class="item">
		<div class="name">快递公司：</div>
		<div class="control">
			<select name="expresNameId" id="expresNameId">
				<?php
					foreach($aExpress as $key => $expresName){
						echo '<option value="' . $key . '">' . $expresName . '</option>';
					}
				?>
				
			</select>
		</div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">快递单号：</div>
		<div class="control"><input type="text" name="expresId" id="expresId"/></div>
	</div>
	<div class="clear"></div>
	

	<div class="item nofloat">
		<div class="name"></div>
		<div class="control">
			<button type="button" class="button fl" onclick="addAward(0, this);" />保存</button>
			<button type="button" class="button" onclick="addAward(1, this);" />保存并继续</button>
		</div>
	</div>
	<div class="clear"></div>
	<input type="hidden" name="type" value="1"/>
	</form>
</div>
<script type="text/javascript">
	$(function(){
		$('#userId').blur(function(){
			$.get('/?m=Raiders&a=checkUser&user_id=' + $(this).val(), function(aResult){
				var aInfo = aResult.data;
				if(aResult.status != 1){
					$('#userTips').text('不存在该用户，请核对');
				}else{
					$('#userTips').text('');
					$('#toName').val(aInfo.name);
					$('#toPhone').val(aInfo.call_phone);
					$('#toAddress').val(aInfo.province_name + aInfo.city_name + aInfo.area_name);
				}
			});
		});
	});
	
	function checkFrom(){
		
		if(!$('#userId').val() || $('#userId').val().length < 5){
			UBox.show('用户ID不正确', -1);
			return false;
		}

		if($('#prizesId').val() == -1){
			UBox.show('请选择奖品', -1);
			return false;
		}

		if($('#toPhone').val().length < 7 || !$('#toPhone').val()){
			UBox.show('收货人电话不正确', -1);
			return false;
		} 

		if(!$('#toName').val() || !$('#toAddress').val()){
			UBox.show('请仔细填写收货人信息', -1);
			return false;
		}

		if($('#expresNameId').val() == 0){
			UBox.show('请选择快递公司', -1);
			return false;
		}

		if(!$('#expresId').val()){
			UBox.show('请填写快递单号', -1);
			return false;
		}
		return true;
	}
	
	function addAward(types, obj){
		if(!checkFrom()){
			return;
		}

		var $this = $(obj);
		ajax({
			url: '/?m=Raiders&a=saveAward',
			data: $('#awardAdd').serialize(),
			beforeSend: function(){
				$('.button').attr('onclick', '');
				$this.addClass('button_loading').html('处理中...');
			},
			complete:function(){
				if(types == 1){
					$this.removeClass('button_loading').html('保存并继续');
				}else{
					$this.removeClass('button_loading').html('保存');
				}
			},
			success: function(aResult){
				if(aResult.status == 1){
					if(types != 1){
						UBox.show(aResult.msg, 1, '/?m=Raiders&a=showAwardList');
					}else{
						UBox.show(aResult.msg, 1, '/?m=Raiders&a=showAddAward');
					}
					
				}else{
					$('.button').attr('onclick', 'addAward(1, this);');
					$('.button.fl').attr('onclick', 'addAward(0, this);');
					UBox.show(aResult.msg, -1);
				}
			}
		});
	}
</script>