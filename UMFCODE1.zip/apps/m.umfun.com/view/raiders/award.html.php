<?php display('raiders/nav.html.php'); ?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:30px;}
	.list .c2{width:120px;}
	.list .c3{width:50px;}
	.list .c4{width:150px;}
	.list .c5{width:150px;}
	.list .c6{width:100px;}
	.list .c7{width:120px;}
	.list .c8{width:400px;}
	.list .c9{width:120px;}
	.list .c10{width:60px;}
	.right{float:right;}
	.button{border: none;}
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			发货列表
			<button class="right button" onclick="location.href='/?m=Raiders&a=showAddAward'">+ 增 加 </button>
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">用户名(ID)</div>
			<div class="c3">奖品ID</div>
			<div class="c4">奖品名</div>
			<div class="c5">获奖时间</div>
			<div class="c6">收货人姓名</div>
			<div class="c7">收货人手机号</div>
			<div class="c8">收货人联系地址</div>
			<div class="c9">快递公司</div>
			<div class="c10 right">操作</div>
		</div>

		<?php if(!empty($aAwardList)){
			foreach($aAwardList as $key => $aAwardInfo){?>
				<div class="row">
					<div class="c1"><?php echo $aAwardInfo['id'];?></div>
					<?php
						$aUserInfo = $aAwardInfo['user_info'];
						$aPrizeInfo = $aAwardInfo['prize_info'];
						if($aUserInfo){
							$name = $aUserInfo['name'] . '(' . $aUserInfo['id'] . ')';
						}else{
							$name = '<span style="color:red;">错误的用户ID</span>';
						}
					?>
					<div class="c2" title="<?php echo $name; ?>">
						<?php echo $name; ?>
					</div>
					<div class="c3"><?php echo $aAwardInfo['prize_id'];?></div>
					<div class="c4"><?php echo $aPrizeInfo['name'];?></div>
					<div class="c5"><?php echo date('Y-m-d H:i:s', $aAwardInfo['create_time']);?></div>
					<div class="c6"><?php echo $aAwardInfo['user_name'];?></div>
					<div class="c7"><?php echo $aAwardInfo['user_number'];?></div>
					<div class="c8" title="<?php echo $aAwardInfo['user_address'];?>"><?php echo $aAwardInfo['user_address'];?></div>
					<div class="c9" title="<?php echo $aAwardInfo['express_info'];?>"><?php echo $aAwardInfo['express_info'];?></div>
					<div class="c10 right">
						<a href="javascript:void(0);" onclick="location.href='/?m=Raiders&a=showEditAward&id=<?php echo $aAwardInfo['id'];?>';" class="checkOff">修改</a>
						<!---a href="javascript:void(0);" onclick="deletes(<?php echo $aAwardInfo['id'];?>, this);" class="checkOn">删除</a--->
					</div>
				</div>
		<?php }
		}else{
			echo '<div class="row">很抱歉，尚无数据</div>';
		}?>

		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>

<script type="text/javascript">
	$(function(){
		$('.row:odd').css('background-color', '#F0F0F0');
	});

	function deletes(id, obj){
		UBox.confirm('您确定要删除该发货信息么？', function(){
			$.ajax({
				url : '/?m=Raiders&a=delPrizes',
				type : 'post',
				data : {id : id},
				success : function(aResult){
					if(aResult.status == 1){
						UBox.show('删除成功', 1);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(error){
					UBox.show('系统错误', 0);
				}
			});
		});
	}
</script>