<?php display('raiders/nav.html.php'); ?>

<style type="text/css">
	._main .name{width: 100px;}
	#userTips{font-style:normal;color: red;}
</style>

<div class="module _main">
	<form id="editAward" class="addForm">
	<div class="title">修改发货列表</div>

	<div class="item">
		<div class="name">用户ID：</div>
		<div class="control"><input type="text" name="userId" id="userId" value="<?php echo $aAwardInfo['user_id'];?>"/><i id="userTips"></i></div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">奖品ID：</div>
		<div class="control">
			<select name="prizesId" id="prizesId">
				<option value="-1">-请选择-</option>
				<?php foreach($aPrizeList as $key => $aPrizeInfo){
					$selectAttr = $aAwardInfo['prize_id'] == $aPrizeInfo['id'] ? 'selected' : '';
					echo '<option value="' . $aPrizeInfo['id'] . '" ' . $selectAttr . '>' . $aPrizeInfo['name'] . '</option>';
				}?>

			</select>
		</div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">收奖人姓名：</div>
		<div class="control"><input type="text" name="toName" value="<?php echo $aAwardInfo['user_name'];?>" id="toName"/></div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">收奖人电话：</div>
		<div class="control"><input type="text" name="toPhone" value="<?php echo $aAwardInfo['user_number'];?>" id="toPhone"/></div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">收奖人地址：</div>
		<div class="control"><input type="text" name="toAddress" value="<?php echo $aAwardInfo['user_address'];?>" id="toAddress" style="width:400px;"/></div>
	</div>
	<div class="clear"></div>


	<div class="item">
		<div class="name">快递公司：</div>
		<div class="control">
			<select name="expresNameId" id="expresNameId">
				<?php
					if($aAwardInfo['express_info']){
						$aExpresInfo = explode(',', $aAwardInfo['express_info']);
					}else{
						$aExpresInfo = array(0 => '', 1 => '');
					}
					foreach($aExpress as $key => $expresName){
						$expresSelectAttr = $aExpresInfo[0] == $key ? 'selected' : '';
						echo '<option value="' . $key . '" ' . $expresSelectAttr . '>' . $expresName . '</option>';
					}
				?>

			</select>
		</div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">快递单号：</div>
		<div class="control"><input type="text" name="expresId" value="<?php echo $aExpresInfo[1];?>" id="expresId"/></div>
	</div>
	<div class="clear"></div>


	<div class="item">
		<div class="name"></div>
		<div class="control"><a class="button" id="submitButton" onclick="updateAward();" />修改发货信息</a></div>
	</div>
	<div class="clear"></div>
	<input type="hidden" name="id" value="<?php echo $aAwardInfo['id'];?>"/>
	<input type="hidden" name="type" value="2"/>
	</form>
</div>

<script type="text/javascript">
		$(function(){
		$('#userId').keyup(function(){
			$.get('/?m=Raiders&a=checkUser&user_id=' + $(this).val(), function(aResult){
				if(aResult.status != 1){
					$('#userTips').text('不存在该用户，请核对');
				}else{
					$('#userTips').text('');
				}
			});
		});
	});

	function checkFrom(){
		if(!$('#userId').val()){
			UBox.show('用户名不正确', -1);
			return false;
		}

		if($('#prizesId').val() == -1){
			UBox.show('请选择奖品', -1);
			return false;
		}

		if($('#toPhone').val().length < 7 || !$('#toPhone').val()){
			UBox.show('收货人电话不正确', -1);
			return false;
		}

		if(!$('#toName').val() || !$('#toAddress').val()){
			UBox.show('请仔细填写收货人信息', -1);
			return false;
		}

		if($('#expresNameId').val() == 0){
			UBox.show('请选择快递公司', -1);
			return false;
		}

		if(!$('#expresId').val()){
			UBox.show('请填写快递单号', -1);
			return false;
		}
		return true;
	}

	function updateAward(){
		if(checkFrom()){
			$.ajax({
				url: '/?m=Raiders&a=saveAward',
				data: $('#editAward').serialize(),
				type: 'post',
				dataType: 'json',
				beforeSend: function(){
					$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
				},
				complete:function(){
					$('#submitButton').attr('onclick', 'updateAward()').removeClass('button_loading').html('修改发货信息');
				},
				success: function(aResult){
					if(aResult.status == 1){
						UBox.show(aResult.msg, 1, '/?m=Raiders&a=showAwardList');
					}else{
						UBox.show(aResult.msg, -1);
					}
				},
				error: function(){
					UBox.show('系统错误', 0);
				}
			});
		}
	}
</script>