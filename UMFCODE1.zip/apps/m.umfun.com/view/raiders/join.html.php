<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<?php display('raiders/nav.html.php'); ?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:300px;}
	.list .c3{width:150px;}
	.list .c4{width:150px;}
	.list .c6{width:100px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:600px; overflow: hidden;}
	.right{float:right;}
	.button{border: none;}
	.maximg{max-width:100%;}
	.search{margin-left: 1%; margin-bottom: 20px; border: 1px #ccc solid; width: 60%; height: 133px;	}
	.search .option{ margin-top: 2%; margin-left: 10px;}
	.head div{line-height: 30px; margin-left: 1px;}
	.option span{ margin-right: 1%;}
	.C_search .sumbit{ display:inline-block; height:25px; width: 30px;  text-align: center; line-height:28px; font-size:12px; font-weight:bold;  padding:0px 20px 0px 20px; color:#FFCC00; background-color:#333333; cursor:pointer;}
	.C_search .sumbit:hover{text-decoration:none; color:#FFCC00;}
	.C_search .sumbit:active{color:#FFCC00; background-color:#000000;}
	/*.sumbit{ width: 50px; height: 25px; background: #EB8744; border-radius:3px; display: inline-block; text-align: center; line-height: 25px; cursor: pointer; color: #FFF; box-shadow: 1px 1px 3px #ddd;font-family: Microsoft YaHei,sans-serif;}*/
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			争分夺宝活动列表
			<button class="right button" onclick="location.href = '/?m=Raiders&a=showAddPrizes'">+ 增 加 </button>
		</div>
		<div class="search head">
			<div class="option">
				<form class="C_search" id="C_search">
					<span>
						<lable>用户类型 ：</lable>
						<select name="userType" id="C_type">
							<option value="0">全部</option>
							<option value="1" <?php
							$userType = intval(get('userType'));
							if ($userType == 1) {
								echo 'selected="selected"';
							};
							?>>老师</option>
							<option value="2" <?php
							if ($userType == 2) {
								echo 'selected="selected"';
							};
							?>>学生</option>
							<option value="3" <?php
							if ($userType == 3) {
								echo 'selected="selected"';
							};
							?>>家长</option>
						</select>
					</span>
					<span>
						<lable>是否获奖 ：</lable>
						<select name="isPrize">
							<option value="-1">全部</option>
							<option value="1" <?php
							$isPrize = intval(get('isPrize'));
							if($isPrize == 1){
								echo 'selected="selected"';
							}?>>是</option>
							<option value="0" <?php
							if($isPrize == 0){
								echo 'selected="selected"';
							}
							?>>否</option>
						</select>
					</span>
					<span>
						<lable>幸运剩余抽奖次数 ：</lable>
						<select name="luckTimes" id="C_type">
							<option value="-1">全部</option>
							<?php
							for($i=0;$i<=5;$i++){
								$html = '';
								$luckTimes = get('luckTimes');
								if($i == $luckTimes && is_numeric($luckTimes)){
									$html='selected="selected"';
								}
								echo '<option value="'.$i.'" '.$html.'>'.$i.'</option>';
							}
							?>
						</select>
					</span>
					<span>
						<lable>剩余抽奖次数 ：</lable>
						<select name="surplus_times" id="C_type">
							<option value="-1">全部</option>
							<?php
							for($i=0;$i<=6;$i++){
								$html = '';
								$surplus_times = get('surplus_times');
								if($i == $surplus_times && is_numeric($surplus_times)){
									$html='selected="selected"';
								}
								echo '<option value="'.$i.'" '.$html.'>'.$i.'</option>';
							}
							?>
						</select>
					</span>
					<div style="height:10px;"></div>

					<span>
						<span>开始时间:</span>
						<input type="text" name="startTime" id="startTime"  value="<?php $startTime = get('startTime'); if($startTime){echo $startTime;}?>" class="Wdate" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:00:00'})" />
					</span>
					<span>
						<span>结束时间:</span>
						<input type="text" name="endTime" id="endTime"  value="<?php $endTime = get('endTime');if($endTime){echo $endTime;}?>" class="Wdate" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:00:00'})" />
					</span>

					<span>
						<lable class="sumbit" id="C_submit">查找</lable>
					</span>
				</form>
			</div>
		</div>
		<div class="head">
			<div>参与人数:<b style="padding-left:15px;"><?php if ($aJoinList) { echo $joinCount;}else{ echo '0';} ?></b></div>
		</div>
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c6">参与用户</div>
			<div class="c6">参与用户类型</div>
			<div class="c4">闯关</div>
			<div class="c6">是否得奖</div>
			<div class="c4">参与时间</div>
			<div class="c6">剩余抽奖次数</div>
			<div class="c6">剩余参与次数</div>
			<div class="c6">操作</div>


		</div>

		<?php if (!empty($aJoinList)) {
			foreach ($aJoinList as $key => $aJoinInfo) {
				?>
				<div class="row" id="row_<?php echo $aJoinInfo['id']; ?>">
					<div class="c1"><?php echo $aJoinInfo['id']; ?></div>
					<div class="c6"><?php echo $aJoinInfo['user_name']; ?></div>
					<div class="c6"><?php
						if ($aJoinInfo['user_type'] == 1) {
							echo '老师';
						} else if ($aJoinInfo['user_type'] == 2) {
							echo '学生';
						} else {
							echo '家长';
						}
						?>
					</div>
					<div class="c4"><?php
					if($aJoinInfo['mission_start_time']) {
							echo date('Y-m-d H:i:s', $aJoinInfo['mission_start_time']);
						}else{
							echo '<b style="color:red;">没玩过</b>';
						}?></div>
					<div class="c6"><?php
					if($aJoinInfo['award_time']) {
							echo date('Y-m-d H:i:s', $aJoinInfo['award_time']);
						}else{
							echo '无';
						}?></div>
					<div class="c4"><?php echo date('Y-m-d H:i:s', $aJoinInfo['create_time']) ?></div>
					<div class="c6"><?php echo $aJoinInfo['luck_times']; ?></div>
					<div class="c6"><?php echo $aJoinInfo['surplus_times'] ?></div>
					<div class="c6"><a href="javascript:void(0);" onclick="deletes(<?php echo $aJoinInfo['id'];?>);" class="checkOn">删除</a></div>
				</div>
			<?php
			}
		} else {
			echo '<div class="row">很抱歉，尚无数据</div>';
		}
		?>

		<div class="row footer">
<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>

<script type="text/javascript">
	$(function () {
		$('.row:odd').css('background-color', '#F0F0F0');
		$('#C_submit').click(function () {
			var url = $('#C_search').serialize();
			location.href = '/?m=Raiders&a=showJoinList&' + url;

		});
	});
	function deletes(id) {
		UBox.confirm('您确定要删除该夺宝信息？', function () {
			$.ajax({
				url: '/?m=Raiders&a=delJoins',
				type: 'post',
				data: {id: id},
				success: function (aResult) {
					if (aResult.status == 1) {
						UBox.show('删除成功', 1);
						$('#row_' + id).remove();
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error: function (error) {
					UBox.show('系统错误', 0);
				}
			});
		});

	}
</script>