<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<?php display('raiders/nav.html.php'); ?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:300px;}
	.list .c3{width:150px;}
	.list .c4{width:150px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:600px; overflow: hidden;}
	.right{float:right;}
	.button{border: none;}
	.maximg{max-width:100%;}
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			奖品列表
			<button class="right button" onclick="location.href='/?m=Raiders&a=showAddPrizes'">+ 增 加 </button>
		</div>
		
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">奖品名称</div>
			<div class="c3">库存</div>
			<div class="c3">奖品等级</div>
			<div class="c5">奖品图片</div>
			<div class="c4 right">操作</div>
		</div>
		
		<?php if(!empty($aPrizeList)){
			foreach($aPrizeList as $key => $aPrizeInfo){?>
				<div class="row" id="row_<?php echo $aPrizeInfo['id']; ?>">
					<div class="c1"><?php echo $aPrizeInfo['id']; ?></div>
					<div class="c2"><?php echo $aPrizeInfo['name']; ?></div>
					<div class="c3"><?php echo $aPrizeInfo['surplus']; ?></div>
					<div class="c3"><?php echo $aGoods[$aPrizeInfo['level']]; ?></div>
					<div class="c5" onclick="lookImages('<?php echo  SYSTEM_RESOURCE_URL . $aPrizeInfo['image']; ?>');">点击查看</div>
					<div class="c4 right">
						<a href="javascript:void(0);" onclick="location.href='/?m=Raiders&a=showEditPrizes&id=<?php echo $aPrizeInfo['id']; ?>';" class="checkOff">修改</a>
						<a href="javascript:void(0);" onclick="deletes(<?php echo $aPrizeInfo['id']; ?>);" class="checkOn">删除</a>
					</div>
				</div>
		<?php }
		}else{
			echo '<div class="row">很抱歉，尚无数据</div>';
		}?>
		
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>

<script type="text/javascript">
	$(function(){
		$('.row:odd').css('background-color', '#F0F0F0');
	});

	function lookImages(imgSrc){
		popEasyDialog({
			title : '查看图片',
			width : 980,
			height : 600,
			content : '<div id="wrapPreview" style="height:600px; overflow-y:scroll;"><img class="maximg" src="' + imgSrc + '?t=' + Math.random() + '"/></div>',
			confirmCallBack : $.noop
		});
	}

	function deletes(id){
		UBox.confirm('您确定要删除该奖品么？', function(){
			$.ajax({
				url : '/?m=Raiders&a=delPrizes',
				type : 'post',
				data : {id : id},
				success : function(aResult){
					if(aResult.status == 1){
						UBox.show('删除成功', 1);
						$('#row_' + id).remove();
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(error){
					UBox.show('系统错误', 0);
				}
			});
		});
		
	}
</script>