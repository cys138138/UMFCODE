<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_ajaxupload']; ?>"></script>
<?php display('raiders/nav.html.php'); ?>

<style type="text/css">
	._main .name{width: 100px;}
	._main .good_name{width:400px;}
	._main .up-img{width:580px; position:relative;overflow:visible}
	._main .up-img .up-img-del{border:1px solid #ccc;position:absolute; left:550px;top:-38px;display:none}
	._main .up-img .up-img-btndel{position:absolute;right:-3px;top:-17px;}
	._main .up-img .images{width:300px;}
	._main .hide{overflow:hidden;}
</style>

<div class="module _main">
	<form id="goodsAdd" class="addForm">
		<div class="addForm">
			<div class="title">新增奖品</div>
			
			<div class="item">
				<div class="name">奖品名称：</div>
				<div class="control"><input type="text" name="good_name" id="good_name" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item up-img">
				<div class="name">奖品图片：</div>
				<div class="control" class="hide">
					<input type="file" name="imgUpload" id="imgUpload"/>
				</div>
				<div class="up-img-del" id="profile_main">
					<a href="javascript:void(0)" onclick="javascript:deleteImage()" title="删除" class="up-img-btndel">删除</a>
					<img id="profileImg" class="images"/>
				</div>
				<input type="hidden" name="good_profile" id="good_profile"/>
			</div>
			
			<div class="clear"></div>
			
			<div class="item up-img">
				<div class="name">高清图集：</div>
				<div class="control" class="hide">
					<input type="file" name="imgUploadSrc" id="imgUploadSrc"   style=" width: 76px; border: 0px;"/>
				</div>
				<div class="clear"></div>
				
				<div class="control" class="hide" id="imgBox" style=" padding-left: 40px; " ></div>
				<div  name="good_profile_atlas" id="goodProfileAtlas" style=" display: none;" ></div>
			</div>
			
			<div class="clear"></div>			

			<div class="item">
				<div class="name">奖品等级：</div>
				<div class="control">
					<select name="good_level" id="good_level">
						<option value="-1">-请选择-</option>
						<option value="1">一等奖</option>
						<option value="2">二等奖</option>
						<option value="3">三等奖</option>
						<option value="4">幸运奖</option>

					</select>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">物品库存：</div>
				<div class="control"><input type="text" name="good_stock" id="good_stock" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">物品总库存：</div>
				<div class="control"><input type="text" name="good_total" id="good_total" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name"></div>
				<div class="control"><a class="button" id="submitButton" onclick="addGoods();" />添加奖品</a></div>
			</div>
			<div class="clear"></div>
		</div>
	</form>
</div>
<script type="text/javascript">
	var aSrc = '';
	var aMapPath = [];
	$(function(){
		
		$('#imgUpload').AjaxUpload({
			text : '选择图片',
			fileKey : 'good_profile',
			uploadUrl : 'http://<?php echo APP_MANAGE ?>/?m=Raiders&a=uploadProfile&ajax=1',
			callback : function(aResult){
				if(aResult.status == 1){
					$('#profileImg').attr('src', aResult.data);
					$('#good_profile').val(aResult.msg);
					$('#profile_main').show(300);
				}else{
					$('#profile_main').hide();
					UBox.show(aResult.msg, -1);
				}
			}
		});
		
		$('#imgUploadSrc').AjaxUpload({
			text : '选择图片',
			fileKey : 'goodProfileAtlas',
			uploadUrl : 'http://<?php echo APP_MANAGE ?>/?m=Raiders&a=uploadProfile&ajax=1',
			callback : function(aResult){
				if(aResult.status == 1){
					//$('#profileImg').attr('src', aResult.data);
					var  aMap = aResult.data;
						$('#imgBox').html(
							 aSrc += '<img src="' + aMap + '" width=100 heighe=100 style="margin: 3px;">'
						);
				
						$('#goodProfileAtlas').html(
							 aMapPath += '<input type="text"name="map_path_list[]" value="' + aResult.msg + '"/>'
						);
				}else{
					UBox.show(aResult.msg, -1);
				}
			}
		});
	});
	
	function checkFrom(){
		if(!$('#good_name').val()){
			UBox.show('奖品名不能为空', -1);
			return false;
		}

		if(!$('#good_profile').val()){
			UBox.show('请上传图片', -1);
			return false;
		}

		if($('#good_level').val() == -1){
			UBox.show('请选择奖品等级', -1);
			return false;
		}

		if(!$('#good_stock').val()){
			UBox.show('请填写库存', -1);
			return false;
		}

		if(!$.isNumeric($('#good_stock').val())){
			UBox.show('库存必须为正整数', -1);
			return false;
		}
		return true;
	}

	function deleteImage(){
		$('#profile_main').hide();
		$('#good_profile').val('');
		$('#profileImg').attr('src', '');
	}

	function addGoods(){
		
		
		if(!checkFrom()){
			return;
		}
		
		ajax({
			url: '/?m=Raiders&a=savePrizes',
			data: $('#goodsAdd').serialize(),
			beforeSend: function(){
				$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
			},
			complete:function(){
				$('#submitButton').attr('onclick', 'addGoods()').removeClass('button_loading').html('添加奖品');
			},
			success: function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1, '/?m=Raiders&a=showPrizesList');
				}else{
					UBox.show(aResult.msg, -1);
				}
			}
		});
	}
</script>