<div class="nav">
	<a <?php if(get('a') == 'showPrizesList'){ ?>class="on"<?php } ?> href="?m=Raiders&a=showPrizesList">奖品列表管理</a>
	<a <?php if(get('a') == 'showAwardList'){ ?>class="on"<?php } ?> href="?m=Raiders&a=showAwardList">奖品发货管理</a>
	<a <?php if(get('a') == 'showJoinList'){ ?>class="on"<?php } ?> href="?m=Raiders&a=showJoinList">争分夺宝活动管理</a>
	
	<?php if(get('a') == 'showAddPrizes'){ echo '<a class="on" href="?m=Raiders&a=showAddPrizes">增加奖品</a>'; } ?>
	<?php if(get('a') == 'showAddAward'){ echo '<a class="on" href="?m=Raiders&a=showAddAward">增加发货信息</a>'; } ?>

	<?php if(get('a') == 'editPrizes'){ echo '<a class="on" href="?m=Raiders&a=editPrizes&id=' . get('id') . '">修改奖品</a>'; } ?>
	<?php if(get('a') == 'editAward'){ echo '<a class="on" href="?m=Raiders&a=editAward&id=' . get('id') . '">修改发货信息</a>'; } ?>
</div>
<div class="br"></div>