<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>

<?php display('match/nav.html.php'); ?>

<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		
		._subject span{margin-right:15px; display:inline-block;}
		._main .item .radio_div{margin-left:15px;margin-right: 5px;}
		
	</style>
	<form id="matchtEditTopic" class="addForm" autocomplete="off">
		<div class="title">选题</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">是否发布：</div>
			<div class="control">
				<select name="is_release" id="is_release">
					<option value="-1">请选择</option>
					<option value="1" <?php if($aMatchInfo['is_release'] == 1){echo 'selected="selected"';} ?>>现在发布</option>
					<option value="0" <?php if($aMatchInfo['is_release'] == 0){echo 'selected="selected"';} ?>>以后发布</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>	

		<div class="item" >
			<div class="name">题型设置：</div>
			<div class="control" id="es_type_main">
				<?php 
					$checkTypeStr = '';
					foreach($esTypeArray as $key => $esType){
						$checkedStr = '';	
						$inputVlue = '';
						$disabledStr = 'disabled="disabled"';
						foreach($aMatchInfo['es_rule'] as $esRule){
							if($esRule['es_type_id'] == $key){
								$checkTypeStr .= ',' . $key;
								$checkedStr = 'checked="checked"';
								$inputVlue = $esRule['es_count']; 
								$disabledStr = '';
								break;		
							}
						}
						echo '<input ' . $checkedStr . ' onclick="javascript:checkEsType('.$key.')" id="type_checkbox_'.$key.'" name="type_checkbox[]" type="checkbox" value="'.$key.'" style="float:left" /><label id="type_label_'.$key.'"  for="type_checkbox_'.$key.'" style="float:left;padding-right:5px">'.$esType.'</label><input type="text" ' . $disabledStr . ' id="type_input_'.$key.'"  name="type_input_'.$key.'" value="'.$inputVlue.'" style="float:left;width:50px;margin-right:25px" />';
					}
				?>
				<input type="text"  style="display:none" id="hasCheckEsType" name="hasCheckEsType" value="<?php echo $checkTypeStr;?>" />
				
			</div>
		</div>		
		<div class="clear"></div>
		<div class="item" id="category_div" isShow='0' <?php if($aMatchCategory['category_titles'] && $aMatchCategory['category_titles']){echo 'style="display:block"';}else{echo 'style="display:none"';}?>>
			<div class="name">己选择目录：</div>
			<div class="control" id="hasSelectCategory">
			<?php if($aMatchCategory['category_titles']){echo $aMatchCategory['category_titles'];}?>
			<input type="text" style="display:none" id="categoryIds"  name="categoryIds" value="<?php if($aMatchCategory['category_ids']){echo $aMatchCategory['category_ids'];}?>"  />
			</div>
		</div>
		<div class="clear"></div>			
		<div class="item">
			<div class="name">题目选择：</div>
			<div class="control" id="category">
				<?php foreach($aSubjectIdsArray as $aSubjectIdInfo){?>
					<div class="category_main" id="category<?php echo $aSubjectIdInfo?>">
						<script type="text/javascript">
							var oDirTree<?php echo $aSubjectIdInfo ?> = new dTree('oDirTree<?php echo $aSubjectIdInfo ?>', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
							oDirTree<?php echo $aSubjectIdInfo ?>.add(0, -1, '<?php echo $aSubject[$aSubjectIdInfo]; ?>目录');
							var aCategoryList = <?php echo json_encode($aCategoryList[$aSubjectIdInfo]); ?>;
							$(aCategoryList).each(function(){
								var esCount = this.es_count > 0 ? '(' + this.es_count + '题)' : '';
								oDirTree<?php echo $aSubjectIdInfo ?>.add(this.id, this.parent_id, this.name, '#catalogue' + this.id, this.name);
							});
							document.write(oDirTree<?php echo $aSubjectIdInfo ?>);
						</script>
					</div>
				<?php }?>
			</div>
		</div>

		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<a class="button" id="submitButton" onclick="saveTopic()" />发布赛事</a>
			</div>
			<div class="control radio_div" >
				<input type="radio" name="nex_step" id="match_list" checked="checked" /><label for="match_list">保存后去 赛事列表</label>
			</div>
			<div class="control radio_div" >
				<input type="radio" name="nex_step" id="match_basic" /><label for="match_basic">保存后去 基本信息设置</label>
			</div>
			<div class="control radio_div">
				<input type="radio" name="nex_step" id="match_prize"/><label for="match_prize">保存后去 奖项设置</label>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">

//题型选择
function checkEsType(id){
	var _check = document.getElementById('type_checkbox_'+id).checked;
	var hasCheck = $('#hasCheckEsType').val();
	if(_check == true){
		$('#type_input_'+id).attr("disabled", false);
		$('#hasCheckEsType').val(','+id+hasCheck);
	}else{
		$('#type_input_'+id).val('').attr("disabled", true);
		$('#hasCheckEsType').val(hasCheck.replace(','+id, ''));
	}
}


						
//没验完的都验完
function checkTopic(){
	var isRelease = $('#is_release').val();
	if(isRelease != '0' && isRelease != '1'){
		UBox.show('请选择发布状态', -1);
		return false;
	}

	var hasCheckEsType = $('#hasCheckEsType').val();
	if(hasCheckEsType == ''){
		UBox.show('请至少选择一种题型', -1);
		return false;
	}

	var checkType = true;
	var numberReg = /^[1-9]{1}\d*$/;
	$('#es_type_main input[type=checkbox]').each(function(){
		_id = $(this).attr('id');
		_val = $(this).val();
		_check = document.getElementById(_id).checked;
		if(_check == true){
			_esCount = $('#type_input_'+_val).val();
			_esName = $('#type_label_'+_val).html();
			if(!numberReg.test(_esCount)){
				checkType = false;
				UBox.show(_esName+'的数量为空或格式错误', -1);
				return false;
			}
		}
	})
	if(checkType == false){
		return false;
	}
	
	var categoryIds = $('#categoryIds').val();
	if(!categoryIds){
		UBox.show('请选择目录', -1);
		return false;
	}
	return true;
}



//选择目录
var selectCategory = $('#categoryIds');
function getCategoryId(oDirTree){
	var categoryId = oDirTree.getSelected();
	var categoryName = oDirTree.getName(categoryId);
	if(!oDirTree.isNoChild(categoryId)){
		UBox.show('请选择一个最终目录', -1);
		return false;
	}
	
	var hasSelected = selectCategory.val();
	var hasSelectedArray = hasSelected.split(',');
	if($.inArray(categoryId + '', hasSelectedArray) != -1){
		UBox.show('您已经添加了这个目录了！', -1);
		return false;
	}
	selectCategory.val(categoryId+','+selectCategory.val());
	$('#hasSelectCategory').append('<label xid='+ categoryId +'>' + categoryName + '<a style="font-size:18px;" onclick="deleteCategory(' + categoryId + ')">×</a>&nbsp;&nbsp;&nbsp;</label>');

	if($('#category_div').attr('isShow') == '0'){
		$('#category_div').show(50).attr('isShow', '1');
	}
}

//删除己选择的目录
function deleteCategory(index){
	selectCategory.val(selectCategory.val().replace(index+',', ''));
	$('label[xid=' + index + ']').remove();

	if(selectCategory.val() == ''){
		$('#category_div').hide(50).attr('isShow', '0');
	}
}


//为每个目录绑定事件
<?php 
	foreach($aSubjectIdsArray as $aSubjectIdInfo){
		if(isset($aCategoryList[$aSubjectIdInfo])){
?>
$(function(){
	for(i = 1; i <= <?php echo count($aCategoryList[$aSubjectIdInfo]); ?>; i++){
		$('#category<?php echo $aSubjectIdInfo;?> #soDirTree<?php echo $aSubjectIdInfo;?>' + i).bind('click', function(){getCategoryId(oDirTree<?php echo $aSubjectIdInfo;?>)});
	}
});
<?php				
		}
	}
?>



//提交表单
function saveTopic(){
		if(checkTopic() == true){
			UBox.confirm('请确认所选择的目录中的题目数量符合输入的数量吗', function(){
				var matchId = <?php echo $aMatchInfo['id']; ?>;
				$.ajax({
					url : '/?m=Match&a=editMatchTopic&id=' + matchId,
					type : 'post',
					dataType : 'json',
					data : $('#matchtEditTopic').serialize(),
					beforeSend: function(){
						$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
					},
					complete:function(){
						$('#submitButton').attr('onclick', 'saveTopic()').removeClass('button_loading').html('发布赛事');
					},
					success : function(aResult){
						if(aResult.status == 1){
							var msg = '操作成功 点击回列表';
							var afterUrl = '/?m=Match&a=showMatchList';
							var after = $('input[type="radio"]:checked').attr('id');
							if(after == 'match_basic'){
								msg = '操作成功 点击进行基本信息设置';
								afterUrl = '/?m=Match&a=showEditMatchBasic&id=' + matchId;
							}else if(after == 'match_prize'){
								msg = '操作成功 点击进行奖项设置';
								afterUrl = '/?m=Match&a=showEditMatchPrize&id=' + matchId;
							}
							UBox.show(msg, 1, afterUrl);
						}else{
							UBox.show(aResult.msg, -1);
						}
					},
					error : function(){
						UBox.show('系统错误', 0);
					}
				});
			});
		}
}


</script>