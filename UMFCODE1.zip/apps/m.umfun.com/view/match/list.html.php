<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<?php display('match/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>

	<form>
		<div class="item">
			<div class="name width80">赛事ID：</div>
			<div class="control"><input type="text" name="matchId" id="matchId" value="<?php if($matchId){echo $matchId;}?>"  /></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="matchSearch(1);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">赛事名称：</div>
			<div class="control"><input type="text" name="matchName" id="matchName" value="<?php if($matchName){echo $matchName;}?>"  /></div>
		</div>
		<div class="clear"></div>
		<div class="item">

			<div class="name width80">开始时间：</div>
			<div class="control"><input type="text" name="startTime" id="startTime"  value="<?php if($startTime){echo $startTime;}?>" class="Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:00:00', minDate:'%y-%M-%d'})" /></div>
			<div class="blank"></div>
			<div class="name width80">结束时间：</div>
			<div class="control"><input type="text" name="endTime" id="endTime" value="<?php if($endTime){echo $endTime;}?>" class="Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:00:00', minDate:'%y-%M-%d'})" /></div>
			<div class="name" style="width:120px;">
				<select id="timeType" name="timeType">
					<option value="-1">-时间范围-</option>
					<option value="1" <?php if($timeType == 1){echo 'selected="selected"';}?>>赛事结束时间</option>
					<option value="2" <?php if($timeType == 2){echo 'selected="selected"';}?> >赛事结束时间</option>
					<option value="3" <?php if($timeType == 3){echo 'selected="selected"';}?>>报名开始时间</option>
					<option value="4" <?php if($timeType == 4){echo 'selected="selected"';}?>>报名结束时间</option>
				</select>
			</div>

		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">赛事时长：</div>
			<div class="control">
				<select id="duration" name="duration">
					<option value="-1">-请选择-</option>
					<?php if(isset($durationArray)){
						foreach($durationArray as $duration){
							echo '<option value="' . $duration . '">-' . $duration . '分钟-</option>';
						}
					}?>
				</select>
			</div>

			<div class="name width80">最小等级：</div>
			<div class="control">
				<select name="limitLevel" id="limitLevel" >
					<option value="-1">请选择</option>
					<?php
						if(isset($levelArray)){
							foreach($levelArray as $key => $level){
								if($limitLevel == $key){
									echo '<option value="' . $key . '" selected="selected">' . $level . '</option>';
								}else{
									echo '<option value="' . $key .'">' . $level . '</option>';
								}
							}
						}
					?>
				</select>
			</div>

			<div class="name width80">参赛年级：</div>
			<div class="control">
				<select name="gradeId" id="gradeId">
					<option value="-1">请选择</option>
					<?php
						foreach($gradeArray as $key => $gradeInfo){
							if($gradeId == $key){
								echo '<option value="' . $key . '" selected="selected">' . $gradeInfo . '</option>';
							}else{
								echo '<option value="' . $key . '">' . $gradeInfo . '</option>';
							}

						}
					?>
				</select>
			</div>
			<div class="name width80">参赛科目：</div>
			<div class="control">
				<select name="subjectId" id="subjectId">
					<option value="-1">请选择</option>
					<?php
						foreach($subjectArray as $key => $sbjectInfo){
							if(get('subjectId') == $key){
								echo '<option value="' . $key . '" selected="selected">' . $sbjectInfo . '</option>';
							}else{
								echo '<option value="' . $key . '">' . $sbjectInfo . '</option>';
							}
						}
					?>
				</select>
			</div>
			<div class="name width80">发布状态：</div>
			<div class="control">
				<select name="isRelease" id="isRelease">
					<option value="-1">请选择</option>
					<option value="1" <?php if($isRelease == 1){echo 'selected="selected"';}?>>己发布</option>
					<option value="0" <?php if($isRelease == 0){echo 'selected="selected"';}?>>末发布</option>
				</select>
			</div>
			<div class="name width80">平台选择：</div>
			<div class="control">
				<select name="limit_xxt_type" id="limit_xxt_type">
					<option value="-1" <?php if($limitXxtType == -1){echo 'selected="selected"';}?>>所有平台</option>
					<option value="0" <?php if($limitXxtType == 0){echo 'selected="selected"';}?>>互联网</option>
					<option value="2" <?php if($limitXxtType == 2){echo 'selected="selected"';}?>>广东和教育</option>
					<option value="3" <?php if($limitXxtType == 3){echo 'selected="selected"';}?>>山西校讯通</option>
				</select>
			</div>

			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="matchSearch(2);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
function matchSearch(type){
	var url='?m=Match&a=showMatchList';
	if(type == 1){
		var reg = /^\d+$/;
		var matchId = $.trim($('#matchId').val());
		if(matchId){
			if(!reg.test(matchId)){
				UBox.show('赛事ID格式错误', -1);
				$('#matchId').select();
				return false;
			}
			url += '&matchId='+matchId;
		}

		window.location.href = url;
	}else if(type == 2){
		var matchName = $.trim($('#matchName').val());
		if(matchName){
			url += '&matchName='+matchName;
		}

		var timeType = $('#timeType').val();
		if(timeType > 0){
			var startTime = $.trim($('#startTime').val());
			if(!startTime){
				UBox.show('请选择开始时间', -1);
				return false;
			}

			var endTime = $.trim($('#endTime').val());
			if(!endTime){
				UBox.show('请选择结束时间', -1);
				return false;
			}
			url += '&timeType='+timeType+'&startTime='+startTime+'&endTime='+endTime;
		}

		var limitXxtType = $('#limit_xxt_type').val();
		if(limitXxtType != -1){
			url += '&limit_xxt_type=' + limitXxtType;
		}

		var gradeId = $('#gradeId').val();
		if(gradeId > -1){
			url += '&gradeId=' + gradeId;
		}

		var subjectId = $('#subjectId').val();
		if(subjectId > -1){
			url += '&subjectId=' + subjectId;
		}

		var duration = $('#duration').val();
		if(duration > -1){
			url += '&duration='+duration;
		}

		var limitLevel = $('#limitLevel').val();
		if(limitLevel > -1){
			url += '&limitLevel='+limitLevel;
		}
		var isRelease = $('#isRelease').val();
		if(isRelease > -1){
			url += '&isRelease='+isRelease;
		}
		window.location.href = url;
	}
}
</script>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
		._userList .list .c1{width:180px;}
		._userList .list .c2{width:70px;}
		._userList .list .c3{width:65px;}
		._userList .list .c4{width:60px;}
		._userList .list .c5{width:60px;}
		._userList .list .c6{width:60px;}
		._userList .list .c7{width:60px;}
		._userList .list .c8{width:80px;}
		._userList .list .c9{width:120px;}
		._userList .list .c10{width:70px;}
		._userList .list .c11{width:50px;}
		._userList .list .c12{width:50px;}
		._userList .list .c13{width:60px;}
		._userList .list .c14{width:125px;}
		._userList .list .c15{width:300px;}
		._userList .list .c16{width:120px;}
		._userList .list .row .c15 a{padding-right:5px;}

		.view_box{min-height:300px; height: 300px;padding: 10px;overflow: overlay;}
		.view_box ul li{line-height: 30px;}
		.view_box span{width:100px;display: inline-block;}
		.view_box b{width:60px;display: inline-block;}
		.view_box i{font-style: normal;display: inline-block;}
	</style>
	<div class="title">赛事列表</div>
	<div class="list">
		<div class="row header">
			<div class="c6">赛事ID</div>
			<div class="c1">赛事名称</div>
			<div class="c6">年 级</div>
			<div class="c7">科 目</div>
			<div class="c2">赛事状态</div>
			<div class="c8">首次参赛费用</div>
			<div class="c4">赛事时长</div>
			<div class="c3">报名等级</div>
			<div class="c10">限制年级</div>
			<div class="c16">平台</div>
			<div class="c13">是否发布</div>
			<div class="c13">团队赛</div>
			<div class="c14">创建时间</div>
			<div class="c15 right">操作</div>
		</div>
		<?php
			if($aMatchList){
				foreach($aMatchList as $aMatchInfo){
		?>
			<div class="row">
				<div class="c6" title="<?php echo $aMatchInfo['id'];?>"><?php echo $aMatchInfo['id'];?></div>
				<div class="c1" title="<?php echo $aMatchInfo['name'];?>"><?php echo $aMatchInfo['name'];?></div>
				<div class="c6">
					<?php echo isset($gradeArray[$aMatchInfo['grade_id']]) ? $gradeArray[$aMatchInfo['grade_id']] : '未知年级'; ?>
				</div>
				<div class="c7">
					<?php echo isset($subjectArray[$aMatchInfo['subject_id']]) ? $subjectArray[$aMatchInfo['subject_id']] : '未知科目'; ?>
				</div>
				<div class="c2">
					<?php
						if($aMatchInfo['match_start_time'] > time() && $aMatchInfo['match_end_time'] > time()){
							echo '未开始';
						}elseif($aMatchInfo['match_start_time'] <= time() && $aMatchInfo['match_end_time'] > time()){
							echo '进行中';
						}elseif($aMatchInfo['match_end_time'] <= time()){
							echo '己结束';
						}
					?>
				</div>
				<div class="c8"><?php echo $aMatchInfo['registration_fee'];?>金币</div>
				<div class="c4"><?php echo $aMatchInfo['duration'];?>分钟</div>
				<div class="c3"><?php if($aMatchInfo['limit_level'] > 0){echo $aMatchInfo['limit_level'] . '级'; }else{echo '无限制';} ?></div>
				<div class="c10"><?php echo empty($aMatchInfo['limit_grades']) ? '无限制' : join(',', $aMatchInfo['limit_grades']) ;?></div>
				<div class="c16">
					<?php
					if($aMatchInfo['limit_xxt_type']){
						$aXxtType = [];
						if(in_array(0, $aMatchInfo['limit_xxt_type'])){
							$aXxtType[] = '互网';
						}
						if(in_array(2, $aMatchInfo['limit_xxt_type'])){
							$aXxtType[] = '广和';
						}
						if(in_array(3, $aMatchInfo['limit_xxt_type'])){
							$aXxtType[] = '山校';
						}
						echo implode(',', $aXxtType);
					}else{
						echo "无限制";
					}
					?>
				</div>
				<div class="c13"><?php echo ($aMatchInfo['is_release'] == 1) ? '己发布' : '未发布';?></div>
				<div class="c13"><?php echo ($aMatchInfo['is_team_match'] == 1) ? '<span style="color:red;">团队赛</span>' : '非团队赛';?></div>
				<div class="c14"><?php echo date('Y-m-d H:i:s', $aMatchInfo['create_time']);?></div>
				<div class="c15 right">
					<a href="javascript:void(0);" onclick="showMatchRankUsers(<?php echo $aMatchInfo['id']?>);">当前排名</a>
					<?php
						if($aMatchInfo['is_release'] == 1){
							echo '<a href="/?m=Match&a=showEditMatchScore&id=' . $aMatchInfo['id'] . '">得分管理</a>';
						}

						echo '<a href="/?m=Match&a=showDetailMatch&id=' . $aMatchInfo['id'] . '">预览</a>';

						if($aMatchInfo['match_end_time'] <= time() && $aMatchInfo['is_release'] == 1){
							if($aMatchInfo['winners']){
								echo '<a href="/?m=Match&a=showWinnerList&id=' . $aMatchInfo['id'] . '">查看获奖名单</a>';
							}else{
								echo '<a href="/?m=Match&a=showMakePrize&id=' . $aMatchInfo['id'] . '">抽奖</a>';
							}
						}

						echo '<a href="/?m=Match&a=showEditMatchBasic&id=' . $aMatchInfo['id'] . '">编辑</a>';

						if($aMatchInfo['is_release'] == 0){
							echo '<a href="javascript:void(0);" onclick="javascript:deleteMatch(' . $aMatchInfo['id'] . ')">删除</a>';
						}
					?>
				</div>
			</div>
		<?php
			 }
				}else{
					echo '<div class="row"><div class="c1">暂无数据</div></div>';
					}
		?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	//删除
	function deleteMatch(matchId){
		if(matchId > 0){
			UBox.confirm('真要的删除吗？', function(){
				$.ajax({
					url:'?m=Match&a=deleteMatch',
					data:{id:matchId},
					type:'POST',
					dataType:'JSON',
					success:function(result){
						if(result.status == 1){
							//UBox.show('操作成功');
							window.location.reload();
						}else{
							UBox.show(result.msg, -1);
						}
					},
					error:function(){
						UBox.show('系统错误', -1);
					}
				})
			})
		}
	}

	function showMatchRankUsers(matchId){
		$.get(
			'/?m=Match&a=showMatchRankUserList&id=' + matchId,
			function(aResult){
				if(aResult.status == 1){
					easyDialog.open({
						container : {
							width : 600,
							header : '查看当前ID为【' + matchId + '】比赛当前排行数据',
							content : '<div id="viewInfo" class="view_box"></div>',
							yesFn : easyDialog.close,
							noFn : true
						},
						fixed : false
					});
					var liHtml = '';
					if(aResult.data.length == 0){
						liHtml += '<li>暂时还没有人上榜</li>'
					}else{
						for(var i = 0; i < aResult.data.length; i++){
							var aUser = aResult.data[i];
							var aRoles = [];	//用户角色
							if(chechkUmfunTestId(aUser.id)){
								aRoles.push('testUser');	//测试用户
							}
							if(aUser.xxt_id != 0){
								aRoles.push('xxtUser');	//和教育用户
							}

							liHtml += '<li' + (aRoles.length ? (' class="' + aRoles.join(' ') + '"') : '') + '><span class="name">' + aResult.data[i].name + '</span><b>' + aResult.data[i].best_score + ' 分</b><i>' + date('Y-m-d H:i:s', aResult.data[i].integral_card_expiration_time) + '</i></li>';
						}
					}

					$('#viewInfo').html('<ul>' + liHtml + '</ul>');
				}else{
					alert(aResult.msg);
				}
			}
		);
	}

	function chechkUmfunTestId(umfunUserId){
		var aUmfunUserIds = <?php echo json_encode($GLOBALS['TEST_USER_LIST']);?>;
		if($.inArray(parseInt(umfunUserId), aUmfunUserIds) != -1){
			return true;
		}else{
			return false;
		}
	}


	//抽奖
	function makePrize(matchId){
		if(matchId > 0){
			$.ajax({
				url : '?m=Match&a=makePrize',
				data:{id:matchId},
				type:'POST',
				dataType:'JSON',
				success:function(result){
					if(result.status == 1){
						UBox.show(result.msg, 1);
						$('#prize'+matchId).after('<a href="/?m=Match&a=showWinnerList&id='+matchId+'">查看获奖名单</a>	');
						$('#prize'+matchId).remove();
					}else{
						UBox.show(result.msg, -1);
					}

				},
				error:function(){
					UBox.show('系统错误', -1);
				}
			})
		}
	}
</script>
