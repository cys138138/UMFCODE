<div class="nav">
	<a <?php if(get('a') == 'showMatchList'){ ?>class="on"<?php } ?> href="?m=Match&a=showMatchList">赛事列表 </a>
	<a <?php if(get('a') == 'showAddMatch'){ ?>class="on"<?php } ?> href="?m=Match&a=showAddMatch">添加赛事 </a>
	<a <?php if(get('a') == 'setMatch'){ ?>class="on"<?php } ?> href="?m=Match&a=setMatch">颁奖设置 </a>
	 <?php if(get('a') == 'showEditMatchBasic' || get('a') == 'showEditMatchPrize' || get('a') == 'showEditMatchTopic'){?>
	 		<a id="editBasic" href="?m=Match&a=showEditMatchBasic&id=<?php echo $aMatchInfo['id']?>">基本信息 </a>
	 		<a id="editPrize" href="?m=Match&a=showEditMatchPrize&id=<?php echo $aMatchInfo['id']?>">奖项设置 </a>
			<?php if($aMatchInfo['description'] && $aMatchInfo['awards']){ ?>
				<a id="editTopic" href="?m=Match&a=showEditMatchTopic&id=<?php echo $aMatchInfo['id']?>">题目设置 </a>
			<?php }?>
	 <?php }?>
	 
	 <?php if(get('a') == 'showDetailMatch'){?>
	 		<a href="#" class="on">赛事预览 </a>
	 <?php }?>
	 
	 <?php if(get('a') == 'showWinnerList'){?>
	 		<a href="#" class="on">获奖人名单列表 </a>
	 <?php }?>	 

	 <?php if(get('a') == 'showEditMatchScore'){?>
	 		<a href="#" class="on">得分管理</a>
	 <?php }?>	
	 
	 <?php if(get('a') == 'showMakePrize'){?>
	 		<a href="#" class="on">抽奖 </a>
	 <?php }?>	
	 
</div>

<div class="br"></div>
<script type="text/javascript">
	var fName = '<?php echo get('a'); ?>';
	if(fName == 'showEditMatchBasic'){
		$('#editBasic').attr('href','#').addClass('on');
	}else if(fName == 'showEditMatchPrize'){
		$('#editPrize').attr('href','#').addClass('on');
	}else if(fName == 'showEditMatchTopic'){
		$('#editTopic').attr('href','#').addClass('on');
	}
</script>
