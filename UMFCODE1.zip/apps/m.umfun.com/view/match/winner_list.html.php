<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left; display:block}
		._main .item .grade_div label{padding-right:25px}


		._main .item .award_main{float:left;padding-bottom:10px;}

		._main .item .award_main .legend{float:left;color:#000; font-size:14px;line-height:26px;padding-left:5px;display:block;border:1px solid #fff}
		._main .item .award_main .award_c1{width:80px;}
		._main .item .award_main .award_c2{width:80px;}
		._main .item .award_main .award_c3{width:80px;}
		._main .item .award_main .award_c4{width:160px;}
		._main .item .award_main .award_c5{width:100px;}
		._main .item .award_main .award_c6{width:100px;}
		._main .item .award_main .award_c7{width:180px;}
		._main .item .award_main .award_c8{width:80px;}
		._main .item .award_main .award_c9{width:120px;}
		._main .item .award_main .award_c10{width:120px;}
		._main .item .award_main .award_c11{width:250px;}
	</style>
		<div class="title">获奖人名单列表</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">奖项信息：</div>
			<div class="control">
				<?php
					if(isset($aMatchInfo['awards']) && $aMatchInfo['awards']){
						if(isset($aMatchInfo['awards']['top']) && $aMatchInfo['awards']['top']){
				?>
					<div class="award_main" >
						<div class=" legend award_c1" >名　次</div>
						<div class=" legend award_c2">获奖人</div>
						<div class=" legend award_c3">领取状态</div>
						<div class=" legend award_c4">领取时间</div>
						<div class=" legend award_c5">经验奖励</div>
						<div class=" legend award_c6">金币奖励</div>
						<div class=" legend award_c7">实物奖励</div>
						<div class=" legend award_c8">收件人</div>
						<div class=" legend award_c9">收件电话</div>
						<div class=" legend award_c10">收件QQ</div>
						<div class=" legend award_c11">收件地址</div>
						<div class="clear"></div>
					</div>
					<div class="clear"></div>
				<?php
							foreach($aMatchInfo['awards']['top'] as $key=> $topAward){
								if(isset($awardsArray[$key])){
				?>
									<div class="award_main">
										<div class=" legend award_c1" >
											<?php echo $awardsArray[$key];?>
										</div>
										<div class=" legend award_c2" >
											<?php
												if(isset($aMatchInfo['winners']['top'][$key])){
													$topUserId = $aMatchInfo['winners']['top'][$key]['user_info']['id'];
													$testUserClass = in_array($topUserId, $GLOBALS['TEST_USER_LIST']) ? 'class="testUser"' : '';
													echo '<a href="#" title="' . $topUserId . '" ' . $testUserClass . '>' .
													$aMatchInfo['winners']['top'][$key]['user_info']['name'] .
													'</a>';
												}else{
													echo '未选出';
												}
											?>
										</div>
										<div class=" legend award_c3" >
											<?php
												if(isset($aMatchInfo['winners']['top'][$key])){
													if($aMatchInfo['winners']['top'][$key]['receive_time'] > 0){
														echo '己领取';
													}else{
														echo '末领取';
													}
												}else{
													echo '末领取';
												}
											?>
										</div>
										<div class=" legend award_c4" >
											<?php
												if(isset($aMatchInfo['winners']['top'][$key])){
													if($aMatchInfo['winners']['top'][$key]['receive_time'] > 0){
														echo date('Y-m-d H:i:s', $aMatchInfo['winners']['top'][$key]['receive_time']);
													}else{
														echo '';
													}
												}
											?>
										</div>
										<div class=" legend award_c5" >
											<?php
												if($aPrizePoints){
													if($key < 4){
														echo $aPrizePoints[$key];
													}else{
														echo $aPrizePoints[4];
													}
												}else{
													echo 0;
												}
											?> 分
										</div>
										<div class=" legend award_c6" >
											<?php echo isset($topAward['gold']) ? $topAward['gold'] : 0 ?> 个
										</div>
										<div class=" legend award_c7" >
											<?php echo isset($topAward['prize']) ? $topAward['prize'] : '' ?>
										</div>
										<div class=" legend award_c8" >
											<?php echo isset($aMatchInfo['winners']['top'][$key]['address']['name']) ? $aMatchInfo['winners']['top'][$key]['address']['name'] : '' ?>
										</div>
										<div class=" legend award_c9" >
											<?php echo isset($aMatchInfo['winners']['top'][$key]['address']['call_phone']) ? $aMatchInfo['winners']['top'][$key]['address']['call_phone'] : '' ?>
										</div>
										<div class=" legend award_c10" >
											<?php echo isset($aMatchInfo['winners']['top'][$key]['address']['qq']) ? $aMatchInfo['winners']['top'][$key]['address']['qq'] : '' ?>
										</div>
										<div class=" legend award_c11" >
											<?php
											if($aMatchInfo['winners']['top'][$key]['address']){
												echo $aMatchInfo['winners']['top'][$key]['address']['province_name'] .  $aMatchInfo['winners']['top'][$key]['address']['city_name'] . $aMatchInfo['winners']['top'][$key]['address']['area_name'] . $aMatchInfo['winners']['top'][$key]['address']['address'];
											}
											?>
										</div>
										<div class="clear"></div>
									</div>
									<div class="clear"></div>
				<?php
								}
							}
						}

						if(isset($aMatchInfo['awards']['rand']) && $aMatchInfo['awards']['rand']){
							for($i = 0; $i< $aMatchInfo['awards']['rand']['number']; $i++){
						?>
							<div class="award_main">
								<div class=" legend award_c1" >幸运奖</div>
								<div class=" legend award_c2" >
									<?php
										if(isset($aMatchInfo['winners']['rand'][$i])){
											$lucklyUserId = $aMatchInfo['winners']['rand'][$i]['user_info']['id'];
											$testUserClass = in_array($lucklyUserId, $GLOBALS['TEST_USER_LIST']) ? 'class="testUser"' : '';
											echo '<a href="#" title="' . $lucklyUserId . '" ' . $testUserClass . '>' . $aMatchInfo['winners']['rand'][$i]['user_info']['name'] . '</a>';
										}else{
											echo'末选出';
										}
									?>
								</div>
								<div class=" legend award_c3" >
									<?php
										if(isset($aMatchInfo['winners']['rand'][$i])){
											if($aMatchInfo['winners']['rand'][$i]['receive_time'] > 0){
												echo '己领取';
											}else{
												echo '末领取';
											}
										}else{
											echo '末领取';
										}
									?>
								</div>
								<div class=" legend award_c4" >
									<?php
										if(isset($aMatchInfo['winners']['rand'][$i])){
											if($aMatchInfo['winners']['rand'][$i]['receive_time'] > 0){
												echo date('Y-m-d H:i:s', $aMatchInfo['winners']['rand'][$i]['receive_time']);
											}else{
												echo '';
											}
										}else{
											echo '';
										}

									?>
								</div>
								<div class=" legend award_c5" >
									<?php echo  isset($aPrizePoints[-1]) ?  $aPrizePoints[-1] : 0; ?> 分
								</div>
								<div class=" legend award_c6" >
									<?php echo isset($aMatchInfo['awards']['rand']['gold']) ? $aMatchInfo['awards']['rand']['gold'] : 0 ?> 个
								</div>
								<div class=" legend award_c7" >
									<?php echo isset($aMatchInfo['awards']['rand']['prize']) ? $aMatchInfo['awards']['rand']['prize'] : ''?>
								</div>
								<div class=" legend award_c8" >
									<?php echo isset($aMatchInfo['winners']['rand'][$i]['address']['name']) ? $aMatchInfo['winners']['rand'][$i]['address']['name'] : '' ?>
								</div>
								<div class=" legend award_c9" >
									<?php echo isset($aMatchInfo['winners']['rand'][$i]['address']['call_phone']) ? $aMatchInfo['winners']['rand'][$i]['address']['call_phone'] : '' ?>
								</div>
								<div class=" legend award_c10" >
									<?php echo isset($aMatchInfo['winners']['rand'][$i]['address']['qq']) ? $aMatchInfo['winners']['rand'][$i]['address']['qq'] : '' ?>
								</div>
								<div class=" legend award_c11" >
									<?php
									if($aMatchInfo['winners']['rand'] && $aMatchInfo['winners']['rand'][$i]['address']){
										echo $aMatchInfo['winners']['rand'][$i]['address']['province_name'] .  $aMatchInfo['winners']['rand'][$i]['address']['city_name'] . $aMatchInfo['winners']['rand'][$i]['address']['area_name'] . $aMatchInfo['winners']['rand'][$i]['address']['address'];
									}
									?>
								</div>
							</div>
							<div class="clear"></div>
						<?php
							}
						}

					}else{
						echo '还末设置奖项信息';
					}
				?>
			</div>
	</div>
	<div class="clear" style="height:5px;"></div>



		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" href="?m=Match&a=showMatchList" />返回列表</a></div>
		</div>
		<div class="clear"></div><BR><BR>

</div>
