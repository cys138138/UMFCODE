<?php display('match/nav.html.php'); ?>
<style>
input{ float: left; margin-right:5px;}
button.button{border:none;}
</style>

<div class="module _main">
	<div class="title">获奖作废天数</div>
	<div class="clear"></div>
	<input type="text" name="matchAward" id="matchAward" value="<?php echo isset($GLOBALS['MATCH_AWARD']) ? $GLOBALS['MATCH_AWARD'] : 7; ?>"/>
	<button class="button">提交</button>
</div>

<script type="text/javascript">
	$(function(){
		$('button').on('click', function(){
			$.ajax({
				url : '?m=match&a=setMatch',
				type : 'post',
				data : {matchAward : $('#matchAward').val()},
				success : function(aResult){
					if(aResult.status == 1){
						UBox.show('设置成功', 1);
					}else{
						UBox.show('设置失败', -1);
					}
				},
				error : function(data){
					UBox.show('系统错误', -1);
				}
			});
		})
	});
	
</script>