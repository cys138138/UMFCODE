<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>

<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .profile_item{position:relative;overflow:visible}
		._main .profile_item .profile_main{border:1px solid #ccc;width:270px;height:300px;position:absolute; left:655px;top:-90px;display:none}
		._main .profile_item .profile_main img{width:270px;height:300px}
		._main .profile_item .profile_main .del_profile{position:absolute;right:-5px;top:-10px;}
		._main .item .hide{display: none}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left;padding-top:10px;padding-bottom:5px;}
		._main .item .grade_div label{padding-right:25px}
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		._subject span{margin-right:15px; display:inline-block;}
		._main .item .control .match_name{width:450px;}

		._mian .item .left{float:left;}
		select{margin-right:15px;padding:0 3px;}
		._main .item .control .button_loading{ background-color: #666}
		._main .item .radio_div{margin-left:15px;margin-right: 5px;}
	</style>
	<form id="matchtEditBasic" class="addForm" autocomplete="off">
		<div class="title">赛事基本信息</div>
		<div class="item">
			<div class="name">赛事名称：</div>
			<div class="control"><input type="text" name="match_name" id="match_name" class="match_name" value=" <?php echo $aMatchInfo['name'] ?>" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">是否团队赛：</div>
			<div class="control">
					<select name="is_team_match" id="is_team_match" >
						<option <?php if(!$aMatchInfo['is_team_match']){ echo 'selected="selected"'; } ?> value="0" >否</option>
						<option <?php if($aMatchInfo['is_team_match']){ echo 'selected="selected"'; } ?> value="1" >是</option>
					</select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">详细介绍：</div>
			<div class="control">
				<script type="text/plain" id="rule" name="rule" style="width:900px;height:320px;"></script>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
		<div class="clear"></div>
		<div class="name">比赛起止时间：</div>
			<div class="control">
				<input type="text" value="<?php echo date('Y-m-d H:i:s', $aMatchInfo['match_start_time'])?>" name="match_start_time" id="match_start_time" class=" left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" />
				<label style="float:left;color:#666;padding:0 8px;">----</label>
				<input type="text" value="<?php echo date('Y-m-d H:i:s', $aMatchInfo['match_end_time'])?>" name="match_end_time" id="match_end_time" class=" left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" />
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">首次参赛费用：</div>
			<div class="control"><input type="text" name="registration_fee" id="registration_fee" value="<?php echo $aMatchInfo['registration_fee']?>" /> 金币(0表示免费)</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">多次参赛费用：</div>
			<div class="control"><input type="text" name="rejoin_fee" id="rejoin_fee" value="<?php echo $aMatchInfo['rejoin_fee']?>" />金币(0表示免费);</div>
		</div>
		<div class="clear"></div>
		<div class="item profile_item" >
			<div class="name">主题图片：</div>
			<div class="control" style="overflow:hidden">
				<input type="file" name="imgUpload" id="imgUpload" />
				图片大小应小于300KB，最大宽度不能超过400它，宽高比为13:9 最佳宽高为130px*90px
			</div>
			<div id="profile_main" class="profile_main">
				<img id="profileImg" />
			</div>
			<input type="text" name="profile" id="profile" class="hide"  value="<?php echo $aMatchInfo['profile'];?>" />
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">时长及等级：</div>
			<div class="control">
				<select id="duration" name="duration">
					<option value="-1">-赛事时长-</option>
					<?php if(isset($durationArray)){
						foreach($durationArray as $duration){
							if($aMatchInfo['duration'] == $duration){
								echo '<option value="' . $duration . '" selected="selected">-' . $duration . '分钟-</option>';
							}else{
								echo '<option value="' . $duration . '">-' . $duration . '分钟-</option>';
							}

						}
					}?>
				</select>
				<select name="limit_level" id="limit_level" >
					<option value="-1">-最小报名等级-</option>
					<?php
						if(isset($levelArray)){
							foreach($levelArray as $key => $level){
								if($aMatchInfo['limit_level'] == $key){
									echo '<option value="'.$key.'" selected="selected">-'.$level.'-</option>';
								}else{
									echo '<option value="'.$key.'">-'.$level.'-</option>';
								}

							}
						}
					?>
				</select>
				<select name="limit_times" id="limit_times" style="display:none">
					<!--<option value="-1">-参赛次数-</option>-->
					<option value="0">无次数限置</option>
					<?php
					/*
						if(isset($limitArray)){
							foreach ($limitArray as $key => $limit){
								if($aMatchInfo['limit_times'] == $key){
									echo '<option value="'.$key.'" selected="selected">-'.$limit.'-</option>';
								}else{
									echo '<option value="'.$key.'">-'.$limit.'-</option>';
								}
							}
						}
					 *
					 */
					?>
				</select>
				<select name="view_css" id="view_css" style="display:none">
					<option value="123">默认风格</option>
				</select>

			</div>

		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name"> 限制条件：</div>
			<div class="control">
					<?php
						foreach($GLOBALS['UMF_GRADE'] as $grade => $gradeName){
								$checkbox = '';
								if(in_array($grade, (array)$aMatchInfo['limit_grades'])){
									$checkbox = ' checked="checked"';
								}
								echo '<label><input type="checkbox" name="limit_grades[]" id="limit_grades" value="' . $grade . '" ' . $checkbox . '>' . $gradeName . '</label>';
								if($grade == 0 || $grade == 6 || $grade == 9){
									echo '<br/>';
								}
						}
					?>
			</div>
			<div class="clear"></div>
			<div class="name"> 参赛用户类型：</div>
			<div class="control" id="limitXxtType">
				<!--select name="limit_xxt" id="limit_xxt" >
					<option value="-1">-参赛用户类型-</option>
					<option value="1"<?php
						//if($aMatchInfo['limit_xxt'] == 1){
							//echo ' selected="selected"';
						//}
					?>> -和教育专场-</option>
					<option value="0"<?php
						//if($aMatchInfo['limit_xxt'] == 0){
							//echo ' selected="selected"';
						//}
					?>> -所有用户- </option>

				</select-->
				<label style="width:100px" for="checkAll">
					<input name="checkAll" type="checkbox"  onclick="checkAllXxtType(this.checked)" id="checkAll">全部用户
				</label>
					<label><input type="checkbox" name="limit_xxt_type[]" class="J-limitXxtType" value="0" <?php if(in_array(0, $aMatchInfo['limit_xxt_type'])){echo 'checked="checked"';} ?>>互联网用户</label>
				<label><input type="checkbox" name="limit_xxt_type[]" class="J-limitXxtType" value="2" <?php if(in_array(2, $aMatchInfo['limit_xxt_type'])){echo 'checked="checked"';} ?>>广东校讯通用户</label>
				<label><input type="checkbox" name="limit_xxt_type[]" class="J-limitXxtType" value="3" <?php if(in_array(3, $aMatchInfo['limit_xxt_type'])){echo 'checked="checked"';} ?>>山西校讯通用户</label>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">年级和科目：</div>
			<div class="control">

				<div class="grade_div" id="grade_div">
					<select name="grade_id" id="grade_id" >
						<option value="-1" >-请选择年级-</option>
						<?php
							foreach($gradeArray as $key => $grade){
								if($key == $aMatchInfo['grade_id']){
									echo '<option value="' . $key . '" selected="selected">' . $grade . '</option>';
								}else{
									echo '<option value="' . $key . '" >' . $grade . '</option>';
								}
							}
						?>
					</select>
					<select name="subject_id" id="subject_id" >
						<option value="-1" >-科目-</option>
						<?php
							foreach($subjectArray as $key => $grade){
								if($key == $aMatchInfo['subject_id']){
									echo '<option value="' . $key . '"  selected="selected">' . $grade . '</option>';
								}else{
									echo '<option value="' . $key . '" >' . $grade . '</option>';
								}
							}
						?>
					</select>
				</div>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<a class="button" id="submitButton" onclick="editMatch()" />保　存</a>
			</div>
			<div class="control radio_div" >
				<input type="radio" name="nex_step" id="match_list" checked="checked" /><label for="match_list">保存后去 赛事列表</label>
			</div>
			<div class="control radio_div">
				<input type="radio" name="nex_step"  id="match_prize" /><label for="match_prize">保存后去 奖项设置</label>
			</div>
			<?php if($aMatchInfo['description'] && $aMatchInfo['awards']){ ?>
				<div class="control radio_div">
					<input type="radio" name="nex_step" id="match_topic"/><label for="match_topic">保存后去 题目设置</label>
				</div>
			<?php } ?>
		</div>
		<div class="clear"></div>
		<br /><br /><br />
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddMatchJs; ?>
function checkAllXxtType(checked){
	$('#limitXxtType input[type=checkbox]').each(function(){$(this).prop('checked', checked);});
}

//实例化编辑器
var ue = UM.getEditor('rule', {
	imageUrl : '?m=Match&a=ueditorUpload',
	imagePath : '<?php echo SYSTEM_RESOURCE_URL . MATCH_RULE_IMAGE_PATH; ?>'
});
ue.setContent("<?php echo $aMatchInfo['rule']?>");



//比赛时间
function _after_match_end_time(){
	var match_start_time = $('#match_start_time').val();
	var match_end_time = $('#match_end_time').val();
	match_start_time = getTimestamp(match_start_time);
	match_end_time = getTimestamp(match_end_time);

	if(match_end_time <= match_start_time){
		UBox.show('赛事结束时间必须大于赛事开始时间', -1);
		return false;
	}
}


//将Y-M-D　格式日期字符串转换成毫秒
function getTimestamp(date){
	var date = new Date(date.replace(/-/g, '/'));
	date = date.getTime();
	return date;
}

//判断编辑器内容是否为空
function _after_description(){
	var content = UM.getEditor('rule').getContent();
	if(content == ''){
		UBox.show('赛事规则不能为空', -1);
		return false;
	}
}


//封面
function _after_registration_fee(){
	var profile = $('#profile').val();
	if(!profile){
		UBox.show('请上传封面图片', -1);
		return false;
	}
}

//赛事开始时间到结束时间不能小于赛事时长
function _after_duration(){
	var match_start_time = $('#match_start_time').val();
	var match_end_time = $('#match_end_time').val();
	match_start_time = getTimestamp(match_start_time);
	match_end_time = getTimestamp(match_end_time);
	match_time = parseInt(match_end_time - match_start_time) / 1000 / 60;

	if(match_time < 1 || isNaN(match_time)){
		UBox.show('请选择赛事时长', -1);
		return false;
	}
	var duration = parseInt($('#duration').val());
	if(match_time < duration){
		UBox.show('赛事开始时间到结束时间的时长不能小于'+duration+'分钟', -1);
		return false;
	}
}

$(function(){
	$("#imgUpload").uploadify({
		'fileTypeExts' : '*.jpg; *.png; *.gif',
		'fileSizeLimit' : '300KB',
		'height' : 30,
		'width' : 100,
		'swf' : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'].$GLOBALS['RESOURCE']['uploadify']['swf']; ?>',
		'uploader' : 'http://<?php echo APP_MANAGE ?>/?m=Match&a=uploadProfile&ajax=1',
		'buttonText' : '选择文件',
		'multi' : true,
		'onUploadSuccess' : function(file, data, response){
			data = eval('(' + data + ');');
			if(data.status == 1){
				var delProfile_a = document.getElementById('delProfile_a');
				if(!delProfile_a){
					$('#profileImg').attr('src', data.data).after('<a href="javascript:void(0)" id="delProfile_a" onclick="javascript:delProfile()" class="del_profile" title="删除封面" >删除</a>');
				}else{
					$('#profileImg').attr('src', data.data);
				}
				$('#profile').val(data.msg);
				$('#profile_main').show(300);
			}else{
				$('#profile_main').hide();
				$('#profileImg').attr('src', '');
				$('#profile').val('');
				UBox.show(data.msg, -1);
			}
		}
	});

	var _profile_url = "<?php echo $aMatchInfo['profile_url'] ?>";
	var _profile = "<?php echo $aMatchInfo['profile'] ?>";
	if(_profile_url && _profile){
		$('#profileImg').attr('src', _profile_url);
		$('#profile').val("<?php echo $aMatchInfo['profile'] ?>");
		$('#profile_main').show();
	}
});

//删除图片
function delProfile(){
	var imgName = $('#profile').val();
	if(!imgName){
		return false;
	}

	UBox.confirm('真要的删除吗？', function(){
		$.ajax({
			url:'?m=Match&a=delProfile',
			data:{profile:imgName},
			type:'POST',
			dataType:'JSON',
			success:function(result){
				if(result.status == 1){
					$('#profile').val('');
					$('#profile_main').hide();
					$('#profileImg').attr('src', '');
					UBox.show('删除成功', 1);
				}else{
					UBox.show(result.msg, -1);
				}
			},
			error:function(){
				UBox.show('删除失败',-1)
			}
		});
	});
}

//提交表单
function editMatch(){
	if(checkForm() == true){
		var matchId = <?php echo $aMatchInfo["id"]; ?>;
		$.ajax({
			url: '/?m=Match&a=editMatchBasic&id=' + matchId,
			data: $('#matchtEditBasic').serialize(),
			type: 'post',
			dataType: 'json',
			beforeSend: function(){
				$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
			},
			complete:function(){
				$('#submitButton').attr('onclick', 'editMatch()').removeClass('button_loading').html('保　存');
			},
			success: function(aResult){
				if(aResult.status == 1){
					var msg = '操作成功 点击回列表';
					var afterUrl = '/?m=Match&a=showMatchList';
					var after = $('input[type="radio"]:checked').attr('id');
					if(after == 'match_prize'){
						msg = '操作成功 点击进行奖项设置';
						afterUrl = '/?m=Match&a=showEditMatchPrize&id=' + matchId;
					}else if(after == 'match_topic'){
						msg = '操作成功 点击进行题目设置';
						afterUrl = '/?m=Match&a=showEditMatchTopic&id=' + matchId;
					}
					UBox.show(msg, 1, afterUrl);
				}else{
					UBox.show(aResult.msg, -1);
				}
			},
			error: function(){
				UBox.show('系统错误', 0);
			}
		});
	}
}
</script>