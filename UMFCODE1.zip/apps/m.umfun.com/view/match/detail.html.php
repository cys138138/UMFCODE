<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		
		
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		
		._subject span{margin-right:15px; display:inline-block;}
		
		
		._main .item .control #match_name{width:450px;}
		._main .item .control #description{width:450px;height:65px}
		._mian .item .profile_main{border:1px solid red;width:130px;height:90px;border:1px solid red;position:absolute; left:240px;top:-70px;}
		._mian .item .left{float:left;}	
		.point_a{font-weight: bold;float:left;font-size:18px;line-height:24px;margin-right:25px}
		.detail_nav{color:#000; font-size:18px;height:28px;line-height:28px;margin:10px; width:950px; text-align:right;}
		._main .profile_item{position:relative;overflow:visible}
		._main .profile_item .proflie_control{overflow:hidden; position: absolute; left: 300px; top: -50px;}
		._main .profile_item .proflie_control img{width:270px;height:300px; border:1px solid #CCC;padding:2px}
		
	</style>
		<div class="title">赛事预览</div>
		<div class="item">
			<div class="name">赛事名称：</div>
			<div class="control"><?php echo $aMatchInfo['name']?></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">赛事规则：</div>
			<div class="control"><?php echo $aMatchInfo['rule']?></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">比赛起止时间：</div>
			<div class="control">
				<?php echo date('Y-m-d H:i:s', $aMatchInfo['match_start_time']);?>
				----
				<?php echo date('Y-m-d H:i:s', $aMatchInfo['match_end_time'])?>
			</div>
		</div>

		<div class="clear"></div>
		<div class="item">
			<div class="name">首次参赛费用：</div>
			<div class="control">
				<?php if($aMatchInfo['registration_fee'] > 0){echo $aMatchInfo['registration_fee'].'金币';}else{ echo '免费';}?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">多次参赛费用：</div>
			<div class="control">
				<?php if($aMatchInfo['rejoin_fee'] > 0){echo $aMatchInfo['rejoin_fee'].'金币';}else{ echo '免费';}?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item profile_item">
			<div class="name">主题图片：</div>
			<div class="control proflie_control">
				<img src="<?php echo $aMatchInfo['profile']?>" alt="图片错误" />
				
			</div>
		</div>
		<div class="clear"></div>
				
		<div class="item">
			<div class="name">赛事时长：</div>
			<div class="control">
				<?php echo $aMatchInfo['duration'].'分钟'?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item" >
			<div class="name">参赛等级：</div>
			<div class="control" >
				<?php if($aMatchInfo['limit_level'] > 0){echo $aMatchInfo['limit_level'] . '级';}else{echo '无等级限制';}?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item" >
			<div class="name">参赛次数：</div>
			<div class="control" >
				<?php if($aMatchInfo['limit_times'] > 0){echo $aMatchInfo['limit_times'] . '次';}else{echo '无次数限制';}?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">主题风格：</div>
			<div class="control">
				<?php if($aMatchInfo['view_css'] == '123'){echo '默认主题';}else{echo '未知主题';}?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">年 级：</div>
			<div class="control">
				<?php echo isset($gradeArray[$aMatchInfo['grade_id']]) ? $gradeArray[$aMatchInfo['grade_id']] : '末知年级';?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">科 目：</div>
			<div class="control">
				<?php echo isset($subjectArray[$aMatchInfo['subject_id']]) ? $subjectArray[$aMatchInfo['subject_id']] : '末知科目';?>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">奖品描述：</div>
			<div class="control"><?php echo $aMatchInfo['description']?></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">奖项信息：</div>
			<div class="control">
				<?php 
					if(isset($aMatchInfo['awards']) && $aMatchInfo['awards']){
						if(isset($aMatchInfo['awards']['top']) && $aMatchInfo['awards']['top']){
							foreach($aMatchInfo['awards']['top'] as $key=> $topAward){
								if(isset($awardsArray[$key])){
				?>
									<div class="award_main">
										<label class="award_text"><?php echo $awardsArray[$key];?></label>
										<label class="award_sub">经验：</label>
										<a class="point_a"><?php echo isset($topAward['accumulate_points']) ? $topAward['accumulate_points'] : 0 ?>分</a>
										<label class="award_sub">金币：</label>
										<a class="point_a"><?php echo isset($topAward['gold']) ? $topAward['gold'] : 0 ?>分</a>
										<label class="award_sub">实物：</label>
										<a class="point_a"><?php echo isset($topAward['prize']) ? $topAward['prize'] : '' ?></a>
									</div>
									<div class="clear"></div>
				<?php
								}
							}
						}	
						
						if(isset($aMatchInfo['awards']['rand']) && $aMatchInfo['awards']['rand']){
						?>
							<div class="award_main" id="luckly">
								<label class="award_text">幸运奖</label>
								<label class="award_sub">从排名第</label>
								<a class="point_a"><?php echo isset($aMatchInfo['awards']['rand']['ranking_rate'][0]) ? $aMatchInfo['awards']['rand']['ranking_rate'][0] : ''?></a>
								<label class="explain_label" >名到第</label>
								<a class="point_a"><?php echo isset($aMatchInfo['awards']['rand']['ranking_rate'][1]) ? $aMatchInfo['awards']['rand']['ranking_rate'][1] : ''?></a>
								<label class="explain_label">名内抽取</label>
								<a class="point_a"><?php echo isset($aMatchInfo['awards']['rand']['number']) ? $aMatchInfo['awards']['rand']['number'] : ''?></a>
								<label class="explain_label">个名额作为幸运奖</label>
								<label class="award_sub">经验：</label>
								<a class="point_a"><?php echo isset($aMatchInfo['awards']['rand']['accumulate_points']) ? $aMatchInfo['awards']['rand']['accumulate_points'] : 0 ?> 分</a>
								<label class="award_sub">金币：</label>
								<a class="point_a"><?php echo isset($aMatchInfo['awards']['rand']['gold']) ? $aMatchInfo['awards']['rand']['gold'] : 0 ?> 个</a>
								<label class="award_sub">实物：</label>
								<a class="point_a"><?php echo isset($aMatchInfo['awards']['rand']['prize']) ? $aMatchInfo['awards']['rand']['prize'] : ''?></a>
							</div>						
						<?php
						}
						
					}else{
						echo '还末设置奖项信息';
					}
				?>
			</div>			
	</div>
	<div class="clear" style="height:5px;"></div>
	<div class="item">
		<div class="name">题型信息：</div>
		<div class="control">

			<?php 
				foreach($esTypeArray as $key => $esType){
					$inputVlue = '0';
					foreach($aMatchInfo['es_rule'] as $esRule){
						if($esRule['es_type_id'] == $key){
							$inputVlue = $esRule['es_count']; 
							break;		
						}
					}
					echo '<label  style="float:left;padding-right:5px">'.$esType.'</label><a class="point_a" >'.$inputVlue.'题</a>';
				}
			?>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">题目目录</div>
		<div class="control">
			<?php if($cagegoryStr){echo $cagegoryStr;}else{echo '还未设置目录';}?>
		</div>
	</div>
	<div class="clear"></div>

		
		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" href="?m=Match&a=showMatchList" />返回列表</a></div>
		</div>
		<div class="clear"></div><BR><BR>
</div>
