<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>
<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left; display:block}
		._main .item .grade_div label{padding-right:25px}
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}

		._subject span{margin-right:15px; display:inline-block;}

		._main .item .control #match_name{width:450px;}
		._main .item .control #description{width:450px;height:65px}
		._mian .item .profile_main{border:1px solid red;width:130px;height:90px;border:1px solid red;position:absolute; left:240px;top:-70px;}
		._mian .item .left{float:left;}
		select{margin-right:15px;padding:0 3px;}
		._main .item .control .button_loading{ background-color: #666}

	</style>

	<form id="matchtAdd" class="addForm">
		<div class="title">新增赛事</div>
		<div class="item">
			<div class="name">赛事名称：</div>
			<div class="control"><input type="text" name="match_name" id="match_name" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">是否团队赛：</div>
			<div class="control">
					<select name="is_team_match" id="is_team_match" >
						<option value="0" >否</option>
						<option value="1" >是</option>
					</select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">详细介绍：</div>
			<div class="control">
				<script type="text/plain" id="rule" name="rule" style="width:900px;height:320px;"></script>
			</div>
		</div>

		<div class="clear" style="height:10px"></div>
		<div class="item">
			<div class="name">比赛起止时间：</div>
			<div class="control">
				<input type="text" name="match_start_time" id="match_start_time" class=" left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" />
				<label style="float:left;color:#666;padding:0 8px;">----</label>
				<input type="text" name="match_end_time" id="match_end_time" class=" left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" />
			</div>
		</div>

		<div class="clear"></div>
		<div class="item">
			<div class="name">首次参赛费用：</div>
			<div class="control">
				<input type="text" name="registration_fee" id="registration_fee" value="0" />
			金币(0表示免费);
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">多次参赛费用：</div>
			<div class="control">
				<input type="text" name="rejoin_fee" id="rejoin_fee" value="0" />
			金币(0表示免费);
			</div>
		</div>
		<div class="clear"></div>
		<div class="item" style="position:relative;overflow:visible">
			<div class="name">主题图片：</div>
			<div class="control" style="overflow:hidden">
				<input type="file" name="imgUpload" id="imgUpload" />
				图片大小应小于300KB，最大宽度不能超过400px，宽高比为9:10 最佳宽高为270px*300px
			</div>
			<div id="profile_main" style="border:1px solid #ccc;width:270px;height:300px;position:absolute; left:650px;top:-110px;display:none">
				<a href="javascript:void(0)" onclick="javascript:delProfile()" title="删除封面" style="position:absolute;right:-5px;top:-10px;" >删除</a>
				<img id="profileImg" style="width:270px;height:300px" />
			</div>
			<input type="text" name="profile" id="profile" style="display:none"  />
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">时长及等级：</div>
			<div class="control">
				<select id="duration" name="duration">
					<option value="-1">-赛事时长-</option>
					<?php if(isset($durationArray)){
						foreach($durationArray as $duration){
							echo '<option value="' . $duration . '">-' . $duration . '分钟-</option>';
						}
					}?>
				</select>
				<select name="limit_level" id="limit_level" >
					<option value="-1">-最小报名等级-</option>
					<?php
						if(isset($levelArray)){
							foreach($levelArray as $key => $level){
								echo '<option value="'.$key.'">-'.$level.'-</option>';
							}
						}
					?>
				</select>

				<select name="limit_times" id="limit_times" style="display: none">
					<!--<option value="-1">-参赛次数-</option>-->
					<option value="0">无次数限制</option>
					<?php
						/*
						if(isset($limitArray)){
							foreach ($limitArray as $key => $limit){
								echo '<option value="'.$key.'">-'.$limit.'-</option>';
							}
						}
						 */
					?>
				</select>

				<select name="view_css" id="view_css" style="display:none">
					<option value="123">默认风格</option>
				</select>
			</div>

		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name"> 限制条件：</div>
			<div class="control">
				<?php
					foreach($GLOBALS['UMF_GRADE'] as $grade => $gradeName){
						echo '<label><input type="checkbox" name="limit_grades[]" id="limit_grades" value="' . $grade . '">' . $gradeName . '</label>';
						if($grade == 0 || $grade == 6 || $grade == 9){
							echo '<br/>';
						}
					}
					?>
			</div>
			<div class="clear"></div>
			<div class="name"> 参赛用户类型：</div>
			<div class="control" id="limitXxtType">
				<!--select name="limit_xxt" id="limit_xxt" >
					<option value="-1">-参赛用户类型-</option>
					<option value="1"> -和教育专场-</option>
					<option value="0"> -所有用户- </option>
				</select-->
				<label style="width:100px" for="checkAll">
					<input name="checkAll" type="checkbox"  onclick="checkAllXxtType(this.checked)" id="checkAll">全部用户
				</label>
				<label><input type="checkbox" name="limit_xxt_type[]" class="J-limitXxtType" value="0">互联网用户</label>
				<label><input type="checkbox" name="limit_xxt_type[]" class="J-limitXxtType" value="2">广东校讯通用户</label>
				<label><input type="checkbox" name="limit_xxt_type[]" class="J-limitXxtType" value="3">山西校讯通用户</label>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">年级和科目：</div>
			<div class="control">
				<div class="grade_div" id="grade_div">
					<select name="grade_id" id="grade_id" >
						<option value="-1" >-请选择年级-</option>
						<?php
							foreach($gradeArray as $key => $grade){
								echo '<option value="' . $key . '" >' . $grade . '</option>';
							}
						?>
					</select>
					<select name="subject_id" id="subject_id" >
						<option value="-1" >-科目-</option>
						<?php
							foreach($subjectArray as $key => $grade){
								echo '<option value="' . $key . '" >' . $grade . '</option>';
							}
						?>
					</select>
				</div>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" id="submitButton" onclick="addMatch()" />发布赛事</a></div>
		</div>
		<div class="clear"></div><br /><br />
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddMatchJs; ?>
function checkAllXxtType(checked){
	$('#limitXxtType input[type=checkbox]').each(function(){$(this).prop('checked', checked);});
}

//比赛时间
function _after_match_end_time(){
	var match_start_time = $('#match_start_time').val();
	var match_end_time = $('#match_end_time').val();
	match_start_time = getTimestamp(match_start_time);
	match_end_time = getTimestamp(match_end_time);
	if(match_end_time <= match_start_time){
		UBox.show('赛事结束时间必须大于赛事开始时间', -1);
		return false;
	}
}


//将Y-M-D　格式日期字符串转换成毫秒
function getTimestamp(dateStr){
	var date = new Date(dateStr.replace(/-/g, '/'));
	date = date.getTime();
	return date;
}

//判断编辑器内容是否为空
function _after_description(){
	var content = UM.getEditor('rule').getContent();
	if(content == ''){
		UBox.show('赛事规则不能为空', -1);
		return false;
	}
}


//封面
function _after_registration_fee(){
	var profile = $('#profile').val();
	if(!profile){
		UBox.show('请上传封面图片', -1);
		return false;
	}
}

//赛事开始时间到结束时间不能小于赛事时长
function _after_duration(){
	var match_start_time = $('#match_start_time').val();
	var match_end_time = $('#match_end_time').val();
	match_start_time = getTimestamp(match_start_time);
	match_end_time = getTimestamp(match_end_time);
	//分钟
	match_time = parseInt(match_end_time - match_start_time) / 1000 / 60;
	if(match_time < 1 || isNaN(match_time)){
		UBox.show('请选择赛事时长', -1);
		return false;
	}
	var duration = parseInt($('#duration').val());
	if(match_time < duration){
		UBox.show('赛事开始时间到结束时间的时长不能小于'+duration+'分钟', -1);
		return false;
	}
}


//实例化编辑器
var ue = UM.getEditor('rule', {
	imageUrl : '?m=Match&a=ueditorUpload',
	imagePath : '<?php echo SYSTEM_RESOURCE_URL . MATCH_RULE_IMAGE_PATH; ?>'
});

$(function(){
	$("#imgUpload").uploadify({
		'fileTypeExts' : '*.jpg; *.png; *.gif',
		'fileSizeLimit' : '300KB',
		'height' : 30,
		'width' : 100,
		'swf' : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'].$GLOBALS['RESOURCE']['uploadify']['swf']; ?>',
		'uploader' : 'http://<?php echo APP_MANAGE ?>/?m=Match&a=uploadProfile&ajax=1',
		'buttonText' : '选择文件',
		'multi' : true,
		'onUploadSuccess' : function(file, data, response){
			data = eval('(' + data + ');');
			if(data.status == 1){
				$('#profileImg').attr('src', data.data);
				$('#profile').val(data.msg);
				$('#profile_main').show(300);
			}else{
				$('#profile_main').hide();
				$('#profileImg').attr('src', '');
				$('#profile').val('');
				UBox.show(data.msg, -1);
			}
		}
	});
});

//删除图片
function delProfile(){
	var imgName = $('#profile').val();
	if(!imgName){
		return false;
	}

	UBox.confirm('真要的删除吗？', function(){
		$.ajax({
			url:'?m=Match&a=delProfile',
			data:{profile:imgName},
			type:'POST',
			dataType:'JSON',
			success:function(result){
				if(result.status == 1){
					$('#profile').val('');
					$('#profile_main').hide();
					$('#profileImg').attr('src', '');
					UBox.show('删除成功', 1);
				}else{
					UBox.show(result.msg, -1);
				}
			},
			error:function(){
				UBox.show('删除成功',-1)
			}
		});
	});
}

//刷新页面重置表单
$(function(){
	document.getElementById('matchtAdd').reset();
});




//提交表单
function addMatch(){
	if(checkForm() == true){
		$.ajax({
			url: '/?m=Match&a=addMatch',
			data: $('#matchtAdd').serialize(),
			type: 'post',
			dataType: 'json',
			beforeSend: function(){
				$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
			},
			complete:function(){
				$('#submitButton').attr('onclick', 'addMatch()').removeClass('button_loading').html('发布赛事');
			},
			success: function(aResult){
				if(aResult.status == 1 && parseInt(aResult.msg) > 1){
					UBox.show('操作成功,点击下一步', 1, '/?m=Match&a=showEditMatchPrize&id=' + aResult.msg );
				}else{
					UBox.show(aResult.msg, -1);
				}
			},
			error: function(){
				UBox.show('系统错误', 0);
			}
		});
	}
}
</script>