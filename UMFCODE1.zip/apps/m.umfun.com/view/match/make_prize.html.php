<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left;padding-top:10px;padding-bottom:5px; display:none}
		._main .item .grade_div label{padding-right:25px}
		
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;width:60px;}
		._main .item .award_main .award_id{float:left;cursor:default;width:90px;padding:0 5px;border:1px solid #fff}
		._main .item .award_main .award_name{float:left;padding-left:25px;cursor:default;width:80px;}
		._main .item .award_main .award_email{float:left;padding-left:25px;cursor:default;width:160px;}
		._main .item .award_main .award_score{float:left;padding-left:25px;cursor:default;width:60px;}
		._main .item .award_main  .award_input{float:left;width:90px;}
	</style>
	
	
	<form id="matchtEditPrize" autocomplete="off" >
		<input type="hidden" name="matchId" value="<?php echo  $aMatchInfo['id']?>" />
		<div class="title">赛事奖项设置</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">奖项设置：</div>
			<div class="control" id="award_main" >
			<?php
				if(isset($aMatchInfo['awards']['top'])){
					$topCount = count($aMatchInfo['awards']['top']);
			?>
					<div class="award_main">
						<label class="award_text">名 次</label>
						<label class="award_id">会员ID</label>
						<label class="award_name">会员姓名</label>
						<!-- <label class="award_email">会员邮箱</label> -->
						<label class="award_socre">会员得分</label>						
					</div>
					<div class="clear" ></div>
			<?php
					for($i = 1; $i <= $topCount; $i++ ){
			?>
						<div class="award_main">
							<label class="award_text">
								<?php echo $awardsArray[$i];?>：
							</label>
							<label class="award_id">
								<?php echo isset($aAwardsList['top'][$i]) ? $aAwardsList['top'][$i]['user_id'] : ''; ?>
								<input type="hidden" name="top_award_<?php echo $i;?>" value="<?php echo isset($aAwardsList['top'][$i]) ? $aAwardsList['top'][$i]['user_id'] : ''; ?>" />
							</label>
							<label class="award_name">
								<a href="#" title="查看会员详情">
									<?php echo isset($aAwardsList['top'][$i]) ? $aAwardsList['top'][$i]['user_name'] : ''; ?>
								</a>
							</label>
							<!-- <label class="award_email">123456@qq.com</label> -->
							<label class="award_socre">
								<?php echo isset($aAwardsList['top'][$i]['best_score']) ? $aAwardsList['top'][$i]['best_score'] : ''; ?>
							</label>						
						</div>
						<div class="clear" ></div>
			<?php
					}
				}
				if(isset($aMatchInfo['awards']['rand'])){
					$randCount = $aMatchInfo['awards']['rand']['number'];
					for($j = 0; $j < $randCount; $j++ ){
			?>
						<div class="award_main" id="rand_main<?php echo $j;?>">
							<label class="award_text">幸运奖：</label>
								<input type="text" class="award_input" xid="rand" name="rand_award_<?php echo $j;?>" value="<?php echo isset($aAwardsList['rand'][$j]) ? $aAwardsList['rand'][$j]['user_id'] : ''; ?>" title="请输入参赛会员id" onblur="getUserInfo(this.value, 'rand_main<?php echo $j;?>')" />
								<label class="award_name">
									<a href="#">
										<?php echo isset($aAwardsList['rand'][$j]) ? $aAwardsList['rand'][$j]['user_name'] : ''; ?>
									</a>
								</label>
								<!-- <label class="award_email">123456@qq.com</label> -->
								<label class="award_socre">
									<?php echo isset($aAwardsList['rand'][$j]) ? $aAwardsList['rand'][$j]['best_score'] : ''; ?>
								</label>						
						</div>
						<div class="clear" ></div>
			<?php 
					}
				}
						
			?>	
			</div>
		</div>


		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" id="submitButton" />保存获奖名单</a></div>
		</div>
		<div class="clear"></div>
	</form>
</div>

<script type="text/javascript">
	

var aUserList = [];
function getUserInfo(userAccount, userMain){
	var numberReg = /^[1-9]{1}\d*$/;
	if(!userAccount){
		return false;
	}
	if(!numberReg.test(userAccount)){
		$('#' + userMain + ' .award_input').val('');
		$('#' + userMain + ' .award_name').html('');
		$('#' + userMain + ' .award_socre').html('');
		UBox.show('会员ID为正整数', -1);
		return false;
	}

	if(aUserList[userAccount] != undefined){
		$('#' + userMain + ' .award_name').html('<a href="#">' + aUserList[userAccount].user_name + '</a>');
		$('#' + userMain + ' .award_socre').html(aUserList[userAccount].best_score);
		return false;
	}
	$.ajax({
		url : '/?m=Match&a=getUserInfo',
		data:{matchId:<?php echo $aMatchInfo['id']?>, userAccount:userAccount, type:1},
		type:'POST',
		dataType:'JSON',
		success:function(aResult){
			if(aResult.status != 1){
				$('#' + userMain + ' .award_input').val('');
				UBox.show(aResult.msg, -1);
				return false;
			}else{
				var aUser = aResult.data;
				aUserList[userAccount] = aUser; 
				$('#' + userMain + ' .award_name').html('<a href="#">' + aUser.user_name + '</a>');
				$('#' + userMain + ' .award_socre').html(aUser.best_score);
			}
		},
		error:function(){
			UBox.show('系统错误', 0);
			return false;
		}
	});
}			
		
	

var aTopWinners;
<?php 
	if(isset($aAwardsList['top'])) {
?>
	aTopWinners =<?php echo json_encode($aAwardsList['top']); ?>;
<?php	
	} 
?>
	
//提交
function mkPrize(){
	var randList = [];
	$('[xid=rand]').each(function(){
		if($(this).val() != ''){
			var userId = $(this).val();
			if(randList[userId]){
				randList[userId]++;
			}else{
				randList[userId] = 1;
			} 	
		}	
	});
		
	for(var i in randList){
		if(randList[i] > 1){
			UBox.show('ID 为  ' + i + ' 的会员不能获得多次幸运奖哦', -1);
			return false;
		}
		for(var j in aTopWinners){
			if(aTopWinners[j].user_id == i){
				UBox.show('ID 为  ' + i + ' 的会员不能同时获得排名奖和幸运奖哦', -1);
				return false;
			}
		}
	}

	UBox.confirm('确定上面会员就是这次比赛的获奖者吗?', function(){
		$.ajax({
			url : '/?m=Match&a=makePrize',
			type : 'POST',
			dataType : 'JSON',
			data : $('form').serialize(),
			beforeSend : function(){
				$('#submitButton').unbind() .attr('style','background-color:#999').html('处理中...');
			},
			complete : function(){
				$('#submitButton').bind('click', function(){mkPrize();}) .attr('style','background-color:#333').html('保存获奖名单');
			},
			success : function(aResult){
				if(aResult.status != 1){
					UBox.show(aResult.msg, -1);
					return false;
				}else{
					UBox.show('操作成功!', 1, '/?m=Match&a=showMatchList', 2);
				}
			},
			error : function(){
				UBox.show('系统错误', 0);
				return false;
			}
		});
	});
}


//提交表单
$('#submitButton').click(function(){
	mkPrize();
});


</script>