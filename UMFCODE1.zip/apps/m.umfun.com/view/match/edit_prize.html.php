<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left;padding-top:10px;padding-bottom:5px; display:none}
		._main .item .grade_div label{padding-right:25px}
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		._subject span{margin-right:15px; display:inline-block;}
		._main .item .control #match_name{width:450px;}
		._main .item .control #description{width:450px;height:65px}
		._mian .item .profile_main{border:1px solid red;width:130px;height:90px;border:1px solid red;position:absolute; left:240px;top:-70px;}
		._main .item .control .button_loading{ background-color: #666}
		._main .item .radio_div{margin-left:15px;margin-right: 5px;}
	</style>
	<form id="matchtEditPrize" class="addForm" autocomplete="off">

		<div class="title">赛事奖项设置</div>

		<div class="item">
			<div class="name">奖品描述：</div>
			<div class="control" >
				<textarea name="description" id="description" rows="5"><?php echo $aMatchInfo['description']; ?></textarea>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">奖项设置：</div>
			<div class="control" id="award_main">
			<?php  
			$topCount = 0;
			$topAwards = array();
			if(isset($aMatchInfo['awards']['top'])){
				$topAwards = $aMatchInfo['awards']['top'];
				$topCount = count($topAwards);
				
			}

				foreach($awardsArray as $key => $awardInfo){
					
			?>
					<div class="award_main" id="top<?php echo $key?>" <?php  if($topCount > 5){if($key > $topCount){echo "style='display:none'";}}else{if($key > 5){echo "style='display:none'";}}?>>
						<label class="award_text"><?php echo $awardInfo;?></label>
						<label class="award_sub">金币：</label>
							<input type="text" class="award_input" id="top<?php echo $key?>_gold" name="top<?php echo $key?>_gold" value="<?php echo isset($topAwards[$key]['gold']) ? ($topAwards[$key]['gold'] > 0 ? $topAwards[$key]['gold'] : '' ) : '' ?>" />
						<label class="award_sub">实物：</label>
							<input type="text"  id="top<?php echo $key?>_prize" name="top<?php echo $key?>_prize" value="<?php echo isset($topAwards[$key]['prize']) ? $topAwards[$key]['prize'] : ''?>" />
						<?php 
							if($key == 1){
								if($topCount > 5){
									echo '<a href="javascript:void(0)" id="addAward" onclick="javascript:addAward(' . ($topCount+1). ')">添加</a>';	
								}else{
									echo '<a href="javascript:void(0)" id="addAward" onclick="javascript:addAward(6)">添加</a>';
								}
							}
						?>
						<?php 
							if($topCount > 5){
								if($key == $topCount){
									echo '<a id="delAward" href="javascript:delAward('.$key.')">删除</a>';
								}		
							}else{
								if($key == 5){
									echo '<a id="delAward" href="javascript:delAward(5)">删除</a>';
								}
							}
						?>
							
						
					</div>
					<div class="clear" id="topClear<?php echo $key?>"></div>
			<?php
				}
				echo '<input type="text" name="awardNum" id="awardNum" style="display:none" value="5"  />';
			?>
				<div class="award_main" id="luckly">
					<label class="award_text">幸运奖</label>
					<label class="award_sub">从排名第</label><input type="text"  class="award_input" id="luckly_start" name="luckly_start" value="<?php echo isset($aMatchInfo['awards']['rand']['ranking_rate'][0]) ? $aMatchInfo['awards']['rand']['ranking_rate'][0] : ''?>" />
					<label class="explain_label" >名到第</label><input type="text"  class="award_input" id="luckly_end" name="luckly_end" value="<?php echo isset($aMatchInfo['awards']['rand']['ranking_rate'][1]) ? $aMatchInfo['awards']['rand']['ranking_rate'][1] : ''?>"  />
					<label class="explain_label">名内抽取</label><input type="text"  class="award_input"  id="luckly_count" name="luckly_count" value="<?php echo isset($aMatchInfo['awards']['rand']['number']) ? $aMatchInfo['awards']['rand']['number'] : ''?>" />
					<label class="explain_label">个名额作为幸运奖</label>
					<label class="award_sub">金币：</label><input type="text" class="award_input" id="luckly_gold" name="luckly_gold" value="<?php echo isset($aMatchInfo['awards']['rand']['gold']) ? ($aMatchInfo['awards']['rand']['gold'] > 0 ? $aMatchInfo['awards']['rand']['gold'] : '')  : '';?>" />
					<label class="award_sub">实物：</label><input type="text"  id="luckly_prize" name="luckly_prize" value="<?php echo isset($aMatchInfo['awards']['rand']['prize']) ? $aMatchInfo['awards']['rand']['prize'] : ''?>" />
				</div>
			</div>
		</div>

		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<a class="button" id="submitButton" onclick="setPrize()"/>保存奖项</a>
			</div>
			<div class="control radio_div" >
				<input type="radio" name="nex_step" id="match_list" checked="checked" /><label for="match_list">保存后去 赛事列表</label>
			</div>
			<div class="control radio_div" >
				<input type="radio" name="nex_step" id="match_basic" /><label for="match_basic">保存后去 基本信息设置</label>
			</div>
			<div class="control radio_div">
				<input type="radio" name="nex_step" id="match_topic"/><label for="match_topic">保存后去 题目设置</label>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>

<script type="text/javascript">
<?php echo $validateAddMatchJs; ?>

//验证
function _after_checkForm(){
	var numberReg = /^[1-9]{1}\d*$/;
	var luckly_start = $('#luckly_start').val();
	var luckly_end = $('#luckly_end').val();
	var luckly_count = $('#luckly_count').val();
	var luckly_gold = $('#luckly_gold').val();
	var luckly_prize = $('#luckly_prize').val();
	
	if(!numberReg.test(luckly_start)){
		UBox.show('幸运奖的开始名次为正整数', -1);
		return false;
	}

	if(!numberReg.test(luckly_end)){
		UBox.show('幸运奖的结束名次为正整数', -1);
		return false;
	}

	if(!numberReg.test(luckly_count)){
		UBox.show('幸运奖的名额为正整数', -1);
		return false;
	}

	luckly_start = parseInt(luckly_start);
	luckly_end = parseInt(luckly_end);
	luckly_gold = parseInt(luckly_gold);

	if((luckly_end - luckly_start) < luckly_count){
		UBox.show('从'+luckly_start+'名到'+luckly_end+'名抽不出这么多名额', -1);
		return false;
	}

	if(!luckly_gold && !luckly_prize){
		UBox.show('幸运奖至少要有一种奖励', -1);
		return false;
	}

	if(luckly_gold){
		if(!numberReg.test(luckly_gold)){
			UBox.show('幸运奖的金币奖励格式错误', -1);
			return false;
		}
	}
	return true;
}

//奖项添加
var awardCount = <?php echo count($awardsArray);?>;

function addAward(id){
	if(id <= awardCount){
		$('#delAward').remove();
		$('#top'+id+'_prize').after('<a id="delAward" href="javascript:delAward('+id+')">删除</a>');
		$('#top'+id).show(50);
		var next = parseInt(id+1);
		if(next <= awardCount){
			$('#addAward').attr('onclick', 'javascript:addAward('+next+')');
		}
		$('#awardNum').val(id);
	}

}

//奖项删除
function delAward(id){
	if(1 < id < awardCount){
		$('#top'+id+'_gold').val('');
		$('#top'+id+'_prize').val('');
		$('#top'+id).hide(50);
		$('#delAward').remove();
		$('#addAward').attr('onclick', 'javascript:addAward('+id+')');
		var prive = parseInt(id-1);
		if(prive > 1){
			$('#top'+prive+'_prize').after('<a id="delAward" href="javascript:delAward('+prive+')">删除</a>');
		}
		$('#awardNum').val(prive);
	}
	
}


//验奖项
function _after_description(){
	var awardNum = parseInt($('#awardNum').val());
	var numberReg = /^[1-9]{1}\d*$/;
	for(var i=1; i <= awardNum; i++){
		var gold = $('#top'+i+'_gold').val();
		var prize = $('#top'+i+'_prize').val();

		if(!gold && !prize){
			UBox.show('第'+i+'名至少要有一种奖励', -1);
			return false;
		}
		if(gold){
			if(!numberReg.test(gold)){
				UBox.show('第'+i+'名的金币奖励格式填写错误', -1);
				return false;
			}
		}
	}
	return true;
}


//提交表单
function setPrize(){
	if(checkForm() == true){
		var matchId = <?php echo $aMatchInfo["id"]; ?>;
		$.ajax({
			url: '?m=Match&a=editMatchPrize&id=' + matchId,
			type: 'post',
			dataType: 'json',
			data: $('#matchtEditPrize').serialize(),
			beforeSend: function(){
				$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
			},
			complete: function(){
				$('#submitButton').attr('onclick', 'setPrize()').removeClass('button_loading').html('保存奖项');
			},
			success: function(aResult){
				if(aResult.status == 1){
					var msg = '操作成功 点击回列表';
					var afterUrl = '/?m=Match&a=showMatchList';
					var after = $('input[type="radio"]:checked').attr('id');
					if(after == 'match_basic'){
						msg = '操作成功 点击进行基本信息设置';
						afterUrl = '/?m=Match&a=showEditMatchBasic&id=' + matchId;
					}else if(after == 'match_topic'){
						msg = '操作成功 点击进行题目设置';
						afterUrl = '/?m=Match&a=showEditMatchTopic&id=' + matchId;
					}
					UBox.show(msg, 1, afterUrl);
				}else{
					UBox.show(aResult.msg, -1);
				}
			},
			error: function(){
				UBox.show('系统错误', 0);
			}
		});
	}
}

</script>