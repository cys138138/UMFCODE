<?php display('match/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .w60{width:80px;}
		._main .item .c000{color:#000}
	</style>
	
	
	<form id="matchtEditPrize" class="addForm" method="post" action="#<?php echo $aMatchInfo['id'] ?>">

		<div class="title">参赛会员得分设置</div>
		<div class="clear" style="height:15px;"></div>
		<div class="item">
			<div class="name">赛事名称：</div>
			<div class="control" style="font-size:16px;color:#000" ><?php echo $aMatchInfo['name'];?></div>
		</div>
		<div class="clear" style="height:15px;"></div>
		<div class="item">
			<div class="name">ID或Email：</div>
			<div class="control">
				<input type="text" id="user_account" />
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" id="get_user_btn" onclick="getUserInfo();">搜素</a>
			</div>
		</div>
		<div class="clear" style="height:22px;"></div>
		<div class="item" id="user_info" style="display:none">
			<div class="name">邮 箱：</div>
			<div class="control c000" id="user_email">
			</div>
			<div class="name w80">姓名：</div>
			<div class="control c000" id="user_name">
			</div>
			<div class="name w80">得 分：</div>
			<div class="control">
				<input type="text" id="user_score" maxlength="5">
				<input type="hidden" id="relation_id" />
			</div>
			<div class="blank"></div>
			<div class="control"><a class="button" id="save_score" onclick="saveScore()" />保存</a></div>
			<i id="tips"></i>
		</div>
		<div class="clear"></div>
	</form>
</div>


<script type="text/javascript">

function getUserInfo(){
	var userAccount = $('#user_account').val();
	var numberReg = /^[1-9]{1}\d*$/;
	var emailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	var type = 0;
	if(numberReg.test(userAccount)  ){
		type = 1;
	}
	if(emailReg.test(userAccount)  ){
		type = 2;
	}
	if(type != 1 && type != 2){
		UBox.show('帐号输入错误', -1);
		hidenUserInfo();
		return false;
	}
	
	$.ajax({
		url : '/?m=Match&a=getUserInfo',
		data:{type:type, matchId:<?php echo $aMatchInfo['id']?>, userAccount:userAccount},
		type:'POST',
		dataType:'JSON',
		beforeSend:function(){
			$('#get_user_btn').attr('onclick', '') .attr('style','background:#999');
			$('#get_user_btn').html('处理中...');
		},
		complete:function(){
			$('#get_user_btn').attr('onclick', 'getUserInfo()') .attr('style','background:#333');
			$('#get_user_btn').html('搜素');
		},
		success:function(aResult){
			if(aResult.status != 1){
				hidenUserInfo();
				UBox.show(aResult.msg, -1);
				return false;
			}else{
				var aUser = aResult.data;
				$('#user_email').html(aUser.user_email);
				$('#user_name').html(aUser.user_name);
				$('#user_score').val(aUser.best_score);
				$('#relation_id').val(aUser.relation_id);
				$('#user_info').slideDown('normal');
			}
		},
		error:function(){
			UBox.show('系统错误', 0);
			hidenUserInfo();
			return false;
		}
	})
}			

function hidenUserInfo(){
	$('#user_info').slideUp('normal');
	$('#user_email').html('');
	$('#user_name').html('');
	$('#user_score').val('');
	$('#relation_id').val('');
	
}


function saveScore(){
	var relationId = $('#relation_id').val();
	var userScore = $('#user_score').val();
	var numberReg = /^[1-9]{1}\d*$/;
	if(!numberReg.test(relationId) || !numberReg.test(userScore)){
		UBox.show('数据错误', -1);
		return false;
	}

	UBox.confirm('确定修改该用户的这场比赛在得分吗？', function(){
		$.ajax({
			url:'/?m=Match&a=editMatchScore',
			type:'POST',
			data:{relationId:relationId, userScore:userScore},
			dataType:'JSON',
			beforeSend:function(){
				$('#save_score').attr('onclick', '') .attr('style','background:#999');
				$('#save_score').html('处理中...');
			},
			complete:function(){
				$('#save_score').attr('onclick', 'saveScore()') .attr('style','background:#333');
				$('#save_score').html('保存');
			},
			success:function(aResult){
				if(aResult.status != 1){
					UBox.show(aResult.msg, -1);
					return false;
				}else{
					UBox.show('修改成功!', 1, '/?m=Match&a=showMatchList', 2);
				}
			},
			error:function(){
				UBox.show('系统错误', 0);
				return false;
			}
		});
	});
	
	

	
}

		
//刷新页面重置表单		
$(function(){
	document.getElementById('matchtEditPrize').reset();
	$('#user_score').keyup(function(){
		if(this.value <= 0 || this.value > 10000 || !$.isNumeric(this.value)){
			this.value = '';
			$('#tips').text(' 请输入0~10000之间的整数').css('color', 'red').show();
			setTimeout(function(){
				$('#tips').hide();
			}, 3000);
		}
	});
})		



//提交表单
$('#submitButton').click(function(){
	if(checkPrize() == true){
		if(checkLuckly() == true){
			$('#matchtEditPrize').submit();
		}
	}
})


</script>