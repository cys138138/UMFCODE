<h2>
<?php echo $message; ?>
<!--抱歉，本次请求发生错误，系统已经记录并通知技术人员修复，请稍后再试！-->
</h2>
<a href="javascript:history.go(-1);" onclick="">返回上一页</a>
<a href="javascript:location.reload(true);" onclick="">刷新重试</a>