<?php display('prop/nav.html.php'); ?>

<style type="text/css">
	._condition .item a{color:#999; margin-right:10px;}
	._condition .item .on{font-weight:bold; color:#000;}
	._condition .name{width:65px;}
	._condition .control input{width:140px;}
	._condition a.button{color:#FC0; margin-left:5px;}

	._esList .row{clear:both;}
	._esList .row .c1{width:3%;}
	._esList .row .c2{width:7%;}
	._esList .row .c3{width:4%;}
	._esList .row .c4{width:5%;}
	._esList .row .c5{width:12%;}
	._esList .row .c6{width:7%;}
	._esList .row .c7{width:4%;}
	._esList .row .c8{width:4%;}
	._esList .row .c9{width:14%;}
	._esList .row .c10{width:5%;}
	._esList .row .c11{width:5%;}
	._esList .row .c12{width:5%;}
	._esList .row .c13{width:8%;}
	._esList .row .c14{width:4%;}
	._esList .row .c13 a{margin-right:10px;}
	._esList .blue{color:blue;}
	._esList .red{color:red;}
	._esList .green{color:green;}
	._esList ._opeartion{width:auto; margin-right:8px; float:left;}

	.wrapEs{padding:0 10px;}
	.wrapEs .module{margin:10px 0;}
	.wrapEs.module{ display:none;}
	.wrapEs ._es_{margin-bottom:5px; border-top:1px solid #ddd; border-bottom:1px solid #ddd;}
	.wrapEs ._es_ ._esText_{margin-bottom:0; padding:2px 0; border-bottom:1px solid #ddd; background:#F5F5F5; overflow: hidden;}
	.wrapEs ._es_ ._esText_ .control{color:#333; font-size:14px; font-weight:bold;}
	.wrapEs .item{width:100%; padding:3px 0; margin:0;}
	.wrapEs .item:hover .control{color:#000;}
	.wrapEs .item_even{background-color:#f7f7f7;}
	.wrapEs .name{width:70px; color:#333; font-weight:bold; margin-right:10px;}
	.wrapEs ._options_{padding:6px 0 6px 75px; background:#fafafa;}
	.wrapEs ._options_ ._option_{padding:8px 0 8px 52px;}
	.wrapEs ._options_ ._optionImage_{padding-left:28px;}
	.wrapEs ._options_ ._optionImage_ img{margin-top:5px;}
	.wrapEs img{max-width:400px;}
	.wrapEs .module .item{margin:0;}
	.wrapEs .title{height:34px; border-bottom:2px solid #ddd; font-size:16px; margin:0; margin-bottom:20px;}
	.wrapEs .title span{height:34px; float:left; border-bottom:2px solid #EFBA03; display:block; padding:0 2px; color:#444;}
	.wrapEs .correct i, .wrapEs .error i{font-size:14px; font-weight:bold; font-style:normal; margin-left:5px; font-family:SimHei;}
	.wrapEs .correct{color:#008000;}
	.wrapEs .error{color:#f00;}
	.wrapEs ._options_{padding:0;}
	.wrapEs ._option_:hover{color:#000;}
	.wrapEs ._option_odd{background-color:#f5f5f5;}
	.wrapEs ._optionContent_ b{width:2px; height:2px; display:inline-block; overflow:hidden; font-size:0; line-height:2px; background-color:#777; margin:0 15px 0 3px;}
	.clear{height:0; font-size:0; line-height:0; overflow:hidden;}
	.wrapEs ._esImage_{padding:5px 0 5px 80px;}
	.wrapEs ._fillBlanks_ .control{color:#333;}
	.wrapEs .isanswer{border-bottom:1px solid #333; margin:0 5px; color:#008000; padding:0 4px 1px 4px;}
	.wrapEs .isanswer b{color:#333; margin:0 7px;}
	.wrapEs ._esImage_ span{display:inline-block; *zoom:1; text-align:center; vertical-align:bottom; margin:5px 20px 5px 0;}
	.wrapEs ._esImage_ span  img{margin-bottom:5px;}
	.wrapEs .module .control{float:none; font-weight:normal; line-height:16px; padding:5px 20px 5px 80px;}
	.control{word-wrap:break-word; word-break:normal;}
	.MathJax_SVG_Display{width:auto;text-align:left;display:inline-block;margin:0;}
	._esImage_ span, ._optionImage_ span{display:inline-block;zoom:1;text-align:center;margin:5px 5px 0 0;}
	._esImage_ span img, ._optionImage_ span img{margin-bottom:5px;}
</style>
	<div class="module _condition">
		<div class="item">
			<div class="name">状态：</div>
			<div class="control">
				<a <?php if($status == -1){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectStatus(-1)">全部</a>
				<a <?php if($status == 1){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectStatus(1)">上架</a>
				<a <?php if($status == 0){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectStatus(0)">下架</a>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	
	<div class="module _condition">
		<div class="item">
			<div class="name">货币类型：</div>
			<div class="control">
				<a <?php if($moneyType == 0){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectMoney(0)">全部</a>
				<a <?php if($moneyType == 1){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectMoney(1)">金币</a>
				<a <?php if($moneyType == 2){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectMoney(2)">U币</a>
			</div>
		</div>
		<div class="clear"></div>
	</div>

	
	<div class="module _condition">
		<div class="item">
			<div class="name">类型：</div>
			<div class="control">
				<a <?php if($type == 0){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(0)">全部</a>
				<a <?php if($type == 1){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(1)">闯关</a>
				<a <?php if($type == 2){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(2)">通用答题</a>
				<a <?php if($type == 3){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(3)">PK</a>
				<a <?php if($type == 4){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(4)">比赛</a>
				<a <?php if($type == 5){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(5)">经验</a>
				<a <?php if($type == 6){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(6)">扩容</a>
				<a <?php if($type == 7){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(7)">装扮</a>
				<a <?php if($type == 8){ ?> class="on" <?php } ?> href="javascript:void(0)" onclick="selectType(8)">道具包</a>
			</div>
		</div>
		<div class="clear"></div>
	</div>

	<div class="clear"></div>
</div>

<div class="title">道具管理</div>

<div class="module _esList">
	<div class="list">
		<div class="row header">
			<div class="c1">编号</div>
			<div class="c2">道具名</div>
			<div class="c3">图标</div>
			<div class="c4">类型</div>
			<div class="c5">描述</div>
			<div class="c6">标记</div>
			<div class="c7">价格</div>
			<div class="c8">折扣</div>
			<div class="c9">折扣时间</div>
			<div class="c14">VIP折扣</div>
			<div class="c10">购买量</div>
			<div class="c11">使用量</div>
			<div class="c12">上架</div>
			<div class="c13">操作</div>
		</div>
		
		<?php
		foreach($aPropList as $aProp){
		?>
		<div title="" class="row">
			<div class="c1"><?php echo $aProp['id']; ?></div>
			<div class="c2"><?php echo $aProp['name']; ?></div>
			<div class="c3"><img src="<?php echo SYSTEM_RESOURCE_URL . '/' . $aProp['ico']; ?>" width="60"></div>
			<div class="c4"><?php echo $GLOBALS['PROP_TYPE_NAME'][$aProp['type']]; ?></div>
			<div class="c5">
			<?php 
			$aDecript = explode('---', $aProp['description']);
			echo '使用范围 ：' . $aDecript[0] . '<br>功效：' . $aDecript[1];
			?>
			</div>
			<div class="c6"><?php echo $aProp['prop_code']; ?></div>
			<div class="c7">
			<?php 
			if($aProp['money_type'] == 1){
				$money = '金币';
			}elseif($aProp['money_type'] == 2){
				$money = 'U币';
			}
			echo $aProp['price'] . $money;
			?>
			</div>
			<div class="c8">
			<?php 
			if($aProp['discount'] < 100){
				echo $aProp['discount'] . '折';
			}else{
				echo '未打折';
			}
			?>
			</div>
			<div class="c9">
			<?php 
			if($aProp['discount_start_time']){
				echo '开始：' . date('Y-m-d H:i', $aProp['discount_start_time']) . '<br>';
			}else{
				echo '开始：---<br>';
			}
			if($aProp['discount_end_time']){
				echo '结束：' . date('Y-m-d H:i', $aProp['discount_end_time']);
			}else{
				echo '结束：---<br>';
			}
			?>
			</div>
			<div class="c14"><?php echo $aProp['vip_discount']; ?></div>
			<div class="c10"><?php echo $aProp['purchase_total']; ?></div>
			<div class="c11"><?php echo $aProp['use_total']; ?></div>
			<div class="c12">
			<?php 
			if($aProp['is_publish'] == 1){
				echo '上架';
			}else{
				echo '下架';
			}
			?>
			</div>
			<div class="c13">
			<?php
			$operation = '<a href="?m=Prop&a=showEdit&id=' . $aProp['id'] . '">编辑</a> &nbsp; &nbsp;';
			if($aProp['is_publish'] == 1){
				$operation .= '<a onclick="changeStatus(' . $aProp['id'] . ')" href="javascript:void(0)">下架</a> &nbsp; &nbsp;';
			}else{
				$operation .= '<a onclick="changeStatus(' . $aProp['id'] . ')" href="javascript:void(0)">上架</a> &nbsp; &nbsp;';
			}
			echo $operation;
			?>
			</div>
		</div>
		<?php
		}
		?>
		<div class="row footer">
			<style type="text/css">
				.bathSubmit{float: left; line-height: 30px;}
				.leftButton{float:left; margin-right:7px;}
			</style>

			<?php //echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	var url = '<?php echo $baseUrl; ?>';
	var status = -1;
	var moneyType = 0;
	var type = 0;
	
	function selectStatus(val){
		status = val;
		select();
	}
	
	function selectMoney(val){
		moneyType = val;
		select();
	}
	
	function selectType(val){
		type = val;
		select();
	}
	
	function select(){
		url += '&status=' + status + '&type=' + type + '&moneyType=' + moneyType;
		window.location.href = url;
	}
	
	function changeStatus(id){
		$.ajax({
			url : '?m=Prop&a=changeStatus',
			data : {
				id : id,
			},
			type : 'POST',
			dataType : 'JSON',
			success:function(result){
				UBox.show(result.msg, result.status);
				if(result.status == 1){
					window.location.href = result.data;
				}
			}
		});
	}
</script>