<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>


<?php display('prop/nav.html.php'); ?>

<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left; display:block}
		._main .item .grade_div label{padding-right:25px}
		
		
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		
		._subject span{margin-right:15px; display:inline-block;}
		
		
		._main .item .control #match_name{width:450px;}
		._main .item .control #description{width:450px;height:20px}
		._mian .item .profile_main{border:1px solid red;width:130px;height:90px;border:1px solid red;position:absolute; left:240px;top:-70px;}
		._mian .item .left{float:left;}	
		select{margin-right:15px;padding:0 3px;}
		
	</style>
	<div class="addForm">
		<div class="title">新增道具</div>
		<div class="item">
			<div class="name">道具名称：</div>
			<div class="control"><input type="text" name="prop_name" id="prop_name" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">道具标记：</div>
			<div class="control"><input type="text" name="mark" id="mark" />道具的标记，配置用,谨慎修改</div>
		</div>
		<div class="clear"></div>
		
		<div class="item" style="position:relative;overflow:visible">
			<div class="name">道具图标：</div>
			<div class="control" style="overflow:hidden">
				<input type="file" name="imgUpload" id="imgUpload" />
				图片大小应小于300KB，最大宽度不能超过200PX
			</div>
			<div id="profile_main" style="border:1px solid #ccc;width:130px;height:90px;position:absolute; left:400px;top:-60px;display:none">
				<a href="javascript:void(0)" onclick="javascript:deleteImage()" title="删除" style="position:absolute;right:-3px;top:-17px;" >删除</a>
				<img id="profileImg" style="width:130px;height:90px" />
			</div>
			<input type="text" name="profile" id="profile" style="display:none"  />	
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">道具类型：</div>
			<div class="control">
				<select name="type" id="type">
					<option value="1">闯关答题</option>
					<option value="2">通用答题道具</option>
					<option value="3">PK道具</option>
					<option value="4">比赛道具</option>
					<option value="5">经验道具</option>
					<option value="6">扩容道具</option>
					<option value="7">装扮道具</option>
					<option value="8">道具包</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">道具描述：</div>
			<div class="control"><input type="text" name="description" id="description" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">使用范围：</div>
			<div class="control">
				<select name="range" id="range">
					<option value="通用答题">通用答题</option>
					<option value="修炼">修炼</option>
					<option value="闯关">闯关</option>
					<option value="PK">PK</option>
					<option value="比赛">比赛</option>
					<option value="所有">所有</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">价格：</div>
			<div class="control">
				<input type="text" name="price" id="price" />
				<select name="money_type" id="money_type">
					<option value="1">金币</option>
					<option value="2">U币</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">折扣：</div>
			<div class="control"><input type="text" name="discount" id="discount" />1到100之间,100表示不打折</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">折扣时间：</div>
			<div class="control">
			 	<input type="text" name="start_time" id="start_time" class="left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" />
				<label style="float:left;color:#666;padding:0 8px;">----</label>
				<input type="text" name="end_time" id="end_time" class="left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})"/>在折扣时间范围内，折扣才起作用
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">VIP折扣：</div>
			<div class="control"><input type="text" name="vip_discount" id="vip_discount" />1到100之间，折上折</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">上架：</div>
			<div class="control">
				<select name="is_publish" id="is_publish">
					<option value="0">暂不上架</option>
					<option value="1">马上上架</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" id="submitButton" onclick="submit();"/>添加道具</a></div>
		</div>
		<div class="clear"></div><BR><BR>
	</div>
	
</div>
<script type="text/javascript">
	$(function(){
		$("#imgUpload").uploadify({
			'fileTypeExts' : '*.jpg; *.png; *.gif',
			'fileSizeLimit' : '300KB',
			'height' : 30,
			'width' : 100,
			'swf' : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'].$GLOBALS['RESOURCE']['uploadify']['swf']; ?>',
			'uploader' : 'http://<?php echo APP_MANAGE ?>/?m=Prop&a=uploadImage&ajax=1',
			'buttonText' : '选择文件',
			'method' : 'POST',
			'formData' : {},
			'onUploadStart' : function(event, queueID, fileObj){
				var mark = $.trim($('#mark').val());
				if(!mark || mark == ''){
					UBox.show('请先填写道具标记', -1);
					return false;
				}
				$('#imgUpload').uploadify('settings','formData', {'mark': mark});
			},
			'onUploadSuccess' : function(file, data, response){
				data = eval('(' + data + ');');
				if(data.status == 1){
					$('#profileImg').attr('src', data.msg);
					$('#profile').val(data.data);
					$('#profile_main').show(300);
				}else{
					$('#profile_main').hide();
					UBox.show(data.msg, -1);
				}
			}
		});
	});
	
	function deleteImage(){
		$('#profile_main').hide();
		$('#profile').val('');
		$('#profileImg').attr('src', '');
	}
	
	function submit(){
		var propName = $.trim($('#prop_name').val());
		var profile = $.trim($('#profile').val());
		var description = $.trim($('#description').val());
		var range = $('#range').val();
		var mark = $.trim($('#mark').val());
		var moneyType = $('#money_type').val();
		var price = $('#price').val();
		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();
		var discount = $('#discount').val();
		var vipDiscount = $('#vip_discount').val();
		var isPublish = $('#is_publish').val();
		var type = $('#type').val();
		
		if(!propName || propName == ''){
			UBox.show('请填写道具名称', -1);
			return;
		}
		if(!profile || profile == ''){
			UBox.show('请上传道具图标', -1);
			return;
		}
		if(!description || description == ''){
			UBox.show('请填写道具描述', -1);
			return;
		}
		if(!range || range == ''){
			UBox.show('请选择道具使用范围', -1);
			return;
		}
		if(!mark || mark == ''){
			UBox.show('请填写道具标记', -1);
			return;
		}
		if(moneyType != 1 && moneyType != 2){
			UBox.show('请选择货币类型', -1);
			return;
		}
		if(!(price > 0)){
			UBox.show('价格必须是大于0的数字', -1);
			return;
		}
		if(!(discount > 0 && discount <= 100)){
			UBox.show('折扣必须是大于0小于等于100', -1);
			return;
		}
		if(discount < 100){
			if(!startTime || startTime == ''){
				UBox.show('请填写折扣开始时间', -1);
				return;
			}
			if(!endTime || endTime == ''){
				UBox.show('请填写折扣结束时间', -1);
				return;
			}
		}
		if(!(vipDiscount > 0 && vipDiscount < 100)){
			UBox.show('VIP折扣必须是大于0小于100', -1);
			return;
		}
		if(isPublish != 0 && isPublish != 1){
			UBox.show('请选择是否上架', -1);
			return;
		}
		if(type != 1 && type != 2 && type != 3 && type != 4 && type != 5 && type != 6 && type != 7 && type != 8){
			UBox.show('请选择道具类型', -1);
			return;
		}
		
		$.ajax({
			url : '?m=Prop&a=addProp',
			data : {
				propName  :propName,
				profile : profile,
				description : description,
				range : range,
				mark : mark,
				moneyType : moneyType,
				price : price,
				discount : discount,
				startTime : startTime,
				endTime : endTime,
				vipDiscount : vipDiscount,
				isPublish : isPublish,
				type : type
			},
			type : 'POST',
			dataType : 'JSON',
			success:function(result){
				UBox.show(result.msg, result.status);
				if(result.status == 1){
					window.location.href = result.data;
				}
			}
		});
	}

</script>