<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=Prop&a=showList">道具列表</a>
	<a <?php if(get('a') == 'showAdd'){  ?>class="on"<?php } ?> href="?m=Prop&a=showAdd">添加道具</a>

	<?php if(get('a') == 'showEdit'){ ?>
		<a class="on">编辑道具ID:<?php echo get('id'); ?></a>
		<a onclick="javascript:history.go(-1);">返回上一页</a>
	<?php } ?>

</div>
<div class="br"></div>
