<?php displayHeader();?>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>
<?php display('edu_news/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .control .w450{width:450px; float:left;}
		._main .item .control .w650{width:650px; float:left;}
		._main .item .control .buttonLoading{background-color: #666}
		._main .item .control .buttonLoading{ background-color: #666}
		#newsContent{width:900px; height:320px;}
	</style>
	<div class="title">添加资讯</div>
	<div class="clear"></div>
	<form id="newsAdd">
		<div class="item">
			<div class="name">文章标题：</div>
			<div class="control">
				<input type="text" class="w650" id="newsTitle" name="title" value="" />
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">文章分类：</div>
			<div class="control">
				<select name="category" id="categoryId"></select>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">文章内容：</div>
			<div class="control">
				<script type="text/plain" id="newsContent" name="content"></script>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" onclick="newsAdd()" id="addButton">保 存</a></div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">

	var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
	var selectHtml = '<option selected="selected" value="">请选择分类</option>';

	for (var i = 0; i < aCategoryList.length; i++){
		var aCategory = aCategoryList[i];
		selectHtml += '<option value="' + aCategory.id + '">' + aCategory.name + '</option>';
	}
	$('#categoryId').html(selectHtml);


	function checkForm(){
		var reg = /^[\s\S]{1,30}$/;
	    if (!reg.exec($('#newsTitle').val())){
	    	alert('文章标题无效');
	    	return false;
	    }
	    reg = /^[\s\S]{1,10000}$/;
	    if (!reg.exec(oUe.getContent().replace(/<[^>]*>/g, ""))){
	    	alert('文章内容无效');
	    	return false;
	    }
	    return true;
	}

	function newsAdd(){
		if (!checkForm()){
			return false;
		}
		ajax({
			url: '/?m=EduNews&a=add',
			data: $('#newsAdd').serialize(),
			beforeSend: function(){
				$('#addButton').addClass('buttonLoading').html('处理中...').attr('onclick', '');
			},
			success: function(aResult){
				$('#addButton').removeClass('buttonLoading').html('保 存').attr('onclick', 'newsAdd()');
				if(aResult.status == 1){
					UBox.show(aResult.msg, aResult.status, '/?m=EduNews&a=showList');
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error: function(){
				$('#addButton').removeClass('buttonLoading').html('保 存').attr('onclick', 'newsAdd()');
				UBox.show('系统错误', 0);
			}
		});
	}

	var oUe = null;
	$(function(){
		oUe = UM.getEditor('newsContent');
	});

</script>
<?php displayFooter();?>