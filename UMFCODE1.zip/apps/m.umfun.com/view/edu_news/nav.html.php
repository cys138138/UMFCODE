<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=EduNews&a=showList">资讯列表</a>
	<a <?php if(get('a') == 'showAdd'){ ?>class="on"<?php } ?> href="?m=EduNews&a=showAdd">添加资讯</a>
	<?php if(get('a') == 'showEdit'){echo '<a class="on">资讯编辑</a>';}?>
</div>
<div class="br"></div>