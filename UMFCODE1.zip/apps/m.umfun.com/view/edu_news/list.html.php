<?php displayHeader();?>
<?php display('edu_news/nav.html.php'); ?>
<div class="module _newsList">
	<style type="text/css">
		.row .c1{width: 150px;}
		.row .c2{width: 120px;}
		.row .c3{width: 260px;}
		.row .c4{width: 120px;}
		.row .c10{width: 70px;}
		.row .c10 a{padding-right: 6px;}
	</style>
	<div class="title">资讯列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">文章标题</div>
			<div class="c2">文章分类</div>
			<div class="c3">文章内容</div>
			<div class="c4">创建时间</div>
			<div class="c10 right">操作</div>
		</div>
		<div id="content"></div>

		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">

	var aEduNewsList = <?php echo json_encode($aEduNewsList); ?>,
		aCategoryList = <?php echo json_encode($aCategoryList); ?>,
		contentHtml = '';

	for (var i = 0; i < aEduNewsList.length; i++){
		var aEduNews = aEduNewsList[i];
		contentHtml += '<div class="row content">\
							<div class="c1">' + (aEduNews.title ? aEduNews.title : '&nbsp;') + '</div>\
							<div class="c2">\
								<a href="?m=EduNews&a=showList&category=' + aCategoryList[aEduNews.category_id - 1].id + '">' + (aCategoryList[aEduNews.category_id - 1].name ? aCategoryList[aEduNews.category_id - 1].name : '&nbsp;') + '</a>\
							</div>\
							<div class="c3">' + (aEduNews.content ? aEduNews.content.replace(/<[^>]*>/g, "").substr(0, 30) : '&nbsp;') + '</div>\
							<div class="c4">' + date('Y-m-d H:i:s', aEduNews.create_time) + '</div>\
							<div class="c10 right">\
								<a href="?m=EduNews&a=showEdit&id=' + aEduNews.id + '">编辑</a>\
								<a href="javascript:void(0)" onclick="delEduNewsById(' + aEduNews.id + ')">删除</a>\
							</div>\
						</div>'
	}
	$('#content').html(contentHtml);

	function delEduNewsById(id){
		UBox.confirm('确定删除这条资讯吗?', function(){
			ajax({
				url : '/?m=EduNews&a=delete',
				data : {videoId : id},
				success : function(aResult){
					if(aResult.status == 1){
						window.location.reload();
					}
					else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(){
					UBox.show('系统错误', 0);
				}
			});
		});
	}

</script>
<?php displayFooter();?>