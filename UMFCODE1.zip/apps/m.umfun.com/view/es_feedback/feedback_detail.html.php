<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="http://s.umfun.com/view3/plugin/esp/esp.js?v=11"></script>
<?php display('es_feedback/feedback_nav.html.php'); ?>
<div class="module _feedback">
	<div class="title">题目反馈详情</div>
	<div class="item _esContent subject_<?php echo $subjectId; ?>">
		<div class="control wrapEs es_content" id="orgContent"></div>
	</div>
	<div class="clear"></div>
</div>

<script type="text/javascript">
Esp.config({
	shuffleChoise : false
});
</script>

<div class="module _feedback">
	<style type="text/css">
		._reason .row .c1{width:40px;}
		._reason .row .c1 label{font-size:11px;}
		._reason .row .c2{width:80px;}
		._reason .row .c3{width:80px;}
		._reason .row .c4{width:80px;}
		._reason .row .c5{width:300px; white-space:normal; word-break:break-all; word-wrap:break-word;}
		._reason .row .c6 input{width:200px;}
		._reason .row label{min-height:26px; height:auto; }
		._reason ._handle .control .button{margin:0 10px;}
		._reason ._handle .control input{width:30px;padding:0 20px;}
		textarea,input[type=text]{font-size:16px;}
	</style>
	<div class="list _reason">
		<div class="row header">
			<div class="c1">&nbsp;&nbsp;</div>
			<div class="c2">反馈者</div>
			<div class="c3">反馈者id</div>
			<div class="c4">来自</div>
			<div class="c5">反馈原因</div>
			<div class="c5">用户作答答案</div>
			<div class="c5">回复</div>
		</div>
		<?php foreach($aEsFeedbackInfo as $aEsFeedback){ ?>
			<div class="row" xid="user" data-user_type="<?php echo $aEsFeedback['user_type']; ?>" data-user_id="<?php echo $aEsFeedback['user_id']; ?>" data-feedback_id="<?php echo $aEsFeedback['id']; ?>" data-username="<?php echo $aEsFeedback['user_name']; ?>">
				<div class="c1">
					<input checked="checked" type="checkbox" xid="feedback" id="feedback<?php echo $aEsFeedback['id']; ?>" />
				</div>
				<div class="c2">
					<label for="feedback<?php echo $aEsFeedback['id']; ?>"><?php echo $aEsFeedback['user_name']; ?></label>
				</div>
				<div class="c3"><?php echo $aEsFeedback['user_id']; ?></div>
				<div class="c4"><?php echo $aEsFeedback['user_type'] == 1 ? '前端' : '后台'; ?></div>
				<div class="c5"><?php echo nl2br($aEsFeedback['reason']); ?></div>
				<div class="c5" id="J-feedbackUserAnswer<?php echo $aEsFeedback['id']; ?>">(未作答)</div>
				<?php if($aEsFeedback['user_type'] == 1){ ?>
					<div class="c6"><input type="text" xid="reply" /></div>
				<?php } ?>
			</div>
			<?php if($aEsFeedback['user_answer'] != '""' && $aEsFeedback['user_answer'] != ''){			?>
				<script type="text/javascript">
					(function(){
						var $es = Esp.buildQuestion(<?php echo json_encode($aEs); ?>);
						$('#J-feedbackUserAnswer<?php echo $aEsFeedback['id']; ?>').html($es.buildAnswerText(<?php echo $aEsFeedback['user_answer']; ?>));
					})();
				</script>
			<?php } ?>
		<?php } ?>
		<div class="row">
			<div class="">
				<input type="checkbox" checked="checked" name="" id="wholeBottom">
				<label for="wholeBottom">全选/全不选</label>
			</div>
		</div>
		<div class="item _handle">
			<div class="control">
				<button type="button" class="btnOperation" onclick="handleAll(2)">反馈无效</button>
			</div>
			<div class="control">
				<button type="button" class="btnOperation" onclick="handleAll(1)">反馈有效</button>
			</div>
		</div>
	</div>
</div>
<br class="clear" />
<div class="title">编辑</div>

<form class="module form esForm" id="form">
	<input type="hidden" name="category_id" value="<?php echo $categoryId; ?>" id="category_id" />
	<input type="hidden" name="subject_id" value="<?php echo $subjectId; ?>" id="subject_id" />
	<input type="hidden" name="es_type" value="<?php echo $esType; ?>" id="es_type" />
	<input type="hidden" name="id" value="<?php echo $esId; ?>" id="id" />
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<input type="text"  value="<?php echo $GLOBALS['SUBJECT'][$subjectId]; ?>" disabled="disabled" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">题型：</div>
		<div class="control">
			<input type="text" id="showEsType"  value="<?php echo $GLOBALS['ES_TYPE'][$esType]; ?>" disabled="disabled" />
		</div>
	</div>
	<div class="clear"></div>
	<?php
	if($sameBaseEsType >= 2){
	?>
		<div class="item">
			<div class="name">修改题型：</div>
			<div class="control">
				<?php
				foreach($aSameEsTypeId as $typeId){
				?>
					<input type="radio" id="sameType<?php echo $typeId; ?>" onclick="changeEsTye(<?php echo $typeId; ?>)" <?php if($esType == $typeId){ ?> checked="checked" <?php } ?> name="type_id" value="<?php echo $typeId; ?>" /><label style="margin-right:10px;" for="sameType<?php echo $typeId; ?>"><?php echo $GLOBALS['ES_TYPE'][$typeId]; ?></label>
				<?php
				}
				?>
			</div>
		</div>
		<div class="clear"></div>
	<?php
	}
	?>
	<div class="clear"></div>
	<div class="item">
		<div class="name">辅助功能：</div>
		<div class="control helpButton">
			<button type="button" class="btnOperation" onclick="rememberUnderline(this)">开始添加下划线</button>
			<?php if($esType == 4 || $esType == 5){ ?>
				<button type="button" class="btnOperation" onclick="oEs.addAnswer()">添加答案填充区</button>
				<button type="button" class="btnOperation" onclick="oEs.resetAllAnswer()">重新生成答案填充区</button>
				<button type="button" class="btnOperation" onclick="oEs.addNorder()">添加答案组</button>
			<?php }
			if($subjectId == 1 || $subjectId == 2){ ?>
				<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['char_inputer']; ?>"></script>
				<button type="button" class="btnOperation" onclick="CharInputer.show()">添加<?php echo $subjectId == 1 ? '元音音标' : '数学符号'; ?></button>
				<script type="text/javascript">
					CharInputer.init({
						subject : <?php echo $subjectId; ?>
						,closeOnMouseout : false
					});
				</script>
			<?php } ?>
			<button type="button" class="btnOperation" onclick="toggleModel(1)">作答预览</button>
			<button type="button" class="btnOperation" onclick="toggleModel(2)">结果预览</button>
		</div>
	</div>
	<div class="clear"></div>

	<div id="esForm" class="subject_<?php echo $subjectId;?>"></div>
	<br class="clear">
	<div class="item">
		<div class="name"></div>
		<div class="control">
			<button id="btnSave" type="button" class="btnOperation" onclick="submitEs()">保存</button>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">所选目录：</div>
		<div id="categoryResult" class="control"></div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">目录：</div>
		<div class="control">
			<script type="text/javascript">
				oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
				oDirTree.add(0, -1, '目录树');
				<?php if(isset($aCategoryList)){ ?>
					var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
					$(aCategoryList).each(function(){
						oDirTree.add(this.id, this.parent_id, this.name, 'javascript:getCategoryId()', this.name);
					});
				<?php } ?>
				document.write(oDirTree);
				oDirTree.openTo(<?php echo $categoryId; ?>, true);
			</script>
		</div>
	</div>
</form>
<div class="clear"></div>

<?php display('es_create/library.js.php'); ?>
<script type="text/javascript">
	function submitEs(){
		var aEs = checkForm();
		if(!aEs){
			return false;
		}

		var categoryId = $('#category_id').val();
		if(!(categoryId >= 1)){
			UBox.show('请选择题目所属目录');
			return false;
		}

		$.ajax({
			url : submitUrl,
			type : 'post',
			dateType : 'json',
			data : {
				id : <?php echo $esId; ?>,
				subject_id : <?php echo $subjectId; ?>,
				es_type : $('#es_type').val(),
				category_id : $('#category_id').val(),
				es : aEs.es_content
			},
			beforeSend : function(){
				$('#btnSave').attr('disabled', 'disabled').css({'background-color':'#999'});
			},
			complete : function(){
				$('#btnSave').attr('disabled', false).css({'background-color':'#333'});
			},
			success : function(aResult){
				if(aResult.status == -1){
					UBox.confirm(aResult.msg, function(){
						submitUrl += '&ignore_same_es=1';
						submitEs();
					});
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error : function(){
				UBox.show('网络可能有点慢');
			}
		});
	}

	function changeEsTye(esType){
		$('#es_type').val(esType);
		<?php
		$i = 0;
		foreach($aSameEsTypeId as $typeId){
			if($i == 0){
		?>
				if(esType == <?php echo $typeId; ?>){
					$('#showEsType').val('<?php echo $GLOBALS['ES_TYPE'][$typeId]; ?>');
				}
		<?php
			}else{
		?>
				else if(esType == <?php echo $typeId; ?>){
					$('#showEsType').val('<?php echo $GLOBALS['ES_TYPE'][$typeId]; ?>');
				}
		<?php
			}
			$i++;
		} ?>
	}

	function handleAll(type){
		var aHandleParam = []
		,noReply = false;
		$('input[xid=feedback]:checked').each(function(){
			var $oUser = $(this).closest('[xid="user"]')
			,reply = $.trim($oUser.find('[xid="reply"]').val());
			if(type == 2 && $oUser.data('user_type') == 1 && !reply){
				UBox.show('如果不采纳则请填写 ' + $oUser.data('username') + ' 的回复', -1);
				noReply = true;
				return false;
			}
			aHandleParam.push({
				id : $oUser.data('feedback_id')
				,reply : reply
			});
		});
		if(noReply){
			return;
		}

		var action = ['反馈有效', '反馈无效'][type - 1];
		if(!aHandleParam.length){
			UBox.show('请勾选 ' + action + ' 的用户！', -1);
			return false;
		}

		UBox.confirm(
			'你确定这是 ' + action + ' 吗？',
			function(){
				$.ajax({
					type : 'post'
					,dataType : 'json'
					,url : '?m=EsFeedback&a=editFeedback'
					,data : {
						param : aHandleParam
						,action : type
					}
					,success : function(aResult){
						var gotoUrl = '';
						if(aResult.status){
							gotoUrl = document.referrer;
						}
						UBox.show(aResult.msg, aResult.status, gotoUrl);
					},
					error : function(oXhr){
						UBox.show('网络可能有点慢，请稍后再试！', 0);
					}
				});
			}
		);
	}

	var oEs = null
	,submitUrl = '?m=EsFeedback&a=editEs';
	$(function(){
		$('#wholeBottom').click(function(){
			var isChecked = $(this).is(':checked');
			$('input[xid=feedback]').each(function(){
				if($(this).is(':checked') != isChecked){
					$(this).click();
				};
			});
		});

		showCategoryResult(<?php echo $categoryId; ?>);
		bindingEvent();

		ES.config({
			imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>',
			imageUploadUrl : '?m=EsCreate&a=uploadImage&ajax=1&subject=<?php echo $subjectId; ?>'
		});
		var aEs = <?php echo json_encode($aEs); ?>;
		oEs = ES.buildForm(aEs);
		$('#esForm').append(oEs);
		$('#orgContent').append(ES.buildDetail(aEs));
	});
</script>