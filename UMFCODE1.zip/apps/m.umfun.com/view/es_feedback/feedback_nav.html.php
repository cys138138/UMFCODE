<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=EsFeedback&a=showList">题目反馈列表</a>
	<?php if(get('a') == 'showEsFeedbackDetail'){ ?>
		<a <?php if(get('a') == 'showEsFeedbackDetail'){  ?>class="on"<?php } ?> onclick="javascript:viod(0);">查看题目反馈详情</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>
<div class="br"></div>
