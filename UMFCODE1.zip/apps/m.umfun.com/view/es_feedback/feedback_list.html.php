<?php display('es_feedback/feedback_nav.html.php')?>
<div class="module _feedbackList">
	<style type="text/css">
		._feedbackList .title a{color:#8d8b8b; margin-left:10px;}
		._feedbackList .title .on{color:#000; font-weight:bold;}
		._feedbackList .title a{color:#8d8b8b; margin-left:10px;}
		._feedbackList ._feedback .row .c1{width:80px;}
		._feedbackList ._feedback .row .c2{width:100px;}
		._feedbackList ._feedback .row .c3{width:70px;}
		._feedbackList ._feedback .row .c4{width:200px;}
		._feedbackList ._feedback .row .c5{width:350px;}
		._feedbackList ._feedback .row .c6{width:450px;}
		._feedbackList ._feedback .row .c7{width:120px;}
		._feedbackList ._feedback .row .c8 a{margin-left:10px;}
	</style>
	<div class="title">题目反馈列表 ：
	
		<?php foreach($aSubject as $key => $subject){ ?>
				<a <?php if($subjectId == $key){ echo 'class="on"'; } ?> href="?m=EsFeedback&a=showList&subject_id=<?php echo $key; ?>"><?php echo $subject; ?></a>
		<?php } ?>
	</div>
	<div class="list _feedback subject_<?php echo $subjectId;?>">
		<div class="row header">
			<div class="c1">题目id</div>
			<div class="c2">反馈者</div>
			<div class="c3">来自</div>
			<div class="c4">关卡</div>
			<div class="c5">题目内容</div>
			<div class="c6">理由</div>
			<div class="c7">时间</div>
			<div class="c8 right">操作</div>
		</div>
		<?php foreach($aFeedbackList as $aFeedback){
			$testUserClass = in_array($aFeedback['user_id'], $GLOBALS['TEST_USER_LIST']) ? ' testUser' : '';
		?>
		<div class="row">
			<div class="c1"><?php echo $aFeedback['es_id']; ?></div>
			<div class="c2<?php echo $testUserClass; ?>" title="<?php echo 'uid:' . $aFeedback['user_id']; ?>"><?php echo $aFeedback['user_name']; ?></div>
			<div class="c3"><?php echo $aFeedback['user_type'] == 1 ? '前端' : '后台'; ?></div>
			<div class="c4"><?php if($aFeedback['mission_id']){echo $aFeedback['mission_name'] . '(' . $aFeedback['mission_id'] . ')'; }else{ echo '--'; } ?></div>
			<div class="c5" title="<?php echo $aFeedback['content_text']; ?>"><?php echo $aFeedback['content_text']; ?></div>
			<div class="c6" title="<?php if($aFeedback['feedback_counts'] > 1){echo '(共' . $aFeedback['feedback_counts'] .'条理由)' . $aFeedback['reason']; }else{ echo $aFeedback['reason']; }; ?>"><?php if($aFeedback['feedback_counts'] > 1){echo '(共<font color="red">' . $aFeedback['feedback_counts'] .'</font>条理由)' . $aFeedback['reason']; }else{ echo $aFeedback['reason']; }; ?></div>
			<div class="c7"><?php echo date('Y-m-d H:m:s', $aFeedback['create_time']); ?></div>
			<div class="c8 right">
				<?php if($aFeedback['mission_id']){
					echo '<a href="?m=Mission&a=showMissionDetail&mission_id=' . $aFeedback['mission_id'] . '">查看关卡</a>';
					}
				?>
				<a href="?m=EsFeedback&a=showEsFeedbackDetail&es_id=<?php echo $aFeedback['es_id']; ?>">查看反馈</a>
				<a onclick="deleteFeedback(<?php echo $aFeedback['es_id']; ?>)">删除</a>
			</div>
		</div>
		<?php } ?>
		
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	
	function deleteFeedback(index){
		UBox.confirm(
			'你确定删除吗？',
			function(){
				$.ajax({
					type : 'post',
					dataType : 'json',
					url : '?m=EsFeedback&a=deleteFeedback',
					data : {es_id : index},
					success : function(result){
						if(result.status == 1){
							UBox.show(result.msg, 1, 'reload');
						}else if(result.status == 0){
							UBox.show(result.msg, 0);
						}
					},
					error : function(request){
						UBox.show('网络可能有点慢，请稍后再试！', 0);
					}
				});
			}
		);
	}
</script>