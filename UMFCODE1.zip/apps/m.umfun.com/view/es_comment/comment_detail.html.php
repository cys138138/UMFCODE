<?php display('es_comment/comment_nav.html.php'); ?>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<div class="module _comment">
	<style type="text/css">
		._comment{min-width:1120px;}
		._comment .item .control input{width:150px;}
		._comment .item .name{margin-left:6px;}
		._comment ._esContent .name{font-size:16px;}
		._comment .item .control a{margin-left:10px;}
		._comment ._parentComment ._review{margin-left:5px;color:#000;}
		._comment ._parentComment {max-width:1100px; height:auto; margin-left:30px; color:red; border-top:2px solid #ccc;}
		._comment ._childComment{margin-left:60px; font-size:16px; width:500px; border-bottom:1px solid #ccc;}
		._comment ._childComment .comment{margin-left:60px;}
		._comment ._parentComment ._childComment ._discuss{margin-left:60px; color:#000;}
		._comment .item .comment{margin:2px 0 5px 60px; padding:0 10px 0 10px; color:#000; height:auto; white-space:normal; word-break:break-all; word-wrap:break-word;}
		._comment .item .on{color:#eee; padding:3px 20px 3px 20px; font-weight:bold; font-size:14px; background-color:#f30;}
	</style>
	<div class="title">题目评论详情</div>
	<div class="item _esContent">
		<div class="control es_content" id="orgContent"></div>
	</div>
	<div class="clear"></div>
	<?php foreach($aCommentList as $floorNums => $aComment){ ?>
	<div class="item _parentComment">
		<div class="name _review">评论<?php echo ($floorNums + 1); ?>：[<?php if($aComment['approved'] == 0){echo '未审核'; }elseif($aComment['approved'] == 1){ echo '审核通过'; }else{ echo '屏蔽'; }?>]</div>
		<div class="name"><?php echo $aComment['user_info']['name'] . '&nbsp;&nbsp;&nbsp;' . $aComment['create_time']; ?>&nbsp;说：</div>
		<div class="control">
			<?php if($aComment['approved'] == 0 || $aComment['approved'] == -1){ ?>
				<a onclick="approve(<?php echo $aComment['id']; ?>, 1)">通过审核</a>
			<?php } ?>
			
			<?php if($aComment['approved'] == 1){ ?>
				<a onclick="approve(<?php echo $aComment['id']; ?>, 0)">撤销通过</a>
			<?php } ?>
			
			<?php if($aComment['approved'] != -1){ ?>
				<a onclick="approve(<?php echo $aComment['id']; ?>, -1)">屏蔽</a>
			<?php } ?>
		</div>
		<div class="clear"></div>
		
		<div class="comment<?php if($aComment['id'] == $commentId){ echo ' on'; }?>" >
			<?php echo $aComment['content']; ?>
		</div>
		<div class="clear"></div>
		
		<?php foreach($aComment['child'] as $rebackNums => $aChildComment){ ?>
			<div class="item _childComment">
				<div class="name _discuss">回复<?php echo ($rebackNums + 1); ?>：[<?php if($aChildComment['approved'] == 0){echo '未审核'; }elseif($aChildComment['approved'] == 1){ echo '审核通过'; }else{ echo '屏蔽'; }?>]</div>
				<div class="name"><?php echo $aChildComment['user_info']['name'] . '&nbsp;&nbsp;&nbsp;' . $aChildComment['create_time']; ?>&nbsp;说：</div>
				
				<div class="control">
					<?php if($aChildComment['approved'] == 0 || $aChildComment['approved'] == -1){ ?>
						<a onclick="approve(<?php echo $aChildComment['id']; ?>, 1)">通过审核</a>
					<?php } ?>
					
					<?php if($aChildComment['approved'] == 1){ ?>
						<a onclick="approve(<?php echo $aChildComment['id']; ?>, 0)">撤销通过</a>
					<?php } ?>
					
					<?php if($aChildComment['approved'] != -1){ ?>
						<a onclick="approve(<?php echo $aChildComment['id']; ?>, -1)">屏蔽</a>
					<?php } ?>
				</div>
				<div class="clear"></div>
				
				<div class="comment<?php if($aChildComment['id'] == $commentId){ echo ' on'; }?>"  >
					<?php echo $aChildComment['content']; ?>
				</div>
				
			</div>
			<div class="clear"></div>
		<?php } ?>
		
	</div>
	<div class="clear"></div>
	<?php } ?>
</div>
<script type="text/javascript">
	function approve(index, statu){
		var action = '';
		if(statu == 0){
			action = '撤销通过';
		}else if(statu == 1){
			action = '审核通过';
		}else if(statu == -1){
			action = '屏蔽';
		}
		UBox.confirm(
			'你确定' + action + '吗？',
			function(){
				$.ajax({
					type : 'post',
					dataType : 'json',
					url : '?m=EsComment&a=approveComment',
					data : {comment_id : index, action_id : statu},
					success : function(result){
						UBox.show(result.msg, result.status, 'reload');
					},
					error : function(request){
						UBox.show('网络可能有点慢，请稍后再试！', 0);
					}
				});
			}
		);
	}
	
	$(function(){
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		$('#orgContent').append(ES.buildDetail(<?php echo json_encode($aEs); ?>));
	});
</script>