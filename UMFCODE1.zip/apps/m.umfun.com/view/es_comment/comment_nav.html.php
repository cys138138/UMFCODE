<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=EsComment&a=showList">题目评论列表</a>
	<?php if(get('a') == 'showCommentDetail'){ ?>
		<a <?php if(get('a') == 'showCommentDetail'){  ?>class="on"<?php } ?> onclick="javascript:viod(0);">查看题目评论详情</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>
<div class="br"></div>
