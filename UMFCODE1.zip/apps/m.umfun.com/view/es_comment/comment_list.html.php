<?php display('es_comment/comment_nav.html.php')?>
<div class="module _commentList">
	<style type="text/css">
		._commentList .title a{color:#8d8b8b; margin-left:10px;}
		._commentList ._comment .row .c1{width:80px;}
		._commentList ._comment .row .c2{width:80px;}
		._commentList ._comment .row .c3{width:80px;}
		._commentList ._comment .row .c4{width:250px;}
		._commentList ._comment .row .c5{width:150px;}
		._commentList ._comment .row .c6{width:100px;}
		._commentList ._comment .row .c8 a{margin-left:10px;}
	</style>
	<div class="title">题目评论列表：</div>
	<div class="list _comment">
		<div class="row header">
			<div class="c1">题目id</div>
			<div class="c2">发言人</div>
			<div class="c3">匿名</div>
			<div class="c4">内容</div>
			<div class="c5">发表时间</div>
			<div class="c6">状态</div>
			<div class="c7">ip地址</div>
			<div class="c8 right">操作</div>
		</div>
		<?php foreach($aCommentList as $aComment){
			$testUserClass = in_array($aComment['user_id'], $GLOBALS['TEST_USER_LIST']) ? ' testUser' : '';
		?>
		<div class="row">
			<div class="c1"><?php echo $aComment['es_id']; ?></div>
			<div class="c2 <?php echo $testUserClass; ?>">
				<span class="name"><?php echo $aComment['user_name']; ?></span>
			</div>
			<div class="c3"><?php if($aComment['is_anonymous'] == 1){ echo '是'; }else{ echo '否'; } ?></div>
			<div class="c4" title="<?php echo $aComment['content']; ?>"><?php echo $aComment['content']; ?></div>
			<div class="c5"><?php echo date('Y-m-d', $aComment['create_time']); ?></div>
			<div class="c6">
				<?php if($aComment['approved'] == 0){ echo '未审核'; }elseif($aComment['approved'] == 1){ echo '审核通过'; }else{ echo '屏蔽'; }?>
			</div>
			<div class="c7"><?php echo $aComment['ip']; ?></div>
			<div class="c8 right">
				<?php if($aComment['approved'] == 0 || $aComment['approved'] == -1){ ?>
					<a onclick="approve(<?php echo $aComment['id']; ?>, 1)">通过审核</a>
				<?php } ?>
				
				<?php if($aComment['approved'] == 1){ ?>
					<a onclick="approve(<?php echo $aComment['id']; ?>, 0)">撤销通过</a>
				<?php } ?>
				
				<?php if($aComment['approved'] != -1){ ?>
					<a onclick="approve(<?php echo $aComment['id']; ?>, -1)">屏蔽</a>
				<?php } ?>
				<a href="?m=EsComment&a=showCommentDetail&es_id=<?php echo $aComment['es_id']; ?>&comment_id=<?php echo $aComment['id']; ?>">查看</a>
			</div>
		</div>
		<?php } ?>
		
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	function approve(index, statu){
		if(statu == 0){
			action = '撤销通过';
		}else if(statu == 1){
			action = '审核通过';
		}else if(statu == -1){
			action = '屏蔽';
		}
		UBox.confirm(
			'你确定' + action + '吗？',
			function(){
				$.ajax({
					type : 'post',
					dataType : 'json',
					url : '?m=EsComment&a=approveComment',
					data : {comment_id : index, action_id : statu},
					success : function(result){
						UBox.show(result.msg, result.status, 'reload');
					},
					error : function(request){
						UBox.show('网络可能有点慢，请稍后再试！', 0);
					}
				});
			}
		);
	}
</script>