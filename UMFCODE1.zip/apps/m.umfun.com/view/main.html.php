<?php if($admin || $userManage){ ?>
<style>
	.main{ width:100%; height:auto; padding:10px;}
	.main .warn{ width:500px; min-height:100px; margin-bottom:15px;}
	.main .warn .title{ font:16px/28px '微软雅黑'; color:#05f; border-bottom:1px solid #eee; padding-left:15px;}
	.main .warn .msg{font:14px/26px '微软雅黑'; color:#333; padding-left:15px;}
	.font{ font:18px/26px '微软雅黑'; color:#f00;}
</style>

<div class="main">
	<div class="warn">
		<div class="title">提醒信息</div>
		<?php if($admin){ ?>
		<div class="msg">题库中有&nbsp;<font class="font"><?php echo $checkPending;?></font>&nbsp;条题目待审核！</div>
		<div class="msg">题库中有&nbsp;<font class="font"><?php echo $recheck;?></font>&nbsp;条题目待复核！</div>
		<div class="msg">语文科目有&nbsp;<font class="font"><?php echo $chineseEsCount;?></font>&nbsp;条题目反馈待处理！</div>
		<div class="msg">数学科目有&nbsp;<font class="font"><?php echo $mathEsCount;?></font>&nbsp;条题目反馈待处理！</div>
		<div class="msg">英语科目有&nbsp;<font class="font"><?php echo $englishEsCount;?></font>&nbsp;条题目反馈待处理！</div>
		<div class="msg">其他科目有&nbsp;<font class="font"><?php echo $otherEsCount;?></font>&nbsp;条题目反馈待处理！</div>
		<?php } ?>
		<?php if($userManage){ ?>
			<div class="msg">您有&nbsp;<font class="font"><?php echo $userCheck;?></font>&nbsp;条用户提交审核的资料未审核，请尽快审核！</div>
		<?php } ?>
	</div>
</div>

<?php }else{ ?>
Home
<?php } ?>

