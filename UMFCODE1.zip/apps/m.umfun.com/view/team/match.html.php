<?php
	displayHeader(); 
	display('team/nav.html.php'); 
?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:20px;}
	.list .c2{width:80px;}
	.list .c3{width:150px;}
	.list .c4{width:100px;}
	.list .c5{width:100px;}
	.list .c6{width:80px;}
	.list .c7{width:80px;}
	.list .c8{width:108px;}
	.list .c9{width:108px;}
	.list .c10{width:108px;}
	.list .c11{width:70px;}
	.list .c12{width:200px;}
	.list .c13{width:120px;}
	.right{float:right;}
	.button{border: none;}
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			赛事列表
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">赛事主题</div>
			<div class="c4">第一轮比赛</div>
			<div class="c5">第二轮比赛</div>
			<div class="c11">参赛队伍</div>
			<div class="c12">奖品设置</div>
			<div class="c13 right">操作</div>
		</div>
		
		<?php
		foreach($aMatchList as $aMatch){
		?>
			<div class="row">
				<div class="c1"><?php echo $aMatch['id']; ?></div>
				<div class="c2"><?php echo $aMatch['name']; ?></div>
				<div class="c4"><?php if(isset($aMatch['first_match'])){ echo $aMatch['first_match']['name']; }else{ echo '赛事不存在'; }; ?></div>
				<div class="c5"><?php if(isset($aMatch['second_match'])){ echo $aMatch['second_match']['name']; }else{ echo '赛事不存在'; }; ?></div>
				<div class="c11"><?php if(isset($aMatch['count'])){ echo $aMatch['count']; }else{ echo 0; }; ?>队</div>
				<div class="c12" style="white-space:normal;" title="<?php echo $aMatch['prizes_name']; ?>"><?php echo $aMatch['prizes_name']; ?></div>
				<div class="c13 right">
					<a  href="/?m=Team&a=showTeam&id=<?php echo $aMatch['id']; ?>"  class="checkOn">查看参赛队伍</a>
					<a  href="/?m=Team&a=showEditMatch&id=<?php echo $aMatch['id']; ?>"  class="checkOn">修改</a>
				</div>
			</div>
		<?php
		}
		?>
		<div class="clear"></div>

	</div>
</div>

<?php displayFooter(); ?>