<?php
	displayHeader(); 
	display('team/nav.html.php'); 
?>

<style type="text/css">
	._main .name{width: 100px;}
	.tips{font-style:normal;color: red;}
	.button{border: none;  display:inline; margin-right:10px;}
	.fl{float: left;}
	.nofloat{float: none;}
</style>

<div class="module _main">
	<form id="matchData" class="addForm">
	<div class="title">新增赛事</div>
	
	<div class="item">
		<div class="name">赛事主题：</div>
		<div class="control"><input type="text" name="name" id="name"/></div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">一轮比赛：</div>
		<div class="control">
			<select id="first_match_id" name="first_match_id">
				<option value="-1">-第一轮比赛-</option>
				<?php 
					foreach($aMatchList as $aMatch){
						echo '<option value="' . $aMatch['id'] . '">-' . $aMatch['name'] . '</option>';
					}
				?>
			</select>（已发布的校讯通专用的团队赛）
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">二轮比赛：</div>
		<div class="control">
			<select id="second_match_id" name="second_match_id">
				<option value="-1">-第二轮比赛-</option>
				<?php 
					foreach($aMatchList as $aMatch){
						echo '<option value="' . $aMatch['id'] . '">-' . $aMatch['name'] . '</option>';
					}
				?>
			</select>（已发布的校讯通专用的团队赛）
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">第一名</div>
		<div class="control">
			<select id="first" name="first">
				<option value="-1">-第一名-</option>
				<?php 
					foreach($aPrizeList as $aPrize){
						echo '<option value="' . $aPrize['id'] . '">-' . $aPrize['name'] . '</option>';
					}
				?>
			</select>
		</div>
	</div>
	<div class="item">
		<div class="name">二到十名</div>
		<div class="control">
			<select id="second_tenth" name="second_tenth">
				<option value="-1">-二到十名-</option>
				<?php 
					foreach($aPrizeList as $aPrize){
						echo '<option value="' . $aPrize['id'] . '">-' . $aPrize['name'] . '</option>';
					}
				?>
			</select>
		</div>
	</div>
	<div class="item">
		<div class="name">一轮幸运奖</div>
		<div class="control">
			<select id="first_lucky" name="first_lucky">
				<option value="-1">-一轮幸运奖-</option>
				<?php 
					foreach($aPrizeList as $aPrize){
						echo '<option value="' . $aPrize['id'] . '">-' . $aPrize['name'] . '</option>';
					}
				?>
			</select>
		</div>
	</div>
	<div class="item">
		<div class="name">二轮幸运奖</div>
		<div class="control">
			<select id="second_lucky" name="second_lucky">
				<option value="-1">-二轮幸运奖-</option>
				<?php 
					foreach($aPrizeList as $aPrize){
						echo '<option value="' . $aPrize['id'] . '">-' . $aPrize['name'] . '</option>';
					}
				?>
			</select>
		</div>
	</div>
	<div class="clear"></div>
	

	<div class="item nofloat">
		<div class="name"></div>
		<div class="control">
			<button type="button" class="button fl" onclick="addMatch();" />添加赛事</button>
		</div>
	</div>
	<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
	
	function checkFrom(){
		var name = $('#name').val();
		var first_match = $('#first_match_id').val();
		var second_match = $('#second_match_id').val();
		var first = $('#first').val();
		var second_tenth = $('#second_tenth').val();
		var first_lucky = $('#first_lucky').val();
		var second_lucky = $('#second_lucky').val();
		
		if(!name || name.length < 5){
			UBox.show('我说赛事主题怎么也得5个字以上吧', -1);
			return false;
		}

		if(first_match <= 0 || isNaN(first_match)){
			UBox.show('不让人做第一轮比赛了吗', -1);
			return false;
		}
		
		if(second_match <= 0 || isNaN(second_match)){
			UBox.show('不让人做第二轮比赛了吗', -1);
			return false;
		}
		
		if(first == '' || first <= 0){
			UBox.show('第一名奖品也不给人家，好坏好坏哒', -1);
			return false;
		}
		
		if(second_tenth == '' || second_tenth <= 0){
			UBox.show('二到十名的奖品也不给人家，好坏好坏哒', -1);
			return false;
		}
		
		if(first_lucky == '' || first_lucky <= 0){
			UBox.show('一轮幸运奖奖品也不给人家，好坏好坏哒', -1);
			return false;
		}
		
		if(second_lucky == '' || second_lucky <= 0){
			UBox.show('二轮幸运奖奖品也不给人家，好坏好坏哒', -1);
			return false;
		}
		return true;
	}
	
	function addMatch(){
		if(!checkFrom()){
			return;
		}
		ajax({
			url: '/?m=Team&a=addMatch',
			data: $('#matchData').serialize(),
			success: function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, aResult.status, '/?m=Team&a=showMatchList');
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			}
		});
	}
</script>
<?php displayFooter(); ?>