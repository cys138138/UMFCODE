<?php
	displayHeader();
	display('team/nav.html.php');
?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:80px;}
	.list .c3{width:150px;}
	.list .c4{width:60px;}
	.list .c5{width:60px;}
	.list .c6{width:80px;}
	.list .c7{width:80px;}
	.list .c8{width:108px;}
	.list .c9{width:108px;}
	.list .c10{width:108px;}
	.list .c11{width:70px;}
	.list .c12{width:200px;}
	.list .c13{width:120px;}
	.right{float:right;}
	.button{border: none;}
</style>
<div class="module _conditon">
	<div class="item">
		<div class="name" style="width:120px;">
			<select onchange="jump()" id="match" name="match">
				<option value="0">-选择赛事-</option>
				<?php
				foreach($aMatchList as $aMatch){
				?>
				<option value="<?php echo $aMatch['id']; ?>" <?php if($aMatch['id'] == get('id')){echo 'selected="selected"';}?>><?php echo $aMatch['name']; ?></option>
				<?php
				}
				?>
			</select>
		</div>
		<div class="name" style="margin-left:10px;">
			<span>
				<span>参赛人数:</span>
				<select onchange="search()" class="J-UserCount">
					<option value="0">全部</option>
					<option value="1" <?php $user_count = get('user_count',0) ;if($user_count == 1) echo 'selected="selected"';?>>1</option>
					<option value="2" <?php if($user_count == 2) echo 'selected="selected"';?>>2</option>
					<option value="3" <?php if($user_count == 3) echo 'selected="selected"';?>>3</option>
				</select></span>
		</div>
	</div>
</div>
<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			参赛队伍(<?php $count = isset($aTeamList['list']) ? count($aTeamList['list']) : 0; echo $count; ?>)
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">队名</div>
			<div class="c3">成员</div>
			<div class="c4">赛事</div>
			<div class="c5">奖品</div>
			<div class="c6">一轮分数</div>
			<div class="c7">二轮分数</div>
			<div class="c8">电话</div>
			<div class="c9">地址</div>
			<div class="c10">收货人</div>
			<div class="c11">创建时间</div>
		</div>

		<?php
		if(isset($aTeamList['list'])){
		foreach($aTeamList['list'] as $aTeam){
		?>
			<div class="row">
				<div class="c1"><?php echo isset($aTeam['id']) ? $aTeam['id'] : 0; ?></div>
				<div class="c2"><?php echo $aTeam['name']; ?></div>
				<div class="c3" style="white-space:normal;">
				<?php
					$names = '';
					foreach($aTeam['user_info'] as $aUser){
						$names .= '，' . $aUser['name'];
					}
					echo $names;
				?>
				</div>
				<div class="c4"><?php echo $aTeam['match']['name']; ?></div>
				<?php
					if($aTeam['prize']){
						$prizeList = '';
						foreach($aTeam['prize'] as $aPrize){
							$prizeList .= '--' . $aPrize['name'];
						}
					}else{
						$prizeList = '---';
					};
				?>
				<div class="c5" title="<?php echo $prizeList; ?>">
					<?php echo $prizeList; ?>
				</div>
				<div class="c6"><?php echo $aTeam['first_one_score'] . ',' . $aTeam['first_two_score'] . ',' . $aTeam['first_three_score']; ?></div>
				<div class="c7"><?php echo $aTeam['second_one_score'] . ',' . $aTeam['second_two_score'] . ',' . $aTeam['second_three_score']; ?></div>
				<div class="c8"><?php echo $aTeam['phone']; ?></div>
				<div class="c9" title="<?php echo $aTeam['address']; ?>"><?php echo $aTeam['address']; ?></div>
				<div class="c10"><?php echo $aTeam['consignee']; ?></div>
				<div class="c11"><?php echo date('Y-m-d H:i', $aTeam['create_time']); ?></div>
			</div>
		<?php
		}
		}
		?>
		<div class="clear"></div>
		
	</div>
</div>

<script type="text/javascript">
	function jump(){
		var matchId = $('#match').val();
		window.location.href = '?m=Team&a=showTeam&id=' + matchId;
	}
	function search(){
		var user_count = $('.J-UserCount').val();
		var matchId = $('#match').val();
		window.location.href = '?m=Team&a=showTeam&id=' + matchId + '&user_count=' + user_count;
	}
</script>

<?php displayFooter(); ?>