<div class="nav">
	<a <?php if(get('a') == 'showPrizeList'){ ?>class="on"<?php } ?> href="?m=Team&a=showPrizeList">奖品列表管理</a>
	<a <?php if(get('a') == 'showMatchList'){ ?>class="on"<?php } ?> href="?m=Team&a=showMatchList">赛事列表管理</a>
	<a <?php if(get('a') == 'showAddPrize'){ ?>class="on"<?php } ?> href="?m=Team&a=showAddPrize">添加奖品</a>
	<a <?php if(get('a') == 'showAddMatch'){ ?>class="on"<?php } ?> href="?m=Team&a=showAddMatch">新增赛事</a>
	<?php if(get('a') == 'showTeam'){ echo '<a class="on" href="?m=Team&a=showTeam&id=' . get('id') . '">参赛队伍</a>'; } ?>
	<?php if(get('a') == 'showEditPrize'){ echo '<a class="on" href="?m=Team&a=showEditPrize&id=' . get('id') . '">修改奖品</a>'; } ?>
	<?php if(get('a') == 'showEditMatch'){ echo '<a class="on" href="?m=Team&a=showEditMatch&id=' . get('id') . '">修改赛事</a>'; } ?>
</div>
<div class="br"></div>