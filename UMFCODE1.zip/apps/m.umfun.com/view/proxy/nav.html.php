<div class="nav">
	<a <?php if(get('a') == 'showProxyList'){ ?>class="on"<?php } ?> href="?m=Proxy&a=showProxyList">代理商列表<?php if($first && $first == 1){echo '[待审核 ' . $count . ']';}?></a>
	<a <?php if(get('a') == 'showProxyStatistic'){ ?>class="on"<?php } ?> href="?m=Proxy&a=showProxyStatistic">代理商统计</a>
	<?php if(get('a') == 'showCommission'){echo '<a class="on">佣金统计</a>';}?>
	<?php if(get('a') == 'showProxyEdit'){echo '<a class="on">编辑</a>';}?>
</div>

<div class="br"></div>
