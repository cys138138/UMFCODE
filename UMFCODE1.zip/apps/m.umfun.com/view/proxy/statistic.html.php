<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<?php display('proxy/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:80px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>

	<form id="userConditionForm">
		<div class="item">
			<div class="name">代理商：</div>
			<div class="control"><input type="text" name="email" id="email" value="<?php if(isset($email)){ echo $email; } ?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="getStatistic(1);">确定</a>
			</div>
			<div class="blank"></div>
			<div class="comment">备注：请填写完整的代理商邮箱或名字进行精确查找</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">充值类型：</div>
			<div class="control">
				<select name="rechargeType" id="rechargeType">
					<option <?php if($rechargeType == 0){ echo 'selected'; }?> value="0">全部</option>
					<option <?php if($rechargeType == 1){ echo 'selected'; }?> value="1">U币</option>
					<option <?php if($rechargeType == 2){ echo 'selected'; }?> value="2">月费</option>
				</select>
			</div>
			<div class="name">时间：</div>
			<div class="control _quickTime">
				<a onclick="setSearchTime(1);">今天</a>
				<a onclick="setSearchTime(3);">最近3天</a>
				<a onclick="setSearchTime(7);">最近7天</a>
				<a onclick="setSearchTime(30);">最近30天</a>
				<a onclick="setSearchTime(0);" >全部</a>
			</div>
			<div class="blank"></div>
			<div class="name">自定义：</div>
			<div class="control">
				<input type="text" id="startTime" value="<?php echo $startTime; ?>" name="startTime" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
				-
				<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="endTime" name="endTime" />
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="getStatistic(2);">统计</a>
			</div>
		</div>
	</form>
</div>
<div class="clear"></div>

<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:80px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		.status a{color:#999; margin-right:10px;}
		.status .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
		._statistic .row .c0{width:50px; color:#000; font-size:14px; }
		._statistic .row .c1{width:120px;}
		._statistic .row .c2{width:100px;}
		._statistic .row .c3{width:100px;}
		._statistic .row .c4{width:100px;}
		._statistic .row .c5{width:100px;}
		._statistic .row .c6{width:100px;}
		._statistic .footer{font-size:14px; color:#000;}
		
	</style>
	
	<div class="list _statistic">
		<div class="row header">
			<div class="c0">&nbsp;</div>
			<div class="c1">代理商</div>
			<div class="c2">用户数量(人)</div>
			<div class="c3">充值总次数(次)</div>
			<div class="c4">充值总额(元)</div>
			<div class="c5">佣金比(%)</div>
			<div class="c6">代理商收入(元)</div>
			<div class="c7">公司收入(元)</div>
			<div class="c8 right">操作</div>
		</div>
		
		<?php if($aProxyList){ foreach($aProxyList as $aProxy){?>
		<div class="row">
			<div class="c0">&nbsp;</div>
			<div class="c1"><?php echo $aProxy['name'] ? $aProxy['name'] : '--'; ?></div>
			<div class="c2"><?php echo $aProxy['user_count']; ?></div>
			<div class="c3"><?php echo $aProxy['recharge_nums']; ?></div>
			<div class="c4"><?php echo $aProxy['recharge_total_money']; ?></div>
			<div class="c5"><?php echo $aProxy['commission']; ?></div>
			<div class="c6"><?php echo $aProxy['recharge_total_money'] - $aProxy['real_pay_money']; ?></div>
			<div class="c7"><?php echo $aProxy['real_pay_money']; ?></div>
			<div class="c8 right"><a href="?m=Recharge&a=showRechargeList&commission=<?php echo $aProxy['commission']; ?>&proxyId=<?php echo $aProxy['id']; ?>&isProxyCount=1">查看详情</a></div>
		</div>
		
		<?php } }else{ echo '<font color="red">抱歉！暂时缺乏数据。</font>'; } ?>
		<div class="row footer">
			<div class="c0">总计</div>
			<div class="c1"><?php echo $aTotalstatistic['total_proxy_nums']; ?>(个)</div>
			<div class="c2"><?php echo $aTotalstatistic['total_user_count']; ?></div>
			<div class="c3"><?php echo $aTotalstatistic['total_recharge_count']; ?></div>
			<div class="c4"><?php echo $aTotalstatistic['total_money']; ?></div>
			<div class="c5"><?php echo $aTotalstatistic['average_commission']; ?>(平均)</div>
			<div class="c6"><?php echo $aTotalstatistic['total_money'] - $aTotalstatistic['real_pay']; ?></div>
			<div class="c7"><?php echo $aTotalstatistic['corporation_income']; ?></div>
		</div>
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>
	</div>
	

<?php setRefererMark(); ?>
<script type="text/javascript">
	window.endTime = "'end_time'";
	
	function getStatistic(index){
		var loadUrl = '?m=Proxy&a=showProxyStatistic&search_type=' + index;
		if(index == 1){
			var email = $('#email').val();
			var emailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
			if($.trim(email).length == 0){
				UBox.show('请输入代理商邮箱', -1);
				return false;
			}else if(!emailReg.test(email)){
				$('#email').select();
				UBox.show('邮箱输入不合法', -1);
				return false;
			}
			loadUrl += '&email=' + email;
		}else if(index == 2){
			var province_id = $('#province_id').val();
			var city_id = $('#city_id').val();
			var district_id = $('#district_id').val();
			var startTime = $('#startTime').val();
			var endTime = $('#endTime').val();
			var rechargeType = $('#rechargeType').val();
			loadUrl += '&start_time=' + startTime + '&end_time=' + endTime + '&recharge_type=' + rechargeType;
			if(province_id){
				loadUrl += '&province_id=' + province_id;
			}
			if(city_id){
				loadUrl += '&city_id=' + city_id;
			}
			if(district_id){
				loadUrl += '&district_id=' + district_id;
			}
		}
		location.href = loadUrl;
	}
	
	function setSearchTime(type){
		var dateStr = '<?php echo date('Y-m-d 00:00:00'); ?>';
		var dateForm = new Date();
		var startTime = dateForm.getTime();
		if(type == 1){
			$('#startTime').val(dateStr);
		}else if(type == 0){
			$('#startTime').val('2013-01-01 00:00:00');
		}else{
			startTime = startTime - type * 24 * 60 * 60 * 1000;
			$('#startTime').val(timeToStr(startTime));
		}
		$('#endTime').val('<?php echo date('Y-m-d H:i:s'); ?>');
	}

	//将秒数转换成  年-月-日 时:分:秒  字符串
	function timeToStr(time){
		var s, y, m, d, h, i, e;
		s = new Date(time)
		y =s.getFullYear();
		m =s.getMonth() + 1;
		d =s.getDate();
		h =s.getHours();
		i =s.getMinutes();
		e =s.getSeconds();
		if(m < 10){
			m = '0' + m;
		}
		if(d < 10){
			d = '0' + d
		}
		if(h < 10){
			h = '0' + h;
		}
		if(i < 10){
			i = '0' + i;
		}
		if(e < 10){
			e = '0' + e;
		}
		startDateStr = y + '-' + m + '-' + d + ' ' + h + ':' + i + ':' + e;
		return startDateStr;
	}
</script>