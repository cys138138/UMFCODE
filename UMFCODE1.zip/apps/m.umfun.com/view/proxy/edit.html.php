<?php display('proxy/nav.html.php'); ?>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item #address{width:300px;}	
	</style>
	<div class="userInfo">
		<form class="editForm">
			<div class="title">编辑代理商</div>
			<div class="item">
				<div class="name">机构名称：</div>
				<div class="control">
					<input type="text" name="name" id="name" value="<?php echo $aProxyInfo['name']; ?>" /></div>
			</div>

			<div class="clear"></div>
			<div class="item">
				<div class="name">API是否激活：</div>
				<div class="control">
					<select name="api_is_active" id="api_is_active">
						<option value="0">末激活</option>
						<option value="1" <?php if($aProxyInfo['api_is_active'] == 1){echo 'selected="selected"';}?>>激活</option>
					</select>
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">代理商秘钥：</div>
				<div class="control">
					<input type="text" name="api_key" id="api_key" value="<?php echo $aProxyInfo['api_key']; ?>" />
				</div>
			</div>			
			<div class="clear"></div>
			<div class="item">
				<div class="name">代理商ip列表：</div>
				<div class="control">
					<input type="text" name="api_ip_list" id="api_ip_list" value="<?php echo $aProxyInfo['api_ip_list']; ?>" />
				</div>
			</div>	
			<div class="clear"></div>
			<div class="item">
				<div class="name">邮箱：</div>
				<div class="control">
					<input type="text" name="email" id="email" value="<?php echo $aProxyInfo['email']; ?>" disabled="disabled" />
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">手机：</div>
				<div class="control">
					<input type="text" name="mobile" id="mobile"  value="<?php echo $aProxyInfo['mobile']; ?>" disabled="disabled"/>
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">电话：</div>
				<div class="control">
					<input type="text" name="telephone" id="telephone"  value="<?php echo $aProxyInfo['telephone']; ?>" />
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">传真：</div>
				<div class="control">
					<input type="text" name="fax" id="fax"  value="<?php echo $aProxyInfo['fax']; ?>" />
				</div>
			</div>
			<div class="clear"></div>			
			<div class="item">
				<div class="name">省份：</div>
				<div class="control">
					<select name="province" id="province"></select>
					<select name="city" id="city"></select>
					<select name="area" id="area"></select>
				</div>
			</div>

			<div class="clear"></div>	
				<div class="item">
				<div class="name">详细地址：</div>
				<div class="control">
					<textarea name="address" id="address"><?php echo $aProxyInfo['address']; ?></textarea>
				</div>
			</div>
			<div class="clear"></div>	
				<div class="item">
				<div class="name">佣金比：</div>
				<div class="control">
					<input type="text" name="commission" id="commission"  value="<?php echo $aProxyInfo['commission']; ?>" />%
				</div>
			</div>			
			<div class="clear"></div>
			<div class="item">
				<div class="name">状态：</div>
				<div class="control">
					<select disabled="disabled">
					<?php foreach($statusArray as $key=>$statusInfo){?>
							<option value="<?php echo $key;?>" <?php if($key == $aProxyInfo['status']){echo 'selected="selected"';}?> ><?php echo $statusInfo;?></option>
					<?php }?>		
					</select>
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">审核：</div>
				<div class="control">
					<select name="status" id="status">
						<option value="0">请审核</option>
						<option value="3" <?php if($aProxyInfo['status'] == 3){echo 'selected="selected"';}?>>通过认证</option>
						<option value="4" <?php if($aProxyInfo['status'] == 4){echo 'selected="selected"';}?>>不通过认证</option>	
					</select>
				</div>
			</div>
			<div class="clear"></div>



			<span id="hiddenFileUrl"></span>
			<div class="clear"></div>
			<div class="item">
				<div class="name" >更新资料：</div>
				<div class="control" style="overflow:hidden"><input type="file" name="imgUpload" id="imgUpload" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">下载资料：</div>
				<div class="control" id="downLoadFile">
				<?php if($aProxyInfo['zipFile']){?>
					<a href="<?php echo $aProxyInfo['zipFile'];?>" target="_blank">下载</a>
				<?php 
					}else{
					echo '末上传'; 
				}?>
					
					
				</div> 
			</div>
			<div class="clear"></div>			
			
			
			<div class="item _button">
				<style type="text/css">
						._button .control a{width:50px; height:30px;}
					</style>
				<div class="name"></div>
				<div class="control">
					
					<a class="button" onclick="alterInfo();" >确认修改</a>
				</div>
			</div>
			<div class="clear"></div>
		</form>
	</div>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
			
	$(function(){
		var oAddressInit = new addressInit('province', 'city', 'area',<?php echo $aProxyInfo['province']?>,<?php echo $aProxyInfo['city']?>,<?php echo $aProxyInfo['area']?>);
		oAddressInit.load();

		$("#imgUpload").uploadify({
			'fileTypeExts' : '*.zip',
			'fileSizeLimit' : '5MB',
			'height' : 30,
			'width' : 100,
			'swf' : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'].$GLOBALS['RESOURCE']['uploadify']['swf']; ?>',
			'uploader' : 'http://<?php echo APP_MANAGE ?>/?m=Proxy&a=uploadFile&proxyId=<?php echo $aProxyInfo['id'];?>&ajax=1',
			'buttonText' : '选择文件',
			'multi' : true,
			'onUploadSuccess' : function(file, data, response){
				//console.log(data);
				data = eval('(' + data + ');');
				if(data.status == 1){
					$('#downLoadFile').html('<a href="'+data.data+'" target="_blank">下载</a>');
				}else{
					UBox.show(data.msg,0);
				}
				$('#hiddenFileUrl').empty();
			}
		});
	})

	//JAVASCRIPT IP列表
	function checkApiIp(){

		var _api_ip_list = $.trim($('#api_ip_list').val());
		if(_api_ip_list){
			var arr = _api_ip_list.split('|');
			var reg = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
			for(i=0;i<arr.length;i++){
					if(!reg.test(arr[i])){
						UBox.show('代理商ip格式错误');
						return false;
					}
					var arr2 = arr[i].split('.');
					for(j=0;j<arr2.length;j++){
							if(parseInt(arr2[j]) > 255){
								UBox.show('代理商ip格式错误');
								return false;
							}
						}				
				}	
		}

		return true;
	}

	//JAVASCRIPT 传真号
	function checkFax(){
		var _fax = $.trim($('#fax').val());
		var reg =/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/; 
         if(_fax){
			if(!reg.test(_fax)){
					UBox.show('传真号格式错误');
					return false;
				}
             }
         return true;
    }
	

	//JAVASCRIPT 电话号
	function checkTel(){
		var _tel = $.trim($('#telephone').val());
		var reg =/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/; 
         if(_tel){
			if(!reg.test(_tel)){
					UBox.show('电话号格式错误', -1);
					return false;
				}
             }
         return true;
    }

	//JAVASCRIPT 佣金比
	function checkCommission(){
		
		var _commission = $.trim($('#commission').val());
		var reg = /^\d{1,2}$/;
		if(_commission){
			if(!reg.test(_commission)){
				UBox.show('佣金比例填写错误');
				return false;
			}	
		}
		
		return true;
	}

	
	function alterInfo(){
		if(!checkApiIp() || !checkFax() || !checkTel()|| !checkCommission()){
			return false;
		}
		UBox.confirm('确定修改吗？', function(){
			$.ajax({
				url:'/?m=Proxy&a=edit&id=<?php echo $aProxyInfo['id'];?>',
				data:$('form').serialize(),
				type:'POST',
				dataType:'json',
				success:function(result){
					if(result.status == 1){
						window.location.href= '?m=Proxy&a=showProxyList';	
					}else{
						UBox.show(result.msg,result.status);	
					}
				},
				error:function(){
					UBox.show('更新失败',-1);
				}
					
			});
		})
	}
</script>