<?php display('proxy/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		.status a{color:#999; margin-right:10px;}
		.status .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
	</style>
	<?php if($aProxyInfo){?>
		<div class="title">代理商信息</div>
		<div class="item">
			<div class="name width80">机构名：</div>
			<div class="control"><?php echo $aProxyInfo['name'];?></div>
			<div class="name width80">佣金比：</div>
			<div class="control"><?php echo $aProxyInfo['commission'];?>%</div>
			<div class="name width80"><a href="/?m=Proxy&a=showProxyEdit&id=<?php echo $aProxyInfo['id']?>">详细信息</a></div>			
		</div>	
		<div class="clear"></div>
		<div class="title">佣金信息</div>
		<?php 
			}else{
				echo '<font color=red>抱歉，代理商不存在！</font>';
			}
		?>
</div>
<div class="br"></div>

<?php setRefererMark(); ?>
