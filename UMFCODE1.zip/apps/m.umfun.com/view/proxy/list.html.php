<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('proxy/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		.status a{color:#999; margin-right:10px;}
		.status .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
	</style>
	<form>
		<div class="item">
			<div class="name width80">认证状态：</div>
			<div class="control status">
				<input id="status" name="status" type="hidden" value="<?php echo $status;?>" />
				<a id="status0" onclick="javascript:getStatus(0)" <?php if($status == 0){echo 'class="on"';}?>>全部</a>
				<a id="status1" onclick="javascript:getStatus(1)" <?php if($status == 1){echo 'class="on"';}?>>末审请</a>
				<a id="status2" onclick="javascript:getStatus(2)" <?php if($status == 2){echo 'class="on"';}?>>待审核</a>
				<a id="status3" onclick="javascript:getStatus(3)" <?php if($status == 3){echo 'class="on"';}?>>己通过</a>
				<a id="status4" onclick="javascript:getStatus(4)" <?php if($status == 4){echo 'class="on"';}?>>末通过</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">邮箱：</div>
			<div class="control"><input type="text" name="email" id="email" value="<?php echo $email;?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="proxySearch(1);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name width80">电话号码：</div>
			<div class="control"><input type="text" name="telephone" id="telephone" value="<?php echo $telephone;?>" /></div>
			<div class="name width80">手机号码：</div>
			<div class="control"><input type="text" name="mobile" id="mobile" value="<?php echo $mobile;?>" /></div>
			<div class="name width80">传真号码：</div>
			<div class="control"><input  type="text" name="fax" id="fax" value="<?php echo $fax;?>" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">佣金比：</div>
			<div class="control"><input  type="text" name="commission" id="commission" value="<?php echo $commission;?>" /></div>
			<div class="name width80">创建时间：</div>
			<div class="control"><input type="text" name="createTime" id="createTime" value="<?php echo $createTime;?>" onclick="WdatePicker({dateFmt:'yyyy-MM-dd H:m:s'})" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name width80">省份：</div>
			<div class="control"><select name="province" id="province" ></select></div>
			<div class="name">城市：</div>
			<div class="control"><select name="city" id="city" ></select></div>
			<div class="name">地区：</div>
			<div class="control"><select name="area" id="area" ></select></div>
			<div class="name width100">API激活状态：</div>
			<div class="control">
				<select name="apiIsActive" id="apiIsActive" >
					<option value="">请选择</option>
					<option value="0" <?php if($apiIsActive == '0'){echo 'selected="selected"';}?>>末激活</option>
					<option value="1" <?php if($apiIsActive == '1'){echo 'selected="selected"';}?>>己激活</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="proxySearch(2);">搜素</a>
			</div>
		</div>
	</form>
	<script type="text/javascript">
		function getStatus(id){
			if(id >= 0 && id < 5){
				$('#status').val(id);

				var url = '?m=Proxy&a=showProxyList&status='+id;
				window.location.href = url;
			}
		}

		function proxySearch(type){
			var url = '?m=Proxy&a=showProxyList&status=<?php echo $status;?>';
			if(type == 1){
				var email = $.trim($('#email').val());
				if(email){
					var emailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
					if(!emailReg.test(email)){
						$('#email').select();
						UBox.show('邮箱输入不合法', -1);
						return false;
					}else{
						url += "&email="+email;
					}
				}
				window.location.href = url;
			}else if(type == 2){
				var telephone = $.trim($('#telephone').val());
				if(telephone){
					var telephoneReg =/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/;
					if(!telephoneReg.test(telephone)){
						$('#telephone').select();
						UBox.show('电话输入不合法', -1);
						return false;
					}
					url += '&telephone='+telephone;
				}

				var mobile = $.trim($('#mobile').val());
				if(mobile){
					var mobileReg =/^((\+86)|(86))?1[3|4|5|8]{1}\d{9}$/;
					if(!mobileReg.test(mobile)){
						$('#mobile').select();
						UBox.show('手机号输入不合法', -1);
						return false;
					}
					url += '&mobile='+mobile;
				}

				var fax = $.trim($('#fax').val());
				if(fax){
					var faxReg =/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/;
					if(!faxReg.test(fax)){
						$('#fax').select();
						UBox.show('传真号输入不合法', -1);
						return false;
					}
					url += '&fax='+fax;
				}

				var commission = $.trim($('#commission').val());
				if(commission){
					var commissionReg =/^\d{1,2}?$/;
					if(!commissionReg.test(commission)){
						$('#commission').select();
						UBox.show('佣金比为1到100的正整数', -1);
						return false;
					}else{
						var commission = parseInt(commission);
						if( 1 > commission || commission >100){
							$('#commission').select();
							UBox.show('佣金比为1到100的正整数', -1);
							return false;
						}
						url += '&commission='+commission;
					}
				}

				var createTime = $.trim($('#createTime').val());
				if(createTime){
					url += '&createTime='+createTime;
				}

				var province = parseInt(($('#province').val()));
				if(province > 0){
					url += '&province='+province;
				}

				var city = parseInt(($('#city').val()));
				if(city > 0){
					url += '&city='+city;
				}

				var area = parseInt(($('#area').val()));
				if(area > 0){
					url += '&area='+area;
				}

				var status = parseInt(($('#status').val()));
				if(status >= 0 && status < 5){
					url += '&status='+status;
				}
				var apiIsActive = $('#apiIsActive').val()
				if(apiIsActive == '0' || apiIsActive == '1'){
					url += '&apiIsActive='+apiIsActive;
				}
				window.location.href = url;
			}

		}
	</script>
</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
		._userList .list .c1{width:150px;}
		._userList .list .c2{width:150px;}
		._userList .list .c3{width:100px;}
		._userList .list .c6{width:100px;}
		._userList .list .c7{width:100px;}
		._userList .list .c8{width:80px;}
		._userList .list .c9{width:80px;}
		._userList .list .c10{width:320px;}
		._userList .list .row .c10 a{padding-right:7px;}
	</style>
	<div class="title">代理商列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">代理机构名</div>
			<div class="c2">邮箱</div>
			<div class="c3">手机号</div>
			<div class="c6">电话</div>
			<div class="c8">状态</div>
			<div class="c9">创建时间</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aProxyList){
			foreach($aProxyList as $aProxyInfo){ ?>
			<div class="row">
				<div class="c1"><?php echo $aProxyInfo['name'] ? $aProxyInfo['name'] : '&nbsp;'; ?></div>
				<div class="c2"><?php echo $aProxyInfo['email'] ? $aProxyInfo['email'] : '&nbsp;'; ?></div>
				<div class="c3"><?php echo $aProxyInfo['mobile'] ? $aProxyInfo['mobile'] : '&nbsp;'; ?></div>
				<div class="c6"><?php echo $aProxyInfo['telephone'] ?  $aProxyInfo['telephone'] : '&nbsp;'; ?></div>

				<div class="c8"><?php echo $aProxyInfo['statusName'];?></div>
				<div class="c9"><?php echo date('Y-m-d',$aProxyInfo['create_time']); ?></div>
				<div class="c10 right">
					<a href="/?m=Recharge&a=showRechargeList&byProxyId=<?php echo $aProxyInfo['id']?>">代理充值记录</a>
					<a href="/?m=Recharge&a=showRechargeList&proxyId=<?php echo $aProxyInfo['id']?>">分红充值记录</a>
					<a href="/?m=Proxy&a=showCommission&id=<?php echo $aProxyInfo['id'];?>">查看佣金</a>
				<?php if($aProxyInfo['zipFile']){?>
					<a href="<?php echo $aProxyInfo['zipFile']?>" target="_blank">下载附件</a>
				<?php }else{?>
					<a href="#" >末上传</a>
				<?php }?>
					<a href="/?m=Proxy&a=showProxyEdit&id=<?php echo $aProxyInfo['id']?>">编辑</a>
				</div>
			</div>
		<?php }
		}else{
			echo '<font color=red>抱歉，暂时缺乏数据！</font>';
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
$(function(){
	var oAddressInit = new addressInit('province', 'city', 'area', '<?php echo $province;?>', '<?php echo $city;?>', '<?php echo $area;?>');
	oAddressInit.load();
})

</script>