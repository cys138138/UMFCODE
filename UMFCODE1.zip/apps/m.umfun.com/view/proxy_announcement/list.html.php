<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('proxy_announcement/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>
	<form>
		<div class="item">
			<div class="name">标题：</div>
			<div class="control"><input type="text" id="announcementTitle" value="<?php echo $announcementTitle;?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="announcementSearch(1);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">发布人：</div>
			<div class="control"><input type="text" name="publisher" id="publisher" value="<?php echo $publisher;?>"/></div>
			<div class="name width80">发布时间：</div>
			<div class="control"><input type="text" name="createTime" id="createTime" value="<?php echo $createTime;?>" onclick="WdatePicker({dateFmt:'yyyy-MM-dd H:m:s'})" /></div>
			<div class="name">类型：</div>
			<div class="control">
				<select name="type" id="type">
					<option value="0">-请选择-</option>
					<?php if($typeArray){
						foreach($typeArray as $key=>$value){
							if($type == $key){
								echo '<option value="' . $key . '" selected="selected">'.$value.'</option>';
							}else{
								echo '<option value="' . $key . '">'.$value.'</option>';
							}
						}
					}?>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="announcementSearch(2);">搜素</a>
			</div>
		</div>
		<script type="text/javascript">
			function announcementSearch(type){
				var url = '?m=ProxyAnnouncement&a=showProxyAnnouncementList';
				if(type == 1){
					var announcementTitle = $.trim($('#announcementTitle').val());
					if(announcementTitle){
						url += '&announcementTitle='+announcementTitle;
					}
					window.location.href= url;
				}else if(type == 2){
					var publisher= $.trim($('#publisher').val());
					if(publisher){
						url += '&publisher='+publisher;
					}

					var createTime = $.trim($('#createTime').val());
					if(createTime){
						url += '&createTime='+createTime;
					}

					var type = $('#type').val();
					if(type > 0){
						url += '&type='+type;
					}
					window.location.href = url;
				}
			}
		</script>
	</form>

</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
 		._userList .list .c1{width:150px;}
		._userList .list .c2{width:150px;}
		._userList .list .c3{width:100px;}
		._userList .list .c6{width:120px;}
		._userList .list .c7{width:100px;}
		._userList .list .c8{width:80px;}
		._userList .list .c9{width:80px;}
		._userList .list .c10{width:200px;}
		._userList .list .row .c10 a{padding-right:7px;}
	</style>
	<div class="title">代理商公告列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">公告标题</div>
			<div class="c2">公告类型</div>
			<div class="c3">发布者</div>
			<div class="c6">发布时间</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aAnnouncementList){
			foreach($aAnnouncementList as $aAnnouncementInfo){ ?>
			<div class="row">
				<div class="c1"><?php echo $aAnnouncementInfo['title'] ? $aAnnouncementInfo['title'] : '&nbsp;'; ?></div>
				<div class="c2"><?php echo $aAnnouncementInfo['typeName'] ? $aAnnouncementInfo['typeName'] : '&nbsp;'; ?></div>
				<div class="c3"><?php echo $aAnnouncementInfo['publisherName'] ? $aAnnouncementInfo['publisherName'] : '&nbsp;'; ?></div>
				<div class="c6"><?php echo date('Y-m-d H:i:s',$aAnnouncementInfo['create_time']); ?></div>
				<div class="c10 right">
					<a href="/?m=ProxyAnnouncement&a=showEdit&id=<?php echo $aAnnouncementInfo['id'];?>">编辑</a>
					<a href="javascript:void(0)" onclick="javascript:delAnnouncement(<?php echo $aAnnouncementInfo['id']?>)">删除</a>
				</div>
			</div>
		<?php } 
		}else{
			echo '<font color=red>抱歉，暂时缺乏数据！</font>'; 
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
	function delAnnouncement(_id){
		if(parseInt(_id) > 0){
			UBox.confirm('确定删除吗',function(){
				$.ajax({
					url:'?m=ProxyAnnouncement&a=del',
					data:{id:_id},
					type:'POST',
					dataType:'json',
					success:function(result){
						if(result.status == 1){
							window.location.reload();
						}else{
							UBox.show(result.msg,0);
						}		
					},
					error:function(){
						UBox.show('删除失败',-1);
					}
					});
				})
		}
	}

</script>