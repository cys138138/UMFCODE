<div class="nav">
	<a <?php if(get('a') == 'showProxyAnnouncementList'){ ?>class="on"<?php } ?> href="?m=ProxyAnnouncement&a=showProxyAnnouncementList">公告列表</a>
	<a <?php if(get('a') == 'showAdd'){ ?>class="on"<?php } ?> href="?m=ProxyAnnouncement&a=showAdd">添加公告</a>
	<a <?php if(get('a') == 'showStatistics'){  ?>class="on"<?php } ?> href="?m=Proxy&a=showStatistics">统计</a>
	<?php if(get('a') == 'showEdit'){echo '<a class="on">编辑</a>';}?>
</div>

<div class="br"></div>
