<?php display('proxy_announcement/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._subject span{margin-right:15px; display:inline-block;}
	</style>
	<form id="announcementEdit" class="addForm" method="post" action="/?m=ProxyAnnouncement&a=edit&id=<?php echo $aAnnouncementInfo['id'];?>">
		<div class="title">编辑公告</div>
		<div class="item">
			<div class="name">标题：</div>
			<div class="control"><input type="text" name="announcementTitle" id="announcementTitle" value="<?php echo $aAnnouncementInfo['title'];?>" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">类型：</div>
			<div class="control">
				<select name="type" id="type">
					<?php 
						foreach ($announcementType as $key=>$value){
					?>
						<option value="<?php echo $key;?>" <?php if($value['type'] == $key){echo 'selected';}?>><?php echo $value;?></option>
					<?php 
						}
					?>
				</select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">内容：</div>
			<div class="control">
				<textarea name="content" cols="60" rows="5"><?php echo $aAnnouncementInfo['content'];?></textarea>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" id="submitButton"/>保存公告</a></div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddAnnouncementJs; ?>
$('#submitButton').click(function(){

	if(checkForm() == true){
		$('#announcementEdit').submit();
	}
})


</script>