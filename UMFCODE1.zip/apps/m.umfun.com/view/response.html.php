<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>系统提示</title>
<body>
<div class="container">
	<style type="text/css">
		.container{width:500px; height:200px; margin:0 auto; padding-top:100px; text-align:center;}
		.content{font-size:26px; color:<?php if($status == 1){ echo '#000';}else{ echo 'red'; }?>;}
	</style>
	<div class="content"><?php echo $msg; ?></div><br/>
	<div>
		<a href="javascript:history.go(-1);" onclick="">返回上一页</a>
		<a href="javascript:location.reload(true);" onclick="">刷新重试</a>
	</div>
</div>
</body>
</html>