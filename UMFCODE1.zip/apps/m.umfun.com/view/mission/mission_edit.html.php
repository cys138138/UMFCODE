<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<?php display('mission/mission_nav.html.php')?>
<div class="module _missionAdd">
	<style type="text/css">
		._missionAdd{min-width:1200px;}
		._missionAdd ._subject .control a{margin:0 7px; color:#9a9393;}
		._missionAdd ._subject .control .on{color:#000; font-weight:bold;}
		._missionAdd .item .name{width:100px; color:#000;}
		._missionAdd .item .comment{margin-right:10px; color:#797676;}
		._missionAdd .control{color:#000;}
		._missionAdd ._condition .control input[type=text]{width:50px; margin:0 14px 0 4px;}
		._missionAdd ._esType .control input[type=text]{width:50px; margin:0 14px 0 4px;}
	</style>
	<div class="title"><?php echo $GLOBALS['SUBJECT'][$aMissionInfo['subject_id']]; ?>关卡编辑</div>
	<div class="clear"></div>
	<form id="missionAdd">
		<input type="hidden" name="subjectId" value="<?php echo get('subject_id'); ?>" />
		<input type="hidden" name="missionId" value="<?php echo $aMissionInfo['id']; ?>" />
		<div class="item _mission">
			<div class="name">关卡名称：</div>
			<div class="control"><input type="text" name="missionName" id="missionName" value="<?php echo $aMissionInfo['name']; ?>"></div>
			<div class="name">练习正确题数：</div>
			<div class="control"><input  type="text" name="missionCorrectCounts" id="missionCorrectCounts" value="<?php if(isset($aMissionInfo['task_content']['correct_counts'])){ echo $aMissionInfo['task_content']['correct_counts']; } ?>" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item _condition">
			<div class="name">关卡挑战限时：</div>
			<div class="control">
				<input  type="text" name="missionDuration" id="missionDuration"  value="<?php echo $aMissionInfo['challenge_limit_duration']?>"/></div>
			<div class="comment">(单位：分钟)</div>
			<div class="name">关卡挑战血量：</div>
			<div class="control"><input  type="text" name="missionBlood" id="missionBlood" value="<?php echo $aMissionInfo['challenge_limit_blood']; ?>"/></div>	
			<div class="comment">(单位：滴)</div>
			<div class="name">关卡排序：</div>
			<div class="control"><input  type="text" name="missionOrders" id="missionOrders" value="<?php echo $aMissionInfo['orders']; ?>"/></div>	
			<div class="comment">(注：最后追加的添加关卡建议使用10的倍数)</div>
		</div>
		<div class="clear"></div>
		<div class="item _esType">
			<div class="name">题型及数量：</div>
			<?php $GLOBALS['SUBJECT_TYPE'][$aMissionInfo['subject_id']][] = 0;		
				  $GLOBALS['ES_TYPE'][0] = '随机题';
			foreach($GLOBALS['SUBJECT_TYPE'][$aMissionInfo['subject_id']] as $type){?>
				<div class="control">
					<input id="id_<?php echo $type; ?>" <?php if(isset($aMissionInfo['challenge_es_count'])){foreach($aMissionInfo['challenge_es_count'] as $esTypeCount){
						if($esTypeCount['es_type_id'] == $type){
							echo 'checked ';
						}
					} }?> type="checkbox" name="esTypeSub[]" value="<?php echo $type; ?>" />
					<label for="id_<?php echo $type; ?>">
						<?php echo $GLOBALS['ES_TYPE'][$type]; ?>
					</label>
					<input type="text" name="esTypeNums<?php echo $type; ?>" <?php if(isset($aMissionInfo['challenge_es_count'])){foreach($aMissionInfo['challenge_es_count'] as $esTypeCount){
						if($esTypeCount['es_type_id'] == $type){
							echo 'value="' . $esTypeCount['es_count'] . '" ';
						}
					} } ?> />
				</div>
			<?php } ?>
		</div>
		<div class="clear"></div>
		
		<div class="item _mission">
			<div id="categoryIds"></div>
			<div class="name">关卡知识点：</div>
			<div class="control" id="missionCategory"></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name"></div>
			<div class="control"><a onclick="saveMission();" class="button">修改</a></div>
		</div>
		<div class="clear"></div>
	</form>
	<div class="item">
		<div class="name">目录：</div>
		<div class="control" id="category">
			<script type="text/javascript">
				oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
				oDirTree.add(0, -1, '<?php echo $GLOBALS['SUBJECT'][$aMissionInfo['subject_id']]; ?>目录');
				var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
				$(aCategoryList).each(function(){
					var esCount = this.es_count > 0 ? '(' + this.es_count + '题)' : '';
					oDirTree.add(this.id, this.parent_id, this.name, '#catalogue' + this.id, this.name);
				});
				document.write(oDirTree);
			</script>
		</div>
	</div>
	<div class="clear"></div>
</div>
<script type="text/javascript">
	var aCategoryList = new Array();
	<?php foreach($aMissionInfo['category_ids'] as $missionId){ ?>
		aCategoryList.push(<?php echo $missionId; ?>);
		$('#categoryIds').append('<input type="hidden" xid="' + <?php echo $missionId; ?> + '"  name="missionCategoryIds[]" id="missionCategoryIds" value="'+ <?php echo $missionId; ?> +'"/>');
	<?php } ?>
	
	for(var subscript in aCategoryList){
		var outCategoryname = oDirTree.getName(aCategoryList[subscript]);
		$('#missionCategory').append('<label xid='+ aCategoryList[subscript] +'>' + outCategoryname + '<a style="font-size:18px;" onclick="deleteCategory(' + aCategoryList[subscript] + ')">×</a>&nbsp;&nbsp;&nbsp;</label>');
	}
	
	function getCategoryId(){
		var categoryId = oDirTree.getSelected();
		var categoryName = oDirTree.getName(categoryId);
		if(!oDirTree.isNoChild(categoryId)){
			UBox.show('请选择一个最终目录');
			if($('#new_category_id').val()){
				$('#new_category_id').val(0);
			}
			return false;
		}
		for(var subscript in aCategoryList){
			if(aCategoryList[subscript] == categoryId){
				UBox.show('您已经添加了这个分类了！', -1);
				return false;
			}
		}
		aCategoryList.push(categoryId);
		$('#categoryIds').append('<input type="hidden" xid="' + categoryId + '"  name="missionCategoryIds[]" id="missionCategoryIds" value="' + categoryId + '"/>');
		$('#missionCategory').append('<label xid='+ categoryId +'>' + categoryName + '<a style="font-size:18px;" onclick="deleteCategory(' + categoryId + ')">×</a>&nbsp;&nbsp;&nbsp;</label>');
	}

	<?php
	if(isset($aCategoryList)){
	?>
		$(function(){
			for(i = 1; i <= <?php echo count($aCategoryList); ?>; i++){
				$('#soDirTree' + i).click(getCategoryId);
			}
		});
	<?php
	}
	?>
	<?php echo $editMissionValidateJs; ?>
	function saveMission(){
		if(!checkForm()){
			return false;
		}
		$.ajax({
			type : 'post',
			url : '?m=Mission&a=editMission',
			dataType : 'json',
			data : $('#missionAdd').serialize(),
			success : function(result){
				UBox.show(result.msg, result.status, result.data);
			
			},
			error : function(request){
				UBox.show('抱歉！系统有误，请稍后再试！', -1);
			}
		});
	}
	
	function deleteCategory(index){
		UBox.confirm(
			'确定删除这个知识点吗？',
			function(){
				$('label[xid=' + index + ']').remove();
				$('input[xid=' + index + ']').remove();
			}
		);
	}
</script>
