<?php display('mission/mission_nav.html.php')?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<div class="module _missionList">
	<style type="text/css">
		._missionList{min-width:1630px;}
		._missionList .title .on{color:#000; font-weight:bold;}
		._missionList .title a{color:#8d8b8b; margin-left:10px;}
		._missionList ._mission .c1{width:150px;}
		._missionList ._mission .c2{width:300px; overflow:auto; white-space:normal;  text-overflow:auto;}
		._missionList ._mission .c3{width:200px;}
		._missionList ._mission .c4{width:70px;}
		._missionList ._mission .c5{width:80px;}
		._missionList ._mission .c6{width:80px;}
		._missionList ._mission .c7{width:80px;}
		._missionList ._mission .c8{width:70px;}
		._missionList ._mission .c9{width:50px;}
		._missionList ._mission .c10{width:250px;}
		._missionList ._mission .c11 a{margin-left:10px;}
		._missionList ._mission .c11 .insert{display:none;}
		
		._missionList .item{min-width:800px;}
		._missionList .item .titles{min-width:300px;}
		._missionList .item .categroy{ padding-left:5px; width:195px;float:right;border:1px solid #BBB; height:26px; margin-right: 5px;color: #999;cursor:pointer;}
		._missionList .item .categroy p:hover > .add_categroy{background: #1D6CA2; }
		._missionList .item .categroy p .categroy_title{width: 160px;overflow: hidden;height: 28px;display: inline-block;}
		._missionList .item .categroy:hover > ul{display: block;}
		._missionList .item .categroy .add_categroy{width:30px;text-align:center;background:#489EE2;color:#FFF;height:26px;line-height:22px;float:right;font-size:18pt;}
		._missionList .item .categroy ul{ border-radius:0 0 5px 5px; display: none; position: absolute; z-index: 9;background: #FFF;border-left: 1px solid #CCC;border-right: 1px solid #CCC;padding: 0;margin: -1px 0 0 -7px;min-width:200px;max-width: 276px; max-height:250px; height:auto; overflow: auto;box-shadow: 0 8px 37px rgba(0, 0, 0, 0.4);}
		._missionList .item .categroy ul > li {list-style: none;color:#000; height:25px; overflow: hidden;}
		._missionList .item .categroy ul li.even{background:#ECECEC;}
		._missionList .item .categroy ul li:hover{background: #6299D4;color:#fff;}
		._missionList .item .categroy ul li i{font-style: normal;display: inline-table;width: 30px;text-align: center;background: #AFC3D6;color: #FFF;margin-right: 2px;}
		._missionList .item .categroy ul li i:hover{background: #2A5B7C;}
		#easyDialogAddBtn{float: left;margin-left: 20px;}
	</style>
	<div class="item">
		<div class="name">关卡名称：</div>
		<div class="control">
			<input type="text" id="searchTitle" class="titles" value="<?php echo get('title');?>"/>&nbsp;&nbsp;

			<div class="categroy">
				<p onclick="showCategroy()">
					<span class="categroy_title" id="CategroyTitle">选择目录(默认全部)</span>
					<span class="add_categroy" id="addCategroy">+</span>
				</p>
				<ul class="change_categroy" id="changeCategroy">
					<?php
						foreach($aCategoryList as $key => $aCategoryValue){
								echo '<li data-id="' . $aCategoryValue['id'] . '">
										<i>X</i>
										<span title="'. $aCategoryValue['name'] . '">' . $aCategoryValue['name'] . '</span>
									  </li>';
						}
					 ?>
				</ul>
			</div>
			&nbsp;&nbsp;
		</div>
		<div class="control"><button onclick="searchMission()" type="button" class="btnOperation"> 搜 索 </a></div>
	</div>

	<div class="clear"></div>
	
	<div class="title">关卡列表 ：
		<?php foreach($aSubject as $key => $subject){ ?>
				<a <?php if($subjectId == $key){ echo 'class="on"'; } ?> href="?m=Mission&a=showList&subject_id=<?php echo $key; ?>"><?php echo $subject; ?></a>
		<?php } ?>
	</div>
	<div class="list _mission">
		<div class="row header">
			<div class="c1">关卡名称</div>
			<div class="c2">关卡知识点</div>
			<div class="c3">闯关题目数</div>
			<div class="c4">练习题数</div>
			<div class="c5">时间&nbsp;(分钟)</div>
			<div class="c6">生命值&nbsp;(滴)</div>
			<div class="c7">闯关总次数</div>
			<div class="c8">过关次数</div>
			<div class="c9">排序</div>
			<div class="c10">题目数</div>
			<div class="c11 right">操作</div>
		</div>
		<?php foreach($aMissionList as $aMission){ ?>
		<div class="row missionList">
			<div class="c1" title="<?php echo $aMission['name']; ?>"><?php echo $aMission['name']; ?></div>
			<div title="<?php 
					foreach($aMission['category_name'] as $aCategoryPath){ 
						echo $aCategoryPath['category_path']; 
					}
					foreach($aMission['warehouse_es_counts'] as $typeKey => $esTypeAndCounts){
						echo $typeKey . '：' . $esTypeAndCounts . ' &nbsp;&nbsp;&nbsp;';
					}
				?>" class="c2">
				<?php 
					foreach($aMission['category_name'] as $aCategoryPath){ 
						echo $aCategoryPath['category_path'] . '<br />'; 
					} 
				?>
				(<?php
					foreach($aMission['warehouse_es_counts'] as $typeKey => $esTypeAndCounts){
						echo $typeKey . '：<font color="red">' . $esTypeAndCounts . '</font> &nbsp;&nbsp;&nbsp;';
					}
				?>)
			</div>
			<div title="<?php foreach($GLOBALS['SUBJECT_TYPE'][$aMission['subject_id']] as $esType){
					foreach($aMission['challenge_es_count'] as $esCount){
						if($esCount['es_type_id'] == $esType){
							echo $GLOBALS['ES_TYPE'][$esType] . ':&nbsp;';
							echo $esCount['es_count'] . '&nbsp;';
						}
					}
				} ?>" class="c3">
				<?php
					foreach($GLOBALS['SUBJECT_TYPE'][$aMission['subject_id']] as $esType){
						foreach($aMission['challenge_es_count'] as $esCount){
							if($esCount['es_type_id'] == $esType){
								echo $GLOBALS['ES_TYPE'][$esType] . ':&nbsp;';
								echo '<span class="red">' . $esCount['es_count'] . '</span>&nbsp;';
							}
						}
					}
				?>&nbsp;
			</div>
			
			<div class="c4"><?php echo $aMission['task_content']['correct_counts']; ?></div>
			<div class="c5"><?php echo $aMission['challenge_limit_duration']; ?></div>
			<div class="c6"><?php echo $aMission['challenge_limit_blood']; ?></div>
			<div class="c7"><?php echo $aMission['challenge_count']; ?></div>
			<div class="c8"><?php echo $aMission['challenge_success_count']; ?></div>
			<div class="c9"><?php echo $aMission['orders']; ?></div>
			<div class="c10"><?php echo $aMission['all_es_counts']; ?></div>
			<div class="c11 right">
				<a class="insert" href="?m=Mission&a=showAddMission&subject_id=<?php echo $aMission['subject_id']; ?>&mission_id=<?php echo $aMission['id']; ?>" >插入关卡</a>
				<a href="?m=Mission&a=showMissionDetail&mission_id=<?php echo $aMission['id']; ?>">查看</a>
				<a href="?m=Mission&a=showEditMission&mission_id=<?php echo $aMission['id']; ?>">编辑</a>
				<a onclick="forbiddenMission(<?php echo $aMission['id']; ?>, <?php echo $aMission['is_forbidden'] == 1 ? 0 : 1;?>)"><?php echo $aMission['is_forbidden'] == 1 ? '解除' : '禁用'; ?></a>
			</div>
		</div>
		<?php }?>
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
var searchUrl = '?m=Mission&a=showList',
	searchCategoryId = [];

$(function(){
	$('ul#changeCategroy li:even').addClass('even');
	//删除多余选项
	$('#changeCategroy').on('click', 'i', function(){
		$(this).parent().hide('fast',function(){
			$(this).remove();
		});
	});
	
});

function searchMission(){
	if($('#changeCategroy li').length > 0){
		$('#changeCategroy li').each(function(){
			var categoryIdInt = parseInt($(this).data('id')),
				categoryName = $(this).find('span').text();
			if($.inArray(categoryIdInt, searchCategoryId) == -1){
				searchCategoryId.push(categoryIdInt);
			}
		});
	}
	var title = $('#searchTitle').val(),
		url = searchUrl;
	if(title.length > 1){
		url += '&title=' + title;
	}
	if(searchCategoryId.length > 0){
		url += '&categoryId=' + searchCategoryId;
	}
	window.location.href = url;
}

function callBack(categoryId, categoryName){
	var categoryIdInt = parseInt(categoryId);
	$('#changeCategroy li').each(function(){
		var categoryIdInt = parseInt($(this).data('id')),
			categoryName = $(this).find('span').text();
		if($.inArray(categoryIdInt, searchCategoryId) == -1){
			searchCategoryId.push(categoryIdInt);
		}
	});
	if($.inArray(categoryIdInt, searchCategoryId) != -1){
		UBox.show('已经存在的关卡', -1);
		return;
	}
	searchCategoryId.push(categoryIdInt);
	var changeHtml = '<li data-id="' + categoryId + '">\
						<i>X</i>\
						<span title="' + categoryName + '">' + categoryName + '</span>\
					</li>';
	
	$(changeHtml).appendTo($('#changeCategroy'));
	$('#CategroyTitle').text(categoryName);
}
function addOneCategroy(){
	var aCategoryInfo = {};
	aCategoryInfo = categroy.window.getCategoryInfo();
	if(aCategoryInfo.hasChild){
		UBox.show('请勿添加目录！', -1);
		return;
	}
	callBack(aCategoryInfo.id, aCategoryInfo.name);
}

function showCategroy(){
	var option = {
		title : '<?php echo $GLOBALS['SUBJECT'][$subjectId > 0 ? $subjectId : $aEsList[0]['subject_id']]; ?>目录',
		width : 520,
		content : '<iframe name="categroy" width="520" height="480"  frameborder="0" src="<?php echo '?m=EsCreate&a=showCategroyTree&callBack=1&subject_id=' . $subjectId; ?>" ></iframe>',
		confirmCallBack : addOneCategroy,
		cancleCallBack : function(){
			easyDialog.close();
		}
	};
	popEasyDialog(option);
	$('<button class="btn_highlight" onclick="addOneCategroy()" id="easyDialogAddBtn">增加</button>').appendTo($('#easyDialogNoBtn').parent());
}

function forbiddenMission(index, action){
	$.ajax({
		type : 'post',
		dataType : 'json',
		url : '?m=Mission&a=deleteMission',
		data : {mission_id : index, action_code : action},
		success : function(result){
			UBox.show(result.msg, result.status, 'reload');
		},
		error : function(request){
			UBox.show('网络可能有点慢，请稍后再试！', 0);
		}
	});

}
</script>