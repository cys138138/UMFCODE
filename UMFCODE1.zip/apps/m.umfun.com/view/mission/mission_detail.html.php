<?php display('mission/mission_nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:115px;}
		._main .item .control input{width:150px;}
	</style>
	<div class="title">关卡详情</div>
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<input type="text" disabled  value="<?php echo $GLOBALS['SUBJECT'][$aMissionInfo['subject_id']]; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">关卡名称：</div>
		<div class="control">
			<input type="text" disabled value="<?php echo $aMissionInfo['name']; ?>" />
		</div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">完成任务题数：</div>
		<div class="control">
			<input type="text" disabled="disabled" value="<?php echo $aMissionInfo['task_content']['correct_counts']; ?>" />
		</div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">闯关时间：</div>
		<div class="control">
			<input type="text" disabled="disabled" value="<?php echo $aMissionInfo['challenge_limit_duration']; ?>分钟" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">闯关生命值：</div>
		<div class="control">
			<input type="text" disabled="disabled" value="<?php echo $aMissionInfo['challenge_limit_blood']; ?>滴" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">闯关总次数：</div>
		<div class="control">
			<input type="text" disabled="disabled" value="<?php echo $aMissionInfo['challenge_count']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">闯关过关次数：</div>
		<div class="control">
			<input type="text" disabled="disabled" value="<?php echo $aMissionInfo['challenge_success_count']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">排序：</div>
		<div class="control">
			<input type="text" disabled="disabled" value="<?php echo $aMissionInfo['orders']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">挑战题目数：</div>
		<div class="control">
			<?php foreach($GLOBALS['SUBJECT_TYPE'][$aMissionInfo['subject_id']] as $esType){foreach($aMissionInfo['challenge_es_count'] as $esTypeCount){if($esTypeCount['es_type_id'] == $esType){ echo $GLOBALS['ES_TYPE'][$esType] . ':&nbsp;'; echo '<font color="red">' . $esTypeCount['es_count'] . '</font>&nbsp;&nbsp;&nbsp;&nbsp;';}}} ?>	
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">关卡知识点：</div>
		<div class="control">
			<?php foreach($aMissionInfo['category_name'] as $aCategoryPath){ echo $aCategoryPath['category_path'] . '<br />'; } ?>
			<?php
				foreach($aMissionInfo['warehouse_es_counts'] as $typeKey => $esTypeAndCounts){
					echo $typeKey . '：<font color=red>' . $esTypeAndCounts . '</font>&nbsp;&nbsp;&nbsp;';
				}
			?>
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">各题型题目数：</div>
		<div class="control">
			<?php echo $aMissionInfo['all_es_counts']; ?>
		</div>
	</div>	
</div>