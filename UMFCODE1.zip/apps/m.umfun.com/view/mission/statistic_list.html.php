<?php display('mission/mission_nav.html.php')?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<div class="module _condition">
	<style>
		._condition .item a{color:#999999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000000;}
		._condition .name{width:60px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FFCC00; margin-left:5px;}
	</style>
	
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<?php
				foreach($aSubject as $key => $subject){
			?>
					<a href="javascript:void(0)" <?php if($key == $subjectId){ ?> class="on" <?php } ?> onclick="setStatistic(2, <?php echo $key; ?>)"><?php echo $subject; ?></a>
			<?php
			}
			?>
		</div>
		<div class="clear"></div>
		<div class="name">时间：</div>
		<div class="control">
			<a href="javascript:void(0)" <?php if($dayType == 1){ ?> class="on" <?php } ?> onclick="setStatistic(3, 1)">最近3天</a>
			<a href="javascript:void(0)" <?php if($dayType == 2){ ?> class="on" <?php } ?> onclick="setStatistic(3, 2)">最近7天</a>
			<a href="javascript:void(0)" <?php if($dayType == 3){ ?> class="on" <?php } ?> onclick="setStatistic(3, 3)">最近15天</a>
			<a href="javascript:void(0)" <?php if($dayType == 4){ ?> class="on" <?php } ?> onclick="setStatistic(3, 4)">最近30天</a>
			<a href="javascript:void(0)" <?php if($dayType == 5){ ?> class="on" <?php } ?> onclick="setStatistic(3, 5)">全部</a>
			自定义时间查询：
			<input type="text" id="startTime" value="<?php echo date('Y-m-d H:i:s', $startTime); ?>" name="startTime" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" />&nbsp;-&nbsp;<input id="endTime" name="endTime" value="<?php echo date('Y-m-d H:i:s', $endTime); ?>" type="text" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" />
		</div>
		<div class="control"><a onclick="statistic()" class="button">确定</a></div>
	</div>

	<div class="clear"></div>

</div>
<div class="module">
	<style>
		._mission .row {font-weight:bold;}
		._mission .row .c0{width:200px; color:#000000;cursor:pointer;}
		._mission .row:hover{background: #DEE9F1;}
		._mission .row .c00{width:195px; color:#000000;}
		._mission .row .c1{width:60px;}
		._mission .row .c2{width:60px;}
		._mission .row .c3{width:60px;}
		._mission .row .c4{width:60px;}
		._mission .row .c5{width:60px;}
		._mission .row .c6{width:60px;}
		._mission .row .c7{width:60px;}
		._mission .row .c8{width:150px;}
		._mission .row .c9{width:60px;}
		._mission .row .c10{width:70px;}
		._mission .row .c11{width:70px;}
		._mission .row .c12{width:70px;}
		._mission .row .c13{width:70px;}
		._mission .row .c14{width:70px;}
		.list .header.fix {width:100%;position:fixed;top:0;}
	</style>
	<div class="list _mission">
		<div class="row header">
			<div class="c0">关卡名</div>
			<div class="c3">选择题</div>
			<div class="c4">判断题</div>
			<div class="c5">简易题型</div>
			<div class="c6">填空题</div>
			<div class="c7">复合题</div>
			<div class="c8">待复核题(到目前为止)</div>
			<div class="c9">总题数</div>
			<div class="c10">选择题占比</div>
			<div class="c11">判断题占比</div>
			<div class="c12">简易题占比</div>
			<div class="c13">填空题占比</div>
			<div class="c14">复合题占比</div>
		</div>
		<?php
			$allChooseEsCount = 0;
			$allJudgeEsCount = 0;
			$allEasyEsCount = 0;
			$allFillEsCount = 0;
			$allComplexEsCount = 0;
			$allWaitEndApproveEsCount = 0;
			$allTotalEsCount = 0;
		?>
		<?php foreach($aMissionEsStatisticList as $aMissionEsStatistic){ ?>

			<?php
				if(!isset($aMissionEsStatistic['es_count'][5])){
					$aMissionEsStatistic['es_count'][5] = 0;
				}
				if(!isset($aMissionEsStatistic['es_count'][6])){
					$aMissionEsStatistic['es_count'][6] = 0;
				}
				if(!isset($aMissionEsStatistic['es_count'][7])){
					$aMissionEsStatistic['es_count'][7] = 0;
				}
				$totalEs = $aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2] + $aMissionEsStatistic['es_count'][3] + $aMissionEsStatistic['es_count'][4] + $aMissionEsStatistic['es_count'][5] + $aMissionEsStatistic['es_count'][6] + $aMissionEsStatistic['es_count'][7];
				$allChooseEsCount += $aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2];
				$allJudgeEsCount += $aMissionEsStatistic['es_count'][3];
				$allEasyEsCount += $aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2] + $aMissionEsStatistic['es_count'][3];
				$allFillEsCount += $aMissionEsStatistic['es_count'][4] + $aMissionEsStatistic['es_count'][5];
				$allComplexEsCount += $aMissionEsStatistic['es_count'][6] + $aMissionEsStatistic['es_count'][7];
				$allWaitEndApproveEsCount += $aMissionEsStatistic['wait_end_approve_count'];
				$allTotalEsCount += $totalEs;
			?>
			<div class="row">
				<div class="c0" title="<?php echo $aMissionEsStatistic['name']; ?>" onclick="goEsMange(<?php
					echo get('subject',1) . ', ';
					echo count($aMissionEsStatistic['category_ids']) > 1 ? 0 : $aMissionEsStatistic['category_ids'][0];
				?>)"><?php echo $aMissionEsStatistic['name']; ?></div>
				<div class="c3"><?php echo $aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2]; ?></div>
				<div class="c4"><?php echo $aMissionEsStatistic['es_count'][3]; ?></div>
				<div class="c5"><?php echo $aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2] + $aMissionEsStatistic['es_count'][3]; ?></div>
				<div class="c6"><?php echo $aMissionEsStatistic['es_count'][4] + $aMissionEsStatistic['es_count'][5]; ?></div>
				<div class="c7"><?php echo $aMissionEsStatistic['es_count'][6] + $aMissionEsStatistic['es_count'][7]; ?></div>
				<div class="c8"><?php echo $aMissionEsStatistic['wait_end_approve_count']; ?></div>
				<div class="c9"><?php echo $totalEs; ?></div>
				<?php if($totalEs == 0){  $totalEs = 1;}?>
				<div class="c10"><?php echo round(($aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2]) * 100 / $totalEs, 2); ?></div>
				<div class="c11"><?php echo round(($aMissionEsStatistic['es_count'][3]) * 100 / $totalEs, 2); ?></div>
				<div class="c12"><?php echo round(($aMissionEsStatistic['es_count'][1] + $aMissionEsStatistic['es_count'][2] + $aMissionEsStatistic['es_count'][3]) * 100 / $totalEs, 2); ?></div>
				<div class="c13"><?php echo round(($aMissionEsStatistic['es_count'][4] + $aMissionEsStatistic['es_count'][5]) * 100 / $totalEs, 2); ?></div>
				<div class="c14"><?php echo round(($aMissionEsStatistic['es_count'][6] + $aMissionEsStatistic['es_count'][7]) * 100 / $totalEs, 2); ?></div>
			</div>
		<?php } ?>
		<div class="row footer">
			<?php //echo $pageHtml; ?>
			<div class="row">
				<div class="c00">总数</div>
				<div class="c3"><?php echo $allChooseEsCount; ?></div>
				<div class="c4"><?php echo $allJudgeEsCount; ?></div>
				<div class="c5"><?php echo $allEasyEsCount; ?></div>
				<div class="c6"><?php echo $allFillEsCount; ?></div>
				<div class="c7"><?php echo $allComplexEsCount; ?></div>
				<div class="c8"><?php echo $allWaitEndApproveEsCount; ?></div>
				<div class="c9"><?php echo $allTotalEsCount; ?></div>
				<div class="c10"><?php echo $allTotalEsCount ? round($allChooseEsCount * 100 / $allTotalEsCount, 2) : 0; ?></div>
				<div class="c11"><?php echo $allTotalEsCount ? round($allJudgeEsCount * 100 / $allTotalEsCount, 2) : 0; ?></div>
				<div class="c12"><?php echo $allTotalEsCount ? round($allEasyEsCount * 100 / $allTotalEsCount, 2) : 0; ?></div>
				<div class="c13"><?php echo $allTotalEsCount ? round($allFillEsCount * 100 / $allTotalEsCount, 2) : 0; ?></div>
				<div class="c14"><?php echo $allTotalEsCount ? round($allComplexEsCount * 100 / $allTotalEsCount, 2) : 0; ?></div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	var url = '<?php echo $baseUrl; ?>';
	var statisticCondition = {
		subject : <?php echo $subjectId; ?>,
		dayType : <?php echo $dayType; ?>,
	};
	function setStatistic(condition, value){
		if(condition == 2){
			statisticCondition.subject = value;
		}else if(condition == 3){
			statisticCondition.dayType = value;
		}

		statistic();
	}

	function goEsMange(subject, category_id){
		var esMangeUrl = 'http://<?php echo APP_MANAGE;?>/?m=ChiefEditor&a=showEsManage&count=1';
		if(category_id != 0){
			esMangeUrl += '&subject=' + subject + '&esStatus=3' + '&category_id=' + category_id;
		}else{
			esMangeUrl += '&subject=' + subject + '&esStatus=3';
		}
		window.location.href = esMangeUrl;
	}
	
	function statistic(){
		url += '&subject=' + statisticCondition.subject;
		if(statisticCondition.dayType != 0){
			url += '&dayType=' + statisticCondition.dayType;
			window.location.href = url;
			return;
		}else{
			var startTime = $('#startTime').val();
			var endTime = $('#endTime').val();
			if(!startTime){
				UBox.show('请填写开始时间');
				return false;
			}
			if(!endTime){
				UBox.show('请填写结束时间');
				return false;
			}
			url += '&startTime=' + startTime;
			url += '&endTime=' + endTime;
			window.location.href = url;
		}
	}

	$(function() {
		$(window).scroll(function(){
			if($(window).scrollTop() > 160){
				$('.list .header').addClass('fix');
			}else{
				$('.list .header').removeClass('fix');
			}
		});
	});
</script>