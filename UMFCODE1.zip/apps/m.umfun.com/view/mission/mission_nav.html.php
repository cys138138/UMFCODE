<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=Mission&a=showList">关卡列表</a>
	<a <?php if(get('a') == 'showAddMission'){ ?>class="on"<?php } ?> href="?m=Mission&a=showAddMission">添加关卡</a>
	<a <?php if(get('a') == 'showEsCountStatistic'){ ?>class="on"<?php } ?> href="?m=Mission&a=showEsCountStatistic">关卡统计</a>
	<?php if(get('a') == 'showAddMission'){ ?>
	<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
	<?php if(get('a') == 'showMissionDetail'){ ?>
		<a <?php if(get('a') == 'showMissionDetail'){  ?>class="on"<?php } ?> onclick="javascript:viod(0);">查看关卡信息</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
	<?php if(get('a') == 'showEditMission'){ ?>
		<a <?php if(get('a') == 'showEditMission'){  ?>class="on"<?php } ?> onclick="javascript:viod(0);">编辑关卡</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>
<div class="br"></div>
