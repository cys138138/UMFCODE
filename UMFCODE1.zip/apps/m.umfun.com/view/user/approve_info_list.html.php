<?php display('user/user_nav.html.php'); ?>
<div class="module conditon">
	<style type="text/css">
		.conditon .name{width:50px;}
		.conditon .control input[type="text"]{width:150px;}
	</style>

	<div class="item">
		<div class="name">用户ID：</div>
		<div class="control"><input type="text" name="account" id="account" value="<?php echo get('account'); ?>"/></div>
		<div class="blank"></div>
		<div class="control">
			<a class="button" onclick="userSearch();">确定</a>
		</div>
	</div>
	<div class="clear"></div>
</div>
<div class="br"></div>
<div class="module userList">
	<style type="text/css">
		.userList .list .c2{width:120px;}
		.userList .list .c3{width:120px;}
		.userList .list .c4{width:120px;}
		.userList .list .c5{width:80px;}
		.userList .list .c6{width:120px;}

		.userList .list .c10{width:300px;}
		.userList .list .row .c10 a{padding-right:7px;}
		.list .row_height {height:50px;}
		.list .row_height .c1, .list .row_height .c2, .list .row_height .c3, .list .row_height .c4{line-height:50px;} 
		.userList .list span{padding-left:5px;line-height:50px;}
		.userList .list .msg_span{color:#f30;}
	</style>
	<div class="title">注册用户列表</div>
	<div class="list">
		<div class="row header">
			<div class="c2">用户id</div>
			<div class="c3">原姓名</div>
			<div class="c4">待审核姓名</div>
			<div class="c5">原头像</div>
			<div class="c6">待审核头像</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aApproveList){
			foreach($aApproveList as $aApproveInfo){ ?>
			<div class="row row_height" xid="<?php echo $aApproveInfo['id'];?>">
				<div class="c2"><?php echo $aApproveInfo['id']; ?></div>
				<div class="c3"><?php echo $aApproveInfo['name']; ?></div>
				<div class="c4">
					<?php 
						if($aApproveInfo['approve_name']){							
							if($aApproveInfo['approve_name_pass_time'] == -1 || $aApproveInfo['approve_name_pass_time'] > 1){
								echo '<span class="msg_span">无</span>';
							}else{
								echo $aApproveInfo['approve_name'];
							}
						}else{
							echo '<span class="msg_span">末修改</span>';
						}
					?>
				</div>
				<div class="c5"><?php if($aApproveInfo['profile']){ echo '<img src=' . SYSTEM_RESOURCE_URL . $aApproveInfo['profile'] . ' style="width:50px;height:50px;" alt="加载失败" />'; }else{ echo '<span>末上传</span>'; } ?></div>
				<div class="c6">
					<?php 
						if($aApproveInfo['approve_profile']){
							if($aApproveInfo['approve_profile_pass_time'] == -1 || $aApproveInfo['approve_profile_pass_time'] > 1){
								echo '<span class="msg_span">无</span>';
							}else{
								echo '<img src="' . SYSTEM_RESOURCE_URL . $aApproveInfo['approve_profile'] . '?' . rand(1,99) .'" style="width:50px;height:50px;" alt="加载失败" />';
							}
						}else{
							echo '<span>末修改</span>';	
						}
					?>
				</div>

				<div class="c10 right">
					<?php if($aApproveInfo['approve_name_pass_time'] == 0) { ?>
						<select id="approve_name<?php echo $aApproveInfo['id'];?>">
							<option value="0">-姓名审核-</option>
							<option value="1">-通过-</option>
							<option value="2">-不通过-</option>
						</select><br>
					<?php }?>
					<?php if($aApproveInfo['approve_profile_pass_time'] == 0) { ?>
						<select id="approve_profile<?php echo $aApproveInfo['id'];?>">
							<option value="0">-头像审核-</option>
							<option value="1">-通过-</option>
							<option value="2">-不通过-</option>
						</select>
					<?php }?>
				</div>
			</div>
		<?php }
		}else{
			echo '<font color="red">抱歉，暂时没有用户提交审核资料！</font>';
		} ?>

		<div class="row footer"><?php echo $pageHtml; ?></div>
		<?php if($aApproveList){ ?>
		<div class="row header">
			<div class="c10 right">
				<a onclick="approveSubmit()" id="submit_a">提交审核</a>
			</div>
		</div>
		<?php } ?>
	</div>
</div>
<script type="text/javascript">
	function approveSubmit(){
		var aApproveList = [];
		var hasData = 0;
		$('.row_height').each(function(){
			var userId = $(this).attr('xid');
			var namePass = $('#approve_name' + userId).val();
			var profilePass = $('#approve_profile' + userId).val();
			if(!namePass){
				namePass = 0;
			}
			if(!profilePass){
				profilePass = 0;
			}
			if(namePass > 0 || profilePass > 0){
				aApproveList.push({userId : userId, namePass : namePass, profilePass : profilePass});
				hasData = 1;
			}
		});

		if(hasData == 0){
			UBox.show('还没有要操作的数据', -1);
			return false;
		}
		UBox.confirm('确定此操作吗', function(){
			$.ajax({
				beforeSend : function(){
					$('#submit_a').attr('onclick','').html('处理中...');
				},
				url : '/?m=User&a=approveInfo',
				type : 'POST',
				dataType : 'JSON',
				data : {approve_list : aApproveList},
				success : function(aResult){
					if(aResult.status == 0){
						$('#submit_a').attr('onclick','approveSubmit()').html('提交审核');
						UBox.show(aResult.msg, -1);
					}else{
						UBox.show(aResult.msg, 1);
						window.location.reload();
					}
				},
				error:function(){
					UBox.show('系统错误', 0);
				}
			});
		});
	}

	function userSearch(){
		var accountValue = $.trim($('#account').val());
		if(accountValue && !/^\d{8}$/.test(accountValue)){
			UBox.show('请输入正确的账号', -1);
			return false;
		}
		location.href = '?m=User&a=showApproveInfoList&account=' + accountValue;
	}	
	
	$(function(){
		$('.row_height select').each(
			function(){
				$(this).get(0).selectedIndex = 0;
			}
		);
	});
</script>