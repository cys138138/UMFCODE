<?php display('user/user_nav.html.php'); ?>
<div class="module _userInfo">
	<style type="text/css">
		._userInfo .item{padding:0 10px;}
		._userInfo .item .name{width:100px;}
		._userInfo .item .control input{width:200px;}	
	</style>
	<div class="title">用户基本资料</div>
	<div class="item">
		<div class="name">姓名：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_name" id="user_id" value="<?php echo $aUserInfo['name']; ?>" />
		</div>
		<div class="name">邮箱账号：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_email" id="user_email" value="<?php echo $aUserInfo['email']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">用户id：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_id" id="user_id" value="<?php echo $aUserInfo['id']; ?>" />
		</div>
		<div class="name">地区：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="area_name" id="area_name" value="<?php echo $aUserInfo['area_name']; ?>" />
		</div>	
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">年龄：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_age" id="user_age" value="<?php echo $aUserInfo['age']; ?>" />
		</div>
		<div class="name">性别：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_gender" id="user_gender" value="<?php echo $aUserInfo['gender']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">	
		<div class="name">学校：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="school_name" id="school_name" value="<?php echo $aUserInfo['school_name']; ?>" />
		</div>
		<div class="name">年级：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_grade" id="user_grade" value="<?php echo $aUserInfo['grade']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">班级：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="user_class" id="user_class" value="<?php echo $aUserInfo['class']; ?>" />
		</div>
		
		<div class="name">用户等级：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="login_numbers" id="login_numbers" value="<?php echo $aUserLevelInfo['level']; ?>" />
		</div>
		
		<!-- 
		<div class="name">登陆次数：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="login_numbers" id="login_numbers" value="<?php //echo $aUserInfo['login_times']; ?>" />
		</div>
		 -->
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">金币余额：</div>
		<div class="control">
			<input disabled="disabled" type="text" name="login_numbers" id="login_numbers" value="<?php echo $aUserLevelInfo['gold']; ?>" />
		</div>
		</div>
	<div class="clear"></div>	

	<div class="br"></div>
	<div class="br"></div>
</div>


<div class="title">金币充值记录查询</div>
<div class="module _goldList">
	<style type="text/css">
		._goldList .button{border: none; }
		.goldList{max-height: 250px;overflow-y: auto;border: 1px solid #CCC;max-width: 750px;margin-left: 2px;margin-top: 5px;display: none;}
		.goldList ul li span{display: inline-block;}
		.goldList .t1{width:70px;}
		.goldList .t2{width:230px;}
		.goldList .t3{width:100px;}
		.goldList .t4{width:200px;}
	</style>
	<button type="button" class="button" id="btnLookUserGold">查询</button>
	<div class="clear"></div>
	<div class="goldList">
		<ul id="goldList"></ul>
	</div>
</div>

<!--
<div class="title">拓展信息</div>
<div class="module _expandMessage">
	<style type="text/css">
		._expandMessage .vice_title{margin-left:20px; width:100px; color:#dc7ef4;}
		._expandMessage .item{margin:0 20px;}
		._expandMessage .item .name{padding-left:16px; color:#748cf6;}
		._expandMessage .item .control{color:#f6161b;}
	</style>
	<div class="title">拓展信息</div>
	<div class="vice_title">关卡信息</div>
	<div class="item">
		<div class="name">已过关卡：</div>
		<div class="control">15关</div>
	</div>
	<div class="clear"></div>
	
	<div class="item">
		<div class="name">正在攻关：</div>
		<div class="control">16关</div>
	</div>
	<div class="clear"></div>
	
	<div class="vice_title">荣誉信息</div>	
	<div class="item">
		<div class="name">头衔：</div>
		<div class="control">贫农</div>
	</div>
	<div class="clear"></div>

	<div class="item">
		<div class="name">经验：</div>
		<div class="control">256</div>
	</div>
	<div class="clear"></div>
</div>
-->

<script type="text/javascript">
var page = 0,
	pageNumber = -1;
	userId = <?php echo $aUserInfo['id']; ?>,
	aGoldType = {
		0 : '未知',
		1 : '签到',
		2 : '错题反馈',
		3 : '首次激活邮箱',
		4 : 'U币',
		5 : 'PK金币',
		6 : '比赛奖励',
		7 : '个人升级奖励',
		8 : '勋章升级', 
		9 : '注册抽奖 - 特等奖',
		10 : '注册抽奖 - 一等奖',
		11 : '注册抽奖-二等奖',
		12 : '注册抽奖-三等奖',
		13 : '会员每日大礼包',
		14 : '每日任务',
		15 : '抽将加5金币',
		16 : '抽将加10金币'
	};

 $(function(){
	$('#btnLookUserGold').on('click', function(){
		getGoldLogList();
	});
 });

 function getGoldLogList(){
	if(page != pageNumber || page >= 0){
		if(page == pageNumber){
			UBox.show('已经到达末页', -1);
			$('#btnLookUserGold').text('没数据了');
			return false;
		}else{
			page = parseInt(page) + 1;
			$('#btnLookUserGold').text('继续查询');
		}
	}

	$.ajax({
		url : '/?m=User&a=getUserGold',
		type : 'post',
		datetype : 'json',
		data : {page : page, id : userId},
		success : function(aResult){
			if(aResult.status == 1){
				var aList = aResult.data.aGoldLogList,
					goldLogHtml = '';
				if(aList.length > 0){
					for(var i in aList){
						goldLogHtml += '<li>\
							<span class="t1">ID：' + aList[i].id + '</span>\
							<span class="t2">来源：' + aGoldType[aList[i].get_type] + '</span>\
							<span class="t3">数量：' + aList[i].number + '</span>\
							<span class="t4">时间：' + date('Y-m-d H:i:s', aList[i].create_time) + '</span>\
						</li>';
					}
					pageNumber = aResult.data.pageNumber;
				}else{
					goldLogHtml += '<li>暂时没有该用户的记录</li>';
				}
				
				$('#goldList').append(goldLogHtml);
				$('.goldList').show(300);
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		},
		error : function(error){
			UBox.show(error.msg, error.status);
		}
	});
 }
</script>
<?php setRefererMark(); ?>