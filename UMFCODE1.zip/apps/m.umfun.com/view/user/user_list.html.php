<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('user/user_nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
		._conditon .vipLevel{margin-left:20px;width:160px}
	</style>

	<form id="userConditionForm">
		<div class="item">
			<div class="name">账号：</div>
			<div class="control"><input type="text" name="account" id="account" value="<?php if(isset($account)){ echo $account; } ?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="userSearch(1);">确定</a>
			</div>
			<div class="blank"></div>
			<div class="comment">备注：请填写完整的邮箱或用户id进行精确查找</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">地区：</div>
			<div class="control">
				<select id="province_id" name="province_id" onchange="clearSelectSchool()"></select>
				<select id="city_id" name="city_id" onchange="clearSelectSchool()" ></select>
				<select id="district_id" name="district_id"></select>
			</div>

			<div class="name">学校：</div>
			<div class="control" >
				<select name="school_id" id="areaSchool"></select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">邮箱：</div>
			<div class="control">
				<input type="radio" checked="checked" name="e_mail" <?php if($eMail == -1){ echo 'checked="checked"'; } ?> id="allMail" value="-1" id="allMail" /><label  for="allMail">全部</label>
				<input type="radio"  name="e_mail" <?php if($eMail == 1){ echo 'checked="checked"'; } ?> id="verifiedMail" value="1" /><label  for="verifiedMail">已验</label>
				<input type="radio"  name="e_mail" <?php if($eMail == 0){ echo 'checked="checked"'; } ?> id="isVerifiedMail" value="0" /><label  for="isVerifiedMail">未验</label>
			</div>
			<div class="blank"></div>
			<div class="name">手机：</div>
			<div class="control" >
				<input type="radio"  <?php if($userPhone == -1){ echo 'checked="checked"'; } ?> name="user_phone" id="allPhone" value="-1" checked="checked" id="allPhone" /><label  for="allPhone">全部</label>
				<input type="radio"  <?php if($userPhone == 1){ echo 'checked="checked"'; } ?> name="user_phone" id="verifiedPhone" value="1" /><label  for="verifiedPhone">已验</label>
				<input type="radio"  <?php if($userPhone == 0){ echo 'checked="checked"'; } ?> name="user_phone" id="isVerifiedPhone" value="0" /><label  for="isVerifiedPhone">未验</label>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">姓名：</div>
			<div class="control">
				<input class="realName" type="text" name="name" id="name" value="<?php echo $name; ?>" />
			</div>
			<div class="blank"></div>
			<div class="name">性别：</div>
			<div class="control">
				<input type="radio" <?php if($gender == 0){ echo 'checked="checked"'; } ?> name="gender" id="all" value="0" checked=checked id="all" /><label  for="all">全部</label>
				<input type="radio" <?php if($gender == 1){ echo 'checked="checked"'; } ?> name="gender" id="boy" value="1"/><label  for="boy">男生</label>
				<input type="radio" <?php if($gender == 2){ echo 'checked="checked"'; } ?> name="gender" id="girl" value="2" /><label  for="girl">女生</label>
			</div>

			<div class="name">年龄：</div>
			<div class="control _ageInput">
				<input type="text" name="start_age" id="start_age" value="<?php  echo $ageStart; ?>" />
				-
				<input type="text" name="end_age" id="end_age" value="<?php  echo $ageEnd; ?>" />
			</div>
			<div class="blank"></div>
			<div class="control">
				<input id="last_login_time" type="checkbox" value="1" name="last_login_time" <?php if($lastLoginTime == 1){ echo 'checked="checked"'; } ?>  />
				<label for="last_login_time" style="width:240px">按最近登陆时间排序</label>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">时间：</div>
			<div class="control _quickTime" >
				<select onchange="setSearchTime(this.value);">
					<option value="1">请选择</option>
					<option value="0">所有时间</option>
					<option value="2">今天</option>
					<option value="3">3天内</option>
					<option value="7">一周内</option>
					<option value="30">一个月内</option>
				</select>
			</div>

			<label class="vipLevel" for="vipLevel">
				VIP等级：
				<select name="vipLevel" id="vipLevel">
					<option value="-1">全部</option>
					<?php
						foreach($GLOBALS['VIP'] as $key => $aVipInfo){
							$changeVipAttr = $vipLevel == $aVipInfo['vip'] ? 'selected' : '';
							echo '<option value="' .$aVipInfo['vip'] . '" ' . $changeVipAttr . '>' . $aVipInfo['name'] . '</option>';
						}
					?>

				</select>
			</label>

			<label style="margin-left:20px;width:90px" for="user"><input  name="checkbox" type="checkbox" value="0" id="user" <?php echo $approveStatus==0?'checked="checked"':'';?>>&nbsp;尚未提醒</label>
			<div class="blank"></div>
			<div class="name">自定义：</div>
			<div class="control">
				<input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
				-
				<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" />
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="userSearch(2);">筛选</a>
			</div>
		</div>
	</form>
</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
 		._userList .list .c1{width:150px;}
		._userList .list .c2{width:50px;}
		._userList .list .c3{width:110px;}
		._userList .list .c4{width:40px;}
		._userList .list .c5{width:60px;}
		._userList .list .c6{width:160px;}
		._userList .list .c7{width:150px;}
		._userList .list .c8{width:110px;}
		._userList .list .c9{width:60px;}
		._userList .list .c10{width:240px;}
		._userList .list .row .c10 a{padding-right:7px;}
		._userList .list .c11{width:120px;}
		._userList .list .c12{width:180px;}
		._userList .list .c13{width:120px;}
	</style>
	<div class="title">用户列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">姓名账号</div>
			<div class="c2">头像</div>
			<!--<div class="c2"></div> --->
			<div class="c4">性别</div>
			<!-- <div class="c5">年龄</div> -->
			<div class="c5">　VIP</div>
			<div class="c6">地区</div>
			<div class="c12">邮箱</div>
			<div class="c13">手机</div>
			<div class="c7">学校</div>
			<!-- <div class="c8">登陆次数</div> -->
			<!-- <div class="c9">激活状态</div> -->
			<div class="c11">注册时间</div>
			<div class="c11">最近登录时间</div>
			<div class="c3">提醒状态</div>
			<div class="c10 right">操作</div>
		</div>
		<?php

		if($aUserList){
			foreach($aUserList as $aUser){ ?>
			<div class="row">
				<div class="c1 <?php
				if(@in_array($aUser['id'], $aPublicUser)){
					echo 'red';
				}
				if(in_array($aUser['id'], $GLOBALS['TEST_USER_LIST'])){
					echo ' testUser';
				}
				if($aUser['xxt_id']){ echo ' xxtUser'; }
				?>">
					<span class="name"><?php echo $aUser['name']; ?></span><br/>
					<span class="mail"><?php echo $aUser['email']; ?></span>
				</div>
				<div class="c2"><a href="<?php echo url('m=Zone&a=showHome&userId='.$aUser['id'], '', APP_HOME); ?>" target="_blank"><img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php echo SYSTEM_RESOURCE_URL . $aUser['profile']; ?>" width="40" height="40" alt="<?php echo $aUser['id'];?>" title="<?php echo $aUser['id'];?>" onload="h(this);" /></a></div>
				<!--<div class="c3">&nbsp;</div>
				<div class="c3"><?php //echo $aUser['id']; ?></div>-->
				<div class="c4"><?php echo $aUser['gender']; ?></div>
				<!--<div class="c5"><?php //echo $aUser['age']; ?></div> -->
				<div class="c5 <?php echo 'vip'.$aUser['vip'];?>" style="width:60px;"><?php echo $GLOBALS['VIP'][$aUser['vip']]['name']; ?></div>
				<div class="c6"><?php echo isset($aUser['area_name']) ? $aUser['area_name'] : ''; ?></div>
				<div class="c12"><?php if($aUser['is_email_active'] == 1){echo $aUser['email']; }else{echo '否';} ?></div>
				<div class="c13"><?php if($aUser['mobile']){echo $aUser['mobile']; }else{echo '没有';} ?></div>
				<div class="c7"><?php echo $aUser['school_name']; ?></div>
				<!-- <div class="c8"><?php //echo $aUser['login_times']; ?></div> -->
				<!--<div class="c9"><?php //echo $aUser['is_forbidden'] ? '禁用' : '激活'; ?></div>-->
				<div class="c11"><?php echo date('Y-m-d H:i:s', $aUser['create_time']); ?></div>
				<div class="c11"><?php echo date('Y-m-d H:i:s', $aUser['last_login_time']); ?></div>
				<div class="c3" id="<?php echo $aUser['id']; ?>"><?php if($aUser['approve_status'] == 1){ ?><font style="color:#f00;">用户已提交修改</font><?php }elseif($aUser['approve_status'] == 2){ ?><font style="color:#f00;">已提醒头像</font><?php }elseif($aUser['approve_status'] == 3){ ?><font style="color:#f00;">已提醒姓名</font><?php }elseif($aUser['approve_status'] == 4){ ?><font style="color:#f00;">已提醒头像和姓名</font><?php }else{ ?>未提醒<?php } ?></div>

				<div class="c10 right">

				<?php if($aUser['approve_status'] != 0 && $aUser['approve_status'] != 1){ ?>
					<a onclick="clearWarn(<?php echo $aUser['id']?>);" id="u<?php echo $aUser['id']; ?>">取消提醒</a>
				<?php }else{ ?>
					<a onclick="warn(<?php echo $aUser['id']?>);" id="u<?php echo $aUser['id']; ?>">提醒用户</a>
				<?php } ?>
				<a onclick="forbidden(<?php echo $aUser['id']; ?>, <?php echo $aUser['is_forbidden'] ? 0 : 1; ?>);"><?php echo $aUser['is_forbidden'] ? '激活' : '禁用'; ?></a>
				<a href="?m=User&a=showUserInfo&account=<?php echo $aUser['id']; ?>">详情</a></div>
			</div>
		<?php }
		}else{
			echo '<font color="red">抱歉，暂时缺乏数据！</font>';
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
	window.endTime = "'end_time'";
	$(function(){
		var oAddressInit = new addressInit('province_id', 'city_id', 'district_id', '<?php echo $provinceId; ?>', '<?php echo $cityId; ?>', '<?php echo $areaId; ?>', changeSchool);
		oAddressInit.load();

	});

	function clearSelectSchool(){
		$('#areaSchool').html('');
	}

	function changeSchool(){
		areaId = $("#district_id").val();
		if(areaId == 0){
			$('#areaSchool').html('');
			$('#areaSchool').append('<option value="0">请选择</option>');
			return false;
		}

		$.ajax({
			type : 'post',
			url : '?m=User&a=schoolInfo',
			data : {areaId : areaId},
			success : function(result){
				$('#loading').html('');
				$('#areaSchool').html('');
				var schoolData = result.data;
				$('#areaSchool').append('<option value="0">请选择</option>');
				var nowSchoolId = <?php echo $schoolId; ?>;
				for(var i = 0; i < schoolData.length; i++){
					var selectAttr = '';
					if(nowSchoolId == schoolData[i].id){
						selectAttr = 'selected="selected"';
					}
					$('#areaSchool').append('<option ' + selectAttr + ' value="' + schoolData[i].id + '">' + schoolData[i].name + '</option>');
				}
			}
		});
	}

	function userSearch(index){
		if(index == 1){
			accountValue = $('#account').val();
			if($.trim(accountValue) == ''){
				UBox.show('请输入账号', -1);
				return false;
			}
			var url = '?m=User&a=showUserList&account=' + accountValue;
			location.href = url;
		}else{
			var startTime = $('#start_time').val(),
				endTime = $('#end_time').val(),
				name = $('#name').val(),
				eMail = $(':checked[name=e_mail]').val(),
				userPhone = $(':checked[name=user_phone]').val(),
				provinceId = $('#province_id').val(),
				cityId = $('#city_id').val(),
				districtId = $('#district_id').val(),
				schoolId = $('#areaSchool').val(),
				gender = $(':checked[name=gender]').val(),
				ageStart = $('#start_age').val(),
				ageEnd = $('#end_age').val(),
				userReviews = $('#user:checked').val(),
				lastLoginTime = 0,
				lastLoginTimeCheck = document.getElementById('last_login_time').checked,
				vipLevel = $('#vipLevel').val();

			if(lastLoginTimeCheck == true){
				lastLoginTime = 1;
			}
			var url = '?m=User&a=showUserList&start_time=' + startTime + '&end_time=' + endTime + '&last_login_time=' + lastLoginTime + '&e_mail=' + eMail + '&user_phone=' + userPhone;

			if(provinceId){
				url += '&province_id=' + provinceId;
			}
			if(cityId){
				url += '&city_id=' + cityId;
			}
			if(districtId){
				url += '&district_id=' + districtId;
			}
			if(schoolId){
				url += '&school_id=' + schoolId;
			}
			if(gender){
				url += '&gender=' + gender;
			}
			if(name){
				url += '&name=' + name;
			}
			if(ageStart){
				url += '&age_start=' + ageStart;
			}
			if(ageEnd){
				url += '&age_end=' + ageEnd;
			}
			if(vipLevel){
				url += '&vipLevel=' + vipLevel;
			}
			if(userReviews == 0){
				url += '&approve_status=' + userReviews;
			}

			location.href = url;
		}
	}

	function setSearchTime(type){
		var dateStr = '<?php echo date('Y-m-d 00:00:00'); ?>',
			dateForm = new Date(),
			startTime = dateForm.getTime();
		if(type == 1){
			$('#start_time').val(dateStr);
		}else if(type == 0){
			$('#start_time').val('2013:01:01 00:00:00');
		}else{
			startTime = startTime - type * 24 * 60 * 60 * 1000;
			$('#start_time').val(timeToStr(startTime));
		}
		$('#end_time').val('<?php echo date('Y-m-d H:i:s'); ?>');
	}

	//将秒数转换成  年-月-日 时:分:秒  字符串
	function timeToStr(time){
		var s, y, m, d, h, i, e;
		s = new Date(time)
		y =s.getFullYear();
		m =s.getMonth() + 1;
		d =s.getDate();
		h =s.getHours();
		i =s.getMinutes();
		e =s.getSeconds();
		if(m < 10){
			m = '0' + m;
		}
		if(d < 10){
			d = '0' + d
		}
		if(h < 10){
			h = '0' + h;
		}
		if(i < 10){
			i = '0' + i;
		}
		if(e < 10){
			e = '0' + e;
		}
		startDateStr = y + '-' + m + '-' + d + ' ' + h + ':' + i + ':' + e;
		return startDateStr;
	}

	function forbidden(index, actionNumber){
		if(actionNumber == 1){
			tips = '禁用';
		}else{
			tips = '激活';
		}
		UBox.confirm('确定' + tips + '该用户吗？', function()
			{$.ajax({
				type : 'post',
				url : '?m=User&a=setForbidden',
				data : {id : index, action : actionNumber},
				success : function(result){
						UBox.show(result.msg, result.status);
						location.reload();
				},
				error : function(fail){
					UBox.show(fail.responseText);
				}
				})
			}
		)
	}

	function clearWarn(userId){
		$.ajax({
			type : 'post',
			url : '?m=User&a=clearApproveStatus',
			data : {userId : userId},
			success : function(result){
				if(result.status == 1){
					$('#u'+userId).attr('onclick','warn('+ userId +')').text('提醒用户');
					$('#'+userId).html('未提醒');
				}
				UBox.show(result.msg,result.status);
			}
		});
	}

	function warn(userId){
		var con = '<div style="margin:10px; line-height:25px;" id="select"> <label class="check" for="check1"><input  name="checkbox" type="checkbox" value="2" id="check1">&nbsp;头像审核不通过</label><br /><label class="check" for="check2" ><input name="checkbox" type="checkbox" value="3" id="check2">&nbsp;名字审核不通过</label><br /></div>';
		easyDialog.open({
			container : {
				width : 200,
				height : 100,
				header : '选择提醒选项',
				content : con,
				yesFn : confirm,
				noFn: function(){}
			},
			overlay : true,
			followX : -100,
			drag : true
		});
		function confirm(){
			var aValue = [];
			$('#select input:checked').each(function(){
				aValue.push($(this).val());
			});
			$.ajax({
				type : 'post',
				url : '?m=User&a=updateApproveStatus',
				data : {userId : userId, status : aValue},
				success : function(result){
					if(result.status == 1){
						var warnHtml = '';
						var vLength = aValue.length;
						if(vLength == 1){
							var value = aValue[0];
							if(value == 1){
								warnHtml = '<font style="color:#f00;">用户已提交修改</font>';
							}else if(value == 2){
								warnHtml = '<font style="color:#f00;">已提醒头像</font>';
							}else if(value == 3){
								warnHtml = '<font style="color:#f00;">已提醒姓名</font>';
							}
						}else if(vLength > 1){
							warnHtml = '<font style="color:#f00;">已提醒头像和姓名</font>';
						}
						$('#u'+userId).attr('onclick','clearWarn('+ userId +')').text('取消提醒');
						$('#'+userId).html(warnHtml);
					}
					UBox.show(result.msg,result.status);
				}
			});
		}
	}
</script>