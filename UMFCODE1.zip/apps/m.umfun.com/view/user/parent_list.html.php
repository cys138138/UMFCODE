<div class="nav">
	<a class="on" href="?m=User&a=showParentList">家长列表</a>
</div>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<style type="text/css">
	.row div{line-height: 28px; height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:60px;}
	.list .c2{width:100px;}
	.list .c3{width:280px;}
	.list .c4{width:280px;}
	.list .c5{width:150px;}
	.w80 {width:80px;}
	.right{float:right;}
	.button{border: none;}
	.caogao{color: #666;}
	.red{color:red;}
	#viewInfo{color: #000;}
	.parentInfo{list-style: none; padding-left: 10px; display: block;}
	.parentInfo li span{width: 80px; display: inline-block;}
</style>

<div class="module">
	<div class="list" id="categoryList">

		<form id="searchParent">
			<div class="item">
				<div class="name">ID：</div>
				<div class="control">
					<input type="text" id="id" name="id" value="<?php echo $searchId;?>">
				</div>

				<div class="blank"></div>
				<div class="name">姓名：</div>
				<div class="control">
					<input type="text" class="w80" id="name" name="name" value="<?php echo $searchUserName;?>">
				</div>

				<div class="blank"></div>
				<div class="item">
				<div class="name">地区：</div>
					<div class="control">
						<select id="province_id" name="province_id"></select>
						<select id="city_id" name="city_id"></select>
						<select id="district_id" name="district_id" style="display:none;"></select>
					</div>
				</div>
				<div class="blank"></div>
				<div class="name">注册时间：</div>
					<div class="control">
						<input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
						-
						<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" />
					</div>
				<div class="blank"></div>
				<div class="control">
					<button type="button" class="button" onclick="searchParent();">搜索</button>
				</div>
			</div>

			<div class="clear"></div>
			<div class="clear"></div>
		</form>

		<div class="title">
			家长列表(<b id="totalNum"><?php echo $tatolNum;?></b>)
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">姓名</div>
			<div class="c3">孩子ID</div>
			<div class="c4">校讯通ID</div>
			<div class="c4">校讯通平台</div>
			<div class="c5">城市标志</div>
			<div class="c5">注册时间</div>
		</div>

		<div id="content"></div>
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>

<script type="text/javascript">
	window.endTime = "'end_time'";
	var aParentDataList = <?php echo json_encode($aParentList); ?>,
		contentHtml = '',
		aXxtPlatforms = {
			'2' : '广东',
			'3' : '山西'
		};
	for (var i = 0; i < aParentDataList.length; i++){
		var aParent = aParentDataList[i];
		contentHtml += '<div class="row" id="row-' + i + '">\
			<div class="c1">' + aParent.id + '</div>\
			<div class="c2">\
				' + aParent.name + '</a>\
			</div>\
			<div class="c3">' + (aParent.user_ids ? aParent.user_ids : "--") + '</div>\
			<div class="c4">' + aParent.extend_code + '</div>\
			<div class="c4">' + aXxtPlatforms[aParent.extend_type] + '</div>\
			<div class="c5">' + aParent.city_id + '</div>\
			<div class="c5">' + aParent.create_time + '</div>\
			<div class="c5 right" style="display:none">\
				<a href="javascript:void(0);" onclick="viewInfo(' + i + ');" class="checkOff">查看详情</a>\
				<a href="javascript:void(0);" onclick="deleteParent(' + i + ')" class="checkOn">删除</a>\
			</div>\
		</div>';
	}
	$('#content').html(contentHtml);

	function searchParent(){
		var id = $("#id").val(),
			name = $("#name").val(),
			provinceId = $('#province_id').val(),
			cityId = $('#city_id').val(),
			startTime = $('#start_time').val(),
			endTime = $('#end_time').val(),
			url = "/?m=User&a=showParentList&search=1";


		if (id.length > 0) {
			url = url + "&user_id=" + id;
		}
		if (name.length > 0) {
			url = url + "&user_name=" + name;
		}
		if (provinceId.length > 0) {
			url = url + "&provinceId=" + provinceId;
		}
		if (cityId.length > 0) {
			url = url + "&cityId=" + cityId;
		}
		if (startTime.length > 0) {
			url = url + "&start_time=" + startTime;
		}
		if (endTime.length > 0) {
			url = url + "&end_time=" + endTime;
		}
		window.location.href = url;
	}

	function domContent(content){
		var $dom = $('<ul class="parentInfo"></ul>');
		var string = '';
			string += '<li>' + '<span>姓名：</span>' + content.name + '</li>';
			string += '<li>' + '<span>电话：</span>' + content.mobile + '</li>';
			string += '<li>' + '<span>创建时间：</span>' + date('Y-m-d H:i:s', content.create_time) + '</li>';
			string += '<li>' + '<span>用户ID：</span>' + content.user_ids + '</li>';
			string += '<li>' + '<span>城市标志：</span>' + content.city_id + '</li>';
			string += '<li>' + '<span>学校ID：</span>' + content.xxt_data.SchoolId + '</li>';
			string += '<li>' + '<span>性别：</span>' + content.xxt_data.Sex + '</li>';
		$dom.append(string);
		return $dom;
	}

	function viewInfo(i){
		var content = aParentDataList[i];
		var dom = domContent(content);
		easyDialog.open({
			container : {
				width : 600,
				header : '查看家长详情',
				content : '<div id="viewInfo" class="view_box"></div>',
				yesFn : easyDialog.close,
				noFn : true
			},
			fixed : false,
		});
		$('#viewInfo').html(dom);
	}

	function deleteParent(id){
		$.post(
			'/?m=User&a=deleteParent',
			{
				id : id
			},
			function(aRequest){
				if(aRequest.status == 1){
					UBox.show('删除成功', 1);
					$("#row-" + id).remove();
				}else{
					UBox.show(aRequest.msg, aRequest.status);
				}
			}
		);
	}
	$(function(){
		var oAddressInit = new addressInit('province_id', 'city_id', 'district_id', '<?php echo $provinceId; ?>', '<?php echo $cityId; ?>', '0');
		oAddressInit.load();
		//未知选项
		$('#city_id').append('<option value="11000000"<?php if($cityId == 11000000){ echo ' selected';} ?>>未知</option>');

	});
</script>