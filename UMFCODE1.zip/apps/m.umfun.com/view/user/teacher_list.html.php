<div class="nav">
	<a class="on" href="?m=User&a=showTeacherList">教师列表</a>
</div>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<style type="text/css">
	.row div{line-height: 28px; height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:60px;}
	.list .c2{width:100px;}
	.list .c3{width:280px;}
	.list .c4{width:280px;}
	.list .c5{width:150px;}
	.w80 {width:80px;}
	.right{float:right;}
	.button{border: none;}
	.caogao{color: #666;}
	.red{color:red;}
	#viewInfo{color: #000;}
	.parentInfo{list-style: none; padding-left: 10px; display: block;}
	.parentInfo li span{width: 80px; display: inline-block;}
	.right a{display: none;}
</style>

<div class="module">
	<div class="list" id="categoryList">

		<form id="searchTeacher">
			<div class="item">
				<div class="name">ID：</div>
				<div class="control">
					<input type="text" id="id" name="id" value="<?php echo $searchId;?>">
				</div>

				<div class="blank"></div>
				<div class="name">姓名：</div>
				<div class="control">
					<input type="text" class="w80" id="name" name="name" value="<?php echo $searchUserName;?>">
				</div>
				<div class="blank"></div>
					<div class="item">
					<div class="name">地区：</div>
						<div class="control">
							<select id="province_id" name="province_id" onchange="clearSelectSchool()"></select>
							<select id="city_id" name="city_id" onchange="clearSelectSchool()" ></select>
							<select id="district_id" name="district_id"></select>
						</div>
					<div class="name">学校：</div>
					<div class="control" >
						<select name="school_id" id="areaSchool"></select>
					</div>
					</div>
				<div class="blank"></div>
				<div class="name">注册时间：</div>
					<div class="control">
						<input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
						-
						<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" />
					</div>

				<div class="control">
					<button type="button" class="button" onclick="searchTeacher();">搜索</button>
				</div>
			</div>

			<div class="clear"></div>
			<div class="clear"></div>
		</form>

		<div class="title">
			教师列表(<b id="totalNum"><?php echo $tatolNum;?></b>)
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">姓名</div>
			<div class="c4">校迅通ID</div>
			<div class="c4">学校ID</div>
			<div class="c5">城市标志</div>
			<div class="c5">注册时间</div>
		</div>

		<div id="content"></div>
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>

<script type="text/javascript">
	window.endTime = "'end_time'";
	var aTeacherDataList = <?php echo json_encode($aTeacherList); ?>,
		contentHtml = '';

	for (var i = 0; i < aTeacherDataList.length; i++){
		var aTeacher = aTeacherDataList[i];
		contentHtml += '<div class="row" id="row-' + i + '">\
			<div class="c1">' + aTeacher.id + '</div>\
			<div class="c2">\
				' + aTeacher.name + '</a>\
			</div>\
			<div class="c4">' + aTeacher.extend_code + '</div>\
			<div class="c4">' + aTeacher.school_id + '</div>\
			<div class="c5">' + (aTeacher.city_id ? aTeacher.city_id : "-/-") + '</div>\
			<div class="c5">' + aTeacher.create_time + '</div>\
			<div class="c5 right">\
				<a href="javascript:void(0);" onclick="viewInfo(' + i + ');" class="checkOff">查看详情</a>\
				<a href="javascript:void(0);" onclick="deleteTeacher(' + i + ')" class="checkOn">删除</a>\
			</div>\
		</div>';
	}
	$('#content').html(contentHtml);

	function searchTeacher(){
		var id = $("#id").val(),
			name = $("#name").val(),
			provinceId = $('#province_id').val(),
			cityId = $('#city_id').val(),
			districtId = $('#district_id').val(),
			startTime = $('#start_time').val(),
			endTime = $('#end_time').val(),
			schoolId = $('#areaSchool').val(),
			url = "/?m=User&a=showTeacherList&search=1";


		if (id.length > 0) {
			url = url + "&user_id=" + id;
		}
		if (name.length > 0) {
			url = url + "&user_name=" + name;
		}
		if (provinceId.length > 0) {
			url = url + "&provinceId=" + provinceId;
		}
		if (cityId.length > 0) {
			url = url + "&cityId=" + cityId;
		}
		if(cityId != 11000000){
			if (districtId.length > 0) {
			url = url + "&district_id=" + districtId;
			}
		}
		if (startTime.length > 0) {
			url = url + "&start_time=" + startTime;
		}
		if (endTime.length > 0) {
			url = url + "&end_time=" + endTime;
		}
		if(schoolId){
				url += '&school_id=' + schoolId;
			}
		window.location.href = url;
	}

	function domContent(content){
		var $dom = $('<ul class="parentInfo"></ul>');
		var string = '';
			string += '<li>' + '<span>姓名：</span>' + content.name + '</li>';
			string += '<li>' + '<span>用户ID：</span>' + content.id + '</li>';
			string += '<li>' + '<span>城市标志：</span>' + (content.city_id ? content.city_id : "-/-") + '</li>';
		$dom.append(string);
		return $dom;
	}

	function viewInfo(i){
		var content = aTeacherDataList[i];
		var dom = domContent(content);
		easyDialog.open({
			container : {
				width : 600,
				header : '查看教师详情',
				content : '<div id="viewInfo" class="view_box"></div>',
				yesFn : easyDialog.close,
				noFn : true
			},
			fixed : false,
		});
		$('#viewInfo').html(dom);
	}

	function deleteTeacher(id){
		$.post(
			'/?m=User&a=deleteTeacher',
			{
				id : id
			},
			function(aRequest){
				if(aRequest.status == 1){
					UBox.show('删除成功', 1);
					$("#row-" + id).remove();
				}else{
					UBox.show(aRequest.msg, aRequest.status);
				}
			}
		);
	}
	$(function(){
		var oAddressInit = new addressInit('province_id', 'city_id', 'district_id', '<?php echo $provinceId; ?>', '<?php echo $cityId; ?>', '<?php echo $districtId; ?>',changeSchool);
		oAddressInit.load();
		$('#city_id').append('<option value="11000000" <?php if($cityId == 11000000){ echo ' selected';} ?>>未知</option>');
	});
	function clearSelectSchool(){
		$('#areaSchool').html('');
	}
	function changeSchool(){
		areaId = $("#district_id").val();
		if(areaId == 0){
			$('#areaSchool').html('');
			$('#areaSchool').append('<option value="0">请选择</option>');
			return false;
		}

		$.ajax({
			type : 'post',
			url : '?m=User&a=schoolInfo',
			data : {areaId : areaId},
			success : function(result){
				$('#loading').html('');
				$('#areaSchool').html('');
				var schoolData = result.data;
				$('#areaSchool').append('<option value="0">请选择</option>');
				var nowSchoolId = <?php echo $schoolId; ?>;
				for(var i = 0; i < schoolData.length; i++){
					var selectAttr = '';
					if(nowSchoolId == schoolData[i].id){
						selectAttr = 'selected="selected"';
					}
					$('#areaSchool').append('<option ' + selectAttr + ' value="' + schoolData[i].id + '">' + schoolData[i].name + '</option>');
				}
			}
		});
	}

</script>