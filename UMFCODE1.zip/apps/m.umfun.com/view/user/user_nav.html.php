<div class="nav">
	<a <?php if(get('a') == 'showUserList'){ ?>class="on"<?php } ?> href="?m=User&a=showUserList">用户列表</a>
	<a <?php if(get('a') == 'showApproveInfoList'){ ?>class="on"<?php } ?> href="?m=User&a=showApproveInfoList">用户资料审核</a>
	<a <?php if(get('a') == 'showStatistics'){  ?>class="on"<?php } ?> href="?m=User&a=showStatistics">统计</a>
	<?php if(get('a') == 'showStatistics'){ ?>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
	
	<?php if(get('a') == 'showUserInfo'){ ?>
		<a class="on" href="?m=User&a=showUserInfo">用户详细页</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>

<div class="br"></div>
