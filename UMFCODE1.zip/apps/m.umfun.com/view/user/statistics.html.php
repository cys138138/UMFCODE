<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('user/user_nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{padding:0 10px; width:100px;}
		._main .item .control a{padding:0 5px;}
		._main .item ._selectTime a{color:#000;}
		._main .item .control .button{width:60px; text-align:center;}
		._main ._member .name{width:80px; font-size:17px; color:#000; text-align:left;}
		._main ._member .control{font-size:17px; width:100px;}
		._main .list .row .c1{width:150px;}
		._main .list .row .c2{width:150px;}
		._main .list .row .c3{width:150px;}
	</style>
	<div class="title" >统计</div>
	<form id="statisticSelect">
		<div class="item">
			<div class="name">时间：</div>
			<div class="control _selectTime">
				<a onclick="setSearchTime(1);">今天</a>
				<a onclick="setSearchTime(3);">最近3天</a>
				<a onclick="setSearchTime(7);">最近7天</a>
				<a onclick="setSearchTime(30);">最近30天</a>
				<a onclick="setSearchTime(0);">全部</a>
				自定义：
				<input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />&nbsp;-&nbsp;<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" />
			</div>
		</div>
		<div class="clear"></div>
			
		<div class="item">
			<div class="name">地区：</div>
			<div class="control">
				<select id="province_id" name="province_id"></select>
				<select id="city_id" name="city_id"></select>
				<select id="district_id" name="areaId"></select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a onclick="statisticSearch();" class="button">查询</a>
			</div>
		</div>
	<form>
	<div class="br"></div>
	
	<div class="item _member">
		<div class="name">新用户：</div>
		<div class="control red"><?php echo $aStatisticsList['all_count']; ?> 人</div>
		<div class="name">总人数：</div>
		<div class="control red"><?php echo $totalUserCount; ?> 人 </div>
	</div>
	<div class="clear"></div>
	
	<div class="title">男女比例</div>
	<div class="list">
		<div class="row header">
			<div class="c1">性别</div>
			<div class="c2">数量</div>
			<div class="c3">比例</div>
		</div>
		<?php foreach($aStatisticsList['gender_list'] as $genderKey => $aGenderCounts){ ?>
		<div class="row">
			<div class="c1"><?php echo $genderKey; ?></div>
			<div class="c2"><?php echo $aGenderCounts; ?></div>
			<div class="c3"><?php echo $aGenderCounts ? round(($aGenderCounts / $aStatisticsList['all_count']) * 100, 2) . '%' : '0%';; ?></div>
		</div>
		<?php } ?>
	</div>
	
	<div class="title">付费用户</div>
	<div class="list">
		<div class="row header">
			<div class="c1">费用</div>
			<div class="c2">数量</div>
			<div class="c3">比例</div>
		</div>
		<?php foreach($aFeeData as $aFee){ ?>
		<div class="row">
			<div class="c1"><?php echo $aFee['fee']; ?></div>
			<div class="c2"><?php echo $aFee['numbers']; ?></div>
			<div class="c3"><?php echo $aFee['percentage']; ?></div>
		</div>
		<?php } ?>
	</div>
	
	<div class="title">年龄区间</div>
	<div class="list">
		<div class="row header">
			<div class="c1">年龄</div>
			<div class="c2">数量</div>
			<div class="c3">比例</div>
		</div>
		<?php foreach($aStatisticsList['age_list'] as $ageKey => $aAgeCounts){
			foreach($aAgeCounts as $key => $ageCounts){ ?>
		<div class="row">
			<div class="c1"><?php echo $key; ?></div>
			<div class="c2"><?php echo $ageCounts; ?></div>
			<div class="c3"><?php echo $ageCounts ? round(($ageCounts / $aStatisticsList['all_count']) * 100, 2) . '%' : '0%'; ?></div>
		</div>
		<?php } } ?>
	</div>
	
	<div class="title">年级区间</div>
	<div class="list">
		<div class="row header">
			<div class="c1">年级</div>
			<div class="c2">数量</div>
			<div class="c3">比例</div>
		</div>
		
		<?php foreach($aStatisticsList['grade_list'] as $gradeKey => $aGradeCounts){
			foreach($aGradeCounts as $key => $gradeCounts){ ?>
		<div class="row">
			<div class="c1"><?php echo $key; ?></div>
			<div class="c2"><?php echo $gradeCounts; ?></div>
			<div class="c3"><?php echo $gradeCounts ? round(($gradeCounts / $aStatisticsList['all_count']) * 100, 2) . '%' : '0%'; ?></div>
		</div>
		<?php } } ?>
	</div>
</div>
<script type="text/javascript">
	window.endTime = "'end_time'";
	
	$(function(){
		var oAddressInit = new addressInit('province_id', 'city_id', 'district_id', '<?php echo $provinceId; ?>', '<?php echo $cityId; ?>', '<?php echo $areaId; ?>');
		oAddressInit.load();
	});
	
	function setSearchTime(type){
		var dateStr = '<?php echo date('Y-m-d 00:00:00'); ?>';
		var dateForm = new Date();
		var startTime = dateForm.getTime();
		if(type == 1){
			$('#start_time').val(dateStr);
		}else if(type == 0){
			$('#start_time').val('2013:01:01 00:00:00');
		}else{
			startTime = startTime - type * 24 * 60 * 60 * 1000;
			$('#start_time').val(timeToStr(startTime));
		}
		$('#end_time').val('<?php echo date('Y-m-d H:i:s'); ?>');
	}

	//将秒数转换成  年-月-日 时:分:秒  字符串
	function timeToStr(time){
		var s, y, m, d, h, i, e;
		s = new Date(time)
		y =s.getFullYear();
		m =s.getMonth() + 1;
		d =s.getDate();
		h =s.getHours();
		i =s.getMinutes();
		e =s.getSeconds();
		if(m < 10){
			m = '0' + m;
		}
		if(d < 10){
			d = '0' + d
		}
		if(h < 10){
			h = '0' + h;
		}
		if(i < 10){
			i = '0' + i;
		}
		if(e < 10){
			e = '0' + e;
		}
		startDateStr = y + '-' + m + '-' + d + ' ' + h + ':' + i + ':' + e;
		return startDateStr;
	}
	
	function statisticSearch(){
		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();
		var provinceId = $('#province_id').val();
		var cityId = $('#city_id').val();
		var districtId = $('#district_id').val();
		var url = '?m=User&a=showStatistics&start_time=' + startTime + '&end_time=' + endTime;
		if(provinceId){
			url += '&province_id=' + provinceId;
		}
		if(cityId){
			url += '&city_id=' + cityId;
		}
		if(districtId){
			url += '&district_id=' + districtId;
		}
		location.href = url;
	}
</script>