<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>
<?php display('style/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._subject span{margin-right:15px; display:inline-block;}
		select{margin-right:25px;padding:0 3px;float:left;}
		.style_img{width:170px; height:100px; border:1px solid #ccc; position:absolute; left:600px; top:30px;padding:2px;display:none}
		.style_img img{width:170px;height:100px;}
		.style_img a{display:block;position:absolute; right:-4px; top:-8px; width:8px; height:16px;  cursor:pointer;font-size:12px; color:#0066FF;overflow:hidden;margin:0;padding:0;font-size:12px;}
	</style>
	<form id="styleAdd" class="addForm" method="post" action="/?m=Style&a=add">
		<div class="title">新增风格</div>
		<div class="item">
			<div class="name">皮肤名称：</div>
			<div class="control"><input type="text" name="style_name" style="width:200px" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">皮肤包名：</div>
			<div class="control"><input type="text" name="style_pack_name" style="width:200px" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">皮肤分类：</div>
			<div class="control">
				<select name="category_id" id="category_id" >
					<?php foreach($GLOBALS['SKIN_CATEGORY'] as $id => $typeName){ ?>
						<option value="<?php echo $id; ?>"><?php echo $typeName; ?></option>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">使用价格：</div>
			<div class="control">
				<input type="text" name="style_price" id="stylePrice" value="0" />
				多少金币/每月 0-100的数字　0表示免费
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">显示顺序：</div>
			<div class="control">
				<input type="text" name="style_orders" value="1" />
				显示顺序为1-99999之间的数字
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">状态及等级：</div>
			<div class="control">
				<select name="style_status" id="status" >
					<option value="-1">-启用状态-</option>
					<option value="1" selected="selected">-现在启用-</option>
					<option value="0">-以后启用-</option>
				</select>
				<select name="style_level_limit" id="levelLimit" >
					<option value="-1">-最小使用等级-</option>
					<option value="0" selected="selected">-无等级限制-</option>
					<?php if(isset($levelArray)){
							foreach($levelArray as $key => $level){
								echo '<option value="' . $key . '">-' . $level . '-</option>';
							}
					} ?>
				</select>
				<select name="style_vip_limit" id="vipLimit">
					<option value="-1">-VIP等级-</option>
					<option value="0" selected="selected">-非会员-</option>
					<option value="1">-普通-</option>
					<option value="2">-白金-</option>
					<option value="3">-砖石-</option>
				</select>
				<select name="style_is_default" id="is_default" onchange="setDefault(this.value)" >
					<option value="-1">-是否默认风格-</option>
					<option value="1" >-默认风格-</option>
					<option value="0" selected="selected">-非默认风格-</option>
				</select>
				<a>操作成功后，此风格将会作为默认风格，其它的默认风格会被更改成非默认风格</a>		
			</div>
		</div>		
		<div class="clear"></div>
		
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button class="btnOperation" type="button" id="submitButton"/>发布样式</button>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddStyleJs; ?>

function _after_orders(){
	if($('#status').val() != '0' && $('#status').val() != '1' ){
		UBox.show('请选择启用状态', -1);
		return false;
	}
	
	if($('#levelLimit').val() == '-1'){
		UBox.show('请选择最小使用等级', -1);
		return false;
	}
	
	if($('#vipLimit').val() == '-1'){
		UBox.show('请选择会员使用等级', -1);
		return false;
	}
	if($('#is_default').val() == '-1'){
		UBox.show('请选择是否默认风格', -1);
		return false;
	}
}

//提交表单
$('#submitButton').click(function(){
	if(checkForm() == true){
		$('#styleAdd').submit();
	}
});

function setDefault(value){
	if(value == 1){
		$('#stylePrice').val(0).attr('readonly', true);
		$("#status").val(1).attr('disabled', true);
		$("#levelLimit").val(0).attr('disabled', true);
		$("#vipLimit").val(0).attr('disabled', true);
	}else{
		$('#stylePrice').attr('readonly', false);
		$("#status").attr('disabled', false);
		$("#levelLimit ").attr('disabled', false);
		$("#vipLimit ").attr('disabled', false);
	}
}
</script>