<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=Style&a=showList">风格列表</a>
	<a <?php if(get('a') == 'showAdd'){ ?>class="on"<?php } ?> href="?m=Style&a=showAdd">添加风格</a>
	<?php if(get('a') == 'showEdit'){echo '<a class="on">编辑</a>';}?>
</div>

<div class="br"></div>
