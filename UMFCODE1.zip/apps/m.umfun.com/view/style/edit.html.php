<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>
<?php display('style/nav.html.php'); ?>

<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._subject span{margin-right:15px; display:inline-block;}
.style_img{width:170px; height:100px; border:1px solid #ccc; position:absolute; left:600px; top:30px;padding:2px;display:none}
		.style_img img{width:170px;height:100px;}
		.style_img a{display:block;position:absolute; right:-4px; top:-8px; width:8px; height:16px;  cursor:pointer;font-size:12px; color:#0066FF;overflow:hidden;margin:0;padding:0;font-size:12px;}
		select{margin-right:25px;padding:0 3px;float:left;}
	</style>
	<form id="styleEdit" class="addForm" method="post" action="/?m=Style&a=edit">
		<input type="hidden" name="id" value="<?php echo $aStyleInfo['id']?>" />
		<div class="title">编辑风格</div>
		<div class="item">
			<div class="name">使用人数：</div>
			<div class="control"><?php echo $aStyleInfo['used_count']?></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">皮肤名称：</div>
			<div class="control"><input type="text" name="style_name" style="width:200px"  value="<?php echo $aStyleInfo['name']?>" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">皮肤包名：</div>
			<div class="control"><input type="text" name="style_pack_name" style="width:200px"  value="<?php echo $aStyleInfo['pack_name']?>" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">皮肤分类：</div>
			<div class="control">
				<select name="category_id" id="category_id" >
					<?php foreach($GLOBALS['SKIN_CATEGORY'] as $id => $typeName){ ?>
						<option value="<?php echo $id; ?>"><?php echo $typeName; ?></option>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">使用价格：</div>
			<div class="control">
				<input type="text" name="style_price" id="stylePrice"  value="<?php echo $aStyleInfo['gold_coin']?>" />
				多少金币/每月 0-100的数字　0表示免费
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">显示顺序：</div>
			<div class="control">
				<input type="text" name="style_orders" id="orders" value="<?php echo $aStyleInfo['orders']?>" />
				显示顺序为1-99999之间的数字
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">状态及等级：</div>
			<div class="control">
				<select name="style_status" id="status" >
					<option value="-1">-启用状态-</option>
					<option value="1" <?php if($aStyleInfo['status'] == 1){echo 'selected="selected"';}?>>-现在启用-</option>
					<option value="0" <?php if($aStyleInfo['status'] == 0){echo 'selected="selected"';}?>>-以后启用-</option>
				</select>
				<select name="style_level_limit" id="levelLimit" >
					<option value="-1">-最小使用等级-</option>
					<option value="0" <?php echo $aStyleInfo['level_limit'] == 0 ? 'selected' : ''; ?>>-无等级限制-</option>
					<?php foreach($levelArray as $key => $level){
						if($aStyleInfo['level_limit'] == $key){
							echo '<option value="' . $key . '" selected="selected">-' . $level . '-</option>';
						}else{
							echo '<option value="' . $key . '">-' . $level . '-</option>';	
						}
					}?>
				</select>
				<select name="style_vip_limit">
					<?php foreach(array(
						'-1' => 'VIP等级',
						'0' => '非会员',
						'1' => '普通',
						'2' => '白金',
						'3' => '钻石',
					) as $vipLevel => $vipName){ ?>
						<option value="<?php echo $vipLevel; ?>" <?php echo $aStyleInfo['vip_limit'] == $vipLevel ? 'selected' : ''; ?>>-<?php echo $vipName; ?>-</option>
					<?php } ?>
				</select>
				<select name="style_is_default" id="is_default"  onchange="setDefault(this.value)">
					<option value="-1">-是否默认风格-</option>
					<option value="1" <?php if($aStyleInfo['is_default'] == 1){echo 'selected="selected"';}?>>-默认风格-</option>
					<option value="0" <?php if($aStyleInfo['is_default'] == 0){echo 'selected="selected"';}?>>-非默认风格-</option>
				</select>
				<a>操作成功后，此风格将会作为默认风格，其它的默认风格会被更改成非默认风格</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button class="btnOperation" type="button" id="submitButton"/>保存</button>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddStyleJs; ?>

function _after_orders(){
	if($('#status').val() != '0' && $('#status').val() != '1' ){
		UBox.show('请选择启用状态', -1);
		return false;
	}
	if($('#levelLimit').val() == '-1'){
		UBox.show('请选择最小使用等级', -1);
		return false;
	}
	if($('#is_default').val() == '-1'){
		UBox.show('请选择是否默认风格', -1);
		return false;
	}
}

//提交表单
$('#submitButton').click(function(){
	if(checkForm() == true){
		$('#styleEdit').submit();
	}
});

<?php 
	if(isset($aStyleInfo['image_url'])){
?>
	$('.style_img img').attr('src','<?php echo $aStyleInfo['image_url'];?>');
	$('.style_img input').val('<?php echo $aStyleInfo['image'];?>');
	$('.style_img').show();
<?php	
	}
?>
function setDefault(value){
	if(value == 1){
		$('#stylePrice').val(0) .attr('readonly', true);
		$("#status ").val(1) .attr('disabled', true);
		$("#levelLimit ").val(0) .attr('disabled', true);
	}else{
		$('#stylePrice').attr('readonly', false);
		$("#status ").attr('disabled', false);
		$("#levelLimit ").attr('disabled', false);
	}
}
	
$(function(){
	setDefault(<?php echo $aStyleInfo['is_default']?>);
	$('#category_id').val(<?php echo $aStyleInfo['category_id']?>);
});
</script>