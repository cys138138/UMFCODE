<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('style/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>
	<form>
		<div class="item">
			<div class="name width80">名称：</div>
			<div class="control"><input  type="text" id="style_name" value="<?php echo $name;?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="styleSearch(1);">搜索</a>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name width80">皮肤分类：</div>
			<div class="control">
				<select name="category_id" id="category_id" >
					<option value="-1">-全部-</option>
					<?php foreach($GLOBALS['SKIN_CATEGORY'] as $id => $typeName){ ?>
						<?php if($category_id == $id){ ?>
							<option value="<?php echo $id; ?>" selected="selected"><?php echo $typeName; ?></option>
						<?php }else{ ?>
							<option value="<?php echo $id; ?>"><?php echo $typeName; ?></option>
						<?php } ?>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name width80">价格范围：</div>
			<div class="control">
				<input  type="text" id="gold_coin_start" value="<?php if($gold_coin_start >= 0 && $gold_coin_start <= 100){echo $gold_coin_start; }else{echo '0';} ?>" style="float:left" />
				<label style="float:left;color:#666;margin:0;padding:0 8px;width:20px">----</label>
				<input  type="text" id="gold_coin_end" value="<?php if($gold_coin_end >= 0 && $gold_coin_end <= 100){echo $gold_coin_end; }else{echo '100';} ?>" style="float:left" />
				
			</div>
			<div class="blank"></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">状态等级：</div>

			<div class="control">
				<select name="status" id="status" >
					<option value="-1">-启用状态-</option>
					<option value="1" <?php if($status == 1){echo 'selected="selected"';}?>>-己启用-</option>
					<option value="0" <?php if($status == 0){echo 'selected="selected"';}?>>-末启用-</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<select name="level_limit" id="level_limit" >	
					<option value="0">-不限等级-</option>
					<?php 
						if(isset($levelArray)){
							foreach($levelArray as $key => $level){
								if($level_limit == $key){
									echo '<option value="'.$key.'" selected="selected">-'.$level.'-</option>';
								}else{
									echo '<option value="'.$key.'">-'.$level.'-</option>';	
								}
							}
						}
					?>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<select name="vip_limit" id="vip_limit" >	
					<option value="-1">-VIP等级-</option>
					<option value="0" <?php if($vip_limit == 0){echo 'selected="selected"';}?>>-非会员-</option>
					<option value="1" <?php if($vip_limit == 1){echo 'selected="selected"';}?>>-普通会员-</option>
					<option value="2" <?php if($vip_limit == 2){echo 'selected="selected"';}?>>-白金会员-</option>
					<option value="3" <?php if($vip_limit == 3){echo 'selected="selected"';}?>>-砖石会员-</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<select id="is_default">
					<option value="-1">-是否默认风格-</option>
					<option value="1" <?php if($is_default == 1){echo 'selected="selected"';}?> >-默认风格-</option>
					<option value="0" <?php if($is_default == 0){echo 'selected="selected"';}?>>-非默认风格-</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="styleSearch(2);">搜索</a>
			</div>
		</div>
	</form>
</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
 		._userList .list .c1{width:200px;}
		._userList .list .c2{width:70px;}
		._userList .list .c3{width:75px;}
		._userList .list .c4{width:70px;}
		._userList .list .c5{width:70px;}

		._userList .list .c6{width:70px;}
		._userList .list .c7{width:130px;}
		._userList .list .c8{width:80px;}
		._userList .list .c9{width:80px;}
		._userList .list .c10{width:200px;}
		._userList .list .row .c10 a{padding-right:7px;}
	</style>
	<div class="title">风格列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">风格名称</div>
			<div class="c2">皮肤分类</div>
			<div class="c2">使用价格</div>
			<div class="c3">显示顺序</div>
			<div class="c3">最小等级</div>
			<div class="c3">会员等级</div>
			<div class="c4">使用人数</div>
			<div class="c5">默认皮肤</div>
			<div class="c6">启用状态</div>
			<div class="c7">发布时间</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aStyleList){
			$aVipList = array('普通玩家', '普通会员', '白金会员', '钻石会员');
			foreach($aStyleList as $aStyleInfo){ ?>
			<div class="row">
				<div class="c1"><?php echo $aStyleInfo['name']; ?></div>
				<div class="c2"><?php echo isset($GLOBALS['SKIN_CATEGORY'][$aStyleInfo['category_id']]) ? $GLOBALS['SKIN_CATEGORY'][$aStyleInfo['category_id']]: ''; ?></div>
				<div class="c2"><?php if($aStyleInfo['gold_coin'] > 0){echo $aStyleInfo['gold_coin'] . '金币/月';}else{echo '免 费';} ?></div>
				<div class="c3"><?php echo $aStyleInfo['orders']; ?></div>
				<div class="c3"><?php echo isset($levelArray[$aStyleInfo['level_limit']]) ? $levelArray[$aStyleInfo['level_limit']] : '不限'; ?></div>
				<div class="c3"><?php echo $aVipList[$aStyleInfo['vip_limit']]; ?></div>
				<div class="c4"><?php echo $aStyleInfo['used_count'] ? $aStyleInfo['used_count'] : '0';  ?></div>
				<div class="c5"><?php echo $aStyleInfo['is_default'] == 1 ? '<span style="color:red">是</span>' : '否'; ?></div>
				<div class="c6"><?php echo $aStyleInfo['status'] == 1 ? '<span style="color:red">己启用</span>' : '<span style="color:#0066CC">末启用</span>';  ?></div>
				<div class="c7"><?php echo date('Y-m-d H:i:s', $aStyleInfo['create_time']); ?></div>
				<div class="c10 right">
					<a href="/?m=Style&a=showEdit&id=<?php echo $aStyleInfo['id'];?>">编辑</a>
					<a href="javascript:void(0)" onclick="deleteStyle(<?php echo $aStyleInfo['id']?>)">删除</a>
				</div>
			</div>
		<?php } 
		}else{
			echo '<font color=red>抱歉，暂时缺乏数据！</font>'; 
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
	function styleSearch(type){
		var url = '?m=Style&a=showList';
		if(type == 1){
			var style_name = $.trim($('#style_name').val());
			if(style_name){
				url += '&style_name='+style_name;
				window.location.href= url;
			}else{
				UBox.show('风格名称不能为空', -1);
				return false;
			}

		}else if(type == 2){
			var gold_coin_start = $.trim($('#gold_coin_start').val());
			var gold_coin_end = $.trim($('#gold_coin_end').val());
			var category_id = $.trim($('#category_id').val());
			if(category_id != -1){
				url += '&category_id=' + category_id;
			}
			if(gold_coin_start){
				if( parseInt(gold_coin_start) >= 0 && parseInt(gold_coin_start) <= 100){
					url += '&gold_coin_start='+gold_coin_start;
				}else{
					UBox.show('价格范围为0到100之间的整数', -1);
					return false;
				}
			}

			if(gold_coin_end){
				if( parseInt(gold_coin_end) >= 0 && parseInt(gold_coin_end) <= 100){
					url += '&gold_coin_end='+gold_coin_end;
				}else{
					UBox.show('价格范围为0到100之间的整数', -1);
					return false;
				}
			}


			var status = $.trim($('#status').val());
			if(status == '0' || status == '1'){
				url += '&status='+status;
			}

			var level_limit = $.trim($('#level_limit').val());
			if(level_limit >= 0){
				url += '&level_limit='+level_limit;
			}

			var vip_limit = $('#vip_limit').val();
			url += '&vip_limit=' + vip_limit;

			var is_default = $('#is_default').val();
			if(is_default == 0 || is_default == 1){
				url += '&is_default=' + is_default;
			}
			window.location.href = url;
		}
	}
			
	//删除
	function deleteStyle(_id){
		if(_id > 0){
			UBox.confirm('确定删除吗',function(){
				$.ajax({
					url:'?m=Style&a=delete',
					data:{id:_id},
					type:'POST',
					dataType:'json',
					success:function(result){
						if(result.status == 1){
							window.location.reload();
						}else{
							UBox.show(result.msg, -1);
						}		
					},
					error : function(){
						UBox.show('系统错误', -1);
					}
				});
			});
		}
	}
</script>