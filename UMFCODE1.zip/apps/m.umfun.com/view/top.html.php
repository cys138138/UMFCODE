<div class="top">
	<a class="logo" href="/" target="_top"></a>
	<a class="link logOut" href="?m=Account&a=logOut" target="_top">安全退出</a></span>
	<a class="link updatePassword" href="?m=Account&a=showPersonalInfo" target="main" class="back1">我的信息</a>
	<a class="link homePage" href="<?php echo 'http://' . APP_HOME; ?>" target="_black">站点首页</a>
    <a class="welcome">Welcome<strong><?php echo $username; ?></strong></a>
</div>