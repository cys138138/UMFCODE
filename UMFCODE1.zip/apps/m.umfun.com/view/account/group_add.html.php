<?php display('account/permission_nav.html.php'); ?>
<div class="main">
	<form>
		<div class="module addTitle">
			<style type="text/css">
				.addTitle .name{margin-left:10px;}
			</style>
			<div class="title">新增权限组</div>
			<div class="item">
				<div class="name">新增组名：</div>
				<div class="control"><input type="text" name="group_name" /></div>
			</div>
			<div class="clear"></div>
		</div>

		<div class="module selectPermission">
			<style type="text/css">
				.selectPermission .item{margin:0 10px;}
				.selectPermission span{margin-right:13px; display:inline-block;}
			</style>
			<div class="item">
				<div class="name">权限：</div>
				<div class="control">
					<?php foreach($GLOBALS['PERMISSION'] as  $aPermissionGroup){
							foreach($aPermissionGroup['child'] as $key => $aPermission){ ?>
						<span><input type="checkbox" name="permission[]" id="permission_<?php echo $key; ?>" value="<?php echo $key; ?>"/><label for="permission_<?php echo $key; ?>"><?php echo $aPermission['title']; ?></label></span>
					<?php 	}
						  } ?>
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name"></div>
				<div class="control">
					<a class="button" onclick="add();"/>添加</a>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</form>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript" >
	<?php echo $validateAddGroupJs; ?>
	
	function add(){
		if(!checkForm()){
			return false;
		}
		var oCheckpermission = $(':checked[name^=permission]');
		var groupName = $.trim($('input[name=group_name]').val());
		if(oCheckpermission.length == 0){
			UBox.show('请至少选择一个权限！', -1);
			return false;
		}
		
		if(groupName == ''){
			UBox.show('请填写权限组名称!', -1);
			return false;
		}

		$.ajax({
			type : 'post',
			url : '?m=Account&a=addPermissionGroup',
			data : $('form').serialize(),
			success : function(result){
				UBox.show(result.msg, result.status, result.data);
			},
			error : function(fail){
				UBox.show(fail.responseText);
			}
		});
	}
</script>