<div class="module bottom">
	<style type="text/css">
		 body {background-color:#000;}
		.module {width:1000px; height:744px; position:absolute; top:43%; left:50%; margin:-372px 0 0 -500px; background:url(<?php echo $GLOBALS['RESOURCE']['login_bg']; ?>) no-repeat;}
		.module .main {width:500px; margin:0 auto; padding:300px 0 0 102px;}
		.main .item{text-align:center; vertical-align:middle;}
		.main .item .name{padding:0 5px;font-size:16px; font-weight:bold; width:80px;}
		.main .item .comment a{text-align:center; vertical-align:middle;}
		.main .item .control label{float:left; line-height:20px;}
		.main .item input[type="checkbox"]{float:left; margin-top:5px;}
		.main .item input[type="text"],
		.main .item input[type="password"]{width:220px;}
		.main .item input[type="button"]{width:90px; height:36px; padding-bottom:1px; background-color:#333; cursor:pointer; color:#eee; margin-right:20px; font-size:16px;}
		.main .item input[type="button"]:hover {background-color:#111;}
		.main .item input[name="captcha"]{width:60px;}
		.main .item input[name="remember_password"]{display:block;}
		.clear {height:0; overflow:hidden;}
		.main .btn {margin-top:-10px;}
	</style>
	<div class="main">
		<form>
			<?php setRefererMark(); ?>
			<div class="clear"></div>

			<div class="item">
				<div class="name">账&nbsp;&nbsp;&nbsp;&nbsp;号</div>
				<div class="control"><input type="text" name="email" id="email" onfocus="this.select();" onKeyDown="enterToNext(event, 1);" style="" /></div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">密&nbsp;&nbsp;&nbsp;&nbsp;码</div>
				<div class="control"><input type="password" name="password" id="password" onfocus="this.select();" onKeyDown="enterToNext(event, 2);"/></div>

			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">验证码</div>
				<div class="control"><input type="text" name="captcha" id="captcha" onfocus="this.select();" onKeyDown="enterToNext(event, 3);" /></div>
				<div class="comment">
					<img id="captchaImage" src="?m=Captcha&a=display&name=login_captcha" height="28" />&nbsp;
					<a onclick="refreshCaptcha();" />换一个?</a>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name"></div>
				<div class="control">
					<input type="checkbox" name="rememberPassword" id="rememberPassword" checked="checked" value="1" />
					<label for="rememberPassword">记住密码</label>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name"></div>
				<div class="control"><input type="button" id="umfunLogin" value="登 录" onclick="return checkForm();"/></div>
			</div>
			<div class="clear"></div>
		</form>
	</div>
</div>


<script type="text/javascript">
	<?php echo $validateJs; ?>

	function _after_checkForm(){
		$.ajax({
			type : 'post',
			url : '?m=Account&a=login',
			dataType : 'json',
			data : $('form').serialize(),
			success : function(aLoginResult){
				if(aLoginResult.status == 1){
					location.href = aLoginResult.data;
				}
				if(aLoginResult.status == 0){
					UBox.show(aLoginResult.msg);
					refreshCaptcha();
					$('#captcha').val('');
				}
			},
			error : function(fail){
				UBox.show('网络可能有点慢,请联系管理员', 0);
			}
		});
		return false;
	}

	function enterToNext(event, number){
		var key = window.event ? event.keyCode : event.which;
		var oEmail = $('#email');
		var oPassword = $('#password');
		var oCaptcha = $('#captcha');
		var oLogin = $('#umfunLogin');

		if(key == 13){
			if(number == 1){
				if($.trim(oEmail.val()) == ''){
					UBox.show('请输入账号', -1);
					oEmail.focus();
					return false;
				}
				oPassword.focus();
			}else if(number == 2){
				if($.trim(oPassword.val()) == ''){
					UBox.show('请输入密码', -1);
					oPassword.focus();
					return false;
				}
				oCaptcha.focus();
			}else if(number == 3){
				if($.trim(oCaptcha.val()) == ''){
					UBox.show('请输入验证码', -1);
					oCaptcha.focus();
					return false;
				}
				$('#umfunLogin').click();
			}
		}
	}

	function refreshCaptcha(){
		var verifyUrl = '?m=Captcha&a=display&name=login_captcha&math=' + Math.random();
		$('#captchaImage').attr('src', verifyUrl);
	}
</script>