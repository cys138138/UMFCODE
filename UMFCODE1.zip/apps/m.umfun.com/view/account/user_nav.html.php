<div class="nav">
	<a <?php if(get('a') == 'showUserList'){ ?>class="on"<?php } ?> href="?m=Account&a=showUserList">用户列表</a>
	<a <?php if(get('a') == 'showAddUser'){  ?>class="on"<?php } ?> href="?m=Account&a=showAddUser">添加用户</a>
	
	
	<?php if(get('a') == 'showEditUser'){ ?>
		<a class="on" onclick="javascript:location.reload();">编辑用户</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>

<div class="br"></div>
