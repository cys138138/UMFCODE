<?php display('account/user_nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._subject span{margin-right:15px; display:inline-block;}
	</style>
	<form class="addForm">
		<div class="title">新增用户</div>
		<div class="item">
			<div class="name">姓名：</div>
			<div class="control"><input type="text"  onblur="checkUserExists();" name="username" id="username" /></div>
			<div class="comment" id="userNameTips"></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">邮箱：</div>
			<div class="control"><input type="text" name="email" id="email" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">密码：</div>
			<div class="control"><input type="password" name="password" id="password" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">确认密码：</div>
			<div class="control"><input type="password" name="confirm_password" id="confirm_password" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">QQ：</div>
			<div class="control"><input type="text" name="qq" id="qq" /></div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">年龄：</div>
			<div class="control"><input type="text" name="age" id="age" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">性别：</div>
			<div class="control">
				<select name="gender" id="gender">
					<option value="0" >请选择</option>
					<option value="1" >男</option>
					<option value="2" >女</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">联系地址：</div>
			<div class="control"><input type="text" name="address" id="address" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">联系电话：</div>
			<div class="control"><input type="text" name="tel" id="tel" /></div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">备注：</div>
			<div class="control"><input type="text" name="comment" id="comment" /></div>
		</div>
		<div class="clear"></div>

		<div class="item _subject">
			<div class="name">允许操作科目:</div>
			<div class="control">
				<?php foreach($GLOBALS['SUBJECT'] as $key => $subject){ ?>
				<span>
					<input type="checkbox" name="subject[]" id="subject_<?php echo $key; ?>" value="<?php echo $key; ?>" />
					<label for="subject_<?php echo $key; ?>"><?php echo $subject; ?></label>
				</span>
				<?php } ?>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name">权限组:</div>
			<div class="control">
				<select name="permission_group_id" id="permission_group_id">
					<?php foreach($aGroupList as $aGroup){ ?>
						<option value="<?php echo $aGroup['id']; ?>" ><?php echo $aGroup['name']; ?></option>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="clear"></div>

		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" onclick="addUser();">添加</a></div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	<?php echo $validateAddUserJs; ?>
	
	function addUser(){
		var password = $.trim($('#password').val());
		var confirmPassword = $.trim($('#confirm_password').val());
		if(password != confirmPassword){
			UBox.show('您两次输入的密码不一致，请重新输入！', -1);
			return false;
		}
		if(!checkForm()){
			return false;
		}
		$.ajax({
			type : 'post',
			url : '?m=Account&a=addUser',
			data : $('form').serialize(),
			success : function(result){
				UBox.show(result.msg, result.status, result.data);
			},
			error : function(fail){
				UBox.show(fail.responseText);
			}
		});
	}
	
	function checkUserExists(){
		$.ajax({
			type : 'post',
			url : '?m=Account&a=checkUserExists',
			data : {name : $('#username').val()},
			success : function(result){
				if(result.status == 1){
					$('#userNameTips').html('<font color="red">' + result.msg + '</font>');
				}else if(result.status == 0){
					$('#userNameTips').html('');
				}
			},
			error : function(fail){
				UBox.show(fail.responseText);
			}
		});
	
	}
	
	function _before_age(){
		var qqStrLength = $('#qq').val().length;
		if(qqStrLength > 0){
			oQq = new Validater("qq");
			var validateQqResult = oQq.isNumber();
			if (validateQqResult !== true) {
				oQq.errorCallBack("QQ长度为5到10个0~9的字符", validateQqResult);
				return false;
			}
			var validateQqResult = oQq.length(5, 10);
			if (validateQqResult !== true) {
				oQq.errorCallBack("QQ长度为5到10个0~9的字符", validateQqResult);
				return false;
			}
		}
		return true;
	}
</script>