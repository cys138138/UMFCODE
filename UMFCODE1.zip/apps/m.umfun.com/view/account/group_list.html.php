<?php display('account/permission_nav.html.php'); ?>
<div class="module _permission">
	<style type="text/css">
		._permission .list .c1{width:100px;}
		._permission .list .c2{width:60px;}
		._permission .list .c3{width:500px;}
		._permission .list .c4{width:150px;}
		._permission .list .c4 a{padding-right:7px;}
	</style>
	<form>
		<div class="list">
			<div class="title">权限分组</div>
			<div class="row header">
				<div class="c1">分组名称</div>
				<div class="c2">人数</div>
				<div class="c3">成员</div>
				<div class="c4 right">操作</div>
			</div>
			<?php foreach($aGroupList as $aGroup){ ?>
				<div class="row">
					<div class="c1"><?php echo $aGroup['name']; ?></div>
					<div class="c2"><?php echo $aGroup['member_count']; ?></div>
					<div class="c3"><?php echo implode('、', $aGroup['members']); ?></div>
					<div class="c4 right">
						<a href="?m=Account&a=showEditGroup&id=<?php echo $aGroup['id']; ?>">编辑</a>
						<a href="?m=Account&a=showGroupDetail&id=<?php echo $aGroup['id']; ?>">查看详情</a>
						<?php if($aGroup['member_count'] == 0){ ?>
						<a onclick="deleteGroup(<?php echo $aGroup['id']; ?>)">删除</a>
						<?php } ?>
					</div>
				</div>
			<?php } ?>
			<div class="row footer">
				<?php echo $pageHtml; ?>
			</div>
		</div>	
	</form>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
	function deleteGroup(index){
		UBox.confirm('你确定删除吗？', function(){
			$.ajax({
				type : 'post',
				url : '?m=Account&a=deleteGroup',
				data : {id : index},
				success : function(result){
					UBox.show(result.msg, result.status);
					location.reload();
				},
				error : function(fail){
					UBox.show(fail.responseText);
				}
			});
		});
	}
</script>