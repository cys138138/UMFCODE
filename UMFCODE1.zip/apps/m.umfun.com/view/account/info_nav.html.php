<div class="nav">
	<a class="on" href="?m=Account&a=showPersonalInfo">个人信息</a>
	<a onclick="history.go(-1);">返回上一页</a>
</div>
<div class="br"></div>
