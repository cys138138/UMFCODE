<?php display('account/permission_nav.html.php'); ?>
<div class="module">
	<div class="list">
		<style type="text/css">
			.list .row .c1{width:70px;}
			.list .row .c2{width:150px;}
			.list .row .c3{width:200px;}
			.list .row .c4{width:200px;}
			.list .row .c5{width:100px;}
		</style>
		<div class="title"><?php echo $groupName; ?></div>
		<div class="row header">
			<div class="c1">成员</div>
			<div class="c2">邮箱</div>
			<div class="c3">创建时间</div>
			<div class="c4">科目</div>
			<div class="c5">状态</div>
		</div>
		<?php foreach($aUserList as $aUser){ ?>
			<div class="row">
				<div class="c1"><?php echo $aUser['name']; ?></div>
				<div class="c2"><?php echo $aUser['email']; ?></div>
				<div class="c3"><?php echo date('Y-m-d H:i:s',$aUser['create_time']); ?></div>
				<div class="c4"><?php foreach($aUser['allowed_subject'] as $subjectId){
					if(!$subjectId){
						continue;
					}
					echo $GLOBALS['SUBJECT'][$subjectId] . '&nbsp;&nbsp;';

				} ?></div>
				<div class="c5"><?php echo $aUser['is_forbidden'] == 2 ? '激活' : '禁用'; ?></div>
			</div>
		<?php } ?>
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>