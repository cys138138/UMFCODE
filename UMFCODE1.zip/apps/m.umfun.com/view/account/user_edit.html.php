<?php display('account/user_nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
	</style>
	<div class="userInfo">
		<form class="editForm">
			<div class="title">编辑用户</div>
			<div class="item">
				<div class="name">姓名：</div>
				<div class="control">

					<input type="text" name="username" id="username"  value="<?php echo $aUserInfo['name']; ?>" /><input type="hidden" name="user_id" id="user_id"  value="<?php echo $aUserInfo['id']; ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">邮箱：</div>
				<div class="control">
					<input type="text" name="user_email" id="user_email" disabled="disabled" value="<?php echo $aUserInfo['email']; ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">创建时间：</div>
				<div class="control">
					<input type="text" name="create_time" id="create_time" disabled="disabled" value="<?php echo date('Y-m-d H:i:s', $aUserInfo['create_time']); ?>" />
				</div>
			</div>
			<div class="clear"></div>
					
			<div class="item">
				<div class="name">QQ：</div>
				<div class="control"><input type="text" name="qq" id="qq" value="<?php if(isset($aUserInfo['personal_info']['qq']))echo $aUserInfo['personal_info']['qq']; ?>" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">年龄：</div>
				<div class="control"><input type="text" name="age" id="age" value="<?php if(isset($aUserInfo['personal_info']['age']))echo $aUserInfo['personal_info']['age']; ?>" /></div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">性别：</div>
				<div class="control">
					<select name="gender" id="gender">
						<option value="0" >请选择</option>
						<option value="1" >男</option>
						<option value="2" >女</option>
					</select>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">联系地址：</div>
				<div class="control"><input type="text" name="address" id="address" value="<?php if(isset($aUserInfo['personal_info']['address']))echo $aUserInfo['personal_info']['address']; ?>" /></div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">联系电话：</div>
				<div class="control"><input type="text" name="tel" id="tel" value="<?php if(isset($aUserInfo['personal_info']['tel']))echo $aUserInfo['personal_info']['tel']; ?>" /></div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">备注：</div>
				<div class="control"><input type="text" name="comment" id="comment" value="<?php if(isset($aUserInfo['personal_info']['comment']))echo $aUserInfo['personal_info']['comment']; ?>" /></div>
			</div>
			<div class="clear"></div>


			<div class="item _permission">
			<style type="text/css">
				._permission .control label{margin-right:17px; display:inline-block;}
			</style>

				<div class="name">科目：</div>
				<div class="control">
					<?php  foreach($GLOBALS['SUBJECT'] as $key => $subjectName){ ?>
						<span>
							<input type="checkbox" <?php if($aUserInfo['allowed_subject']){foreach($aUserInfo['allowed_subject'] as $subject){ if( $subject == $key){ echo 'checked="checked"';}}} ?>  name="allowed_subject[]" id="allowed_subject_<?php echo $key; ?>" value="<?php echo $key; ?>"/>
							<label for="allowed_subject_<?php echo $key; ?>"><?php echo $subjectName; ?></label></span>
					<?php } ?>
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">所在分组：</div>
				<div class="control">
					<select name="group_id" id="group_id">
						<?php foreach($aGroupList as $aGroup){ ?>
							<option value="<?php echo $aGroup['id'] ;?>" <?php if($aGroup['id'] == $aUserInfo['group_id']){ echo 'selected="selected"'; }?>><?php echo $aGroup['name'] ;?></option>
						<?php } ?>
					</select>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">修改密码：</div>
				<div class="control">
					<input type="password" name="password" id="password" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">确认密码：</div>
				<div class="control">
					<input type="password" name="confirm_password" id="confirm_password" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item _button">
				<style type="text/css">
						._button .control a{width:50px; height:30px;}
					</style>
				<div class="name"></div>
				<div class="control">
					
					<a class="button" onclick="alterInfo();" >确认修改</a>
				</div>
			</div>
			<div class="clear"></div>
		</form>
	</div>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	<?php echo $validateEditUserJs; ?>
	$('#gender').val('<?php echo isset($aUserInfo['personal_info']['gender']) ? $aUserInfo['personal_info']['gender'] : 0; ?>');
	function alterInfo(){
		if(!checkForm()){
			return false;
		}
		UBox.confirm('确定修改吗？', function(){
			var password = $('#password').val();
			var confirmPassword = $('#confirm_password').val();
			if($.trim(password) != $.trim(confirmPassword)){
				UBox.show('您两次输入的密码不一致', -1);
				$('#confirm_password').focus();
				return false;
			}
			$.post(
				'?m=Account&a=editUser',
				$('form').serialize(),
				function(result){
					UBox.show(result.msg, result.status, result.data);
			});
		});	
	}
	
	function _before_age(){
		var qqStrLength = $('#qq').val().length;
		if(qqStrLength > 0){
			oQq = new Validater("qq");
			var validateQqResult = oQq.isNumber();
			if (validateQqResult !== true) {
				oQq.errorCallBack("QQ长度为5到10个0~9的字符", validateQqResult);
				return false;
			}
			var validateQqResult = oQq.length(5, 10);
			if (validateQqResult !== true) {
				oQq.errorCallBack("QQ长度为5到10个0~9的字符", validateQqResult);
				return false;
			}
		}
		return true;
	}
</script>