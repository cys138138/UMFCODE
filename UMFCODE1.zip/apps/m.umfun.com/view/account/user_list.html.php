<?php display('account/user_nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
	<div class="module list">
		<style type="text/css">
			.list .row .c1{width:100px;}
			.list .row .c2{width:150px;}
			.list .row .c3{width:100px;}
			.list .row .c4{width:100px;}
			.list .row .c5{width:100px;}
			.list .row .c6{width:100px;}
			.list .row .c6 a{margin-right:7px;}
			.list .item a{color:#999; margin-right:10px;}
			.list .item .on{font-weight:bold; color:#000;}
			.list input{width:140px;}
			.list a.button{color:#FC0; margin-left:5px;}
			.row .paganitions .pages{width:500px;}
            .m_la{margin-left: 10px;}
            a.spanCheck{border-bottom: 2px #666 solid;padding: 3px;color: #FFCC00;}
            .search{display: block;}
		</style>

		<div class="item">	
        		<div class="name">&nbsp;&nbsp;&nbsp;&nbsp;搜索条件:</div>
			<div class="control">
			    <a href="javascript:void(0);" id="changeUser">按用户名</a>
				&nbsp;&nbsp;
			    <a href="javascript:void(0);" id="changeWhere">按条件</a>
				&nbsp;&nbsp;
			</div>
            <div class="clear"></div>
			<div class="name">&nbsp;&nbsp;&nbsp;&nbsp;请选择：</div>
			<div class="control">
				<select id="searchUserType" name="searchUserType">
					<option <?php echo get('searchUserType') == '1' ? 'selected' : ''; ?> value="1">用户名</option>
					<option <?php echo get('searchUserType') == '2' ? 'selected' : ''; ?> value="2">邮箱</option>
				</select>
				&nbsp;&nbsp;
				<input type="text" id="searchUserValue" value="<?php echo get('searchUserValue'); ?>" name="searchUserValue" />
				&nbsp;&nbsp;
			</div>

			<div class="name m_la">创建时间：</div>
			<div class="control">
				<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo get('starteTime'); ?>" type="text" id="starteTime" name="starteTime" />&nbsp;&nbsp;
			</div>
			<div class="name m_la">到：</div>
			<div class="control">
				<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo get('endTime'); ?>" type="text" id="endTime" name="endTime" />&nbsp;&nbsp;
			</div>
            
			<div class="control m_la">
				<select id="groupId" name="groupId">
					<option value="0">用户权限组</option>
                     <?php foreach($aGroupList as $key => $groupList){
                        if(get('groupId') === $groupList['id']){
                             echo '<option value="',$groupList['id'], '" selected> ▪', $groupList['name'], '</option>', PHP_EOL, '			';
                        }else{
                             echo '<option value="', $groupList['id'], '">', $groupList['name'], '</option>', PHP_EOL, '			';
                        }
                     } ?>
				</select>
				&nbsp;&nbsp;
			</div>
			
			<div class="control m_la">
				<select id="isForbidden" name="isForbidden">
                	<option value="0">状态</option>
					<option <?php echo get('isForbidden') == '2' ? 'selected' : ''; ?> value="2">激活</option>
					<option <?php echo get('isForbidden') == '1' ? 'selected' : ''; ?> value="1">禁止</option>
				</select>
				&nbsp;&nbsp;
			</div>
			
			<div class="control search"><a href="javascript:void(0);" class="button" onclick="searchUser();" >搜索</a></div>
		</div>
       
		<div class="clear"></div>

		
		<div class="title">用户列表 <i style="font-size: 8pt;color:#aaa;">当前 <?php echo $countUser; ?>位用户 </i></div>
		<div class="clear"></div>
		<div class="row header">
			<div class="c1">用户名</div>
			<div class="c2">邮箱</div>
			<div class="c3">创建时间</div>
			<div class="c4">所在分组</div>
			<div class="c5">状态</div>
			<div class="c6 right">操作</div>
		</div>
		<?php foreach($aUserList as $aUser){ ?>
			<div class="row">
				<div class="c1"><?php echo $aUser['name']; ?></div>
				<div class="c2"><?php echo $aUser['email']; ?></div>
				<div class="c3"><?php echo date('Y-m-d', $aUser['create_time']); ?></div>
				<div class="c4"><?php echo $aUser['group_name']; ?></div>
				<div class="c5"><?php echo $aUser['is_forbidden'] == 2 ? '激活' : '禁用'; ?></div>
				<div class="c6 right">

					<?php if($aUser['id'] != $myUserId){ ?>
					<a onclick="setForbidden('<?php echo $aUser['id']; ?>', '<?php echo $aUser['is_forbidden'] == 2 ? 1 : 2; ?>')"><?php echo $aUser['is_forbidden'] == 2 ? '禁用' : '激活'; ?></a>
					<?php } ?>
					<?php if($aUser['id'] != $myUserId){ ?>
					<a onclick="deleteUser('<?php echo $aUser['id']; ?>')">删除</a>
					<?php } ?>
					<a href="?m=Account&a=showEditUser&id=<?php echo $aUser['id']; ?>">编辑</a>
				</div>
			</div>
		<?php } ?>
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>
	</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	function setForbidden(index, value){
		if(value == 1){
			tips = '禁用';
		}else{
			tips = '激活';
		}
		UBox.confirm('确定' + tips + '该用户吗？', function(){
			$.ajax({
				type : 'post',
				url : '?m=Account&a=setForbidden',
				data : {id : index, forbidden : value, tips : tips},
				success : function(result){
					UBox.show(result.msg, result.status);
					location.reload();
				},
				error : function(fail){
					UBox.show(fail.responseText);
				}
			});
		
		})
		
	}

	function deleteUser(index){
		UBox.confirm('你确定删除吗？', function(){
			$.ajax({
				type : 'post',
				url : '?m=Account&a=deleteUser',
				data : {id : index},
				success : function(result){
					UBox.show(result.msg, result.status);
					location.reload();
				},
				error : function(fail){
					UBox.show(fail.responseText);
				}
			});
		})	
	}

	function searchUser(){
        var url = location.href;
        var search = {
            userType : $('#searchUserType').val(),
            serachValue : $('#searchUserValue').val(),
            starteTime : $('#starteTime').val(),
            endTime : $('#endTime').val(),
            groupValue : $('#groupId').val(),
            isForbidden : $('#isForbidden').val()
        }

        if(search.userType == 1){
            if(!search.serachValue || search.serachValue.length<1){
           	    search.serachValue= '';
            }
            url += '&searchUserType=' + search.userType + '&searchUserValue=' + search.serachValue;
        }else if(search.userType == 2){
            url += '&searchUserType=' + search.userType + '&searchUserValue=' + search.serachValue;
        }
        if(search.starteTime && search.endTime){
            url += '&starteTime=' + search.starteTime + '&endTime=' + search.endTime;
        }
        url += '&groupId=' + search.groupValue + '&isForbidden=' + search.isForbidden;
  
		window.location.href = url;
	}
    
    if($.cookie('search')==2){
        $('#changeUser').removeClass('spanCheck');
        $('#changeWhere').addClass('spanCheck');
        $('.name:eq(1)').css('display','none');
        $('.control:eq(1)').css('display','none');
        $('.name:gt(1)').css('display','block');
        $('.control:gt(1)').css('display','block');
    }else{
        $('.name:gt(1)').css('display','none');
        $('.control:gt(1)').css('display','none');
        $('#changeUser').addClass('spanCheck')
        $('.search').css('display','block');
    }
    
    
    $('#changeUser').click(function(){
        $('#changeWhere').removeClass('spanCheck');
        $(this).addClass('spanCheck');
        $('.name:eq(1)').css('display','block');
        $('.control:eq(1)').css('display','block');
        $('.name:gt(1)').css('display','none');
        $('.control:gt(1)').css('display','none');
        $('.search').css('display','block');
        $.cookie('search','1',{expires:1});
    });
    
    $('#changeWhere').click(function(){
        $('#changeUser').removeClass('spanCheck');
        $(this).addClass('spanCheck');
        $('.name:eq(1)').css('display','none');
        $('.control:eq(1)').css('display','none');
        $('.name:gt(1)').css('display','block');
        $('.control:gt(1)').css('display','block');
        $.cookie('search','2',{expires:1})
        $('#searchUserValue').val('');
    });
 </script>