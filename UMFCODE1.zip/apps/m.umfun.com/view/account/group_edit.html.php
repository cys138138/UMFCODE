<?php display('account/permission_nav.html.php'); ?>
<div class="module">
	<form>
		<div class="title"><input type="text" value="<?php echo $aGroupInfo['name']; ?>" id="group_name" name="group_name"></div>
		<input type="hidden" name="group_id" id="group_id" value="<?php echo $aGroupInfo['id']; ?>">
		<div class="selectPermission">
			<style type="text/css">
				.selectPermission span{margin-right:13px; display:inline-block;}
				.selectPermission .item{margin-left:10px;}
			</style>
			<div class="item">
				<div class="name">权限：</div>
				<div class="control">
					<?php foreach($GLOBALS['PERMISSION'] as $aGroup){
							foreach($aGroup['child'] as $key => $aPermission){ ?>
						<span><input type="checkbox" <?php foreach($aGroupInfo['permission'] as $permissionName){
							if($permissionName == $key){ echo 'checked="checked"';} }?> name="permission[]" id="permission_<?php echo $key; ?>" value="<?php echo $key; ?>"/><label for="permission_<?php echo $key; ?>"><?php echo $aPermission['title']; ?></label></span>
					<?php }
					} ?>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name"></div>
				<div class="control">
					<button type="button" class="button" onclick="edit();"/>确认修改</button>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</form>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
	<?php echo $validateEditGroupJs; ?>
	function edit(){
		if(!checkForm()){
			return false;
		}
		UBox.confirm('你确定修改吗？', function(){
			var oCheckpermission = $(':checked[name^=permission]');
			if(oCheckpermission.length == 0){
				UBox.show('请至少选择一个权限！', -1);
				return false;
			}
			$.ajax({
				type : 'post',
				url : '?m=Account&a=editGroup',
				data : $('form').serialize(),
				success : function(result){
					UBox.show(result.msg, result.status, result.data);
				},
				error : function(fail){
					alert(fail);
				}
			});
		})	
	}
</script>