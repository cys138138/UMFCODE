<div class="nav">
	<a <?php if(get('a') == 'showPermissionList'){ ?>class="on"<?php } ?> href="?m=Account&a=showPermissionList">权限分组</a>
	<a <?php if(get('a') == 'showAddPermissionGroup'){  ?>class="on"<?php } ?> href="?m=Account&a=showAddPermissionGroup">新增权限组</a>
	
	<?php if(get('a') == 'showEditGroup'){ ?>
		<a <?php if(get('a') == 'showEditGroup'){  ?>class="on"<?php } ?> onclick="javascript:location.reload();">编辑权限组</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
	
	<?php if(get('a') == 'showGroupDetail'){ ?>
		<a class="on" onclick="javascript:location.reload();">权限组成员</a>
	<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>

<div class="br"></div>
