<?php display('account/info_nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:115px;}
		._main .item .button{width:120px; height:32px;}
	</style>
	<div class="userInfo">
		<form id="info">
			<div class="item">
				<div class="name">姓名：</div>
				<div class="control">
					<input type="text" name="username" id="username"  value="<?php echo $aPersonalInfo['name']; ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">邮箱：</div>
				<div class="control">
					<input type="text" name="user_email" id="user_email" disabled="disabled" value="<?php echo $aPersonalInfo['email']; ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">创建时间：</div>
				<div class="control">
					<input type="text" name="create_time" id="create_time" disabled="disabled" value="<?php echo date('Y-m-d H:i:s', $aPersonalInfo['create_time']); ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">科目：</div>
				<div class="control">

					<input type="text" name="allowed_subject" id="allowed_subject" disabled="disabled" value="<?php foreach($aPersonalInfo['allowed_subject'] as $key){ echo $GLOBALS['SUBJECT'][$key] . '&nbsp;&nbsp;';}; ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item permission">
				<style type="text/css">
					.permission .control{padding:0 5px; border:1px solid #ccc;}
				</style>
				<div class="name">所有权限：</div>
				<div class="control">
					<?php echo implode('&nbsp;,&nbsp;', $aPersonalInfo['permissionName']); ?>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">所在分组：</div>
				<div class="control">
					<input type="text" name="group_name" id="group_name" disabled="disabled" value="<?php echo $aPersonalInfo['groupName']; ?>" />
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name"></div>
				<div class="control">
					<button type="button" class="button" onclick="alterInfo();" >确认修改</button>
				</div>
			</div>
			<div class="clear"></div>
		</form>
	</div>

	<div class="userPassword">
		<style type="text/css">
			.userPassword{margin-top:20px;}
		</style>
		<form id="passwordForm">
			<div class="title">修改密码</div>
			<div class="item">
				<div class="name">原密码：</div>
				<div class="control">
					<input type="password" name="old_password" id="old_password" />
				</div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">新密码：</div>
				<div class="control"><input type="password" name="password" id="password" /></div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">确认新密码：</div>
				<div class="control"><input type="password" name="confirm_password" id="confirm_password" /></div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name"></div>
				<div class="control"><button type="button" class="button" onclick="savePassword   ();">保存密码</button></div>
			</div>
		</form>
	</div>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	<?php echo $validatePersonalInfoJs; ?>

	function alterInfo(){
	UBox.confirm('您确定修改吗？', function(){
		if(!checkUsername()){
			return false;
		}
	
		$.post(
			'?m=Account&a=savePersonalInfo',
			$('#info').serialize(),
			function(alterResult){
				UBox.show(alterResult.msg, alterResult.status);
			}
		);
	});
		
	}
	<?php echo $validatePasswordJs; ?>
	function savePassword(){
		if(!checkForm()){
			return false;
		}
		var oldPassword = $.trim($('#old_password').val());
		var newPassword = $.trim($('#password').val());
		var confirmPassword = $.trim($('#confirm_password').val());
		if(newPassword != confirmPassword){
			UBox.show('您两次输入的密码不一致', -1);
			$('#confirm_password').focus();
			return false;
		}
		if(oldPassword == newPassword){
			UBox.show('原密码和新密码一样', -1)
			return false;
		}
		
		 
		UBox.confirm('您确定修改密码吗？', function(){
			
			$.post(
				'?m=Account&a=savePassword',
				$('#passwordForm').serialize(),
				function(savePasswordResult){
					UBox.show(savePasswordResult.msg, savePasswordResult.status);
		});
		
		});
	}
</script>