
<div class="module systemBaseOption">
	<style type="text/css">
		.systemSwitch{ margin:20px;}
		textarea{ width:80%;height:30%;padding:0;}
	</style>
	<div class="title">公众号列表</div>
	<form id="systemPublicUserOption">
		<div class="item systemSwitch">
			<div class="name">(多个请用英文逗号分隔，必须为8位数字ID 且不能有重复)：</div><div class="clear"></div>
			<div class="control">
				<textarea name="public_list" cols="100" rows="20" id="public_list"><?php
				$aPublicUser = '';
				foreach($GLOBALS['PUBLIC_USER_IDS'] as $value){
					$aPublicUser .= $value . ',';
				}
				echo rtrim($aPublicUser, ',');
				?></textarea>
			</div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button class="button" type="button" onclick="commit();">确定</button>
			</div>
		</div>
	</form>
</div>

<script type="text/javascript">
	function commit(){
		$.ajax({
			url : '?m=System&a=settingPublicUser',
			type : 'post',
			data : $('#systemPublicUserOption').serialize(),
			dataType : 'json',
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
			},
			error : function(aRequest){
				UBox.show('抱歉，网络可能有点慢，请重试', 0);
			}
		});
	}
</script>