<div class="nav">
	<a <?php if(get('a') == 'showBaseOption'){ ?>class="on"<?php } ?> href="?m=System&a=showBaseOption">基础设置</a>
	<a <?php if(get('a') == 'showTableOptimize'){ ?>class="on"<?php } ?> href="?m=System&a=showTableOptimize">表优化</a>
	<a <?php if(get('a') == 'showOtherOperating'){ ?>class="on"<?php } ?> href="?m=System&a=showOtherOperating">其它操作</a>
</div>
<div class="br"></div>
