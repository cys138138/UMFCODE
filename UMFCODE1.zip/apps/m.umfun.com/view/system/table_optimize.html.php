<?php display('system/nav.html.php'); ?>
<div class="module _tableOptimize">
	<style type="text/css">
		._tableOptimize .list .c1{width:150px;}
		._tableOptimize .list .c2{width:150px;}
		._tableOptimize .list .c3{width:120px;}
		._tableOptimize .list .c4{width:120px;}
		._tableOptimize .list .c5{width:120px;}
		._tableOptimize .list .c6{width:120px;}
	</style>
	<div class="title">空闲空间超过1M的表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">数据库名</div>
			<div class="c2">表 名</div>
			<div class="c3">记录数(条)</div>
			<div class="c4">表空间大小(M)</div>
			<div class="c5">索引大小(M)</div>
			<div class="c6">空闲空间大小(M)</div>
		</div>
		<?php if($aTableList){
		$_1M = 1024 * 1024;	?>
		<form id="tableOptimize">
			<?php foreach($aTableList as $aTable){ ?>
				<div class="row">
					<input type="hidden" name="tables[]" value="<?php echo '`' . $aTable['TABLE_SCHEMA'] . '`' . '.' . '`' . $aTable['TABLE_NAME'] . '`' ?>"  />
					<div class="c1"><?php echo $aTable['TABLE_SCHEMA']; ?></div>
					<div class="c2"><?php echo $aTable['TABLE_NAME']; ?></div>
					<div class="c3"><?php echo $aTable['TABLE_ROWS']; ?></div>
					<div class="c4"><?php echo sprintf('%.2f', $aTable['DATA_LENGTH'] / $_1M); ?></div>
					<div class="c5"><?php echo sprintf('%.2f', $aTable['INDEX_LENGTH'] / $_1M); ?></div>
					<div class="c6"><?php echo sprintf('%.2f', $aTable['DATA_FREE'] / $_1M); ?></div>
				</div>
			<?php } ?>
			<div class="item">
				<div class="name">总空闲空间：</div>
				<div class="control">
					<?php echo $freeData / $_1M; ?>M
				</div>
			</div>
			<div class="item">
				<div class="name"></div>
				<div class="control">
					<button class="button" type="button" onclick="commit();">一键优化</button>
				</div>
			</div>
		</form>
		<?php }else{ ?>
			<div class="row">没有可以优化的表啦</div>
		<?php } ?>
	</div>
</div>

<script type="text/javascript">
	function commit(){
		$.ajax({
			url : '?m=System&a=optimizeTable',
			type : 'post',
			data : $('#tableOptimize').serialize(),
			dataType : 'json',
			success : function(aResult){
				//console.log(aResult.data);
				UBox.show(aResult.msg, aResult.status);
				location.reload();
			},
			error : function(aRequest){
				UBox.show('抱歉，网络可能有点慢，请重试', 0);
			}
		});
	}
</script>