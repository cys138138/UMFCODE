<?php display('system/nav.html.php'); ?>
<div class="module systemBaseOption">
	<style type="text/css">
		.systemBaseOption .tip{position:relative; top:-7px;}
		.systemBaseOption .tip input[type=text]{width:600px;}
	</style>
	<div class="title">清除临时文件</div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button class="button" type="button" onclick="clearTempFile();">点击清除</button>
			</div>
		</div>
</div>

<script type="text/javascript">
	function clearTempFile(){
		$.ajax({
			url : '?m=System&a=clearTempFile',
			type : 'post',
			data : {},
			dataType : 'json',
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
			},
			error : function(aRequest){
				UBox.show('抱歉，网络可能有点慢，请重试', 0);
			}
		});
	}
</script>