<?php display('system/nav.html.php'); ?>
<div class="module systemBaseOption">
	<style type="text/css">
		.systemBaseOption .name{width:90px;}
		.systemBaseOption .systemSwitch span{display:inline-block; margin-right:10px;}
		.systemBaseOption .tip{position:relative; top:-7px;}
		.systemBaseOption .tip input[type=text]{width:600px;}
	</style>
	<div class="title">基础设置</div>
	<form id="systemBaseOption">
		<div class="item systemSwitch">
			<div class="name">后台开关：</div>
			<div class="control">
				<span>
					<input id="isOpenSystemM1" type="radio" name="is_open_system_m" value="1"<?php if($GLOBALS['SYSTEM_SWITCH']['is_open_system_m']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemM1">开</label>
				</span>
				<span>
					<input id="isOpenSystemM2" type="radio" name="is_open_system_m" value="0"<?php if(!$GLOBALS['SYSTEM_SWITCH']['is_open_system_m']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemM2">关</label>
				</span>
				<span class="tip">
					<label>关闭提示：</label>
					<input name="m_close_tip" type="text" value="<?php echo $GLOBALS['SYSTEM_SWITCH']['m_close_tip']; ?>" />
				</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item systemSwitch">
			<div class="name">学习系统开关：</div>
			<div class="control">
				<span>
					<input id="isOpenSystemWWW1" type="radio" name="is_open_system_www" value="1"<?php if($GLOBALS['SYSTEM_SWITCH']['is_open_system_www']){ echo ' checked="checked"'; } ?> />
					<label for="isOpenSystemWWW1">开</label>
				</span>
				<span>
					<input id="isOpenSystemWWW2" type="radio" name="is_open_system_www" value="0"<?php if(!$GLOBALS['SYSTEM_SWITCH']['is_open_system_www']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemWWW2">关</label>
				</span>
				<span class="tip">
					<label>关闭提示：</label>
					<input name="www_close_tip" type="text" value="<?php echo $GLOBALS['SYSTEM_SWITCH']['www_close_tip']; ?>"/>
				</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item systemSwitch">
			<div class="name">SNS系统开关：</div>
			<div class="control">
				<span>
					<input id="isOpenSystemSNS1" type="radio" name="is_open_system_sns" value="1"<?php if($GLOBALS['SYSTEM_SWITCH']['is_open_system_sns']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemSNS1">开</label>
				</span>
				<span>
					<input id="isOpenSystemSNS2" type="radio" name="is_open_system_sns" value="0"<?php if(!$GLOBALS['SYSTEM_SWITCH']['is_open_system_sns']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemSNS2">关</label>
				</span>
				<span class="tip">
					<label>关闭提示：</label>
					<input name="sns_close_tip" type="text" value="<?php echo $GLOBALS['SYSTEM_SWITCH']['sns_close_tip']; ?>"/>
				</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item systemSwitch">
			<div class="name">充值系统开关：</div>
			<div class="control">
				<span>
					<input id="isOpenSystemPAY1" type="radio" name="is_open_system_pay" value="1"<?php if($GLOBALS['SYSTEM_SWITCH']['is_open_system_pay']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemPAY1">开</label>
				</span>
				<span>
					<input id="isOpenSystemPAY2" type="radio" name="is_open_system_pay" value="0"<?php if(!$GLOBALS['SYSTEM_SWITCH']['is_open_system_pay']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemPAY2">关</label>
				</span>
				<span class="tip">
					<label>关闭提示：</label>
					<input name="pay_close_tip" type="text" value="<?php echo $GLOBALS['SYSTEM_SWITCH']['pay_close_tip']; ?>"/>
				</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item systemSwitch">
			<div class="name">代理平台开关：</div>
			<div class="control">
				<span>
					<input id="isOpenSystemPROXY1" type="radio" name="is_open_system_proxy" value="1"<?php if($GLOBALS['SYSTEM_SWITCH']['is_open_system_proxy']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemPROXY1">开</label>
				</span>
				<span>
					<input id="isOpenSystemPROXY2" type="radio" name="is_open_system_proxy" value="0"<?php if(!$GLOBALS['SYSTEM_SWITCH']['is_open_system_proxy']){ echo ' checked="checked"'; } ?>/>
					<label for="isOpenSystemPROXY2">关</label>
				</span>
				<span class="tip">
					<label>关闭提示：</label>
					<input name="proxy_close_tip" type="text" value="<?php echo $GLOBALS['SYSTEM_SWITCH']['proxy_close_tip']; ?>"/>
				</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button class="button" type="button" onclick="commit();">确定</button>
			</div>
		</div>
	</form>
</div>

<script type="text/javascript">
	function commit(){
		$.ajax({
			url : '?m=System&a=settingBaseOption',
			type : 'post',
			data : $('#systemBaseOption').serialize(),
			dataType : 'json',
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
			},
			error : function(aRequest){
				UBox.show('抱歉，网络可能有点慢，请重试', 0);
			}
		});
	}
</script>