<?php
	displayHeader(); 
	display('packet/nav.html.php'); 
?>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_ajaxupload']; ?>"></script>

<style type="text/css">
	._main .name{width: 100px;}
	._main .good_name{width:400px;}
	._main .up-img{width:580px; position:relative;overflow:visible}
	._main .up-img .up-img-del{border:1px solid #ccc;position:absolute; left:550px;top:-38px;display:none}
	._main .up-img .up-img-btndel{position:absolute;right:-3px;top:-17px;}
	._main .up-img .images{width:300px;}
	._main .hide{overflow:hidden;}
</style>

<div class="module _main">
	<form id="goodsAdd" class="addForm">
		<div class="addForm">
			<div class="title">新增奖品</div>
			
			<div class="item">
				<div class="name">奖品名称：</div>
				<div class="control"><input type="text" name="name" id="name" value="<?php echo $aPrize['name']; ?>" /></div>
			</div>
			<div class="clear"></div>
			<input type="hidden" name="id" id="id" value="<?php echo $aPrize['id']; ?>"/>
			<div class="item">
				<div class="name">奖品名称：</div>
				<div class="control">
					<select id="type" name="type">
						<option <?php if($aPrize['type'] == 1){ echo 'selected="selected"'; } ?> value="1">金币</option>
						<option <?php if($aPrize['type'] == 2){ echo 'selected="selected"'; } ?> value="2">Q币</option>
						<option <?php if($aPrize['type'] == 3){ echo 'selected="selected"'; } ?> value="3">实物</option>
					</select>
				</div>
			</div>
			<div class="clear"></div>
			
			<div class="item up-img">
				<div class="name">奖品图片：</div>
				<div class="control" class="hide">
					<input type="file" name="image" id="image"/>
				</div>
				<div class="up-img-del" id="profile_main" style="display:block">
					<a href="javascript:void(0)" onclick="deleteImage()" title="删除" class="up-img-btndel">删除</a>
					<img id="profileImg" class="images" src="<?php echo SYSTEM_RESOURCE_URL . $aPrize['profile']; ?>"/>
				</div>
				<input type="hidden" value="<?php echo $aPrize['profile']; ?>" name="prize_addr" id="prize_addr"/>
			</div>
			
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">总数：</div>
				<div class="control"><input type="text" name="total" id="total" value="<?php echo $aPrize['total']; ?>"/>（不填或0就表示无限制，如金币）</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">金币数：</div>
				<div class="control"><input type="text" name="gold" id="gold" value="<?php echo $aPrize['gold']; ?> " />（只有类型为金币的时候才填）</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">概率：</div>
				<div class="control"><input type="text" name="chance" id="chance" value="<?php echo $aPrize['chance']; ?> " />（填50，表示50/10000。“2金币”奖品的概率要设为<strong>0</strong>，程序需要！）</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name"></div>
				<div class="control"><a class="button" id="submitButton" onclick="setGoods();" />修改奖品</a></div>
			</div>
			<div class="clear"></div>
		</div>
	</form>
</div>
<script type="text/javascript">
	$(function(){
		$('#image').AjaxUpload({
			text : '选择图片',
			fileKey : 'prize_addr',
			uploadUrl : 'http://<?php echo APP_MANAGE ?>/?m=Packet&a=uploadProfile&ajax=1',
			callback : function(aResult){
				if(aResult.status == 1){
					$('#profileImg').attr('src', aResult.data);
					$('#prize_addr').val(aResult.msg);
					$('#profile_main').show();
				}else{
					$('#profile_main').hide();
					UBox.show(aResult.msg, -1);
				}
			}
		});
	});
	
	function checkFrom(){
		if(!$('#name').val()){
			UBox.show('喂喂，给奖品起个名字好吧', -1);
			return false;
		}

		if(!$('#prize_addr').val()){
			UBox.show('喂喂大哥，明显还没上传图片好吧', -1);
			return false;
		}
		
		if(!$('#chance').val()){
			UBox.show('奖品概率呢', -1);
			return false;
		}
		return true;
	}

	function deleteImage(){
		$('#profile_main').hide();
		$('#prize_addr').val('');
		$('#profileImg').attr('src', '');
	}

	function setGoods(){
		if(!checkFrom()){
			return;
		}
		ajax({
			url: '/?m=Packet&a=setPrize',
			data: $('#goodsAdd').serialize(),
			success: function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1, '/?m=Packet&a=showPrizeList');
				}else{
					UBox.show(aResult.msg, -1);
				}
			}
		});
	}
</script>
<?php displayFooter(); ?>