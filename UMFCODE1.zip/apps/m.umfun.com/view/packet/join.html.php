<?php
	displayHeader();
	display('packet/nav.html.php');
?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:80px;}
	.list .c3{width:150px;}
	.list .c4{width:260px;}
	.list .c5{width:120px;}
	.list .c6{width:80px;}
	.list .c7{width:80px;}
	.list .c8{width:108px;}
	.list .c9{width:108px;}
	.list .c10{width:108px;}
	.list .c11{width:70px;}
	.list .c12{width:200px;}
	.list .c13{width:120px;}
	.right{float:right;}
	.button{border: none;}
</style>
<div class="module _conditon">
	<div class="item">
		<div class="name" style="margin-left:10px;">
			<span>
				<span>学生人数: <strong><?php echo $studentCount; ?></strong></span>
				<span>老师人数: <strong><?php echo $teacherCount; ?></strong></span>
				<span>家长人数: <strong><?php echo $parentCount; ?></strong></span>
				<span>发出金币: <strong><?php echo $sendGold; ?></strong></span>
			</span>
		</div>
	</div>
</div>
<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">姓名</div>
			<div class="c3">类型</div>
			<div class="c4">得奖</div>
			<div class="c5">参加时间</div>
			<div class="c6">上次抽奖时间</div>
		</div>

		<?php
		if(isset($aJoinList)){
			foreach($aJoinList as $aJoin){
			?>
				<div class="row">
					<div class="c1"><?php echo $aJoin['id']; ?></div>
					<div class="c2"><?php echo $aJoin['user_info']['name']; ?></div>
					<div class="c3" style="white-space:normal;">
					<?php
					if($aJoin['user_type'] == 1){
						echo '老师';
					}elseif($aJoin['user_type'] == 2){
						echo '学生';
					}else{
						echo '家长';
					}
					?>
					</div>
					<?php 
					$awardList = '--';
					if($aJoin['award_list']){
						foreach($aJoin['award_list'] as $aAward){
							$awardList .= '--' . $aAward['prize_info']['name'];
						}
					} 
					?>
					<div class="c4" title="<?php echo $awardList; ?>">
						<?php echo $awardList; ?>
					</div>
					<div class="c5">
						<?php echo date('m-d H:i', $aJoin['create_time']); ?>
					</div>
					<div class="c6">
						<?php
							if($aJoin['draw_time']){
								echo date('m-d H:i', $aJoin['draw_time']);
							}else{
								echo '---';
							}
						?>
					</div>
				</div>
			<?php
			}
		}
		?>
		<div class="clear"></div>
		
	</div>
</div>
<div class="row footer">
	<?php echo $pageHtml; ?>
</div>

<?php displayFooter(); ?>