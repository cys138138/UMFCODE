<?php
displayHeader(); 
display('packet/nav.html.php'); 
?>

<style type="text/css">
	.row div{line-height: 28px;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:100px;}
	.list .c3{width:150px;}
	.list .c4{width:150px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:100px;}
	.right{float:right;}
	.button{border: none;}
	.maximg{max-width:100%;}
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			奖品列表
		</div>
		
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">奖品名称</div>
			<div class="c2">类型</div>
			<div class="c3">图片</div>
			<div class="c5">总数</div>
			<div class="c5">概率</div>
			<div class="c5">被领取</div>
			<div class="c4 right">操作</div>
		</div>
		
		<?php if(isset($aPrizeList)){
			foreach($aPrizeList as $key => $aPrize){?>
				<div class="row">
					<div class="c1"><?php echo $aPrize['id']; ?></div>
					<div class="c2"><?php echo $aPrize['name']; ?></div>
					<div class="c2">
						<?php 
						if($aPrize['type'] == 1){  
							echo '金币'; 
						}elseif($aPrize['type'] == 2){  
							echo 'Q币'; 
						}else{
							echo '实物';
						}
						?>
					</div>
					<div class="c3"><img width="80px" src="<?php echo SYSTEM_RESOURCE_URL . $aPrize['profile']; ?>" ></div>
					<div class="c5"><?php echo $aPrize['total']; ?></div>
					<div class="c5"><?php echo $aPrize['chance']; ?>/10000</div>
					<div class="c5"><?php echo $aPrize['send_nums']; ?></div>
					<div class="c4 right">
						<a href="/?m=Packet&a=showEditPrize&id=<?php echo $aPrize['id']; ?>" class="checkOff">修改</a>
					</div>
				</div>
		<?php }
		}else{
			echo '<div class="row">很抱歉，尚无数据</div>';
		}?>

		<div class="clear"></div>

	</div>
</div>
<?php displayFooter(); ?>