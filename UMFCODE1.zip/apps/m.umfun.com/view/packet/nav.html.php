<div class="nav">
	<a <?php if(get('a') == 'showJoinList'){ ?>class="on"<?php } ?> href="?m=Packet&a=showJoinList">参加统计</a>
	<a <?php if(get('a') == 'showAwardList'){ ?>class="on"<?php } ?> href="?m=Packet&a=showAwardList">获奖管理</a>
	<a <?php if(get('a') == 'showPrizeList'){ ?>class="on"<?php } ?> href="?m=Packet&a=showPrizeList">奖品管理</a>
	<a <?php if(get('a') == 'showAddPrize'){ ?>class="on"<?php } ?> href="?m=Packet&a=showAddPrize">添加奖品</a>
	<?php if(get('a') == 'showEditPrize'){ echo '<a class="on" href="?m=Packet&a=showEditPrize&id=' . get('id') . '">修改奖品</a>'; } ?>
</div>
<div class="br"></div>