<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=EsCreate&a=showList">我的题目</a>
	<a <?php if(get('a') == 'showAdd' || get('a') == 'showBatchAdd'){  ?>class="on"<?php } ?> href="?m=EsCreate&a=showAdd">出题</a>
	<a <?php if(get('a') == 'showStatistic'){ ?>class="on"<?php } ?> href="?m=EsCreate&a=showStatistic">统计</a>

	<?php if(get('a') == 'showDetail'){ ?>
		<a class="on">查看题目ID:<?php echo get('esId'); ?></a>
		<a onclick="javascript:history.go(-1);">返回上一页</a>
	<?php } ?>

	<?php if(get('a') == 'showEdit'){ ?>
		<a class="on">编辑题目ID:<?php echo get('esId'); ?></a>
		<a onclick="javascript:history.go(-1);">返回上一页</a>
	<?php } ?>

</div>

<div class="br"></div>
