<?php display('es_create/nav.html.php'); ?>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<?php if($aEs['subject_id'] == 2){ ?>
	<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<?php } ?>
<div class="module wrapEs">
	<div class="title"><span>查看 <?php echo get('esId'); ?> 号题目</span></div>
	<div class="item">
		<div class="name">科目：</div>
		<div class="control"><?php echo $aSubject[$aEs['subject_id']]; ?></div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">所在目录：</div>
		<div class="control"><?php echo $aEs['catetory_name']; ?></div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">题型：</div>
		<div class="control"><?php echo $aEsType[$aEs['type_id']]; ?></div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">状态：</div>
		<div class="control"><?php echo $aEsStatus[$aEs['status']]; ?></div>
	</div>
	
	<?php 
	if(isset($aEs['sendback_reason'])){
	?>
		<div class="clear"></div>
		<div class="item">
			<div class="name">驳回理由：</div>
			<div class="control"><?php echo $aEs['sendback_reason']; ?></div>
		</div>
	<?php 
	}
	?>
	
	<div class="clear"></div>
	<div class="item">
		<div class="name">创建时间：</div>
		<div class="control"><?php echo $aEs['create_time']; ?></div>
	</div>
	<div class="clear"></div>
	<?php if($aEs['status'] >= 2){ ?>
	<div class="item">
		<div class="name">提交时间：</div>
		<div class="control"><?php echo $aEs['submit_time']; ?></div>
	</div>
	<div class="clear"></div>
	<?php } ?>
    
	<div id="esContent" class="es_content"></div>
</div>

<script type="text/javascript">
$(function(){
	$(".module .item:even").addClass("item_even");
	$(".module ._option_:odd").addClass("_option_odd");
	
	ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
	$('#esContent').append(ES.buildDetail(<?php echo json_encode($aEs); ?>));
});
</script>