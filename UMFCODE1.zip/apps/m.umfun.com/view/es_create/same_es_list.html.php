<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<?php if(isset($aSameEsList[0]['subject_id']) && $aSameEsList[0]['subject_id'] == 2){ ?>
	<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<?php } ?>
<style>
.wrapEs{margin-bottom:20px; border-bottom:1px solid #CCC;}
.wrapEs.mainEs{background:#FDCB01;}
.wrapEs .indexTip{font-size:14px; color:#000;}
</style>
	
<div class="title">目录：<?php
$aCategory = $aSameEsList[0]['category_tree'];
$categoryPath = '';
do{
	$categoryPath .= $aCategory['name'] . ' => ';
	if(isset($aCategory['child'])){
		$aCategory = $aCategory['child'];
	}else{
		$aCategory = array();
	}
}while($aCategory);
$categoryPath = substr($categoryPath, 0, -4);
echo $categoryPath;
?></div>
<div class="wrapEsList" id="wrapEsList">
	<?php if($aMainEs){ ?>
	<div class="wrapEs mainEs">
		<p class="indexTip">您要检查的题目 id:<?php echo $aMainEs['id']; ?></p>
		<div id="mainEsContent" class="es_content"></div>
		<br class="clear">
	</div>
	<?php } ?>
</div>
<p><button class="button" type="button" onclick="window.close();">关闭窗口</button></p>
<script>
	$(function(){
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		
		$('#mainEsContent').append(ES.buildDetail(<?php echo json_encode($aMainEs); ?>));
		var aSameEsList = <?php echo json_encode($aSameEsList); ?>
		,aStatusList = <?php echo json_encode($aEsStatus); ?>;
		for(var i = 0; i < aSameEsList.length; i++){
			var aEs = aSameEsList[i];
			var $oEs = $('<div class="wrapEs sameEs">\
				<p class="indexTip">第' + (i + 1) + '条相似题目 id:' + (aEs.id) + '</p>\
				<p class="indexTip">状态：<span>' + (aEs.status == 0 ? '未入库' : aStatusList[aEs.status]) + '</span></p>\
				<p class="indexTip">出题人：<span>' + (aEs.creater ? aEs.creater : '<font class="red">(旧转新)</font>') + '</span></p>\
				<div class="es_content" xid="sameEsContent"></div>\
				<br class="clear">\
			</div>');
			$oEs.find('div[xid="sameEsContent"]').append(ES.buildDetail(aEs));
			$('#wrapEsList').append($oEs);
		}
	});
</script>