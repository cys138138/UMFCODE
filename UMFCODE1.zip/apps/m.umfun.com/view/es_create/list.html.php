<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<?php display('es_create/nav.html.php'); ?>
<div class="module _condition">
	<style type="text/css">
		._condition .item a{color:#999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
	</style>

	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<a href="javascript:void(0)" onclick="select(1, 0, this)" <?php if(!$subjectId){ ?> class="on" <?php } ?> xid="subject">全部</a>
			<?php foreach($aSubject as $key => $subject){ ?>
				<a href="javascript:void(0)" <?php if($subjectId == $key){ ?> class="on" <?php } ?> onclick="select(1, <?php echo $key; ?>, this)" xid="subject"><?php echo $subject; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="name">题型：</div>
		<div class="control">
			<a href="javascript:void(0)" onclick="select(2, 0, this)" <?php if(!$esTypeId){ ?> class="on" <?php } ?> xid="esType">全部</a>
			<?php foreach($aEsType as $key => $esType){ ?>
				<a href="javascript:void(0)" <?php if($esTypeId == $key){ ?> class="on" <?php } ?> onclick="select(2, <?php echo $key; ?>, this)" xid="esType"><?php echo $esType; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="name">状态：</div>
		<div class="control">
			<?php
			foreach($aStatus as $key => $status){
				if($key <= 4){
			?>
					<a href="javascript:void(0)" <?php if($esStatus == $key){ ?> class="on" <?php } ?> onclick="select(3, <?php echo $key; ?>, this)" xid="esStatus"><?php echo $status; ?></a>
			<?php
				}
			}
			?>
		</div>
	</div>

	<div class="clear"></div>

	<div class="item">
		<div class="name">时间：</div>
		<div class="control">
			<select id="time_type" onchange="selectTimeType()" name="time_type">
				<?php foreach($aTimeType as $key => $action){ ?>
					<option <?php if($timeType == $key){ ?> selected="selected" <?php } ?> value="<?php echo $key; ?>"><?php echo $action; ?></option>
				<?php } ?>
			</select>
			&nbsp;&nbsp;
		</div>
		<div class="control"><input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />&nbsp;-&nbsp;<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" /></div>
		<div class="control"><a href="javascript:void(0)" class="button" onclick="searchEs()">确定</a></div>
	</div>

	<div class="clear"></div>
</div>

<form autocomplete="off">
	<div class="wrapEsListContainer subject_<?php echo $subjectId; ?>">
		<p class="title">我的题目</p>
		<ul class="listItem esListHead">
			<li class="checkBox">选择</li>
			<li class="id">编号</li>
			<li class="subject">科目</li>
			<li class="type">题型</li>
			<li class="status">状态</li>
			<li class="submitTime">提交时间</li>
			<li class="approveTime">审核时间</li>
			<li class="appeal">申诉状态</li>
			<br class="clear">
		</ul>

		<div class="wrapEsList" id="wrapEsList"></div>
		<br class="clear">

		<div class="wrapPage">
			<span class="cellAll">
				<input id="cellAll" type="checkbox" onclick="cellIds();" />
				<label for="cellAll">全选</label>
			</span>
			<button type="button" class="btnOperation" onclick="subApprove();">批量提交</button><?php isset($pageHtml) && print($pageHtml); ?>
			<br class="clear">
		</div>
		<br class="clear">
	</div>
</form>
<script type="text/javascript">
	function select(key, value, object){
		if(key == 1){
			searchCondition.subject = value;
			$('a[xid="subject"]').removeClass('on');
		}else if(key == 2){
			searchCondition.esType = value;
			$('a[xid="esType"]').removeClass('on');
		}else if(key == 3){
			searchCondition.esStatus = value;
			$('a[xid="esStatus"]').removeClass('on');
		}
		$(object).addClass('on');
		searchEs();
	}

	function selectTimeType(){
		searchCondition.timeType = $('#time_type').val();
	}
	
	<?php
	$subjectCheck = '';
	$i = 1;
	foreach($aSubject as $key => $subject){
		if($i < count($aSubject)){
			$subjectCheck .= 'searchCondition.subject != ' . $key . ' && ';
		}else{
			$subjectCheck .= 'searchCondition.subject != ' . $key;
		}
		$i++;
	}
	$subjectCheck .= ' && searchCondition.subject != 0';

	$esTypeCheck = '';
	$i = 1;
	foreach($aEsType as $key => $esType){
		if($i < count($aEsType)){
			$esTypeCheck .= 'searchCondition.esType != ' . $key . ' && ';
		}else{
			$esTypeCheck .= 'searchCondition.esType != ' . $key;
		}
		$i++;
	}
	$esTypeCheck .= ' && searchCondition.esType != 0';

	$esStatusCheck = '';
	$i = 1;
	foreach($aStatus as $key => $status){
		if($i < count($aStatus)){
			$esStatusCheck .= 'searchCondition.esStatus != ' . $key . ' && ';
		}else{
			$esStatusCheck .= 'searchCondition.esStatus != ' . $key;
		}
		$i++;
	}
	?>
		
	function searchEs(){
		if(<?php echo $subjectCheck; ?>){
			UBox.show('错误的科目');
			return false;
		}
		if(<?php echo $esTypeCheck; ?>){
			UBox.show('错误的题目类型');
			return false;
		}
		if(<?php echo $esStatusCheck; ?>){
			UBox.show('错误的题目状态');
			return false;
		}
		if(searchCondition.timeType != 1 && searchCondition.timeType != 2 && searchCondition.timeType != 3){
			UBox.show('错误的时间类型');
			return false;
		}

		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();

		if(searchCondition.subject){
			url += '&subject=' + searchCondition.subject;
		}
		if(searchCondition.esType){
			url += '&esType=' + searchCondition.esType;
		}
		if(searchCondition.esStatus){
			url += '&esStatus=' + searchCondition.esStatus;
		}
		url += '&timeType=' + searchCondition.timeType;
		if(startTime){
			url += '&startTime=' + startTime;
		}
		if(endTime){
			url += '&endTime=' + endTime;
		}

		window.location.href = url;
	}

	function operateEs(id, type){
		if(!(id >= 1)){
			UBox.show('非法的题目ID');
			return false;
		}else{
			var method = '';
			if(type == 1){
				if(!confirm('确定要删除这条题目吗?')){
					return false;
				}
				method = 'deleteEs';
			}else if(type == 2){
				method = 'submitEs';
			}else if(type == 3){
				method = 'appeal';
			}
			$.ajax({
				url : '?m=EsCreate&a=' + method + ignoreSameEsParam,
				type : 'post',
				data : {esId : id},
				dataType : 'json',
				success : function(aResult){
					if(aResult.status == -1){
						UBox.confirm(aResult.msg, function(){
							ignoreSameEsParam = '&ignore_same_es=1';
							operateEs(id, type);
						});
					}else{
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status != 1){
							return;
						}
						
						$('#esItem' + id).slideUp('normal', function(){
							$(this).remove();
							if($oWrapEsList.find('ul[xid="esItem"]').length == 0){
								location.reload();
							}
						});
					}
				},
				error : function(aRequest){
					UBox.show('抱歉，网络可能有点慢，请稍后再重试');
				}
			});
		}
	}

	function cellIds(){
		var $oCellAll = $('#cellAll');
		if($oCellAll.data('status') == 1){
			$('input[xid="chkEsid"]').each(function(){
				this.checked = false;
			});
			$oCellAll.data('status', 0);
		}else{
			$('input[xid="chkEsid"]').each(function(){
				this.checked = true;
			});
			$oCellAll.data('status', 1);
		}
	}

	function subApprove(){
		var aEsId = [];
		$oWrapEsList.find('input[xid="chkEsid"]:checked').each(function(){
			aEsId.push($(this).closest('[xid="esItem"]').data('es').id);
		});
		if(aEsId.length == 0){
			UBox.show('请选择需要提交的题目', -1);
			return false;
		}
		
		$.ajax({
			url : '?m=EsCreate&a=batchSubmitEs' + ignoreSameEsParam,
			type : 'post',
			data : {esIds : aEsId},
			dataType : 'json',
			success : function(aResult){
				if(aResult.status == -1){
					UBox.confirm(aResult.msg, function(){
						ignoreSameEsParam += '&ignore_same_es=1';
						subApprove();
					});
				}else{
					UBox.show(aResult.msg, aResult.status, aResult.status == 1 ? 'reload' : '');
				}
			},
			error : function(aRequest){
				UBox.show('网络可能有点慢');
			}
		});
	}
	
	function showEsList(){
		var aEsList = <?php echo json_encode($aEsList); ?>
		,aSubjectList = <?php echo json_encode($aSubject); ?>
		,aTypeList = <?php echo json_encode($aEsType); ?>
		,aStatusList = <?php echo json_encode($aStatus); ?>
		,aAppealStatusList = ['未申诉', '申诉中', '申诉成功', '申诉失败'];
		for(var i = 0; i < aEsList.length; i++){
			var aEs = aEsList[i]
			,aControlButtons = [];
			
			if(aEs.status == 1 || aEs.status == 4 && aEs.appeal_status != 2){
				aControlButtons.push('<p class="control">\
					<button class="btnOperation" type="button" onclick="location.href=\'?m=EsCreate&a=showEdit&esId=' + aEs.id + '&rf=<?php echo base64_encode($_SERVER["REQUEST_URI"]);?>\'">编辑</button>');
				if(aEs.status != 4){
					aControlButtons.push('<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 2)">提交</button>');
				}
			}
			if(aEs.status == 1){
				aControlButtons.push('<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 1)">删除</button>');
			}
			if(aEs.status == 4 && aEs.appeal_status == 1){
				aControlButtons.push('<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 3)">申诉</button>');
			}
			
			var $oEs = $('<ul class="listItem esItem subject' + aEs.subject_id + '" xid="esItem" id="esItem' + aEs.id + '">\
				<li class="checkBox"><input type="checkbox" id="esId' + aEs.id + '" xid="chkEsid" /></li>\
				<li class="id"><label for="esId' + aEs.id + '">' + aEs.id + '</label></li>\
				<li class="subject">' + aSubjectList[aEs.subject_id] + '</li>\
				<li class="type">' + aTypeList[aEs.type_id] + '</li>\
				<li class="status">' + aStatusList[aEs.status] + '</li>\
				<li class="submitTime">' + (aEs.submit_time ? aEs.submit_time : '-- -- --') + '</li>\
				<li class="approveTime">' + (aEs.approve_time ? aEs.approve_time : '-- -- --') + '</li>\
				<li class="appeal status' + aEs.appeal_status + '">' + aAppealStatusList[aEs.appeal_status - 1] + '</li>\
				<br class="clear">\
				<div class="wrapDetail es_content" xid="wrapDetail"></div>\
				<p class="control category">目录：' + getCategoryTreePath(aEs.category_tree) + '</p>\
				' + (aEs.same_ids.length ? '<p class="control sameEs"><a class="red" href="?m=EsCreate&a=showSameEsList&check_es_id=' + aEs.id + '&same_ids=' + aEs.same_ids.join(',') + '" target="_blank">存在相似题目</a></p>' : '') + '\
				' + (aEs.sendback_reason ? '<p class="control name reject">驳回理由：' + aEs.sendback_reason + '</p>' : '') + '\
				<p class="control">' + aControlButtons.join('') + '</p>\
			</ul>').appendTo($oWrapEsList).data('es', aEs);
			$oEs.find('div[xid="wrapDetail"]').append(ES.buildDetail(aEs));
		}
	}

	var $oWrapEsList = null
	,endTime = "'end_time'"
	,url = '<?php echo $baseUrl; ?>'
	,ignoreSameEsParam = ''
	,searchCondition = {
		subject : <?php echo $subjectId; ?>,
		esType : <?php echo $esTypeId; ?>,
		esStatus : <?php echo $esStatus; ?>,
		timeType : <?php echo $timeType; ?>
	};
	$(function(){
		$oWrapEsList = $('#wrapEsList');
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		showEsList();
		
		$('#start_time').blur(function(){
			$.cookie('createrStartTime', $(this).val(), {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
		});
		$('#end_time').blur(function(){
			$.cookie('createrEndTime', $(this).val(), {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
		});
	});
</script>