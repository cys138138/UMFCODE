<?php display('es_create/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<div class="module _condition">
	<style>
		._condition .item a{color:#999999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FFCC00; margin-left:5px;}
	</style>
	
	<div class="item">
		<div class="name">时间：</div>
		<div class="control">
			<a href="javascript:void(0)" <?php if($dayType == 1){ ?> class="on" <?php } ?> onclick="statistic(1)">最近3天</a>
			<a href="javascript:void(0)" <?php if($dayType == 2){ ?> class="on" <?php } ?> onclick="statistic(2)">最近7天</a>
			<a href="javascript:void(0)" <?php if($dayType == 3){ ?> class="on" <?php } ?> onclick="statistic(3)">最近15天</a>
			<a href="javascript:void(0)" <?php if($dayType == 4){ ?> class="on" <?php } ?> onclick="statistic(4)">最近30天</a>
			自定义时间查询：
			<input type="text" id="startTime" value="<?php echo date('Y-m-d H:i:s', $startTime); ?>" name="startTime" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" />&nbsp;-&nbsp;<input id="endTime" name="endTime" value="<?php echo date('Y-m-d H:i:s', $endTime); ?>" type="text" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" />
		</div>
		<div class="control"><a onclick="searchStatistic()" class="button">确定</a></div>
	</div>
	
	<div class="clear"></div>

</div>
<?php
	$checkDayType = '';
	$i = 1;
	foreach($aDayType as $key => $dayType){
		if($i < count($aDayType)){
			$checkDayType .= 'dayType != ' . $key . ' && ';
		}else{
			$checkDayType .= 'dayType != ' . $key;
		}
		$i++;
	}
?>
<script type="text/javascript">
	var dayType = '<?php echo $dayType ?>';
	window.url = '<?php echo $baseUrl; ?>';
	function statistic(currentDay){
		dayType = currentDay;
		if(<?php echo $checkDayType; ?>){
			UBox.show('错误的类型');
			return false;
		}
		url += '&dayType=' + dayType;
		window.location.href = url;
	}
	
	function searchStatistic(){
		var startTime = $('#startTime').val();
		var endTime = $('#endTime').val();
		if(!startTime){
			UBox.show('请填写开始时间');
			return false;
		}
		if(!endTime){
			UBox.show('请填写结束时间');
			return false;
		}
		url += '&startTime=' + startTime;
		url += '&endTime=' + endTime;
		window.location.href = url;
	}
</script>
<style>
	._esList .row {font-weight:bold;}
	._esList .row .c1{width:100px; color:#000000;}
	._esList .row .c2{width:100px;}
	._esList .row .c3{width:100px;}
	._esList .row .c4{width:100px;}
	._esList .row .c5{width:100px;}
	._esList .row .c6{width:100px;}
</style>
<?php
	foreach($aStatistic as $subjectKey => $aSubjectStatic){
?>
	<div class="module _esList">
		<div class="title"><?php echo $GLOBALS['SUBJECT'][$subjectKey]; ?>科目</div>
		<div class="list">
			
			<div class="row header">
				<div class="c1">题型</div>
				<div class="c2">创建数量</div>
				<div class="c3">已提交数量</div>
				<div class="c4">已通审数量</div>
				<div class="c5">已发回数量</div>
				<div class="c6">申诉有效数量</div>
			</div>
			<?php
			foreach($aSubjectStatic as $esTypeKey => $static){
			?>
			<div class="row">
				<div class="c1"><?php echo $GLOBALS['ES_TYPE'][$esTypeKey]; ?></div>
				<div class="c2"><?php echo $static['create_nums']; ?></div>
				<div class="c3"><?php echo $static['submit_times']; ?></div>
				<div class="c4"><?php echo $static['pass_approve_nums']; ?></div>
				<div class="c5"><?php echo $static['sendback_times']; ?></div>
				<div class="c6"><?php echo $static['effective_appeal_nums']; ?></div>
			</div>
			<?php
			}
			?>

			<div class="row footer">
			</div>
		</div>
	</div>
<?php
}
?>