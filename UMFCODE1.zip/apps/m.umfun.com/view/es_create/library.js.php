<script type="text/javascript">
	var lastActiveObject;
	var rememberAddUnderline = false;
	ES.config({
		shuffleChoise : false
	});
	function rememberUnderline(obj){
		if(rememberAddUnderline == false){
			rememberAddUnderline = true;
			$(obj).text('结束添加下划线');
		}else{
			rememberAddUnderline = false;
			$(obj).text('开始添加下划线');
		}
	}

	function bindingEvent(){
		$('#esForm').delegate('textarea,:text', 'click', function(){
			lastActiveObject = this;
		});

		$('#esForm').delegate('textarea', 'click', function(){
			addUnderLine();
		});
	}

	function toggleModel(type){
		var aEs = oEs.buildEsData()
		,oPreview = null;
		aEs.subject_id = '<?php echo $subjectId; ?>';
		if(type == 1){
			oPreview = ES.buildQuestion(aEs);
		}else{
			oPreview = ES.buildDetail(aEs);
		}
		
		popEasyDialog({
			title : '题目预览',
			width : 725,
			height : 500,
			content : '<div id="wrapPreview" class="wrapEsPreview es_content"></div>',
			confirmCallBack : $.noop
		});
		oPreview.appendTo('#wrapPreview');
	}

	function checkForm(){
		if(!oEs.validate()){
			return false;
		}
		return oEs.buildEsData();
	}

	function addUnderLine(){
		if(rememberAddUnderline == true){
			if(!lastActiveObject || lastActiveObject.selectionStart == lastActiveObject.selectionEnd){
				return false;
			}
			var obj = lastActiveObject;
			var selStr = obj.value.slice(obj.selectionStart, obj.selectionEnd),
			lStr = obj.value.slice(0, obj.selectionStart),
			rStr = obj.value.slice(obj.selectionEnd, obj.value.length);
			selStr = '<u>' + selStr + '</u>';
			obj.value = lStr + selStr + rStr;
			return obj.value;
		}
	}

	function getCategoryId(){
		var categoryId = oDirTree.getSelected();
		if(!oDirTree.isNoChild(categoryId)){
			if($('#category_id').val()){
				$('#category_id').val(0);
				showCategoryResult(0);
			}
			return;
		}
		$('#category_id').val(categoryId);
		$.cookie('lastCatagory<?php echo $subjectId; ?>', categoryId , {expires: 3600000 * 24 * 7});
		showCategoryResult(categoryId);
	}

	//将目录显示结果显示到#categoryResult上
	function showCategoryResult(categoryId){
		var categoryName = '';

		$(aCategoryList).each(function(){
			if(this.id == categoryId){
				categoryName = this.name;
				return;
			}
		});

		$('#categoryResult').text(categoryName);
	}
</script>