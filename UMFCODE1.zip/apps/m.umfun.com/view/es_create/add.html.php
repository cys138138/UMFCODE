<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<?php display('es_create/nav.html.php'); ?>
<div class="module _subject">
	<div class="item">
		<?php
		foreach($aSubject as $subjectKey => $subject){
			if(isset($aSubjectType[$subjectKey])){
		?>
				<div class="name"><?php echo $subject; ?>：</div>
				<div class="control">
					<?php foreach($aSubjectType[$subjectKey] as $subjectType){ ?>
						<a <?php if($subjectId == $subjectKey && $esType == $subjectType){ ?> class="on" <?php } ?> href="?m=EsCreate&a=showAdd&subject=<?php echo $subjectKey; ?>&esType=<?php echo $subjectType; ?>"><?php echo $aEsType[$subjectType]; ?></a>
					<?php } ?>
				</div>
				<div class="clear"></div>
		<?php
			}
		}
		?>
	</div>
	<div class="clear"></div>
</div>

<?php
if($subjectId && $esType){
?>
	<div class="item">
		<div class="control batch">
			<a href="?m=EsCreate&a=showBatchAdd&subject=<?php echo $subjectId; ?>&esType=<?php echo $esType; ?>">批量出题</a>
		</div>
	</div>
	<div class="clear"></div>
	<form class="module form esForm" id="form">
		<input type="hidden" name="category_id" id="category_id" />
		<input type="hidden" name="subject_id" id="subject_id" value="<?php echo $subjectId; ?>" />
		<input type="hidden" name="es_type" value="<?php echo $esType; ?>" />
		<input type="hidden" id="isSubmit" name="isSubmit" />
		<div class="item">
			<div class="name">辅助功能：</div>
			<div class="control helpButton">
			<button type="button" class="btnOperation" onclick="rememberUnderline(this)">开始添加下划线</button>
			<?php if($esType == 4 || $esType == 5){ ?>
				<button type="button" class="btnOperation" onclick="oEs.addAnswer()">添加答案填充区</button>
				<button type="button" class="btnOperation" onclick="oEs.resetAllAnswer()">重新生成答案填充区</button>
				<button type="button" class="btnOperation" onclick="oEs.addNorder()">添加答案组</button>
			<?php }
			if($subjectId == 1 || $subjectId == 2){ ?>
				<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['char_inputer']; ?>"></script>
				<button type="button" class="btnOperation" onclick="CharInputer.show()">添加<?php echo $subjectId == 1 ? '元音音标' : '数学符号'; ?></button>
				<script type="text/javascript">
					CharInputer.init({
						subject : <?php echo $subjectId; ?>
						,closeOnMouseout : false
					});
				</script>
			<?php } ?>
			<button type="button" class="btnOperation" onclick="toggleModel(1)">作答预览</button>
			<button type="button" class="btnOperation" onclick="toggleModel(2)">结果预览</button>
		</div>
		</div>
		<div class="clear"></div>
		<div id="esForm" class="subject_<?php echo $subjectId; ?>"></div>
		<div class="clear"></div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button id="saveEs" onclick="submitEs(false)" type="button" class="btnOperation">保存</button>
				<button id="saveAndSubmit" onclick="submitEs(true)" type="button" class="btnOperation">保存并提交</button>
				<span class="noJump">
					<input type="checkBox" id="noJump" onclick="saveJumpSet()" />
					<label for="noJump">保存后不跳转</label>
				</span>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">所选目录：</div>
			<div id="categoryResult" class="control"></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">目录：</div>
			<div class="control" id="category">
				<script type="text/javascript">
					oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
					oDirTree.add(0, -1, '题目目录');
					<?php if(isset($aCategoryList)){
						if(!$aCategoryList){ ?>
							UBox.show('系统还没有建立 <?php echo $GLOBALS['SUBJECT'][$subjectId]; ?> 科目的题目目录,请提醒总编设定题目目录', 0, '', 2);
						<?php } ?>
					var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
					$(aCategoryList).each(function(){
						oDirTree.add(this.id, this.parent_id, this.name, 'javascript:getCategoryId()', this.name);
					});
					<?php } ?>
					document.write(oDirTree);
					var lastCategory = $.cookie('lastCatagory<?php echo $subjectId; ?>');
					if(lastCategory > 0){
						oDirTree.openTo(lastCategory, true);
						$('#category_id').val(lastCategory);
					}
				</script>
			</div>
		</div>
	</form>
<?php } ?>
<?php display('es_create/library.js.php'); ?>
<script type="text/javascript">
	function submitEs(isSubmit){
		var aEs = checkForm();
		if(!aEs){
			return false;
		}

		var categoryId = $('#category_id').val();
		if(!(categoryId >= 1)){
			UBox.show('请选择题目所属目录');
			return false;
		}
		$.ajax({
			url : submitUrl,
			type : 'post',
			dateType : 'json',
			data : {
				subject_id : '<?php echo $subjectId; ?>',
				es_type : '<?php echo $esType; ?>',
				category_id : $('#category_id').val(),
				isSubmit : isSubmit ? 1 : 0,
				es : aEs.es_content
			},
			beforeSend : function(){
				$('#saveEs,#saveAndSubmit').attr('disabled', 'disabled').css({'background-color':'#999'});
			},
			complete : function(){
				$('#saveEs').attr('disabled', false).css({'background-color':'#333'});
				$('#saveAndSubmit').attr('disabled', false).css({'background-color':'#333'});
			},
			success : function(result){
				if(result.status == 1){
					addLastIdToLeftIframe(result.data.lastId);
					if($.cookie('noJump') == 1){
						UBox.show(result.msg, result.status);
						setTimeout(function(){
							window.location.reload();
						}, 1000);
					}else{
						UBox.show(result.msg, result.status, result.data.url);
					}
				}else if(result.status == -1){
					UBox.confirm(result.msg, function(){
						submitUrl += '&ignore_same_es=1';
						submitEs(isSubmit);
					});
				}else{
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				UBox.show('网络可能有点慢');
			}
		});
	}

	function addLastIdToLeftIframe(lastId){
		var oLeftBody = $(parent.leftFrame.window.document.body);
		var lastIdDivHtml = '';
		var oDate = new Date();
		var hours = oDate.getHours();
		var minutes = oDate.getMinutes();
		var seconds = oDate.getSeconds();
		var addTime = hours + ':' + minutes + ':' + seconds;
		if(oLeftBody.find('#esIdDiv').length == 0){
			lastIdDivHtml += '<a class="btnClearIds" onclick="$(\'#esIdDiv\').empty()" target="_self" href="##">清除ID记录</a>\n\
			<style type="text/css">\n\
				.btnClearIds{display:block; font-weight:bold; margin:5px 0; text-align:center;}\n\
				.esIdDiv{overflow:hidden;height:300px;}\n\
				.esIdDiv p{text-align:center; }\n\
				.esIdDiv p a{color:#FFF; font-size: 14px; margin: 10px 0;}\n\
			</style>\n\
			<div id="esIdDiv" class="esIdDiv">\n\
				<p><a href="?m=EsCreate&a=showDetail&esId=' + lastId + '"><span style="color:#06C;">' + addTime + '</span>&nbsp;&nbsp;' + lastId + '</a></p>\n\
			</div>';
			oLeftBody.append(lastIdDivHtml);
		}else{
			lastIdDivHtml += '<p><a href="?m=EsCreate&a=showDetail&esId=' + lastId + '"><span style="color:#06C;">' + addTime + '</span>&nbsp;&nbsp;' + lastId + '</a></p>';
			oLeftBody.find('#esIdDiv').prepend(lastIdDivHtml);
		}
	}

	function saveJumpSet(){
		var noJump = document.getElementById('noJump');
		if(noJump.checked){
			$.cookie('noJump', 1 , {expires: 3600000 * 24 * 7});
		}else{
			$.cookie('noJump', 0);
		}
	}
	
	var aPostData = null,
	submitUrl = '?m=EsCreate&a=addEs';
	var oEs = null;
	$(function(){
		if(!'<?php echo $subjectId; ?>'){
			return;
		}
		
		showCategoryResult(lastCategory);
		bindingEvent();

		ES.config({
			imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>',
			imageUploadUrl : '?m=EsCreate&a=uploadImage&ajax=1&subject=<?php echo $subjectId; ?>'
		});
		
		oEs = ES.buildForm(ES.getDefaultData(<?php echo $esType; ?>));
		$('#esForm').append(oEs);

		if($.cookie('noJump') == 1){
			$('#noJump').attr('checked', true);
		}
		
		$('textarea, input[type="text"]').each(function(){
			$(this).val('');
		});
		
		$('input[xid="trueFalse"], input[xid="isAnswer"]').each(function(){
			$(this).attr('checked', false);
		});
	});
</script>