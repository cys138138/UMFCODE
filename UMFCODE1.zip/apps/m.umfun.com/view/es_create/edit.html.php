<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<?php display('es_create/nav.html.php'); ?>
<form class="module form esForm" id="form">
	<input type="hidden" name="category_id" value="<?php echo $categoryId; ?>" id="category_id" />
	<input type="hidden" name="subject_id" value="<?php echo $subjectId; ?>" id="subject_id" />
	<input type="hidden" name="es_type" value="<?php echo $esType; ?>" id="es_type" />
	<input type="hidden" name="id" value="<?php echo $id; ?>" id="id" />
	<input type="hidden" id="isSubmit" name="isSubmit"/>
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<input type="text"  value="<?php echo $GLOBALS['SUBJECT'][$subjectId]; ?>" disabled="disabled" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">题型：</div>
		<div class="control">
			<input type="text" id="showEsType"  value="<?php echo $GLOBALS['ES_TYPE'][$esType]; ?>" disabled="disabled" />
		</div>
	</div>
	<div class="clear"></div>
	<?php if($sameBaseEsType >= 2){ ?>
		<div class="item">
			<div class="name">修改题型：</div>
			<div class="control">
				<?php foreach($aSameEsTypeId as $typeId){ ?>
					<input type="radio" id="sameType<?php echo $typeId; ?>" onclick="changeEsTye(<?php echo $typeId; ?>)" <?php if($esType == $typeId){ ?> checked="checked" <?php } ?> name="type_id" value="<?php echo $typeId; ?>" /><label style="margin-right:10px;" for="sameType<?php echo $typeId; ?>"><?php echo $GLOBALS['ES_TYPE'][$typeId]; ?></label>
				<?php } ?>
			</div>
		</div>
		<div class="clear"></div>
	<?php } ?>
	<div class="clear"></div>
	<div class="item">
		<div class="name">辅助功能：</div>
		<div class="control helpButton">
			<button type="button" class="btnOperation" onclick="rememberUnderline(this)">开始添加下划线</button>
			<?php if($esType == 4 || $esType == 5){ ?>
				<button type="button" class="btnOperation" onclick="oEs.addAnswer()">添加答案填充区</button>
				<button type="button" class="btnOperation" onclick="oEs.resetAllAnswer()">重新生成答案填充区</button>
				<button type="button" class="btnOperation" onclick="oEs.addNorder()">添加答案组</button>
			<?php }
			if($subjectId == 1 || $subjectId == 2){ ?>
				<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['char_inputer']; ?>"></script>
				<button type="button" class="btnOperation" onclick="CharInputer.show()">添加<?php echo $subjectId == 1 ? '元音音标' : '数学符号'; ?></button>
				<script type="text/javascript">
					CharInputer.init({
						subject : <?php echo $subjectId; ?>
						,closeOnMouseout : false
					});
				</script>
			<?php } ?>
			<button type="button" class="btnOperation" onclick="toggleModel(1)">作答预览</button>
			<button type="button" class="btnOperation" onclick="toggleModel(2)">结果预览</button>
		</div>
	</div>
	<div class="clear"></div>
	<div id="esForm" class="subject_<?php echo $subjectId;?>"></div>
	<div class="clear"></div>
	<div class="item">
		<div class="name"></div>
		<div class="control">
			<?php
			if($status != 4){
			?>
				<input id="saveEs" type="button" onclick="submitEs(false)" value="保存" class="button" />
			<?php
			}
			?>
			<input id="saveAndSubmit" type="button" onclick="submitEs(true)" value="保存并提交" class="button" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">所选目录：</div>
		<div id="categoryResult" class="control"></div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">目录：</div>
		<div class="control">
			<script type="text/javascript">
				oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
				oDirTree.add(0, -1, '题目目录');
				var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
				$(aCategoryList).each(function(){
					oDirTree.add(this.id, this.parent_id, this.name, 'javascript:getCategoryId()', this.name);
				});
				document.write(oDirTree);
				oDirTree.openTo(<?php echo $categoryId; ?>, true);
			</script>
		</div>
	</div>
</form>

<?php display('es_create/library.js.php'); ?>
<script type="text/javascript">
	function submitEs(isSubmit){
		var aEs = checkForm();
		if(!aEs){
			return false;
		}

		var categoryId = $('#category_id').val();
		if(!(categoryId >= 1)){
			UBox.show('请选择题目所属目录');
			return false;
		}
		$.ajax({
			url : submitUrl,
			type : 'post',
			dateType : 'json',
			data : {
				id : <?php echo $id; ?>,
				subject_id : <?php echo $subjectId; ?>,
				es_type : $('#es_type').val(),
				category_id : $('#category_id').val(),
				isSubmit : isSubmit ? 1 : 0,
				es : aEs.es_content
			},
			beforeSend : function(){
				$('#saveEs,#saveAndSubmit').attr('disabled', 'disabled').css({'background-color':'#999'});
			},
			complete : function(){
				$('#saveEs').attr('disabled', false).css({'background-color':'#333'});
				$('#saveAndSubmit').attr('disabled', false).css({'background-color':'#333'});
			},
			success : function(aResult){
				if(aResult.status == -1){
					UBox.confirm(aResult.msg, function(){
						submitUrl += '&ignore_same_es=1';
						submitEs(isSubmit);
					});
				}else{
					UBox.show(aResult.msg, aResult.status, '<?php echo base64_decode(get('rf'));?>');
				}
			},
			error : function(){
				UBox.show('网络可能有点慢');
			}
		});
	}

	function changeEsTye(esType){
		$('#es_type').val(esType);
		<?php
		$i = 0;
		foreach($aSameEsTypeId as $typeId){
			if($i == 0){
		?>
				if(esType == <?php echo $typeId; ?>){
					$('#showEsType').val('<?php echo $GLOBALS['ES_TYPE'][$typeId]; ?>');
				}

		<?php
			}else{
		?>
				else if(esType == <?php echo $typeId; ?>){
					$('#showEsType').val('<?php echo $GLOBALS['ES_TYPE'][$typeId]; ?>');
				}
		<?php
			}
			$i++;
		}
		?>
	}

	var submitUrl = '?m=EsCreate&a=editEs';
	var oEs = null;
	$(function(){
		showCategoryResult(<?php echo $categoryId; ?>);
		bindingEvent();

		ES.config({
			imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>',
			imageUploadUrl : '?m=EsCreate&a=uploadImage&ajax=1&subject=<?php echo $subjectId; ?>'
		});
		var aEs = <?php echo json_encode($aEs); ?>;
		oEs = ES.buildForm(aEs);
		$('#esForm').append(oEs);
	});
</script>