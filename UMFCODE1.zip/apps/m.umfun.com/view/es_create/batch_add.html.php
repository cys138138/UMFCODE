<?php display('es_create/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />

<div class="bundleBatchAddEs">
	
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<input type="text" value="<?php echo $GLOBALS['SUBJECT'][$subject]; ?>" disabled="disabled" />
		</div>
	</div>
	<br class="clear" />

	<div class="item">
		<div class="name">题型：</div>
		<div class="control">
			<input type="text" value="<?php echo $GLOBALS['ES_TYPE'][$esType]; ?>" disabled="disabled" />
		</div>
	</div>
	<br class="clear" />
	
	<div id="wrapInput" class="item wrapInput subject_<?php echo $subject; ?>">
		<div class="parseOption">
			<span>
				<input type="checkbox" id="spaceToLine" />
				<label for="spaceToLine">将4个连续空格以上的区域替换成下划线</label>
			</span>
			<span>
				<input type="checkbox" id="clearCnSymbol" />
				<label for="clearCnSymbol">去除 【 】 内容区间</label>
			</span>
			<span>
				<input type="checkbox" id="trimSpaceInLine" />
				<label for="trimSpaceInLine">去除每行左右空格</label>
			</span>
		</div>
		<div><textarea id="batchContent"></textarea></div>
		<div class="item" id="checkButton">
			<button type="button" class="btnOperation" onclick="parseBatchContent()">解析以上内容</button>
		</div>
	</div>
	<br class="clear" />
	
	<div id="wrapOutput" class="item wrapOutput subject_<?php echo $subject; ?>">
		<div id="esList" class="esForm"></div>
		
		<div class="controls">
			<button type="button" class="btnOperation" id="btnSave" onclick="submitEs()">保存</button>
			<button type="button" class="btnOperation" onclick="returnCheckEs()">返回</button>
		</div>
		
		<div class="category" id="selectCategory">
			<div class="result">
				<div class="name">所选目录：</div>
				<div id="categoryResult" class="control"></div>
			</div>
			<br class="clear">
			<div id="categoryTree"></div>
		</div>
	</div>
	<br class="clear" />
</div>

<div class="esEditTools">
	<button type="button" class="btnOperation" id="addUnderLine" onclick="rememberUnderline(this)">开始添加下划线</button>
<?php if($subject == 1 || $subject == 2){ ?>
	<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['char_inputer']; ?>"></script>
	<button type="button" class="btnOperation" id="btnShowCharInputer" onclick="CharInputer.show()"><?php echo $subject == 1 ? '添加元音音标' : '添加数学符号'; ?></button>
<?php } ?>
</div>
<script>
	/**
	 * 解析单选题批量内容
	 */
	function parseBatchSingleChoiceEs(batchContent){
		var aEsContentList = batchContent.split(regEsItem)
		,aEsList = [];	//最终生成的题目数据列表

		for(var i in aEsContentList){
			i = parseInt(i);
			var aEsContent = aEsContentList[i].split(markEsContentAndOption)
			,aEs = {content : '', answer : null, option : []};
			
			aEs.content = aEsContent[0].replace(regEsItemCNIndex, '');
			var esDesc = '第' + (i + 1) + '题,题目内容为 <span style="color:yellow">' + aEsContent[0].substr(0, 25) + '</span> 的题目';
			
			if(aEsContent.length < 2){
				UBox.show(esDesc + '缺少题干或选项', -1);
				return false;
			}
			if(aEsContent.length > 2){
				UBox.show(esDesc + '有多余的数据', -1);
				return false;
			}
			
			//验证答案数量
			var aAnswerContentList = aEsContent[1].split(markEsOption);
			if(aAnswerContentList.length < 2){
				UBox.show(esDesc + '选项不能少于两个', -1);
				return false;
			}
			
			//组装答案
			for(var j = 0; j < aAnswerContentList.length; j++){
				var answer = aAnswerContentList[j];
				if(regOptionAnswer.test(answer)){
					if(aEs.answer === null){
						aEs.answer = j;
					}else{
						UBox.show(esDesc + '只能有1个正确答案哦', -1);
						return false;
					}
					answer = answer.replace(regOptionAnswer, '');
				}
				aEs.option.push({content : answer.replace(regEsOptionIndex, '')});
			}
			
			aEsList.push({
				id : i + 1
				,subject_id : subjectId
				,type_id : typeId
				,es_content : aEs
			});
		}
		return aEsList;
	}
	
	/**
	 * 解析多选题批量内容
	 */
	function parseBatchMultipleChoiceEs(batchContent){
		var aEsContentList = batchContent.split(regEsItem)
		,aEsList = [];	//最终生成的题目数据列表

		for(var i in aEsContentList){
			i = parseInt(i);
			var aEsContent = aEsContentList[i].split(markEsContentAndOption)
			,aEs = {content : '', answer : [], option : []};
			
			aEs.content = aEsContent[0].replace(regEsItemCNIndex, '');
			var esDesc = '第' + (i + 1) + '题,题目内容为 <span style="color:yellow">' + aEsContent[0].substr(0, 25) + '</span> 的题目';
			
			if(aEsContent.length < 2){
				UBox.show(esDesc + '缺少题干或选项', -1);
				return false;
			}
			if(aEsContent.length > 2){
				UBox.show(esDesc + '有多余的数据', -1);
				return false;
			}
			
			//验证答案数量
			var aAnswerContentList = aEsContent[1].split(markEsOption);
			if(aAnswerContentList.length < 2){
				UBox.show(esDesc + '选项不能少于两个', -1);
				return false;
			}
			
			//组装答案
			for(var j = 0; j < aAnswerContentList.length; j++){
				var answer = aAnswerContentList[j];
				if(regOptionAnswer.test(answer)){
					aEs.answer.push(j);
					answer = answer.replace(regOptionAnswer, '');
				}
				aEs.option.push({content : answer.replace(regEsOptionIndex, '')});
			}
			
			aEsList.push({
				id : i + 1
				,subject_id : subjectId
				,type_id : typeId
				,es_content : aEs
			});
		}
		return aEsList;
	}
	
	/**
	 * 解析判断题批量内容
	 */
	function parseBatchJudgmentEs(batchContent){
		var aEsContentList = batchContent.split(regEsItem)
		,aEsList = [];	//最终生成的题目数据列表
		
		for(var i in aEsContentList){
			i = parseInt(i);
			var aEsContent = aEsContentList[i].split(markEsContentAndOption)
			,aEs = {
				content : aEsContent[0].replace(regEsItemCNIndex, '')
				,answer : null
			};
			var esDesc = '第' + (i + 1) + '题,题目内容为 <span style="color:yellow">' + aEsContent[0].substr(0, 25) + '</span> 的题目';
			
			if(aEsContent.length < 2){
				UBox.show(esDesc + '缺少题干或选项', -1);
				return false;
			}
			if(aEsContent.length > 2){
				UBox.show(esDesc + '有多余的数据', -1);
				return false;
			}
			aEsContent[1] = parseInt(aEsContent[1]);
			if(aEsContent[1] != 1 && aEsContent[1] != 0){
				UBox.show(esDesc + '答案只能为0或1', 0);
				return false;
			}
			
			aEs.answer = aEsContent[1];
			
			aEsList.push({
				id : i + 1
				,subject_id : subjectId
				,type_id : typeId
				,es_content : aEs
			});
		}
		return aEsList;
	}
	
	/**
	 * 解析填空题批量内容
	 */
	function parseBatchFillBlankEs(batchContent){
		var aEsContentList = batchContent.split(regEsItem)
		,aEsList = []	//最终生成的题目数据列表
		,markAnswer = '____';
		
		for(var i in aEsContentList){
			i = parseInt(i);
			var aEsContent = aEsContentList[i].split(markEsContentAndOption)
			,aEs = {
				content : aEsContent[0].replace(regEsItemCNIndex, '').replace(/[_]{4,}/g, ' ' + markAnswer + ' ').replace(/ {2,}_{4,}/g, ' ' + markAnswer).replace(/_{4,} {2,}/g, markAnswer + ' ')
				,answer : []
				,answer_group : []
			};
			var esDesc = '第' + (i + 1) + '题,题目内容为 <span style="color:yellow">' + aEsContent[0].substr(0, 25) + '</span> 的题目';
			
			if(aEsContent.length < 2){
				UBox.show(esDesc + '缺少题干或答案', -1);
				return false;
			}
			if(aEsContent.length > 2){
				UBox.show(esDesc + '有多余的数据', -1);
				return false;
			}
			
			var aAnswerContentList = aEsContent[1].split(markEsOption);
			//解析填空区域
			var answerNums = aEs.content.match(new RegExp('[' + markAnswer.substr(0,1) + ']{4,}', 'g'));
			if(!answerNums){
				UBox.show(esDesc + '缺少填空区域', -1);
				return false;
			}else if(aAnswerContentList.length != answerNums.length){
				UBox.show(esDesc + '填空区域个数为 <b>' + answerNums.length + '</b> 而实际答案个数为 <b>' + aAnswerContentList.length + '</b> ，两者不匹配', -1);
				return false;
			}
			
			//解析答案
			var groupCount = 0;
			for(var j in aAnswerContentList){
				var answer = aAnswerContentList[j];
				
				//解析答案组
				var regAnswerGroupIndex = /^\+(\d)\+/
				,aAnswerGroupIndex = answer.match(regAnswerGroupIndex);
				if(aAnswerGroupIndex){
					var groupIndex = parseInt(aAnswerGroupIndex[1]) - 1;
					if(aEs.answer_group[groupIndex] == undefined){
						aEs.answer_group[groupIndex] = [];
						groupCount++;
					}
					aEs.answer_group[groupIndex].push(j);
					answer = answer.replace(regAnswerGroupIndex, '');
				}
				
				aEs.answer.push(answer.split('|'));
			}
			
			//校验答案组
			for(var j in aEs.answer_group){
				if(aEs.answer_group[j].length == 1){
					UBox.show(esDesc + '的第' + (j + 1) + '个答案组的数量只有1个');
					return false;
				}
			}
			
			if(groupCount && groupCount != parseInt(j) + 1){
				UBox.show(esDesc + '答案组的标识符必须从1开始,比如+1+,然后才能有+2+哦');
				return false;
			}
			
			aEsList.push({
				id : i + 1
				,subject_id : subjectId
				,type_id : typeId
				,es_content : aEs
			});
		}
		return aEsList;
	}
	
	/**
	 * 解析批量录入题目内容
	 * @returns {undefined}
	 */
	function parseBatchContent(){
		var batchContent = $('#batchContent').val().replace(/^\n{1,}/, '').replace(/\n{1,}$/, '')	//录入内容,去掉前后空行
		,aEsList = []
		,isSpaceToLine = $('#spaceToLine')[0].checked	//是否将连续4个以上的空格替换成下四条划线
		,isClearCnSymbol = $('#clearCnSymbol')[0].checked	//是否清除中文符号【】 的内容区间
		,isTrimSpaceInLine = $('#trimSpaceInLine')[0].checked;	//是否去除每行的左右空格
		
		if(!batchContent){
			UBox.show('请输入题目数据');
			return false;
		}
		
		//初步过滤
		var aBatchContent = batchContent.split(/\n/g);
		aBatchContent = aBatchContent.map(function(item){
			if(/^\s+$/g.test(item)){
				return '';
			}else{
				if(isClearCnSymbol){
					item = item.replace(/【.*】/g, '');
				}
				if(isSpaceToLine){
					item = item.replace(/[ \u3000]{4,}/g, ' ____ ');
				}
				return isTrimSpaceInLine ? $.trim(item) : item;
			}
		});
		batchContent = aBatchContent.join('\n');
		
		//解析数据列表
		if(ES.type.isSingleChoice(typeId)){
			aEsList = parseBatchSingleChoiceEs(batchContent);
		}else if(ES.type.isMultipleChoice(typeId)){
			aEsList = parseBatchMultipleChoiceEs(batchContent);
		}else if(ES.type.isJudgment(typeId)){
			aEsList = parseBatchJudgmentEs(batchContent);
		}else if(ES.type.isFillBlank(typeId)){
			aEsList = parseBatchFillBlankEs(batchContent);
		}else{
			UBox.show('抱歉，暂不支持该题型的批量出题');
			return false;
		}
		if(!aEsList){
			return false;
		}
		
		//界面切换
		$('#wrapInput').slideUp('fast', function(){
			$('#wrapOutput').show();
		});
		
		//绘制题目表单
		var $oEsList = $('#esList');
		for(var i in aEsList){
			oEsList[i] = ES.buildForm(aEsList[i]);
			var $oWrapEs = $('<div xid="esItem" itemid="' + i + '">\n\
				<div class="item esIndex">\n\
					<div class="name">第' + (parseInt(i) + 1) + '题</div>\n\
					<div class="control">\n\
						<button class="btnOperation" type="button" onclick="preview(' + i + ', 1)">作答预览</button>\n\
						<button class="btnOperation" type="button" onclick="preview(' + i + ', 2)">结果预览</button>\n\
						<button class="btnOperation" type="button" onclick="deleteEs(' + i + ')">删除该题</button>\n\
					</div>\n\
				</div><br class="clear" />\n\
				<div xid="wrapEsContent"></div>\n\
				<br class="clear" />\n\
			</div>').appendTo($oEsList);
			$oWrapEs.find('div[xid="wrapEsContent"]').append(oEsList[i]);
		}
	}
	
	function deleteEs(esIndex){
		UBox.confirm('确定要删除 第' + (esIndex + 1) + '题 吗？', function(){			
			delete oEsList[esIndex];
			$('#esList div[xid="esItem"][itemid="' + esIndex + '"]').slideUp('fast', function(){
				$(this).remove();
			});
		});
	}
	
	function preview(esIndex, type){
		var aEs = oEsList[esIndex].buildEsData()
		,oPreview = null;
		if(type == 1){
			oPreview = ES.buildQuestion(aEs);
		}else{
			oPreview = ES.buildDetail(aEs);
		}
		
		popEasyDialog({
			title : '题目预览',
			width : 725,
			height : 500,
			content : '<div id="wrapPreview" class="wrapEsPreview es_content"></div>',
			confirmCallBack : $.noop
		});
		oPreview.appendTo('#wrapPreview');
	}
	
	function rememberUnderline(obj){
		if(rememberAddUnderline == false){
			$(obj).text('清除添加下划线状态');
		}else{
			$(obj).text('记住添加下划线状态');
		}
		rememberAddUnderline = !rememberAddUnderline;
	}

	function addUnderLine(){
		if(rememberAddUnderline){
			if(!lastActiveObject || lastActiveObject.selectionStart == lastActiveObject.selectionEnd){
				return false;
			}
			var obj = lastActiveObject;
			var selStr = obj.value.slice(obj.selectionStart, obj.selectionEnd),
			lStr = obj.value.slice(0, obj.selectionStart),
			rStr = obj.value.slice(obj.selectionEnd, obj.value.length);
			selStr = '<u>' + selStr + '</u>';
			obj.value = lStr + selStr + rStr;
			return obj.value;
		}
	}

	function addLastIdToLeftIframe(lastId){
		var oLeftBody = $(parent.leftFrame.window.document.body);
		var lastIdDivHtml = '';
		var oDate = new Date();
		var hours = oDate.getHours();
		var minutes = oDate.getMinutes();
		var seconds = oDate.getSeconds();
		var addTime = hours + ':' + minutes + ':' + seconds;
		if(oLeftBody.find('#esIdDiv').length == 0){
			lastIdDivHtml += '<a class="btnClearIds" onclick="$(\'#esIdDiv\').empty()" target="_self" href="##">清除ID记录</a>\n\
			<style type="text/css">\n\
				.btnClearIds{display:block; font-weight:bold; margin:5px 0; text-align:center;}\n\
				.esIdDiv{overflow:hidden;height:300px;}\n\
				.esIdDiv p{text-align:center; }\n\
				.esIdDiv p a{color:#FFF; font-size: 14px; margin: 10px 0;}\n\
			</style>\n\
			<div id="esIdDiv" class="esIdDiv">\n\
				<p><a href="?m=EsCreate&a=showDetail&esId=' + lastId + '"><span style="color:#06C;">' + addTime + '</span>&nbsp;&nbsp;' + lastId + '</a></p>\n\
			</div>';
			oLeftBody.append(lastIdDivHtml);
		}else{
			lastIdDivHtml += '<p><a href="?m=EsCreate&a=showDetail&esId=' + lastId + '"><span style="color:#06C;">' + addTime + '</span>&nbsp;&nbsp;' + lastId + '</a></p>';
			oLeftBody.find('#esIdDiv').prepend(lastIdDivHtml);
		}
	}
	
	function getCategoryId(){
		categoryId = oDirTree.getSelected();
		if(!oDirTree.isNoChild(categoryId)){
			UBox.show('请选择一个最终目录');
			if(categoryId){
				categoryId = 0;
			}
			return;
		}
		var name = oDirTree.getName(categoryId);
		$('#categoryResult').text(name);
		$.cookie('lastCatagory' + subjectId, categoryId , {expires: 3600000 * 24 * 7});
	}

	function returnCheckEs(){
		$('#wrapOutput').slideUp('fast', function(){
			$('#wrapInput').show();
			$('#esList').empty();
		});
	}
	
	/**
	 * 提交题目
	 */
	function submitEs(){
		if(categoryId == 0){
			UBox.show('请选择题目所属目录');
			return false;
		}
		
		var aEsList = [];
		for(var i in oEsList){
			i = parseInt(i);
			if(!oEsList[i].validate()){
				alert('错误发生在第' + (i + 1) + '题');
				return false;
			}
			aEsList.push(oEsList[i].buildEsData().es_content);
		}
		
		var oBtnSave = $('#btnSave');
		$.ajax({
			url : submitUrl,
			type : 'post',
			data : {
				subject_id : subjectId
				,type_id : typeId
				,category_id : categoryId
				,es_list : aEsList
			},
			dataType : 'json',
			beforeSend : function(){
				oBtnSave.attr('onclick', '').css({'background-color':'#999'});
			},
			complete : function(){
				oBtnSave.attr('onclick', 'submitEs()').css({'background-color':'#333'});
			},
			success : function(aResult){
				if(aResult.status == 1){
					for(var i = aResult.data.start; i <= aResult.data.end; i++){
						addLastIdToLeftIframe(i);
					}
					UBox.show(aResult.msg, aResult.status, aResult.data.url);
				}else if(aResult.status == -1){
					UBox.confirm(aResult.msg, function(){
						submitUrl += '&ignore_same_es=1';
						submitEs();
					});
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error : function(){
				UBox.show('网络可能有点慢');
			}
		});
	}
	
	var subjectId = <?php echo $subject; ?>
	,typeId = <?php echo $esType; ?>
	,categoryId = 0
	,oDirTree = null
	,regOptionAnswer = /^##{1}[\s]{0,1}/
	,regEsItem = /[\n]{3,}/g
	,markEsContentAndOption = '\n\n'
	,regEsItemCNIndex = /^(([A-Z]\.)|(\d{1,}\.)|(\(\d{1,}\)|(（\d{1,}）))|([一二三四五六七八九十]{1}、)|(\d{1,}、)|(第\d{1,}题.)|(第\d{1,}题、)|(第\d{1,}题))/g
	,markEsOption = '\n'
	,regEsOptionIndex = /^(([A-Z]\.)|([A-Z]、)|(（\d{1,}）))/g
	,oEsList = []
	,lastActiveObject = null
	,rememberAddUnderline = false
	,submitUrl = '?m=EsCreate&a=batchAdd';
	
	if(subjectId == 2){
		regEsItemCNIndex = /^(([A-Z]\.)|(\(\d{1,}\)|(（\d{1,}）))|([一二三四五六七八九十]{1}、)|(\d{1,}、)|(第\d{1,}题.)|(第\d{1,}题、)|(第\d{1,}题))/g;
	}
	
	$(function(){
		if(ES.type.isComplex(typeId)){
			UBox.show('抱歉，暂未支持阅读理解/完型填空的批量出题哦！', -1, '', 99999999);
			return false;
		}
		
		//配置题目插件
		ES.config({
			imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>',
			imageUploadUrl : 'http://<?php echo APP_MANAGE; ?>/?m=EsCreate&a=uploadImage&ajax=1&subject=<?php echo intval(get('subject', 1)); ?>',
			uploadButtonImage : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['button_image']; ?>',
			uploadSwf : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['swf']; ?>'
		});
		
		//上一个对象监听以及添加下划线功能绑定
		$('#wrapInput,#wrapOutput').delegate('textarea,:text', 'focus', function(){
			lastActiveObject = this;			
		}).delegate('textarea,:text', 'mouseup', function(){
			addUnderLine();
		});
		
		//初始化符号插件
		if($.inArray(subjectId, [1,2]) != -1){
			CharInputer.init({
				subject : subjectId
				,closeOnMouseout : false
			});
		}
		
		//显示目录树
		(function(){
			oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
			categoryId = $.cookie('lastCatagory' + subjectId);
			oDirTree.add(0, -1, '题目目录');
			$(<?php echo json_encode($aCategoryList); ?>).each(function(){
				oDirTree.add(this.id, this.parent_id, this.name, 'javascript:getCategoryId();', this.name);
			});
			$('#categoryTree').html(oDirTree.toString());
			if(categoryId){
				oDirTree.openTo(categoryId , true);
				getCategoryId();
			}
		})();
	});
</script>