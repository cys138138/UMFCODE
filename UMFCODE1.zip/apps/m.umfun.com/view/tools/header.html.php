<!DOCTYPE html>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link  href="<?php echo $GLOBALS['RESOURCE']['style_manage']; ?>" type="text/css" rel="stylesheet">
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery_cookie']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<?php display('tools/style.css.php'); ?>
</head>
<body>
<div class="mainOut">