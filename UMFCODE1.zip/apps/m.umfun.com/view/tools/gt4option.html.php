<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Document</title>
<link  href="<?php echo $GLOBALS['RESOURCE']['style_manage']; ?>" type="text/css" rel="stylesheet">
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<style>
.id{font-size:18px;}
</style>
</head>
<body>
<p><?php $g79 && print('7-9年级 '); ?>共 <?php echo $allCount; ?> 条题目是小于4个选项</p>
<ul class="es_content" id="xx"></ul>
<script>
var DEFAULT_IMG = '<?php echo $GLOBALS['RESOURCE']['image_error']; ?>';
	
ES.config({
	imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'
});

$(function(){
	var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
	var aEsListCategoryGroup = <?php echo json_encode($aEsCategoryGroupList); ?>;
	
	var $ul = $('#xx');
	for(var i in aEsListCategoryGroup){
		
		$ul.append('<h2>目录:' + aCategoryList[i].name + '</h2>');
		for(var j in aEsListCategoryGroup[i]){
			var aEs = aEsListCategoryGroup[i][j];
			if(aEs.es_content.option.length > 3){
				continue;
			}
			var $esItem = $('<div>\
				<p class="id">id : ' + aEs.id + ' <a href="javascript:;" onclick="$(this).parent().parent().slideUp()">处理完毕</a></p>\
				<div xid="esContent"></div>\
				<hr>\
			</div>').appendTo($ul);
			ES.buildDetail(aEs).appendTo($esItem.find('div[xid="esContent"]'));
		}
	}
});
</script>
</body>
</html>