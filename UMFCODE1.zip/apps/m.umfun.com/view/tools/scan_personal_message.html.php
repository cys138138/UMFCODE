<?php display('tools/header.html.php'); ?>
<h1>与我相关动态信息扫描检测结果</h1>
<h3 style="color:#f00;">注意此删除只针对personalMessage的表删除数据</h3>
<h2>根据用户ID扫描：<input type="text" name="user" id="user">&nbsp;&nbsp;&nbsp;<button onclick="scanUser();">用户ID扫描</button>&nbsp;&nbsp;&nbsp;<button onclick="scan();">直接扫描</button>&nbsp;&nbsp;&nbsp;<a href="?m=Tools&a=scanPersonalMessageError&pageSize=0">全盘扫描</a></h2>
<form action="?m=Tools&a=deletePersonalMessageError" method="post" onsubmit="return checkForm();">
	<input type="submit" value="删除选中选项" name="sub" />
	<?php if($aResult){?>
	<table border="1" style="margin:20px 0 0 20px">
		<tr height="30px">
			<th>全选<br/><input style="margin-left:10px;"  name="checkbox[]" type="checkbox" id="check"></th>
			<th>动态ID</th>
			<th>TYPE</th>
			<th>数据表名</th>
			<th>数据ID</th>
			<th>错误情况</th>
			<th>操作</th>
		</tr>
		<?php foreach($aResult as $aErrorInfo){?>
		<tr height="25px">
			<td width="5%"><input style="margin-left:10px;" type="checkbox" name="checkbox[]" value="<?php echo $aErrorInfo['id'];?>"></td>
			<td width="5%"><?php echo $aErrorInfo['id'];?></td>
			<td width="25%"><?php echo $aErrorInfo['type'];?></td>
			<td width="25%"><?php echo $aErrorInfo['table_name'];?></td>
			<td width="10%"><?php echo $aErrorInfo['data_id'];?></td>
			<td width="25%"><?php echo $aErrorInfo['error_info'];?></td>
			<td width="5%"><a href="?m=Tools&a=deletePersonalMessageError&id=<?php echo $aErrorInfo['id'];?>">删除</a></td>
		</tr>
		<?php }?>
	</table>
	<?php }else{?>
		<h2 style="color:#f00;">亲没有错误数据！你猪脑袋是被门夹了吗？不知道我跑一次服务器很累的吗？。。。。。</h4>
	<?php }?>
</form>
<?php display('tools/footer.html.php'); ?>
<script type="text/javascript">
	function scanUser(){
		var user_id = $('#user').val();
		location.href = '?m=Tools&a=scanPersonalMessageError&user=' + user_id;	
	}
	
	function scan(){
		location.href = '?m=Tools&a=scanPersonalMessageError';	
	}
	
	function checkForm(){
		if(confirm('确定要删除数据吗？注意删除后不能恢复！！！')){
			return true;
		}else{
			return false;
		}
	}

	$('#check').click(function(){
		var check = this.checked;
		if(check){
			check = 'checked';
		}
		$("input[name='checkbox[]']").each(
			function(){
				this.checked = check;
			}
		);
	});
	
	$(function(){
		$('#check').checked = false;
		$("input[name='checkbox[]']").each(
			function(){
				this.checked = false;
			}
		);
	});

</script>