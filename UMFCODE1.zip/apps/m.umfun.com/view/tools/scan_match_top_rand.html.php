<?php display('tools/header.html.php'); ?>
<h1>比赛得奖用户扫描检测结果</h1>
<h2>根据比赛ID扫描：<input type="text" name="user" id="user">&nbsp;&nbsp;&nbsp;<button onclick="scanMatch();">比赛ID扫描</button>&nbsp;&nbsp;&nbsp;<a href="?m=Tools&a=scanMatchTopAndRand&allScan=1">全盘扫描</a>&nbsp;&nbsp;&nbsp;<a href="?m=Tools&a=scanMatchTopAndRand&allScan=1&update=1">全部更新</a></h2>
	<?php if($aResult){?>
	<table border="1" style="margin:20px 0 0 20px">
		<tr height="30px">
			<th>比赛ID</th>
			<th>用户Id</th>
			<th>用户名</th>
			<th>比赛错误信息</th>
			<th>操作</th>
		</tr>
		<?php foreach($aResult as $aErrorInfo){?>
		<tr height="25px">
			<td width="5%"><?php echo $aErrorInfo['id'];?></td>
			<td width="25%"><?php echo $aErrorInfo['user_id'];?></td>
			<td width="25%"><?php echo $aErrorInfo['user_name'];?></td>
			<td width="25%"><?php echo $aErrorInfo['error_info'];?></td>
			<td width="5%"><a href="?m=Tools&a=scanMatchTopAndRand&update=1&matchId=<?php echo $aErrorInfo['id'];?>&userId=<?php echo $aErrorInfo['user_id']?>">更新</a></td>
		</tr>
		<?php }?>
	</table>
	<?php }else{?>
		<h2 style="color:#f00;">亲没有错误数据！你猪脑袋是被门夹了吗？不知道我跑一次服务器很累的吗？。。。。。</h4>
	<?php }?>
<?php display('tools/footer.html.php'); ?>
<script type="text/javascript">
	function scanMatch(){
		var match_id = $('#user').val();
		location.href = '?m=Tools&a=scanMatchTopAndRand&matchId=' + match_id;	
	}

</script>