<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>

	<style>
		#inputText{padding: 5px;}
		.input_text{min-width : 300px;border:1px solid #1e0000; display: inline-block;padding:5px; }
		.button{border: none; display: inline-block; }
		.box{border:1px solid #ccc; padding: 5px; margin:32px 5px 0 5px;}
		
		
		.clera{clear:both;}

		.row{line-height: 30px; margin-bottom: 10px; }
		.row.hr{border-bottom:1px solid #999;border-top:1px solid #999; margin-top:20px;padding:3px 0 10px 0; background-color:#F0F0F0;}
		.row > div{border-bottom: 1px dashed #999;}
		.tab{position: absolute;padding-left: 20px;}
		.tab ul {margin: 0;padding: 5px;}
		.tab ul li{border-top: 1px solid #999;border-left: 1px solid #999;border-right: 1px solid #999; float: left; min-width:100px;  padding: 5px; margin: 0 10px 0 0; list-style-type:none;background: #FFF;}
		.tab ul li:hover{background: #DDD ;cursor:pointer;}
		.tab ul li i{font-style: normal;color: #387AF0;}
		#esList_1{display: block;}
		.subject{height: 30px;}
	</style>

	<div id="inputText">
		<button id="btnChangeCaryte" class="button">选择类目</button>
		科目：<select onchange="changeSubject(this);" class="subject">
			<option value="1">语文</option>
			<option value="2">数学</option>
			<option value="3">英语</option>
			<option value="4">其他</option>
		</select>
		
		<span id="text" class="input_text">　</span>
		<span id="countCaryte"></span>  
	</div>

	<div class="tab" id="tab">
		<ul>
			<?php
			 if(isset($aSameEsCount)){
				$countEsType = count($aSameEsCount);
				for($i = 1; $i < $countEsType; $i++){
					echo '<li data-id="' . $i . '">【分类' . $i . '】<i>' . $aSameEsCount[$i] . '</i></li>';
				}
			 }else{
				 foreach($GLOBALS['ES_TYPE'] as $i => $name){
					echo '<li data-id="' . $i . '">【' . $name . '】<i>0</i></li>';
					if($i == 6){
						break;
					}
				}
				
			 }

			?>
		</ul>
	</div>
	
	<div class="box clera" id="esList">
		<?php if(isset($aSameEsHtmlList)){
				$countEsHtmlList = count($aSameEsHtmlList);
				for($i = 1; $i < $countEsHtmlList; $i++){
					echo '<div id="esList_' . $i . '"><ul>'.$aSameEsHtmlList[$i].'</ul></div>';
				}
			 }else{
				for($i = 1; $i < 6; $i++){
					echo '<div id="esList_' . $i . '"><ul></ul></div>';
				}
			}
			 ?>
		<?php ?>
		
	</div>

	
<script>
	var categoryId = 1,
		subjectId = <?php echo $subjectId > 0 ? $subjectId : 1; ?>,
		oSubject = <?php echo json_encode($GLOBALS['SUBJECT']); ?>;
	$(function(){
		$('#btnChangeCaryte').on('click', function(){
			showCategroy();
		});
		ES.config({imageBaseUrl : 'http://<?php echo APP_MANAGE; ?>/'});

		$('#tab li').click(function(){
			$('#esList_1,#esList_2,#esList_3,#esList_4').hide();
			$('#esList_' + $(this).data('id')).show();
		});

		$('.row:odd').addClass('hr');
		

	});
	
	function changeSubject(obj){
		subjectId = obj.value;
		var stare = {title : $('title').html(), url : '<?php echo $baseUrl;?>'}
		history.pushState(stare, '', stare.url + '&subject=' + subjectId);
	}
	
	function showCategroy(){
		var option = {
			title :  oSubject[subjectId] + '目录',
			width : 520,
			content : '<iframe name="categroy" width="520" height="480"  frameborder="0" src="<?php echo '/?m=EsCreate&a=showCategroyTree&callBack=1&subject_id='; ?>' + subjectId + '" ></iframe>',
			confirmCallBack : addOneCategroy,
			cancleCallBack : function(){
				easyDialog.close();
			}
		};
		popEasyDialog(option);
	}
	
	function addOneCategroy(){
		var aCategoryInfo = {};
		aCategoryInfo = categroy.window.getCategoryInfo();
		if(aCategoryInfo.hasChild){
			UBox.show('请勿添加目录！', -1);
			return;
		}
		clearHtml();
		callBack(aCategoryInfo.id, aCategoryInfo.name);
	}

	function clearHtml(){
		$('#countCaryte').html('');
		for(var i = 1; i < 6; i++){
			$('#esList_' + i + ' ul').html('');
			$('#tab li[data-id="' + i +'"]').find('i').text(0);
		}
	}

	function showDetailEs(id){
		$.ajax({
			url : '/m=tools&a=getEsinfo',
			data : {
				id : id
			},
			success : function(aResult){
				if(aResult.status == 1){
					var oEsDom = ES.buildDetail(aResult.data);
					popEasyDialog({
						title : '完整题目',
						width : 720,
						height : 400,
						content : '<div id="wrapPreview" class="wrapEsPreview es_content" style="height:400px; overflow-y:scroll;"></div>',
						confirmCallBack : $.noop
					});
					oEsDom.appendTo('#wrapPreview');
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			}
		});
	}
	
	function callBack(categoryId, categoryName){
		var categoryIdInt = parseInt(categoryId),
			casdHtml = '',
			countEs = 0,
			countTypeEs = 0;
		$.ajax({
			url : '/m=Tools&a=showAllSameEs',
			data : {
				categoryId : categoryIdInt,
				getData : 1
			},
			beforeSend : function(){
				$('#btnChangeCaryte').html('<img width="20" src="<?php echo SYSTEM_RESOURCE_URL;?>/view2/images/competition/loading.gif">加载中...');
			},
			complete : function(){
				$('#btnChangeCaryte').html('选择类目');
			},
			success : function(aResult){
				
				if(aResult.status == 1){
					var aEs = aResult.data;
					for(var i in aEs){
						for(var j in aEs[i]){
							casdHtml += '<li class="row">';
							for(var k in aEs[i][j]){
								casdHtml += '<div onclick="showDetailEs(' + aEs[i][j][k].id + ');">【ID : ' + aEs[i][j][k].id + '】 <span>' + aEs[i][j][k].content_text + '</span></div>';
								countEs++;
								
							}
							casdHtml += '</li>';
							countTypeEs++;
							$(casdHtml).appendTo('#esList_' + i + ' ul');
							casdHtml = '';
						}
						
						$('#tab li[data-id="' + i +'"]').find('i').text(countTypeEs);
					}
					$('#esList_1').show();
					$('#countCaryte').html('本次类目题目总数：' + countEs);
					$('.row:odd').addClass('hr');
					var stare = {title : $('title').html(), url : '<?php echo $baseUrl;?>'}
					history.pushState(stare, '', stare.url + '&categoryId=' + categoryId);
					
				}
			}
		});
		
		$('#text').text('【' + categoryId + '】' + categoryName);
	}
	
</script>