<?php displayHeader(); ?>
<script src="<?php echo $GLOBALS['RESOURCE']['script_log']; ?>"></script>
<script>
var oLog = new Log({
	name : '后门日志'
});
</script>
<style>
	.mainOut{padding:0 15px;}
	.block{margin-bottom:20px; padding:7px; border:1px solid #000;}
	.block.student_test p{margin-bottom:7px;}
</style>
<div class="mainOut">
	<center>
		<h1>后门工具</h1>
		<a href="http://<?php echo APP_HOME; ?>" target="_blank">站点首页</a>
		<a href="##" onclick="oLog.show(); return false;">查看日志</a>
	</center>
	<div class="block dedeteData">
		<h2>删除数据</h2>
		<div>
			<button type="button" onclick="deleteUserById(1)">删除指定ID的学生</button>
			<button type="button" onclick="deleteUserById(2)">删除指定ID的家长</button>
			<button type="button" onclick="deleteTitleById()">删除指定ID的题目</button>
			<button type="button" onclick="deleteCache()">清除缓存</button>
			<button type="button" onclick="location.href='/?m=Tools&a=scanPersonalMessageError'">删除废弃的好友动态</button>
			<!--<button type="button" onclick="deleteUserById(3)" disabled="disabled">删除指定ID的教师</button>-->
		</div>

		<script>
			function deleteUserById(type){
				var userId = parseInt(prompt('请输入要删除的用户ID'));
				if(isNaN(userId)){
					alert('请输入用户ID');
					return;
				}

				var url = [
					'/?m=Tools&a=deleteAccount'
					,'/?m=Tools&a=deleteParent'
					,'/?m=Tools&a=deleteTeacher'
				][type - 1];

				ajax({
					url : url
					,data : {id : userId}
					,success : function(aResult){
						alert(aResult.msg);
					}
				});
			}

			function deleteTitleById(){
				var titleId = parseInt(prompt('请输入要删除的题目ID'));
				if(isNaN(titleId)){
					alert('请输入题目ID');
					return;
				}
				ajax({
					url : '/?m=Tools&a=deleteEs'
					,data : {id : titleId}
					,success : function(aResult){
						alert(aResult.msg);
					}
				});
			}

			function deleteCache() {
				var tableName = prompt('请输入要清除缓存的表名');
				if (tableName.length == 0){
					return;
				}
				else if (/[^\d\w_]+/.test(tableName)){
					alert("错误的表名");
				}
				else {
					var url = "/?m=Tools&a=flushCache";
					ajax({
						url : url,
						data: {table : tableName},
						success : function(aResult){
							alert(aResult.msg);
						}
					});

				}
			}
		</script>
	</div>

	<div class="block tidy">
		<h2>数据调整</h2>
		<div>
			<button type="button" onclick="setStudentGold()">为指定用户设置金币数量</button>
		</div>

		<script>
			function setStudentGold(){
				var userId = parseInt(prompt('请输入用户ID'));
				if(isNaN(userId)){
					alert('请输入用户ID');
					return;
				}

				var gold = parseInt(prompt('请输入要修改的金币数量'));
				if(isNaN(gold)){
					alert('请输入要修改的金币数量');
					return;
				}

				ajax({
					url : '/?m=Tools&a=setGold&uid=' + userId + '&gold=' + gold
					,type : 'get'
					,success : function(aResult){
						alert(aResult.msg);
					}
				});
			}
		</script>
	</div>

	<div class="block student_test">
		<h2>学生用户操作</h2>
		<div class="wrapContent">
			<p>
				<input type="text" id="studentId" value="<?php echo Cookie::getDecrypt('userId'); ?>"> 对该学生进行
				<select id="userOperatingType">
					<option value="1">和教育用户解绑</option>
					<option value="2">绑定和教育用户</option>
					<option value="3">QQ用户解绑</option>
					<option value="4">绑定QQ用户</option>
					<option value="5">登陆</option>
					<option value="6">查询登陆状态信息</option>
				</select>
				<button type="button" onclick="operatingUser()">执行</button>
			</p>
		</div>

		<script>
			function operatingUser(){
				var studentId = parseInt($('#studentId').val());
				if(isNaN(studentId)){
					alert('请输入学生ID');
					return;
				}

				var type = parseInt($('#userOperatingType').val());
				switch(type){
					case 1:
						unbindXxtUserId(studentId);
						break;

					case 2:
						var xxtUserId = prompt('请输入和教育学生ID');
						if(isNaN(xxtUserId)){
							alert('无效的和教育用户ID');
							return;
						}
						revertXxtUserBind(studentId, xxtUserId);
						break;

					case 3:
						unbindQQUserId(studentId);
						break;

					case 4:
						var openId = $.trim(prompt('请输入QQ的openid'));
						if(!openId.length){
							alert('无效的和教育学生ID');
							return;
						}
						revertQQUserBind(studentId, openId);
						break;

					case 5:
						loginStudent(studentId);
						break;

					case 6:
						checkStudentLoginInfo(studentId);
						break;

					default:
						alert('请选择操作类型');
						return;
				}
			}

			function unbindXxtUserId(studentId){
				ajax({
					url : '/?m=Tools&a=unbindThirdPartyUser'
					,data : {
						type : 2
						,user_id : studentId
					}
					,success : function(aResult){
						alert(aResult.msg + '\n点击上面的"查看日志"可以在日志记录中看到解绑的和教育学生ID');
						if(aResult.status != 1){
							return;
						}
						oLog.add(aResult.data.xxt_id, studentId + '解绑的和教育ID');
					}
				});
			}

			function revertXxtUserBind(studentId, xxtUserId){
				ajax({
					url : '/?m=Tools&a=bindThirdPartyUser'
					,data : {
						type : 2
						,user_id : studentId
						,xxt_user_id : xxtUserId
					}
					,success : function(aResult){
						alert(aResult.msg);
						if(aResult.status != 1){
							return;
						}
					}
				});
			}
			function unbindQQUserId(studentId){
				ajax({
					url : '/?m=Tools&a=unbindThirdPartyUser'
					,data : {
						type : 1
						,user_id : studentId
					}
					,success : function(aResult){
						alert(aResult.msg + '\n点击上面的"查看日志"可以在日志记录中看到解绑的QQ openid');
						if(aResult.status != 1){
							return;
						}
						oLog.add(aResult.data.qq_open_id, studentId + '解绑的QQ openid');
					}
				});
			}

			function revertQQUserBind(studentId, openId){
				ajax({
					url : '/?m=Tools&a=bindThirdPartyUser'
					,data : {
						type : 1
						,user_id : studentId
						,qq_open_id : openId
					}
					,success : function(aResult){
						alert(aResult.msg);
						if(aResult.status != 1){
							return;
						}
					}
				});
			}

			function loginStudent(studentId){
				ajax({
					url : '/?m=Tools&a=loginUser'
					,data : {
						type : 1
						,user_id : studentId
					}
					,success : function(aResult){
						alert(aResult.msg);
						if(aResult.status != 1){
							return;
						}
					}
				});
			}

			function checkStudentLoginInfo(studentId){
				ajax({
					url : '/?m=Tools&a=checkStudentLoginInfo'
					,data : {id : studentId}
					,success : function(aResult){
						if(aResult.status != 1){
							alert(aResult.msg);
							return;
						}
						oLog.add(aResult.data, studentId + ' 的登陆信息');
						alert('已经添加到日志面板,请点击 查看日志');
					}
				});
			}
		</script>
	</div>

	<div class="block parent_test">
		<h2>家长操作</h2>
		<div class="wrapContent">
			<p>
				<input type="text" id="parentId"> 对该家长进行
				<select id="parentOperatingType">
					<option value="1">登陆</option>
					<option value="2">注销登陆</option>
				</select>
				<button type="button" onclick="operatingParent()">执行</button>
			</p>
		</div>

		<script type="text/javascript">
			function operatingParent(){
				var parentId = parseInt($('#parentId').val());
				if(isNaN(parentId)){
					alert('请输入家长ID');
					return;
				}

				var type = parseInt($('#parentOperatingType').val());
				switch(type){
					case 1:
						loginParent(parentId);
						break;

					case 2:
						logoutParent(parentId);
						break;

					default:
						alert('请选择操作');
				}
			}

			function loginParent(parentId){
				ajax({
					url : '/?m=Tools&a=loginUser'
					,data : {
						type : 2
						,user_id : parentId
					}
					,success : function(aResult){
						alert(aResult.msg);
						if(aResult.status != 1){
							return;
						}
					}
				});
			}

			function logoutParent(parentId){
				ajax({
					url : '/?m=Tools&a=logoutUser'
					,data : {
						type : 2
						,user_id : parentId
					}
					,success : function(aResult){
						alert(aResult.msg);
						if(aResult.status != 1){
							return;
						}
					}
				});
			}
		</script>
	</div>

	<div class="block another">
		<h2>其它</h2>
		<div class="wrapContent">
			<button type="button" onclick="decryptEsId()">解密题目ID</button>
			<button type="button" onclick="location.href='http://tools.umfun.dev?m=DbTools&a=show'">本地与线上数据库对比</button>
			<button type="button" onclick="location.href='/?m=Tools&a=showChoiceEsForGt4Options'">找出4个选项以下的选择题</button>
			<button type="button" onclick="showLogsList()">下载日志</button>
		</div>

		<script>
			function decryptEsId(){
				var encryptId = $.trim(prompt('请输入加密的题目ID'));
				if(encryptId.length == 0){
					alert('不输入就当你不用了哦');
					return;
				}

				ajax({
					url : '/?m=Tools&a=decryptEsId'
					,data : {encrypt_id : encryptId}
					,success : function(aResult){
						alert(aResult.msg);
					}
				});
			}

			function showLogsList(){
				ajax({
					url : '/?m=Tools&a=getLogsList'
					,success : function(aResult){
						if(aResult.status != 1){
							UBox.show(aResult.msg, aResult.status);
							return;
						}

						var message = '', logsCount = 0;
						for(var i in aResult.data){
							var aLogItem = aResult.data[i];
							message += aLogItem.name + ': ' + aLogItem.log_count + '个';
							logsCount += parseInt(aLogItem.log_count);
							if(i % 2 == 0){
								message += aLogItem.name.substr(-3) == 'com' ? '\t\t' : '\t\t\t';
							}else{
								message += '\n';
							}
						}
						message += '\n共' + logsCount + '个日志文件,点击确定开始下载';

						var isDownload = confirm(message);
						isDownload && downloadLogs();
					}
				});
			}

			function downloadLogs(){
				$('<form action="/?m=Tools&a=downloadLogFiles" method="POST"></form>').appendTo('body').submit().remove();
			}
		</script>
	</div>
</div>
<?php displayFooter();