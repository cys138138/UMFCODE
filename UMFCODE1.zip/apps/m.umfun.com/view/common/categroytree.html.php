<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>目录树</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery_cookie']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
</head>
<body>
	<script type="text/javascript">
		var aCategoryList = <?php echo json_encode($aCategoryList); ?>,
			callBackText = '<?php echo get('callBackText') ? get('callBackText') : '#categoryResult';?>',
			callBackCategoryId = '<?php echo get('callBackCategoryId') ? get('callBackCategoryId') : '#category_id';?>',
			oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
			oDirTree.add(0, -1, '<?php echo $GLOBALS['SUBJECT'][$subjectId]; ?>目录');

		$(aCategoryList).each(function(){
			oDirTree.add(this.id, this.parent_id, this.name, 'javascript:<?php echo get('callBack') ? 'void(0);' : 'getCategoryId()'; ?>', this.name);
		});
		document.write(oDirTree);

		function getCategoryInfo(){
			var categoryId = oDirTree.getSelected(),
				categoryChild = false,
				categoryName = '';
			if(!oDirTree.isNoChild(categoryId)){
				categoryChild = true;
			}
			$(aCategoryList).each(function(){
				if(this.id == categoryId){
					categoryName = this.name;
					return;
				}
			});
			$.cookie('lastCatagory<?php echo $subjectId; ?>', categoryId , {expires: 3600000 * 24 * 7});
			return {id : categoryId, name : categoryName, hasChild : categoryChild}
		}

		function showCategoryResult(categoryId){
			var categoryName = '';
			$(aCategoryList).each(function(){
				if(this.id == categoryId){
					categoryName = this.name;
					return;
				}
			});
			$(callBackText, window.parent.document).text(categoryName);
		}
		
		function getCategoryId(){
			var categoryId = oDirTree.getSelected();
			if(!oDirTree.isNoChild(categoryId)){
				UBox.show('请选择一个最终目录', -1);
				if($(callBackCategoryId, window.parent.document).val()){
					$(callBackCategoryId, window.parent.document).val(0);
					showCategoryResult(0);
				}
				return;
			}
			$(callBackCategoryId, window.parent.document).val(categoryId);
			$.cookie('lastCatagory<?php echo $subjectId; ?>', categoryId , {expires: 3600000 * 24 * 7});
			showCategoryResult(categoryId);
		}
		
		var lastCategory = $.cookie('lastCatagory<?php echo $subjectId; ?>');
		if(lastCategory > 0){
			oDirTree.openTo(lastCategory, true);
			$(callBackCategoryId, window.parent.document).val(lastCategory);
			showCategoryResult(lastCategory)
		}
	</script>
</body>
</html>