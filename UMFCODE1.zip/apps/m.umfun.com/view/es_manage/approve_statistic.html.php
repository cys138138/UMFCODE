<?php display('es_manage/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<div class="module _condition">
	<style>
		._condition .list .row .c1{width:100px;}
		._condition .list .row .c2{width:100px;}
		._condition .item ._selectTime a{color:#000;}
		._condition .item .control a{margin-left:8px;}
		._condition .item .name{margin-left:10px; width:50px;}
		
	</style>
	<div class="title">旧题审核统计</div>
	<div class="item">
		<div class="name">时间：</div>
		<div class="control _selectTime">
			<a  onclick="setSearchTime(1);">今天</a>
			<a  onclick="setSearchTime(3);">最近3天</a>
			<a  onclick="setSearchTime(7);">最近7天</a>
			<a  onclick="setSearchTime(30);">最近30天</a>
			<a  onclick="setSearchTime(0);">全部</a>
			
		</div>
		<div class="br"></div>
		
		<div class="name">自定义：</div>
		<div class="control _selectTime">
			<input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />&nbsp;-&nbsp;<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" />
		</div>
		<div class="br"></div>
		<div class="name"></div>
		<div class="control">
			<a onclick="statisticSearch();" class="button">查询</a>
		</div>
	</div>
	<div class="clear"></div>
	
	
	
	<div class="list">
		<div class="row header">
			<div class="c1">科目</div>
			<div class="c2">数量</div>
		</div>
		<?php foreach($aStatisticCountsList as $aStatisticCounts){ ?>
		<div class="row">
			<div class="c1"><?php echo $GLOBALS['SUBJECT'][$aStatisticCounts['subject_id']];?></div>
			<div class="c2"><?php echo $aStatisticCounts['nums'];?></div>
		</div>
		<?php } ?>
	</div>
	<div class="clear"></div>

</div>
<script type="text/javascript">
	window.endTime = "'end_time'";
	
	function setSearchTime(type){
		var dateStr = '<?php echo date('Y-m-d 00:00:00'); ?>';
		var dateForm = new Date();
		var startTime = dateForm.getTime();
		if(type == 1){
			$('#start_time').val(dateStr);
		}else if(type == 0){
			$('#start_time').val('2013:01:01 00:00:00');
		}else{
			startTime = startTime - type * 24 * 60 * 60 * 1000;
			$('#start_time').val(timeToStr(startTime));
		}
		$('#end_time').val('<?php echo date('Y-m-d H:i:s'); ?>');
	}

	//将秒数转换成  年-月-日 时:分:秒  字符串
	function timeToStr(time){
		var s, y, m, d, h, i, e;
		s = new Date(time)
		y =s.getFullYear();
		m =s.getMonth() + 1;
		d =s.getDate();
		h =s.getHours();
		i =s.getMinutes();
		e =s.getSeconds();
		if(m < 10){
			m = '0' + m;
		}
		if(d < 10){
			d = '0' + d
		}
		if(h < 10){
			h = '0' + h;
		}
		if(i < 10){
			i = '0' + i;
		}
		if(e < 10){
			e = '0' + e;
		}
		startDateStr = y + '-' + m + '-' + d + ' ' + h + ':' + i + ':' + e;
		return startDateStr;
	}
	
	function statisticSearch(){
		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();
		var url = '?m=ChiefEditor&a=approveStatistic&start_time=' + startTime + '&end_time=' + endTime;
		location.href = url;
	}
</script>