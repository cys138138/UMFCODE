<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<?php display('es_manage/nav.html.php'); ?>

<style type="text/css">
	._subject .item a{color:#999999; margin-right:10px;}
	._subject .item .on{font-weight:bold; color:#000000;}
	._subject .name{width:40px;}
	._subject .control input{width:140px;}
</style>
<div class="module _subject">
	<a href="?m=ChiefEditor&a=showCreateCatalogue&subject=<?php echo $subjectId; ?>">添加<?php echo $aSubject[$subjectId]; ?>目录</a>
	<div class="clear"></div>
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<?php foreach($aSubject as $key => $subjectName){ ?>
				<a <?php if($subjectId == $key){ ?> class="on" <?php } ?> href="?m=ChiefEditor&a=showCatalogueManage&subject=<?php echo $key; ?>"><?php echo $subjectName; ?></a>
			<?php } ?>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">目录：</div>
		<div class="control" id="category">
			<script type="text/javascript">
				oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
				oDirTree.add(0, -1, '<?php echo $aSubject[$subjectId]; ?>目录');
				var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
				$(aCategoryList).each(function(){
					var esCount = this.es_count > 0 ? '(' + this.es_count + '题)' : '';
					oDirTree.add(this.id, this.parent_id, this.name + esCount, '#catalogue' + this.id, this.name);
				});
				document.write(oDirTree);
			</script>
		</div>
	</div>
	<div class="clear"></div>
</div>

<style type="text/css">
	._list .row .c1{width:5%;}
	._list .row .c2{width:30%;}
	._list .row .c3{width:15%;}
	._list .row .c5{width:5%;}
	._list .row .c6{width:5%;}
	._list .row .c7{width:5%;}
	._list .row .c7 a{float:left; margin-right:10px;}
	.list .header.fix {width:97.5%;position:fixed;top:0;}
</style>
<div class="module _list">
	<div class="list">
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">名称</div>
			<div class="c3">父目录</div>
			<div class="c5">选择题</div>
			<div class="c5">判断题</div>
			<div class="c5">待初审</div>
			<div class="c5">待复核</div>
			<div class="c5">已复核</div>
			<div class="c5">总题数</div>
			<div class="c6">排序</div>
			<div class="c7">操作</div>
		</div>
		<?php
		if(isset($aCategoryList)){
			foreach($aCategoryList as $key => $aCategory){
		?>
			<div class="row" id="catalogue<?php echo $aCategory['id']; ?>">
				<div class="c1"><?php echo $aCategory['id']; ?></div>
				<div class="c2"><?php echo $aCategory['name']; ?></div>
				<div class="c3"><?php echo $aCategory['parent_name']; ?></div>
				<div class="c5"><?php echo !$aCategory['not_final_dir'] ? $aCategory['select_es'] : '&nbsp;';?></div>
				<div class="c5"><?php echo !$aCategory['not_final_dir'] ? $aCategory['judge_es'] : '&nbsp;';?></div>
				<div class="c5"><?php echo !$aCategory['not_final_dir'] ? $aCategory['wait_appeal'] : '&nbsp;';?></div>
				<div class="c5"><?php echo !$aCategory['not_final_dir'] ? $aCategory['wait_end_appeal'] : '&nbsp;';?></div>
				<div class="c5"><?php echo !$aCategory['not_final_dir'] ? $aCategory['pass_end_appeal'] : '&nbsp;';?></div>
				<div class="c5"><?php echo !$aCategory['not_final_dir'] ? $aCategory['all_es'] : '&nbsp;';?></div>
				
				<div class="c6"><?php echo $aCategory['orders']; ?></div>
				<div class="c7">
					<a href="?m=ChiefEditor&a=showEditCatalogue&catagolueId=<?php echo $aCategory['id']; ?>">编辑</a>
					<a href="javascript:void(0)" onclick="deleteCatalogue(<?php echo $aCategory['id']; ?>)">删除</a>
				</div>
			</div>
			<?php
				}
			}
			?>
	</div>
</div>

<script type="text/javascript">
	function deleteCatalogue(id){
		if(!confirm('确定要删除这个目录吗?')){
			return false;
		}
		if(!(id >= 1)){
			UBox.show('目录ID非法');
			return false;
		}
		$.post('http://<?php echo APP_MANAGE; ?>/?m=ChiefEditor&a=deleteCatalogue', {catagolueId:id}, function(result){
		   var isJson = typeof(result) == 'object' && Object.prototype.toString.call(result).toLowerCase() == '[object object]' && !result.length;
		   if(isJson){
			   UBox.show(result.msg, result.status, result.data);
		   }else{
			   UBox.show('网络可能有点慢');
		   }
	   });
	}

	$(function(){
		$(window).scroll(function(){
			if($(window).scrollTop() > 160){
				$('.list .header').addClass('fix');
			}else{
				$('.list .header').removeClass('fix');
			}
		})
	})
</script>
