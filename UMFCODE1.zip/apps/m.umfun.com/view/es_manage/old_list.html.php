<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es_feedback']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<?php display('es_manage/nav.html.php'); ?>
<div class="module _condition">
	<style type="text/css">
		._condition .item a{color:#999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000;}
		._condition .name{width:60px;}
		._condition .control input{width:140px;}
		._condition a.button{ color:#FC0; margin-left:5px;}
		.excet{margin-top:15px;}
	</style>

	<div class="item">
		<div class="clear"></div>
		<div class="name">科目：</div>
		<div class="control">
			<?php foreach($aSubject as $key => $subject){ ?>
				<a href="javascript:void(0)" <?php if($subjectId == $key){ ?> class="on" <?php } ?> onclick="select(1, <?php echo $key; ?>, this)" xid="subject"><?php echo $subject; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="name">题型：</div>
		<div class="control">
			<a href="javascript:void(0)" onclick="select(2, 0, this)" <?php if(!$esTypeId){ ?> class="on" <?php } ?> xid="esType">全部</a>
			<?php foreach($aEsType as $key => $esType){ ?>
				<a href="javascript:void(0)" <?php if($esTypeId == $key){ ?> class="on" <?php } ?> onclick="select(2, <?php echo $key; ?>, this)" xid="esType"><?php echo $esType; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>
		<div class="name">状态：</div>
		<div class="control">
			<?php foreach($aStatus as $key => $name){ ?>
				<a href="javascript:void(0)" <?php if($esStatus == $key){ ?> class="on" <?php } ?> onclick="select(3, <?php echo $key; ?>, this)" xid="esStatus" ><?php echo $name; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="clear"></div>
		<div class="name">目录：</div>
		<div class="control">
			<label class="on" style="margin-right:4px; float:left;" id="categoryResult"><?php if(isset($categroyName)){ echo $categroyName; }else{ echo '全部'; } ?></label><a onclick="removeCategroy()" style="font-size:17px; color:#0066CC; margin-right:6px; float:left;" href="javascript:void(0)">×</a><label onclick="showCategroy()" id="showCategroy">选择目录</label>
		</div>
		<input type="hidden" id="category_id" value="<?php echo $categroyId; ?>" />
		<div class="clear"></div>
	</div>

	<div class="clear"></div>
</div>

<div class="wrapEsListContainer subject_<?php echo $subjectId; ?>">
	<p class="title">我的题目</p>
	<ul class="listItem esListHead">
		<li class="id">编号</li>
		<li class="type">题型</li>
		<li class="status">状态</li>
		<li class="approveTime">审核时间</li>
		<br class="clear">
	</ul>

	<div class="wrapEsList" id="wrapEsList"></div>
	<br class="clear">

	<div class="wrapPage">
		<button type="button" class="btnOperation" onclick="subApprove();">批量提交</button><?php isset($pageHtml) && print($pageHtml); ?>
		<br class="clear">
	</div>
	<br class="clear">
</div>
<script type="text/javascript">
	function select(key, value, object){
		if(key == 1){
			searchCondition.subject = value;
			$('a[xid="subject"]').removeClass('on');
		}else if(key == 2){
			searchCondition.esType = value;
			$('a[xid="esType"]').removeClass('on');
		}else if(key == 3){
			searchCondition.esStatus = value;
			$('a[xid="esStatus"]').removeClass('on');
		}
		$(object).addClass('on');
		searchEs();
	}

	<?php
	$subjectCheck = '';
	foreach($aSubject as $key => $subject){
		$subjectCheck .= 'searchCondition.subject != ' . $key . ' && ';
	}
	$subjectCheck .= 'searchCondition.subject !=0';

	$esTypeCheck = '';
	foreach($aEsType as $key => $esType){
		$esTypeCheck .= 'searchCondition.esType != ' . $key . ' && ';
	}
	$esTypeCheck .= 'searchCondition.esType != 0';
	?>

	function searchEs(){
		if(<?php echo $subjectCheck; ?>){
			UBox.show('错误的科目');
			return false;
		}
		if(<?php echo $esTypeCheck; ?>){
			UBox.show('错误的题目类型');
			return false;
		}

		if(searchCondition.subject){
			url += '&subject=' + searchCondition.subject;
		}
		if(searchCondition.esType){
			url += '&esType=' + searchCondition.esType;
		}
		if(searchCondition.esStatus){
			url += '&esStatus=' + searchCondition.esStatus;
		}
		if($('#category_id').val() > 0){
			url += '&category_id=' + $('#category_id').val();
		}
		window.location.href = url;
	}


	function cancelEs(id){
		UBox.confirm('确定作废这条题目？', function(){
			$.ajax({
				url : '/?m=ChiefEditor&a=cancleEs',
				type : 'post',
				data : {esId : id},
				success : function(result){
					$('#esItem' + id).slideUp('normal', function(){
						$(this).remove();
						if($('ul[xid="esItem"]').length == 0){
							UBox.show(result.msg, result.status, 'reload');
						}else{
							UBox.show(result.msg, result.status);
						}
					});
				}
			});
		});
	}

	function operateEs(id, type){
		var url = '?m=ChiefEditor&a=operateOldEs';
		if(type == 1){
			$.ajax({
				url : url,
				type : 'post',
				data : {esId:id, action:type},
				success : function(result){
					$('#esItem' + id).slideUp('normal', function(){
						$(this).remove();
						if($oWrapEsList.find('ul[xid="esItem"]').length == 0){
							UBox.show(result.msg, result.status, 'reload');
						}else{
							UBox.show(result.msg, result.status);
						}
					});
				}
			});
		}else if(type == 2){
			UBox.confirm('删除后不可恢复！确定删除？', function(){
				$.ajax({
					url : url,
					type : 'post',
					data : {esId:id, action:type},
					success : function(result){
						$('#esItem' + id).slideUp('normal', function(){
							$(this).remove();
							if($oWrapEsList.find('ul[xid="esItem"]').length == 0){
								UBox.show(result.msg, result.status, 'reload');
							}else{
								UBox.show(result.msg, result.status);
							}
						});
					},
					error : function(request){
						UBox.show('网络可能有点慢');
					}
				});
			});
		}else{
			UBox.show('参数错误');
		}
	}

	function closeCallBack(){
		easyDialog.close();
    }

	function showCategroy(){
		var option={
			title:'<?php echo $GLOBALS['SUBJECT'][$subjectId]; ?>目录',
			width:520,
			content:'<iframe width="520" height="480"  frameborder="0" src="<?php echo '?m=EsCreate&a=showCategroyTree&subject_id=' . $subjectId; ?>" ></iframe>',
			confirmCallBack: function(){
				if(!$('#category_id').val()){
					UBox.show('请选择一个最终目录');
					return false;
				}
				searchEs();
			},
			cancleCallBack: closeCallBack
		};
		popEasyDialog(option);
	}

	function removeCategroy(){
		$('#category_id').val(0);
		$('#categoryResult').text('全部');
	}

	function showFeedbackEs(index){
		EsFeedback.config({
			url : 'm=ChiefEditor&a=addFeedback',
			aSelect : <?php echo json_encode($GLOBALS['ES_WRONG_REASON'][$subjectId]); ?>
		});
		EsFeedback.show({es_id : index});
	}

	function showEsList(){
		var aEsList = <?php echo json_encode($aEsList); ?>
		,aTypeList = <?php echo json_encode($aEsType); ?>;
		for(var i = 0; i < aEsList.length; i++){
			var aEs = aEsList[i]
			,controlButtons = '';

			if(aEs.status == 0){
				controlButtons = '<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 1)">入库</button>\n\
				<button type="button" class="btnOperation" onclick="location.href=\'?m=ChiefEditor&a=showEditOldEs&esId=' + aEs.id + '\'">编辑</button>\
				<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 2)">删除</button>';
			}else if(aEs.status == 5){
				controlButtons = '<button type="button" class="btnOperation" onclick="showFeedbackEs(' + aEs.id + ')">反馈</button>\
	<button type="button" class="btnOperation" onclick="cancelEs(' + aEs.id + ')">作废</button>';
			}

			var $oEs = $('<ul class="listItem esItem subject' + aEs.subject_id + '" xid="esItem" id="esItem' + aEs.id + '">\
				<li class="id">' + aEs.id + '</li>\
				<li class="type">' + aTypeList[aEs.type_id] + '</li>\
				<li class="status">' + (aEs.status == 0 ? '未入库' : '已入库') + '</li>\
				<li class="approveTime">' + (aEs.approve_time ? aEs.approve_time : '-- -- --') + '</li>\
				<br class="clear">\
				<div class="wrapDetail es_content" xid="wrapDetail"></div>\
				<p class="control category">目录：' + getCategoryTreePath(aEs.category_tree) + '</p>\
				' + (aEs.same_ids.length ? '<p class="control sameEs"><a class="red" href="?m=EsCreate&a=showSameEsList&check_es_id=' + aEs.id + '&same_ids=' + aEs.same_ids.join(',') + '" target="_blank">存在相似题目</a></p>' : '') + '\
				' + (aEs.sendback_reason ? '<p class="control name reject">驳回理由：' + aEs.sendback_reason + '</p>' : '') + '\
				<p class="control">' + controlButtons + '</p>\
			</ul>').appendTo($oWrapEsList).data('es', aEs);
			$oEs.find('div[xid="wrapDetail"]').append(ES.buildDetail(aEs));
		}
	}


	var $oWrapEsList = null
	,endTime = "'end_time'"
	,url = '<?php echo $baseUrl; ?>'
	,searchCondition = {
		subject : <?php echo $subjectId; ?>,
		esType : <?php echo $esTypeId; ?>,
		esStatus : '<?php echo $esStatus; ?>'
	};

	$(function(){
		$oWrapEsList = $('#wrapEsList');
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		showEsList();

		$.cookie('lastEsSubjectId', searchCondition.subject, {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
	});
</script>