<?php display('es_manage/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<div class="module _condition">
	<style>
		._condition .item a{color:#999999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000000;}
		._condition .name{width:60px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FFCC00; margin-left:5px;}
	</style>

	<div class="item">
		<div class="name">统计项目：</div>
		<div class="control">
			<a href="javascript:void(0)" <?php if($type == 1){ ?> class="on" <?php } ?> onclick="setStatistic(1, 1)">出题统计</a>
			<a href="javascript:void(0)" <?php if($type == 2){ ?> class="on" <?php } ?> onclick="setStatistic(1, 2)">审核统计</a>
			<a href="javascript:void(0)" <?php if($type == 3){ ?> class="on" <?php } ?> onclick="setStatistic(1, 3)">复核统计</a>
			<a href="?m=ChiefEditor&a=approveStatistic">旧题审核统计</a>
		</div>
		<div class="clear"></div>
		<div class="name">科目：</div>
		<div class="control">
			<?php
				foreach($aSubject as $key => $subject){
			?>
					<a href="javascript:void(0)" <?php if($key == $subjectId){ ?> class="on" <?php } ?> onclick="setStatistic(2, <?php echo $key; ?>)"><?php echo $subject; ?></a>
			<?php
			}
			?>
		</div>
		<div class="clear"></div>
		<div class="name">时间：</div>
		<div class="control">
			<a href="javascript:void(0)" <?php if($dayType == 1){ ?> class="on" <?php } ?> onclick="setStatistic(3, 1)">最近3天</a>
			<a href="javascript:void(0)" <?php if($dayType == 2){ ?> class="on" <?php } ?> onclick="setStatistic(3, 2)">最近7天</a>
			<a href="javascript:void(0)" <?php if($dayType == 3){ ?> class="on" <?php } ?> onclick="setStatistic(3, 3)">最近15天</a>
			<a href="javascript:void(0)" <?php if($dayType == 4){ ?> class="on" <?php } ?> onclick="setStatistic(3, 4)">最近30天</a>
			自定义时间查询：
			<input type="text" id="startTime" value="<?php echo date('Y-m-d H:i:s', $startTime); ?>" name="startTime" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" />&nbsp;-&nbsp;<input id="endTime" name="endTime" value="<?php echo date('Y-m-d H:i:s', $endTime); ?>" type="text" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" />
		</div>
		<div class="control"><a onclick="statistic(0)" class="button">确定</a></div>
	</div>
	
	<div class="clear"></div>

</div>

<script type="text/javascript">
	window.url = '<?php echo $baseUrl; ?>';
	var statisticCondition = {
		subject : <?php echo $subjectId; ?>,
		type : <?php echo $type; ?>,
		dayType : <?php echo $dayType; ?>,
	};
	
	<?php
		$checkSubject = '';
		$i = 1;
		foreach($aSubject as $key => $subject){
			if($i < count($aSubject)){
				$checkSubject .= 'statisticCondition.subject != ' . $key . ' && ';
			}else{
				$checkSubject .= 'statisticCondition.subject != ' . $key;
			}
			$i++;
		}
		
		$checkDayType = '';
		foreach($aDayType as $key => $dayType){
			$checkDayType .= 'statisticCondition.dayType != ' . $key . ' && ';
		}
		$checkDayType .= ' statisticCondition.dayType != 0';
	?>
	function setStatistic(condition, value){
		if(condition == 1){
			statisticCondition.type = value;
		}else if(condition == 2){
			statisticCondition.subject = value;
		}else if(condition == 3){
			statisticCondition.dayType = value;
		}
		
		statistic(1);
	}
	
	function statistic(searchType){
		if(statisticCondition.type != 1 && statisticCondition.type != 2 && statisticCondition.type != 3){
			UBox.show('错误的统计类型');
			return false;
		}
		url += '&type=' + statisticCondition.type;
		
		if(<?php echo $checkSubject; ?>){
			UBox.show('错误的科目');
			return false;
		}
		url += '&subject=' + statisticCondition.subject;
		
		if(<?php echo $checkDayType; ?>){
			UBox.show('错误的时间段类型');
			return false;
		}
		if(statisticCondition.dayType != 0 && searchType == 1){
			url += '&dayType=' + statisticCondition.dayType;
			window.location.href = url;
			return;
		}else{
			var startTime = $('#startTime').val();
			var endTime = $('#endTime').val();
			if(!startTime){
				UBox.show('请填写开始时间');
				return false;
			}
			if(!endTime){
				UBox.show('请填写结束时间');
				return false;
			}
			url += '&startTime=' + startTime;
			url += '&endTime=' + endTime;
			window.location.href = url;
		}
	}
</script>
<style>
	._esList .row {font-weight:bold;}
	._esList .row .c1{width:100px; color:#000000;}
	._esList .row .c2{width:100px;}
	._esList .row .c3{width:100px;}
	._esList .row .c4{width:100px;}
	._esList .row .c5{width:100px;}
	._esList .row .c6{width:100px;}
</style>

	<div class="module _esList">
		<?php
		if($type == 1){
		?>
			<div class="title">出题统计</div>
			<div class="list">
				<div class="row header">
					<div class="c1">统计</div>
					<div class="c2">创建数量</div>
					<div class="c3">已提交数量</div>
					<div class="c4">已通审数量</div>
					<div class="c5">已发回数量</div>
					<div class="c6">申诉有效数量</div>
				</div>
				<?php
				foreach($aStatis as $key => $static){
				?>
				<div class="row">
					<div class="c1"><?php echo $static['name']; ?></div>
					<div class="c2"><?php echo $static['create_nums']; ?></div>
					<div class="c3"><?php echo $static['submit_times']; ?></div>
					<div class="c4"><?php echo $static['pass_approve_nums']; ?></div>
					<div class="c5"><?php echo $static['sendback_times']; ?></div>
					<div class="c6"><?php echo $static['effective_appeal_nums']; ?></div>
				</div>
				<?php
				}
				
				?>
				<div class="row footer">
				</div>
			</div>
		<?php
		}elseif($type == 2){
		?>
			<div class="title">审核统计</div>
			<div class="list">
			<div class="row header">
				<div class="c1">统计</div>
				<div class="c2">通过初审数量</div>
				<div class="c3">发回数量</div>
				<div class="c4">通过复核数量</div>
				<div class="c5">复核驳回数量</div>
				<div class="c6">被有效申诉数量</div>
			</div>
				<?php
				foreach($aStatis as $key => $static){
				?>
					<div class="row">
						<div class="c1"><?php echo $static['name']; ?></div>
						<div class="c2"><?php echo $static['pass_first_approve_nums']; ?></div>
						<div class="c3"><?php echo $static['sendback_times']; ?></div>
						<div class="c4"><?php echo $static['pass_end_approve_nums']; ?></div>
						<div class="c5"><?php echo $static['not_pass_end_approve_times']; ?></div>
						<div class="c6"><?php echo $static['effective_appeal_nums']; ?></div>
					</div>
				<?php
				}
				?>
				<div class="row footer">
				</div>
			</div>
		<?php
		}elseif($type == 3){
		?>
			<div class="title">复核统计</div>
			<div class="list">
			<div class="row header">
				<div class="c1">统计</div>
				<div class="c2">通过复核数量</div>
				<div class="c3">复核不通过数量</div>
				<div class="c4">作废数量</div>
			</div>
				<?php
				foreach($aStatis as $key => $static){
				?>
					<div class="row">
						<div class="c1"><?php echo $static['name']; ?></div>
						<div class="c2"><?php echo $static['pass_end_approve_nums']; ?></div>
						<div class="c3"><?php echo $static['not_pass_end_approve_times']; ?></div>
						<div class="c4"><?php echo $static['blank_out_nums']; ?></div>
					</div>
				<?php
				}
				?>
				<div class="row footer">
				</div>
			</div>
		<?php
		}
		?>
	</div>
	<div class="stats">
		<p><b>获取科目时间：</b><a><?php echo $aRunTimeStatis['getUserAllowedSubjectTime']; ?> 秒</a></p>
		<p><b>获取统计用户时间：</b><a><?php echo $aRunTimeStatis['getStatisticUserTime']; ?> 秒</a></p>
		<p><b>获取统计数据时间：</b><a><?php echo $aRunTimeStatis['getStatisticTime']; ?> 秒</a></p>
	</div>
	<style type="text/css">
		.stats p{line-height:25px; padding-left:10px;}
	</style>
