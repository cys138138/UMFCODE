<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<?php display('es_manage/nav.html.php'); ?>
<style type="text/css">
	._form .name{width:80px;}
	._form .item .noRoot{margin-right:8px;}
	._form .item .on{font-weight:bold; color:#000000;}
	._form a.button{color:#FFCC00; margin-left:5px;}
</style>
<form class="module _form" id="form">
	<input type="hidden" name="parent_id" id="parent_id" />
	<input type="hidden" name="subject_id" id="subject_id" value="<?php echo $subjectId; ?>" />
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<style type="text/css">
				._form .createSubject{margin-right:8px;}
			</style>
			<?php
			foreach($aSubject as $key => $subject){
			?>
				<a class="createSubject <?php if($subjectId == $key){ ?> on <?php } ?>"  href="http://<?php echo APP_MANAGE; ?>/?m=ChiefEditor&a=showCreateCatalogue&subject=<?php echo $key; ?>" xid="subject"><?php echo $subject; ?></a>
			<?php
			}
			?>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">目录名称：</div>
		<div class="control">
			<input type="text" id="name" name="name" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">排序：</div>
		<div class="control">
			<input type="text" id="orders" name="orders" value="1" />
		</div>
	</div>
	<div class="clear"></div>
		<div class="item">
		<div class="name">是否根目录：</div>
		<div class="control">
			<input type="radio" id="noRootCatalogue" onclick="showCatalogue()" checked="checked" name="catalogue" xid="isRoot" value="0" /><label class="noRoot" for="noRootCatalogue">否</label>
			<input type="radio" id="rootCatalogue" onclick="hideCatalogue()" name="catalogue" xid="isRoot" value="1" /><label for="rootCatalogue">是</label>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item" id="catalogue">
		<div class="name">父目录：</div>
		<div class="control">
			<script type="text/javascript">
				var oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
				oDirTree.add(0, -1, '<?php echo str_replace("'", "\\'", $aSubject[$subjectId]); ?>目录');
				var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
				$(aCategoryList).each(function(){
					oDirTree.add(this.id, this.parent_id, this.name, 'javascript:getCategoryId()', this.name);
				});
				document.write(oDirTree);
				
				if($.cookie('lastCatagory<?php echo $subjectId; ?>') > 0){
					oDirTree.openTo($.cookie('lastCatagory<?php echo $subjectId; ?>'), true);
					$('#parent_id').val($.cookie('lastCatagory<?php echo $subjectId; ?>'));
				}
			</script>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name"></div>
		<div class="control">
			<input type="button" onclick="createCatalogue()" value="提交" class="button">
		</div>
	</div>
</form>

<script type="text/javascript">
	function createCatalogue(){
		var parentId = $('#parent_id').val();
		var subjectId = $('#subject_id').val();
		var isRoot = $('input[xid="isRoot"]:checked');
		var name = $.trim($('#name').val());
		var orders = $('#orders').val();
		if(!(subjectId >= 1)){
			UBox.show('非法的科目ID');
			return false;
		}
		if(!name){
			UBox.show('请填写目录名称');
			return false;
		}
		if(!(orders >= 1)){
			UBox.show('排序必须为正整数');
			return false;
		}
		if(isRoot.length != 1){
			UBox.show('请选择是否根目录');
			return false;
		}
		if(isRoot.val() == 0 && !(parentId >= 1)){
			UBox.show('请选择父目录');
			return false;
		}
		$.post('http://<?php echo APP_MANAGE; ?>/?m=ChiefEditor&a=createCatalogue', $('#form').serialize(), function(result){
			var isJson = typeof(result) == "object" && Object.prototype.toString.call(result).toLowerCase() == "[object object]" && !result.length;
			if(isJson){
				UBox.show(result.msg, result.status, result.data, 1);
			}else{
				UBox.show('网络可能有点慢');
			}
		});
	}

	function showCatalogue(){
		$('#catalogue').slideDown();
	}

	function hideCatalogue(){
		$('#catalogue').slideUp();
		$('#parent_id').val(0);
	}

	function getCategoryId(){
		var categoryId = oDirTree.getSelected();
		$('#parent_id').val(categoryId);
		$.cookie('lastCatagory<?php echo $subjectId; ?>', categoryId , {expires: 3600000 * 24 * 7});
	}
</script>