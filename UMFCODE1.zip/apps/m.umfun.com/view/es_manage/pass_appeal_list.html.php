<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />

<?php display('es_manage/nav.html.php'); ?>
<div class="wrapEsListContainer subject_<?php echo $subjectId; ?>">
	<p class="title">申诉成功的题目</p>
	<ul class="listItem esListHead">
		<li class="id">编号</li>
		<li class="subject">科目</li>
		<li class="type">题型</li>
		<li class="creater">出题人</li>
		<li class="approver">审核人</li>
		<li class="sendbackTime">发回时间</li>
		<br class="clear">
	</ul>

	<div class="wrapEsList" id="wrapEsList"></div>
	<br class="clear">

	<div class="wrapPage">
		<?php isset($pageHtml) && print($pageHtml); ?>
		<br class="clear">
	</div>
	<br class="clear">
</div>

<script>	
	function showEsList(){
		var aEsList = <?php echo json_encode($aEsList); ?>
		,aSubjectList = <?php echo json_encode($GLOBALS['SUBJECT']); ?>
		,aTypeList = <?php echo json_encode($GLOBALS['ES_TYPE']); ?>;
		for(var i = 0; i < aEsList.length; i++){
			var aEs = aEsList[i]
			,$oEs = $('<ul class="listItem esItem subject' + aEs.subject_id + '" xid="esItem" id="esItem' + aEs.id + '">\
				<li class="id">' + aEs.id + '</li>\
				<li class="subject">' + aSubjectList[aEs.subject_id] + '</li>\
				<li class="type">' + aTypeList[aEs.type_id] + '</li>\
				<li class="creater">' + aEs.submiter_user_name + '</li>\
				<li class="approver">' + aEs.approver_user_name + '</li>\
				<li class="sendbackTime">' + date('Y-m-d H:i:s', aEs.sendback_time) + '</li>\
				<br class="clear">\
				<div class="wrapDetail es_content" xid="wrapDetail"></div>\
				<p class="control category">目录：' + getCategoryTreePath(aEs.category_tree) + '</p>\
				<p class="control name reject">驳回理由：' + aEs.sendback_reason + '</p>\
			</ul>').appendTo($oWrapEsList).data('es', aEs);
			$oEs.find('div[xid="wrapDetail"]').append(ES.buildDetail(aEs));
		}
	}

	var $oWrapEsList = null;
	$(function(){
		$oWrapEsList = $('#wrapEsList');
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		showEsList();
	});
</script>