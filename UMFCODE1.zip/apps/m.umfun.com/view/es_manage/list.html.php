<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es_feedback']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['char_inputer']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['layer_min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['analysis']; ?>"></script>
<script type="text/javascript" src="<?php echo Yii::getAlias('@r.js.esp'); ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo Yii::getAlias('@r.css.esp'); ?>" />

<?php display('es_manage/nav.html.php'); ?>
<div class="module _condition">
	<style type="text/css">
		._condition .item a{color:#999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000;}
		._condition .name{width:60px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
		.excet{margin-top:15px;}
		.leftlabel{margin-right:4px; float:left;}
		.removeCategroy{font-size:17px; color:#0066CC !important; margin-right:6px !important; float:left;}
		.approveUser{width:90px;}
	</style>

	<div class="item">
		<div class="name">状态：</div>
		<div class="control">
			<?php foreach($aStatus as $key => $status){ ?>
				<a href="javascript:void(0)" <?php if($esStatus == $key){ ?> class="on" <?php } ?> onclick="select(3, <?php echo $key; ?>, this)" xid="esStatus"><?php echo $status; ?></a>
			<?php } ?>
		</div>
		<div class="clear"></div>
		<div class="name">科目：</div>
		<div class="control">
			<?php foreach($aSubject as $key => $subject){ ?>
				<a href="javascript:void(0)" <?php if($subjectId == $key){ ?> class="on" <?php } ?> onclick="select(1, <?php echo $key; ?>, this)" xid="subject"><?php echo $subject; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="name">题型：</div>
		<div class="control">
			<a href="javascript:void(0)" onclick="select(2, 0, this)" <?php if(!$esTypeId){ ?> class="on" <?php } ?> xid="esType">全部</a>
			<?php foreach($aEsType as $key => $esType){ ?>
				<a href="javascript:void(0)" <?php if($esTypeId == $key){ ?> class="on" <?php } ?> onclick="select(2, <?php echo $key; ?>, this)" xid="esType"><?php echo $esType; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>
	</div>

	<div class="clear"></div>

	<div class="item">
		<div class="name">时间：</div>
		<div class="control">
			<select id="time_type" onchange="selectTimeType()" name="time_type">
				<?php foreach($aTimeType as $key => $action){ ?>
					<option <?php if($timeType == $key){ ?> selected="selected" <?php } ?> value="<?php echo $key; ?>"><?php echo $action; ?></option>
				<?php } ?>
			</select>
			&nbsp;&nbsp;
		</div>
		<div class="control"><input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />&nbsp;-&nbsp;<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" /></div>
	</div>

	<div class="clear"></div>
	<div class="item">
		<div class="name">创建人：</div>
		<div class="control">
			<select id="creater" onchange="selectCreater()" name="creater">
				<option value="0">全部</option>
				<?php
					foreach($aCreaterList as $key => $aCreater){
				?>
						<option <?php if($creater == $aCreater['id']){ ?> selected="selected" <?php } ?> value="<?php echo $aCreater['id']; ?>"><?php echo $aCreater['name']; ?></option>
				<?php
					}
				?>
			</select>
			&nbsp;&nbsp;
		</div>
	</div>

	<div class="clear"></div>
	<div class="item">
		<div class="name">目录：</div>
		<div class="control">
			<label class="on leftlabel" id="categoryResult"><?php if(isset($categroyName)){ echo $categroyName; }else{ echo '全部'; } ?></label><a onclick="removeCategroy()" class="removeCategroy" href="javascript:void(0)">×</a><label onclick="showCategroy()" id="showCategroy">选择目录</label>
		</div>
		<input type="hidden" id="category_id" value="<?php echo $categroyId; ?>" />
		<div class="control"><a href="javascript:void(0)" class="button" onclick="searchEs()">确定</a></div>
	</div>

	<div class="clear"></div>
	<div class="item excet">
		<div class="name">题目ID：</div>
		<div class="control">
			<input type="text" value="<?php echo $esIds; ?>" id="esIds" name="esIds" />
		</div>
		<div class="control"><a href="javascript:void(0)" class="button" onclick="searchEsByID()">精确查找</a></div>
	</div>
	<div class="clear"></div>
</div>

<div class="wrapEsListContainer subject_<?php echo $subjectId; ?>">
	<p class="title">题目管理</p>
	<ul class="listItem esListHead">
		<li class="id">编号</li>
		<li class="subject">科目</li>
		<li class="type">题型</li>
		<li class="status">状态</li>
		<li class="creater">出题人</li>
		<?php if($esStatus == 6){ echo '<li class="approveUser">审核人</li>'; }?>
		<li class="approveTime">审核时间</li>
		<li class="appeal">申诉状态</li>
		<br class="clear">
	</ul>

	<div class="wrapEsList" id="wrapEsList"></div>
	<br class="clear">

	<div class="wrapPage">
		<?php isset($pageHtml) && print($pageHtml); ?>
		<br class="clear">
	</div>
	<br class="clear">
</div>

<script>
	function select(key, value, object){
		if(key == 1){
			searchCondition.subject = value;
			$('a[xid="subject"]').removeClass('on');
		}else if(key == 2){
			searchCondition.esType = value;
			$('a[xid="esType"]').removeClass('on');
		}else if(key == 3){
			searchCondition.esStatus = value;
			$('a[xid="esStatus"]').removeClass('on');
		}
		$(object).addClass('on');
		searchEs();
	}

	function selectTimeType(){
		searchCondition.timeType = $('#time_type').val();
	}

	function selectCreater(){
		searchCondition.creater = $('#creater').val();
	}

	function searchEsByID(){
		var aEsId = $.trim($('#esIds').val()).split(',');
		for(var i in aEsId){
			if(!/^[0-9]*[1-9][0-9]*$/.test(aEsId[i])){
				UBox.show('发现非整数的题目ID');
				return false;
			}
		}
		url += '&esIds=' + aEsId.join(',');
		window.location.href = url;
	}

	<?php
	$subjectCheck = '';
	foreach($aSubject as $key => $subject){
		$subjectCheck .= 'searchCondition.subject != ' . $key . ' && ';
	}
	$subjectCheck .= 'searchCondition.subject !=0';

	$esTypeCheck = '';
	foreach($aEsType as $key => $esType){
		$esTypeCheck .= 'searchCondition.esType != ' . $key . ' && ';
	}
	$esTypeCheck .= 'searchCondition.esType != 0';

	$esStatusCheck = '';
	foreach($aStatus as $key => $status){
		$esStatusCheck .= 'searchCondition.esStatus != ' . $key . ' && ';
	}
	$esStatusCheck .= 'searchCondition.esStatus !=0';

	$timeTypeCheck = '';
	$i = 1;
	foreach($aTimeType as $key => $time){
		if($i < count($aTimeType)){
			$timeTypeCheck .= 'searchCondition.timeType != ' . $key . ' && ';
		}else{
			$timeTypeCheck .= 'searchCondition.timeType != ' . $key;
		}
		$i++;
	}
	?>

	function searchEs(){
		if(<?php echo $subjectCheck; ?>){
			UBox.show('错误的科目');
			return false;
		}
		if(<?php echo $esTypeCheck; ?>){
			UBox.show('错误的题目类型');
			return false;
		}
		if(<?php echo $esStatusCheck; ?>){
			UBox.show('错误的题目状态');
			return false;
		}
		if(<?php echo $timeTypeCheck; ?>){
			UBox.show('错误的时间类型');
			return false;
		}

		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();

		if(searchCondition.subject){
			url += '&subject=' + searchCondition.subject;
		}
		if(searchCondition.esType){
			url += '&esType=' + searchCondition.esType;
		}
		if(searchCondition.esStatus){
			url += '&esStatus=' + searchCondition.esStatus;
		}
		url += '&timeType=' + searchCondition.timeType;
		if(startTime){
			url += '&startTime=' + startTime;
		}
		if(endTime){
			url += '&endTime=' + endTime;
		}
		if(searchCondition.creater > 0){
			url += '&creater=' + searchCondition.creater;
		}
		if($('#category_id').val() > 0){
			url += '&category_id=' + $('#category_id').val();
		}
		window.location.href = url;
	}

	function operateEs(id, type){
		if(!(id >= 1)){
			UBox.show('非法的题目ID');
			return false;
		}else{
			var esId = id;
			if(type == 1 || type == 2){
				var method = 'approvalEs';
				if(!allowApprove){
					UBox.show('每次审核操作必须间隔5秒,请认真审阅题目哦!');
					return;
				}


				if(type == 1){
					var param = {esId : id, action : 1};
				}else{
					var	option = {
						title: '填写驳回的理由',
						width: 400,
						height: 280,
						content: '<textarea style="margin:10px; width:367px; height:250px;color:#808080;" id="comment' + esId + '"></textarea>',
						confirmCallBack: function(){
							var comment = $.trim($('#comment' + esId).val());
							if(comment == ''){
								UBox.show('请填写驳回的理由');
								return false;
							}
							var param = {
								esId : esId,
								action : 2,
								comment : comment
							};
							ajaxType(esId, 'approvalEs', param);
						}
					};
					popEasyDialog(option);
					return false;
				}
			}else if(type == 4 || type == 5){
				var method = 'appeal';
				if(type == 4){
					var param = {esId : id, action : 1};
				}else{
					var param = {esId : id, action : 2};
				}
			}
			ajaxType(id, method, param);
		}
	}

	function ajaxType(id, method, param){

		$.ajax({
			url : '?m=ChiefEditor&a=' + method,
			type : 'post',
			data : param,
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status != 1){
					return;
				}

				if(method == 'approvalEs'){
					allowApprove = false;
					$('.btnOperation').css('background', '#666');
					setTimeout(function(){
						allowApprove = true;
						$('.btnOperation').css('background', '#333');
					}, 3000);
				}
				$('#esItem' + id).slideUp('normal', function(){
					$(this).remove();
					if($oWrapEsList.find('ul[xid="esItem"]').length == 0){
						location.reload();
					}
				});
			},
			error : function(request){
				UBox.show('网络可能有点慢');
			}
		});

	}

	function cancelEs(id){
		if(!(id >= 1)){
			UBox.show('非法的题目ID');
			return false;
		}
		UBox.confirm('确定作废这条题目？', function(){
			$.ajax({
				url : '?m=ChiefEditor&a=cancleEs',
				type : 'post',
				data : {esId : id},
				success : function(result){
					$('#esItem' + id).slideUp('normal', function(){
						$(this).remove();
						if($('ul[xid="esItem"]').length == 0){
							UBox.show(result.msg, result.status, 'reload');
						}else{
							UBox.show(result.msg, result.status);
						}
					});
				},
				error : function(request){
					UBox.show('网络可能有点慢');
				}
			});
		});
	}

	function closeCallBack(){
		easyDialog.close();
    }

	function showCategroy(){
		var option={
			title:'<?php echo $GLOBALS['SUBJECT'][$subjectId > 0 ? $subjectId : $aEsList[0]['subject_id']]; ?>目录',
			width:520,
			content:'<iframe width="520" height="480"  frameborder="0" src="<?php echo '?m=EsCreate&a=showCategroyTree&subject_id=' . $subjectId; ?>" ></iframe>',
			confirmCallBack: function(){
				if(!$('#category_id').val()){
					UBox.show('请选择一个最终目录');
					return false;
				}
			},
			cancleCallBack: closeCallBack
		};
		popEasyDialog(option);
	}

	function removeCategroy(){
		$('#category_id').val(0);
		$('#categoryResult').text('全部');
	}

	function showFeedbackEs(index){
		EsFeedback.show({es_id : index});
	}

	function showEsList(){
		var aEsList = <?php echo json_encode($aEsList); ?>
		,aSubjectList = <?php echo json_encode($aSubject); ?>
		,aTypeList = <?php echo json_encode($aEsType); ?>
		,aStatusList = <?php echo json_encode($aStatus); ?>
		,aAppealStatusList = ['未申诉', '申诉中', '申诉成功', '申诉失败'];

		var aEsIds = [];
		for(var i = 0; i < aEsList.length; i++){
			var aEs = aEsList[i]
			,aControlButtons = [];

			aEsIds.push(aEs.id);

			if(aEs.status == 3){
				aControlButtons.push('<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 1)">复核通过</button>\
				<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 2)">复核驳回</button>');
			}
			if(aEs.status == 5){
				aControlButtons.push('<button type="button" class="btnOperation" onclick="cancelEs(' + aEs.id + ')">作废</button>\
				<button type="button" class="btnOperation" onclick="showFeedbackEs(' + aEs.id + ')">反馈</button>');
			}
			if(aEs.appeal_status == 2){
				aControlButtons.push('<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 4)">申诉通过</button>\
				<button type="button" class="btnOperation" onclick="operateEs(' + aEs.id + ', 5)">申诉驳回</button>');
			}

			var approveUser = searchCondition.esStatus == 6 ? '<li class="approveUser">' + aEs.approver_user_name + '</li>' : '';

			var $oEs = $('<ul class="listItem esItem subject' + aEs.subject_id + '" xid="esItem" id="esItem' + aEs.id + '" data-id="' + aEs.id + '">\
				<li class="id"><label for="esId' + aEs.id + '">' + aEs.id + '</label></li>\
				<li class="subject">' + aSubjectList[aEs.subject_id] + '</li>\
				<li class="type">' + aTypeList[aEs.type_id] + '</li>\
				<li class="status">' + aStatusList[aEs.status] + '</li>\
				<li class="creater">' + (aEs.create_user_name ? aEs.create_user_name : '-- -- --') + '</li>\
				' + approveUser + '\
				<li class="approveTime">' + (aEs.approve_time ? aEs.approve_time : '-- -- --') + '</li>\
				<li class="appeal status' + aEs.appeal_status + '">' + aAppealStatusList[aEs.appeal_status - 1] + '</li>\
				<br class="clear">\
				<div class="wrapDetail es_content" xid="wrapDetail"></div>\
				<p class="control category jietisilu" xid="category">目录：' + getCategoryTreePath(aEs.category_tree) + '</p>\
				' + (aEs.same_ids.length ? '<p class="control sameEs"><a class="red" href="?m=EsCreate&a=showSameEsList&check_es_id=' + aEs.id + '&same_ids=' + aEs.same_ids.join(',') + '" target="_blank">存在相似题目</a></p>' : '') + '\
				' + (aEs.sendback_reason ? '<p class="control name reject">驳回理由：' + aEs.sendback_reason + '</p>' : '') + '\
				<p class="control">' + aControlButtons.join('') + '</p>\
			</ul>').appendTo($oWrapEsList).data('es', aEs);
			$oEs.find('div[xid="wrapDetail"]').append(ES.buildDetail(aEs));
		}

		aEsIds.length && loadEsAnalysis(aEsIds);
	}

	function loadEsAnalysis(aEsIds){
		ajax({
			url : '/?m=EsCreate&a=getAnalysis',
			data : {es_ids : aEsIds},
			success : function(aResult){
				if(aResult.status != 1){
					UBox.show(aResult.msg);
					return;
				}

				for(var i in aEsIds){
					var searchId = aEsIds[i];
					var hasAnalysis = false;
					for(var j in aResult.data){

						var aEsAnalysis = aResult.data[j];
						if(aEsAnalysis.id == searchId){
							$('#esItem' + searchId).data('analysis', aEsAnalysis.analysis).showAnalysis();
							hasAnalysis = true;
							break;
						}
					}

					if(!hasAnalysis){
						$('#esItem' + searchId).showWriteAnalysis();
					}
				}
			}
		});
	}

	//显示解题思路
	$.fn.showAnalysis = function(){
		var analysis = $(this).data('analysis');
		if(!analysis){
			$.error(this.id + ' 没有题目解析');
			return;
		}

		var $this = $(this),
			id = $this.data('id');

		var $btnWriteAnalysis = $this.find('[xid="btnWriteAnalysis"]');
		if($btnWriteAnalysis.length){
			$btnWriteAnalysis = $this.find('[xid="btnWriteAnalysis"]').parent().remove();
		}

		$this.find('p[xid="category"]').after('<p class="control analysis jietisilu">\
			<button type="button" class="btnOperation" xid="btnEditAnalysis">修改解题思路</button>\
			解题思路：<span class="J-analysis-' + id + '">' + analysis + '</span></p>');

		ES.drawMathExpression($this);

		$this.on('click', '[xid="btnEditAnalysis"]', function(){
			new analysisPlugin('edit', {
				editUrl : '/?m=ChiefEditor&a=editAnalysis',
				id : id,
				defaultContent : $('#esItem' + id).data('analysis'),
				subject : searchCondition.subject
			});
		});
	};

	//填写解题思路
	$.fn.showWriteAnalysis = function(){
		var $this = $(this),
			id = $this.data('id');
		$this.find('p[xid="category"]').after('<p class="control"><button type="button" class="btnOperation" xid="btnWriteAnalysis">填写解题思路</button></p>');

		$this.on('click', '[xid="btnWriteAnalysis"]', function(){
			new analysisPlugin('add', {
				editUrl : '/?m=ChiefEditor&a=publishAnalysis',
				id : id,
				defaultContent : '',
				subject : searchCondition.subject
			});
		});
	};



	var $oWrapEsList = null
	,endTime = "'end_time'"
	,url = '<?php echo $baseUrl; ?>';
	var searchCondition = {
		subject : <?php echo $subjectId > 0 ? $subjectId : $aEsList[0]['subject_id']; ?>,
		esType : <?php echo $esTypeId; ?>,
		esStatus : <?php echo $esStatus; ?>,
		timeType : <?php echo $timeType; ?>,
		creater  : <?php echo $creater; ?>
	};

	var allowApprove = true;
	$(function(){
		$oWrapEsList = $('#wrapEsList');
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		showEsList();

		EsFeedback.config({
			url : '/?m=ChiefEditor&a=addFeedback',
			aSelect : <?php echo json_encode($defaultReason); ?>
		});

		$('#start_time').blur(function(){
			$.cookie('chiefStartTime', $(this).val(), {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
		});
		$('#end_time').blur(function(){
			$.cookie('chiefEndTime', $(this).val(), {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
		});
	});
</script>