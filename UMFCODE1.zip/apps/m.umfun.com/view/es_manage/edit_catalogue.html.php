<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dtree']['path'] . $GLOBALS['RESOURCE']['dtree']['js']; ?>"></script>
<?php display('es_manage/nav.html.php'); ?>
<style type="text/css">
	._form .name{width:80px;}
	._form .item .noRoot{margin-right:8px;}
	._form .item .on{font-weight:bold; color:#000000;}
	._form a.button{color:#FFCC00; margin-left:5px;}
</style>
<form class="module _form" id="form">
	<input type="hidden" name="id" id="id" value="<?php echo $aCatalogueInfo['id']; ?>" />
	<input type="hidden" name="parent_id" id="parent_id" value="<?php echo $aCatalogueInfo['parent_id']; ?>" />
	<input type="hidden" name="subject_id" id="subject_id" value="<?php echo $aCatalogueInfo['subject_id']; ?>" />
	<div class="item">
		<div class="name">目录ID：</div>
		<div class="control">
			<input type="text" name="showId" id="showId" value="<?php echo $aCatalogueInfo['id']; ?>" disabled="disabled"/>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">科目：</div>
		<div class="control">
			<input type="text" name="subject" id="subject" value="<?php echo $GLOBALS['SUBJECT'][$aCatalogueInfo['subject_id']]; ?>" disabled="disabled"/>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">目录名称：</div>
		<div class="control">
			<input type="text" id="name" name="name" value="<?php echo $aCatalogueInfo['name']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name">排序：</div>
		<div class="control">
			<input type="text" id="orders" name="orders" value="<?php echo $aCatalogueInfo['orders']; ?>" />
		</div>
	</div>
	<div class="clear"></div>
		<div class="item">
		<div class="name">是否根目录：</div>
		<div class="control">
			<input type="radio" <?php if($aCatalogueInfo['parent_id']){ ?> checked="checked" <?php } ?> id="noRootCatalogue" onclick="showCatalogue()" checked="checked" name="catalogue" xid="isRoot" value="0" /><label class="noRoot" for="noRootCatalogue">否</label>
			<input type="radio" <?php if(!$aCatalogueInfo['parent_id']){ ?> checked="checked" <?php } ?>  id="rootCatalogue" onclick="hideCatalogue()" name="catalogue" xid="isRoot" value="1" /><label for="rootCatalogue">是</label>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item" id="catalogue" <?php if(!$aCatalogueInfo['parent_id']){ ?> style="display:none" <?php } ?>>
		<div class="name">父目录：</div>
		<div class="control">
			<script type="text/javascript">
				var oDirTree = new dTree('oDirTree', '<?php echo $GLOBALS['RESOURCE']['dtree']['path']; ?>');
				oDirTree.add(0, -1, '<?php echo str_replace("'", "\\'", $GLOBALS['SUBJECT'][$aCatalogueInfo['subject_id']]); ?>目录树');
				var aCategoryList = <?php echo json_encode($aCategoryList); ?>;
				$(aCategoryList).each(function(){
					oDirTree.add(this.id, this.parent_id, this.name, 'javascript:getCategoryId()', this.name);
				});
				document.write(oDirTree);
				oDirTree.openTo(<?php echo $aCatalogueInfo['parent_id']; ?>, true);
			</script>
		</div>
	</div>
	<div class="clear"></div>
	<div class="item">
		<div class="name"></div>
		<div class="control">
			<input type="button" onclick="createCatalogue()" value="提交" class="button">
		</div>
	</div>
</form>

<script type="text/javascript">
	function createCatalogue(){
		var parentId = $('#parent_id').val();
		var isRoot = $('input[xid="isRoot"]:checked');
		var name = $.trim($('#name').val());
		var orders = $('#orders').val();
		if(!name){
			UBox.show('请填写目录名称');
			return false;
		}
		if(!(orders >= 1)){
			UBox.show('排序必须为正整数');
			return false;
		}
		if(isRoot.length != 1){
			UBox.show('请选择是否根目录');
			return false;
		}
		if(isRoot.val() == 0 && !(parentId >= 1)){
			UBox.show('请选择父目录');
			return false;
		}
		$.post('http://<?php echo APP_MANAGE; ?>/?m=ChiefEditor&a=editCatalogue', $('#form').serialize(), function(result){
			var isJson = typeof(result) == "object" && Object.prototype.toString.call(result).toLowerCase() == "[object object]" && !result.length;
			if(isJson){
				UBox.show(result.msg, result.status, result.data);
			}else{
				UBox.show('网络可能有点慢');
			}
		});
	}

	function showCatalogue(){
		$('#catalogue').slideDown();
	}

	function hideCatalogue(){
		$('#catalogue').slideUp();
		$('#parent_id').val(0);
	}

	function getCategoryId(){
		var categoryId = oDirTree.getSelected();
		$('#parent_id').val(categoryId);
		$.cookie('lastCatagory<?php echo $aCatalogueInfo['subject_id']; ?>', categoryId , {expires: 3600000 * 24 * 7});
	}
</script>