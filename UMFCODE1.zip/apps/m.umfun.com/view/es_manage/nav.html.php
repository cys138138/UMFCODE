<div class="nav">
	<a <?php if(get('a') == 'showEsManage'){ ?> class="on"<?php } ?>  href="?m=ChiefEditor&a=showEsManage">题目管理</a>
	<a <?php if(get('a') == 'showCatalogueManage'){ ?> class="on"<?php } ?>  href="?m=ChiefEditor&a=showCatalogueManage">目录管理</a>
	<a <?php if(get('a') == 'showStatistic' || get('a') == 'approveStatistic'){ ?> class="on"<?php } ?>  href="?m=ChiefEditor&a=showStatistic">统计</a>
	<a <?php if(get('a') == 'showOld2NewEsManage' || get('a') == 'showEditOldEs'){ ?> class="on"<?php } ?>  href="?m=ChiefEditor&a=showOld2NewEsManage">旧题管理</a>
	<a <?php if(get('a') == 'showPassAppealEsList'){ ?> class="on"<?php } ?>  href="?m=ChiefEditor&a=showPassAppealEsList">申诉成功</a>
	<a href="javascript:;" onclick="unlockApproveEs();">解锁一周前题目</a>
	<?php if(get('a') == 'showEditCatalogue'){ ?>
		<a class="on">编辑目录ID:<?php echo get('catagolueId'); ?></a>
		<a onclick="javascript:history.go(-1);">返回上一页</a>
	<?php } ?>
	<?php if($_GET['a'] == 'showCreateCatalogue'){ ?>
		<a class="on">添加<?php echo $GLOBALS['SUBJECT'][get('subject')]; ?>目录</a>
		<a onclick="javascript:history.go(-1);">返回上一页</a>
	<?php } ?>
	<?php if(get('count')){ ?>
	<a onclick="javascript:history.go(-1);" class="on">返回上一页</a>
	<?php } ?>
</div>
<div class="br"></div>

<script>
	function unlockApproveEs(){
		if(confirm('你确定要解锁一周前所有的题目吗？')){
			$.ajax({
				type : 'get',
				data : {},
				url : '?m=ChiefEditor&a=unlockApproveEs',
				success : function(aResult){
					UBox.show(aResult.msg, aResult.status);
				},
				error : function(){
					UBox.show('系统错误', 0);
				}
			
			});
		}	
	}
</script>