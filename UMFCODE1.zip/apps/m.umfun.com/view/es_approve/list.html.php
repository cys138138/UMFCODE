<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />

<?php display('es_approve/nav.html.php'); ?>
<div class="module _condition">
	<style type="text/css">
		._condition .item a{color:#999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000;}
		._condition .name{width:60px;}
		._condition .control input{width:140px;}
		._condition a.button{ color:#FC0; margin-left:5px;}
	</style>
	<?php
	if($subjectId == 2){
	?>
		<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
	<?php
	}
	?>
	<div class="item">
		<div class="name">状态：</div>
		<div class="control">
			<?php foreach($aStatus as $key => $status){ ?>
				<a href="javascript:void(0)" <?php if($esStatus == $key){ ?> class="on" <?php } ?> onclick="select(3, <?php echo $key; ?>, this)" xid="esStatus"><?php echo $status; ?></a>
			<?php } ?>
		</div>
		<div class="clear"></div>
		<div class="name">科目：</div>
		<div class="control">
			<?php foreach($aSubject as $key => $subject){ ?>
				<a href="javascript:void(0)" <?php if($subjectId == $key){ ?> class="on" <?php } ?> onclick="select(1, <?php echo $key; ?>, this)" xid="subject"><?php echo $subject; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="name">题型：</div>
		<div class="control">
			<a href="javascript:void(0)" onclick="select(2, 0, this)" <?php if(!$esTypeId){ ?> class="on" <?php } ?> xid="esType">全部</a>
			<?php foreach($aEsType as $key => $esType){ ?>
				<a href="javascript:void(0)" <?php if($esTypeId == $key){ ?> class="on" <?php } ?> onclick="select(2, <?php echo $key; ?>, this)" xid="esType"><?php echo $esType; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>
	</div>

	<div class="clear"></div>

	<div class="item">
		<div class="name">时间：</div>
		<div class="control">
			<select id="time_type" onchange="selectTimeType()" name="time_type">
				<?php foreach($aTimeType as $key => $action){ ?>
					<option <?php if($timeType == $key){ ?> selected="selected" <?php } ?> value="<?php echo $key; ?>"><?php echo $action; ?></option>
				<?php } ?>
			</select>
			<input type="text" id="start_time" value="<?php echo $startTime; ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />&nbsp;-&nbsp;<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo $endTime; ?>" type="text" id="end_time" name="end_time" />
		</div>
		<div class="control"><a href="javascript:void(0)" class="button" onclick="searchEs()">确定</a></div>
	</div>

	<div class="clear"></div>
</div>

<div class="wrapEsListContainer subject_<?php echo $subjectId; ?>">
	<p class="title">我处理的题目</p>
	<ul class="listItem esListHead">
		<li class="id">编号</li>
		<li class="type">题型</li>
		<li class="approveTime">审核时间</li>
		<li class="appeal">申诉状态</li>
		<br class="clear">
	</ul>

	<div class="wrapEsList" id="wrapEsList"></div>
	<br class="clear">

	<div class="wrapPage">
		<?php isset($pageHtml) && print($pageHtml); ?>
		<br class="clear">
	</div>
	<br class="clear">
</div>

<script type="text/javascript">
	function select(key, value, object){
		if(key == 1){
			searchCondition.subject = value;
			$('a[xid="subject"]').removeClass('on');
		}else if(key == 2){
			searchCondition.esType = value;
			$('a[xid="esType"]').removeClass('on');
		}else if(key == 3){
			searchCondition.esStatus = value;
			$('a[xid="esStatus"]').removeClass('on');
		}
		$(object).addClass('on');
		searchEs();
	}

	function selectTimeType(){
		searchCondition.timeType = $('#time_type').val();
	}
	<?php
	$subjectCheck = '';
	$i = 1;
	foreach($aSubject as $key => $subject){
		if($i < count($aSubject)){
			$subjectCheck .= 'searchCondition.subject != ' . $key . ' && ';
		}else{
			$subjectCheck .= 'searchCondition.subject != ' . $key;
		}
		$i++;
	}

	$esTypeCheck = '';
	$i = 1;
	foreach($aEsType as $key => $esType){
		if($i < count($aEsType)){
			$esTypeCheck .= 'searchCondition.esType != ' . $key . ' && ';
		}else{
			$esTypeCheck .= 'searchCondition.esType != ' . $key;
		}
		$i++;
	}
	$esTypeCheck .= ' && searchCondition.esType != 0';

	$esStatusCheck = '';
	$i = 1;
	foreach($aStatus as $key => $status){
		if($i < count($aStatus)){
			$esStatusCheck .= 'searchCondition.esStatus != ' . $key . ' && ';
		}else{
			$esStatusCheck .= 'searchCondition.esStatus != ' . $key;
		}
		$i++;
	}
	?>
		
	function searchEs(){
		if(<?php echo $subjectCheck; ?>){
			UBox.show('错误的科目');
			return false;
		}
		if(<?php echo $esTypeCheck; ?>){
			UBox.show('错误的题目类型');
			return false;
		}
		if(<?php echo $esStatusCheck; ?>){
			UBox.show('错误的题目状态');
			return false;
		}

		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();

		if(searchCondition.subject){
			url += '&subject=' + searchCondition.subject;
		}
		if(searchCondition.esType){
			url += '&esType=' + searchCondition.esType;
		}
		if(searchCondition.esStatus){
			url += '&esStatus=' + searchCondition.esStatus;
		}
		url += '&timeType=' + searchCondition.timeType;
		if(startTime){
			url += '&startTime=' + startTime;
		}
		if(endTime){
			url += '&endTime=' + endTime;
		}

		window.location.href = url;
	}
	
	function submitEs(id){
		$.ajax({
			url : submitUrl
			,type : 'post'
			,dataType : 'json'
			,data : {esId : id}
			,success : function(aResult){
				if(aResult.status == 0){
					UBox.show(aResult.msg, aResult.status);
				}else if(aResult.status == -1){
					UBox.confirm(aResult.msg, function(){
						submitUrl += '&ignore_same_es=1';
						submitEs(id);
					});
				}else{
					$('#esItem' + id).slideUp('normal', function(){
						$(this).remove();
						if($('ul[xid="esItem"]').length == 0){
							UBox.show(aResult.msg, aResult.status, aResult.data);
						}else{
							UBox.show(aResult.msg, aResult.status);
						}
					});
				}
			}
		});
	}
	
	function showEsList(){
		var aEsList = <?php echo json_encode($aEsList); ?>
		,aTypeList = <?php echo json_encode($aEsType); ?>
		,aAppealStatusList = ['未申诉', '申诉失败', '申诉成功', '申诉失败'];
		for(var i = 0; i < aEsList.length; i++){
			var aEs = aEsList[i]
			,controlButtons = '';
			
			if(aEs.status == 6){
				controlButtons = '<button type="button" class="btnOperation" onclick="location.href=\'?m=EsApprove&a=showEdit&esId=' + aEs.id + '\'">编辑</button>\n\
				<button type="button" class="btnOperation" onclick="submitEs(' + aEs.id + ')">提交</button>';
			}
			
			var $oEs = $('<ul class="listItem esItem subject' + aEs.subject_id + '" xid="esItem" id="esItem' + aEs.id + '">\
				<li class="id">' + aEs.id + '</li>\
				<li class="type">' + aTypeList[aEs.type_id] + '</li>\
				<li class="approveTime">' + (aEs.approve_time ? aEs.approve_time : '-- -- --') + '</li>\
				<li class="appeal status' + (aEs.appeal_status != 2 ? aEs.appeal_status : 4) + '">' + aAppealStatusList[aEs.appeal_status - 1] + '</li>\
				<br class="clear">\
				<div class="wrapDetail es_content" xid="wrapDetail"></div>\
				<p class="control category">目录：' + getCategoryTreePath(aEs.category_tree) + '</p>\
				' + (aEs.same_ids.length ? '<p class="control sameEs"><a class="red" href="?m=EsCreate&a=showSameEsList&check_es_id=' + aEs.id + '&same_ids=' + aEs.same_ids.join(',') + '" target="_blank">存在相似题目</a></p>' : '') + '\
				' + (aEs.sendback_reason ? '<p class="control name reject">驳回理由：' + aEs.sendback_reason + '</p>' : '') + '\
				<p class="control">' + controlButtons + '</p>\
			</ul>').appendTo($oWrapEsList).data('es', aEs);
			$oEs.find('div[xid="wrapDetail"]').append(ES.buildDetail(aEs));
		}
	}
	
	var $oWrapEsList = null
	,submitUrl = '?m=EsApprove&a=submitEs'
	,endTime = "'end_time'"
	,searchCondition = {
		subject : <?php echo $subjectId; ?>,
		esType : <?php echo $esTypeId; ?>,
		esStatus : <?php echo $esStatus; ?>,
		timeType : <?php echo $timeType; ?>
	}
	,url = '<?php echo $baseUrl; ?>';
	$(function(){
		$oWrapEsList = $('#wrapEsList');
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		showEsList();
		
		$('#start_time').blur(function(){
			$.cookie('approveStartTime', $(this).val(), {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
		});
		$('#end_time').blur(function(){
			$.cookie('approveEndTime', $(this).val(), {expires:30, path:'<?php echo DEFAULT_COOKIE_PATH; ?>', domain:'<?php echo DEFAULT_COOKIE_DOMAIN; ?>'});
		});
	});
</script>