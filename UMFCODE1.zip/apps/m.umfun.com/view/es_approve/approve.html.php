<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<?php if($subjectId == 2){ ?>
	<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<?php } ?>
	
<?php display('es_approve/nav.html.php'); ?>
<div class="module _condition">
	<style type="text/css">
		._condition .item a{color:#999; margin-right:10px;}
		._condition .item .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{ color:#FC0; margin-left:5px;}
	</style>
	<div class="item">
		<div class="name">状态：</div>
		<div class="control">
			<?php foreach($aStatus as $key => $status){ ?>
				<a href="javascript:void(0)" <?php if($esStatus == $key){ ?> class="on" <?php } ?> onclick="select(3, <?php echo $key; ?>, this)" xid="esStatus"><?php echo $status; ?></a>
			<?php } ?>
		</div>
		<div class="clear"></div>
		<div class="name">科目：</div>
		<div class="control">
			<?php foreach($aSubject as $key => $subject){ ?>
				<a href="javascript:void(0)" <?php if($subjectId == $key){ ?> class="on" <?php } ?> onclick="select(1, <?php echo $key; ?>, this)" xid="subject"><?php echo $subject; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>

		<div class="name">题型：</div>
		<div class="control">
			<a href="javascript:void(0)" onclick="select(2, 0, this)" <?php if(!$esTypeId){ ?> class="on" <?php } ?> xid="esType">全部</a>
			<?php foreach($aEsType as $key => $esType){ ?>
				<a href="javascript:void(0)" <?php if($esTypeId == $key){ ?> class="on" <?php } ?> onclick="select(2, <?php echo $key; ?>, this)" xid="esType"><?php echo $esType; ?></a>
			<?php } ?>
		</div>

		<div class="clear"></div>
	</div>
	
	<div class="clear"></div>
</div>

<div class="wrapEsListContainer subject_<?php echo $subjectId; ?>">
	<p class="title">需要我审核的题目</p>
	<ul class="listItem esListHead">
		<li class="id">编号</li>
		<li class="type">题型</li>
		<br class="clear">
	</ul>

	<div class="wrapEsList" id="wrapEsList"></div>
	<br class="clear">
</div>

<script type="text/javascript">
	function select(key, value, object){
		if(key == 1){
			searchCondition.subject = value;
			$('a[xid="subject"]').removeClass('on');
		}else if(key == 2){
			searchCondition.esType = value;
			$('a[xid="esType"]').removeClass('on');
		}else if(key == 3){
			searchCondition.esStatus = value;
			$('a[xid="esStatus"]').removeClass('on');
		}
		$(object).addClass('on');
		searchEs();
	}

	<?php
	$subjectCheck = '';
	$i = 1;
	foreach($aSubject as $key => $subject){
		if($i < count($aSubject)){
			$subjectCheck .= 'searchCondition.subject != ' . $key . ' && ';
		}else{
			$subjectCheck .= 'searchCondition.subject != ' . $key;
		}
		$i++;
	}

	$esTypeCheck = '';
	$i = 1;
	foreach($aEsType as $key => $esType){
		if($i < count($aEsType)){
			$esTypeCheck .= 'searchCondition.esType != ' . $key . ' && ';
		}else{
			$esTypeCheck .= 'searchCondition.esType != ' . $key;
		}
		$i++;
	}
	$esTypeCheck .= ' && searchCondition.esType != 0';

	$esStatusCheck = '';
	$i = 1;
	foreach($aStatus as $key => $status){
		if($i < count($aStatus)){
			$esStatusCheck .= 'searchCondition.esStatus != ' . $key . ' && ';
		}else{
			$esStatusCheck .= 'searchCondition.esStatus != ' . $key;
		}
		$i++;
	}
	?>
		
	function searchEs(){
		if(<?php echo $subjectCheck; ?>){
			UBox.show('错误的科目');
			return false;
		}
		if(<?php echo $esTypeCheck; ?>){
			UBox.show('错误的题目类型');
			return false;
		}
		if(<?php echo $esStatusCheck; ?>){
			UBox.show('错误的题目状态');
			return false;
		}

		var startTime = $('#start_time').val();
		var endTime = $('#end_time').val();

		if(searchCondition.subject){
			url += '&subject=' + searchCondition.subject;
		}
		if(searchCondition.esType){
			url += '&esType=' + searchCondition.esType;
		}
		if(searchCondition.esStatus){
			url += '&esStatus=' + searchCondition.esStatus;
		}
		url += '&timeType=' + searchCondition.timeType;
		if(startTime){
			url += '&startTime=' + startTime;
		}
		if(endTime){
			url += '&endTime=' + endTime;
		}

		window.location.href = url;
	}

	function approveEs(id){
		if(!allowApprove){
			UBox.show('每次审核操作必须间隔5秒,请认真审阅题目哦!');
			return;
		}
		
		$.ajax({
			url : '/?m=EsApprove&a=approvalEs',
			type : 'post',
			data : {
				esId : id,
				operationType : 1
			},
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);

				if(aResult.status != 1){
					return;
				}

				allowApprove = false;
				$('.btnOperation').css('background', '#666');
				setTimeout(function(){
					allowApprove = true;
					$('.btnOperation').css('background', '#333');
				}, 3000);
			
				$('#esItem' + id).slideUp('normal', function(){
					$(this).remove();
					if($oWrapEsList.find('ul[xid="esItem"]').length == 0){
						UBox.show(aResult.msg, aResult.status, aResult.data);
					}
				});
			},
			error : function(request){
				UBox.show('网络可能有点慢');
			}
		});
	}

	function refuseEs(){
		var $oRefuseComment = $('#refuseEsComment')
		,comment = $.trim($oRefuseComment.val())
		,esId = $oRefuseComment.data('es_id');
		if(comment == ''){
			UBox.show('请填写驳回的理由', -1);
			return false;
		}
		
		$.ajax({
			url : '?m=EsApprove&a=approvalEs'
			,data : {
				esId : esId,
				operationType : 2,
				comment : comment
			},
			type : 'post',
			success : function(aResult){
				$('#esItem' + esId).slideUp('normal', function(){
					$(this).remove();
					if($oWrapEsList.find('ul[xid="esItem"]').length == 0){
						UBox.show(aResult.msg, aResult.status, aResult.data);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				});
			}
		});
	}

	function showComment(id){
	    var	option = {
            title: '填写驳回的理由',
            width: 400,
            height: 280,
            content: '<textarea style="margin:10px; width:367px; height:250px; color:#808080;" id="refuseEsComment" data-es_id="' + id + '"></textarea>',
            confirmCallBack: refuseEs
        };
        popEasyDialog(option);
	}
	
	function showEsList(){
		var aEsList = <?php echo json_encode($aEsList); ?>
		,aTypeList = <?php echo json_encode($aEsType); ?>;
		for(var i = 0; i < aEsList.length; i++){
			var aEs = aEsList[i]
			,$oEs = $('<ul class="listItem esItem subject' + aEs.subject_id + '" xid="esItem" id="esItem' + aEs.id + '">\
				<li class="id">' + aEs.id + '</li>\
				<li class="type">' + aTypeList[aEs.type_id] + '</li>\
				<br class="clear">\
				<div class="wrapDetail es_content" xid="wrapDetail"></div>\
				<p class="control category">目录：' + getCategoryTreePath(aEs.category_tree) + '</p>\
				' + (aEs.same_ids.length ? '<p class="control sameEs"><a class="red" href="?m=EsCreate&a=showSameEsList&check_es_id=' + aEs.id + '&same_ids=' + aEs.same_ids.join(',') + '" target="_blank">存在相似题目</a></p>' : '') + '\
				' + (aEs.sendback_reason.length ? '<p class="control red">驳回理由：' + aEs.sendback_reason + ' </p>' : '') + '\
				<p class="control">\n\
					<button type="button" class="btnOperation" onclick="approveEs(' + aEs.id + ')">通审</button>\n\
					<button type="button" class="btnOperation" onclick="showComment(' + aEs.id + ')">驳回</button>\n\
				</p>\
			</ul>').appendTo($oWrapEsList).data('es', aEs);
			$oEs.find('div[xid="wrapDetail"]').append(ES.buildDetail(aEs));
		}
	}

	var $oWrapEsList = null
	,endTime = "'end_time'"
	,url = '<?php echo $baseUrl; ?>'
	,searchCondition = {
		subject : <?php echo $subjectId; ?>,
		esType : <?php echo $esTypeId; ?>,
		esStatus : <?php echo $esStatus; ?>
	}
	,allowApprove = true;
	$(function(){		
		$oWrapEsList = $('#wrapEsList');
		ES.config({imageBaseUrl : '<?php echo SYSTEM_RESOURCE_URL; ?>'});
		showEsList();
	});
</script>