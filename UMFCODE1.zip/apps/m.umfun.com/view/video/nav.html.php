<div class="nav">
	<a <?php if(get('a') == 'showCategoryList'){ ?>class="on"<?php } ?> href="?m=Video&a=showCategoryList">视频分类列表</a>
	<a <?php if(get('a') == 'showCategoryAdd'){ ?>class="on"<?php } ?> href="?m=Video&a=showCategoryAdd">视频分类添加</a>
	<?php if(get('a') == 'showCategoryEdit'){echo '<a class="on">视频分类编辑</a>';}?>
	
	
	<a <?php if(get('a') == 'showVideoList'){ ?>class="on"<?php } ?> href="?m=Video&a=showVideoList">视频列表</a>
	<a <?php if(get('a') == 'showVideoAdd'){ ?>class="on"<?php } ?> href="?m=Video&a=showVideoAdd">视频添加</a>
	<?php if(get('a') == 'showVideoEdit'){echo '<a class="on">视频编辑</a>';}?>
</div>

<div class="br"></div>
