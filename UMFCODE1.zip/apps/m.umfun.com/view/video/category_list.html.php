<?php display('video/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		.status a{color:#999; margin-right:10px;}
		.status .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
	</style>
	<form>
		<div class="item">
			<div class="name width80">分类名：</div>
			<div class="control"><input type="text" name="categoryName" id="categoryName" value="<?php echo get('categoryName');?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="categorySearch(1);">搜素</a>
			</div>
		</div>

		<div class="clear"></div>

		<div class="item">
			<div class="name width100">显示状态：</div>
			<div class="control">
				<select name="categoryStatus" id="categoryStatus" >
					<option value="-1">请选择</option>
					<option value="0" <?php if(get('categoryStatus') == '0'){echo 'selected="selected"';}?>>不显示</option>
					<option value="1" <?php if(get('categoryStatus') == '1'){echo 'selected="selected"';}?>>显示</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="categorySearch(2);">搜素</a>
			</div>
		</div>
	</form>
	<script type="text/javascript">

		function categorySearch(type){
			var url = '?m=Video&a=showCategoryList';
			if(type == 1){
				var categoryName = $.trim($('#categoryName').val());
				if(categoryName){
						url += "&categoryName="+categoryName;
					}
				window.location.href = url;
			}else if(type == 2){
				var categoryStatus = $('#categoryStatus').val();
				if(categoryStatus == 0 || categoryStatus == 1){
					url += '&categoryStatus='+categoryStatus;
				}
				window.location.href = url;
			}
		}
	</script>
</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
		._userList .list .c1{width:150px;}
		._userList .list .c2{width:150px;}
		._userList .list .c3{width:150px;}
		._userList .list .c10{width:320px;}
		._userList .list .row .c10 a{padding-right:7px;}
	</style>
	<div class="title">视频分类列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">分类名</div>
			<div class="c2">状态</div>
			<div class="c3">创建时间</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aCategoryList){
			foreach($aCategoryList as $aCategoryInfo){ ?>
			<div class="row">
				<div class="c1"><?php echo $aCategoryInfo['name'] ? $aCategoryInfo['name'] : '&nbsp;'; ?></div>
				<div class="c2"><?php echo $aCategoryInfo['status'] == 1 ? '显示' : '不显示'; ?></div>
				<div class="c3"><?php echo date('Y-m-d H:i:s', $aCategoryInfo['create_time']); ?></div>
				<div class="c10 right">
					<a href="/?m=Video&a=showVideoList&categoryId=<?php echo $aCategoryInfo['id']?>">查看所有视频</a>
					<a href="/?m=Video&a=showCategoryEdit&id=<?php echo $aCategoryInfo['id']?>">编辑</a>
					<a href="javascript:void(0)" onclick="delCategoryById(<?php echo $aCategoryInfo['id']; ?>)">删除</a>
				</div>
			</div>
		<?php }
		}else{
			echo '<font color=red>抱歉，暂时缺乏数据！</font>';
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	function delCategoryById(categoryId){
		UBox.confirm('真的要删除这个分类吗', function(){
			$.ajax({
				url : '/?m=Video&a=delCategory',
				data : {categoryId : categoryId},
				type : 'post',
				dataType : 'json',
				success:function(aResult){
					if(aResult.status == 1){
						window.location.reload();
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error:function(){
					UBox.show('系统错误', 0);
				}
			});			
		});

	}
</script>