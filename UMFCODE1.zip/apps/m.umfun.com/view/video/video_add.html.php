<?php display('video/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .control .w450{width:450px;float:left;}
		._main .item .control .w650{width:650px;float:left;}
		._main .item .control .readonly{ background-color: #EAEAEA}
		._main .item .control .resolve{float:left;margin:0 10px;}
		._main .item .control .thumb_img{float: left;margin-left: 20px;margin-top: 130px; padding:2px; border:1px solid #ccc;width:160px;height:90px}
		._main .item .control .thumb_img img{width:160px;height:90px}
		._main .item .control .play_box{width:400px;height:225px;border:1px solid #ccc;float:left;}
		select{margin-right:15px;padding:0 3px;}
		._main .item .control .button_loading{ background-color: #666}
		._main .item .control .video_description{height:150px;}
	</style>
	<div class="title">视频添加</div>
	<div class="item">
		<div class="name">视频URL：</div>
		<div class="control">
			<input type="text" class="w450" name="uemlook_url" id="uemlook_url"/>
			<a class="button resolve" onclick="getVideo()" id="get_video_button"/>解 析</a>
			请填写UEMLOOK播放页的URL 如: <a>http://v.umelook.com/?m=video&vid=511804</a>
		</div>
	</div>
	<div class="clear"></div>
	<form id="videoAdd" class="addForm" style="display:none">
		<div class="title">视频信息</div>

		<div class="clear"></div>
		<div class="item">
			<div class="name">预览：</div>
			<div class="control">
				<div class="play_box" id="playBox" ></div>
				<div  class="thumb_img"><img id="thumb_img" alt="图片错误" title="视频缩略图"/></div>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">视频标题：</div>
			<div class="control">
				<input type="text" class="w650" id="video_title" name="video_title"/>
				<input type="hidden" id="is_trans" name="is_trans" />
			</div>
		</div>
		<div class="clear"></div>		
		<div class="item">
			<div class="name">播放次数：</div>
			<div class="control"><input type="text" class="w650" id="video_views" name="video_views" /></div>
		</div>
		<div class="clear"></div>	
		<div class="item">
			<div class="name">视频描述：</div>
			<div class="control">
				<textarea id="video_description" name="video_description" rows="7" class="w650 video_description"></textarea>
			</div>
		</div>
		<div class="clear"></div>	
		<div class="item">
			<div class="name">分类及状态：</div>
			<div class="control">				
				<select name="category_id" id="category_id">
					<option value="">请选择分类</option>
					<?php 
						if($aCategoryList){
							foreach ($aCategoryList as $aCategoryInfo) {
								echo '<option value="' . $aCategoryInfo['id'] . '">' . $aCategoryInfo['name'] . '</option>';
							}
						}
					?>
				</select>
				<select name="video_status" id="video_status">
					<option value="-1">请选择发布状态</option>
					<option value="1">显示</option>
					<option value="0">不显示</option>
				</select>
				<select name="is_recommend" id="is_recommend">
					<option value="-1">请选择推荐状态</option>
					<option value="1">推 荐</option>
					<option value="0">不推荐</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>		
		<div class="item">
			<div class="name">图片路径：</div>
			<div class="control"><input type="text" class="w650 readonly" id="thumb_url" name="thumb_url" readonly="readonly" /></div>
		</div>
		<div class="clear"></div>		
		<div class="item">
			<div class="name">文件路径：</div>
			<div class="control"><input type="text" class="w650 readonly" id="video_url" name="video_url" readonly="readonly" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">uemlook_ID：</div>
			<div class="control"><input type="text"id="umelook_id" name="umelook_id" readonly="readonly" class="readonly" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">播放时长：</div>
			<div class="control"><input type="text" id="video_duration" name="video_duration" readonly="readonly" class="readonly" /> 秒</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" onclick="videoAdd()" id="add_button"/>添 加</a></div>
		</div>
		<div class="clear"></div><br /><br />
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddMatchJs; ?>

	function videoAdd() {
		if (!checkForm()) {
			return false;
		}
		$.ajax({
			url: '/?m=Video&a=videoAdd',
			data: $('#videoAdd').serialize(),
			type: 'post',
			beforeSend: function(){$('#add_button').addClass('button_loading').html('处理中...').attr('onclick', '');},
			dataType: 'json',
			success: function(aResult){
				$('#add_button').removeClass('button_loading').html('添 加').attr('onclick', 'videoAdd()');
				if(aResult.status == 1){
					UBox.show(aResult.msg, aResult.status, '/?m=Video&a=showVideoList');
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error: function(){
				UBox.show('系统错误', 0);
				$('#add_button').removeClass('button_loading').html('添 加').attr('onclick', 'videoAdd()');
			}
		});
	
	}

//视频采集
	function getVideo() {
		var uemlookUrl = $.trim($('#uemlook_url').val());
		var reg = /^http:\/\/v.umelook.com\/\?m=video&vid=\d+$/;
		if (!reg.test(uemlookUrl)) {
			UBox.show('视频URL 错误', -1);
			return;
		}
		var vid = uemlookUrl.replace('http://v.umelook.com/?m=video&vid=', '');
		if (vid < 1) {
			UBox.show('视频URL 错误', -1);
			return;
		}

		$.ajax({
			url: '/?m=Video&a=getVideoInfo',
			data: {id: vid},
			beforeSend: function(){$('#get_video_button').addClass('button_loading').html('处理中...').attr('onclick', '');},
			type: 'post',
			dataType: 'json',
			success: function(aResult) {
				$('#get_video_button').removeClass('button_loading').html('解 析').attr('onclick', 'getVideo()');
				UBox.show(aResult.msg, aResult.status);
				if (aResult.status == 1) {
						setVideoForm(aResult.data);
						$('#videoAdd').show(400);
				}else{
					setVideoForm();
					$('#videoAdd').hide(400);
				}
			},
			error: function() {
				$('#get_video_button').removeClass('button_loading').html('解 析').attr('onclick', 'getVideo()');
				UBox.show('系统错误', 0);
				setVideoForm();
				$('#videoAdd').hide(400);
			}
		});
	}

	//显示视频信息表单
	function setVideoForm(videoData) {
		if(videoData){
			$('#umelook_id').val(videoData.id);
			$('#video_title').val(videoData.title);
			$('#thumb_url').val(videoData.thumb_url);
			$('#umelook_id').val(videoData.id);
			$('#video_title').val(videoData.title);
			$('#video_url').val(videoData.video_url);
			$('#video_duration').val(videoData.duration);
			$('#video_views').val(videoData.views);
			$('#video_description').val(videoData.description);
			if(videoData.tran_url){
				$('#is_trans').val('1');
			}else{
				$('#is_trans').val('0');
			}
			
			$('#thumb_img').attr('src', videoData.thumb_url);
			showVideoPlayer(videoData.play_url);
		}else{
			document.getElementById('videoAdd').reset();
			$('#thumb_img').attr('src', '');
			$('#playBox').html('');
		}
	}
	
	
	function showVideoPlayer(url){
		PlayerCode = '<embed id="videoBox" name="videoBox" src="http://v.umelook.com/plugins/player/player.swf?dn=v&vid=' + url + '" allowFullScreen="true" wmode="opaque" quality="high" width="400" height="225" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" autostart="false" ></embed>';
		$('#playBox').html(PlayerCode);
	}
	//刷新页面重置表单		
	$(function() {
		document.getElementById('videoAdd').reset();
	});

</script>