<?php display('video/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		select{margin-right:15px;padding:0 3px;}
		._main .item .control .button_loading{ background-color: #666}
	</style>
	<form id="categorytEdit" class="editForm">
		<div class="title">编辑视频分类</div>
		<div class="item">
			<div class="name">分类标题：</div>
			<div class="control">
				<input type="text" name="category_name" id="category_name" value="<?php echo $aCategoryInfo['name']; ?>" />
				<input type="hidden" name="category_id" id="category_id" value="<?php echo $aCategoryInfo['id']; ?>" />
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">是否显示：</div>
			<div class="control">				
				<select name="category_status" id="category_status">
					<option value="-1">请选择</option>
					<option value="1" <?php if($aCategoryInfo['status'] == 1){echo 'selected="selected"';} ?>>显示</option>
					<option value="0" <?php if($aCategoryInfo['status'] == 0){echo 'selected="selected"';} ?>>不显示</option>
				</select>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name"></div>
			<div class="control"><a class="button" onclick="categoryEdit()" id="edit_button" />保 存</a></div>
		</div>
		<div class="clear"></div><BR><BR>
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddMatchJs; ?>

function _after_category_name(){
	var categoryStatus = $('#category_status').val();
	if(categoryStatus != 1 && categoryStatus != 0){
		UBox.show('请选择显示状态', -1);
		return false;
	}
	return true;
}

//刷新页面重置表单		
$(function(){
	document.getElementById('categorytEdit').reset();
});

function categoryEdit(){
	if(!checkForm()){
		return false;
	}
	$.ajax({
		url: '/?m=Video&a=categoryEdit',
		data: $('#categorytEdit').serialize(),
		beforeSend: function(){$('#edit_button').addClass('button_loading').html('处理中...').attr('onclick', '');},
		type: 'post',
		dataType: 'json', 
		success: function(aResult){
			$('#edit_button').removeClass('button_loading').html('保 存').attr('onclick', 'categoryEdit()');
			if(aResult.status == 1){
				UBox.show(aResult.msg, aResult.status, '/?m=Video&a=showCategoryList');
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		},
		error: function(){
			UBox.show('系统错误', 0);
			$('#edit_button').removeClass('button_loading').html('保 存').attr('onclick', 'categoryEdit()');
		}
	});
}
</script>