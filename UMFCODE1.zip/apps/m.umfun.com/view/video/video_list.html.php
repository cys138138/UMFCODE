<?php display('video/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		._conditon .width150{width:150px;}
		.status a{color:#999; margin-right:10px;}
		.status .on{font-weight:bold; color:#000;}
		._condition .name{width:40px;}
		._condition .control input{width:140px;}
		._condition a.button{color:#FC0; margin-left:5px;}
	</style>
	<form>
		<div class="item">
			<div class="name width150">
				<select name="searchType" id="searchType">
					<option value="">搜索类型</option>
					<option value="1" <?php if(get('searchType') == 1){echo 'selected="selected"';} ?>>视频标题</option>
					<option value="2" <?php if(get('searchType') == 2){echo 'selected="selected"';} ?>>视频ID</option>
					<option value="3" <?php if(get('searchType') == 3){echo 'selected="selected"';} ?>>UMELOOK ID</option>
				</select>
			</div>
			<div class="control"><input type="text" name="searchValue" id="searchValue" value="<?php echo get('searchValue');?>"/></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="videoSearch(1);">搜索</a>
			</div>
		</div>
	
		<div class="clear"></div>

		<div class="item">
			<div class="name width80">视频分类：</div>
			<div class="control">
				<select name="categoryId" id="categoryId">
					<option value="">请选择</option>					
					<?php 
						foreach($aCategoryList as $aCategoryInfo){
							if(get('categoryId') == $aCategoryInfo['id']){
								echo '<option value="' . $aCategoryInfo['id'] . '" selected="selected">' . $aCategoryInfo['name'] . '</option>';
							}else{
								echo '<option value="' . $aCategoryInfo['id'] . '">' . $aCategoryInfo['name'] . '</option>';
							}
						}
					?>
				</select>
			</div>
			<div class="name width80">显示状态：</div>
			<div class="control">
				<select name="videoStatus" id="videoStatus">
					<option value="-1">请选择</option>
					<option value="0" <?php if(get('videoStatus') == '0'){echo 'selected="selected"';}?>>不显示</option>
					<option value="1" <?php if(get('videoStatus') == '1'){echo 'selected="selected"';}?>>显  示</option>
				</select>
			</div>
			<div class="name width80">推荐状态：</div>
			<div class="control">
				<select name="videoRecommend" id="videoRecommend">
					<option value="-1">请选择</option>
					<option value="0" <?php if(get('videoRecommend') == '0'){echo 'selected="selected"';}?>>未推荐</option>
					<option value="1" <?php if(get('videoRecommend') == '1'){echo 'selected="selected"';}?>>推  荐</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="videoSearch(2);">搜索</a>
			</div>
		</div>
	</form>
	<script type="text/javascript">

		function videoSearch(type){
			var url = '?m=Video&a=showVideoList';
			if(type == 1){
				var searchType = $('#searchType').val();
				var searchValue = $.trim($('#searchValue').val());
				var idReg = /^[1-9]+\d*$/;
				if(!searchType || !searchValue){
					UBox.show('请选择搜索类型并输入搜索内容', -1);
					return;
				}
				if(searchType == 2 && !idReg.test(searchValue)){
					UBox.show('视频ID为正整数', -1);
					return;	
				}
				url += "&searchType=" + searchType + '&searchValue=' + searchValue;
				window.location.href = url;
			}else if(type == 2){
				var categoryId = $('#categoryId').val();
				var videoStatus = $('#videoStatus').val();
				var videoRecommend = $('#videoRecommend').val();
				if(categoryId > 0){
					url += '&categoryId='+categoryId;
				}
				if(videoStatus == 0 || videoStatus == 1){
					url += '&videoStatus='+videoStatus;
				}
				if(videoRecommend == 0 || videoRecommend == 1){
					url += '&videoRecommend='+videoRecommend;
				}
				window.location.href = url;
			}
		}
	</script>
</div>
<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
		._userList .list .c1{width:160px;}
		._userList .list .c2{width:120px;}
		._userList .list .c3{width:80px;}
		._userList .list .c4{width:80px;}
		._userList .list .c5{width:80px;}
		._userList .list .c6{width:60px;}
		._userList .list .c7{width:50px;}
		._userList .list .c8{width:115px;}
		._userList .list .c10{width:70px;}
		._userList .list .row .c10 a{padding-right:7px;}
	</style>
	<div class="title">视频列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">视频标题</div>
			<div class="c2">视频分类</div>
			<div class="c3">显示状态</div>
			<div class="c4">推荐状态</div>
			<div class="c5">UMELOOK ID</div>
			<div class="c6">播放次数</div>
			<div class="c7">时长</div>
			<div class="c8">创建时间</div>
			<div class="c10 right">操作</div>
		</div>
		<?php if($aVideoList){
			foreach($aVideoList as $aVideoInfo){ ?>
			<div class="row">
				<div class="c1" title="<?php echo $aVideoInfo['title'] ? $aVideoInfo['title'] : '&nbsp;'; ?>">
					<?php echo $aVideoInfo['title'] ? $aVideoInfo['title'] : '&nbsp;'; ?>
				</div>
				<div class="c2">
					<?php 
						$hasCategory = 0;
						foreach($aCategoryList as $aCategoryInfo){
							if($aCategoryInfo['id'] == $aVideoInfo['category_id']){
								echo '<a title="查看分类下所有视频" href="/?m=Video&a=showVideoList&categoryId=' . $aCategoryInfo['id'] . '" >' . $aCategoryInfo['name'] . '</a>';
								$hasCategory = 1;
								break;
							}
						}
						if($hasCategory == 0){
							echo '<a>末知分类</a>';
						}
					?>
				</div>
				<div class="c3"><?php echo $aVideoInfo['status'] == 1 ? '显示' : '不显示'; ?></div>
				<div class="c4"><?php echo $aVideoInfo['is_recommend'] == 1 ? '推荐' : '未推荐'; ?></div>
				<div class="c5"><?php echo $aVideoInfo['umelook_id'] ? $aVideoInfo['umelook_id'] : '&nbsp;'; ?></div>
				<div class="c6"><?php echo $aVideoInfo['views'] ? $aVideoInfo['views'] : '&nbsp;' ; ?></div>
				<div class="c7"><?php echo $aVideoInfo['duration'] ? $aVideoInfo['duration'] : '&nbsp;' ; ?> S</div>
				<div class="c8"><?php echo date('Y-m-d H:i:s', $aVideoInfo['create_time']); ?></div>
				<div class="c10 right">
					<a href="/?m=Video&a=showVideoEdit&id=<?php echo $aVideoInfo['id']?>">编辑</a>
					<a href="javascript:void(0)" onclick="delVideoById(<?php echo $aVideoInfo['id']; ?>)">删除</a>
				</div>
			</div>
		<?php }
		}else{
			echo '<font color=red>抱歉，暂时缺乏数据！</font>';
		} ?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	function delVideoById(id){
		UBox.confirm('确定删除这条视频数据吗?', function(){
			$.ajax({
				url : '/?m=Video&a=delVideo',
				data : {videoId : id},
				type : 'post',
				dataType : 'json',
				success : function(aResult){
					if(aResult.status == 1){
						window.location.reload();
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(){
					UBox.show('系统错误', 0);
				}
			});
		});
	}
</script>