<?php display('school/school_nav.html.php'); ?>
<div class="module _userList">
	<style type="text/css">
 		._userList .list .c1{width:250px;}
		._userList .list .c2{width:220px;}
		._userList .list .c3{width:70px;}
		._userList .list .c4{width:70px;}
		._userList .list .row .c5 a{padding-right:7px;}
	</style>
	<div class="title"><?php echo $schoolName; ?>&nbsp;--&nbsp;相似学校列表</div>
	<div class="list">
		<div class="row header">
			<div class="c1">名字</div>
			<div class="c2">地区</div>
			<div class="c3">人数</div>
			<div class="c4">类型</div>

			<div class="c5 right">操作</div>
		</div>
		<?php foreach($aSchoolList as $aSchool){ ?>
			<div class="row">
				<div class="c1"><?php echo $aSchool['name']; ?></div>
				<div class="c2"><?php echo $aSchool['province_name']; ?>&nbsp;-&nbsp;<?php echo $aSchool['city_name']; ?>&nbsp;-&nbsp;<?php echo $aSchool['district_name']; ?></div>
				<div class="c3"><?php echo $aSchool['member_nums']; ?></div>
				<div class="c4"><?php if($aSchool['type'] == 0 || $aSchool['type'] == ''){echo '用户创建'; }elseif($aSchool['type'] == 1){echo '小学'; }elseif($aSchool['type'] == 2){echo '初中'; }elseif($aSchool['type'] == 3){echo '高中'; } ?></div>
				<div class="c5 right"><a onclick="deleteSchool(<?php echo $aSchool['id']; ?>);">删除</a></div>
			</div>
		<?php } ?>
	</div>
</div>
<?php setRefererMark(); ?>
<script type="text/javascript">
	function deleteSchool(index){
		UBox.confirm('你确定删除吗？',
			function(){
				$.post('?m=School&a=delete', {id : index}, function(result){
					UBox.show(result.msg, result.status, 'reload');
				});
			}
		);
	}

</script>