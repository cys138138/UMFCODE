<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=School&a=showList">学校列表</a>
	<?php if(get('a') == 'searchSimilarSchool'){ ?>
		<a class="on">相似学校列表</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
	<?php if(get('a') == 'showEditSchool'){ ?>
		<a class="on">编辑学校</a>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>

<div class="br"></div>
