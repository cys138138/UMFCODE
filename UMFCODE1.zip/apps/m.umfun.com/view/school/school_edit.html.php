<?php display('school/school_nav.html.php'); ?>
<div class="module _school_info">
	<style type="text/css">
 		._school_info .school_list .c1{width:300px; color:#000;}
 		._school_info .school_list .c1 input{width:250px; color:#000;}
		._school_info .school_list .c2{width:60px; color:#000;}
		._school_info .school_list .c3{width:80px; color:#000;}
		._school_info .school_list .row .c4 a{padding-right:7px;}
		._school_info .school_list .on{background-color:#e0e0e0;}
	</style>
	<div class="title">学校信息</div>
	<div class="list school_list">
		<div class="row header">
			<div class="c1">名字</div>
			<div class="c2">人数</div>
			<div class="c3">学校类型</div>
			<div class="c4 right">操作</div>
		</div>
		<form id="edit_school">
			<input type="hidden" name="school_id" value="<?php echo $aSchool['id']; ?>" />
			<input type="hidden" name="area_id" value="<?php echo $aSchool['area_id']; ?>" />
			<div class="row">
				<div class="c1"><input type="text" name="school_name" value="<?php echo $aSchool['name']; ?>" /></div>
				<div class="c2"><?php echo $aSchool['member_nums']; ?></div>
				<div class="c3">
					<select name="type">
						<option value="0" <?php if($aSchool['type'] == 0 || $aSchool['type'] == ''){echo 'selected="selected"'; } ?> >用户创建</option>
						<option value="1" <?php if($aSchool['type'] == 1){echo 'selected="selected"'; } ?> >小学</option>
						<option value="2" <?php if($aSchool['type'] == 2){echo 'selected="selected"'; } ?> >初中</option>
						<option value="3" <?php if($aSchool['type'] == 3){echo 'selected="selected"'; } ?> >高中</option>
					</select>
				</div>
				<div class="c4 right">
					<a onclick="setSchoolType()">保存</a>
				</div>
			</div>
		</form>
		<div class="row footer">
		</div>
	</div>
</div>

<script type="text/javascript">
	<?php echo $editSchoolValidateJs; ?>
	
	function setSchoolType(){
		UBox.confirm(
			'你确定保存吗？',
			function(){
				$.ajax({
					type : 'post',
					dataType : 'json',
					url : '?m=School&a=editSchool', 
					data : $('form[id=edit_school]').serialize(),
					success : function(result){
						UBox.show(result.msg, result.status, 'reload');
					},
					error : function(request){
						UBox.show('抱歉！系统出错，请稍后再试！');
					}
				});
			}
		);
	}
</script>