<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('school/school_nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		.module{min-width:1300px;}
		._conditon ._select .name{width:85px;}
		._conditon ._select .control a{width:30px;}
		.item .control a{margin: 0 7px;}
		.item .name{margin: 0 10px;}
	</style>
	<form id="schoolForm">
		<div class="item">
			<div class="name">地区：</div>
			<div class="control">
				<select id="province_id" name="province_id" onchange="clearSelectSchool()"></select>
				<select id="city_id" name="city_id" onchange="clearSelectSchool()" ></select>
				<select id="areaId" name="areaId"></select>
			</div>
		</div>

		<div class="item _select">
			<div class="name">选择学校类型：</div>
			<div class="control">
				<select name="school_type" id="school_type">
					<option <?php if($schoolType == -1){ echo 'selected="selected"'; } ?> value="-1">全部</option>
					<option <?php if($schoolType == 1){ echo 'selected="selected"'; } ?> value="1">小学</option>
					<option <?php if($schoolType == 2){ echo 'selected="selected"'; } ?> value="2">初中</option>
					<option <?php if($schoolType == 3){ echo 'selected="selected"'; } ?> value="3">高中</option>
					<option <?php if($schoolType == 0){ echo 'selected="selected"'; } ?> value="0">用户创建</option>
				</select>
			</div>
		</div>
		<div class="item">
			<div class="control"><a class="button" onclick="searchSchool();">确定</a></div>
		</div>
		<div class="item">
			<div class="name">新增学校名称：</div>
			<div class="control">
				<input type="text" name="school_name" id="school_name" value="" />
			</div>
		</div>
		<div class="item">
			<div class="control"><a class="button" onclick="addSchool();">添加</a></div>
		</div>
	</form>
</div>
<div class="clear"></div>
<div class="module _userList">
	<style type="text/css">
 		._userList .school_list{width:690px; height:652px; float:left; overflow-y:scroll; border:1px solid #CCCCCC; margin-right:20px;}
 		._userList .school_list .c1{width:280px; color:#000;}
		._userList .school_list .c2{width:40px; color:#000;}
		._userList .school_list .c3{width:50px; color:#000;}
		._userList .school_list .row .c4 a{padding-right:7px;}
		._userList .school_list .on{background-color:#e0e0e0;}
	</style>
	<div class="title">学校列表</div>
	<div class="list school_list">
		<div class="row header">
			<div class="c1">名字</div>
			<div class="c2">人数</div>
			<div class="c3">类型</div>
			<div class="c4 right">操作</div>
		</div>
		<?php foreach($aSchoolList as $aSchool){ ?>
			<div class="row" itemid="<?php echo $aSchool['id']; ?>">
				<div class="c1"><?php echo $aSchool['name']; ?></div>
				<div class="c2"><?php echo $aSchool['member_nums']; ?></div>
				<div class="c3">
					<?php if($aSchool['type'] == 1){echo '小学'; }elseif($aSchool['type'] == 2){echo '初中'; }elseif($aSchool['type'] == 3){echo '高中'; }else{echo '用户创建'; } ?>
				</div>
				<div class="c4 right">
					<a onclick="deleteSchool(<?php echo $aSchool['id']; ?>);">删除</a>
					<a onclick="searchSimilarSchool('<?php echo $aSchool['name']; ?>')">查看相似学校</a>
					<a href="?m=School&a=showEditSchool&school_id=<?php echo $aSchool['id'] ;?>">编辑</a>
					<a onclick="showClass(<?php echo $aSchool['id']; ?>, '<?php echo $aSchool['name']; ?>');">查看班级</a>
				</div>
			</div>
		<?php } ?>
		<div class="row footer">
			<style type="text/css">
				.school_list .footer .pagination .select input{height:auto;}
			</style>
		<?php echo $pageHtml; ?>
		</div>
	</div>

	<div class="class_list">
		<style type="text/css">
			._userList .class_list{width:580px; height:652px; overflow-y:scroll; border:1px solid #CCCCCC; float:left;}
			._userList .classValue{margin:10px 10px 0 10px;}
			._userList ._list_ .row .c1{width:80px;}
			._userList ._list_ .row .c2{width:180px;}
			._userList ._list_ .row .c3{width:40px;}
			._userList ._list_ .row .c4 a{margin:0 3px;}
		</style>
		<div class="classValue"></div>
	</div>
</div>

<script type="text/javascript">
	$(function(){
		var oAddressInit = new addressInit('province_id', 'city_id', 'areaId', '<?php echo $provinceId; ?>', '<?php echo $cityId; ?>', '<?php echo $areaId; ?>');
		oAddressInit.load();
	});

	function clearSelectSchool(){
		$('#areaSchool').html('');
	}

	function searchSchool(){
		var schoolType = $('#school_type').val();
		var url = '?m=School&a=showList&school_type=' + schoolType ;
		var provinceId = $('#province_id').val();
		var cityId = $('#city_id').val();
		var districtId = $('#areaId').val();
		if(provinceId){
			url += '&province_id=' + provinceId;
		}
		if(cityId){
			url += '&city_id=' + cityId;
		}
		if(districtId){
			url += '&areaId=' + districtId;
		}
		location.href = url;
	}

	function deleteSchool(index){
		UBox.confirm(
			'确定删除吗？',
			function(){
				$.ajax({
					type : 'post',
					dataType : 'json',
					url : '?m=School&a=delete', 
					data : {id : index}, 
					success : function(result){
						UBox.show(result.msg, result.status, 'reload');
					},
					error : function(request){
						UBox.show('系统错误！请稍后再试！');
					}
				});
			}
		);
	}
	
	<?php echo $addSchoolValidateJs; ?>

	function addSchool(){
		if(!checkForm){
			return false;
		}
		$.ajax({
			type : 'post',
			dataType : 'json',
			url : '?m=School&a=add', 
			data : $('#schoolForm').serialize(), 
			success : function(result){
				UBox.show(result.msg, result.status);
			},
			error : function(request){
				UBox.show('抱歉！系统错误，请稍后再试！');
			}
		});
	}

	function searchSimilarSchool(schoolName){
		var url = '?m=School&a=searchSimilarSchool&school_name=' + schoolName;
		var provinceId = $('#province_id').val();
		var cityId = $('#city_id').val();
		var districtId = $('#areaId').val();
		if(provinceId){
			url += '&province_id=' + provinceId;
		}
		if(cityId){
			url += '&city_id=' + cityId;
		}
		if(districtId){
			url += '&district_id=' + districtId;
		}
		location.href = url;
	}

	function showClass(index, schoolName){
		$('.classValue').html('');
		$('.row').removeClass('on');
		$('.row[itemid="' + index + '"]').addClass('on');
		$.ajax({
			type : 'post',
			dataType : 'json',
			url : '?m=School&a=showClassList', 
			data : {id : index}, 
			success : function(result){
				var classList = result.data;
				var htmlCode = '', grade = '', className = '', classNums = 0, classId = 0;

				for(var i = 0; i < classList.length; i++){
					grade = classList[i].grade;
					className = classList[i]['class'];
					classNums = classList[i].nums;
					htmlCode += '<div class="row"><div class="c1">' + grade + '</div><div class="c2 ' + 'c2_' + index + '_' + grade + '_' + className + '">' + className + '</div><div class="c3">' + classNums + '</div><div class="c4 ' + 'c4_' + index + '_' + grade + '_' + className + ' right"><a onclick="deleteClass(' + index + ',' + grade + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ');">删除</a><a onclick="editClass(' + index + ',' + grade + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ')">编辑</a></div></div>';
				}
				$('.classValue').html('<div class="item"><div class="name">学校：' + schoolName +'</div></div><div class="clear"></div><div class="item"><div class="name">选择年级</div><div class="control"><select name="grade" id="grade"><option value="5">五年级</option><option value="6">六年级</option><option value="7">七年级</option><option value="8">八年级</option><option value="9">九年级</option></select></div><div class="name">新增班级名称：</div><div class="control"><input type="text" name="class_name" id="class_name" value="" /></div></div><div class="item"><div class="control"><a class="button" onclick="addClass(' + index +  ',' +  "'" +schoolName + "'" + ');">增加</a></div></div><div class="clear"></div><div class="list _list_"><div class="row"><div class="c1">年级</div><div class="c2">班级</div><div calss="c3">人数</div><div class="c4 right">操作</div></div>' + htmlCode + '</div>');
			},
			error : function(request){
				UBox.show('抱歉！系统错误，请稍后再试！');
			}
		});
	}

	function addClass(index, schoolName){
		var className = $('#class_name').val();
		var gradeName = $('#grade').val();
		$.ajax({
			type : 'post',
			dataType : 'json',
			url : '?m=School&a=addClass', 
			data : {class_name : className, grade : gradeName, school_id : index}, 
			success : function(result){
				UBox.show(result.msg, result.status, result.data);
				showClass(index, schoolName);
			},
			error : function(request){
				UBox.show('系统出错，请稍后再试！');  
			}
		});
	}

	function deleteClass(index, gradeName, className, schoolName){
		UBox.confirm('确定删除？',function(){
			$.ajax({
				type : 'post',
				dataType : 'json',
				url : '?m=School&a=deleteClass', 
				data : {school_id : index, grade : gradeName, class_name : className}, 
				success : function(result){
					UBox.show(result.msg, result.status);
					showClass(index, schoolName);
				},
				error : function(request){
					UBox.show('抱歉！系统出错，请稍后再试！');
				}
			});
		})
	}

	function editClass(index, gradeName, className, schoolName){
		$('.c2_' + index + '_' + gradeName + '_' + className).html('');
		$('.c2_' + index + '_' + gradeName + '_' + className).html('<input type="text" id="' + index + '_' + gradeName + '_' + className + '" value="' + className +'">');
		$('.c4_' + index + '_' + gradeName + '_' + className).html('<a onclick="saveClassName(' + index + ',' + gradeName + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ',' + 1 +')">保存</a><a onclick="saveClassName(' + index + ',' + gradeName + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ',' + 2 +')">取消</a>');
	}

	function saveClassName(index, gradeName, className, schoolName, action){
		if(action == 1){
			var newClassName = $('#' + index + '_' + gradeName + '_' + className).val();
			$('.c2_' + index + '_' + gradeName + '_' + className).html('');
			$('.c2_' + index + '_' + gradeName + '_' + className).html(newClassName);
			if(className == newClassName){
				UBox.show('您没有修改！', -1);
				$('.c2_' + index + '_' + gradeName + '_' + className).html('');
				$('.c2_' + index + '_' + gradeName + '_' + className).html(className);
				$('.c4_' + index + '_' + gradeName + '_' + className).html('<a onclick="deleteClass(' + index + ',' + gradeName + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ');">删除</a><a onclick="editClass(' + index + ',' + gradeName + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ')">编辑</a>');
				return false;	
			}
			$.ajax({
				type : 'post',
				dataType : 'json',
				url : '?m=School&a=saveClassName', 
				data : {school_id : index, grade : gradeName, oldClassName : className, newClassName : newClassName}, 
				success : function(result){
					UBox.show(result.msg, result.status);
					showClass(index, schoolName);
				},
				error : function(){
					UBox.show('抱歉！系统出错，请稍后再试！');
				}
			});	
		}else{
			$('.c2_' + index + '_' + gradeName + '_' + className).html('');
			$('.c2_' + index + '_' + gradeName + '_' + className).html(className);
			$('.c4_' + index + '_' + gradeName + '_' + className).html('<a onclick="deleteClass(' + index + ',' + gradeName + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ');">删除</a><a onclick="editClass(' + index + ',' + gradeName + ',' + "'" + className + "'" + ',' + "'" + schoolName + "'" + ')">编辑</a>');
		}	
	}
</script>