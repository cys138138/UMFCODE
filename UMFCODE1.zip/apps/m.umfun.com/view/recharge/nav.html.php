<div class="nav">
	<a <?php if(str_replace('\\', '', get('a')) == 'showRechargeList'){ ?>class="on"<?php } ?> href="?m=Recharge&a=showRechargeList">充值记录列表</a>
	<a <?php if(get('a') == 'showStatistics'){  ?>class="on"<?php } ?> href="#">统计</a>
	<?php if(str_replace('\\', '', get('a')) == 'showRechargeInfo'){ echo get('a');?><a class="on">订单详情</a><?php }?>
	<?php if(get('a') == 'showRechargeList'){ ?>
		<a href="<?php echo getReferer(); ?>">返回上一页</a>
	<?php } ?>
</div>

<div class="br"></div>
