<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['place_selector']; ?>"></script>
<?php display('recharge/nav.html.php'); ?>
<div class="module _conditon">
	<style type="text/css">
		._conditon .name{width:50px;}
		._conditon .width80{width:80px;}
		._conditon .width100{width:100px;}
		._conditon label{width:40px;}
		._conditon .control input[type="text"]{width:150px;}
		._conditon .control input.realName{width:100px;}
		._conditon ._ageInput input[type="text"]{width:60px;}
		._conditon ._quickTime a{color:#000000; margin-right:10px;}
	</style>

	<form>
		<div class="item">
			<div class="name width80">订单号：</div>
			<div class="control"><input type="text" name="rechargeId" id="rechargeId" value="<?php if($rechargeId){echo $rechargeId;}?>"  /></div>
			<div class="name width100">第三方订单号：</div>
			<div class="control"><input type="text" name="serialNumber" id="serialNumber" value="<?php if($serialNumber){echo $serialNumber;}?>" /></div>			
			<div class="blank"></div>
			<div class="name width100">会员数字编号：</div>
			<div class="control"><input type="text" name="userId" id="userId"  value="<?php if($userId){echo $userId;}?>" /></div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="rechargeSearch(1);">搜素</a>
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">金额(月数)：</div>
			<div class="control"><input type="text" name="quantity" id="quantity"  value="<?php if($quantity){echo $quantity;}?>" /></div>
			<div class="blank"></div>
			<div class="name width80">实付金额：</div>
			<div class="control"><input type="text" name="payMoney" id="payMoney" value="<?php if($payMoney){echo $payMoney;}?>" /></div>
			<div class="name width80">充值时间：</div>
			<div class="control"><input type="text" name="createTime" id="createTime"  onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})"  value="<?php if($createTime){echo $createTime;}?>" /></div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name width80">充值代理商：</div>
			<div class="control">
				<select name="byProxyId" id="byProxyId">
					<option value="">请选择</option>
					<?php if($proxyList){
						foreach($proxyList as $proxyKey=> $proxyInfo){
							if($byProxyId == $proxyInfo['id']){
								 echo '<option selected="selected" value='.$proxyInfo['id'].'>'.$proxyInfo['name'].'</option>';	
							}else{
								echo '<option value='.$proxyInfo['id'].'>'.$proxyInfo['name'].'</option>';
							}
						}
					}?>
					
				</select>
			</div>
			
			<div class="name width80">分红代理商：</div>
			<div class="control">
				<select name="proxyId" id="proxyId">
					<option value="">请选择</option>
					<?php if($proxyList){
						foreach($proxyList as $proxyKey=> $proxyInfo){
							if($proxyId == $proxyInfo['id']){
								 echo '<option selected="selected" value='.$proxyInfo['id'].'>'.$proxyInfo['name'].'</option>';	
							}else{
								echo '<option value='.$proxyInfo['id'].'>'.$proxyInfo['name'].'</option>';
							}
						}
					}?>
					
				</select>
			</div>
			
			
			<div class="name width80">支付方式：</div>
			<div class="control">
				<select name="payType" id="payType">
					<option value="">请选择</option>
					<?php if($payTypeList){
						foreach($payTypeList as $payKey=> $typeInfo){
							if($payType == $payKey){
								 echo '<option selected="selected" value='.$payKey.'>'.$typeInfo.'</option>';	
							}else{
								echo '<option value='.$payKey.'>'.$typeInfo.'</option>';
							}
						}
					}?>
				</select>
			</div>
			<div class="name width80">充值类型：</div>
			<div class="control">
			<?php if($isProxyCount != 1){?>
				<select name="type" id="type">
					<option value="">请选择</option>
					<option value="1" <?php if($type == '1'){echo 'selected="selected"';}?>>U币充值</option>
					<option value="2" <?php if($type == '2'){echo 'selected="selected"';}?>>月费充值</option>
				</select>
			<?php }else{ ?>
				<input type='radio' <?php if($type == '1'){echo 'checked="checked"';}?> name="type" value="1" />
				<span style="float:left; margin-right:10px; color:#000;">U币充值</span>
				<input type='radio' <?php if($type == '2'){echo 'checked="checked"';}?> name="type" value="2" />
				<span style="color:#000;">月费充值</span>
			<?php } ?>
			</div>

			<div class="name width80">订单状态：</div>
			<div class="control">
				<select name="payFinish" id="payFinish">
					<option value="">请选择</option>
					<option value="0" <?php if($payFinish == '0'){echo 'selected="selected"';}?>>失败</option>
					<option value="1" <?php if($payFinish == '1'){echo 'selected="selected"';}?>>成功</option>
				</select>
			</div>

			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="rechargeSearch(2);">筛选</a>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">

function rechargeSearch(type){
	var url = '?m=Recharge&a=showRechargeList&isProxyCount=<?php echo $isProxyCount; ?>&commission=<?php echo $commission; ?>';
	if(type == 1){
		var reg = /^\d{5,}$/;
		var rechargeId = $.trim($('#rechargeId').val());
		var serialNumber = $.trim($('#serialNumber').val());
		if(rechargeId){
			if(!reg.test(rechargeId)){
				UBox.show('订单号格式错误', -1);
				$('#rechargeId').select();
				return false;
			}
			url += '&rechargeId='+rechargeId;
		}
		
		if(serialNumber){
			url += '&serialNumber='+serialNumber;
		}

		var userId = $.trim($('#userId').val());
		if(userId){
			var userIdReg = /^\d{8,}$/;
			if(!userIdReg.test(userId)){
				UBox.show('会员数字帐号为8位会更长的纯数字字符串', -1);
				$('#userId').select();
				return false;
			}else{
				url += '&userId='+userId;
			}
		}
		window.location.href = url;
	}else if(type == 2){
		var quantity = $.trim($('#quantity').val());
		if(quantity){
			var quantityReg = /^\d{1,5}$/; 
			if(!quantityReg.test(quantity)){
				UBox.show('金额(月数)为1到10000之间的正整数', -1);
				$('#quantity').select();
				return false;
			}

			if(parseInt(quantity) < 1 || parseInt(quantity) > 10000){
				UBox.show('金额(月数)为1到10000之间的正整数', -1);
				$('#quantity').select();
				return false;
			}
			url += '&quantity='+quantity;
		}

		var payMoney = $.trim($('#payMoney').val());
		if(payMoney){
			var payMoneyReg = /^\d{1,5}(\.\d{1,2})?$/;
			if(!payMoneyReg.test(payMoney)){
				UBox.show('实付金额为0到10000之间的数字，可有两位小数aaa', -1);
				$('#payMoney').select();
				return false;
			}
			if(parseFloat(payMoney) < 0 || parseFloat(payMoney) > 10000){
				UBox.show('实付金额为0到10000之间的数字，可有两位小数', -1);
				$('#payMoney').select();
				return false;
			}

			url += '&payMoney='+payMoney;
		}

		var createTime = $.trim($('#createTime').val());
		if(createTime){
			url += '&createTime='+createTime;
		}

		var byProxyId = $('#byProxyId').val();
		if(byProxyId){
			url += '&byProxyId='+byProxyId;
		}
		
		var proxyId = $('#proxyId').val();
		if(proxyId){
			url += '&proxyId='+proxyId;
		}
		
		var type1 = $('#type').val();
		var type2 = $(':radio:checked').val();
		
		if(type1){
			url += '&type='+type1;
		}
		if(type2){
			url += '&type='+type2;
		}

		var payType = $('#payType').val();
		if(payType){
			url += '&payType='+payType;
		}
		
		var payFinish = $('#payFinish').val();
		if(payFinish){
			url += '&payFinish='+payFinish;
		}
		window.location.href = url;
		
	}
}
</script>

<div class="br"></div>
<div class="module _userList">
	<style type="text/css">
		._userList .list .c0{width:50px; color:#000; font-size:14px; }
		._userList .list .c1{width:70px;}
		._userList .list .c2{width:110px;}
		._userList .list .c3{width:60px;}
		._userList .list .c4{width:60px;}
		._userList .list .c5{width:80px;}
		._userList .list .c6{width:80px;}
		._userList .list .c7{width:100px;}
		._userList .list .c8{width:60px;}
		._userList .list .c9{width:120px;}
		._userList .list .c10{width:50px;}
		._userList .list .c11{width:60px;}
		._userList .list .row .c10 a{padding-right:5px;}
		._userList .list .row .fail{color:red}
	</style>
	
	<?php if($type == '2'  && ($isProxyCount == 1)){?>
		<div class="title">用户月费充值记录列表&nbsp;&nbsp;&nbsp;&nbsp;</div>
	<?php }else if($type == '1'  && ($isProxyCount == 1)){ ?>
		<div class="title">用户U币充值记录列表&nbsp;&nbsp;&nbsp;&nbsp;</div>
	<?php }else{ ?>
		<div class="title">用户充值记录列表</div>
	
	<?php } ?>
	<div class="list">
		<div class="row header">
		<?php if($isProxyCount == 1){?>
			<div class="c0">&nbsp;</div>
		<?php } ?>
			<div class="c1">订单号</div>
			<div class="c2">充值会员</div>
			<div class="c3">金额(月数)</div>
			<div class="c4">实付金额</div>
			<div class="c5">支付方式</div>
			<div class="c6">充值代理商</div>
			<div class="c6">分红代理商</div>
			<div class="c7">第三方订单号</div>
			<div class="c11">充值类型</div>
			<div class="c8">支付状态</div>
			<div class="c9">充值时间</div>
			<div class="c10 right">操作</div>
		</div>
		
		<?php if($aRechargeList){
			foreach($aRechargeList as $aRecharge){ 
			?>
			<div class="row">
			<?php if($isProxyCount == 1){?>
				<div class="c0">&nbsp;</div>
			<?php } ?>	
				<div class="c1"><?php echo $aRecharge['id']; ?></div>
				<div class="c2"><a title="<?php echo $aRecharge['user_id']; ?>" href="?m=Recharge&a=showRechargeList&userId=<?php echo $aRecharge['user_id']?>"><?php echo $aRecharge['userName']; ?></a></div>
				<div class="c3"><?php if($aRecharge['type'] == 1){ echo $aRecharge['quantity'] .' U币'; }elseif($aRecharge['type'] == 2){ echo $aRecharge['quantity'].' 个月'; }else{ echo '&nbsp;'; } ?></div>
				<div class="c4"><?php echo $aRecharge['pay_money'] ? $aRecharge['pay_money'] : '&nbsp;';?></div>
				<div class="c5"><?php echo $aRecharge['payTypeName'] ?  $aRecharge['payTypeName'] : '&nbsp;';?></div>
				<div class="c6"><?php echo $aRecharge['proxyName'] ? '<a title="查看代理商所有充值记录" href="?m=Recharge&a=showRechargeList&proxyId='.$aRecharge['proxy_user_id'].'">' . $aRecharge['proxyName'] . '</a>' : '&nbsp;';?></div>
				<div class="c6"><?php echo $aRecharge['proxyName'] ? '<a title="查看代理商所有充值记录" href="?m=Recharge&a=showRechargeList&proxyId='.$aRecharge['proxy_user_id'].'">' . $aRecharge['proxyName'] . '</a>' : '&nbsp;';?></div>
				<div class="c7"><?php echo $aRecharge['serial_number'] ? $aRecharge['serial_number'] : '&nbsp;';?></div>
				<div class="c11"><?php echo $aProductList[$aRecharge['type']]; ?></div>
				<div class="c8"><?php if($aRecharge['pay_finish'] == 1){ echo '成功'; }else{ echo '<span class="fail">失败</span>'; }?></div>
				<div class="c9"><?php if($aRecharge['create_time']){ echo date('Y-m-d H:i:s' , $aRecharge['create_time']); }?></div>
				
				
				<div class="c10 right"><a href="?m=Recharge&a=showRechargeInfo&id=<?php echo $aRecharge['id']; ?>">详情</a></div>
			</div>
		<?php } 
		}else{ echo '<font color=red>抱歉，暂时缺乏数据！</font>'; } ?>
		
		<?php if(isset($orderNumberCount) && ($isProxyCount == 1)){ ?>
		<div class="row footer">
			<div class="c0">总计</div>
			<div class="c1"><?php echo $orderNumberCount;?>(条)</div>
			<div class="c2">--</div>
			<div class="c3"><?php echo $quantityCount; if($type == '1'){echo '(U币)';}else{echo '(个月)';} ?></div>
			<div class="c4"><?php echo $pay_moneyCount; ?>(元)</div>
			
		</div>
		<?php } ?>
		
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>
