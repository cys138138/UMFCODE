<?php display('recharge/nav.html.php'); ?>
<?php if($aRechargeInfo){?>
	<div class="module _userInfo">
		<style type="text/css">
			._userInfo .item{padding:0 10px;}
			._userInfo .item .name{width:100px;}
			._userInfo .item .control input{width:200px;}	
		</style>
		<div class="title">充值详情</div>
		<div class="item">
			<div class="name">订单号：</div>
			<div class="control">
				<input disabled="disabled" type="text" value="<?php echo $aRechargeInfo['id']; ?>" />
			</div>
			<div class="name">充值会员：</div>
			<div class="control">
				<input disabled="disabled" type="text" value="<?php echo $aRechargeInfo['usrName']; ?>" />
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">充值金额：</div>
			<div class="control">
				<input disabled="disabled" type="text"  value="<?php echo $aRechargeInfo['quantity']; ?>" />
			</div>
			<div class="name">实付金额：</div>
			<div class="control">
				<input disabled="disabled" type="text"  value="<?php echo $aRechargeInfo['pay_money'];?>" />
			</div>	
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name">支付方式：</div>
			<div class="control">
				<input disabled="disabled" type="text" value="<?php echo $aRechargeInfo['payTypeName'];?>" />
			</div>
			<div class="name">代理商：</div>
			<div class="control">
				<input disabled="disabled" type="text"  value="<?php echo $aRechargeInfo['proxyName'];?>" />
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">第三方订单号：</div>
			<div class="control">
				<input disabled="disabled" type="text" value="<?php echo $aRechargeInfo['serial_number'];?>" />
			</div>
			<div class="name">充值时间：</div>
			<div class="control">
				<input disabled="disabled" type="text"  value="<?php if($aRechargeInfo['create_time']){echo date('Y-m-d H:i:s' , $aRechargeInfo['create_time']);}?>" />
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">订单状态：</div>
			<div class="control">
				<input disabled="disabled" type="text" value="<?php if($aRechargeInfo['pay_finish'] == 1){echo '成功';}else{echo '失败';}?>" />
			</div>
			<div class="name">UB是否到帐：</div>
			<div class="control">
				<input disabled="disabled" type="text"  value="<?php if($aRechargeInfo['ub_finish'] == 1){echo '己到帐';}else{echo '末到帐';}?>" />
			</div>
		</div>
		<div class="clear"></div>
		<div class="item">
			<div class="name">&nbsp;</div>
			<div class="control">
				<a href="?m=Recharge&a=showRechargeList">返回</a>
			</div>
		</div>
	
		<div class="br"></div>
		<div class="br"></div>
	</div>

<?php 
	}else{
		echo '<font color=red>此记录不存在！</font>';
	} 
?>
