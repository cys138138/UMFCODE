<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<?php display('service/nav.html.php'); ?>

<style type="text/css">
	._feedback .row div{line-height: 28px;cursor: pointer;}
	._feedback .row:hover{background-color:#D9E4EE !important;}
	._feedback .list .c1{width:40px;}
	._feedback .list .c2{width:100px;}
	._feedback .list .c3{width:200px;}
	._feedback .list .c4{width:150px;}
	._feedback .list .c4 a{padding-right:7px;}
	._feedback .list .c5{width:600px; overflow: hidden;}
	._feedback .list .checkOff{color:red;}
	._feedback .list .checkOn{color:grey;}
	._feedback .item .control a{ margin:0 5px;}
	._feedback .item .control a:hover{ color:#000;}
	._feedback .item .control a.check{color: #FC0;border-bottom: 3px solid;background: #000;padding: 2px;}
	._feedback .button:hover{background:#696969;}
	label{width: 100%;}
	label.button{width:80px; text-align: center;}
	#tips.tips{z-index: 9;position: absolute;border-radius: 4px;width: 350px;padding: 5px;background-color: #FAFAFA; box-shadow: 0px 2px 12px rgba(0, 0, 0, 0.3);	word-break:break-all;  overflow:auto;white-space:normal;border: 1px solid #90ABC5;}
</style>
<div class="module _feedback">
	<div class="item">
		<div class="name">按处理状态： </div>
		<div class="control">
			<a href="?m=Service&a=showFeedBack&isHandled=-1" <?php echo get('isHandled',-10) == -10 ? 'class="check"' : '';?>>全部</a>
			<a href="?m=Service&a=showFeedBack&isHandled=0"  <?php echo get('isHandled', -10) == 0 ? 'class="check"' : '';?>>未处理</a>
			<a href="?m=Service&a=showFeedBack&isHandled=1"  <?php echo get('isHandled', -10) == 1 ? 'class="check"' : '';?>>以处理</a>
			</div>
		<div class="blank"></div>
		<div class="control">
		</div>
	</div>
	<div class="br"></div>
	<div class="item">
		<div class="name">按分类筛选：</div>
		<div class="control">
			<?php
			 foreach( $aFromatFeedBackType as $aTypeId => $aTyteName){
				$thisType =  get('type') == $aTypeId ? ' class="check"' : '';
				echo '<a href="?m=Service&a=showFeedBack&type=' . $aTypeId . '" ' . $thisType  . '>' . $aTyteName . '</a>';
			}?>
			</div>
		<div class="blank"></div>
		<div class="control">
		</div>
	</div>
	<div class="br"></div>
	<div class="item">
		<div class="name">自定义：</div>
		<div class="control">
			<input type="text" id="start_time" value="<?php echo get('starteTime'); ?>" name="start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
			-
			<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo get('endTime'); ?>" type="text" id="end_time" name="end_time" />
		</div>
		<div class="blank"></div>
		<div class="control">
			<a class="button" id="diySearch">查看</a>
		</div>
	</div>
	<div class="clear"></div>

	<div class="list" id="feedBackList">
			<div class="title">反馈列表</div>
			<div class="row header">
				<div class="c1">ID</div>
				<div class="c2">姓名</div>
				<div class="c2">用户ID</div>
				<div class="c3">联系方式</div>
				<div class="c2">类别</div>
				<div class="c3">反馈时间</div>
				<div class="c5">描述内容</div>
				<div class="c4 right">操作</div>
			</div>
			<?php
			if(!empty($aFeedBackList)){
			foreach($aFeedBackList as $aFeedBack){
				$testUserClass = in_array($aFeedBack['user_id'], $GLOBALS['TEST_USER_LIST']) ? ' testUser' : ''; ?>
				<div class="row"><label>
					<div class="c1">
						<input name="feedBackId_<?php echo $aFeedBack['id']; ?>" type="checkbox" value="<?php echo $aFeedBack['id']; ?>" id="feedBackId_<?php echo $aFeedBack['id']; ?>">
						<?php echo $aFeedBack['id']; ?>
					</div>
					<div class="c2 <?php echo $testUserClass; ?>"><span class="name"><?php echo $aFeedBack['name']; ?></span></div>
					<div class="c2"><?php echo $aFeedBack['user_id'] ? $aFeedBack['user_id'] : '--'; ?></div>
					<div class="c3"><?php echo $aFeedBack['contact']; ?></div>
					<div class="c2"><?php
					if(isset($aFromatFeedBackType[$aFeedBack['type']])){
						echo $aFromatFeedBackType[$aFeedBack['type']];
					}else{
						echo '未定义';
					} ?></div>
					<div class="c3"><?php echo date('Y-m-d H:i:s', $aFeedBack['create_time']); ?></div>
					<div class="c5 descript"><?php echo $aFeedBack['descript']; ?></div>
					<div class="c4 right">
					<?php if($aFeedBack['is_handled']== 0 ){ ?>
						<a href="javascript:void(0);" data-xid="<?php echo $aFeedBack['id']?>" class="checkStatus checkOff">未处理</a>
						<?php }else{ ?>
						<a href="javascript:void(0);" data-xid="<?php echo $aFeedBack['id']?>" class="checkStatus checkOn">已处理</a>
						<?php }?>
					</div>
					<!--<div class="right" style="width:60px;" xid="messageSend" number="<?php echo $aFeedBack['contact']; ?>">短信回复</div>-->
					</label>
				</div>
			<?php }} ?>
			<div class="clear"></div>
			<div class="row footer">
				<?php echo $pageHtml; ?>
			</div>
			<div class="row">
				<label style="width:120px" for="checkAll">
					<input name="checkAll" type="checkbox"  onclick="checkAll(this.checked)" id="checkAll">&nbsp;全选
				</label>


				<label id="checkChangeDel" class="button">删除选中</label>

			</div>
		</div>
</div>
<div id="tips"></div>
<script type="text/javascript">
	window.endTime = "'end_time'";

	$(function(){
		$('#diySearch').click(function(){
			var url = 'http://<?php echo APP_MANAGE . '/?m=' . get('m') . '&a=' . get('a');?>';
			var search = {
				isHandled : <?php echo get('isHandled') ?  get('isHandled') : -1 ;?>,
				type : <?php echo get('type') ?  get('type') : -1 ;?>,
				starteTime : $('#start_time').val(),
				endTime : $('#end_time').val()
			};
			if(search.isHandled != -1){
				url += '&isHandled=' + search.isHandled;
			}
			if(search.type != -1){
				url += '&type=' + search.type;
			}
			if(search.starteTime && search.endTime){
				url += '&starteTime=' + search.starteTime + '&endTime=' + search.endTime;
			}
			window.location.href = url;
		});

		$('#checkChangeDel').click(function(){
			var aFeedBackId = [];
			$('#feedBackList input[type=checkbox]').not('input[name=checkAll]').each(
				function(){
					if(this.checked == true){
						aFeedBackId.push($(this).val());
					}
				}
			);

			if(aFeedBackId.length < 1){
				UBox.show('请选择要删除的内容', -1);
				return false;
			}
			UBox.confirm('确定要删除选中的反馈吗?', function(){
				$.ajax({
					url:'?m=Service&a=delFeedBack',
					data:{aId:aFeedBackId},
					beforeSend:function(){
						$('#checkChangeDel').text('正在删除中...');
					},
					complete:function(){
						$('#checkChangeDel').text('删除选中');
					},
					success:function(aResult){
						if(aResult.status == 1){
							UBox.show('操作成功', 1);
							for (var i in aFeedBackId){
								$('#feedBackId_'+aFeedBackId[i]).parent().parent().parent().remove();
							}
						}else{
							UBox.show(aResult.msg, -1);
						}
					},
					error:function(){
						UBox.show('系统错误', 0);
					}
				});
			});
		});

		$('a.checkStatus').click(function(){
			var $this = $(this);
			$.ajax({
				url : '?m=Service&a=checkFeedBack',
				data : {id : $this.data('xid')},
				success : function(aResult){
					if(aResult.status == 1){
							UBox.show(aResult.msg, 1);
							if($this.text() == '未处理'){
								$this.removeClass('checkOff').addClass('checkOn').text('已处理');
							}else{
								$this.removeClass('checkOn').addClass('checkOff').text('未处理');
							}
						}else{
							UBox.show(aResult.msg, -1);
						}
				},
				error : function(){
					UBox.show('系统错误', 0);
				}
			});
		});

		$('._feedback .row:odd').css('background-color', '#F0F0F0');
		$('._feedback .row').hover(function(){
			var tips = $(this).find('.descript').text();
			$(this).find('.descript').append($("#tips").html(tips).addClass("tips"));
		},function(){
			$('div.tips').removeClass("tips");
		});
		$('#feedBackList div[xid=messageSend]').click(function(){
			var phoneNumber = $(this).attr('number');
			var pattern = /^(((13[0-9]{1})|15|14|18|15)+\d{9})$/;
			if(!pattern.test(phoneNumber)){
				UBox.show('用户预留的联系方式不是个有效手机号码', 0);
				return;
			}else{
				showSendMessageBox(phoneNumber);
			}
		});
	});

	function showSendMessageBox(phoneNumber){
		var html = '<div style="margin:20px; line-height:25px;" id="select"> <label class="check" for="phoneNumber" style="margin-bottom:10px;">&nbsp;回复号码：<input  name="phoneNumber" type="text" value="'+phoneNumber+'" id="phoneNumber"></label><br /><label class="check" for="content" >&nbsp;回复内容：<textarea name="content" id="content" rows="3" cols="20" style="width: 235px;height: 131px;"></textarea></label><br /></div>';
		easyDialog.open({
			container : {
				width : 400,
				height : 250,
				header : '短信回复用户反馈信息',
				content : html,
				yesFn : sendMessage,
				noFn: function(){}
			},
			overlay : true,
			followX : -100,
			drag : true
		});
	}
	/**
	 * 获取内容异步后台发短信
	 * @returns {undefined}
	 */
	function sendMessage(){
		var phoneNumber = $('#phoneNumber').val();
		var content = $('#content').val();
		$.ajax({
			url : '?m=Service&a=feedBackSendMessage',
			type : 'post',
			data : {
				content : content,
				phoneNumber : phoneNumber
			},
			success : function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg,1);
				}else{
					UBox.show(aResult.msg,0);
				}
			}
		});
	}
	function checkAll(checked){
		$('#feedBackList input[type=checkbox]').each(function(){$(this).prop('checked', checked);});
	}

</script>