<?php display('bbs/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<style type="text/css">
	.row div{line-height: 28px;cursor: pointer;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:100px;}
	.list .c3{width:200px;}
	.list .c4{width:150px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:600px; overflow: hidden;}
	.list .checkOff{color:red;}
	.list .checkOn{color:grey;}
	.right{float:right;}
	#addCategoryBtn{cursor:pointer;}
	.category_box{margin: 20px;}
	.category_box ul li{line-height:40px;height:40px; list-style: none;}
	.button{border: none;}
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			板块管理
			<button class="right button" id="addCategoryBtn">+ 增加板块</button>
		</div>

		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">板块名称</div>
			<div class="c3">状态</div>
			<div class="c3"></div>
			<div class="c5"></div>
			<div class="c4 right">操作</div>
		</div>

		<?php foreach($aCategory as $k => $categoryInfo){ ?>
		<div class="row">
			<div class="c1">
				<?php echo $categoryInfo['id']; ?>
			</div>
			<div class="c2"><?php echo $categoryInfo['name']; ?></div>
			<div class="c3"><? echo $categoryInfo['status'] == 1 ? '<font color="#090">显示</font>' : '<font color="#999">隐藏</font>' ; ?></div>
			<div class="c3"></div>
			<div class="c5"></div>
			<div class="c4 right">
				<a href="javascript:void(0);" onclick="updateCategory(<?php echo $categoryInfo['id']; ?>);" class="checkOff">修改</a>
				<a href="javascript:void(0);" onclick="delCategory(<?php echo $categoryInfo['id']; ?>);" class="checkOn">删除</a>
			</div>
		</div>
		<?php } ?>

		<div class="clear"></div>

	</div>
</div>


<script type="text/javascript">
	$(function(){
		$('.row:odd').css('background-color', '#F0F0F0');

		$('#addCategoryBtn').click(function(){
			easyDialog.open({
				container : {
					width : 600,
					header : '增加板块',
					content : categoryInfoHtml(),
					yesFn : addCategory,
    				noFn : true
				},
				fixed : false,
			});
		});
	});

	function addCategory(){
		var $data = $('#categoryForm').serialize();
		$.ajax({
			type : 'post',
			url:'?m=Bbs&a=saveCategory&type=1',
			data: $data,
			success:function(aResult){
				if(aResult.status == 1){
					UBox.show('操作成功', 1);
					easyDialog.close();
				}else{
					UBox.show(aResult.msg, -1);
				}
			},
			error:function(){
				UBox.show('系统错误', 0);
			}
		});
		return false;
	}

	function updateCategory(id){
		$.get('?m=Bbs&a=getCategoryInfo&id=' + id, function(aResult){
			if(aResult.status == 1){
				var aData = aResult.data;
				easyDialog.open({
					container : {
						width : 600,
						header : '您正在修改[ ' + aResult.data.name + ' ]',
						content : categoryInfoHtml(),
						yesFn : updateCategoryInfo,
	    				noFn : true
					},
					fixed : false,
				});
				$('input[name="CategoryName"]').val(aData.name);
				$('input[name="CategoryKeywords"]').val(aData.keywords);
				$('input[name="CategoryDescript"]').val(aData.descript);
				$('input[name="CategoryOrder"]').val(aData.order);

				if(aData.status == 1){
					$('input[name="CategoryIsOpen"]').first().attr('checked', 'checked');
				}else if(aData.status == 2){
					$('input[name="CategoryIsOpen"]').last().attr('checked', 'checked');
				}

				$('textarea[name="CategoryDescription"]').val(aData.description);
				$('input[name="CategoryId"]').val(aData.id);
			}else{
				UBox.show('很抱歉，读取出错', -1);
			}
		});

	}
	function updateCategoryInfo(){
		var $data = $('#categoryForm').serialize();
		$.ajax({
			type : 'post',
			url:'?m=Bbs&a=saveCategory&type=2',
			data: $data,
			success:function(aResult){
				if(aResult.status == 1){
					UBox.show('操作成功', 1);
					window.location.reload();
				}else{
					UBox.show(aResult.msg, -1);
				}
			},
			error:function(){
				UBox.show('系统错误', 0);
			}
		});
		return false;
	}

	function delCategory(id){

		UBox.confirm('确定要删除这个板块吗? 会删除包含里面的所有帖子和评论喔!', function(){
			$.post('?m=Bbs&a=delCategory', {'id' : id}, function(aResult){
				if(aResult.status == 1){
					UBox.show('删除成功', 1);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			});
		});
	}

	function categoryInfoHtml(){
		return '<div id="categoryInfo">\
					<div class="category_box">\
						<form id="categoryForm">\
							<ul>\
								<li>板块名称：<input type="text" name="CategoryName" /></li>\
								<li>关 键 字 ：<input type="text" name="CategoryKeywords" style="width:370px"/></li>\
								<li>描　　述：<input type="text" name="CategoryDescript" style="width:370px" /></li>\
								<li>排　　序：<input type="text" name="CategoryOrder" style="width:50px" /></li>\
								<li>是否启用：\
									<label style="float: none;display: inline-block;">启用<input name="CategoryIsOpen" type="radio" value="1"></label>\
									<label style="float: none;display: inline-block;">关闭<input name="CategoryIsOpen" type="radio" value="2"></label></li>\
								<li style="line-height: normal;height: initial;">\
									板块信息：<textarea name="CategoryDescription" rows="5" cols="50"></textarea> </li>\
								<input name="CategoryId" type="hidden" value="0" />\
							</ul>\
						</form>\
					</div>\
				</div>';
	}
</script>