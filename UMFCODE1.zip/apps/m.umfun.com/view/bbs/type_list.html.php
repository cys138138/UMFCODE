<?php 
displayHeader();
display('bbs/nav.html.php'); 
?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<style type="text/css">
	.row div{line-height: 28px;cursor: pointer;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:100px;}
	.list .c3{width:200px;}
	.list .c4{width:150px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:600px; overflow: hidden;}
	.list .checkOff{color:red;}
	.list .checkOn{color:grey;}
	.right{float:right;}
	#addCategoryBtn{cursor:pointer;}
	.category_box{margin: 20px;}
	.category_box ul li{line-height:40px;height:40px; list-style: none;}
	.button{border: none;}
</style>

<div class="module BbsOption">
	<div class="list" id="categoryList">
		<div class="title">
			板块管理
			<button class="right button" id="addCategoryBtn">+ 增加分类</button>
		</div>
		
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">分类名称</div>
			<div class="c3">所属版块</div>
			<div class="c5">创建时间</div>
			<div class="c4 right">操作</div>
		</div>
		
		<?php foreach($aTypeList as $aType){ ?>
		<div class="row">
			<div class="c1">
				<?php echo $aType['id']; ?>
			</div>
			<div class="c2"><?php echo $aType['name']; ?></div>
			<div class="c3"><? echo $aType['cagegory_name']; ?></div>
			<div class="c5"><? echo date('Y-m-d H:i', $aType['create_time']); ?></div>
			<div class="c4 right">
				<a href="javascript:void(0);" onclick="updateCategory(<?php echo $aType['id']; ?>);" class="checkOff">修改</a>
				<a href="javascript:void(0);" onclick="delCategory(<?php echo $aType['id']; ?>);" class="checkOn">删除</a>
			</div>
		</div>
		<?php } ?>

		<div class="clear"></div>

	</div>
</div>


<script type="text/javascript">
	$(function(){
		$('.row:odd').css('background-color', '#F0F0F0');

		$('#addCategoryBtn').click(function(){
			easyDialog.open({
				container : {
					width : 600,
					header : '增加分类',
					content : categoryInfoHtml(),
					yesFn : addCategory,
    				noFn : true
				},
				fixed : false,
			});
		});
	});

	function addCategory(){
		var $data = $('#categoryForm').serialize();
		$.ajax({
			type : 'post',
			url:'?m=Bbs&a=addType',
			data: $data,
			success:function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1);
					window.location.reload();
				}else{
					UBox.show(aResult.msg, -1);	
				}
			},
			error:function(){
				UBox.show('系统错误', 0);
			}
		});
		return false;
	}

	function updateCategory(id){
		$.get('?m=Bbs&a=getTypeInfo&id=' + id, function(aResult){
			if(aResult.status == 1){
				var aData = aResult.data;
				easyDialog.open({
					container : {
						width : 600,
						header : '您正在修改[ ' + aResult.data.name + ' ]',
						content : categoryInfoHtml(),
						yesFn : updateCategoryInfo,
	    				noFn : true
					},
					fixed : false,
				});
				$('#name').val(aData.name);
				$('#order').val(aData.order);
				$('#id').val(aData.id);
				$('#category option').each(function(){
					var cateId = $(this).attr('value');
					if(cateId == aData.category_id){
						$(this).attr('selected', 'selected');
					}else{
						$(this).removeAttr('selected');
					}
				});
			}else{
				UBox.show('很抱歉，读取出错', -1);
			}
		});
		
	}
	function updateCategoryInfo(){
		var $data = $('#categoryForm').serialize();
		$.ajax({
			type : 'post',
			url:'?m=Bbs&a=saveType',
			data: $data,
			success:function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1);
					window.location.reload();
				}else{
					UBox.show(aResult.msg, -1);	
				}
			},
			error:function(){
				UBox.show('系统错误', 0);
			}
		});
		return false;
	}

	function delCategory(id){
		UBox.confirm('确定要删除这个分类吗？', function(){
			$.post('?m=Bbs&a=delType', {'id' : id}, function(aResult){
				//console.log(id);
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1);
					window.location.reload();
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			});
		});
	}
	
	<?php
	$cateList = '';
	foreach($aCateList as $aCate){
		$cateList .= '<option value="' . $aCate['id'] . '">' . $aCate['name'] .  '</option>';
	}
	?>
	function categoryInfoHtml(){
		return '<div id="categoryInfo">\
					<div class="category_box">\
						<form id="categoryForm">\
							<ul>\
								<li>分类名称：<input type="text" name="name" id="name" /></li>\
								<li>排　　序：<input type="text" id="order" name="order" style="width:50px" /></li>\
								<li>所属板块：\
									<select id="category" name="category"><?php echo $cateList; ?></select>\
								<input name="id" id="id" type="hidden" value="0" />\
							</ul>\
						</form>\
					</div>\
				</div>';
	}
</script>

<?php displayFooter(); ?>