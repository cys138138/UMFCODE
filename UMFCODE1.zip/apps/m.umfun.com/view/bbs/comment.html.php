<?php display('bbs/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<style type="text/css">
	.row div{line-height: 28px;cursor: pointer;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:600px;}
	.list .c3{width:130px;}
	.list .c4{width:150px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:600px; overflow: hidden;}
	.list .checkOff{color:red;}
	.list .checkOn{color:grey;}

	.view_box{overflow-y: auto; max-height:600px; padding: 10px;}
	.right{float:right;}
	.button{border: none;}
	.caogao{color: #666;}
	.hide{display: none;}
</style>
<div class="module">
	<div class="list">
		<div class="title">
			评论列表
		</div>
		
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">内容</div>
			<div class="c3">所属文章ID</div>
			<div class="c3">评论用户</div>
			<div class="c3">发表时间</div>

			<div class="c3">被赞次数</div>
			<div class="c4 right">操作</div>
		</div>
		
		<?php foreach($aComment as $k => $CommentInfo){ ?>
		<div class="row">
			<div class="c1">
				<?php echo $CommentInfo['id']; ?>
			</div>
			
			<div class="c2">
				
				<a href="javascript:void(0);" onclick="viewInfo(this);">
					<?php $content = mb_substr(strip_tags(htmlspecialchars_decode($CommentInfo['content'])), 0,60);
					echo  $content ? $content : '--'; ?>
					<i class="hide"><pre><?php echo htmlspecialchars_decode($CommentInfo['content']);?></pre></i>
				</a>
				
			</div>
			
			<div class="c3">
				<a href="http://<?php echo APP_BBS . '/?m=Thread&a=article&id=' . $CommentInfo['thread_id']; ?>" target="_blank">
				查看本话题(<?php echo $CommentInfo['thread_id']; ?>)
				</a>
			</div>
			<div class="c3"><a href="javascript:void(0);" title="<?php echo $CommentInfo['user_info']['id']; ?>"><?php echo $CommentInfo['user_info']['name']; ?></a></div>
			<div class="c3"><?php echo date('Y-m-d H:i:s', $CommentInfo['create_time']); ?></div>
			<div class="c3"><?php echo $CommentInfo['support_times']; ?></div>
			<div class="c4 right">
				<a href="javascript:void(0);" onclick="deleteComment(<?php echo $CommentInfo['id']; ?>, this);" class="checkOn">删除</a>
			</div>
		</div>
		<?php } ?>
		
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>
<script type="text/javascript">
	$(function(){
		$('.row:odd').css('background-color', '#F0F0F0');
	});

	function viewInfo(obj){
		var $obj = $(obj);
		easyDialog.open({
			container : {
				width : 600,
				header : '查看评论详细内容',
				content : '<div id="viewInfo" class="view_box"></div>',
				yesFn : easyDialog.close,
				noFn : true
			},
			fixed : false,
		});
		$('#viewInfo').html($obj.find('i').html());
	}

	function deleteComment(id, obj){
		var $obj = $(obj);
		$.post(
			'/?m=Bbs&a=delete',
			{
				id : id,
				type : 2
			},
			function(aRequest){
				if(aRequest.status == 1){
						UBox.show('删除成功', 1);
						$obj.parent().parent().hide('fast',function(){
							$obj.remove();
						});
					}else{
						UBox.show(aRequest.msg, aRequest.status);
					}
			}
		);
	}
</script>