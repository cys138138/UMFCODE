<?php display('bbs/nav.html.php'); ?>
<div class="module BbsOption">
	<style type="text/css">
		.BbsOption .name{width:90px;}
		.BbsOption .BbsDiv span{display:inline-block; margin-right:10px;}
		.BbsOption .tip{position:relative; top:-7px;}
		.BbsOption .tip input[type=text]{width:600px;}
		.BbsOption .category{margin-left: 20px;}
	</style>
	<div class="title">论坛基础配置</div>
	<form id="BbsOption">
		<div class="item BbsDiv">
			<div class="control">
				<span class="tip">
					<label>热门帖子：</label>
					<input name="bbsHot" type="text" value="<?php echo $GLOBALS['BBS']['hot']; ?>" />
				</span>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item BbsDiv">
			<div class="control">
				<span class="tip">
					<label>默认板块：</label>
					<?php
						foreach($aCategory as $key => $aCategoryInfo){
							$checked = '';
							if($aCategoryInfo['id'] == $GLOBALS['BBS']['defult_channel']){
								$checked = 'checked';
							}
							echo '<label class="category">' . $aCategoryInfo['name'] . '<input name="defultChannel" '. $checked .' type="radio" value="' . $aCategoryInfo['id'] . '"/></label>';
						}
					?>
				</span>
			</div>
		</div>
		<div class="clear"></div>
		
		<div class="item">
			<div class="name"></div>
			<div class="control">
				<button class="button" type="button" onclick="commit();">确定</button>
			</div>
		</div>
	</form>
</div>

<script type="text/javascript">
	function commit(){
		$.ajax({
			url : '?m=Bbs&a=setConfig',
			type : 'post',
			data : $('#BbsOption').serialize(),
			dataType : 'json',
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
			},
			error : function(aRequest){
				UBox.show('抱歉，网络可能有点慢，请重试', 0);
			}
		});
	}
</script>