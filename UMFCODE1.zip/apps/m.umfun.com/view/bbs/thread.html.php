<?php display('bbs/nav.html.php'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['easydialog']['path'] . $GLOBALS['RESOURCE']['easydialog']['js']; ?>"></script>
<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<style type="text/css">
	.row div{line-height: 28px;cursor: pointer;}
	.row:hover{background-color:#D9E4EE !important;}
	.list .c1{width:40px;}
	.list .c2{width:480px;}
	.list .c3{width:130px;}
	.list .c4{width:150px;}
	.list .c4 a{padding-right:7px;}
	.list .c5{width:600px; overflow: hidden;}
	.list .checkOff{color:red;}
	.list .checkOn{color:grey;}

	.w80 {width:80px;}
	.right{float:right;}
	.button{border: none;}
	.caogao{color: #666;}
	.red{color:red;}
</style>

<div class="module">
	<div class="list" id="categoryList">

		<form id="searchTread">
			<div class="item">
				<div class="name">话题ID：</div>
				<div class="control">
					<input type="text" id="threadIds" name="threadIds" value="<?php echo get('threadIds', 0); ?>">
				</div>
				<div class="blank"></div>
				<div class="name">用户ID：</div>
				<div class="control">
					<input type="text" class="w80" id="userId" name="userId" value="<?php echo get('userId', 0); ?>">
				</div>
				
				<div class="blank"></div>
				<div class="name">阅读量 N 以上：</div>
				<div class="control">
					<input type="text" class="w80" id="read" name="read" value="<?php echo get('read', 0); ?>">
				</div>
				<div class="blank"></div>
				<div class="name">点赞量 N 以上：</div>
				<div class="control">
					<input type="text" class="w80" id="support" name="support" value="<?php echo get('support', 0); ?>">
				</div>
				<div class="blank"></div>
				<div class="name">发布时间：</div>
				<div class="control">
					<input type="text" id="creat_start_time" value="<?php echo get('creat_start_time'); ?>" name="creat_start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
					-
					<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo get('creat_end_time'); ?>" type="text" id="creat_end_time" name="creat_end_time" />
				</div>
				<div class="blank"></div>
				<div class="name">回复时间：</div>
				<div class="control">
					<input type="text" id="real_start_time" value="<?php echo get('real_start_time'); ?>" name="real_start_time" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss',maxDate:'#F{$dp.$D('+endTime+')}'})" />
					-
					<input onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})" value="<?php echo get('real_end_time'); ?>" type="text" id="real_end_time" name="real_end_time" />
				</div>
				
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name">板块选择：</div>
				<div class="control">
					<select name="category" id="category">
						<option value="0">-默认全部-</option>
						<?php foreach($aCategoryList as $k => $categoryInfo){
							$select = '';
							if(intval(get('categoryId')) == $categoryInfo['id']){$select = 'selected';}
							echo '<option value="' . $categoryInfo['id'] . '" ' . $select . '>-' . $categoryInfo['name'] . '-</option>';
						 } ?>
					</select>
				</div>
				<div class="blank"></div>
				<div class="name">是否推荐：</div>
				<div class="control">
					<select name="isRecommend" id="isRecommend">
						<option value="-1" <?php if(get('isRecommend') == -1){echo 'selected';} ?>>-默认全部-</option>
						<option value="1" <?php if(get('isRecommend') == 1){echo 'selected';} ?>>-推荐-</option>
						<option value="0" <?php if(get('isRecommend') == 0){echo 'selected';} ?>>-未推荐-</option>
					</select>
				</div>
				<div class="blank"></div>
				<div class="name">是否置顶：</div>
				<div class="control">
					<select name="isTop" id="isTop">
						<option value="-1" <?php if(get('isTop') == -1){echo 'selected';} ?>>-默认全部-</option>
						<option value="1" <?php if(get('isTop') == 1){echo 'selected';} ?>>-置顶-</option>
						<option value="0" <?php if(get('isTop') == 0){echo 'selected';} ?>>-未置顶-</option>
					</select>
				</div>
				<div class="blank"></div>
				<div class="name">排序方式：</div>
				<div class="control">
					<select name="order" id="order">
						<option value="0" <?php if(get('order') == 0){echo 'selected';} ?>>-默认-</option>
						<option value="1"  <?php if(get('order') == 1){echo 'selected';} ?>>-按发表时间-</option>
						<option value="2"  <?php if(get('order') == 2){echo 'selected';} ?>>-按最后回复时间-</option>
						<option value="3"  <?php if(get('order') == 3){echo 'selected';} ?>>-赞的个数-</option>
						<option value="4"  <?php if(get('order') == 4){echo 'selected';} ?>>-阅读次数-</option>
					</select>
				</div>
				<div class="blank"></div>
				<div class="control">
					<button type="button" class="button" onclick="searchThread();">搜索</button>
				</div>
			</div>
			<div class="clear"></div>
		</form>
		
		<div class="title">
			话题列表
		</div>
		
		<div class="row header">
			<div class="c1">ID</div>
			<div class="c2">标题</div>
			<div class="c3">所属板块</div>
			<div class="c3">所属用户</div>
			<div class="c3">发表时间</div>
			<div class="c3">阅读次数</div>
			<div class="c3">被赞次数</div>
			<div class="c4 right">操作</div>
		</div>
		
		<?php foreach($aThreadList as $k => $threadInfo){
			$testUserClass = in_array($threadInfo['user_info']['id'], $GLOBALS['TEST_USER_LIST']) ? ' testUser' : ''; ?>
		<div class="row">
			<div class="c1">
				<?php echo $threadInfo['id']; ?>
			</div>
			
			<div class="c2">
				<a href="<?php echo url('m=Thread&a=article&id=' . $threadInfo['id'], '', APP_HOME); ?>" class="<?php 
				if($threadInfo['is_top'] == 1){
					echo 'red';
				}
				if($threadInfo['status'] == 1){
					echo 'caogao';
				}
			?>" target="_blank">
					<?php echo $threadInfo['title']; ?>
				</a>
			</div>
			
			<div class="c3"><?php echo isset($threadInfo['category_name']) ? $threadInfo['category_name'] : '被取消的版块'; ?></div>
			<div class="c3 <?php echo $testUserClass;?>">
				<a href="javascript:void(0);" title="<?php echo $threadInfo['user_info']['id']; ?>">
					<span class="name"><?php echo $threadInfo['user_info']['name']; ?></span>
				</a>
			</div>
			<div class="c3"><?php echo date('Y-m-d H:i', $threadInfo['create_time']); ?></div>
			<div class="c3"><?php echo $threadInfo['read_times']; ?></div>
			<div class="c3"><?php echo $threadInfo['support_times']; ?></div>
			<div class="c4 right">
				<?php
				if($threadInfo['is_top'] == 1){ ?>
					<a href="javascript:void(0);" onclick="setThreadState(<?php echo $threadInfo['id']; ?>, 2, 1, this);" class="checkOff">取消置顶</a>
				<?php }else{ ?>
					<a href="javascript:void(0);" onclick="setThreadState(<?php echo $threadInfo['id']; ?>, 1, 1, this);" class="checkOn">置顶</a>
				<?php }
					  if($threadInfo['is_recommend'] == 1){ 
				?>
					<a href="javascript:void(0);" onclick="setThreadState(<?php echo $threadInfo['id']; ?>, 2, 2, this);" class="checkOff">取消推荐</a>
				<?php }else{ ?>
					<a href="javascript:void(0);" onclick="setThreadState(<?php echo $threadInfo['id']; ?>, 1, 2, this);" class="checkOn">推荐</a>
					
				<?php } ?>
				<a href="javascript:void(0);" onclick="showSetThread(<?php echo $threadInfo['id']; ?>, this);" class="checkOn">修改</a>
				<a href="javascript:void(0);" onclick="deleteThread(<?php echo $threadInfo['id']; ?>, this);" class="checkOn">删除</a>
			</div>
		</div>
		<?php } ?>
		
		<div class="row footer">
			<?php echo $pageHtml; ?>
		</div>

		<div class="clear"></div>

	</div>
</div>

<script type="text/javascript">
	window.endTime = "'end_time'";
	$(function(){
		$('.row:odd').css('background-color', '#F0F0F0');
	});

	function searchThread(){
		/*
		threadIds=0
		userId=0
		read=0
		support=0
		creat_start_time=2014-07-0100:00:00
		creat_end_time=2014-07-2918:48:55
		real_start_time=2014-07-0100:00:00
		real_end_time=2014-07-2918:48:55
		category=0
		isRecommend=-1
		isTop=-1
		order=0
		*/
		var threadIds = $('#threadIds').val(),
			userId = $('#userId').val(),
			read = $('#read').val(),
			support = $('#support').val(),
			creat_start_time = $('#creat_start_time').val(),
			creat_end_time = $('#creat_end_time').val(),
			real_start_time = $('#real_start_time').val(),
			real_end_time = $('#real_end_time').val(),
			category = $('#category').val(),
			isRecommend = $('#isRecommend').val(),
			isTop = $('#isTop').val(),
			order = $('#order').val(),
			url = '/?m=Bbs&a=showThreadList';

		if(threadIds.length > 0){
			url = url + '&threadIds=' + threadIds;
		}
		if(userId.length > 0){
			url = url + '&userId=' + userId;
		}
		if(read.length > 0){
			url = url + '&read=' + read;
		}
		if(support.length > 0){
			url = url + '&support=' + support;
		}
		if(creat_start_time.length > 0){
			url = url + '&creat_start_time=' + creat_start_time;
		}
		if(creat_end_time.length > 0){
			url = url + '&creat_end_time=' + creat_end_time;
		}
		if(real_start_time.length > 0){
			url = url + '&real_start_time=' + real_start_time;
		}
		if(real_end_time.length > 0){
			url = url + '&real_end_time=' + real_end_time;
		}
		if(category.length > 0){
			url = url + '&categoryId=' + category;
		}
		if(isRecommend.length > 0){
			url = url + '&isRecommend=' + isRecommend;
		}
		if(isTop.length > 0){
			url = url + '&isTop=' + isTop;
		}
		if(order.length > 0){
			url = url + '&order=' + order;
		}

		window.location.href = url;

	}
	
	function setThreadState(id, type, setType, obj){
		var tipsTypeText = type == 1 ? '设置' : '取消',
			tipsSetText = setType == 1 ? '置顶' : '推荐',
			$obj = $(obj);
		$.post(
			'/?m=Bbs&a=setThreadState',
			{
				id : id,
				type : type,
				setType : setType
			},
			function(aRequest){
				if(aRequest.status == 1){
					UBox.show(tipsTypeText + tipsSetText + '成功', 1);
					updateStateHtml(id, type, setType, $obj);
				}else{
					UBox.show(aRequest.msg, aRequest.status);
				}
			}
		);
	}

	function updateStateHtml(id, type, setType, jqObj){
		var tipsTypeText = type != 1 ? '' : '取消',
			tipsSetText = setType == 1 ? '置顶' : '推荐';
		if(type == 1){
			jqObj.text(tipsTypeText + tipsSetText)
				.removeClass()
				.addClass('checkOff')
				.attr('onclick', 'setThreadState(' + id + ', 2, ' + setType + ', this);');
		}else{
			jqObj.text(tipsTypeText + tipsSetText)
				.removeClass()
				.addClass('checkOn')
				.attr('onclick', 'setThreadState(' + id + ', 1, ' + setType + ', this);');
		}
	}

	function deleteThread(id, jqObj){
		var $obj = $(jqObj);
		UBox.confirm('确定要删除这个话题吗? 会删除包含里面的所有帖子和评论喔!', function(){
			$.post(
				'/?m=Bbs&a=delete',
				{
					id : id,
					type : 1
				},
				function(aRequest){
					if(aRequest.status == 1){
						UBox.show('删除成功', 1);
						$obj.parent().parent().hide('fast',function(){
							$obj.remove();
						});
					}else{
						UBox.show(aRequest.msg, aRequest.status);
					}
				}
			);
		});
	}
	
	function showSetThread(id){
		$.get('?m=Bbs&a=getThreadInfo&id=' + id, function(aResult){
			if(aResult.status == 1){
				var aData = aResult.data;
				easyDialog.open({
					container : {
						width : 600,
						header : '您正在修改[ ' + aResult.data.title + ' ]',
						content : categoryInfoHtml(),
						yesFn : setThread,
	    				noFn : true
					},
					fixed : false,
				});
				$('#id').val(aData.id);
				$('#category option').each(function(){
					var cateId = $(this).attr('value');
					if(cateId == aData.category_id){
						$(this).attr('selected', 'selected');
					}else{
						$(this).removeAttr('selected');
					}
				});
				$('#classify_id option').each(function(){
					var typeId = $(this).attr('value');
					if(typeId == aData.classify_id){
						$(this).attr('selected', 'selected');
					}else{
						$(this).removeAttr('selected');
					}
				});
			}else{
				UBox.show('很抱歉，读取出错', -1);
			}
		});	
	}
	function setThread(){
		var data = $('#categoryForm').serialize();
		$.ajax({
			data : data,
			type : 'post',
			url:'?m=Bbs&a=setThreadCate',
			success:function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1);
					window.location.reload();
				}else{
					UBox.show(aResult.msg, -1);	
				}
			},
			error:function(){
				UBox.show('系统错误', 0);
			}
		});
		return false;
	}
	
	<?php
	$cateList = '';
	foreach($aCategoryList as $aCate){
		$cateList .= '<option value="' . $aCate['id'] . '">' . $aCate['name'] .  '</option>';
	}
	$typeList = '<option value="0">无分类</option>';
	foreach($aClassList as $aType){
		$typeList .= '<option value="' . $aType['id'] . '">' . $aType['name'] .  '</option>';
	}
	?>
	function categoryInfoHtml(){
		return '<div id="categoryInfo">\
					<div class="category_box">\
						<form id="categoryForm">\
							<ul>\
								<li>所属版块：\
									<select id="category" name="category"><?php echo $cateList; ?></select>\
								<input name="id" id="id" type="hidden" value="0" /></li>\
								<li>所属分类：\
									<select id="classify_id" name="classify_id"><?php echo $typeList; ?></select></li>\
							</ul>\
						</form>\
					</div>\
				</div>';
	}
</script>