<div class="nav">
	<a <?php if(get('a') == 'config'){ ?>class="on"<?php } ?> href="?m=Bbs&a=config">基础设置</a>
	<a <?php if(get('a') == 'category'){ ?>class="on"<?php } ?> href="?m=Bbs&a=category">板块管理</a>
	<a <?php if(get('a') == 'showThreadList'){ ?>class="on"<?php } ?> href="?m=Bbs&a=showThreadList">话题列表</a>
	<a <?php if(get('a') == 'showCommentList'){ ?>class="on"<?php } ?> href="?m=Bbs&a=showCommentList">评论列表</a>
	<a <?php if(get('a') == 'showTypeList'){ ?>class="on"<?php } ?> href="?m=Bbs&a=showTypeList">分类列表</a>
</div>
<div class="br"></div>
