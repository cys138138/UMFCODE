<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<style type="text/css">
	._conditon .name{width:50px;}
	._conditon .width80{width:80px;}
	._conditon .width100{width:100px;}
	._conditon label{width:40px;}
	._conditon .control input[type="text"]{width:150px;}
	._conditon .control input.realName{width:100px;}
	._conditon ._ageInput input[type="text"]{width:60px;}
	._conditon ._quickTime a{color:#000000; margin-right:10px;}
	
	._userList .list .c1{width:180px;}
	._userList .list .c2{width:70px;}
	._userList .list .c3{width:65px;}
	._userList .list .c4{width:60px;}
	._userList .list .c5{width:60px;}
	._userList .list .c6{width:60px;}
	._userList .list .c7{width:60px;}
	._userList .list .c8{width:80px;}
	._userList .list .c9{width:100px;}
	._userList .list .c10{width:50px;}
	._userList .list .c11{width:50px;}
	._userList .list .c12{width:50px;}
	._userList .list .c13{width:60px;}
	._userList .list .c14{width:125px;}
	._userList .list .c15{width:165px;}
	._userList .list .c400{width:290px;}
	._userList .list .row .c15 a{padding-right:5px;}
	._userList .list .row div{text-align:center;}
</style>
<?php display('exchange/nav.html.php'); ?>
<div class="module _conditon">
	<form>
		<div class="item">
			<div class="name width80">等级限制：</div>
			<div class="control">
				<select name="exchange_level" id="exchange_level" >
					<option value="-1">全部</option>
					<?php 
						for($i = 1; $i <= 60; $i++){
							if(isset($aCondition['level']) && $aCondition['level'] == $i){
								echo '<option value="' . $i . '" selected="selected">' . $i . ' 级</option>';
							}else{
								echo '<option value="' . $i . '">' . $i . ' 级</option>';
							}
						}
					?>
				</select>
			</div>
			<div class="name width80">物品状态：</div>
			<div class="control">
				<select name="exchange_release" id="exchange_release">
					<option value="-1">全部</option>
					<option value="2" <?php if(isset($aCondition['release']) && $aCondition['release'] == 2){ echo 'selected="selected"'; } ?>>已上架</option>
					<option value="1" <?php if(isset($aCondition['release']) && $aCondition['release'] == 1){ echo 'selected="selected"'; } ?>>已下架</option>
				</select>
			</div>
			<div class="name width80">推荐类型：</div>
			<div class="control">
				<select name="recommand" id="recommand">
					<option value="0" <?php if(isset($aCondition['recommand']) && $aCondition['recommand'] == 0){ echo 'selected="selected"'; } ?>>全部</option>
					<option value="1" <?php if(isset($aCondition['recommand']) && $aCondition['recommand'] == 1){ echo 'selected="selected"'; } ?>>推荐</option>
				</select>
			</div>
			<div class="blank"></div>
			<div class="control">
				<a class="button" onclick="goodsSearch(1);">搜索</a>
			</div>
		</div>
		<div class="clear"></div>
	</form>
</div>

<div class="br"></div>
<div class="module _userList">
	<div class="title">兑换物品列表</div>
	<div class="list">
		<div class="row header">
			<div class="c9">兑换ID</div>
			<div class="c400">兑换物品名称</div>
			<div class="c9">等级限制</div>
			<div class="c9">兑换金币</div>
			<div class="c9">物品库存</div>
			<div class="c9">排序</div>
			<div class="c8">上架状态</div>
			<div class="c14">创建时间</div>
			<div class="c14">抢购时间</div>
			<div class="c15 right">操作</div>
		</div>
		<?php 
			if($aGoodsList){
				foreach($aGoodsList as $aGoodsInfo){
		?>
					<div class="row">
						<div class="c9"><?php echo $aGoodsInfo['id']; ?></div>
						<div class="c400" title="<?php echo $aGoodsInfo['name']; ?>" style="text-align:left;"><?php echo $aGoodsInfo['name']; ?></div>
						<div class="c9"><?php echo $aGoodsInfo['level']; ?> 级</div>				
						<div class="c9"><?php echo $aGoodsInfo['gold']; ?> 金币</div>		
						<div class="c9"><?php echo $aGoodsInfo['stock']; ?> 件</div>
						<div class="c9"><?php echo $aGoodsInfo['orders']; ?> </div>
						<div class="c8"><?php echo $aGoodsInfo['release'] == 2 ? '已上架' : '已下架'; ?></div>
						<div class="c14"><?php echo date('Y-m-d H:i:s', $aGoodsInfo['create_time']); ?></div>
						<div class="c14">
							<?php 
								if($aGoodsInfo['rush_time']){ 
									echo date('Y-m-d H:i:s', $aGoodsInfo['rush_time']); 
								}else{
									echo '非抢购商品';
								}
							?>
						</div>
						<div class="c15 right">
							<a href="/?m=Exchange&a=showDetail&id=<?php echo $aGoodsInfo['id']; ?>">查看</a>
							<a href="/?m=Exchange&a=showEdit&id=<?php echo $aGoodsInfo['id']; ?>">编辑</a>
							<?php if($aGoodsInfo['recommand_time']){ ?>
							<a href="javascript:;" id="btn_<?php echo $aGoodsInfo['id']; ?>" onclick="cancelRecommand(<?php echo $aGoodsInfo['id']; ?>, this);">取消推荐</a>
							<?php } ?>
						</div>
					</div>
		<?php
				}
			}else{
				echo '<div class="row"><div class="c1">暂无数据</div></div>';
				}
		?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	function goodsSearch(type){
		var url = '/?m=Exchange&a=showList',
		level = parseInt($('#exchange_level').val()),
		release = parseInt($('#exchange_release').val()),
		recommand = parseInt($('#recommand').val());
		if(level > 0 && level < 60){
			url += '&level=' + level;
		}
		if(release > 0 && release < 3){
			url += '&release=' + release;
		}
		if(recommand >= 0 && recommand < 2){
			url += '&recommand=' + recommand;
		}
		window.location.href = url;
	}
	
	function cancelRecommand(id, o){
		$.ajax({
			url: '/?m=Exchange&a=cancelRecommand',
			data: {
				'id' : id
			},
			type: 'post',
			dataType: 'json',
			success: function(aResult){
				if(aResult.status == 1){
					UBox.show(aResult.msg, 1);
					$(o).remove();
				}else{
					UBox.show(aResult.msg, -1);
				}
			},
			error: function(){
				UBox.show('系统错误', 0);
			}
		});
	}
</script>
