<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['js']; ?>"></script>

<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>
<?php display('exchange/nav.html.php'); ?>

<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		._main .item .grade_div{float:left; display:block}
		._main .item .grade_div label{padding-right:25px}
		
		
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		
		._subject span{margin-right:15px; display:inline-block;}
		
		
		._main .item .control #match_name{width:450px;}
		._main .item .control #description{width:450px;height:20px}
		._mian .item .profile_main{border:1px solid red;width:130px;height:90px;border:1px solid red;position:absolute; left:240px;top:-70px;}
		._mian .item .left{float:left;}	
		select{margin-right:15px;padding:0 3px;}
		
	</style>
	<form id="goodsAdd" class="addForm">
		<div class="addForm">
			<div class="title">新增兑换物品</div>
			<div class="item">
				<div class="name">兑换物品名称：</div>
				<div class="control"><input type="text" name="exchange_name" id="exchange_name" style="width:400px;" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item" style="position:relative;overflow:visible">
				<div class="name">兑换物品截图：</div>
				<div class="control" style="overflow:hidden">
					<input type="file" name="imgUpload" id="imgUpload" />
					图片大小应小于300KB，最大宽度不能超过400PX
				</div>
				<div id="profile_main" style="border:1px solid #ccc;width:130px;height:90px;position:absolute; left:400px;top:-60px;display:none">
					<a href="javascript:void(0)" onclick="javascript:deleteImage()" title="删除" style="position:absolute;right:-3px;top:-17px;" >删除</a>
					<img id="profileImg" style="width:130px;height:90px" />
				</div>
				<input type="text" name="exchange_profile" id="exchange_profile" style="display:none"  />	
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">推荐时间：</div>
				<div class="control"><input type="text" name="recommandTime" id="recommandTime" class="left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" /></div>
			</div>
			<div class="clear"></div>
			<div class="item">
				<div class="name">抢购时间：</div>
				<div class="control"><input type="text" name="rushTime" id="rushTime" class="left Wdate" onclick="WdatePicker({dateFmt:'yyyy-M-d H:m:00'})" /></div><span><b>抢购商品才需要填写(每周六中午12点正！)</b></span>
			</div>
			<div class="clear"></div>
			
			<div class="item" style="position:relative;overflow:visible">
				<div class="name">推荐轮显图片：</div>
				<div class="control" style="overflow:hidden">
					<input type="file" name="recommandImgUpload" id="recommandImgUpload" />
					图片大小应为 650 * 260 （填写了推荐时间必须上传推荐轮显图片）
				</div>
				<div id="recommand_main" style="border:1px solid #ccc;width:130px;height:90px;position:absolute; left:400px;top:-60px;display:none">
					<a href="javascript:void(0)" onclick="javascript:deleteRecommandImage()" title="删除" style="position:absolute;right:-3px;top:-17px;" >删除</a>
					<img id="recommandImg" style="width:130px;height:90px" />
				</div>
				<input type="text" name="recommand" id="recommand" style="display:none"  />	
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">等级限制：</div>
				<div class="control">
					<select name="exchange_level" id="exchange_level" >
						<option value="-1">-等级-</option>
						<?php 
							for($i = 1; $i <= 60; $i++){
								echo '<option value="' . $i . '">' . $i . ' 级</option>';
							}
						?>
					</select>
				</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">兑换金币：</div>
				<div class="control"><input type="text" name="exchange_gold" id="exchange_gold" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">原价金币：</div>
				<div class="control"><input type="text" name="original_gold" id="original_gold" />（<strong>没有打折就不用填啊笨蛋</strong>）</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">物品库存：</div>
				<div class="control"><input type="text" name="exchange_stock" id="exchange_stock" /></div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">默认排序：</div>
				<div class="control"><input type="text" name="exchange_orders" id="exchange_orders" /> (目前最大排序是 <?php echo $maxOrder; ?>, 建议填写 <?php echo ($maxOrder + 10); ?>)</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">上架状态：</div>
				<div class="control">
					<select name="exchange_release" id="exchange_release">
						<option value="2">上架</option>
						<option value="1">下架</option>
					</select>
				</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">兑换物品简介：</div>
				<div class="control">
					<textarea name="exchange_summary" id="exchange_summary" cols="124" rows="10"></textarea>
				</div>
			</div>
			<div class="clear"></div>
			
			<div class="item">
				<div class="name">兑换物品描述：</div>
				<div class="control">
					<script type="text/plain" id="exchange_description" name="exchange_description" style="width:900px;height:320px;"></script>
				</div>
			</div>
			<div class="clear"></div>

			<div class="item">
				<div class="name"></div>
				<div class="control"><a class="button" id="submitButton" onclick="addGoods();" />添加兑换物品</a></div>
			</div>
			<div class="clear"></div>
			
			<BR><BR>
		</div>
	</form>
</div>
<script type="text/javascript">
<?php echo $validateAddGoodsJs; ?>

	//实例化编辑器
	UM.getEditor('exchange_description', {
		imageUrl : '?m=Exchange&a=ueditorUpload',
		imagePath : '<?php echo SYSTEM_RESOURCE_URL . PRODUCT_DESCRIPTION_IMAGE_PATH; ?>'
	});
	
	$(function(){
		$("#imgUpload").uploadify({
			'fileTypeExts' : '*.jpg; *.png; *.gif',
			'fileSizeLimit' : '300KB',
			'height' : 30,
			'width' : 100,
			'swf' : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['swf']; ?>',
			'uploader' : 'http://<?php echo APP_MANAGE ?>/?m=Exchange&a=uploadProfile&ajax=1',
			'buttonText' : '选择文件',
			'onUploadSuccess' : function(file, data, response){
				data = eval('(' + data + ');');
				if(data.status == 1){
					$('#profileImg').attr('src', data.data);
					$('#exchange_profile').val(data.msg);
					$('#profile_main').show(300);
				}else{
					$('#profile_main').hide();
					UBox.show(data.msg, -1);
				}
			}
		});
		
		$("#recommandImgUpload").uploadify({
			'fileTypeExts' : '*.jpg; *.png; *.gif',
			'fileSizeLimit' : '300KB',
			'height' : 30,
			'width' : 100,
			'swf' : '<?php echo $GLOBALS['RESOURCE']['uploadify']['path'] . $GLOBALS['RESOURCE']['uploadify']['swf']; ?>',
			'uploader' : 'http://<?php echo APP_MANAGE ?>/?m=Exchange&a=uploadRecommand&ajax=1',
			'buttonText' : '选择文件',
			'onUploadSuccess' : function(file, data, response){
				data = eval('(' + data + ');');
				if(data.status == 1){
					$('#recommandImg').attr('src', data.data);
					$('#recommand').val(data.msg);
					$('#recommand_main').show(300);
				}else{
					$('#recommand_main').hide();
					UBox.show(data.msg, -1);
				}
			}
		});
	});
	
	function deleteImage(){
		$('#profile_main').hide();
		$('#exchange_profile').val('');
		$('#profileImg').attr('src', '');
	}
	
	function deleteRecommandImage(){
		$('#recommand_main').hide();
		$('#recommand').val('');
		$('#recommandImg').attr('src', '');
	}

	function addGoods(){
		if(checkForm() == true){
			$.ajax({
				url: '/?m=Exchange&a=add',
				data: $('#goodsAdd').serialize(),
				type: 'post',
				dataType: 'json',
				beforeSend: function(){
					$('#submitButton').attr('onclick', '').addClass('button_loading').html('处理中...');
				},
				complete:function(){
					$('#submitButton').attr('onclick', 'addGoods()').removeClass('button_loading').html('添加兑换物品');
				},
				success: function(aResult){
					if(aResult.status == 1){
						UBox.show(aResult.msg, 1, '/?m=Exchange&a=showDetail&id=' + aResult.data);
					}else{
						UBox.show(aResult.msg, -1);
					}
				},
				error: function(){
					UBox.show('系统错误', 0);
				}
			});
		}
	}
</script>