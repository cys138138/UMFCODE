<?php display('exchange/nav.html.php'); ?>
<div class="module _main">
	<style type="text/css">
		._main .item .name{width:100px;}
		._main .item .grade_select{float:left}
		
		
		._main .item .award_main{float:left;padding-bottom:15px}
		._main .item .award_main .award_text{float:left;cursor:default;}
		._main .item .award_main .award_sub{float:left;padding-left:20px;padding-right:5px;cursor:default;}
		._main .item .control .explain_label{float:left;padding:0 5px;cursor:default;}
		._main .item .award_main  .award_input{float:left;width:50px;}
		._main .item .control .category_main{float:left;padding-right:20px;}
		
		._subject span{margin-right:15px; display:inline-block;}
		
		
		._main .item .control #match_name{width:450px;}
		._main .item .control #description{width:450px;height:65px}
		._mian .item .profile_main{border:1px solid red;width:130px;height:90px;border:1px solid red;position:absolute; left:240px;top:-70px;}
		._mian .item .left{float:left;}	
		.point_a{font-weight: bold;float:left;font-size:18px;line-height:24px;margin-right:25px}
		.detail_nav{color:#000; font-size:18px;height:28px;line-height:28px;margin:10px; width:950px; text-align:right;}
		._main .profile_item{position:relative;overflow:visible}
		._main .profile_item .proflie_control{overflow:hidden; position: absolute; left: 300px; top: -50px;}
		._main .profile_item .proflie_control img{width:270px;height:300px; border:1px solid #CCC;padding:2px}
		
	</style>
		<div class="title">物品预览</div>
		<div class="item">
			<div class="name">兑换物品名称：</div>
			<div class="control"><?php echo $aGoods['name']; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">兑换物品截图：</div>
			<div class="control proflie_control">
				<img src="<?php echo SYSTEM_RESOURCE_URL . $aGoods['profile']; ?>" alt="" />
			</div>
		</div>
		<?php if($aGoods['recommand_time'] || $aGoods['recommand_image']){ ?>
		<div class="clear"></div>
		<div class="item">
			<div class="name">推荐时间：</div>
			<div class="control"><?php echo date('Y-m-d H:i:s', $aGoods['recommand_time']); ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">抢购时间：</div>
			<div class="control">
			<?php 
				if($aGoods['rush_time']){ 
					echo date('Y-m-d H:i:s', $aGoods['rush_time']); 
				}else{
					echo '非抢购商品';
				}
			?>
			</div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">推荐轮显图片：</div>
			<div class="control proflie_control">
				<img src="<?php echo SYSTEM_RESOURCE_URL . $aGoods['recommand_image']; ?>" alt="" />
			</div>
		</div>
		<?php }?>
		<div class="clear"></div>
		<div class="item">
			<div class="name">等级限制：</div>
			<div class="control"><?php echo $aGoods['level']; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">兑换金币：</div>
			<div class="control"><?php echo $aGoods['gold']; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">物品库存：</div>
			<div class="control"><?php echo $aGoods['stock']; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">默认排序：</div>
			<div class="control"><?php echo $aGoods['orders']; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">上架状态：</div>
			<div class="control"><?php echo $aGoods['release'] == 2 ? '已上架' : '已下架'; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">兑换物品简介：</div>
			<div class="control" id="summary"><?php echo $aGoods['summary']; ?></div>
		</div>
		
		<div class="clear"></div>
		<div class="item">
			<div class="name">兑换物品描述：</div>
			<div class="control" id="description"><?php echo $aGoods['description']; ?></div>
		</div>
		
		<div class="clear"></div><BR><BR>
</div>