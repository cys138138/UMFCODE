<link type="text/css" rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['wdatepicker']['path'] . $GLOBALS['RESOURCE']['wdatepicker']['js']; ?>"></script>
<style type="text/css">
	._condition .item a{color:#999; margin-right:10px;}
	._condition .item .on{font-weight:bold; color:#000;}
	._condition .name{width:65px;}
	._condition .control input{width:140px;}
	._condition a.button{color:#FC0; margin-left:5px;}

	._conditon .name{width:50px;}
	._conditon .width80{width:80px;}
	._conditon .width100{width:100px;}
	._conditon label{width:40px;}
	._conditon .control input[type="text"]{width:150px;}
	._conditon .control input.realName{width:100px;}
	._conditon ._ageInput input[type="text"]{width:60px;}
	._conditon ._quickTime a{color:#000000; margin-right:10px;}

	._userList .list .c1{width:130px;}
	._userList .list .c2{width:57px;}
	._userList .list .c3{width:65px;}
	._userList .list .c4{width:60px;}
	._userList .list .c5{width:60px;}
	._userList .list .c6{width:60px;}
	._userList .list .c7{width:60px;}
	._userList .list .c8{width:80px;}
	._userList .list .c9{width:120px;}
	._userList .list .c10{width:50px;}
	._userList .list .c11{width:50px;}
	._userList .list .c12{width:50px;}
	._userList .list .c13{width:60px;}
	._userList .list .c14{width:125px;}
	._userList .list .c15{width:165px;}
	._userList .list .c300{width:350px;}
	._userList .list .c400{width:400px;}
	._userList .list .row .c15 a{padding-right:5px;}
	._userList .list .edit_item{height:100px;overflow: hidden;border-bottom: 1px solid #000000;padding: 10px;display:none;}
</style>
<?php display('exchange/nav.html.php'); ?>
<div class="module _condition">
	<div class="item">
		<div class="name">兑换状态：</div>
		<div class="control">
			<a <?php if($status == 0){ ?> class="on" <?php } ?>  onclick="showList(0);">全部</a>
			<a <?php if($status == 1){ ?> class="on" <?php } ?>  onclick="showList(1);">待收货</a>
			<a <?php if($status == 2){ ?> class="on" <?php } ?>  onclick="showList(2);">已发货</a>
		</div>
	</div>
	<div class="clear"></div>
</div>

<div class="br"></div>
<div class="module _userList">
	<div class="title">兑换记录列表</div>
	<div class="list">
		<div class="row header">
			<div class="c2">兑换用户</div>
			<div class="c300">收货地址</div>
			<div class="c1">联系电话</div>
			<div class="c1">QQ号码</div>
			<div class="c1">收货人</div>
			<div class="c1">快递公司</div>
			<div class="c1">快递单号</div>
			<div class="c1">兑换物品</div>
			<div class="c13" style="width:125px;">兑换时间</div>
			<div class="c13">兑换状态</div>
			<div class="c15 right">操作</div>
		</div>
		<?php
			if($aExchangeList){
				foreach($aExchangeList as $aExchangeInfo){
					$testUserClass = in_array($aExchangeInfo['user_info']['id'], $GLOBALS['TEST_USER_LIST']) ? ' testUser' : '';
		?>
					<div class="row">
						<div class="c2 <?php echo $testUserClass; ?>">
							<a target="_blank" href="<?php echo url('m=Zone&a=showHome&userId=' . $aExchangeInfo['user_info']['id'], '', APP_HOME); ?>"<span class="name">
							<span class="name"><?php echo $aExchangeInfo['user_info']['name']; ?></span>
							</a>
						</div>
						<div class="c300" title="<?php echo $aExchangeInfo['address']; ?>"><?php echo $aExchangeInfo['address']; ?></div>
						<div class="c1"><?php echo $aExchangeInfo['mobile']; ?></div>
						<div class="c1"><?php echo $aExchangeInfo['qq']; ?></div>
						<div class="c1<?php echo $testUserClass; ?>"><span class="name"><?php echo $aExchangeInfo['receiver'] == '' ? '--' : $aExchangeInfo['receiver']; ?></span></div>
						<div class="c1" id="company_<?php echo $aExchangeInfo['id']; ?>"><?php echo $aExchangeInfo['express_company'] == '' ? '--' : $aExchangeInfo['express_company']; ?></div>
						<div class="c1" id="number_<?php echo $aExchangeInfo['id']; ?>"><?php echo $aExchangeInfo['express_number'] == '' ? '--' : $aExchangeInfo['express_number']; ?></div>
						<div class="c1"><a href="/?m=Exchange&a=showDetail&id=<?php echo $aExchangeInfo['goods_id']; ?>" title="<?php echo $aExchangeInfo['good_info']['name']; ?>"><?php echo $aExchangeInfo['good_info']['name']; ?></a></div>
						<div class="c13" style="width:125px;"><?php echo date('Y-m-d H:i:s', $aExchangeInfo['create_time']); ?></div>
						<div class="c13" id="status_<?php echo $aExchangeInfo['id']; ?>"><?php echo $aExchangeInfo['status'] == 1 ? '待收货' : '已发货'; ?></div>
						<?php if($aExchangeInfo['status'] == 1){ ?>
						<div class="c15 right">
							<a href="javascript:;" id="btn_<?php echo $aExchangeInfo['id']; ?>" goods_id="<?php echo $aExchangeInfo['goods_id']; ?>" onclick="showSend(<?php echo $aExchangeInfo['id']; ?>, this);">发货</a>
						</div>
						<?php } ?>
					</div>
		<?php
				}
			}else{
				echo '<div class="row"><div class="c1">暂无数据</div></div>';
				}
		?>
		<div class="row footer">
		<?php echo $pageHtml; ?>
		</div>
	</div>
</div>
<?php setRefererMark(); ?>

<script type="text/javascript">
	var currentEditId = 0;
	currentEditGoodsId = 0;
	function goodsSearch(type){
		var url = '/?m=Exchange&a=showList';

		window.location.href = url;
	}

	function showList(status){
		var url = '/?m=Exchange&a=showExchangeList&status=' + status;
		window.location.href = url;
	}

	function showSend(id, o){
		cancelEdit();
		currentEditId = id;
		$(o).text('取消操作');
		$(o).attr('onclick', 'cancelEdit();');
		var htmlStr = '<div class="row">';
		htmlStr += $(o).parent().parent().html();
		htmlStr += '</div>';
		htmlStr += '\
			<div id="edit_item" class="edit_item">\
				<h3>请填写快递信息</h3>\
				<div class="item">\
					<div class="name">快递公司：</div>\
					<div class="control"><input type="text" name="express_company" id="express_company" />&nbsp;&nbsp;</div>\
					<div class="name">快递单号：</div>\
					<div class="control"><input type="text" name="express_number" id="express_number" style="width:200px;" />&nbsp;&nbsp;</div>\
					<div class="control"><input type="button" class="button" name="express_submit" id="express_submit" value="提交" onclick="submitExpress(' + id + ');" /> </div>\
				</div>\
				<div class="clear"></div>\
			</div>\
		';
		$(o).parent().parent().replaceWith(htmlStr);
		$('#edit_item').slideDown();
	}

	function cancelEdit(){
		$('#edit_item').remove();
		$('#btn_' + currentEditId).text('发货');
		$('#btn_' + currentEditId).attr('onclick', 'showSend(' + currentEditId + ', this);');
	}

	function submitExpress(id){
		var expressCompany = $('#express_company').val(),
		expressNumber = $('#express_number').val();
		if(expressCompany == '' || expressNumber == ''){
			return false;
		}
		$.ajax({
				url: '/?m=Exchange&a=editExchange',
				data: {
					'id' : currentEditId,
					'express_company' : expressCompany,
					'express_number' : expressNumber
				},
				type: 'post',
				dataType: 'json',
				beforeSend: function(){
					$('#express_submit').attr('disabled', 'true');
				},
				complete:function(){
					$('#express_submit').removeAttr('disabled');
				},
				success: function(aResult){
					if(aResult.status == 1){
						cancelEdit();
						$('#btn_' + currentEditId).text('');
						$('#btn_' + currentEditId).removeAttr('onclick');
						$('#company_' + currentEditId).text(expressCompany);
						$('#number_' + currentEditId).text(expressNumber);
						$('#status_' + currentEditId).text('已发货');
						UBox.show(aResult.msg, 1);
					}else{
						UBox.show(aResult.msg, -1);
					}
				},
				error: function(){
					UBox.show('系统错误', 0);
				}
			});
	}
</script>
