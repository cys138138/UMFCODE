<div class="nav">
	<a <?php if(get('a') == 'showList'){ ?>class="on"<?php } ?> href="?m=Exchange&a=showList">兑换物品列表 </a>
	<a <?php if(get('a') == 'showExchangeList'){ ?>class="on"<?php } ?> href="?m=Exchange&a=showExchangeList">兑换物品记录 </a>
	<a <?php if(get('a') == 'showAdd'){ ?>class="on"<?php } ?> href="?m=Exchange&a=showAdd">添加兑换物品 </a>
	<?php if(get('a') == 'showEdit'){ ?><a class="on" href="#">兑换物品编辑 </a><?php } ?>
	<?php if(get('a') == 'showDetail'){ ?><a class="on" href="#">查看兑换物品 </a><?php } ?>
</div>

<div class="br"></div>
