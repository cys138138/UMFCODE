<body class="left">
	<?php foreach($GLOBALS['PERMISSION'] as $aPermissionGroup){
		$havePermission = $isAdmin;
		foreach($aPermissionGroup['child'] as $key => $aPermission){
			if(in_array($key, $aUserPermission)){
				$havePermission = true;
				break;
			}
		}
		if(!$havePermission){
			continue;
		}
	?>
	<a class="menu "><?php echo $aPermissionGroup['title']; ?></a>
	<div class="subMenu" style="display:none;">
		<?php foreach($aPermissionGroup['child'] as $key => $aPermission){
				if(!in_array($key, $aUserPermission) && !$isAdmin){ continue; }
		?>
		<a href="<?php echo $aPermission['url']; ?>" target="main"><?php echo $aPermission['title']; ?></a>
		<?php } ?>
	</div>
	<?php }?>
	<script type="text/javascript">
		$('.menu').click(function(){
			oCategory = $(this);
			oMenu = oCategory.next('.subMenu');
			if(oMenu.css('display') == 'none'){
				oMenu.slideDown(100);
				oCategory.addClass('on');
			}else{
				oMenu.slideUp(100);
				oCategory.removeClass('on');
			}
		});

		$('.subMenu a').click(function(){
			$('.subMenu a').removeClass('on');
			$(this).addClass('on');
		});
	</script>
</body>