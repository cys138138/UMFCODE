<?php
class MatchController{

	private $_permissionFlag = 'manage_match';
	private $_userId = 0;

	//赛事时长
	private $_durationArray = array(5, 10, 20, 30, 45, 60, 90, 120);

	//科目
	private function _getSubjectList(){
		$subjectArray = array();
		foreach($GLOBALS['SUBJECT'] as $key=> $subject){
			$subjectArray[$key] = $subject;
		}
		$subjectArray[99] = '综合';
		return $subjectArray;
	}

	//年级列表
	private $_gradeArray = array(
		/*
		1	=>	'一年级',
		2	=>	'二年级',
		3	=>	'三年级',
		4	=>	'四年级',
		 */
		5	=>	'五年级',
		6	=>	'六年级',
		7	=>	'初一',
		8	=>	'初二',
		9	=>	'初三',
		10	=>	'小升初',
		11	=>	'中考'
	);

	//奖项
	private $_awardsArray = array(
		1 => '第一名',
		2 => '第二名',
		3 => '第三名',
		4 => '第四名',
		5 => '第五名',
		6 => '第六名',
		7 => '第七名',
		8 => '第八名',
		9 => '第九名',
		10 => '第十名'
	);

	public function __construct(){
		if(get('a') != 'uploadProfile'){
			$this->_userId = checkLogin();
			if(!checkPermission($this->_userId, $this->_permissionFlag)){
				wrong('您没有权限对此操作');
			}
		}
	}

	//显示赛事列表
	public function showMatchList(){
		tipsNewManage();
		$matchId = intval(get('matchId', 0));
		$matchName = get('matchName', '');
		$timeType = intval(get('timeType', 0));
		$startTime = get('startTime', '');
		$endTime = get('endTime', '');
		$limitLevel = intval(get('limitLevel', -1));
		$gradeId = intval(get('gradeId', -1));
		$subjectId = intval(get('subjectId', -1));
		$isRelease = intval(get('isRelease', -1));
		$limitXxtType = intval(get('limit_xxt_type', -1));
		$url = '?m=Match&a=showMatchList';
		$page = intval(get('page', 1));
		$pageSize = 10;
		$pageCount = 1;
		$matchCount = 0;
		$pageHtml = '';
		$aMatchList = array();
		$aCondition = array();
		if($page < 1){
			$page = 1;
		}
		$oMatch = m('Match');
		if($matchId > 0){
			$aMatchInfo = $oMatch->getMatchInfoById($matchId);
			if($aMatchInfo === false){
				alert('系统错误', 0);
			}
			if($aMatchInfo){
				$aMatchList[0] = $aMatchInfo;
			}
		}else{
			if($matchName){
				$aCondition['name'] = $matchName;
				$url .= '&matchName=' . $matchName;
			}
			if($timeType > 0){
				if(strtotime($startTime) > 0 && strtotime($endTime) > 0 ){
					$aCondition['time_type'] = $timeType;
					$aCondition['time_rate_start'] = strtotime($startTime);
					$aCondition['time_rate_end'] = strtotime($endTime);
					$url .= '&timeType=' . $timeType . '&startTime=' . $startTime . '&endTime=' . $endTime;
				}
			}
			if($limitLevel > -1){
				$aCondition['level'] = $limitLevel;
				$url .= '&limitLevel=' . $limitLevel;
			}

			if($gradeId > 0){
				$aCondition['grade_id'] = $gradeId;
				$url .= '&gradeId=' . $gradeId;
			}
			if($subjectId > 0){
				$aCondition['subject_id'] = $subjectId;
				$url .= '&subjectId=' . $subjectId;
			}
			if($isRelease == 0 ){
				$aCondition['status'] = 1;
				$url .= '&isRelease=' . $isRelease;
			}
			if($isRelease == 1 ){
				$aCondition['status'] = 2;
				$url .= '&isRelease=' . $isRelease;
			}
			if($limitXxtType != -1){
				$aCondition['xxt_type'] = $limitXxtType;
				$url .= '&limit_xxt_type=' . $limitXxtType;
			}
			$matchCount = $oMatch->getMatchCount($aCondition);
			if($matchCount === false){
				alert('系统错误', 0);
			}
			if($matchCount > 0){
				$pageCount = ceil($matchCount / $pageSize);
				if($page > $pageCount){
					$page = $pageCount;
				}
				$aMatchList = $oMatch->getMatchList($aCondition, $page, $pageSize);
				if($aMatchList === false){
					alert('系统错误', 0);
				}
				if($pageCount > 1){
					$url .= '&page=_PAGE_';
					$aPageInfo = array(
						'url' 	=> $url,
						'total' => $matchCount,
						'size' 	=> $pageSize,
						'page' 	=> $page,
					);
					$pageHtml = page($aPageInfo);
				}
			}
		}
		assign('matchId', $matchId);
		assign('matchName', $matchName);
		assign('timeType', $timeType);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		assign('limitLevel', $limitLevel);
		assign('limitXxtType', $limitXxtType);
		assign('gradeId', $gradeId);
		assign('subjectId', $subjectId);
		assign('isRelease', $isRelease);
		assign('durationArray', $this->_durationArray);
		assign('levelArray', $this->_getLevel());
		assign('gradeArray', $this->_gradeArray);
		assign('subjectArray', $this->_getSubjectList());
		assign('aMatchList', $aMatchList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('match/list.html.php');
		displayFooter();
	}

	//显示赛事添加页面
	public function showAddMatch(){
		//description,
		assign('validateAddMatchJs', j('match_name,match_start_time,match_end_time,registration_fee,rejoin_fee,duration,limit_level,limit_times,view_css,grade_id,subject_id'));
		assign('durationArray', $this->_durationArray);
		assign('levelArray', $this->_getLevel());
		assign('limitArray', $this->_getLimit());
		assign('gradeArray', $this->_gradeArray);
		assign('subjectArray', $this->_getSubjectList());
		displayHeader();
		display('match/add.html.php');
		displayFooter();
	}

	//赛事添加
	public function addMatch(){
		$vAddResult = v('match_name,match_start_time,match_end_time,registration_fee,rejoin_fee,duration,limit_level,limit_times,view_css,grade_id,subject_id');
		if($vAddResult){
			alert($vAddResult, 0);
		}
		$aData = array(
			'name'						=> post('match_name'),							//名称
			//'description'				=> post('description'),							//摘要
			'rule' 						=> isset($_POST['rule']) ? $_POST['rule'] : '',	//规则
			'match_start_time' 			=> strtotime(post('match_start_time')),			//开始时间
			'match_end_time'			=> strtotime(post('match_end_time')),			//结束时间
			'registration_fee'			=> intval(post('registration_fee', 0)),			//报名费
			'rejoin_fee'				=> intval(post('rejoin_fee', 0)),				//续场费
			'profile'					=> post('profile'),								//封面
			'duration'					=> intval(post('duration', '-1')),				//时长
			'limit_level'				=> intval(post('limit_level', '-1')),			//等级
			'limit_times'				=> intval(post('limit_times', '-1')),			//次数
			'limit_grades'				=> (array)post('limit_grades', '-1'),			//年级
			'limit_xxt_type'			=> (array)(post('limit_xxt_type', '')),			//用户类型
			'is_team_match'				=> intval(post('is_team_match', 0)),
			'view_css'					=> intval(post('view_css', '-1')),				//风格样式
			'grade_id'					=> intval(post('grade_id', 0)),					//年级ID
			'subject_id'				=> intval(post('subject_id', 0)),				//科目ID
			'create_time'				=> time(),										//创建时间
		);
		if(!$aData['rule']){
			alert('详细介绍不能为空', 0);
		}
		if($aData['match_end_time'] <= $aData['match_start_time']){
			alert('比赛结束时间必须大于比赛开始时间', 0);
		}
		if(!$aData['profile']){
			alert('请上传主题图片', 0);
		}
		$tmpProfile = SYSTEM_RESOURCE_PATH . str_replace(MATCH_PROFILE_PATH, MATCH_PROFILE_TMP_PATH, $aData['profile']);
		$profile = SYSTEM_RESOURCE_PATH .  $aData['profile'];
		if(!file_exists($tmpProfile)){
			alert('主题图片上传错误', 0);
		}
		if(!in_array($aData['duration'], $this->_durationArray)){
			alert('请选择赛事时长', 0);
		}
		$match_time = intval($aData['match_end_time'] - $aData['match_start_time']) / 60;
		if($match_time < $aData['duration'] ){
			alert('赛事开始时间到结束时间的时长不能小于' . $aData['duration'] . '分钟', 0);
		}
		$levelArray = $this->_getLevel();
		if(!in_array($aData['limit_level'], $levelArray)){
			alert('请选择最小报名等级', 0);
		}
		$limitArray = $this->_getLimit();
		if(!in_array($aData['limit_times'], $limitArray)){
			alert('请选参赛次数', 0);
		}
		foreach($aData['limit_grades'] as &$greadeId){
			if($greadeId == 0){
				$aData['limit_grades'] = array(0);
				break;
			}elseif(!array_key_exists(intval($greadeId), $GLOBALS['UMF_GRADE'])){
				alert('请选择正确年级限制', 0);
			}
		}
		if(!$aData['limit_xxt_type']){
			alert('请选择参赛用户类型', 0);
		}
		if(!isset($this->_gradeArray[$aData['grade_id']])){
			alert('参赛年级错误', 0);
		}
		if($aData['view_css'] == '-1'){
			alert('请选择模板风格', 0);
		}

		$oMatch = m('Match');
		//查询同名的比赛是否己存在
		$aCondition = array('name' => $aData['name']);
		$checkResult = $oMatch->getMatchCount($aCondition);
		if($checkResult === false){
			alert('系统错误', 0);
		}
		if($checkResult > 0){
			alert('标题为: ' . $aData['name'] . ' 的比赛记录己存在', 0);
		}
		//入库
		$insertResult = $oMatch->addMatch($aData);
		if($insertResult === false){
			alert('系统错误', 0);
		}
		if($insertResult){
			if(rename($tmpProfile, $profile)){
				alert($insertResult, 1);
			}else{
				$oMatch->deleteMatchById($insertResult);
				if(file_exists($tmpProfile)){
					unlink($tmpProfile);
				}
				alert('添加失败', 0);
			}
		}else{
			if(file_exists($tmpProfile)){
				unlink($tmpProfile);
			}
			alert('添加失败', 0);
		}
	}


	//赛事基本资料编辑模板
	public function showEditMatchBasic(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);

		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('数据不存在', 0);
		}

		$aMatchInfo['profile_url'] = '';
		if($aMatchInfo['profile']){
			$aMatchInfo['profile_url'] = SYSTEM_RESOURCE_URL . $aMatchInfo['profile'];
		}
		$aMatchInfo['rule'] = addslashes($aMatchInfo['rule']);
		//description,
		assign('validateAddMatchJs', j('match_name,match_start_time,match_end_time,registration_fee,rejoin_fee,duration,limit_level,limit_times,view_css,grade_id,subject_id'));
		assign('aMatchInfo', $aMatchInfo);
		assign('durationArray', $this->_durationArray);
		assign('levelArray', $this->_getLevel());
		assign('limitArray', $this->_getLimit());
		assign('gradeArray', $this->_gradeArray);
		assign('subjectArray', $this->_getSubjectList());
		displayHeader();
		display('match/edit_basic.html.php');
		displayFooter();
	}

	//赛事基本资料更新
	public function editMatchBasic(){
		$vAddResult = v('match_name,match_start_time,match_end_time,registration_fee,rejoin_fee,duration,limit_level,limit_times,limit_grades,view_css,grade_id,subject_id');
		if($vAddResult){
			alert($vAddResult, 0);
		}

		$id = intval(get('id', 0));
		if($id <= 0){
			alert('数据错误');
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('该记录不存在', 0);
		}

		$aData = array(
			'id'						=> $id,
			'name'						=> post('match_name'),							//名称
			//'description'				=> post('description'),							//摘要
			'rule' 						=> isset($_POST['rule']) ? $_POST['rule'] : '',	//规则
			'match_start_time' 			=> strtotime(post('match_start_time')),			//开始时间
			'match_end_time'			=> strtotime(post('match_end_time')),			//结束时间
			'registration_fee'			=> intval(post('registration_fee', 0)),			//报名费
			'rejoin_fee'				=> intval(post('rejoin_fee', 0)),				//续场费
			'profile'					=> post('profile'),								//封面
			'duration'					=> intval(post('duration', '-1')),				//时长
			'limit_level'				=> intval(post('limit_level', '-1')),			//等级
			'limit_times'				=> intval(post('limit_times', '-1')),			//次数
			'limit_grades'				=> (array)post('limit_grades', '-1'),			//年级
			'limit_xxt_type'			=> (array)(post('limit_xxt_type', '')),				//用户类型
			'is_team_match'				=> intval(post('is_team_match', 0)),
			'view_css'					=> intval(post('view_css', '-1')),				//风格样式
			'grade_id'					=> post('grade_id', 0),							//年级ID
			'subject_id'				=> post('subject_id', 0),						//科目ID
		);
		if(!$aData['rule']){
			alert('详细介绍不能为空', 0);
		}
		if($aData['match_end_time'] <= $aData['match_start_time']){
			alert('比赛结束时间必须大于比赛开始时间', 0);
		}
		if(!$aData['profile']){
			alert('请上传主题图片', 0);
		}
		$tmpProfile = SYSTEM_RESOURCE_PATH . str_replace(MATCH_PROFILE_PATH, MATCH_PROFILE_TMP_PATH, $aData['profile']);
		$profile = SYSTEM_RESOURCE_PATH .  $aData['profile'];
		if($aMatchInfo['profile'] != $aData['profile']){
			if(!file_exists($tmpProfile)){
				alert('主题图片上传错误', 0);
			}
		}
		if(!in_array($aData['duration'], $this->_durationArray)){
			alert('请选择赛事时长', 0);
		}
		$match_time = intval($aData['match_end_time'] - $aData['match_start_time']) / 60;
		if($match_time < $aData['duration'] ){
			alert('赛事开始时间到结束时间的时长不能小于' . $aData['duration'] . '分钟', 0);
		}
		$levelArray = $this->_getLevel();
		if(!in_array($aData['limit_level'], $levelArray)){
			alert('请选择最小报名等级', 0);
		}
		$limitArray = $this->_getLimit();
		if(!in_array($aData['limit_times'], $limitArray)){
			alert('请选参赛次数', 0);
		}
		foreach($aData['limit_grades'] as &$greadeId){
			if($greadeId == 0){
				$aData['limit_grades'] = array(0);
				break;
			}elseif(!array_key_exists(intval($greadeId), $GLOBALS['UMF_GRADE'])){
				alert('请选择正确年级限制', 0);
			}
		}

		if(!$aData['limit_xxt_type']){
			alert('请选择参赛用户类型', 0);
		}
		if(!isset($this->_gradeArray[$aData['grade_id']])){
			alert('参赛年级错误', 0);
		}
		if($aData['view_css'] == '-1'){
			alert('请选择模板风格', 0);
		}

		//查询同名的比赛是否己存在
		$aCondition = array('name' => $aData['name']);
		$aCheckResultArray = $oMatch->getMatchList($aCondition);
		if($aCheckResultArray === false){
			alert('系统错误', 0);
		}
		if($aCheckResultArray){
			foreach($aCheckResultArray as $aCheckResultInfo){
				if($aCheckResultInfo['id'] != $id){
					alert('标题为: ' . $aData['name'] . ' 的比赛记录己存在', 0);
				}
			}
		}
		if($aMatchInfo['profile'] != $aData['profile']){
			if(rename($tmpProfile, $profile)){
				$editResult = $oMatch->setMatch($aData);
				if($editResult === false){
					if(file_exists($profile)){
						unlink($profile);
					}
					alert('系统错误', 0);
				}else{
					if(file_exists(SYSTEM_RESOURCE_PATH . $aMatchInfo['profile'])){
						unlink(SYSTEM_RESOURCE_PATH . $aMatchInfo['profile']);
					}
					alert('', 1);
				}
			}else{
				alert('封面上传错误', 0);
			}
		}else{
			$editResult = $oMatch->setMatch($aData);
			if($editResult === false){
				alert('系统错误', 0);
			}else{
				alert('', 1);
			}
		}
	}

	//奖项设置模板
	public function showEditMatchPrize(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');

		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('记录不存在', 0);
		}
		if($aMatchInfo['is_release'] == 1){
			//alert('此赛事己发布，无法编辑', 0);
		}
		assign('validateAddMatchJs', j('description,'));
		assign('aMatchInfo', $aMatchInfo);
		assign('awardsArray', $this->_awardsArray);
		displayHeader();
		display('match/edit_prize.html.php');
		displayFooter();
	}


	//奖项设置
	public function editMatchPrize(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$vAddResult = v('description');
		if($vAddResult){
			alert($vAddResult, 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('记录不存在', 0);
		}
		if($aMatchInfo['is_release'] == 1){
			//alert('此赛事己发布，无法编辑', 0);
		}

		$aData = array(
			'id' => $id ,
			'description' => post('description')
		);
		$awardsArray = $this->_awardsArray;
		$awardNum = intval(post('awardNum', 0));
		if($awardNum < 1 || $awardNum > 10){
			alert('奖项设置错误', 0);
		}

		//排名奖项
		$aTopArray = array();
		$gold = 0;
		$prize = '';
		for($i =1; $i<=$awardNum; $i++){
			$gold = intval(post('top'. $i .'_gold', 0));
			$prize = post('top'. $i .'_prize', '');
			if($gold == 0 && $prize == ''){
				alert($awardsArray[$i] . '至少要有一项奖励', 0);
			}

			if($gold != 0 && $gold < 1){
				alert($awardsArray[$i] . '的金币奖励输入错误', 0);
			}

			$aTopArray[$i]['gold'] = $gold;
			$aTopArray[$i]['prize'] = $prize;
		}

		$aData['awards']['top'] = $aTopArray;
		unset($gold);
		unset($prize);
		unset($aTopArray);

		//幸运奖项
		$aRandArray = array();
		$lucklyStart = intval(post('luckly_start', 0));
		$lucklyEnd = intval(post('luckly_end', 0));
		$lucklyCount = intval(post('luckly_count', 0));
		$lucklyGold = intval(post('luckly_gold', 0));
		$lucklyPrize = post('luckly_prize', '');
		if($lucklyStart == 0 || $lucklyEnd == 0 ){
			alert('幸运奖项排名设置错误', 0);
		}
		if($lucklyEnd <= $lucklyStart){
			alert('幸运奖项排名设置错误', 0);
		}
		if($lucklyCount == 0){
			alert('幸运奖项名额设置错误', 0);
		}
		if($lucklyCount > ($lucklyEnd - $lucklyStart)){
			alert('幸运奖项名额设置错误', 0);
		}

		if($lucklyGold == 0 && $lucklyPrize == ''){
			alert('幸运奖至少要有一种奖励', 0);
		}

		if($lucklyGold != 0 && $lucklyGold < 1){
			alert('幸运奖项金币奖励设置错误', 0);
		}

		$aRandArray['ranking_rate'] = array($lucklyStart, $lucklyEnd);
		$aRandArray['number'] = $lucklyCount;
		$aRandArray['gold'] = $lucklyGold;
		$aRandArray['prize'] = $lucklyPrize;

		$aData['awards']['rand'] = $aRandArray;
		unset($lucklyStart);
		unset($lucklyEnd);
		unset($lucklyCount);
		unset($lucklyGold);
		unset($lucklyPrize);
		unset($aRandArray);
		$result = $oMatch->setMatch($aData);
		if($result === false){
			alert('系统错误', 0);
		}else{
			alert('操作成功', 1);
		}
	}

	//选题模板页
	public function showEditMatchTopic(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('该记录不存在', 0);
		}
		if($aMatchInfo['is_release'] == 1){
			//alert('此赛事己发布，无法编辑', 0);
		}


		//查询出所有科目目录
		$aSubjectIdsArray = array();
		$aCategoryList = array();
		$aSubject = isset($GLOBALS['SUBJECT']) ? $GLOBALS['SUBJECT'] : '';
		$aMatchSubject = $this->_getSubjectList();

		if(isset($aMatchSubject[$aMatchInfo['subject_id']])){
			if(isset($aSubject[$aMatchInfo['subject_id']])){
				$aSubjectIdsArray[0] = $aMatchInfo['subject_id'];
			}else{
				//综合
				$aSubjectIdsArray = array_keys($aSubject);
			}
		}else{
			alert('科目配置出错', 0);
		}
		$oEs = m('Es');
		if($aSubject){
			//取配置中关于科目配置的下标
			if(count($aSubjectIdsArray) > 0){
				foreach($aSubjectIdsArray as $subjectId){
					//查询每个科目下的目录
					$aCategoryList[$subjectId] = $oEs->getCategoryDetailedListBySubjectId($subjectId);
					if($aCategoryList[$subjectId] === false){
						alert('系统出错，请稍后再试！', 0);
					}
					foreach($aCategoryList[$subjectId] as $key => $aCategory){
						//每个目录下的题目数量
						$nums = $oEs->isExistSubCategory($aCategory['id']);
						if($nums > 0){
							continue;
						}
						//根据题目科目及目录获得各题型题目数量
						$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($aCategory['subject_id'], array($aCategory['id']));
						if($aCategoryTypeAndCounts === false){
							alert('系统错误', 0);
						}
						$typeAndCounts = ' [ ';
						foreach($aCategoryTypeAndCounts as $typeKey => $categoryTypeAndCounts){
							$typeAndCounts .= $GLOBALS['ES_TYPE'][$typeKey] . ' : ' . $categoryTypeAndCounts . ' ';
						}
						$typeAndCounts .= ']';
						$aCategoryList[$subjectId][$key]['name'] .= $typeAndCounts;
					}
				}
			}else{
				alert('科目配置出错', 0);
			}
		}else{
			alert('科目配置出错', 0);
		}

		//将己选择的目录处理成前端需要的格式，并查询出名称
		$aMatchCategory = array(
			'category_ids' 	 =>'',
			'category_titles'=> ''
		);
		$aCategorInfo = array();
		$aCategoryTypeAndCounts = array();
		if($aMatchInfo['es_category_ids']){
			foreach($aMatchInfo['es_category_ids'] as $categoryId){
				$aCategorInfo = $oEs->getCategoryInfoByCategoryId($categoryId);
				if($aCategorInfo === false){
					alert('系统错误', 0);
				}
				if($aCategorInfo){
					$aCategoryTypeAndCounts = array();
					$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($aCategorInfo['subject_id'], array($aCategorInfo['id']));
					if($aCategoryTypeAndCounts === false){
						alert('系统错误', 0);
					}
					$typeAndCounts = '';
					foreach($aCategoryTypeAndCounts as $typeKey => $categoryTypeAndCounts){
						$typeAndCounts .= $GLOBALS['ES_TYPE'][$typeKey] . ' ' . $categoryTypeAndCounts . ' ';
					}
					$aMatchCategory['category_ids'] .= $categoryId . ',';
					$aMatchCategory['category_titles'] .= '<label xid="' . $categoryId . '">' . $aCategorInfo['name'] . ' [' . $typeAndCounts . ']<a onclick="deleteCategory(' . $categoryId . ')" style="font-size:18px;">×</a></label> ';
				}
			}
		}
		assign('aCategoryList', $aCategoryList);
		assign('aSubject', $aSubject);
		assign('aSubjectIdsArray', $aSubjectIdsArray);
		assign('aMatchInfo', $aMatchInfo);
		assign('aMatchCategory', $aMatchCategory);
		assign('esTypeArray', $this->_getEsType());
		displayHeader();
		display('match/edit_topic.html.php');
		displayFooter();
	}

	//选题
	public function editMatchTopic(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('记录不存在', 0);
		}
		if($aMatchInfo['is_release'] == 1){
			//alert('此赛事己发布，无法编辑', 0);
		}

		$aData = array(
			'id' 				=> $id,
			'is_release' 		=> intval(post('is_release')),
			'es_category_ids' 	=> rtrim(post('categoryIds'), ',')
		);

		if($aData['is_release'] != 0 && $aData['is_release'] != 1){
			alert('请选择发布状态', 0);
		}

		$typeCheckbox = post('type_checkbox');
		if(!$typeCheckbox){
			alert('请选择题型', 0);
		}

		//判断所选题型是否在定义范围之内及题目数量是否输入正确
		$aEsRuleArray = array();
		$aEsTypeArray = $this->_getEsType();
		foreach($typeCheckbox as $typeInfo){
			if(!isset($aEsTypeArray[$typeInfo])){
				alert('题型选择错误', 0);
			}
			$typeNum = post('type_input_' . $typeInfo);
			if(!preg_match('/^[1-9]{1}\d*$/', $typeNum)){
				alert($aEsTypeArray[$typeInfo] . '的数量为空或格式错误', 0);
			}
			$aEsRuleArray[] = array('es_type_id' => $typeInfo, 'es_count' => $typeNum);
		}
		$aData['es_rule'] = $aEsRuleArray;

		//判断是否选择了目录
		if(!$aData['es_category_ids']){
			alert('请选择题目目录', 0);
		}

		//将目录字段从字符串转换成数组
		$aCategoryIds = explode(',', $aData['es_category_ids']);
		if(!$aCategoryIds){
			alert('请选择题目目录', 0);
		}
		$aData['es_category_ids'] = $aCategoryIds;

		//所有题目ID
		$aEsSetArray = $oMatch->getEsSetForMatch($aCategoryIds);
		if($aEsSetArray === false){
			alert('系统错误', 0);
		}

		//判断当前所选目录中是否有足够数量的规定题型
		foreach($aEsRuleArray as $key => $ruleInfo){
			if(!isset($aEsSetArray[$ruleInfo['es_type_id']]) || count($aEsSetArray[$ruleInfo['es_type_id']]) < $ruleInfo['es_count'] ){
				alert('当前选择的目录中没有 ' .  $aEsTypeArray[$ruleInfo['es_type_id']] . ' 或 ' . $aEsTypeArray[$ruleInfo['es_type_id']] . ' 数量小于规定数量', 0);
			}
		}

		//所有题目
		$aData['es_set'] = $aEsSetArray;
		$result = $oMatch->setMatch($aData);
		if($result === false){
			alert('系统错误', 0);
		}else{
			alert('操作成功', 1);
		}
	}

	//赛事预览
	public function showDetailMatch(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('记录不存在', 0);
		}
		$aMatchInfo['profile'] = SYSTEM_RESOURCE_URL . $aMatchInfo['profile'];
		assign('aMatchInfo', $aMatchInfo);
		assign('gradeArray', $this->_gradeArray);
		assign('awardsArray', $this->_awardsArray);
		assign('esTypeArray', $this->_getEsType());
		assign('subjectArray', $this->_getSubjectList());

		//将己选择的目录处理成前端需要的格式，并查询出名称
		$cagegoryStr = '';
		$aCategorInfo = array();
		if($aMatchInfo['es_category_ids']){
			$oEs = m('es');
			foreach($aMatchInfo['es_category_ids'] as $categoryId){
				$aCategorInfo = $oEs->getCategoryInfoByCategoryId($categoryId);
				if($aCategorInfo === false){
					alert('系统错误', 0);
				}
				if($aCategorInfo){
					$aCategoryTypeAndCounts = array();
					$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($aCategorInfo['subject_id'], array($aCategorInfo['id']));
					if($aCategoryTypeAndCounts === false){
						alert('系统错误', 0);
					}
					$typeAndCounts = '';
					foreach($aCategoryTypeAndCounts as $typeKey => $categoryTypeAndCounts){
						$typeAndCounts .= $GLOBALS['ES_TYPE'][$typeKey] . ' ' . $categoryTypeAndCounts . ' ';
					}
					$cagegoryStr .= '<label style="padding-right:15px" >' . $aCategorInfo['name'] . ' [' . $typeAndCounts . ']</label>';
				}
			}
		}
		assign('cagegoryStr', $cagegoryStr);
		displayHeader();
		display('match/detail.html.php');
		displayFooter();
	}

	//赛事删除
	public function deleteMatch(){
		$id = intval(post('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('要删除的数据不存在', 0);
		}
		if($aMatchInfo['is_release'] == 1){
			alert('这个比赛己发布，不能删除', 0);
		}
		$result = $oMatch->deleteMatchById($id);
		if($result === false){
			alert('系统错误', 0);
		}
		if($result){
			if(file_exists(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_PATH . $aMatchInfo['profile'])){
				unlink(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_PATH . $aMatchInfo['profile']);
			}
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}

	//赛事得分修改模板
	public function showEditMatchScore(){
		$id = intval(get('id', 0));
		$oMatch = m('Match');
		$aMatchInfo = $oMatch -> getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('这条记录不存在', 0);
		}
		if($aMatchInfo['is_release'] != 1){
			alert('这场比赛还没发布呢', 0);
		}
		if($aMatchInfo['match_start_time'] > time()){
			alert('这场比赛还没开始呢', 0);
		}

		assign('aMatchInfo', $aMatchInfo);
		displayHeader();
		display('match/edit_match_score.html.php');
		displayFooter();

	}

	//修改比赛得分
	public function editMatchScore(){
		$aData = array(
			'id'		 =>	intval(post('relationId', 0)),
			'best_score' =>	intval(post('userScore', 0))
		);
		if($aData['id'] < 1 || $aData['best_score'] < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$result = $oMatch->setMatchUserRelation($aData);
		if($result === false){
			alert('系统错误', 0);
		}
		alert($result, 1);
	}


	//得到参加比赛用户的信息
	public function getUserInfo(){
		$matchId = intval(post('matchId', 0));
		$userAccount = post('userAccount');
		$type = intval(post('type', 0));

		if($matchId < 1 || !$userAccount || ($type !=1 && $type != 2 )){
			alert('数据错误', 0);
		}
		if($type == 1){
			$userAccount = intval($userAccount);
			if($userAccount < 1){
				alert('帐号为用户ID或邮箱', 0);
			}
		}
		if($type == 2){
			$result = w('isEmail()', $userAccount);
			if($result === false){
				alert('帐号为用户ID或邮箱', 0);
			}
		}

		$oUser = m('User');
		$aUserInfo = array();
		$aPersonalInfo = array();
		if($type == 1){
			$aUserInfo = $oUser->getUserInfoByNumberId($userAccount);
		}elseif($type == 2){
			$aUserInfo = $oUser->getUserInfoByEmail($userAccount);
		}
		if($aUserInfo === false){
			alert('系统错误', 0);
		}
		if(!$aUserInfo){
			alert('这个用户不存在', 0);
		}

		$aPersonalInfo = $oUser->getPersonalInfoByUserId($aUserInfo['id']);
		if($aPersonalInfo === false){
			alert('系统错误', 0);
		}
		if(!$aPersonalInfo){
			alert('这个用户不存在', 0);
		}

		$oMatch = m('Match');
		$aRelationInfo = array();
		$aRelationInfo = $oMatch->getMatchUserRelationInfo($aUserInfo['id'], $matchId);
		if($aRelationInfo === false){
			alert('系统错误', 0);
		}

		if(!$aRelationInfo){
			alert('该用户没有参加这场比赛呢', 0);
		}
		$aData = array(
			'user_id'	=> $aUserInfo['id'],
			'user_name'	=> $aPersonalInfo['name'],
			'user_email'=> $aUserInfo['email'],
			'relation_id'=> $aRelationInfo['id'],
			'best_score'=> $aRelationInfo['best_score']
		);
		alert('', 1, $aData);
	}

	//抽奖模板页
	public function showMakePrize(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('这条记录不存在', 0);
		}
		if($aMatchInfo['is_release'] != 1){
			alert('这场比赛还没发布呢', 0);
		}
		if($aMatchInfo['match_end_time'] > time()){
			alert('这场比赛还没结束呢', 0);
		}
		if(!$aMatchInfo['awards']){
			alert('这场比赛没有设置奖项信息哦', 0);
		}
		if($aMatchInfo['winners']){
			alert('这场比赛己经抽过奖了', 0);
		}

		$aAwardsList = $oMatch->getPrizeUserList($id, $aMatchInfo['awards']);
		if($aAwardsList === false){
			alert('系统错误', 0);
		}
		if(!$aAwardsList){
			alert('还没有用户参加过这场比赛', 0);
		}

		assign('aAwardsList', $aAwardsList);
		assign('aMatchInfo', $aMatchInfo);
		assign('awardsArray', $this->_awardsArray);
		displayHeader();
		display('match/make_prize.html.php');
		displayFooter();
	}

	//抽奖－写库
	public function makePrize(){
		$id = intval(post('matchId', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('这条记录不存在', 0);
		}
		if($aMatchInfo['is_release'] != 1){
			alert('这场比赛还没发布呢', 0);
		}
		if($aMatchInfo['match_end_time'] > time()){
			alert('这场比赛还没结束呢', 0);
		}
		if(!$aMatchInfo['awards']){
			alert('这场比赛没有设置奖项信息哦', 0);
		}
		if($aMatchInfo['winners']){
			alert('这场比赛己经抽过奖了', 0);
		}
		$aRelationInfo = array();
		$aTopArray = array();
		$aTopUserIds = array();
		$aRandArray = array();
		$topCount = 0;
		$randCount = 0;
		$aTopUserIdList = array();
		$aRandUserIdList = array();
		$aEventData = array();
		$aPrizeUserList = array();
		if(isset($aMatchInfo['awards']['top'])){
			$topCount = count($aMatchInfo['awards']['top']);
			$j = 1;
			for($i = 1; $i <= $topCount; $i++){
				$topUserId = intval(post('top_award_' . $i, 0));
				if($topUserId > 0){
					if(in_array($topUserId, $aTopUserIdList)){
						alert('ID为 ' . $topUserId . '　的会员不能获得多次排名奖哦', 0);
					}
					$aRelationInfo = $oMatch->getMatchUserRelationInfo($topUserId, $id);
					if($aRelationInfo === false){
						alert('系统错误', 0);
					}
					if(!$aRelationInfo){
						alert('ID为' . $topUserId . '　的用户没有参加这场比赛 ', 0);
					}

					$aTopArray[$j] = array(
						'user_id'		=> $topUserId,
						'receive_time' 	=> 0
					);
					$aTopUserIds[] = $topUserId;
					$aTopUserIdList[] = $topUserId;
					$aEventData[] = array(
						'user_id'	=> $topUserId,
						'type'		=> 12,
						'data_id'	=> $aRelationInfo['id']
					);
					$j++;
					$isSetSuccess = $oMatch->setMatchUserRelation(array('id' => $aRelationInfo['id'], 'user_id' => $topUserId, 'prize_status' => 1));
					if($isSetSuccess === false){
						alert('系统错误', 0);
					}
					//如果是和教育用户，则发送应用消息
					$aUser = getUserInfo($topUserId, array('personal'));
					if($aUser['xxt_data']){
						$aPrizeUserTemp = array();
						$aPrizeUserTemp['user_id'] = $topUserId;
						$aPrizeUserTemp['match_id'] = $aMatchInfo['id'];
						$aPrizeUserTemp['match_name'] = $aMatchInfo['name'];
						$aPrizeUserTemp['prize_type'] = 'top';
						$aPrizeUserTemp['ranking'] = $i;
						$aPrizeUserTemp['xxt_data'] = $aUser['xxt_data'];
						$aPrizeUserList[] = $aPrizeUserTemp;
						$this->_sendMatchRewardMessage($topUserId, $id, $i, 1);
					}

					//和教育家长端学生数据收集
					Parents::statistics('match',  array(
						'user_id' => $topUserId,
						'match_id' => $id,
						'subject_id' => $aMatchInfo['subject_id'],
						'ranking' => $i,
						'create_time' => time()
					));
				}
			}
		}

		if(isset($aMatchInfo['awards']['rand'])){
			$randCount = $aMatchInfo['awards']['rand']['number'] ;
			for($i = 0; $i< $randCount; $i++){
				$randUserId = intval(post('rand_award_' . $i, 0));
				if($randUserId > 0){
					if(in_array($randUserId, $aRandUserIdList)){
						alert('ID为 ' . $randUserId . '　的会员不能获得多次幸运奖哦', 0);
					}
					if(in_array($randUserId, $aTopUserIds)){
						alert('ID为' . $randUserId . '　的用户不能同时获得排名奖和幸运奖 ', 0);
					}
					$aRelationInfo = $oMatch->getMatchUserRelationInfo($randUserId, $id);
					if($aRelationInfo === false){
						alert('系统错误', 0);
					}
					if(!$aRelationInfo){
						alert('ID为' . $randUserId . '　的用户没有参加这场比赛 ', 0);
					}

					$aRandArray[] = array(
						'user_id'		=> $randUserId,
						'receive_time' 	=> 0
					);
					$aRandUserIdList[] = $randUserId;
					$aEventData[] = array(
						'user_id'	=> $randUserId,
						'type'		=> 12,
						'data_id'	=> $aRelationInfo['id']
					);
					//prize_status=1
					$isSetSuccess = $oMatch->setMatchUserRelation(array('id' => $aRelationInfo['id'], 'user_id' => $randUserId, 'prize_status' => 1));
					if($isSetSuccess === false){
						alert('系统错误', 0);
					}
					//如果是和教育用户，则发送应用消息
					$aUser = getUserInfo($randUserId, array('personal'));
					if($aUser['xxt_data']){
						$aPrizeUserTemp = array();
						$aPrizeUserTemp['user_id'] = $randUserId;
						$aPrizeUserTemp['match_id'] = $aMatchInfo['id'];
						$aPrizeUserTemp['match_name'] = $aMatchInfo['name'];
						$aPrizeUserTemp['prize_type'] = 'rand';
						$aPrizeUserTemp['ranking'] = $i;
						$aPrizeUserTemp['xxt_data'] = $aUser['xxt_data'];
						$aPrizeUserList[] = $aPrizeUserTemp;
						$this->_sendMatchRewardMessage($randUserId, $id, $i, 2);
					}
				}
			}
		}

		if(!$aTopArray && !$aRandArray){
			alert('数据错误', 0);
		}
		$aData = array(
			'id'	 => $id,
			'winners'=> array(
				'top'		 => $aTopArray,
				'rand'		 => $aRandArray,
				'create_time'=> time()
			)
		);

		unset($aRandArray);
		$result =  $oMatch->setMatch($aData);

		//写动态 2015-3-9 start
		$aMatchData = $oMatch->getMatchInfoById($id, true);
		//奖品
		$AawardsList = $aMatchData['awards'];
		//获奖者
		$AwinnersList = $aMatchData['winners'];

		//第几等级 奖品和获奖者都存在
		if(isset($AawardsList['top']) && isset($AwinnersList['top'])){
			foreach($AwinnersList['top'] as $k => $aTopwinners){
				$type = 26;
				if(isset($AawardsList['top'][$k]['gold'])){
					if($AawardsList['top'][$k]['gold'] > 0){
						$type = 25;
					}
				}
				$oMatch = m('Match');
				$aRelationInfos = array();
				$aRelationInfos = $oMatch->getMatchUserRelationInfo($aTopwinners['user_id'], $aMatchInfo['id']);
				if($aRelationInfos === false){
					alert('系统错误', 0);
				}
				$aEventData1 = array(
					'user_id'	=>	$aTopwinners['user_id'],
					'type'		=> $type,
					'data_id'	=>	$aRelationInfos['id'],
					'data'		=>	[
						'match_id' => $aMatchInfo['id'],
						'ranking' => $k,
						'create_time' => time(),
					]
				);
				$oSnsEvent = m('SnsEvent');
				$oSnsEvent->addEvent($aEventData1);
			}
		}
		//幸运奖
		if(isset($AawardsList['rand']) && isset($AwinnersList['rand'])){
			foreach($AwinnersList['rand'] as $aRandwinners){
				$type = 26;
				if(isset($AawardsList['rand']['gold'])){
					if($AawardsList['rand']['gold'] > 0){
						$type = 25;
					}
				}

				$oMatch = m('Match');
				$aRelationInfos = array();
				$aRelationInfos = $oMatch->getMatchUserRelationInfo($aRandwinners['user_id'], $aMatchInfo['id']);
				if($aRelationInfos === false){
					alert('系统错误', 0);
				}
				$aEventData1 = array(
					'user_id'	=>	$aRandwinners['user_id'],
					'type'		=> $type,
					'data_id'	=>	$aRelationInfos['id'],
					'data'		=>	[
						'match_id' => $aMatchInfo['id'],
						'ranking' => 'rand',
						'create_time' => time(),
					]
				);
				$oSnsEvent = m('SnsEvent');
				$oSnsEvent->addEvent($aEventData1);
			}
		}
		//写动态结束 end

		if($result > 0){
			$this->_sendMatchRewardMessageToParentAndTeacherAndShare($aPrizeUserList);
			$oUserNumerical = m('UserNumerical');
			foreach($aTopArray as $ranking => $aTop){
				$medel = '';
				if($ranking == 1){
					$medel = 'gold_medal';
				}if($ranking == 2){
					$medel = 'silver_medal';
				}if($ranking == 3){
					$medel = 'cuprum_medal';
				}
				if($medel){
					$oUserNumerical->setMedal(array('id' => $aTop['user_id'], $medel => array('add', 1)));
				}
			}
			alert('操作成功', 1);
//			$oSns = m('Sns');
//			$noticeId = $oSns->addEvent($aEventData);
//			if($noticeId > 0){
//				alert('操作成功', 1);
//			}else{
//				myLog('ID为	' . $id . '　的比赛在抽奖时写用户事件失败');
//				alert('操作失败', 0);
//			}
		}else{
			alert('操作失败', 0);
		}
	}


	//获奖名单
	public function showWinnerList(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($id, true);
		$aUserIds = array();
		foreach($aMatchInfo['winners'] as $key => $aWinnerList){
			if($key == 'create_time' ){
				continue;
			}
			foreach($aWinnerList as $aWinner){
				$aUserIds[] = $aWinner['user_id'];
			}
		}
		$aMatchUserRelationList= $oMatch->getUserMatchRelationList($id, $aUserIds);
		$aAreaIds = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			if($aMatchUserRelation['address'] && isset($aMatchUserRelation['address']['province_id'])){
				$aAreaIds[] = (int)$aMatchUserRelation['address']['province_id'];
				$aAreaIds[] = (int)$aMatchUserRelation['address']['city_id'];
				$aAreaIds[] = (int)$aMatchUserRelation['address']['area_id'];
			}
		}
		$aAreaList = m('user')->getAreaListByAreaIds($aAreaIds);
		foreach($aMatchUserRelationList as $key => $aMatchUserRelation){
			if($aMatchUserRelation['address']){
				$aMatchUserRelationList[$key]['address']['province_name'] = '';
				$aMatchUserRelationList[$key]['address']['city_name'] = '';
				$aMatchUserRelationList[$key]['address']['area_name'] = '';
				foreach($aAreaList as $aArea){
					if(!isset($aMatchUserRelation['address']['province_id'])){
						break;
					}
					if($aArea['id'] == $aMatchUserRelation['address']['province_id']){
						$aMatchUserRelationList[$key]['address']['province_name'] = $aArea['name'];
					}elseif($aArea['id'] == $aMatchUserRelation['address']['city_id']){
						$aMatchUserRelationList[$key]['address']['city_name'] = $aArea['name'];
					}elseif($aArea['id'] == $aMatchUserRelation['address']['area_id']){
						$aMatchUserRelationList[$key]['address']['area_name'] = $aArea['name'];
					}
				}
			}
		}
		foreach($aMatchInfo['winners'] as $key => $aWinnerList){
			if($key == 'create_time' ){
				continue;
			}
			foreach($aWinnerList as $key2 => $aWinner){
				foreach($aMatchUserRelationList as $aMatchUserRelation){
					if($aMatchUserRelation['user_id'] == $aWinner['user_id']){
						$aMatchInfo['winners'][$key][$key2]['address'] = $aMatchUserRelation['address'];
					}
				}
			}
		}
		if($aMatchInfo === false){
			alert('系统错误', 0);
		}
		if(!$aMatchInfo){
			alert('这条记录不存在', 0);
		}
		if($aMatchInfo['is_release'] != 1){
			alert('这场比赛还没发布呢', 0);
		}
		if($aMatchInfo['match_end_time'] > time()){
			alert('这场比赛还没结束呢', 0);
		}
		if(!$aMatchInfo['winners']){
			alert('这场比赛还没抽奖呢呢', 0);
		}

		$aPrizePoints = $oMatch->getPrizeAccumulatePoints($id);
		if($aPrizePoints === false){
			alert('系统错误', 0);
		}

		assign('awardsArray', $this->_awardsArray);
		assign('aMatchInfo', $aMatchInfo);
		assign('aPrizePoints', $aPrizePoints);
		displayHeader();
		display('match/winner_list.html.php');
		displayFooter();
	}

	public function showMatchRankUserList(){
		$page = 1;
		$matchId = intval(get('id'));
		$oMatch = new Match();
		$aResult = $oMatch->matchRankingList($page, $matchId, 0);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}


	//上传封面
	public function uploadProfile(){
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(307200, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . MATCH_PROFILE_TMP_PATH,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败".' . $oUploader->getErrorMsg() . '."', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$aWidthAndHeight = array();
		$aWidthAndHeight = getimagesize(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_TMP_PATH . $uploadFileInfo['savename']);
		if(!$aWidthAndHeight){
			alert('文件上传失败', 0);
		}
		$width = intval($aWidthAndHeight[0]);
		$height = intval($aWidthAndHeight[1]);
		if($width > 400){
			if(file_exists(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽度不能超过400px', 0);
		}
		if($width/$height != 0.9){
			if(file_exists(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . MATCH_PROFILE_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽高比为9:10', 0);
		}
		alert(MATCH_PROFILE_PATH . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . MATCH_PROFILE_TMP_PATH . $uploadFileInfo['savename']);
	}

	//删除图片
	public function delProfile(){
		$profile = post('profile');
		if(!$profile){
			alert('数据错误', 0);
		}
		$tmpProfile = SYSTEM_RESOURCE_PATH . str_replace(MATCH_PROFILE_PATH, MATCH_PROFILE_TMP_PATH, $profile);
		if(!file_exists($tmpProfile)){
			alert('文件不存在', 0);
		}
		if(unlink($tmpProfile)){
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}

	//编辑器图片上传
	public function ueditorUpload(){
		$editorId = get('editorid');
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(512000, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . MATCH_RULE_IMAGE_PATH,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			exit("<script>parent.UM.getEditor('". $editorId ."').getWidgetCallback('image')('', '" . $oUploader->getErrorMsg() . "')</script>");
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		exit("<script>parent.UM.getEditor('". $editorId ."').getWidgetCallback('image')('" . $uploadFileInfo['savename'] . "','" . 'SUCCESS' . "')</script>");
	}

	//题型
	private function _getEsType(){
		$esTypeAarray = array();
		if(isset($GLOBALS['ES_TYPE'])){
			foreach($GLOBALS['ES_TYPE'] as $key => $type){
				$esTypeAarray[$key] = $type;
			}
		}
		return $esTypeAarray;
	}

	//赛事等级
	private function _getLevel(){
		$levelArray = array();
		$levelArray[0] = '无等级限制';
		if(isset($GLOBALS['LEVEL'])){
			for($i = 1; $i<= count($GLOBALS['LEVEL']); $i++){
				$levelArray[$i] = $i . '级';
			}
		}
		return $levelArray;
	}

	//赛事次数
	private function _getLimit(){
		$limitArray = array();
		$limitArray[0] = '无次数限制';
		for($i = 1; $i<=5; $i++){
			$limitArray[$i] = $i . '次';
		}
		return $limitArray;
	}

	public function setMatch(){
		if(empty($_POST)){
			displayHeader();
			display('match/setting_match.html.php');
			displayFooter();
		}else{
			$matchAwardDay = intval(post('matchAward', 0));
			$size = file_put_contents(MATCH_AWARD_CONFIG , '<?php' . PHP_EOL . '$GLOBALS[\'MATCH_AWARD\'] = ' . $matchAwardDay . ';');
			if($size){
				alert('设置成功');
			}else{
				alert('操作失败', 0);
			}
		}

	}

	private function _sendXxtAppMessage($aParams){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('SEND_SYS_PUBLIC_MESSAGE', $aParams);
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return true;
		}
		return false;
	}

	private function _sendMatchRewardMessage($userId, $matchId, $rank, $type){
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($matchId, true);

		$aUser = getUserInfo($userId, array('personal'));
		if(!(isset($aUser['xxt_data']['CityId']) && isset($aUser['xxt_data']['SchoolId']) && isset($aUser['xxt_data']['RoleType']) && isset($aUser['xxt_data']['UserId']) && isset($aUser['xxt_data']['UserName']))){
			return false;
		}
		$messageContent = '';
		if($type == 1){
			$prize = '';
			if(isset($aMatchInfo['awards']['top'][$rank]) && $aMatchInfo['awards']['top'][$rank]){
				if(isset($aMatchInfo['awards']['top'][$rank]['prize']) && $aMatchInfo['awards']['top'][$rank]['prize']){
					$prize .= $aMatchInfo['awards']['top'][$rank]['prize'];
				}
				if(isset($aMatchInfo['awards']['top'][$rank]['accumulate_points']) && $aMatchInfo['awards']['top'][$rank]['accumulate_points']){
					$prize .= ' ' . $aMatchInfo['awards']['top'][$rank]['accumulate_points'] . '个经验 ';
				}
				if(isset($aMatchInfo['awards']['top'][$rank]['gold']) && $aMatchInfo['awards']['top'][$rank]['gold']){
					$prize .= $aMatchInfo['awards']['top'][$rank]['gold'] . '个金币 ';
				}
			}
			$messageContent = $aUser['xxt_data']['UserName'] . ' 恭喜你参加优满分 ' . $aMatchInfo['name'] . ' 比赛获得了第' . $rank . '名!奖品是 ' . $prize . ' ,颁奖人员会在24小时内联系你寄送奖品,请保证你的电话可以联系哦!';
		}else{
			$prize = '';
			if(isset($aMatchInfo['awards']['rand']['prize']) && $aMatchInfo['awards']['rand']['prize']){
				$prize .= $aMatchInfo['awards']['rand']['prize'];
			}
			if(isset($aMatchInfo['awards']['rand']['accumulate_points']) && $aMatchInfo['awards']['rand']['accumulate_points']){
				$prize .= ' ' . $aMatchInfo['awards']['rand']['accumulate_points'] . '个经验 ';
			}
			if(isset($aMatchInfo['awards']['rand']['gold']) && $aMatchInfo['awards']['rand']['gold']){
				$prize .= $aMatchInfo['awards']['rand']['gold'] . '个金币 ';
			}
			$messageContent = $aUser['xxt_data']['UserName'] . ' 恭喜你参加优满分 ' . $aMatchInfo['name'] . ' 比赛获得了幸运奖!奖品是 ' . $prize . ' ,颁奖人员会在24小时内联系你寄送奖品,请保证你的电话可以联系哦!';
		}

		$aParams = array(
			'CityId' => $aUser['xxt_data']['CityId'],
			'SchoolId' => $aUser['xxt_data']['SchoolId'],
			'MessageType' => 1,
			'UserType' => $aUser['xxt_data']['RoleType'],
			'MessageContent' => $messageContent,
			'UserId' => $aUser['xxt_data']['UserId'],
			'MessageURL' => url('m=Match&a=showDetail&match_id=' . $matchId, '', APP_HOME),
			'IsOauth' => 1,
			'OthMsgId' => time(),
			'ValidDate' => date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30)
		);

		return $this->_sendXxtAppMessage($aParams);
	}

	/*
	 * 给家长和老师发应用消息并分享微博到班圈
	 */
	private function _sendMatchRewardMessageToParentAndTeacherAndShare($aPrizeUserList){
		if(!$aPrizeUserList){
			return;
		}
		foreach($aPrizeUserList as $aPrizeUser){
			//获取学生是否和教育的
			$aUserInfo = getUserInfo($aPrizeUser['user_id'], array('personal'));
			if(!$aUserInfo['xxt_id']){
				continue;
			}
			//获取学生信息
			if(isset($aUserInfo['xxt_data']['UserId']) && $aUserInfo['xxt_data']['UserId'] && isset($aUserInfo['xxt_data']['CityId']) && $aUserInfo['xxt_data']['CityId']){
				if($aPrizeUser['prize_type'] == 'top'){
					$messageContent = '恭喜您的小孩：' . $aUserInfo['name'] . '，在《优满分》的比赛"' .$aPrizeUser['match_name'] .  '"获得了 ' . $aPrizeUser['ranking'] . ' 等奖';
				}else{
					$messageContent = '恭喜您的小孩：' . $aUserInfo['name'] . '，在《优满分》的比赛"' .$aPrizeUser['match_name'] .  '"获得了幸运奖';
				}
				$aXxtUserInfo = array();
				try{
					$aXxtUserInfo = Xxt::getStudentInfo($aUserInfo['xxt_data']['UserId'], $aUserInfo['xxt_data']['CityId']);
				}catch(XxtException $e){
					$e->log();
					return false;
					//alert('获取和教育学生信息失败：' . $e->getMessage(), 0);
				}
				if(empty($aXxtUserInfo['StudentEntity']['ParentEntity']['ParentId'])){
					myLog('给用户：' . $aUserInfo['id'] . ' 的家长发应用消息失败 $aParams:'.json_encode($aParams));
					return false;
				}
				//给家长发送消息
				$aParams = array(
					'CityId' => $aUserInfo['xxt_data']['CityId'],
					'SchoolId' => $aXxtUserInfo['StudentEntity']['SchoolId'],
					'MessageType' => 1,
					'UserType' => 3,
					'MessageContent' => $messageContent,
					'UserId' => $aXxtUserInfo['StudentEntity']['ParentEntity']['ParentId'],
					'MessageURL' => url('m=Match&a=showDetail&match_id=' . $aPrizeUser['match_id'], '', APP_HOME),
					'IsOauth' => 1,
					'OthMsgId' => time(),
					'ValidDate' => date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30)
				);
				$result = $this->_sendXxtAppMessage($aParams);
				if(!$result){
					myLog('给用户：' . $aUserInfo['id'] . ' 的家长发应用消息失败 $aParams:' . json_encode($aParams));
					//alert('给和教育用户家长发应用消息失败了', 0);
				}

				//给老师发应用消息
				$aXxClassAndTeacherInfo = Xxt::getClassAndTeacher($aXxtUserInfo['StudentEntity']['ClassId']);
				if($aXxClassAndTeacherInfo['Result'] != 200){
					myLog('获取和教育老师信息失败:ClassId:' . $aXxtUserInfo['StudentEntity']['ClassId']);
					//alert($aXxClassAndTeacherInfo['Desc'], 0);
				}
				if($aPrizeUser['prize_type'] == 'top'){
					$messageContent = '恭喜您的学生：' . $aUserInfo['name'] . '，在《优满分》的比赛"' . $aPrizeUser['match_name'] .  '"获得了 ' . $aPrizeUser['ranking'] . ' 等奖';
				}else{
					$messageContent = '恭喜您的学生：' . $aUserInfo['name'] . '，在《优满分》的比赛"' . $aPrizeUser['match_name'] .  '"获得了幸运奖';
				}
				//debug($aXxClassAndTeacherInfo);
				//debug($aXxClassAndTeacherInfo['MSG_BODY']['Relations']['ClassTeacherRelation']);
				if(isset($aXxClassAndTeacherInfo['MSG_BODY']['Relations']['ClassTeacherRelation']['ClassId'])){
					$aParams = array(
						'CityId' => $aUserInfo['xxt_data']['CityId'],
						'SchoolId' => $aXxtUserInfo['StudentEntity']['SchoolId'],
						'MessageType' => 1,
						'UserType' => 1,
						'MessageContent' => $messageContent,
						'UserId' => $aXxClassAndTeacherInfo['MSG_BODY']['Relations']['ClassTeacherRelation']['TeacherId'],
						'MessageURL' => url('m=Match&a=showDetail&match_id=' . $aPrizeUser['match_id'], '', APP_HOME),
						'IsOauth' => 1,
						'OthMsgId' => time(),
						'ValidDate' => date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30)
					);
					$result = $this->_sendXxtAppMessage($aParams);
					if(!$result){
						myLog('给用户：' . $aUserInfo['id'] . ' 的老师XXT_ID:' . $aXxClassAndTeacherInfo['MSG_BODY']['Relations']['ClassTeacherRelation']['TeacherId'] . '发应用消息失败 $aParams:' . json_encode($aParams));
					}
				}else{
					foreach($aXxClassAndTeacherInfo['MSG_BODY']['Relations']['ClassTeacherRelation'] as $aXxtTeacher){
						$aParams = array(
							'CityId' => $aUserInfo['xxt_data']['CityId'],
							'SchoolId' => $aXxtUserInfo['StudentEntity']['SchoolId'],
							'MessageType' => 1,
							'UserType' => 1,
							'MessageContent' => $messageContent,
							'UserId' => $aXxtTeacher['TeacherId'],
							'MessageURL' => url('m=Match&a=showDetail&match_id=' . $aPrizeUser['match_id'], '', APP_HOME),
							'IsOauth' => 1,
							'OthMsgId' => time(),
							'ValidDate' => date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30)
						);
						$result = $this->_sendXxtAppMessage($aParams);
						if(!$result){
							myLog('给用户：' . $aUserInfo['id'] . ' 的老师XXT_ID:' . $aXxClassAndTeacherInfo['MSG_BODY']['Relations']['ClassTeacherRelation']['TeacherId'] . '发应用消息失败 $aParams:' . json_encode($aParams));
						}
					}
				}

				if($aPrizeUser['prize_type'] == 'top'){
					$messageContent = '我在《优满分》的比赛："' . $aPrizeUser['match_name'] .  '"获得了 ' . $aPrizeUser['ranking'] . ' 等奖,你们也一起来玩吧！';
				}else{
					$messageContent = '我在《优满分》的比赛："' . $aPrizeUser['match_name'] .  '"获得了幸运奖,你们也一起来玩吧！';
				}
				//分享到班圈
				$aWeiboParams = array();
				$aWeiboParams['city_id'] = $aUserInfo['xxt_data']['CityId'];
				$aWeiboParams['user_id'] = $aUserInfo['xxt_data']['UserId'];
				$aWeiboParams['role_type'] = 2;
				$aWeiboParams['school_id'] = $aXxtUserInfo['StudentEntity']['SchoolId'];
				$aWeiboParams['class_id'] = $aXxtUserInfo['StudentEntity']['ClassId'];
				$aWeiboParams['content'] = $messageContent;
				$aWeiboParams['from_sys'] = 9;
				$aWeiboParams['msg_type'] = 2;
				$aWeiboParams['has_attachment'] = 0;
				$result = false;
				try{
					$result = Xxt::addWeibo($aWeiboParams);
				}catch(XxtException $e){
					$e->log();
				}
			}else{
				continue;
			}
		}
	}
}