<?php
class ProxyController{
	private $_permissionFlag = 'manage_proxy';
	private $_userId = 0;
	
	public function __construct(){
		if(get('a') != 'uploadFile'){
			
			$this->_userId = checkLogin();
			if(!checkPermission($this->_userId, $this->_permissionFlag)){
				wrong('您没有权限对此操作');
			}
		}
	}

	private $_proxyStatusArray = array(
		1 => '未申请认证',
		2 => '认证审核中',
		3 => '已通过认证',
		4 => '认证不通过'
	); 
	
	
	public function showProxyList(){
		
		$url = '?m=Proxy&a=showProxyList&page=_PAGE_';
		
		$email = get('email');
		if(!w('isEmail()', $email)){
			$email = '';
		}else{
			$url .= '&email=' . $email;
		}
		
		
		$telephone = get('telephone');
		if(!preg_match('/^((\+86)|(86))?1[3|4|5|8]{1}\d{9}$/', $telephone)){
			$telephone = '';
		}else{
			$url .= '&telephone=' . $telephone;
		}
		
		$mobile = get('mobile');
		if(!w('isPhone()', $mobile)){
			$mobile = '';
		}else{
			$url .= '&mobile=' . $mobile;
		}
		
		$fax = get('fax');
		if(!w('isPhone()', $fax)){
			$fax = '';
		}else{
			$url .= '&fax=' . $fax;
		}
		
		$commission = intval(get('commission'));
		if(1 > $commission || $commission > 100){
			$commission = '';
		}else{
			$url .= '&commission=' . $commission;
		}
		
		$searchCreateTime = 0;
		$createTime = get('createTime');
		if($createTime){
			$searchCreateTime = strtotime($createTime);
			$url .= '&createTime=' . $createTime;
		}
		
		$province = intval(get('province'));
		if($province > 0){
			$url .= '&province=' . $province;
		}
		$city = intval(get('city'));
		if($province > 0){
			$url .= '&city=' . $city;
		}
		$area = intval(get('area'));
		if($area > 0){
			$url .= '&area=' . $area;
		}
		$status = intval(get('status', 0));

		if(isset($this->_proxyStatusArray[$status])){
			$url .= '&status=' . $status;
		}else{
			$status = 0;
		}
		
		$apiIsActive = get('apiIsActive');
		if($apiIsActive != '0' && $apiIsActive != '1'){
			$apiIsActive = '';
		}else{
			$url .= '&apiIsActive=' . $apiIsActive;
		}
		
		$first = 0;
		if($url == '?m=Proxy&a=showProxyList&page=_PAGE_&status=2'){
			$first = 1;
		}
		
		assign('first', $first);
		assign('email', $email);
		assign('telephone', $telephone);
		assign('mobile', $mobile);
		assign('fax', $fax);
		assign('commission', $commission);
		assign('createTime', $createTime);
		assign('province', $province);
		assign('city', $city);
		assign('area', $area);
		assign('status', $status);
		assign('apiIsActive', $apiIsActive);
		
		
		$oProxy = m('Proxy');
		$aProxyList = array();
		$pageHtml = '';
		$page = intval(get('page','1'));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 20;
		$count = $oProxy->getProxyUserCount($email, $telephone, $mobile, $fax, $commission, $searchCreateTime, $province, $city, $area, $status, $apiIsActive);
		
		if($count > 0){
			$pageCount = ceil($count/$pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aProxyList = $oProxy->getProxyUserList($page, $pageSize, $email, $telephone, $mobile, $fax, $commission, $searchCreateTime, $province, $city, $area, $status, $apiIsActive);
			if($aProxyList){
				foreach($aProxyList as $key => $aProxyInfo){
					$aProxyList[$key]['statusName'] = '';
					$aProxyList[$key]['zipFile'] = '';
					if(isset($this->_proxyStatusArray[$aProxyInfo['status']]) && $this->_proxyStatusArray[$aProxyInfo['status']]){
						$aProxyList[$key]['statusName'] = $this->_proxyStatusArray[$aProxyInfo['status']]; 
					}
					if(file_exists(SYSTEM_RESOURCE_PATH . PROXY_PROFILE_PATH . $aProxyInfo['id'] . '.zip')){
						$aProxyList[$key]['zipFile'] = SYSTEM_RESOURCE_URL . 'data/proxy/' . $aProxyInfo['id'] . '.zip';
					}
				}	
			}
			
			$aPageInfo = array(
				'url' 	=> $url,
				'total' => $count,
				'size' 	=> $pageSize,
				'page' 	=> $page,
			);
			$pageHtml = page($aPageInfo);
		}
		
		assign('count', $count);
		assign('aStatusArray', $this->_proxyStatusArray);
		assign('aProxyList', $aProxyList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('proxy/list.html.php');
		displayFooter();
	}
	
	
	public function showProxyEdit(){
		$id = intval(get('id'));
		$oProxy = m('Proxy');
		$aProxyInfo = array();
		if($id > 0){
			$aResultArray = $oProxy->getProxyUserInfoById($id);
			if($aResultArray){
				$aProxyInfo = $aResultArray;
				unset($aResultArray);
				$aProxyInfo['zipFile'] = '';
				if(file_exists(SYSTEM_RESOURCE_PATH . PROXY_PROFILE_PATH . $aProxyInfo['id'] . '.zip')){
					$aProxyInfo['zipFile'] = SYSTEM_RESOURCE_URL . 'data/proxy/' . $aProxyInfo['id'] . '.zip';
				}
				
				assign('first', 0);
				assign('aProxyInfo',$aProxyInfo);
				assign('statusArray', $this->_proxyStatusArray);
				
				assign('validateJs', j('email,password,captcha'));
				displayHeader();
				display('proxy/edit.html.php');
				displayFooter();
			}else{
				wrong('代理商不存在');
			}
		}else{
			wrong('代理商不存在');
		}
	}
	
	public function edit(){
		$proxyId = intval(get('id',0));
		$status = intval(post('status'));
		$aData = array(
			'name' 			=> post('name'),
			'api_is_active' => post('api_is_active'),
			'api_key'		=> post('api_key'),
			'api_ip_list'	=> post('api_ip_list'),	
			'telephone' 	=> post('telephone'),
			'fax' 			=> post('fax'),
			'province' 		=> post('province'),
			'city' 			=> post('city'),
			'area' 			=> post('area'),
			'address' 		=> post('address'),
			'commission' 	=> intval(post('commission',0))
		);

		if($status == 3 || $status == 4){
			$aData['status'] = $status;
		}
		
		if($aData['api_ip_list']){
			$tmpArray = explode('|',$aData['api_ip_list']);
			$reg = '/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/';
			foreach($tmpArray as $key => $tmpInfo){
				if(!preg_match($reg,$tmpInfo)){
					alert('代理商ip格式错误',0);
				}
				
				$tmpArray2 = explode('.', $tmpInfo);
				if(count($tmpArray2) != 4){
					alert('代理商ip格式错误',0);
				}
				
				foreach($tmpArray2 as $value){
					if($value < 0 || $value > 255 ){
						alert('代理商ip格式错误',0);
					}
				}
			}
		}
		
		if($aData['commission']){
			$reg = '/^\d{1,2}$/';
			if(!is_int($aData['commission'])){
				alert('佣金比例错误',0);
			}
			if(0 > $aData['commission'] || 100 < $aData['commission']){
				alert('佣金比例错误',0);
			}
		}
		
		if($aData['telephone']){
			$reg ='/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/';
			if(!preg_match($reg, $aData['telephone'])){
				alert('电话号码格式错误',0);
			}	
		}
		
		if($aData['fax']){
			$reg ='/^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/';
			if(!preg_match($reg, $aData['fax'])){
				alert('传真号码格式错误',0);
			}
		}
		
		
		$oProxy = m('Proxy');
		$aProxInfo = $oProxy->getProxyUserInfoById($proxyId);
		if($aProxInfo){
			$aData['id'] = $proxyId;
			$aResult = $oProxy->setProxyUser($aData);
			if($aResult !== false){
				if($aProxInfo['status'] != $status){
					if($status == 3){
						$statusStr = '审核通过';
					}else{
						$statusStr = '末通过审核';
					}
					$aEmailArray = array(
						'to' => $aProxInfo['email'],
						'subject' => 'UMFun代理商审核结果',
						'name' => '亲爱的用户',
						'content' => '您提交的代理资料，我们已收到并已完成审核，审核结果：' . $statusStr . '。请知悉并尽快查看处理！
代理商提交了审核资料，等待审核，请UMFun工作人员尽快处理并跟进该反馈，如无特殊情况请当日予以跟进处理！'
					);
					email($aEmailArray);
				}
				alert('更新成功',1);
			}else{
				alert('更新失败',0);
			}
		}
	}

	
	public function showCommission(){
		$id = intval(get('id', 0));
		$oRecharge = new ProxyModel();
		$aProxyInfo = array();
		if($id > 0){
			$aProxyInfo = $oRecharge->getProxyUserInfoById($id);
		}
		
		assign('aProxyInfo', $aProxyInfo);
		assign('first', 0);
		displayHeader();
		display('proxy/commission.html.php');
		displayFooter();
		
	}
	
	public function showProxyStatistic(){
		$email = '';
		$searchType = get('search_type');
		if($searchType == 1){
			if(!w('isEmail()', $email = get('email', ''))){
				alert('请输入正确的邮箱', 0);
			}
		}
		$rechargeType = get('recharge_type', 0);
		$startTime = get('start_time', date('Y-01-01 00:00:00'));
		$endTime = get('end_time', date('Y-m-d H:i:s'));
		$startTimeStamp = strtotime($startTime);
		$endTimeStamp = strtotime($endTime);
		$page = intval(get('page', 1));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 20;
		$oProxy = m('Proxy');
		$proxyCount = $oProxy->getProxyUserCount($email, $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $provinceId = 0, $cityId = 0, $areaId = 0, $status = 3, $apiIsActive = '', $rechargeType, $startTimeStamp, $endTimeStamp);
		
		$aProxyList = $oProxy->getProxyStatistic($page, $pageSize, $email, $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $provinceId = 0, $cityId = 0, $areaId = 0, $status = 3, $apiIsActive = '', $rechargeType, $startTimeStamp, $endTimeStamp);
		$aPageInfo = array(
			'url' => 'm=Proxy&a=showProxyStatistic&page=_PAGE_',
			'total' => $proxyCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$aTotalProxyList = $oProxy->getProxyStatistic(0, 0, $email, $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $provinceId = 0, $cityId = 0, $areaId = 0, $status = 3, $apiIsActive = '', $rechargeType, $startTimeStamp, $endTimeStamp);
		$total_user_count = 0;
		$total_recharge_count = 0;
		$total_money = 0;
		$total_commission = 0;
		$total_pay = 0;
		$real_pay = 0;
		
		foreach($aTotalProxyList as $aTotalProxy){
			$total_user_count += $aTotalProxy['user_count'];
			$total_recharge_count += $aTotalProxy['recharge_nums'];
			$total_money += $aTotalProxy['recharge_total_money'];
			$total_commission += $aTotalProxy['commission'];
			$real_pay += $aTotalProxy['real_pay_money'];
		}
		$average_commission = $proxyCount ? round($total_commission / $proxyCount, 2) : $total_commission;
		
		$aTotalstatistic = array(
			'total_proxy_nums' => $proxyCount,
			'total_user_count' => $total_user_count,
			'total_recharge_count' => $total_recharge_count,
			'total_money' => $total_money,
			'average_commission' => $average_commission,
			'real_pay' => $real_pay,
			'corporation_income' => $real_pay,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('aProxyList', $aProxyList);
		assign('aTotalstatistic', $aTotalstatistic);
		assign('email', $email);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		assign('rechargeType', $rechargeType);
		assign('first', 0);
		displayHeader();
		display('proxy/statistic.html.php');
		displayFooter();
	}
	
	//上传附件
	public static function uploadFile(){
		$proxyId = intval(get('proxyId',0));
		$oProxy = m('Proxy');
		$aProxyInfo = $oProxy->getProxyUserInfoById($proxyId);
		if(!$aProxyInfo){
			alert('文件上传失败', 0);
		}
		
		$oUploader = new UploadFile(5242880, 'zip', '', SYSTEM_RESOURCE_PATH . PROXY_PROFILE_PATH, $proxyId);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		
		//alert(USER_PROFILE_PATH . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . '/data/proxy/' . $uploadFileInfo['savename']);
		alert('文件上传成功', 1, SYSTEM_RESOURCE_URL . 'data/proxy/' . $proxyId . '.zip');
	}
}