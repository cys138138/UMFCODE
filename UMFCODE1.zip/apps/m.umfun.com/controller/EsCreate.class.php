<?php
class EsCreateController{

	private $_permissionFlag = 'add_es';
	private $_userId = 0;
	private $_aEsStatus  = array(
		1	=> '已保存',
		2	=> '已提交',
		3	=> '已通审',
		4	=> '已发回',
		5	=> '已通审',
		6	=> '已通审',
		7	=> '已通审',
	);
	private $_aStatus  = array(
		1	=> '已保存',
		2	=> '已提交',
		3	=> '已初审',
		4	=> '已发回',
		5	=> '已终审',
		6	=> '未复核',
		7	=> '已作废',
	);

	private $_aTimeType = array(
		1 => '创建时间',
		2 => '提交时间',
		3 => '审核时间'
	);

	public function __construct(){
		$method = strtolower(get('a'));
		$this->_userId = checkLogin();
		if(!in_array($method, array('showsameeslist', 'showcategroytree', 'getanalysis'))){
			if(!checkPermission($this->_userId, $this->_permissionFlag)){
				alert('您没有权限对此操作', 0);
			}
		}
	}

	/**
	 * 显示题目列表
	 */
	public function showList(){
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);

		//检查是否有题目需要优先处理
		$oEs = m('Es');
		//题目状态
		$esStatus = get('esStatus', 1);
		if($esStatus){
			if(!array_key_exists($esStatus, $this->_aEsStatus)){
				wrong('错误的题目状态');
			}
			$url .= '&esStatus=' . $esStatus;
		}
		assign('esStatus', $esStatus);

		if($esStatus != 4){
			$mustFinishFirst = $oEs->isExistEsNeedFinishByCreaterId($this->_userId);
			if($mustFinishFirst){
				displayHeader();
				echo '<script type="text/javascript">UBox.show("您有 ' . $mustFinishFirst . ' 道发回的题目超过1天未处理，请先处理", 0, "?m=EsCreate&a=showList&esStatus=4", 4);</script>';
				displayFooter();
				return;
			}
		}

		//处理搜索条件
		//科目ID
		$subject = get('subject', 0);
		if($subject){
			if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
				wrong('不存在此科目');
			}
			$url .= '&subject=' . $subject;
		}

		assign('subjectId', $subject);

		//题目类型
		$esType = get('esType', 0);
		if($esType){
			if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
				wrong('不存在此题型');
			}
			$url .= '&esType=' . $esType;
		}
		assign('esTypeId', $esType);

		//时间
		$timeType = get('timeType', 1);
		$startTime = get('startTime');
		$endTime = get('endTime');
		if(!in_array($timeType, array(1, 2, 3))){
			wrong('错误的时间类型');
		}
		$url .= '&timeType=' . $timeType;
		assign('timeType', $timeType);

		//开始时间
		if(!$startTime){
			$startTimeStamp = 0;
		}else{
			$startTimeStamp = strtotime($startTime);
			$url .= '&startTime=' . $startTime;
		}
		if(isset($_COOKIE['createrStartTime'])){
			$startTime = $_COOKIE['createrStartTime'];
		}else{
			setcookie('createrStartTime', $startTime, time() + 3600 * 24 * 30, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
		}
		assign('startTime', $startTime);

		//结束时间
		if(!$endTime){
			$endTimeStamp = time();
		}else{
			$endTimeStamp = strtotime($endTime);
			$url .= '&endTime=' . $endTime;
		}
		if(isset($_COOKIE['createrEndTime'])){
			$endTime = $_COOKIE['createrEndTime'];
		}else{
			setcookie('createrEndTime', $endTime, time() + 3600 * 24 * 30, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
		}
		assign('endTime', $endTime);

		//分页数
		$page = get('page');
		$pageSize = 10;
		if(!($page >= 1)){
			$page = 1;
		}
		//题目列表
		$esNums = $oEs->getEsCountByCreater($timeType, $startTimeStamp, $endTimeStamp, $this->_userId, $subject, $esType, $esStatus);
		assign('esNums', $esNums);
		$aEsList = $oEs->getEsListByCreater($page, $pageSize, $this->_userId, $startTimeStamp, $endTimeStamp, $timeType, $subject, $esType, $esStatus);
		$aEsPlugin = array();	//存放题目插件对象的数组
		foreach($aEsList as $keyNum => $aEs){
			$aEsList[$keyNum]['same_ids'] = array();
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				foreach($aSameEsList as $aSameEs){
					$aEsList[$keyNum]['same_ids'][] = $aSameEs['id'];
				}
			}

			foreach($aEs as $keyField => $es){
				if($keyField == 'content_json'){
					if(!isset($aEsPlugin[$aEs['subject_id']][$aEs['type_id']])){
						$aEsPlugin[$aEs['subject_id']][$aEs['type_id']] = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
					}
					$aEsList[$keyNum]['es_content'] = $aEsPlugin[$aEs['subject_id']][$aEs['type_id']]->resolve($es);
					unset($aEsList[$keyNum][$keyField]);
				}
			}
			if($aEs['status'] != 4){
				unset($aEsList[$keyNum]['sendback_reason']);
			}
		}
		unset($aEsPlugin);
		assign('aEsList', $aEsList);

		//分页HTML
		$pageHtml = page(array(
			'url' => $url . '&page=_PAGE_',
			'total' => $esNums,
			'selector' => 1,
			'size' => $pageSize,
			'page' => $page
		));
		assign('pageHtml', $pageHtml);

		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aUser = $oManager->getUserInfoByUserId($this->_userId);
		$aAllowedSubject = array();
		foreach($aUser['allowed_subject'] as $subjectId){
			if(isset($GLOBALS['SUBJECT'][$subjectId])){
				$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
			}
		}
		assign('aSubject', $aAllowedSubject);

		assign('aTimeType', $this->_aTimeType);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aStatus', $this->_aEsStatus);
		displayHeader();
		display('es_create/list.html.php');
		displayFooter();
	}

	public function showStatistic(){
		$aDayType = array(
				1 => 3,
				2 => 7,
				3 => 15,
				4 => 30
		);
		assign('aDayType', $aDayType);
		$dayType = get('dayType', 0);
		assign('dayType', $dayType);
		if($dayType){
			if(!array_key_exists($dayType, $aDayType)){
				wrong('错误的类型');
			}

			$endTime = time();
			$startTime = $endTime - 86400 * $aDayType[$dayType];
		}else{
			$startTime = get('startTime');
			$endTime = get('endTime');
			if(!$startTime){
				$startTime = time() - 86400 * 7;
			}else{
				$startTime = strtotime($startTime);
			}
			if(!$endTime){
				$endTime = time();
			}else{
				$endTime = strtotime($endTime);
			}
		}
		assign('startTime', $startTime);
		assign('endTime', $endTime);

		$oEs = m('Es');
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		$aStatistic = array();
		foreach($aAllowSubjectId as $key => $subjectId){
			foreach($GLOBALS['SUBJECT_TYPE'][$subjectId] as $esTypeId){
				$aStatistic[$subjectId][$esTypeId] = $oEs->getStatisticsForCreater($startTime, $endTime, $this->_userId, $subjectId, $esTypeId);
			}
		}
		assign('aStatistic', $aStatistic);

		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);
		displayHeader();
		display('es_create/statistic.html.php');
		displayFooter();
	}

	/**
	 * 显示添加题目的界面
	 */
	public function showAdd(){
		//检查是否有题目需要优先处理
		$oEs = m('Es');
		$mustFinishFirst = $oEs->isExistEsNeedFinishByCreaterId($this->_userId);
		if($mustFinishFirst){
			displayHeader();
			echo '<script type="text/javascript">UBox.show("您有 ' . $mustFinishFirst . ' 道发回的题目超过1天未处理，请先处理", 0, "?m=EsCreate&a=showList&esStatus=4", 4);</script>';
			displayFooter();
			return;
		}

		$subject = get('subject');
		$esType = get('esType');
		if((!($subject >= 1) && $subject) || (!($esType >= 1) && $esType)){
			wrong('科目或题型参数错误');
		}

		assign('subjectId', $subject);
		assign('esType', $esType);

		if($subject){
			assign('aCategoryList', Es::getCategoryTreeListBySubjectId($subject));
		}

		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		$aAllowedSubject = array();
		foreach($aAllowSubjectId  as $subjectId){
			$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
		}
		if(!$aAllowedSubject){
			wrong('没有可操作的科目');
		}
		assign('aSubject', $aAllowedSubject);

		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aSubjectType', $GLOBALS['SUBJECT_TYPE']);
		displayHeader();
		display('es_create/add.html.php');
		displayFooter();
	}

	/**
	 * 添加题目
	 */
	public function addEs(){
		//检查是否有题目需要优先处理
		$oEs = m('Es');
		$mustFinishFirst = $oEs->isExistEsNeedFinishByCreaterId($this->_userId);
		if($mustFinishFirst){
			alert('你有 ' . $mustFinishFirst . ' 道被发回的题目已经超过1天时间，需要优先处理', 0);
		}

		$aEs = array();

		//科目ID
		$aEs['subject_id'] = post('subject_id');
		if(!($aEs['subject_id'] >= 1)){
			alert('非法的科目ID', 0);
		}

		/*if ($aEs['subject_id'] != 4) {
			alert('暂时禁止录题', 0);
		}*/

		$this->_checkAllowSubject($aEs['subject_id']);	//检查科目权限

		//题目类型
		$aEs['type_id'] = post('es_type');
		if(!($aEs['type_id'] >= 1)){
			alert('非法的题目类型ID', 0);
		}

		//调用题目插件
		$oEsPlugin = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
		if(!is_object($oEsPlugin)){
			alert('错误的科目或题型', 0);
		}
		$aEsMainContent = $oEsPlugin->build($_POST['es']);
		if($aEsMainContent == null){
			alert($oEsPlugin->getError(), 0);
		}

		$aEs['content_json'] = $aEsMainContent['content_json'];
		$aEs['content_text'] = $aEsMainContent['content_text'];

		//检查目录
		$aEs['category_id'] = post('category_id');
		if(!($aEs['category_id'] >= 1)){
			alert('非法的目录ID', 0);
		}else{
			$categoryExists = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
			if(!$categoryExists){
				alert('目录不存在', 0);
			}
		}
		$childNums = $oEs->isExistSubCategory($aEs['category_id']);
		if($childNums > 0){
			alert('选择的目录不是最底层目录，请检查', 0);
		}
		$aEs['status'] = 1;	//已保存
		$aEs['correct_counts'] = 0;
		$aEs['answer_counts'] = 0;
		$aEs['correct_percent'] = 0;
		$aEs['submiter_user_id'] = $this->_userId;
		$aEs['approver_user_id'] = 0;
		$aEs['operating_time'] = time();
		$aEs['action'] = 1;	//创建
		$aEs['appeal_status'] = 1;	//1未申诉 2申诉中 3申诉成功 4申诉失败

		//检查是否存在相同题干的题目
		if(get('ignore_same_es') == 0){
			$aSameEsList = $oEs->getSimilarEsListByData($aEs);
			if($aSameEsList){
				$aSameEsIdList = array();
				foreach($aSameEsList as $aSameEs){
					$aSameEsIdList[] = $aSameEs['id'];
				}
				alert('检测到正式题库中已经存在相似题目,是否继续保存?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
			}
		}
		if($insertEsId = $oEs->addEs($aEs)){
			if(post('isSubmit')){
				$aSubmitEs = array();
				$aSubmitEs['id'] = $insertEsId;
				$aSubmitEs['action'] = 2;
				$aSubmitEs['status'] = 2;
				$aSubmitEs['operating_time'] = time();
				$aSubmitEs['submiter_user_id'] = $this->_userId;
				$aSubmitEs['subject_id'] = $aEs['subject_id'];
				$isSubmitEs = $oEs->changeStatus($aSubmitEs);
				if($isSubmitEs){
					alert('创建并提交题目成功', 1, array('url' => '?m=EsCreate&a=showList', 'lastId' => $insertEsId));
				}else{
					alert('创建并提交题目失败', 0);
				}
			}
			alert('创建题目成功', 1, array('url' => '?m=EsCreate&a=showList', 'lastId' => $insertEsId));
		}else{
			alert('创建题目失败', 0);
		}
	}

	/**
	 * 显示批量添加题目的界面
	 */
	public function showBatchAdd(){
		$subject = get('subject', 1);

		assign('subject', $subject);
		assign('esType', get('esType'));
		assign('aCategoryList', Es::getCategoryTreeListBySubjectId($subject));

		displayHeader();
		display('es_create/batch_add.html.php');
		displayFooter();
	}

	public function batchAdd(){
		if(!isset($_POST['es_list']) || !is_array($_POST['es_list'])){
			alert('缺少题目数据', 0);
		}

		//检查是否有题目需要优先处理
		$oEs = m('Es');
		$mustFinishFirst = $oEs->isExistEsNeedFinishByCreaterId($this->_userId);
		if($mustFinishFirst){
			alert('你有 ' . $mustFinishFirst . ' 道被发回的题目已经超过1天时间，需要优先处理', 0);
		}

		//科目ID
		$subjectId = post('subject_id');
		if(!($subjectId >= 1)){
			alert('非法的科目ID', 0);
		}
		$this->_checkAllowSubject($subjectId);	//检查科目权限

		//题目类型
		$typeId = post('type_id');
		if(!($typeId >= 1)){
			alert('非法的题目类型ID', 0);
		}

		//检查目录
		$categoryId = post('category_id');
		if(!($categoryId >= 1)){
			alert('非法的目录ID', 0);
		}else{
			$categoryExists = $oEs->getCategoryInfoByCategoryId($categoryId);
			if(!$categoryExists){
				alert('目录不存在', 0);
			}
		}
		$childNums = $oEs->isExistSubCategory($categoryId);
		if($childNums > 0){
			alert('选择的目录不是最底层目录，请检查', 0);
		}

		$submiterUserId = $this->_userId;
		$operatingTime = time();

		//调用题目插件
		$oEsPlugin = $this->_esFactory($subjectId, $typeId);
		if(!is_object($oEsPlugin)){
			alert('错误的科目或题型', 0);
		}

		$aEsList = array();
		$ignoreSameEs = get('ignore_same_es') == 0;
		foreach($_POST['es_list'] as $key => $aEs){
			if(!$aEs){
				continue;
			}
			//题目内容
			$aEsMainContent = $oEsPlugin->build($aEs);
			if(!$aEsMainContent){
				alert('第' . ($key + 1) . '题' . $oEsPlugin->getError(), 0);
			}
			
			$aEsList[$key] = array(
				'content_json' => $aEsMainContent['content_json'],
				'content_text' => $aEsMainContent['content_text'],
				'subject_id' => $subjectId,
				'type_id' => $typeId,
				'category_id' => $categoryId,
				'status' => 1,
				'correct_counts' => 0,
				'answer_counts' => 0,
				'correct_percent' => 0,
				'submiter_user_id' => $submiterUserId,
				'approver_user_id' => 0,
				'operating_time' => $operatingTime,
				'action' => 1,
				'appeal_status' => 1,
				'comment' => '',
			);

			//检查是否存在相同题干的题目
			if($ignoreSameEs){
				$aSameEsList = $oEs->getSimilarEsListByData($aEsList[$key]);
				if($aSameEsList){
					$aSameEsIdList = array();
					foreach($aSameEsList as $aSameEs){
						$aSameEsIdList[] = $aSameEs['id'];
					}
					alert('检测到正式题库中已经存在与 “<span class="red">' . mb_substr(strip_tags($aEs['content']), 0, 20) . '</span> 相似的题目,是否继续保存?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
				}
			}
		}

		$lastEsID = $oEs->addBatchEs($aEsList);
		if($lastEsID){
			$endId = $lastEsID - 1;
			$startId = $lastEsID - count($aEsList);
			alert('批量添加题目成功', 1, array('url' => '?m=EsCreate&a=showList', 'start' => $startId, 'end' => $endId));
		}else{
			alert('批量添加题目失败', 0);
		}
	}

	/**
	 * 显示修改题目的界面
	 */
	public function showEdit(){
		$esId = get('esId');
		if(!($esId >= 1)){
			wrong('非法的题目ID');
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			wrong('指定的题目不存在');
		}
		$isMyEs = $oEs->isUserEs($this->_userId, $esId);
		if(!$isMyEs){
			wrong('该题目不属于您');
		}
		if($aEsInfo['appeal_status'] == 2){
			wrong('申诉中的题目不能编辑');
		}
		if(!in_array($aEsInfo['status'], array(1, 4, 6))){
			wrong('题目已经入库或待审中，不能编辑');
		}
		assign('status', $aEsInfo['status']);

		$oEsPlugin = $this->_esFactory($aEsInfo['subject_id'], $aEsInfo['type_id']);
		$aEsInfo['es_content'] = $oEsPlugin->resolve($aEsInfo['content_json']);
		if($esError = $oEsPlugin->getError()){
			alert($esError, 0);
		}

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$aEsInfo['subject_id']])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		assign('sameBaseEsType', $sameBaseEsType);
		assign('aSameEsTypeId', $aSameEsTypeId);

		assign('aEs', $aEsInfo);
		assign('aCategoryList', Es::getCategoryTreeListBySubjectId($aEsInfo['subject_id']));
		assign('categoryId', $aEsInfo['category_id']);
		assign('subjectId', $aEsInfo['subject_id']);
		assign('esType', $aEsInfo['type_id']);
		assign('id', $aEsInfo['id']);
		displayHeader();
		display('es_create/edit.html.php');
		displayFooter();
	}

	/**
	 * 修改题目
	 */
	public function editEs(){
		$aEs = array();

		//题目信息
		$aEs['id'] = post('id');
		if(!($aEs['id'] >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($aEs['id']);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}
		$isMyEs = $oEs->isUserEs($this->_userId, $aEs['id']);
		if(!$isMyEs){
			alert('题目不属于您', 0);
		}
		if(!in_array($aEsInfo['status'], array(1, 4))){
			alert('题目在库或待审中，不能修改', 0);
		}

		//科目ID
		$subjectId = post('subject_id');
		if(!($subjectId >= 1)){
			alert('非法的科目ID', 0);
		}
		$this->_checkAllowSubject($subjectId);	//检查科目权限

		//题目类型
		$esType = post('es_type');
		if(!($esType >= 1)){
			alert('非法的题目类型ID', 0);
		}

		//调用题目插件
		$oEsPlugin = $this->_esFactory($subjectId, $esType);
		if(!is_object($oEsPlugin)){
			alert('错误的科目或题型', 0);
		}
		$aEsMainContent = $oEsPlugin->build($_POST['es']);
		if($oEsPlugin->getError()){
			alert($oEsPlugin->getError(), 0);
		}
		$aEs['content_json'] = $aEsMainContent['content_json'];
		$aEs['content_text'] = $aEsMainContent['content_text'];

		//检查目录
		$aEs['category_id'] = post('category_id');
		if(!($aEs['category_id'] >= 1)){
			alert('非法的目录ID', 0);
		}else{
			$categoryExists = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
			if(!$categoryExists){
				alert('目录不存在', 0);
			}
		}
		$childNums = $oEs->isExistSubCategory($aEs['category_id']);
		if($childNums > 0){
			alert('选择的目录不是最底层目录，请检查', 0);
		}

		if($aEsInfo['appeal_status'] == 2){
			alert('申诉中的题目不能编辑', 0);
		}

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$esType];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$subjectId])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		if($sameBaseEsType >= 2){
			$aEs['type_id'] = post('es_type');
			if(!in_array($aEs['type_id'], $aSameEsTypeId)){
				alert('错误的题型', 0);
			}
		}

		//检查是否存在相同题干的题目
		if(intval(get('ignore_same_es')) == 0){
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				$aSameEsIdList = array();
				foreach($aSameEsList as $aSameEs){
					$aSameEsIdList[] = $aSameEs['id'];
				}
				alert('检测到正式题库中已经存在相似的题目,是否继续保存?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
			}
		}

		$isUpdataEs = $oEs->setEs($aEs);
		if($isUpdataEs || $isUpdataEs === 0){
			if($aEsInfo['status'] == 4 || post('isSubmit')){
				$aSubmitEs = array();
				$aSubmitEs['id'] = $aEs['id'];
				$aSubmitEs['action'] = 2;
				$aSubmitEs['status'] = 2;
				$aSubmitEs['operating_time'] = time();
				$aSubmitEs['submiter_user_id'] = $this->_userId;
				$aSubmitEs['subject_id'] = $aEsInfo['subject_id'];
				$isSubmitEs = $oEs->changeStatus($aSubmitEs);
				if($isSubmitEs){
					alert('保存提交题目成功', 1, '?m=EsCreate&a=showList&esStatus=' . $aEsInfo['status'] . '&=subject' . $aEsInfo['subject_id']);
				}else{
					alert('保存提交题目失败', 0);
				}
			}
			alert('编辑题目成功', 1, '?m=EsCreate&a=showList&esStatus=' . $aEsInfo['status'] . '&=subject' . $aEsInfo['subject_id']);
		}else{
			alert('编辑题目失败', 0);
		}
	}

	/**
	 * 删除题目
	 */
	public function deleteEs(){
		$esId = post('esId');
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}
		$isMyEs = $oEs->isUserEs($this->_userId, $esId);
		if(!$isMyEs){
			alert('题目不属于您', 0);
		}
		$this->_checkAllowSubject($aEsInfo['subject_id']);	//检查科目权限

		if($aEsInfo['status'] == 1){
			$aEsInfo['action'] = 8;
			$aEsInfo['operating_time'] = time();
			$isDeleteEs = $oEs->deleteEsByEsId($aEsInfo);
			if($isDeleteEs){
				alert('删除题目成功', 1, '?m=EsCreate&a=showList');
			}else{
				alert('删除题目失败', 0);
			}
		}else{
			alert('题目不是已保存状态，不可删除', 0);
		}
	}

	/**
	 * 显示题目详细信息
	 */
	public function showDetail(){
		$esId = intval(get('esId', 0));
		//读出题目数据
		$oEs = m('Es');
		$aEs = $oEs->getEsInfoByEsId($esId);
		if(!$aEs){
			wrong('抱歉,找不到指定的题目');
		}

		//实例化题目解析器解析得到题目视图
		$oEsParser = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
		if(!is_object($oEsParser)){
			wrong('错误的科目或题型');
		}
		$isMyEs = $oEs->isUserEs($this->_userId, $esId);
		if(!$isMyEs){
			wrong('该题目不属于您');
		}
		$aEs['es_content'] = $oEsParser->resolve($aEs['content_json']);

		//取目录名称
		$aCategory = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
		if(!$aCategory){
			wrong('抱歉，数据读取失败');
		}
		$aEs['catetory_name'] = $aCategory['name'];
		assign('aEs', $aEs);

		assign('aSubject', $GLOBALS['SUBJECT']);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aEsStatus', $this->_aEsStatus);
		displayHeader();
		display('es_create/detail.html.php');
		displayFooter();
	}

	/**
	 * 提交题目进行审核
	 */
	public function submitEs(){
		$esId = post('esId');
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEs = $oEs->getEsInfoByEsId($esId);
		if(!$aEs){
			alert('题目不存在', 0);
		}
		$isMyEs = $oEs->isUserEs($this->_userId, $esId);
		if(!$isMyEs){
			alert('题目不属于您', 0);
		}
		$this->_checkAllowSubject($aEs['subject_id']);	//检查科目权限

		if($aEs['appeal_status'] == 2){
			alert('申诉中的题目不能提交', 0);
		}elseif($aEs['status'] == 1 || $aEs['status'] == 4){
			if(get('ignore_same_es') == 0){
				if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
					$aSameEsIdList = array();
					foreach($aSameEsList as $aSameEs){
						$aSameEsIdList[] = $aSameEs['id'];
					}
					alert('检测到正式题库中已经存在相似题目,是否继续提交?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&check_es_id=' . $aEs['id'] . '&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
				}
			}

			$isSubmitEs = $oEs->changeStatus(array(
				'id' => $esId,
				'subject_id' => $aEs['subject_id'],
				'action' => 2,
				'status' => 2,
				'operating_time' => time(),
				'submiter_user_id' => $this->_userId
			));
			if($isSubmitEs){
				alert('提交题目成功', 1, 'reload');
			}else{
				alert('提交题目失败', 0);
			}
		}else{
			alert('提交的题目必须是在已保存或已发回状态', 0);
		}
	}

	/**
	 * 批量提交题目
	 */
	public function batchSubmitEs(){
		$aEsId = post('esIds');
		if(!is_array($aEsId)){
			alert('题目数据格式错误', 0);
		}
		if(count($aEsId) == 0){
			alert('题目数据为空', 0);
		}
		if(!w('isNumber()', $aEsId)){
			alert('非法的题目ID', 0);
		}

		$oEs = m('Es');
		$aEsList = array();	//要处理的题目列表

		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);	//用户可操作科目ID
		$ignoreSameEs = intval(get('ignore_same_es')) == 0;	//是否需要检查相似题目
		foreach($aEsId as $esId){
			$aEs = $oEs->getEsInfoByEsId($esId);
			if(!$aEs){
				alert('题目ID为 ' . $esId . ' 的题目不存在', 0);
			}elseif($aEs['status'] != 1 && $aEs['status'] != 4){
				alert('题目ID为 ' . $esId . ' 的题目状态不是已保存或者已发回，不能提交', 0);
			}elseif(!in_array($aEs['subject_id'], $aAllowSubjectId)){
				alert('您没有操作 ' . $GLOBALS['SUBJECT'][$aEs['subject_id']] . ' 科目的权限', 0);
			}
			if($ignoreSameEs){
				//检查是否存在相似题目
				if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($esId))){
					$aSameEsIdList = array();
					foreach($aSameEsList as $aSameEs){
						$aSameEsIdList[] = $aSameEs['id'];
					}
					alert('检测到正式题库中存在与ID '. $esId .' 相似题目,是否继续提交?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&check_es_id=' . $esId . '&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
				}
			}
			$aEsList[] = $aEs;
		}

		$failMsg = '';
		foreach($aEsList as $aEs){
			$isSubmitEs = $oEs->changeStatus(array(
				'id' => $aEs['id'],
				'subject_id' => $aEs['subject_id'],
				'action' => 2,
				'status' => 2,
				'operating_time' => time(),
				'submiter_user_id' => $this->_userId
			));
			if(!$isSubmitEs){
				if(!$failMsg){
					$failMsg .= '题目ID为 ：';
				}else{
					$failMsg .= $aEs['id'] . '，';
				}
			}
		}
		if(!$failMsg){
			alert('批量提交题目成功', 1, 'reload');
		}else{
			$failMsg .= ' 的题目提交失败';
			alert($failMsg, 0);
		}

	}

	/**
	 * 申诉
	 */
	public function appeal(){
		$esId = post('esId');
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}

		$this->_checkAllowSubject($aEsInfo['subject_id']);	//检查科目权限

		$isMyEs = $oEs->isUserEs($this->_userId, $esId);
		if(!$isMyEs){
			alert('题目不属于您', 0);
		}
		if($aEsInfo['status'] != 4 && $aEsInfo['appeal_status'] == 1){
			alert('申诉的题目必须是在已发回状态且未进行申诉', 0);
		}
		$isAppeal = $oEs->appealByEsId($esId);
		if($isAppeal){
			alert('申诉提交成功', 1, '?m=EsCreate&a=showList');
		}else{
			alert('申诉提交失败', 0);
		}
	}


	/**
	 * 出题时的图片上传
	 */
	public function uploadImage(){
		$subject = get('subject');
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('上传目录不存在', 0);
		}
		$rand = rand(10000, 99999);
		$folder = substr($rand, 3, 2);
		$filePrefix = str_replace(array('0.', ' '), '', microtime()) . '_' . $rand;
		$uploadPath = SYSTEM_RESOURCE_PATH . ES_IMAGE_PATH . $subject . '/' . $folder . '/';
		$oUploader = new UploadFile(512000, 'gif,jpg,jpeg,png,bmp', '', $uploadPath, $filePrefix);

		$uploadFileInfo = $oUploader->uploadOne($_FILES['_es_image']);
		if(!$uploadFileInfo){
			alert('文件上传失败:' . $oUploader->getErrorMsg(), 0);
		}
		$uploadFileInfo = $uploadFileInfo[0];
		$file = SYSTEM_RESOURCE_PATH . '/' . ES_IMAGE_PATH . $subject . '/' . $folder . '/' . $uploadFileInfo['savename'];
		$aImage = getimagesize($file);
		if($aImage[0] > 650){
			@unlink($file);
			alert('请确定图片宽度少于650', 0);
		}

		alert('', 1, ES_IMAGE_PATH . $subject . '/' . $folder . '/' . $uploadFileInfo['savename']);
	}


	/**
	 * 输出目录
	 */
	public function showCategroyTree(){
		$subjectId = get('subject_id');
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			wrong('不存在此科目');
		}
		assign('subjectId', $subjectId);
		$oEs = m('Es');
		$aCategoryList = $oEs->getCategoryDetailedListBySubjectId($subjectId);
		assign('aCategoryList', $aCategoryList);
		display('common/categroytree.html.php');
	}

	/**
	 * 输出相似题目
	 */
	public function showSameEsList(){
		$checkEsId = get('check_es_id', 0);
		$aSameEsIdList = explode(',', get('same_ids', ''));
		if(!w('isNumber()', $aSameEsIdList)){
			alert('请传递相似题目ID列表', 0);
		}
		$oEs = m('Es');
		$aSimilarEsList = $oEs->getEsListForSimilar(array_merge(array($checkEsId), $aSameEsIdList));
		$aEsPlugin = array();	//存放题目插件对象的数组
		foreach($aSimilarEsList as $keyNum => $aEs){
			if(!isset($aEsPlugin[$aEs['subject_id']][$aEs['type_id']])){
				$aEsPlugin[$aEs['subject_id']][$aEs['type_id']] = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
			}
			$aSimilarEsList[$keyNum]['es_content'] = $aEsPlugin[$aEs['subject_id']][$aEs['type_id']]->resolve($aEs['content_json']);
		}
		unset($aEsPlugin);

		$aMainEs = array();
		if($checkEsId > 0){
			foreach($aSimilarEsList as $key => $aEs){
				if($aEs['id'] == $checkEsId){
					$aMainEs = $aEs;
					unset($aSimilarEsList[$key]);
					break;
				}
			}
		}
		assign('aEsStatus', $this->_aStatus);
		assign('aMainEs', $aMainEs);
		sort($aSimilarEsList);
		assign('aSameEsList', $aSimilarEsList);
		displayHeader();
		display('es_create/same_es_list.html.php');
		displayFooter();
	}

	/**
	 * 生产插件对象的工厂
	 * @param type $subject
	 * @param type $esType
	 * @return type
	 */
	private function _esFactory($subject, $esType){
		if(!is_numeric($subject) || !is_numeric($esType)){
			wrong('参数错误');
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			wrong('不存在此科目');
		}
		if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
			wrong('不存在此题型');
		}
		if(!in_array($esType, $GLOBALS['SUBJECT_TYPE'][$subject])){
			wrong($GLOBALS['SUBJECT'][$subject] . '科目不存在' . $GLOBALS['ES_TYPE'][$esType]);
		}
		$oEs = esPlugin($GLOBALS['TYPE_RESOLVER'][$esType]);
		return $oEs;
	}

	/**
	 * 检查绑定的科目
	 */
	private function _checkAllowSubject($subjectId){
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		if(!in_array($subjectId, $aAllowSubjectId)){
			alert('您没有管理 ' . $GLOBALS['SUBJECT'][$subjectId] . ' 科目的权限', 0);
		}
	}

	/**
	 * 获取题目解题思路
	 */
	public function getAnalysis(){
		$aEsIds = (array)post('es_ids');
		if(!$aEsIds || !w('isNumber()', $aEsIds)){
			alert('非法的参数', 0);
		}

		$aEsAnalysisList = m('Es')->getEsAnalysisList($aEsIds);
		if($aEsAnalysisList !== false){
			alert('', 1, $aEsAnalysisList);
		}else{
			alert('', 0);
		}
	}
}