<?php
class StyleController{
	private $_permissionFlag = 'style_management';
	private $_userId = 0;


	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('您没有权限对此操作', 0);
		}
	}

	//显示皮肤列表
	public function showList(){
		tipsNewManage();
		$name = trim(get('style_name'));
		$categoryId = trim(get('category_id'));
		$goldCoinStart = intval(get('gold_coin_start', -1));
		$goldCoinEnd = intval(get('gold_coin_end', -1));
		$status = intval(get('status', -1));
		$levelLimit = intval(get('level_limit', 0));
		$vipLimit = intval(get('vip_limit', -1));
		$isDefault = intval(get('is_default', -1));
		$url = '?m=Style&a=showList&page=_PAGE_';
		$levelArray = $this->_getLevel();
		$page = intval(get('page', 1));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 10;
		$pageCount = 0;
		$aCondition = $aStyleList = array();
		if($categoryId && $categoryId != -1){
			$aCondition['category_id'] = $categoryId;
		}
		if($name){
			$aCondition['name'] = $name;
		}
		if($goldCoinStart >= 0 || $goldCoinEnd >= 0){
			$aCondition['gold_coin'] = array($goldCoinStart, $goldCoinEnd);
		}
		if($status == 0 || $status == 1){
			$aCondition['status'] = $status;
		}
		if(isset($levelArray[$levelLimit])){
			$aCondition['level_limit'] = $levelLimit;
		}
		if(in_array($vipLimit, array(0,1,2,3))){
			$aCondition['vip_limit'] = $vipLimit;
		}
		if($isDefault == 0 || $isDefault == 1){
			$aCondition['is_default'] = $isDefault;
		}
		$oStyle = m('style');
		$styleCount = $oStyle->getStyleCount($aCondition);
		if($styleCount === false){
			alert('系统错误', 0);
		}
		$pageHtml = '';
		if($styleCount > 0){
			$pageCount = ceil($styleCount / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aStyleList = $oStyle->getStyleList($aCondition, $page, $pageSize);
			if($aStyleList === false){
				alert('系统错误', 0);
			}
			if($pageCount > 1){
				$pageHtml = page(array(
					'url' 	=> $url,
					'total' => $styleCount,
					'size' 	=> $pageSize,
					'page' 	=> $page,
				));
			}
		}

		assign('name', $name);
		assign('gold_coin_start', $goldCoinStart);
		assign('gold_coin_end', $goldCoinEnd);
		assign('status', $status);
		assign('level_limit', $levelLimit);
		assign('category_id', $categoryId);
		assign('vip_limit', $vipLimit);
		assign('is_default', $isDefault);
		assign('levelArray', $levelArray);
		assign('aStyleList', $aStyleList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('style/list.html.php');
		displayFooter();
	}

	/**
	 * 显示皮肤添加页面
	 */
	public function showAdd(){
		assign('validateAddStyleJs', j('style_name,category_id,style_price,style_status,style_orders,style_pack_name,style_level_limit,style_is_default,style_vip_limit'));
		assign('levelArray', $this->_getLevel());
		displayHeader();
		display('style/add.html.php');
		displayFooter();
	}

	/**
	 * 添加皮肤
	 */
	public function add(){
		$vAddResult = v('style_name,category_id,style_price,style_status,style_orders,style_pack_name,style_level_limit,style_is_default,style_vip_limit');
		if($vAddResult){
			alert($vAddResult, 0);
		}

		$aStyle = array(
			'name'			=> post('style_name'),					//名称
			'gold_coin'		=> 0,			//使用价格
			'orders'		=> intval(post('style_orders')),		//排序
			'status'		=> 1,	//状态
			'level_limit'	=> 0,	//等级
			'vip_limit'		=> 0,	//VIP等级
			'is_default'	=> intval(post('style_is_default', -1)),		//是否是默认皮肤
			'pack_name'		=> trim(post('style_pack_name')),		//内容
			'category_id'	=> intval(post('category_id')),
			'create_time'	=> time(),
		);

		if(!$aStyle['is_default']){
			$aStyle['gold_coin'] = intval(post('style_price'));
			$aStyle['status'] = intval(post('style_status', -1));
			$aStyle['level_limit'] = intval(post('style_level_limit', -1));
			$aStyle['vip_limit'] = intval(post('style_vip_limit', -1));
		}

		$oStyle = m('style');
		$checkResult = $oStyle->getStyleCount(array('name' => $aStyle['name']));
		if($checkResult === false){
			alert('系统错误', 0);
		}elseif($checkResult > 0){
			alert('名称为: ' . $aStyle['name'] . ' 的皮肤记录己存在', 0);
		}

		$insertResult = $oStyle->addStyles($aStyle);
		if($insertResult === false){
			alert('系统错误', 0);
		}

		if($insertResult > 0){
			alert('添加成功 <a href="/?m=Style&a=showList">皮肤列表</a>', 1);
		}else{
			alert('添加失败', 0);
		}
	}

	/**
	 * 显示编辑皮肤
	 */
	public function showEdit(){
		$id = intval(get('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oStyle = m('style');
		$aStyle = $oStyle->getStyleInfoById($id);

		if(!$aStyle){
			alert('数据不存在', -1);
		}
		assign('validateAddStyleJs', j('style_name,category_id,style_price,style_status,style_orders,style_pack_name,style_level_limit,style_is_default,style_vip_limit'));
		assign('levelArray', $this->_getLevel());
		assign('aStyleInfo', $aStyle);
		displayHeader();
		display('style/edit.html.php');
		displayFooter();
	}


	/**
	 * 编辑皮肤
	 */
	public function edit(){
		$id = (int)post('id');
		$oStyle = m('style');
		$aStyle = $oStyle->getStyleInfoById($id);
		if(!$aStyle){
			alert('该皮肤不存在', -1);
		}

		$vAddResult = v('style_name,category_id,style_price,style_status,style_orders,style_pack_name,style_level_limit,style_is_default,style_vip_limit');
		if($vAddResult){
			alert($vAddResult, 0);
		}

		$aStyle['name'] = (string)post('style_name');
		$aStyle['pack_name'] = (string)post('style_pack_name');
		$aStyle['gold_coin'] = 0;
		$aStyle['orders'] = (int)post('style_orders');
		$aStyle['status'] = 1;
		$aStyle['level_limit'] = 0;
		$aStyle['vip_limit'] = 0;
		$aStyle['category_id'] = (int)post('category_id');
		$aStyle['is_default'] = (int)post('style_is_default', -1);

		if(!$aStyle['is_default']){
			$aStyle['gold_coin'] = (int)post('style_price');
			$aStyle['status'] = (int)post('style_status', -1);
			$aStyle['level_limit'] = (int)post('style_level_limit', -1);
			$aStyle['vip_limit'] = (int)post('style_vip_limit', -1);
		}

		$hasUsed = 0;
		$aCheckArray = $oStyle->getStyleList(array('name' => $aStyle['name']));
		if($aCheckArray === false){
			alert('系统错误', 0);
		}
		if($aCheckArray){
			foreach($aCheckArray as $aCheckInfo){
				if($aCheckInfo['id'] != $id){
					$hasUsed = $aCheckInfo['id'];
					break;
				}
			}
		}
		if($hasUsed > 0){
			alert('名称为: ' . $aStyle['name'] . ' 的皮肤记录己存在', 0);
		}
		unset($aCheckArray);

		$updateResult = $oStyle->setStyle($aStyle);
		if($updateResult === false){
			alert('系统错误', 0);
		}elseif(!$updateResult){
			alert('您没有作任何修改', 0);
		}

		if($aStyle['is_default']){
			$defaultResult = $oStyle->setDefaultStyle($id);
			if($defaultResult === false){
				myLog('将ID为 : ' . $id . '的皮肤设置为默认皮肤时操作失败');
			}
		}

		alert('操作成功 <a href="/?m=Style&a=showList">皮肤列表</a>', 1);
	}

	/**
	 * 将皮肤设为默认皮肤
	 */
	public function setDefaultStyle(){
		$id = intval(post('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oStyle = m('style');
		$aStyleInfo = $oStyle->getStyleInfoById($id);
		if($aStyleInfo === false){
			alert('系统错误', 0);
		}
		if(!$aStyleInfo){
			alert('数据不存在', 0);
		}
		if($aStyleInfo['status'] == 0){
			alert('这个皮肤还没发布', 0);
		}
		if($aStyleInfo['is_default'] == 1){
			alert('这个皮肤己经是默认皮肤了', 0);
		}

		$aCondition = array('is_default'=>1);
		$aDefaultInfo = $oStyle->getStyleList($aCondition);
		if($aDefaultInfo === false){
			alert('系统错误', 0);
		}

		if($aDefaultInfo){
			$aData = array(
				'id' 		=> $aDefaultInfo[0]['id'],
				'is_default'=> 0
			);
			$result = $oStyle->setStyle($aData);
			if($result === false){
				alert('系统错误', 0);
			}
			if($result > 0){
				$aNewData = array(
					'id'		=> $id,
					'is_default'=> 1
				);
				$setReulst = $oStyle->setStyle($aNewData);
				if($setReulst === false){
					$aData['is_default'] = 1;
					$oStyle->setStyle($aData);
					alert('系统错误', 0);
				}
				if($setReulst > 0){
					alert('操作成功', 1);
				}else{
					$aData['is_default'] = 1;
					$oStyle->setStyle($aData);
					alert('操作失败', 0);
				}
			}else{
				alert('操作失败', 0);
			}
		}else{
			$aData = array(
				'id' 		=> $id,
				'is_default'=> 1
			);
			$result = $oStyle->setStyle($aData);
			if($result === false){
				alert('系统错误', 0);
			}
			if($result > 0){
				alert('操作成功', 1);
			}else{
				alert('操作失败', 0);
			}
		}
	}

	/**
	 * 删除皮肤
	 */
	public function delete(){
		$id = intval(post('id', 0));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oStyle = m('style');
		$aStyleInfo = $oStyle->getStyleInfoById($id);
		if($aStyleInfo === false){
			alert('系统错误', 0);
		}
		if(!$aStyleInfo){
			alert('要删除的数据不存在', 0);
		}
		if($aStyleInfo['status'] == 1){
			alert('这个皮肤己发布不能删除哦', 0);
		}
		$result = $oStyle->deleteStyles($id);
		if($result){
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}

	//会员等级
	private function _getLevel(){
		$aLevelList = array();
		if(isset($GLOBALS['LEVEL'])){
			for($i = 1; $i <= count($GLOBALS['LEVEL']); $i++){
				$aLevelList[$i] = $i . '级';
			}
		}
		return $aLevelList;
	}
}