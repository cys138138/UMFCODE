<?php
/**
 * 道具模块
 */
class PropController{

	private $_userId = 0;
	
	public function __construct(){
		if(get('a') != 'uploadImage'){
			$this->_userId = checkLogin();
		}
	}
	
	public function showList(){
		$status = intval(get('status', -1));
		$type = intval(get('type', 0));
		$moneyType = intval(get('moneyType', 0));
		if(!in_array($status, array(-1, 1, 0))){
			alert('上架状态错误');
		}
		if(!in_array($type, array(0, 1, 2, 3, 4, 5, 6, 7, 8))){
			alert('类型错误');
		}
		if(!in_array($moneyType, array(0, 1, 2))){
			alert('货币类型错误');
		}
		$aCondition = array(
			'money_type' => $moneyType,
			'is_publish' => $status,
		);
		if($type){
			$aCondition['type'] = array($type);
		}else{
			$aCondition['type'] = array();
		}
		$oProp = m('Prop');
		$aPropList = $oProp->getPropList($aCondition, 1, 30);
		assign('aPropList', $aPropList);
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);
		assign('status', $status);
		assign('type', $type);
		assign('moneyType', $moneyType);
		//$url .= '&status=' . $status . '&type=' . $type . '&moneyType=' . $moneyType;

		displayHeader();
		display('prop/list.html.php');
		displayFooter();
	}
	
	public function showAdd(){
		displayHeader();
		display('prop/add.html.php');
		displayFooter();
	}
	
	public function addProp(){
		$propName = trim(post('propName'));
		$profile = trim(post('profile'));
		$description = trim(post('description'));
		$range = trim(post('range'));
		$mark = trim(post('mark'));
		$moneyType = post('moneyType');
		$price = intval(post('price'));
		$discount = intval(post('discount'));
		$startTime = post('startTime');
		$endTime = post('endTime');
		$vipDiscount = intval(post('vipDiscount'));
		$isPublish = post('isPublish');
		$type = post('type');
		
		$check = $this->_checkProp($propName, $profile, $description, $range, $mark, $moneyType, $price, $discount, $startTime, $endTime, $vipDiscount, $isPublish, $type);
		if($check !== true){
			alert($check, -1);
		}
		
		$now = time();
		$aProp = array(
			'name' => $propName,
			'ico' => $profile,
			'description' => $range . '---' . $description,
			'type' => $type,
			'prop_code' => $mark,
			'money_type' => $moneyType,
			'price' => $price,
			'discount' => $discount,
			'vip_discount' => $vipDiscount,
			'purchase_total' => 0,
			'use_total' => 0,
			'is_publish' => $isPublish,
			'create_time' => $now,
		);
		if($isPublish == 1){
			$aProp['on_market_time'] = $now;
		}
		if($discount < 100){
			$aProp['discount_start_time'] = strtotime($startTime);
			$aProp['discount_end_time'] = strtotime($endTime);
		}else{
			$aProp['discount_start_time'] = 0;
			$aProp['discount_end_time'] = 0;
		}
		$oProp = m('Prop');
		if($oProp->addProp($aProp)){
			alert('添加道具成功', 1, 'm=Prop&a=showList');
		}else{
			alert('添加道具失败', 0);
		}
	}
	
	function showEdit(){
		$id = intval(get('id'));
		$oProp = m('Prop');
		$aProp = $oProp->getPropInfoById($id);
		assign('aProp', $aProp);
		
		displayHeader();
		display('prop/edit.html.php');
		displayFooter();
	}
	
	function editProp(){
		$id = intval(post('id'));
		$propName = trim(post('propName'));
		$profile = trim(post('profile'));
		$description = trim(post('description'));
		$range = trim(post('range'));
		$mark = trim(post('mark'));
		$moneyType = post('moneyType');
		$price = intval(post('price'));
		$discount = intval(post('discount'));
		$startTime = post('startTime');
		$endTime = post('endTime');
		$vipDiscount = intval(post('vipDiscount'));
		$isPublish = post('isPublish');
		$type = post('type');
		
		$check = $this->_checkProp($propName, $profile, $description, $range, $mark, $moneyType, $price, $discount, $startTime, $endTime, $vipDiscount, $isPublish, $type);
		if($check !== true){
			alert($check, -1);
		}
		
		$oProp = m('Prop');
		$aBeforeProp = $oProp->getPropInfoById($id);
		if(!$aBeforeProp){
			alert('道具不存在', -1);
		}
		
		$now = time();
		$aProp = array(
			'id' => $id,
			'name' => $propName,
			'ico' => $profile,
			'description' => $range . '---' . $description,
			'type' => $type,
			'prop_code' => $mark,
			'money_type' => $moneyType,
			'price' => $price,
			'discount' => $discount,
			'vip_discount' => $vipDiscount,
			'is_publish' => $isPublish,
		);
		if($isPublish == 1 && $aBeforeProp['is_publish'] != 1){
			$aProp['on_market_time'] = $now;
		}
		if($discount < 100){
			$aProp['discount_start_time'] = strtotime($startTime);
			$aProp['discount_end_time'] = strtotime($endTime);
		}else{
			$aProp['discount_start_time'] = 0;
			$aProp['discount_end_time'] = 0;
		}
		$result = $oProp->setProp($aProp);
		if($result || $result === 0){
			alert('修改道具成功', 1, 'm=Prop&a=showList');
		}else{
			alert('修改道具失败', 0);
		}
	}
	
	public function changeStatus(){
		$id = intval(post('id'));
		$oProp = m('Prop');
		$aBeforeProp = $oProp->getPropInfoById($id);
		if(!$aBeforeProp){
			alert('道具不存在', -1);
		}
		$aProp = array('id' => $id);
		if($aBeforeProp['is_publish'] == 1){
			$aProp['is_publish'] = 0;
		}else{
			$aProp['is_publish'] = 1;
		}
		if($oProp->setProp($aProp)){
			alert('修改成功', 1);
		}else{
			alert('操作失败', 0);
		}
	}
	
	private function _checkProp($propName, $profile, $description, $range, $mark, $moneyType, $price, $discount, $startTime, $endTime, $vipDiscount, $isPublish, $type){
		if(!$propName){
			return '请填写道具名称';
		}
		if(!$profile){
			return '请上传道具图标';
		}
		if(!$description){
			return '请填写道具描述';
		}
		if(!$range){
			return '请选择道具使用范围';
		}
		if(!$mark){
			return '请填写道具标记';
		}
		if($moneyType != 1 && $moneyType != 2){
			return '请选择货币类型';
		}
		if(!($price > 0)){
			return '价格必须是大于0的数字';
		}
		if(!($discount > 0 && $discount <= 100)){
			return '折扣必须是大于0小于等于100';
		}
		if($discount < 100){
			if(!$startTime){
				return '请填写折扣开始时间';
			}
			if(!$endTime){
				return '请填写折扣结束时间';
			}
			$startTime = strtotime($startTime);
			$endTime = strtotime($endTime);
			if($startTime >= $endTime){
				return '折扣结束时间必须大于开始时间';
			}
		}
		if(!($vipDiscount > 0 && $vipDiscount < 100)){
			return 'VIP折扣必须是大于0小于100';
		}
		if($isPublish != 0 && $isPublish != 1){
			return '请选择是否上架';
		}
		if(!in_array($type, array(1,2,3,4,5,6,7,8))){
			return '请选择道具类型';
		}
		return true;
	}
	
	public function uploadImage(){
		$rand = rand(10000, 99999);
		$mark = post('mark');
		if(!$mark){
			alert('请先填写道具标记', 0);
		}
		$filePrefix = md5($mark);
		$path = 'view2/images/prop/';
		$uploadPath = SYSTEM_RESOURCE_PATH . $path;
		$oUploader = new UploadFile(307200, 'gif,jpg,jpeg,png,bmp', '', $uploadPath, $filePrefix, true);
		$uploadFileInfo = $oUploader->uploadOne($_FILES['Filedata']);
		if(!$uploadFileInfo){
			alert($oUploader->getErrorMsg(), 0);
		}
		$uploadFileInfo = $uploadFileInfo[0];
		$file = SYSTEM_RESOURCE_PATH . '/' . $path . $uploadFileInfo['savename'];
		$aImage = getimagesize($file);
		if($aImage[0] > 200){
			@unlink($file);
			alert('请确定图片宽度少于200', 0);
		}
		alert(SYSTEM_RESOURCE_URL . '/' . $path . $uploadFileInfo['savename'], 1, $path . $uploadFileInfo['savename']);
	}
}

