<?php
/*
 * 团队赛后台管理控制器
 * 罗启军
 * 455538375@qq.com
 * 只要是石头，到哪里都不会发光的---高尔基
 */
class TeamController{
	const AUTHORITY = 'manage_team';
	private $_userId = 0;
	
	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, self::AUTHORITY)){
			alert('您没有权限对此操作', 0);
		}
	}
	
	
	public function showPrizeList(){
		$oPrize = m('Team');
		$aPrizeList = $oPrize->getPrizeList('`id` > 0', 1, 500);
		assign('aPrizeList', $aPrizeList);
		display('team/prizes.html.php');
	}
	
	public function showMatchList(){
		$oMatch = m('Team');
		$aMatchList = $oMatch->getMathchList('`id` > 0', 1, 100);
		assign('aMatchList', $aMatchList);
		display('team/match.html.php');
	}
	
	public function showAddPrize(){
		display('team/prizes_add.html.php');
	}
	
	public function addPrize(){
		$name = post('name');
		if(!$name){
			alert('喂喂，给奖品起个名字好吧', -1);
		}
		$imageAddr = post('prize_addr');
		$image = SYSTEM_RESOURCE_PATH . $imageAddr;
		if(!file_exists($image)){
			alert('喂喂大哥，明显还没上传图片好吧', -1);
		}
		$aData = array(
			'name' => $name,
			'image' => $imageAddr,
			'create_time' => time(),
 		);
		$oPrize = m('Team');
		if($oPrize->addPrize($aData)){
			alert('好吧，有奖品咯，不过建议您先去报销钱', 1);
		}else{
			alert('我去，添加奖品失败了', 0);
		}
	}
	
	public function showAddMatch(){
		$oTeam = m('Team');
		$aPrizeList = $oTeam->getPrizeList('`id` > 0', 1, 100);
		assign('aPrizeList', $aPrizeList);
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`name`', '`limit_xxt`=1 AND `is_team_match`=1 AND `is_release`=1', '', 0, 200);
		//debug($aMatchList);
		assign('aMatchList', $aMatchList);
		display('team/match_add.html.php');
	}
	
	public function addMatch(){
		$aData = $this->_checkMatchData();
		$oTeam = m('Team');
		if($oTeam->addMatch($aData)){
			alert('准备好迎接团队赛的腥风血雨吧哈哈哈哈！！', 1);
		}else{
			alert('出错！任性！', 0);
		}
	}
	
	
	private function _checkMatchData(){
		$name = post('name');
		$firstMatch = intval(post('first_match_id'));
		$secondMatch = intval(post('second_match_id'));
		$first = intval(post('first'));
		$secondTenth = intval(post('second_tenth'));
		$firstLucky = intval(post('first_lucky'));
		$secondLucky = intval(post('second_lucky'));
		
		if(!$name){
			alert('我说赛事主题怎么也得5个字以上吧', -1);
		}
		if(!$firstMatch){
			alert('不让人做第一轮题目了吗', -1);
		}
		if(!$secondMatch){
			alert('不让人做第二轮题目了吗', -1);
		}
		if(!$first){
			alert('第一名奖品也不给人家，好坏好坏哒', -1);
		}
		if(!$secondTenth){
			alert('二到十名的奖品也不给人家，好坏好坏哒', -1);
		}
		if(!$firstLucky){
			alert('一轮幸运奖奖品也不给人家，好坏好坏哒', -1);
		}
		
		if(!$secondLucky){
			alert('二轮幸运奖奖品也不给人家，好坏好坏哒', -1);
		}
		$aData = array(
			'name' => $name,
			'first_match_id' => $firstMatch,
			'second_match_id' => $secondMatch,
			'prizes' => array('first_lucky' => $firstLucky, 'second_lucky' => $secondLucky, 'second_tenth' => $secondTenth, 'first' => $first),
			'create_time' => time(),
		);
		return $aData;
	}
	
	public function showEditPrize(){
		$id = intval(get('id'));
		$oPrize = m('Team');
		$aPrize = $oPrize->getPrizeInfoById($id);
		if(!$aPrize){
			alert('奖品不存在', -1);
		}
		assign('aPrize', $aPrize);
		display('team/prizes_edit.html.php');
	}
	
	public function setPrize(){
		$id= intval(post('id'));
		$name = post('name');
		if(!$name){
			alert('喂喂，给奖品起个名字好吧', -1);
		}
		$imageAddr = post('prize_addr');
		$image = SYSTEM_RESOURCE_PATH . $imageAddr;
		if(!file_exists($image)){
			alert('喂喂大哥，明显还没上传图片好吧', -1);
		}
		$aData = array(
			'id' => $id,
			'name' => $name,
			'image' => $imageAddr,
 		);
		$oPrize = m('Team');
		if($oPrize->setPrize($aData)){
			alert('改来改去有意思么', 1);
		}else{
			alert('我去，添加奖品失败了', 0);
		}
	}
	
	
	public function showEditMatch(){
		$id = intval(get('id'));
		$oTeam = m('Team');
		$aMatch = $oTeam->getMatchById($id);
		if(!$aMatch){
			alert('估计赛事被狗吃了', -1);
		}
		assign('aMatch', $aMatch);
		
		$aPrizeList = $oTeam->getPrizeList('`id` > 0', 1, 100);
		assign('aPrizeList', $aPrizeList);
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`name`', '`limit_xxt`=1 AND `is_team_match`=1 AND `is_release`=1', '', 0, 200);
		assign('aMatchList', $aMatchList);
		display('team/match_edit.html.php');
	}
	
	public function setMatch(){
		$id = intval(post('id'));
		$oTeam = m('Team');
		$aMatch = $oTeam->getMatchById($id);
		if(!$aMatch){
			alert('赛事被狗吃了', -1);
		}
		$aData = $this->_checkMatchData();
		$aData['id'] = $id;
		if($oTeam->setMatch($aData)){
			alert('改来改去好好玩吧', 1);
		}else{
			alert('出错！任性！', 0);
		}
	}
	
	public function showTeam(){
		$oTeam = m('Team');
		$aMatchList = $oTeam->getMathchList('`id` > 0',1, 500);
		$id = intval(get('id'));
		if($id){
			$where = '`match_id` = ' . $id;
		}else{
			$where = '`match_id` > 0';
		}
		$aTeamList = $oTeam->getJoinList('*', $where, 1, 2000);

		//参赛人数
		$userCount = intval(get('user_count', 0));
		if($userCount){
			foreach ($aTeamList['list'] as $k => $aList) {
				$temp = key_exists('user_info', $aList) ? count($aList['user_info']) : 0;
				if ($temp != $userCount) {
					unset($aTeamList['list'][$k]);
				}
			}
		}

		assign('aMatchList', $aMatchList);
		assign('aTeamList', $aTeamList);
		display('team/team.html.php');
	}
	
	public function uploadProfile(){
		$folder = 'data/team/';
		$imageAddr = SYSTEM_RESOURCE_PATH . $folder;
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(3072000, 'jpg,png,gif', '', $imageAddr,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败".' . $oUploader->getErrorMsg() . '."', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$aWidthAndHeight = array();
		$aWidthAndHeight = getimagesize($imageAddr . $uploadFileInfo['savename']);
		if(!$aWidthAndHeight){
			alert('文件上传失败', 0);
		}
		$width = intval($aWidthAndHeight[0]);
		$height = intval($aWidthAndHeight[1]);
		if($width > 1920){
			if(file_exists($imageAddr . $uploadFileInfo['savename'])){
				unlink($imageAddr . $uploadFileInfo['savename']);
			}
			alert('图片宽度不能超过1920px', 0);
		}
		alert($folder . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . $folder . $uploadFileInfo['savename']);
	}


}