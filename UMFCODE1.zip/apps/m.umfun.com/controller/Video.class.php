<?php
class VideoController{
	private $_permissionFlag = 'manage_video';
	private $_userId = 0;
	
	public function __construct(){	
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			wrong('您没有权限对此操作');
		}
	}
	
	//视频分类列表
	public function showCategoryList(){
		$page = intval(get('page', 1));
		$categoryName = get('categoryName');
		$status = intval(get('categoryStatus', -1));
		$pageSize = 10;
		$url = '/?m=Video&a=showCategoryList&page=_PAGE_';
		$oVideo = m('video');
		$aCategoryList = array();
		$categoryCount = 0;
		if($categoryName){
			$aCategoryList = array($oVideo->getVideoCategoryInfoByName($categoryName));
			if($aCategoryList[0] === false){
				alert('系统错误', 0);
			}elseif(!$aCategoryList[0]){
				unset($aCategoryList[0]);
			}
		}else{
			$url .= '&categoryStatus=' . $status;
			$categoryCount = $oVideo->getVideoCategoryCount($status);
			if($categoryCount === false){
				alert('系统错误', 0);
			}
			if($categoryCount > 0){
				$aCategoryList = $oVideo->getVideoCategoryList($status, $page, $pageSize);	
			}
			if($aCategoryList === false){
				alert('系统错误', 0);
			}
		}
		$aPageInfo = array(
			'url' 	=> $url,
			'total' => $categoryCount,
			'size' 	=> $pageSize,
			'page' 	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('aCategoryList', $aCategoryList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('video/category_list.html.php');
		displayFooter();
	}
	
	//视频分类添加视图
	public function showCategoryAdd(){
		assign('validateAddMatchJs', j('category_name'));
		displayHeader();
		display('video/category_add.html.php');
		displayFooter();
	}
	
	//视频分类添加
	public function categoryAdd(){
		$vResult = v('category_name');
		if($vResult){
			alert($vResult, -1);
		}
		$aData = array(
			'name'		 => post('category_name'),
			'status'	 => post('category_status'),
			'create_time'=> time()
		);
		if($aData['status'] != 0 && $aData['status'] != 1){
			alert('请选择显示状态', -1);
		}
		$oVideo = m('video');
		$aCategorInfo = $oVideo->getVideoCategoryInfoByName($aData['name']);
		if($aCategorInfo === false){
			alert('系统错误', 0);
		}
		if($aCategorInfo){
			alert('名为:' . $aData['name'] . ' 的分类己存在', -1);
		}
		$aCategorResult = $oVideo->addVideoCategory($aData);
		if($aCategorResult){
			alert('操作成功', 1);
		}else{
			alert('操作失败', 0);
		}
	}
	
	
	//视频分类编辑视图
	public function showCategoryEdit(){
		$id = intval(get('id'));
		if($id < 1){
			alert('数据错误', 0);
		}
		
		$oVideo = m('video');
		$aCategoryInfo = $oVideo->getVideoCategoryInfoById($id);
		if($aCategoryInfo === false){
			alert('系统错误', 0);
		}
		if(!$aCategoryInfo){
			alert('此分类不存在', 0);
		}
		assign('aCategoryInfo', $aCategoryInfo);
		assign('validateAddMatchJs', j('category_name'));
		displayHeader();
		display('video/category_edit.html.php');
		displayFooter();
	}
	
	//视频分类编辑
	public function categoryEdit(){
		$vResult = v('category_name');
		if($vResult){
			alert($vResult, -1);
		}
		$aData = array(
			'id'	 => intval(post('category_id')),
			'name'	 => post('category_name'),
			'status' => intval(post('category_status'))
		);
		if($aData['id'] < 1 || ($aData['status'] != 0 && $aData['status'] != 1)){
			alert('数据错误', -1);
		}
		$oVideo = m('video');
		$aVideoInfo = $oVideo->getVideoCategoryInfoByName($aData['name']);
		if($aVideoInfo === false){
			alert('系统错误', 0);
		}
		if($aVideoInfo && $aVideoInfo['id'] != $aData['id']){
			alert('标题为:' . $aData['name'] . ' 的视频分类己存在', -1);
		}
		$editResult = $oVideo->setVideoCategory($aData);
		
		if($editResult === false){
			alert('系统错误', 0);
		}elseif($editResult == 0){
			alert('没有修改数据', -1);
		}else{
			alert('操作成功', 1);
		}
		
	}
	
	//视频分类删除
	public function delCategory(){
		$categoryId = intval(post('categoryId'));
		if($categoryId < 1){
			alert('数据错误', 0);
		}
		$oVideo = m('video');
		$aCategorInfo = $oVideo->getVideoCategoryInfoById($categoryId);
		if($aCategorInfo === false){
			alert('系统错误', 0);
		}
		if(!$aCategorInfo){
			alert('该分类不存在', 0);
		}
		
		$aCondition = array(
			'is_background' => 1,
			'category_id'	=> $categoryId
		);
		$aCategorVideoCount = $oVideo->getVideoCount($aCondition);
		if($aCategorVideoCount === false){
			alert('系统错误', 0);
		}
		if($aCategorVideoCount > 0){
			alert('该分类下还有' .$aCategorVideoCount . '条视频数据,暂不能进行此操作', -1);
		}
		if($oVideo->deleteVideoCategoryById($categoryId)){
			alert('操作成功', 1);
		}else{
			alert('操作失败', 0);
		}	
		
	}
	
	//视频列表
	public function showVideoList(){
		$url = '/?m=Video&a=showVideoList&page=_PAGE_';
		$searchType = intval(get('searchType'));
		$searchValue = get('searchValue');
		
		$categoryId = intval(get('categoryId'));
		$videoStatus = intval(get('videoStatus', -1));
		$videoRecommend = intval(get('videoRecommend', -1));

		$page = intval(get('page', 1));
		$pageSize = 10;
		$videoCount = 0;
		$aVideoList = array();
		$oVideo = m('video');
		if($searchType > 0 && $searchValue){
			$aVideoInfo = array();
			if($searchType == 1){
				$aVideoInfo = $oVideo->getVideoInfoByTitle(addslashes($searchValue));
			}
			if($searchType == 2 && $searchValue > 0){
				$aVideoInfo = $oVideo->getVideoInfoById($searchValue);
			}
			if($searchType == 3){
				$aVideoInfo = $oVideo->getVideoInfoByUmelookId($searchValue);
			}
			if($aVideoInfo === false){
				alert('系统错误', 0);
			}
			if($aVideoInfo){
				$aVideoList[0] = $aVideoInfo;
			}
			unset($aVideoInfo);
		}else{
			$aCondition = array(
				'is_background' => 1,
				'category_id' => $categoryId,
				'statu' => $videoStatus,
				'is_recommend' => $videoRecommend
			);
			$videoCount = $oVideo->getVideoCount($aCondition);
			if($videoCount === false){
				alert('系统错误', 0);
			}
			$aVideoList = $oVideo->getVideoList($aCondition, $page, $pageSize);
			if($aVideoList === false){
				alert('系统错误', 0);
			}
			$url .= '&categoryId=' . $categoryId . '&videoStatus=' . $videoStatus . '&videoRecommend=' . $videoRecommend;
		}
		$aPageInfo = array(
			'url' 	=> $url,
			'total' => $videoCount,
			'size' 	=> $pageSize,
			'page' 	=> $page,
		);
		$pageHtml = page($aPageInfo);
		$aCategoryList = $this->_getCategoryList(-1);
		if($aCategoryList === false){
			alert('系统错误', 0);
		}
		assign('aVideoList', $aVideoList);
		assign('aCategoryList', $aCategoryList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('video/video_list.html.php');
		displayFooter();	
	}
	
	//视频添加视图
	public function showVideoAdd(){
		$aCategoryList = $this->_getCategoryList();
		if($aCategoryList === false){
			alert('系统错误', 0);
		}
		assign('aCategoryList', $aCategoryList);
		assign('validateAddMatchJs', j('video_title,video_views,video_description,category_id,video_status,is_recommend,thumb_url,video_url,umelook_id,video_duration'));
		displayHeader();
		display('video/video_add.html.php');
		displayFooter();	
	}
	
	//视频添加
	public function videoAdd(){
		$vResult = v('video_title,video_views,video_description,category_id,video_status,is_recommend,thumb_url,video_url,umelook_id,video_duration');
		if($vResult){
			alert($vResult, -1);
		}
		$aData = array(
			'title'			=> post('video_title'),	
			'views'			=> post('video_views'),
			'description'	=> post('video_description'),
			'category_id'	=> intval(post('category_id')),
			'status'		=> intval(post('video_status')),
			'is_recommend'	=> intval(post('is_recommend')),
			'thumb_url'		=> post('thumb_url'),
			'video_url'		=> post('video_url'),
			'umelook_id'	=> intval(post('umelook_id')),
			'duration'		=> intval(post('video_duration')),
			'is_trans'		=> intval(post('is_trans')),
			'create_time'	=> time()
		);
		$oVideo = m('video');
		$aResult = $oVideo->getVideoInfoByUmelookId($aData['umelook_id']);
		if($aResult === false){
			alert('系统错误', 0);
		}
		if($aResult){
			alert('UMELOOK ID 为 ' . $aData['umelook_id'] . '的数据己存在', -1);
		}
		$aResult = $oVideo->getVideoInfoByTitle($aData['title']);
		if($aResult === false){
			alert('系统错误', 0);
		}
		if($aResult){
			alert('视频标题 为 ' . $aData['title'] . '的数据己存在', -1);
		}
		if($oVideo->addVideo($aData)){
			alert('操作成功', 1);
		}else{
			alert('操作失败', 0);
		}
		
	}

	//视频编辑视图
	public function showVideoEdit(){
		$id = intval(get('id'));
		if($id < 1){
			alert('数据错误', 0);
		}
		$oVideo = m('video');
		$aVideoInfo = $oVideo->getVideoInfoById($id);
		if($aVideoInfo === false){
			alert('系统错误', 0);
		}
		if(!$aVideoInfo){
			alert('此视频不存在', 0);
		}
		$aVideoInfo['play_url'] = base64_encode($aVideoInfo['umelook_id']) . '__';
		if($aVideoInfo['is_trans'] == 1){
			$aVideoInfo['play_url'] .= base64_encode($aVideoInfo['umelook_id']) . '_0.xml';
		}
		
		$aCategoryList = $this->_getCategoryList();
		if($aCategoryList === false){
			alert('系统错误', 0);
		}
		
		assign('aVideoInfo', $aVideoInfo);
		assign('aCategoryList', $aCategoryList);
		assign('validateAddMatchJs', j('video_title,video_views,video_description,category_id,video_status,is_recommend,thumb_url,video_url,umelook_id,video_duration'));
		displayHeader();
		display('video/video_edit.html.php');
		displayFooter();
	}

	//视频编辑
	public function videoEdit(){
		$vResult = v('video_title,video_views,video_description,category_id,video_status,is_recommend,thumb_url,video_url,umelook_id,video_duration');
		if($vResult){
			alert($vResult, -1);
		}
		$aData = array(
			'id'			=> intval(post('video_id')),
			'title'			=> post('video_title'),	
			'views'			=> post('video_views'),
			'description'	=> post('video_description'),
			'category_id'	=> intval(post('category_id')),
			'status'		=> intval(post('video_status')),
			'is_recommend'	=> intval(post('is_recommend')),
			'thumb_url'		=> post('thumb_url'),
			'video_url'		=> post('video_url'),
			'umelook_id'	=> intval(post('umelook_id')),
			'duration'		=> intval(post('video_duration')),
			'is_trans'		=> intval(post('is_trans'))
		);
		$oVideo = m('video');
		$aResult = $oVideo->getVideoInfoByTitle($aData['title']);
		if($aResult === false){
			alert('系统错误', 0);
		}
		if($aResult && $aResult['id'] != $aData['id']){
			alert('视频标题为:' . $aData['title'] . ' 的视频己存在', -1);
		}
		$setResult = $oVideo->setVideo($aData);
		if($setResult === false){
			alert('系统错误', 0);
		}
		if($setResult > 0){
			alert('操作成功', 1);
		}else{
			alert('没有修改数据', -1);
		}
	}

	//视频删除
	public function delVideo(){
		$videoId = intval(post('videoId'));
		if($videoId < 1){
			alert('数据错误', -1);
		}
		$oVideo = m('video');
		if($oVideo->deleteVideoById($videoId)){
			alert('操作成功', 1);	
		}else{
			alert('操作失败', 0);
		}
	}
	
	
	//视频采集
	public function getVideoInfo(){
		$id = intval(post('id'));
		if($id < 1){
			alert('数据错误', 0);
		}
		$videoUrl = 'http://f.umelook.com/apps/interface/data/umfun.php?id=' . $id;
		$videoResult = '';
		if(function_exists('file_get_contents')){
			$videoResult = file_get_contents($videoUrl);
		}else{
			$ch = curl_init();
			$timeout = 10;
			curl_setopt($ch, CURLOPT_URL, $videoUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$videoResult = curl_exec($ch);
			curl_close($ch);
		}
		if(!$videoResult){
			alert('视频采集失败', 0);
		}
		$aVideoArray = json_decode($videoResult, true);
		if(!$aVideoArray){
			myLog('解析umelook视频出错,相关信息:' . $videoResult);
			alert('远程网络可能有点慢,解析失败', 0);
		}elseif($aVideoArray['status'] == 1){
			$aVideoArray['data']['play_url'] = base64_encode($aVideoArray['data']['id']) . '__' . $aVideoArray['data']['tran_url'];
		}
		alert($aVideoArray['msg'], $aVideoArray['status'], isset($aVideoArray['data']) ? $aVideoArray['data'] : '' );
		
	}
	
	
	
	//返回所有视频分类  $status = 1 所有可见分类， $status = 0 所有不可见分类，$status = -1 所有分类
	private function _getCategoryList($status = 1){
		$oVideo = m('video');
		$categoryCount = $oVideo->getVideoCategoryCount($status);
		if($categoryCount === false){
			return false;
		}
		$aCategoryList = $oVideo->getVideoCategoryList($status, 1, $categoryCount);
		if($aCategoryList === false){
			return false;
		}
		return $aCategoryList;
		
	}
	

}