<?php
class ServiceController {
	private $_userId = 0;
	private $_permissionFlag = 'manage_feedback';

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('抱歉！您无权进行操作，请联系管理员！', 0);
		}
	}

	public function showFeedBack(){
		tipsNewManage();
		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$pageSize = 15;
		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;

		$aSearchWhere = array(
			'type' => get('type') ?  get('type') : '',
			'is_handled' => get('isHandled'),
			'start_time' => get('starteTime') ?  strtotime(get('starteTime')) : '',
			'end_time' => get('endTime') ?  strtotime(get('endTime')) : ''
		);

		$oService = m('Service');
		$aFeedBackList = array();
		$aFeedBackList = $oService->getFeedbackList($aSearchWhere, $page, $pageSize );
		if($aFeedBackList === false){
			alert('网络可能有点慢',0);
		}
		$countFeedBack = 0;
		$countFeedBack = $oService->getFeedbackCount($aSearchWhere);
		if($countFeedBack === false){
			alert('网络可能有点慢',0);
		}
		if(empty($aFeedBackList)){
			alert('数据为空',0);
		}
		$aFeedBackList = $oService->converUserNameByName($aFeedBackList);
		if(!$aFeedBackList){
			alert('网络可能有点慢',0);
		}
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $countFeedBack,
			'size' => $pageSize,
			'page' => $page,
		);
		$aFromatFeedBackType = array(
			0 => '查看全部',
			1 => '登陆注册相关',
			2 => '充值相关',
			3 => '账户相关',
			4 => '代理商相关',
			5 => '其他问题',
			6 => '和教育教师' ,
			7 => '和教育家长'
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('aFromatFeedBackType', $aFromatFeedBackType);
		assign('aFeedBackList', $aFeedBackList);
		displayHeader();
		display('service/feedback_list.html.php');
		displayFooter();
	}

	public function checkFeedBack(){
		$checkId = get('id');
		$oService = m('Service');
		$aCheckFeedBack = $oService->getFeedbackInfoById($checkId);
		if($aCheckFeedBack === false){
			alert('系统错误', 0);
		}elseif(!$aCheckFeedBack){
			alert('查到不到这条数据', -1);
		}
		if($aCheckFeedBack['is_handled'] == 1){
			$isHandled = 0;
		}else{
			$isHandled = 1;
		}
		$result = $oService->editFeedback(array(
			'id' => $checkId,
			'is_handled' => $isHandled
		));

		if($result === false){
			alert('系统出错', 0);
		}elseif($result){
			alert('状态变更成功', 1);
		}
	}

	public function delFeedBack(){
		$aDelId = get('aId');
		$delFeedBack = m('Service')->deleteFeedbackById($aDelId);
		if($delFeedBack === false){
			alert('系统错误', 0);
		}elseif(!$delFeedBack){
			alert('删除错误，没有找到该条记录', -1);
		}else{
			alert('删除成功', 1);
		}
	}
	public function feedBackSendMessage(){
		$phoneNumber = post('phoneNumber');
		$content = post('content');
		if(!$phoneNumber || !$content){
			alert('缺少参数',0);
		}
		$result = $this->_sendMessage($phoneNumber, $content .'【优满分】');
		if($result){
			alert('短信发成功',1);
		}else{
			alert('短信发送失败',0);
		}

	}
	/**
	 * 短信发送
	 * @param type $mobile
	 * @param type $msgText
	 */
	private function _sendMessage($mobile,$msgText){
		$url = 'http://utf8.sms.webchinese.cn/?Uid=' . SEND_MESSAGE_USER . '&Key=' . SEND_MESSAGE_KEY . '&smsMob=' . $mobile . '&smsText=' . $msgText;
		$returnStatus = 0;
		if(function_exists('file_get_contents')){
			$returnStatus = @file_get_contents($url);
		}else{
			$ch = curl_init();
			$timeout = 5;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$returnStatus = curl_exec($ch);
			curl_close($ch);
		}
		return $returnStatus;

	}
}