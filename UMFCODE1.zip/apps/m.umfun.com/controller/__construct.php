<?php
define('TITLE', 'UmFun后台管理系统');
header("Content-type: text/html; charset=utf-8");
$GLOBALS['VIEW'] = new View(APP_VIEW_PATH);
checkSwitch();

function tipsNewManage(){
	alert('本功能已在m2.umfun.com这个新后台中重建,请移步到新后台进行使用,如无法访问请修改C:\\windows\\system32\\drivers\\etc\\hosts这个文件,加一行以下代码<br/>115.159.25.111 m2.umfun.com<br/>即可访问');
}

/**
 * 检查系统开关
 * @return type
 */
function checkSwitch(){
	$userId = Cookie::getDecrypt('m_userId');
	if(Cookie::getXcrypt('m_rememberPassword') == Xxtea::xCrypt(md5($_SERVER['HTTP_USER_AGENT'] . $userId))){
		//如果是管理员则不进行检查,允许管理员操作后台
		if($userId == 1){
			return;
		}
	}

	if(!$GLOBALS['SYSTEM_SWITCH']['is_open_system_m']){
		alert($GLOBALS['SYSTEM_SWITCH']['m_close_tip'] ? $GLOBALS['SYSTEM_SWITCH']['m_close_tip'] : '抱歉，系统暂时关闭，请稍后再访问', 0);
	}
}

function displayHeader($title = TITLE){
	echo getHeader($title);
}

function getHeader($title = TITLE){
	assign('title', $title);
	return fetch('header.html.php');
}


function displayFooter(){
	echo getFooter();
}

function getFooter(){
	return fetch('footer.html.php');
}

/**
 * 检查用户是否登录及验证用户是否被禁用
 */
function checkLogin(){
	$userId = Cookie::getDecrypt('m_userId');
	if($userId){
		$rememberPassword = Cookie::getXcrypt('m_rememberPassword');
		if($rememberPassword){
			$userAgent = $_SERVER['HTTP_USER_AGENT'];
			if($rememberPassword == Xxtea::xCrypt(md5($userAgent . $userId))){
				$aUserInfo = m('Manager')->getUserInfoByUserId($userId);
				if($aUserInfo){
					if($aUserInfo['is_forbidden'] != 2){
						wrong('抱歉,您已经被禁用,请联系管理员');
					}
					return $userId;
				}
			}
		}
	}

	Cookie::delete('m_userId');
	Cookie::delete('m_rememberPassword');
	$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty($_POST['ajax']) || !empty($_GET['ajax']);

	if(!$isAjax){
		header('Location:/?m=Account&a=showLogin');
		exit;
	}else{
		alert('请重新登录', 2, '?m=Account&a=showLogin');
	}
}

/**
* 检查用户权限
* @param $permissionFlag 权限码
*/
function checkPermission($userId, $permissionFlag){
   $oManager = m('Manager');
   $aUserInfo = $oManager->getUserInfoByUserId((int)$userId);
   if($aUserInfo === false){
	   alert('系统出错，请稍后再试', 0);
   }elseif(!isset($aUserInfo['group_id'])){
	   return false;
   }
   if($aUserInfo['id'] == 1){
	   return true;
   }

   $aGroupInfo = $oManager->getGroupInfoByGroupId($aUserInfo['group_id']);
   if($aGroupInfo === false){
	   alert('系统出错，请稍后再试', 0);
   }
   foreach($GLOBALS['PERMISSION'] as $configPermission){
	   foreach($configPermission['child'] as $key => $value){
		   $permission[] = $key;
	   }
   }
   $permissionArray = array_intersect($aGroupInfo['permission'], $permission);
   if(!in_array($permissionFlag, $permissionArray)){
	   return false;
   }
   return true;
}