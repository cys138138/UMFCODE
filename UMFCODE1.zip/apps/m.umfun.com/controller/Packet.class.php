<?php
/*
 * 牛逼红包活动后台管理控制器
 * 罗启军
 * 455538375@qq.com
 * 如果你不努力尝试，又怎么知道自己就是这个水平呢
 */

use home\lib\Controller;
use manage\model\RedPacketPrize;
use manage\model\RedPacketJoin;
use common\model\Teacher;
use common\model\activity\RedPacketAward;
use manage\model\RedPacketAward as ManageAward;

class PacketController{
	const AUTHORITY = 'manage_packet';
	private $_userId = 0;

	public function __construct(){

		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, self::AUTHORITY)){
			alert('您没有权限对此操作', 0);
		}
	}

	public function abc(){
		$mTeacher = Teacher::findOne(10);
		$oApp = Yii::$app;
		$oApp->teacher->login($mTeacher);
		//$mTeacher->login();

	}

	public function showJoinList(){
		$page = intval(get('page', 1));
		$pageSize = 20;

		$aJoinList = RedPacketJoin::getJoinList($page, $pageSize);
		$aJoinCount = RedPacketJoin::joinUserCount();
		$sendGold = RedPacketJoin::sendGoldCount();
		assign('sendGold', $sendGold);
		assign('aJoinList', $aJoinList);


		$joinCount = 0;
		$studentCount = 0;
		$teacherCount = 0;
		$parentCount = 0;
		if($aJoinCount){
			foreach($aJoinCount as $aJoin){
				if($aJoin['user_type'] == 1){
					$teacherCount += $aJoin['nums'];
				}elseif($aJoin['user_type'] == 2){
					$studentCount += $aJoin['nums'];
				}else{
					$parentCount += $aJoin['nums'];
				}
				$joinCount += $aJoin['nums'];
			}
		}
		assign('studentCount', $studentCount);
		assign('teacherCount', $teacherCount);
		assign('parentCount', $parentCount);


		$url = 'http://' . APP_MANAGE . '/?m=Packet&a=showJoinList';
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $joinCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		display('packet/join.html.php');
	}


	public function showPrizeList(){
		$aPrizeList = RedPacketPrize::getPrizeList();
		assign('aPrizeList', $aPrizeList);
		display('packet/prizes.html.php');
	}

	public function showAwardList(){
		$page = intval(get('page', 1));
		$pageSize = 20;
		$status = intval(get('status', 0));
		$aCondition = ['status' => $status];
		$aAwardList = RedPacketAward::getAwardList($page, $pageSize, $aCondition);
		$awardCount = RedPacketAward::getAwardCount($aCondition);

		assign('aAwardList', $aAwardList);

		$url = 'http://' . APP_MANAGE . '/?m=Packet&a=showAwardList&status=' . $status;
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $awardCount,
			'size' => $pageSize,
			'page' => $page,
		);

		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('status', $status);
		display('packet/award.html.php');
	}

	public function showAddPrize(){
		display('packet/prizes_add.html.php');
	}

	public function addPrize(){
		$name = post('name');
		if(!$name){
			alert('喂喂，给奖品起个名字好吧', -1);
		}
		$imageAddr = post('prize_addr');
		$image = SYSTEM_RESOURCE_PATH . $imageAddr;
		if(!file_exists($image)){
			alert('喂喂大哥，明显还没上传图片好吧', -1);
		}
		$total = intval(post('total'));
		$type = intval(post('type'));
		if($type != 1 && $type != 2 && $type != 3){
			alert('选个奖品类型吧大哥', -1);
		}
		$gold = intval(post('gold'));
		$chance = intval(post('chance'));
		$aData = array(
			'name' => $name,
			'type' => $type,
			'profile' => $imageAddr,
			'total' => $total,
			'gold' => $gold,
			'chance' => $chance,

 		);
		if(RedPacketPrize::add($aData)){
			alert('好吧，有奖品咯，不过建议您先去报销钱', 1);
		}else{
			alert('我去，添加奖品失败了', 0);
		}
	}

	public function showEditPrize(){
		$id = intval(get('id'));
		$mPrize = RedPacketPrize::findOne($id);
		if(!$mPrize){
			alert('奖品不存在', -1);
		}
		$aPrize = $mPrize->toArray(['id', 'type', 'name', 'profile', 'total', 'gold', 'chance']);
		assign('aPrize', $aPrize);
		display('packet/prizes_edit.html.php');
	}

	public function deliver(){
		$id = intval(post('id'));
		$mPrize = ManageAward::findOne($id);
		if(!$mPrize){
			alert('奖品不存在', -1);
		}
		$mPrize->set('status', 2);
		if($mPrize->save()){
			alert('已发货', 1);
		}else{
			alert('我去！发货失败', 0);
		}
	}

	public function setPrize(){
		$id = intval(post('id'));
		$name = post('name');
		if(!$name){
			alert('喂喂，给奖品起个名字好吧', -1);
		}
		$imageAddr = post('prize_addr');
		$image = SYSTEM_RESOURCE_PATH . $imageAddr;
		if(!file_exists($image)){
			alert('喂喂大哥，明显还没上传图片好吧', -1);
		}
		$total = intval(post('total'));
		$type = intval(post('type'));
		if($type != 1 && $type != 2 && $type != 3){
			alert('选个奖品类型吧大哥', -1);
		}
		$gold = intval(post('gold', 0));
		$mPrize =RedPacketPrize::findOne($id);
		if(!$mPrize){
			alert('奖品不存在', -1);
		}
		$chance = intval(post('chance'));
		$mPrize->set('name', $name);
		$mPrize->set('type', $type);
		$mPrize->set('profile', $imageAddr);
		$mPrize->set('total', $total);
		$mPrize->set('gold', $gold);
		$mPrize->set('chance', $chance);
		if($mPrize->save()){
			alert('修改咯', 1);
		}else{
			alert('我去，修改奖品失败了', 0);
		}
	}


	public function uploadProfile(){
		$folder = 'data/packet/';
		$imageAddr = SYSTEM_RESOURCE_PATH . $folder;
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(3072000, 'jpg,png,gif', '', $imageAddr,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败".' . $oUploader->getErrorMsg() . '."', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$aWidthAndHeight = array();
		$aWidthAndHeight = getimagesize($imageAddr . $uploadFileInfo['savename']);
		if(!$aWidthAndHeight){
			alert('文件上传失败', 0);
		}
		$width = intval($aWidthAndHeight[0]);
		$height = intval($aWidthAndHeight[1]);
		if($width > 1920){
			if(file_exists($imageAddr . $uploadFileInfo['savename'])){
				unlink($imageAddr . $uploadFileInfo['savename']);
			}
			alert('图片宽度不能超过1920px', 0);
		}
		alert($folder . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . $folder . $uploadFileInfo['savename']);
	}


}