<?php
if(!in_array(get('a'), array('showChoiceEsForGt4Options', 'showAllSameEs'))){
	$authFile = APP_CACHE_PATH . 'tools_auth.php';
	if(file_exists($authFile)){
		require $authFile;
	}
}

class ToolsController{
	private $_aCategory = array();

	public function __construct(){
		set_time_limit(0);
		assign('title', 'umfun维护工具');
	}

	public function getUserLoginStatics(){
		$startTime = intval(get('startTime', 0));
		$endTime = intval(get('endTime', 0));
		$where = '';
		if($startTime){
			$where = '`login_time`>=' . $startTime;
		}
		if($endTime){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`login_time`<=' . $endTime;
		}
		$oUserLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$aStaticsList = $oUserLoginLog->get('`user_type`,`client_type`,count(distinct(`user_id`)) as nums', $where, '', '', '', '`user_type`,`client_type`');
		$title = '<div style="margin:2px;width:auto; height:35px; line-height:35px;background-color:#DFDFDF;"><div style="float:left; text-align:center; width:100px; border-right:solid 1px #FFF; ">客户端类型</div><div style="float:left; text-align:center; width:100px; border-right:solid 1px #FFF; ">用户类型</div><div style="float:left; text-align:center; width:100px; border-right:solid 1px #FFF; ">登陆人数</div></div>';
		echo $title;
		foreach($aStaticsList as $aStatics){
			$clientType = '未知';
			if($aStatics['client_type'] == 1){
				$clientType = 'PC';
			}elseif($aStatics['client_type'] == 2){
				$clientType = 'APP';
			}
			$userType = '未知';
			if($aStatics['user_type'] == 1){
				$userType = '学生';
			}elseif($aStatics['user_type'] == 2){
				$userType = '家长';
			}elseif($aStatics['user_type'] == 3){
				$userType = '老师';
			}
			echo '<div style="margin:2px;width:auto; height:35px; line-height:35px;background-color:#DFDFDF;"><div style="float:left; text-align:center; width:100px; border-right:solid 1px #FFF; ">' . $clientType . '</div><div style="float:left; text-align:center; width:100px; border-right:solid 1px #FFF; ">' . $userType . '</div><div style="float:left; text-align:center; width:100px; border-right:solid 1px #FFF; ">' . $aStatics['nums'] . '</div></div>';
		}
	}

	public function getTeacherStudentList(){
		$page = get('page', 0);
		if($page < 1){
			die('你妹的志辉，页码都不会写啊？');
		}
		$pageSize = 30;
		$offect = ($page - 1) * $pageSize;
		$oTeacherDayTeacher = new Model(T_TEACHER_DAY_TEACHER);
		$aTeacherList = $oTeacherDayTeacher->get('', '`xin_number`>=1', '`id` ASC', $offect, $pageSize);
		$aTeacherIds = array();
		foreach($aTeacherList as $key => $aTeacher){
			if($aTeacher['xxt_data']){
				$aTeacherList[$key]['xxt_data'] = json_decode($aTeacher['xxt_data'], true);
			}else{
				$aTeacherList[$key]['xxt_data'] = array();
			}
			$aTeacherIds[] = $aTeacher['xxt_teacher_id'];
		}
		//debug($aTeacherList);
		$oTeacherUserRelation = new Model(T_TEACHER_USER_RELATION);
		$aRelationList = $oTeacherUserRelation->get('', '`teacher_id` in (' . implode(',', $aTeacherIds) . ')');
		//debug($aRelationList);
		foreach($aTeacherList as $key => $aTeacher){
			$aTeacherList[$key]['student_list'] = array();
			foreach($aRelationList as $aRelation){
				if($aRelation['teacher_id'] == $aTeacher['xxt_teacher_id']){
					if(isset($aTeacherList[$key]['student_list'][$aRelation['user_id']])){
						continue;
					}else{
						$aTeacherList[$key]['student_list'][$aRelation['user_id']] = $aRelation;
					}
				}
			}
		}

		//debug($aTeacherList);
		foreach($aTeacherList as $aTeacher){
			$title =  '<p><span style="display:block; float:left; width:100px;">' . $aTeacher['xxt_data']['teacher_info']['UserName'] . '</span><span style="display:block; float:left; width:500px;">' . $aTeacher['xxt_data']['school_info']['AreaName'] . ' ' . $aTeacher['xxt_data']['school_info']['TownName'] . ' ' . $aTeacher['xxt_data']['school_info']['SchoolName'] . '</span><span>';
			foreach($aTeacher['student_list'] as $aStudent){
				$title .= $aStudent['user_name'] . ' ';
			}
			$title .= '</span></p>';
			echo $title . '<br /><hr />';
		}
	}

	//和教育转化率
	public function getXxtStatics(){
		$startWeek = get('startWeek', 201433);
		$endWeek = get('endWeek', 201433);
		if($startWeek < 201430){
			$startWeek = 201430;
		}
		$thisWeek = intval(date('Y') . date('W'));
		if(time() > 1419836398){
			$thisWeek = intval(2015 . date('W'));
		}
		if($endWeek > $thisWeek){
			$endWeek = $thisWeek;
		}
		if($startWeek > $endWeek){
			die('你妹的!输入正确的周啊!!!');
		}
		$aXxtCity = array(
			'zs' => array(
				'name'	=>	'中山',
				'num'	=>	0,
			),
			'dg' => array(
				'name'	=>	'东莞',
				'num'	=>	0,
			),
			'zq' => array(
				'name'	=>	'肇庆',
				'num'	=>	0,
			),
			'gz' => array(
				'name'	=>	'广州',
				'num'	=>	0,
			),
			'cs' => array(
				'name'	=>	'测试',
				'num'	=>	0,
			),
			'sz' => array(
				'name'	=>	'深圳',
				'num'	=>	0,
			),
			'fs' => array(
				'name'	=>	'佛山',
				'num'	=>	0,
			),
			'zh' => array(
				'name'	=>	'珠海',
				'num'	=>	0,
			),

			'hz' => array(
				'name'	=>	'惠州',
				'num'	=>	0,
			),
			'jm' => array(
				'name'	=>	'江门',
				'num'	=>	0,
			),
			'sg' => array(
				'name'	=>	'韶关',
				'num'	=>	0,
			),
			'hy' => array(
				'name'	=>	'河源',
				'num'	=>	0,
			),
			'mz' => array(
				'name'	=>	'梅州',
				'num'	=>	0,
			),
			'sw' => array(
				'name'	=>	'汕尾',
				'num'	=>	0,
			),
			'yj' => array(
				'name'	=>	'阳江',
				'num'	=>	0,
			),
			'zj' => array(
				'name'	=>	'湛江',
				'num'	=>	0,
			),

			'mm' => array(
				'name'	=>	'茂名',
				'num'	=>	0,
			),
			'qy' => array(
				'name'	=>	'清远',
				'num'	=>	0,
			),
			'cz' => array(
				'name'	=>	'潮州',
				'num'	=>	0,
			),
			'jy' => array(
				'name'	=>	'揭阳',
				'num'	=>	0,
			),
			'yf' => array(
				'name'	=>	'云浮',
				'num'	=>	0,
			),
			'st' => array(
				'name'	=>	'汕头',
				'num'	=>	0,
			),

			'undefind' => array(
				'name'	=>	'未知地',
				'num'	=>	0,
			),
		);
		$aStaticsList = array();
		for($i = $startWeek; $i <= $endWeek; $i++){
			$aStaticsList[$i] = $aXxtCity;
		}
		$sYear = substr($startWeek, 0, 4);
		$sWeek = substr($startWeek, 4, 2);
		$aTimestamp['start'] = strtotime($sYear.'W'.$sWeek);

		$eYear = substr($endWeek, 0, 4);
		$eWeek = substr($endWeek, 4, 2);
		$endTimestampStart = strtotime($eYear.'W'.$eWeek);
		$aTimestamp['end'] = strtotime('+1 week', $endTimestampStart);
		$oUser = new Model(T_USER);
		$aUserList = $oUser->get('`id`,`create_time`', '`xxt_id`>0 AND `create_time`>=' . $aTimestamp['start'] . ' AND `create_time`<' . $aTimestamp['end']);
		if($aUserList === false){
			die('出错啦啦啦啦啦啦啦！！！！');
		}elseif(!$aUserList){
			return $aStaticsList;
		}
		$aUserIds = array();
		$aUserReferList = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['id'];
			$aUserReferList[$aUser['id']] = $aUser;
		}

		$aCityList = $GLOBALS['XXT_CITY'];
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalList = $oPersonal->get('`id`,`area_id`,`xxt_data`', array('id' => array('in', $aUserIds)));
		foreach($aPersonalList as $aPersonal){
			$week = date('YW', $aUserReferList[$aPersonal['id']]['create_time']);
			if($aPersonal['xxt_data']){
				$aPersonal['xxt_data'] = json_decode($aPersonal['xxt_data'], true);
				if(isset($aStaticsList[$week][$aPersonal['xxt_data']['CityId']])){
					$aStaticsList[$week][$aPersonal['xxt_data']['CityId']]['num'] += 1;
				}else{
					//debug('---------' . $aPersonal['id']);
					$aStaticsList[$week]['undefind']['num'] += 1;
				}
			}else{
				$findFlag = 0;
				foreach($aCityList as $key => $aCity){
					if(in_array($aPersonal['area_id'], $aCity)){
						$aStaticsList[$week][$key]['num'] += 1;
						$findFlag = 1;
						break;
					}
				}
				if(!$findFlag){
					//debug('---------' . $aPersonal['id']);
					$aStaticsList[$week]['undefind']['num'] += 1;
				}
			}
		}
		//debug($aStaticsList);
		$title =  '<p><span style="display:block; float:left; width:60px;">周次</span>';
		foreach($aStaticsList as $week => $aWeekStatics){
			foreach($aWeekStatics as $aAreaStatics){
				$title .= '<span style="display:block; float:left; width:60px;">|' . $aAreaStatics['name'] . '</span>';
			}
			break;
		}
		$title .= '</p>';
		echo $title . '<br />';


		foreach($aStaticsList as $week => $aWeekStatics){
			$row =  '<p><span style="display:block; float:left; width:60px;">' . $week . '</span>';
			foreach($aWeekStatics as $aAreaStatics){
				$row .= '<span style="display:block; float:left; width:60px;">|' . $aAreaStatics['num'] . '</span>';
			}
			$row .= '</p>';
			echo $row . '<br />';
		}

	}


	/**
	 * 显示全部相似的题目
	 * @subject get 科目
	 */
	public function showAllSameEs(){
		$url = '/?m=' . get('m') .'&a=' . get('a');

		//科目ID
		$subject = get('subject', 1);
		assign('subjectId', $subject);

		$oEs = m('Es');
		$categoryId = intval(get('categoryId'));

		if($categoryId){
			$aEsList = $oEs->getEsListByCategoryId($categoryId);
			if($aEsList === false){
				alert('系统错误', 0);
			}

			$aEsTypeList = array();
			foreach($aEsList as $key => $aEsInfo){
				$aSameEsList = $oEs->getSimilarEsListByData($aEsInfo, array(), 100);
				$aMergeEsList = array();
				foreach($aSameEsList as $aSameEs){
					if($aSameEs['status'] == 5){
						$aMergeEsList[] = $aSameEs;
					}
				}

				if(!empty($aMergeEsList)){
					$tmpEsInfo = array_merge($aMergeEsList, array($aEsInfo));
					$aEsTypeList[$aEsInfo['type_id']][] = $tmpEsInfo;
				}

			}

			$aSameEsHtmlList = array(
				1 => '',
				2 => '',
				3 => '',
				4 => '',
				5 => ''
			);
			$aSameEsCount = array(
				1 => 0,
				2 => 0,
				3 => 0,
				4 => 0,
				5 => 0
			);
			foreach($aEsTypeList as $typeId => $aTypeEsList){

				foreach($aTypeEsList as $key => $aEsList){
					$aSameEsHtmlList[$typeId] .= '<li class="row">';
					foreach($aEsList as $k => $aEsInfo){
						$aSameEsHtmlList[$typeId] .= '<div onclick="showDetailEs(' . $aEsInfo['id']  . ');">【ID : ' . $aEsInfo['id']  . '】 <span>' . $aEsInfo['content_text'] . '</span></div>';
						$aSameEsCount[$typeId]++;
					}
					$aSameEsHtmlList[$typeId] .= '</li>';
				}
			}
			assign('aSameEsCount', $aSameEsCount);
			assign('aSameEsHtmlList', $aSameEsHtmlList);
		}

		assign('baseUrl', $url);

		if(get('getData')){
			header("Content-type: application/json");
			alert('数据加载成功', 1, $aEsTypeList);
		}


		displayHeader('相似题目查看');
		display('tools/all_same_es.html.php');
		displayFooter();
	}

	public function getEsinfo(){
		$id = intval(get('id'));
		$aEsDetail = Teacher::getEsDetail($id);
		alert('题目详细', $aEsDetail ? 1 : 0, $aEsDetail);
	}

	public function del(){
		$oDb = new DBOI();
		$aEsList = $oDb->table(T_TEACHER_DAY_STUDENT)->where('id=73540790')->delete();
		echo json_decode($aEsList);
	}


	/*
	 *去除搜索字段里面的图片
	 */
	public function delEsSearchImg(){
		$aEsList = $aError = array();
		$count = 0;

		/*$this->_connectDb();
		$sql = 'select id,content_text from umfun.es where content_text like "% data/es/%" limit 1, 10000';
		//$sql = 'select id,content_text from umfun.es where id=4391';
		$result = mysql_query($sql)or die(mysql_error());
		while($row = mysql_fetch_assoc($result)){
			$aEsList[] = $row;
		}*/

		$oDb = new DBOI();
		$aEsList = $oDb->table(T_ES)->fields('id,content_text')->where('content_text like "% data/es/%"')->limit('1,100')->select();
		if(empty($aEsList)) {
			alert('已经没有数据了', 0);
		}

		foreach($aEsList as $aEsInfo){
			$aEsInfo['content_text'] = preg_replace('/ data\/es(.+?)(jpg|bmp|png|gif)/i', '', $aEsInfo['content_text']);

			/*$upSql = "update umfun.es set content_text='" . addslashes($aEsInfo["content_text"]) . "' where id=" . $aEsInfo["id"] . ";";
			if(mysql_query($upSql)){
				$count++;
				//$aSuccess[] = array(
				//	'id' => $aThisEs['id'],
				//	'content_text' => $aThisEs['content_text']
				//);
			}
			*/

			$upResult = $oDb->table(T_ES)
							->where(array('id' => $aEsInfo["id"]))
							->date(array('content_text' => addslashes($aEsInfo["content_text"])))
							->update();
			if(isset($upResult)){
				$count++;
			}else{
				$aError[] = array(
					'id' => $aEsInfo['id'],
					'content_text' => $aEsInfo['content_text'],
					'sql' => $upSql,
					'dbError' => mysql_error()
				);
			}
		}
		echo '本次替换完成了：' . $count . '条数据<br><br>以下是失败数据:<br>' . json_encode($aError);
	}

	public function showGetSameEs($esId){
		$aEsInfo = m('Es')->getEsInfoByEsId($esId);
		debug($aEsInfo);
		displayHeader();
		display('tools/same_es.html.php');
		displayFooter();
	}

	private function _fetch($sql){
		$queryResult = mysql_query($sql);
		if(!$queryResult){
			return array();
		}
		$aResult = array();
		while($aResult[] = mysql_fetch_assoc($queryResult)){}
		array_pop($aResult);
		return $aResult;
	}

	private function _connectDb(){
		$aDbConfig = $GLOBALS['DB_CONFIG']['MYSQL_SERVER']['mysql_master_1'];
		$link = mysql_connect($aDbConfig['host'], $aDbConfig['username'], $aDbConfig['password'])or die(mysql_error());
		//$link = mysql_connect('192.168.1.186', 'root', '')or die(mysql_error());
		if($link){
			mysql_select_db('test')or die(mysql_error() . '2112');
			mysql_query('set names utf8');
		}
		return $link;
	}

	private function _getSameEs($subjectId){
		$this->_connectDb();
		$aEsList = array();
		$sql = 'select es.* from `es` join es_index as ei on ei.id = es.id where ei.subject_id=' . $subjectId . ' group by  `content_text` having count(`content_text`) > 1';
		$result = mysql_query($sql)or die(mysql_error());

		while($row = mysql_fetch_assoc($result)){
			$aEsList[] = $row;
		}
		return $aEsList;
	}

	/**
	 * 删除账号
	 */
	public function deleteAccount(){
		$userId = (int)post('id');
		if(!getUserInfo($userId)){
			alert('找不到该用户', 0);
		}

		/*
		if($openId){
			$oUser = m('User');
			$aUser = $oUser->getUserInfoByQqOpenId($openId);
			if($aUser === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			if(!$aUser){
				alert('系统找不到QQ账号【'. $openId . '】', 0);
			}
			$userId = $aUser['id'];
		}
		*/

		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result = $oDboi->table(T_USER)->where(array('id' => $userId))->delete();

		if($result){
			$row = $oDboi->table(T_PERSONAL)->where(array('id' => $userId))->delete();
			if(!$row){
				$oDboi->rollBack();
				alert('删除personal信息失败', 0);
			}
			$row = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $userId))->delete();
			if(!$row){
				$oDboi->rollBack();
				alert('删除数据表信息失败', 0);
			}

			$oDboi->table(T_USER_INVITATION)->where(array('id' => $userId))->delete();
			$oDboi->table(T_USER_RELATION)->where('`user_master_id` = ' . $userId . ' or `user_slave_id` = ' . $userId)->delete();
			$oDboi->table(T_SNS_SHUOSHUO)->where('`user_id` = ' . $userId)->delete();
			$oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where('`user_id` = ' . $userId)->delete();
			$oDboi->table(T_MISSION_USER_RELATION_INDEX)->where('`user_id` = ' . $userId)->delete();
			$oDboi->table(T_MATCH_USER_RELATION)->where('`user_id` = ' . $userId)->delete();
		}else{

		}
		alert('删除成功', 1);
	}

	public function getHavePinYinEs(){
		$this->_connectDb();
		$sql = "select es.id,es.content_json,es.content_text,ei.type_id from `es` join es_index as ei on ei.id = es.id where ei.subject_id= 1 and ei.type_id in (4,5) and (binary es.content_text like '%ā%' or binary es.content_text like '%á%' or binary es.content_text like '%ǎ%' or binary es.content_text like '%à%' or binary es.content_text like '%ō%' or binary es.content_text like '%ó%' or binary es.content_text like '%ǒ%' or binary es.content_text like '%ò%' or binary es.content_text like '%ē%' or binary es.content_text like '%é%' or binary es.content_text like '%ě%' or binary es.content_text like '%è%' or binary es.content_text like '%ī%' or binary es.content_text like '%í%' or binary es.content_text like '%ǐ%' or binary es.content_text like '%ì%' or binary es.content_text like '%ū%' or binary es.content_text like '%ú%' or binary es.content_text like '%ǔ%' or binary es.content_text like '%ù%' or binary es.content_text like '%ü%' or binary es.content_text like '%ǖ%' or binary es.content_text like '%ǘ%' or binary es.content_text like '%ǚ%' or binary es.content_text like '%ǜ%')";
		$result = mysql_query($sql)or die(mysql_error());
		$aEsList = array();
		while($row = mysql_fetch_assoc($result)){
			$aEsList[] = $row;
		}
		echo '<div style="padding:10px 50px">';
		echo '<h2 color="red">总数是： '. count($aEsList) . '</h2><br />';
		foreach($aEsList as $key => $aEs){
			echo '<font color="red">' . ($key + 1) . '</font>' . '&nbsp;&nbsp;&nbsp;题目id：' . $aEs['id'];
			echo '<font size="4"><pre>';
			print_r($aEs['content_text']);
			echo '</pre></font>';
			echo '<hr />';
			//debug($tigan);
		}
		echo '</div>';
		//debug($tigan);
		assign('aEsList', $aEsList);
		displayHeader();
		display('tool/pinyin.html.php');
		displayFooter();
	}

	/**
	 * 删除题目
	 */
	public function deleteEs(){
		$esId = post('id');
		if(!($esId >= 1)){
			alert('题目ID非法', 0);
		}
		$oDb = new DBOI();
		$oDb->startTrans();
		$result = $oDb->table(T_ES_INDEX)->where(array('id' => $esId))->delete();
		if($result){
			$row = $oDb->table(T_ES)->where(array('id' => $esId))->delete();
			if(!$row){
				$oDb->rollBack();
				alert('网络可能有点慢', 0);
			}
			$row = $oDb->table(T_ES_LOG)->where('`es_id`=' . $esId)->delete();
			if(!$row){
				$oDb->rollBack();
				alert('网络可能有点慢', 0);
			}
			$oDb->table(T_USER_ES_WRONG)->where('`es_id`=' . $esId)->delete();
			$oDb->table(T_ES_FEEDBACK)->where('`es_id`=' . $esId)->delete();
			alert('成功删除题目', 1);
		}else{
			alert('删除失败', 0);
		}

	}

	/**
	 * 根据目录添加系统关卡
	 */
	public function addAllMission(){
		$oDboi = new DBOI();
		$oEs = m('Es');
		$aRootCate = $oDboi->table(T_ES_CATEGORY)->where('parent_id = 0')->select();
		foreach($aRootCate as $categoryId){
			$i = 1;
			$aTreeList = $oEs->getCategoryTree($categoryId['id']);
			//debug($aTreeList, 11);
			$this->_addMission($aTreeList, $i);
		}
	}

	private function _addMission($aTreeList, &$i){
		$oDboi = new DBOI();
		foreach($aTreeList as $key => $aCate){
			if(isset($aCate['child'])){
				$this->_addMission($aCate['child'], $i);
			}else{
				$aMission = array();
				$aMission['subject_id'] = $aCate['subject_id'];
				$aMission['category_ids'] = $aCate['id'];
				$aMission['task_content'] = json_encode(array('correct_counts' => 20));
				$aMission['challenge_es_count'] = json_encode(array(array('es_type_id' => 0, 'es_count' => 10)));
				$aMission['challenge_limit_duration'] = 15;
				$aMission['challenge_limit_blood'] = 3;
				$aMission['challenge_count'] = 0;
				$aMission['challenge_success_count'] = 0;
				$aMission['orders'] = $i * 10;
				$aMission['recent_record'] = json_encode(array());

				$aMission['name'] = '';
				$aCurrentCate = $oDboi->table(T_ES_CATEGORY)->where(array('id' => $aCate['parent_id']))->select();
				while(!$nianji = $this->_getGrade($aCurrentCate[0]['name'])){
					$aCurrentCate = $oDboi->table(T_ES_CATEGORY)->where(array('id' => $aCurrentCate[0]['parent_id']))->select();
				}
				if($i < 10){
					$index = '00' . $i;
				}
				if($i >= 10 && $i < 100){
					$index = '0' . $i;
				}
				if($i >= 100){
					$index = $i;
				}
				$aMission['name'] .= $nianji . $aCate['subject_id'] . $index . '&nbsp;';
				if($aCate['subject_id'] == 3){
					$aEnParent = $oDboi->table(T_ES_CATEGORY)->where(array('id' => $aCate['parent_id']))->select();
					if($aEnParent){
						$aMission['name'] .= $aEnParent[0]['name'] . '&nbsp;';
					}
				}
				$aMission['name'] .= $aCate['name'];
				if(!$oDboi->table(T_MISSION)->data($aMission)->insert()){
					echo $aCate['name'] . '关卡插入失败 <br/>';
				}
				$i++;
			}
		}
	}

	private function _getGrade($str){
		 if(str_replace('一年', '', $str) != $str){
			return 1;
		 }elseif(str_replace('二年', '', $str) != $str){
			return 2;
		 }elseif(str_replace('三年', '', $str) != $str){
			return 3;
		 }elseif(str_replace('四年', '', $str) != $str){
			return 4;
		 }elseif(str_replace('五年', '', $str) != $str){
			return 5;
		 }elseif(str_replace('六年', '', $str) != $str){
			return 6;
		 }elseif(str_replace('七年', '', $str) != $str){
			return 7;
		 }elseif(str_replace('八年', '', $str) != $str){
			return 8;
		 }elseif(str_replace('九年', '', $str) != $str){
			return 9;
		 }else{
			return false;
		 }
	}

	/**
	 * 禁用少于40题的关卡
	 */
	public function forbidFewEsMission(){
		$oDboi = new DBOI();
		$i = 0;
		foreach($GLOBALS['SUBJECT'] as $subjectKey => $subjectName){
			$aMissionList = $oDboi->table(T_MISSION)->where('subject_id = '. $subjectKey)->select();
			echo '<strong>' . $subjectName . '</strong><br/>';
			foreach($aMissionList as $key => $aMission){
				$aCountEs = $oDboi->fields('count(id) as num')->table(T_ES_INDEX)->where('category_id =' . $aMission['category_ids'] . ' AND status = 5')->select();
				$num = $aCountEs[0]['num'];
				if($num < 40){
					$aCate = $oDboi->table(T_ES_CATEGORY)->where('id =' . $aMission['category_ids'])->select();
					echo '<b>关卡</b>：' . $aMission['id'] . '---' . $aMission['name'] . '&nbsp;&nbsp;&nbsp;' . '<b>目录</b>：' . $aCate[0]['id'] . '---' . $aCate[0]['name'] . '（' . $num . '题）<br/>';
					$i++;
					$oDboi->table(T_MISSION)->where('category_ids =' . $aMission['category_ids'])->data(array('is_forbidden' => 1))->update();
				}
			}
			echo '<br/><br/>';
		}
		echo $i;
	}

	/**
	 * 将非内联公式符号的题目替换成内联公式符号
	 */
	public function searchContentJsonStr(){
		$ids = array();
		$oDboi = new DBOI();

		$selectFields = '`t1`.`id`, `t1`.`content_json`, `es_index`.`type_id`,`t1`.`content_text`';
		$whereCondition = ' `es_index`.subject_id=2 and ((`t1`.`content_json` like "%\\\\\\\\\[%" and `t1`.`content_json` like "%\\\\\\\\\]%") or (`t1`.`content_text` like "%\\\\\\\\\[%" and `t1`.`content_text` like "%\\\\\\\\\]%"))';
		$leftJoinCondition = ' as `es_index` on `es_index`.id=`t1`.id ';
		$aEsList = $oDboi->fields($selectFields)->table(T_ES)->leftjoin(T_ES_INDEX, $leftJoinCondition)->where($whereCondition)->select();

		//debug($result);
		foreach($aEsList as $aEs){
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
			$aNesEsContent = $oEsPlugin->build(json_decode($aEs['content_json'], 1));
			$aNewData = array(
				'content_json' => $aNesEsContent['content_json'],
				'content_text' => $aNesEsContent['content_text'],
			);
			//下面是交替换结果更新到数据库操作
			$rs = $oDboi->table(T_ES)->where(array('id' => $aEs['id']))->data($aNewData)->update();
			if(!$rs){
				$oDboi->rollBack();
				debug($aEs['id'] . '失败了');
			}else{
				$ids[] = $aEs['id'];
			}
		}

		debug($ids, 11);
	}

	public function searchContentJsonStrSqrt(){
		$oDboi = new DBOI();

		$selectFields = '`t1`.`id`, `t1`.`content_json`, `es_index`.`type_id`,`t1`.`content_text`';
		$whereCondition = ' `es_index`.subject_id=2 and `t1`.`content_json` REGEXP "\\sqrt[[:blank:]][0-9a-zA-Z\.]{2,}"';
		$leftJoinCondition = ' as `es_index` on `es_index`.id=`t1`.id ';
		$aEsList = $oDboi->fields($selectFields)->table(T_ES)->leftjoin(T_ES_INDEX, $leftJoinCondition)->where($whereCondition)->select();


		$ids = array();
		foreach($aEsList as $key => $aEs){
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
			$aEsInfo = array(
				'id' => $aEs['id'],
				'es_content' => $oEsPlugin->resolve($aEs['content_json']),
			);
			preg_match_all('/sqrt [^{][\w\.]+/', $aEs['content_json'], $aEsMatch);
			if($aEsMatch[0]){
				//debug($aEsInfo);
				foreach($aEsMatch[0] as $k => $v){
					$replaceStr = '';
					for($i = 0; $i < strlen($v); $i++){
						if($i == 5){
							$replaceStr .= '{';
						}
						$replaceStr .= $v[$i];
					}
					$replaceStr .= '}';
					$aEs['content_text'] = preg_replace('/' . $v . '/', $replaceStr, $aEs['content_text']);
					$aEs['content_json'] = preg_replace('/' . $v . '/', $replaceStr, $aEs['content_json']);
				}

				//下面是交替换结果更新到数据库操作
				$rs = $oDboi->table(T_ES)->where(array('id' => $aEs['id']))->data(array(
					'content_json' => $aEs['content_json'],
					'content_text' => $aEs['content_text'],
				))->update();
				if(!$rs){
					$oDboi->rollBack();
					debug($aEs['id'] . '失败了');
				}else{
					$ids[] = $aEs['id'];
				}
			}
		}

		debug(implode(',', $ids));
	}

	/*扫描与我相关错误动态信息*/
	public function scanPersonalMessageError(){
		//用户个人消息表配置
		$aPesonalType = array(
			'ait'	=>	1,
			'comment_ait' =>100,
			'retransmission'	=>	2,
			'comment'	=>	3,
			'reply_comment'	=>	4,
			'public_message'	=>	8,
			'reply_public_message'	=>	9,
			'match_result' =>  20,
			'sponsor_pk' =>  30,
			'refuse_pk' =>  31,
			'pk_result' =>  32,
		);
		//用户个人消息表配置
		$aPesonalTypeInfo = array(
			1 => '1-在说说中@了我',
			100 => '100-在评论中@了我',
			2 => '2-转发了我的说说',
			3 => '3-评论我的说说',
			4 => '4-回复了我的评论',
			8 => '8-给我留言',
			9 => '9-回复我的留言',
			20 => '20-我的比赛结果',
			30 => '30-向我发起一场Pk',
			31 => '31-拒绝了我的pk筹码',
			32 => '32-pk结果信息',
		);
		$page = get('page', 1);
		$pageSize = get('pageSize', 60);
		$userId = get('user');
		$offect = ($page-1) * $pageSize;
		$aResult = array();
		$oDboi = new DBOI();
		$where = '';
		if($userId){
			$where .= 'user_id='.$userId;
		}
		if($pageSize == 0){
			$aPersonalMessageList = $oDboi->table(T_PERSONAL_MESSAGE)->where($where)->orderby('id DESC')->select();
		}else{
			$aPersonalMessageList = $oDboi->table(T_PERSONAL_MESSAGE)->where($where)->orderby('id DESC')->limit($offect,$pageSize)->select();
		}

		//与我相关
		foreach($aPersonalMessageList as $key => $aPersonalMessage){
			//用户不存在
			$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aPersonalMessage['user_id']))->select();
			if(!$aUser){
				$aPersonalMessageList[$key]['error_info'] = '此动态用户不存在';
				$aPersonalMessageList[$key]['table_name'] = 'personal_message';
				$aPersonalMessageList[$key]['type'] = isset($aPesonalTypeInfo[$aPersonalMessage['type']])?$aPesonalTypeInfo[$aPersonalMessage['type']]:$aPersonalMessage['type'];
				$aResult[] = $aPersonalMessageList[$key];
				continue;
			}
			//说说数据
			if($aPersonalMessage['type'] == $aPesonalType['ait'] || $aPersonalMessage['type'] == $aPesonalType['retransmission']){
				$aShuoshuoList = $oDboi->table(T_SNS_SHUOSHUO)->where('id ='.$aPersonalMessage['data_id'].' AND (source_type=0 or source_type=1)')->select();
				if(!$aShuoshuoList){
					$aPersonalMessageList[$key]['error_info'] = '此说说信息不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
					$aResult[] = $aPersonalMessageList[$key];
					continue;
				}
				$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoList[0]['user_id']))->select();
				if(!$aUser){
					$aPersonalMessageList[$key]['error_info'] = '此说说用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
					$aResult[] = $aPersonalMessageList[$key];
				}
				/* //转发的源信息不存在
				if($aShuoshuoList[0]['source_id']){
					$aSourceShuoshuo = $oDboi->table(T_SNS_SHUOSHUO)->where('id ='.$aShuoshuoList[0]['source_id'].' AND source_type=0')->select();
					if(!$aSourceShuoshuo){
						$aPersonalMessageList[$key]['error_info'] = '此转发说说源信息不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				} */
				//评论信息
				$aShuoshuoCommentList = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where('shuoshuo_id ='.$aShuoshuoList[0]['id'])->select();
				if(!$aShuoshuoCommentList){
					continue;
				}

				//没有父评论信息
				if($aShuoshuoCommentList[0]['parent_id']){
					$aComment = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where(array('id'=>$aShuoshuoCommentList[0]['parent_id']))->select();
					if(!$aComment){
						$aPersonalMessageList[$key]['error_info'] = '此说说父评论信息不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}
				//发布评论或回复评论的用户不存在
				if($aShuoshuoCommentList[0]['user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoCommentList[0]['user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '发布评论或回复评论的用户不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '发布评论或回复评论的用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aShuoshuoCommentList[0]['user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}
				//接收评论或接收回复的用户不存在
				if($aShuoshuoCommentList[0]['replyed_user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoCommentList[0]['replyed_user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '接收评论或接收回复的用户不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '接收评论或接收回复的用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aShuoshuoCommentList[0]['replyed_user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}

			//评论数据
			}elseif($aPersonalMessage['type'] == $aPesonalType['comment_ait'] || $aPersonalMessage['type'] == $aPesonalType['comment'] || $aPersonalMessage['type'] == $aPesonalType['reply_comment']){
				//评论信息
				$aShuoshuoCommentList = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where('id ='.$aPersonalMessage['data_id'])->select();
				if(!$aShuoshuoCommentList){
					$aPersonalMessageList[$key]['error_info'] = '此说说评论信息或回复信息不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
					$aResult[] = $aPersonalMessageList[$key];
					continue;
				}
				//没有父评论信息
				if($aShuoshuoCommentList[0]['parent_id']){
					$aComment = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where(array('id'=>$aShuoshuoCommentList[0]['parent_id']))->select();
					if(!$aComment){
						$aPersonalMessageList[$key]['error_info'] = '此说说父评论信息不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}
				//发布评论或回复评论的用户不存在
				if($aShuoshuoCommentList[0]['user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoCommentList[0]['user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '发布评论或回复评论的用户不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '发布评论或回复评论的用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aShuoshuoCommentList[0]['user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}
				//接收评论或接收回复的用户不存在
				if($aShuoshuoCommentList[0]['replyed_user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoCommentList[0]['replyed_user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '接收评论或接收回复的用户不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '接收评论或接收回复的用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_shuoshuo_comment';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aShuoshuoCommentList[0]['replyed_user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}

			//留言数据
			}elseif($aPersonalMessage['type'] == $aPesonalType['public_message'] || $aPersonalMessage['type'] == $aPesonalType['reply_public_message']){
				$aPublicMessageList = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->where(array('id'=>$aPersonalMessage['data_id']))->select();
				if(!$aPublicMessageList){
					$aPersonalMessageList[$key]['error_info'] = '不存在此留言数据';
					$aPersonalMessageList[$key]['table_name'] = 'sns_public_message';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
					$aResult[] = $aPersonalMessageList[$key];
					continue;
				}
				//回复评论信息不存在
				if($aPublicMessageList[0]['parent_id']){
					$aReply = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->where(array('id'=>$aPublicMessageList[0]['parent_id']))->select();
					if(!$aReply){
						$aPersonalMessageList[$key]['error_info'] = '不存在此留言评论的回复数据';
						$aPersonalMessageList[$key]['table_name'] = 'sns_public_message';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}
				//接收用户不存在
				if($aPublicMessageList[0]['user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aPublicMessageList[0]['user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '接收留言或评论留言的用户不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_public_message';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '接收留言或评论留言的用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_public_message';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aPublicMessageList[0]['user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}
				//发送用户不存在
				if($aPublicMessageList[0]['sender_user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aPublicMessageList[0]['sender_user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '发送留言或回复留言的用户不存在';
						$aPersonalMessageList[$key]['table_name'] = 'sns_public_message';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '发送留言或回复留言的用户不存在';
					$aPersonalMessageList[$key]['table_name'] = 'sns_public_message';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aPublicMessageList[0]['sender_user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}

			//比赛结果数据
			}elseif($aPersonalMessage['type'] == $aPesonalType['match_result']){
				$aMatchUserRelationList = $oDboi->table(T_MATCH_USER_RELATION)->where(array('id' => $aPersonalMessage['data_id']))->select();
				if(!$aMatchUserRelationList){
					$aPersonalMessageList[$key]['error_info'] = '不存在此场用户的比赛信息';
					$aPersonalMessageList[$key]['table_name'] = 'match_user_relation';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
					$aResult[] = $aPersonalMessageList[$key];
					continue;
				}
				//参加比赛的用户信息不存在
				if($aMatchUserRelationList[0]['user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aMatchUserRelationList[0]['user_id']))->select();
					if(!$aUser){
						$aPersonalMessageList[$key]['error_info'] = '参加比赛的用户信息不存在';
						$aPersonalMessageList[$key]['table_name'] = 'match_user_relation';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
					}
				}else{
					$aPersonalMessageList[$key]['error_info'] = '参加比赛的用户信息不存在';
					$aPersonalMessageList[$key]['table_name'] = 'match_user_relation';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']].'用户id为'.$aMatchUserRelationList[0]['user_id'];
					$aResult[] = $aPersonalMessageList[$key];
				}
				//用户参加的比赛不存在
				if($aMatchUserRelationList[0]['match_id']){
					$aMatchList= $oDboi->table(T_MATCH)->where(array('id' =>$aMatchUserRelationList[0]['match_id']))->select();
					//debug($aMatchList);
					if(!$aMatchList){
						$aPersonalMessageList[$key]['error_info'] = '用户参加的比赛不存在';
						$aPersonalMessageList[$key]['table_name'] = 'match';
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
						continue;
					}
				}
				//此比赛的题目目录为空
				if(!$aMatchList[0]['es_category_ids']){
						$aPersonalMessageList[$key]['error_info'] = '此比赛的题目目录为空(此时data_id为比赛id)';
						$aPersonalMessageList[$key]['table_name'] = 'match';
						$aPersonalMessageList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aResult[] = $aPersonalMessageList[$key];
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
				}
				//此比赛的题目设置为空
				if(!$aMatchList[0]['es_set']){
						$aPersonalMessageList[$key]['error_info'] = '此比赛的题目目录为空(此时data_id为比赛id)';
						$aPersonalMessageList[$key]['table_name'] = 'match';
						$aPersonalMessageList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
				}
				//此比赛的挑战题目为空
				if(!$aMatchList[0]['es_rule']){
						$aPersonalMessageList[$key]['error_info'] = '此比赛的挑战题目为空(此时data_id为比赛id)';
						$aPersonalMessageList[$key]['table_name'] = 'match';
						$aPersonalMessageList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
				}
				//此比赛没有奖项信息
				if(!json_decode($aMatchList[0]['awards'],true)){
						$aPersonalMessageList[$key]['error_info'] = '此比赛没有奖项信息(此时data_id为比赛id)';
						$aPersonalMessageList[$key]['table_name'] = 'match';
						$aPersonalMessageList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
				}
				//此比赛没有获奖人信息信息
				if(!json_decode($aMatchList[0]['winners'],true)){
						$aPersonalMessageList[$key]['error_info'] = '此比赛没有获奖人信息信息(此时data_id为比赛id)';
						$aPersonalMessageList[$key]['table_name'] = 'match';
						$aPersonalMessageList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
						$aResult[] = $aPersonalMessageList[$key];
				}

			//pk数据
			}elseif($aPersonalMessage['type'] == $aPesonalType['sponsor_pk'] || $aPersonalMessage['type'] == $aPesonalType['refuse_pk'] || $aPersonalMessage['type'] == $aPesonalType['pk_result']){
				$aPkList = $oDboi->table(T_PK_INDEX)->where(array('id' => $aPersonalMessage['data_id']))->select();
				if(!$aPkList){
					$aPersonalMessageList[$key]['error_info'] = '不存在此场pk';
					$aPersonalMessageList[$key]['table_name'] = 'pk_index';
					$aPersonalMessageList[$key]['type'] = $aPesonalTypeInfo[$aPersonalMessage['type']];
					$aResult[] = $aPersonalMessageList[$key];
				}

			}else{
				if($aPersonalMessage['type'] == 10 || $aPersonalMessage['type'] == 33){
					continue;
				}
				//没有此类型
				$aPersonalMessageList[$key]['error_info'] = '没有此类型的动态数据';
				$aPersonalMessageList[$key]['table_name'] = 'personal_message';
				$aResult[] = $aPersonalMessageList[$key];
			}
		}
		//debug($aResult,11);
		assign('aResult', $aResult);
		display('tools/scan_personal_message.html.php');
	}

	public function deletePersonalMessageError(){
		if(isset($_POST['sub'])){
			$aIds = post('checkbox',0);
			if(!$aIds){
				alert('你还没选中选项，请选择你要删除的数据！！！',0);
			}else{
				if(count($aIds) == 1){
					if($aIds[0] != 'on'){
						$where = array('id'=>$aIds[0]);
					}else{
						alert('你还没选中选项，请选择你要删除的数据！！！',0);
					}
				}else{
					array_splice($aIds,0,1);
					$where = array('id'=>array('in',$aIds));
				}
			}
		}else{
			$id = get('id');
			if(!$id){
				alert('没有你要删除的数据',0);
			}else{
				$where = array('id'=>$id);
			}
		}
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$deleteResult = $oPersonalMessage->delete($where);
		if($deleteResult){
			alert('已成功删除数据');
		}else{
			alert('删除数据失败',0);
		}
	}

	/*扫描好友动态错误动态信息*/
	public function scanSnsEventError(){
		//用户动态表配置
		$aSnsEvent = array(
			'publish_shuoshuo'	=>	1,	//发表说说
			'become_friends'	=>	3,	//成为好友
			'pass_mission'	=>	6,	//过关
			'finish_task'	=>	7,	//完成修炼
			'break_self_record' => 90, //破自己的记录
			'break_world_record' => 91, //破世界记录
			'medal_process'	=>	8,	//勋章升级及获得
			'registration_match'	=>	9,	//报名参赛
			'finish_match'	=>	11,	//完成比赛
			'join_match_again'	=>	17,	//再次参赛
			'win_match'	=>	12,	//比赛中获奖
			'pk_result'	=>	16,	//分享PK结果
			'match_result' => 80, //分享比赛结果
		);

		$aSnsEventInfo = array(
			1 => 	'1-发表说说或转发说说',
			3 => 	'3-成为好友',
			6 => 	'6-过关',
			7 => 	'7-完成修炼',
			90 =>  '90-破自己的记录',
			91 =>  '91-破世界记录',
			8 => 	'8-勋章升级及获得',
			9 => 	'9-报名参赛',
			11 => 	'11-完成比赛',
			17 => 	'17-再次参赛',
			12 => 	'12-比赛中获奖',
			16 => 	'16-分享PK结果',
			80 =>  '80-分享比赛结果',
		);

		$page = get('page', 1);
		$pageSize = get('pageSize', 60);
		$offect = ($page-1) * $pageSize;
		$userId = get('user');
		$aResult = array();
		$oDboi = new DBOI();
		$where = '';
		if($userId){
			$where .= 'user_id='.$userId;
		}
		if($pageSize == 0){
			$aEventList = $oDboi->table(T_SNS_EVENT)->where($where)->orderby('id DESC')->select();
		}else{
			$aEventList = $oDboi->table(T_SNS_EVENT)->where($where)->orderby('id DESC')->limit($offect,$pageSize)->select();
		}

		//好友动态
		foreach($aEventList as $key => $aEvent){
			//用户不存在
			$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aEvent['user_id']))->select();
			if(!$aUser){
				$aEventList[$key]['error_info'] = '此动态用户不存在';
				$aEventList[$key]['table_name'] = 'sns_event';
				$aEventList[$key]['type'] = isset($aSnsEventInfo[$aEvent['type']])?$aSnsEventInfo[$aEvent['type']]:$aEvent['type'];
				$aResult[] = $aEventList[$key];
				continue;
			}

			//说说数据（包括分享数据）
			if($aEvent['type'] == $aSnsEvent['publish_shuoshuo'] || $aEvent['type'] == $aSnsEvent['pk_result'] || $aEvent['type'] == $aSnsEvent['match_result']){
				$aShuoshuoList = $oDboi->table(T_SNS_SHUOSHUO)->where(array('id'=>$aEvent['data_id']))->select();
				if(!$aShuoshuoList){
					$aEventList[$key]['error_info'] = '此说说信息不存在';
					$aEventList[$key]['table_name'] = 'sns_shuoshuo';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					continue;
				}
				$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoList[0]['user_id']))->select();
				if(!$aUser){
					$aEventList[$key]['error_info'] = '此说说用户不存在';
					$aEventList[$key]['table_name'] = 'sns_shuoshuo';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
				}
				/* //转发说说的源信息不存在
				if($aShuoshuoList[0]['source_id'] && $aShuoshuoList[0]['source_type'] == 0){
					$aSourceShuoshuo = $oDboi->table(T_SNS_SHUOSHUO)->where('id ='.$aShuoshuoList[0]['source_id'].' AND source_type=0')->select();
					if(!$aSourceShuoshuo){
						$aEventList[$key]['error_info'] = '此转发说说源信息不存在';
						$aEventList[$key]['table_name'] = 'sns_shuoshuo';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}
				} */
				//分享pk的源信息不存在
				if($aShuoshuoList[0]['source_id']  && $aShuoshuoList[0]['source_type'] == 2){
					$aSourcePk = $oDboi->table(T_PK_INDEX)->where('id ='.$aShuoshuoList[0]['source_id'])->select();
					if(!$aSourcePk){
						$aEventList[$key]['error_info'] = '分享pk的源信息不存在';
						$aEventList[$key]['table_name'] = 'pk_index';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}
				}

				//分享比赛的源信息不存在,若存在分析比赛信息
				if($aShuoshuoList[0]['source_id']  && $aShuoshuoList[0]['source_type'] == 3){
					$aSourceMatch = $oDboi->table(T_MATCH_USER_RELATION)->where('id ='.$aShuoshuoList[0]['source_id'])->select();
					if(!$aSourceMatch){
						$aEventList[$key]['error_info'] = '分享比赛的源信息不存在';
						$aEventList[$key]['table_name'] = 'match_user_relation';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}else{
						//参加比赛的用户信息不存在
						if($aSourceMatch[0]['user_id']){
							$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aSourceMatch[0]['user_id']))->select();
							if(!$aUser){
								$aEventList[$key]['error_info'] = '参加比赛的用户信息不存在';
								$aEventList[$key]['table_name'] = 'match_user_relation';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}
						}else{
							$aEventList[$key]['error_info'] = '参加比赛的用户信息不存在';
							$aEventList[$key]['table_name'] = 'match_user_relation';
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']].'用户id为'.$aSourceMatch[0]['user_id'];
							$aResult[] = $aEventList[$key];
						}
						//用户参加的比赛不存在
						if($aSourceMatch[0]['match_id']){
							$aMatchList= $oDboi->table(T_MATCH)->where(array('id' =>$aSourceMatch[0]['match_id']))->select();
							if(!$aMatchList){
								$aEventList[$key]['error_info'] = '用户参加的比赛不存在';
								$aEventList[$key]['table_name'] = 'match';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
								continue;
							}
						}
						//此比赛的题目目录为空
						if(!$aMatchList[0]['es_category_ids']){
								$aEventList[$key]['error_info'] = '此比赛的题目目录为空(此时data_id为比赛id)';
								$aEventList[$key]['table_name'] = 'match';
								$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
						}
						//此比赛的题目设置为空
						if(!$aMatchList[0]['es_set']){
								$aEventList[$key]['error_info'] = '此比赛的题目目录为空(此时data_id为比赛id)';
								$aEventList[$key]['table_name'] = 'match';
								$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
						}
						//此比赛的挑战题目为空
						if(!$aMatchList[0]['es_rule']){
								$aEventList[$key]['error_info'] = '此比赛的挑战题目为空(此时data_id为比赛id)';
								$aEventList[$key]['table_name'] = 'match';
								$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
						}
						//此比赛没有奖项信息
						if(!json_decode($aMatchList[0]['awards'],true)){
								$aEventList[$key]['error_info'] = '此比赛没有奖项信息(此时data_id为比赛id)';
								$aEventList[$key]['table_name'] = 'match';
								$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
						}
						//此比赛没有获奖人信息信息
						if(!json_decode($aMatchList[0]['winners'],true)){
								$aEventList[$key]['error_info'] = '此比赛没有获奖人信息信息(此时data_id为比赛id)';
								$aEventList[$key]['table_name'] = 'match';
								$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
						}
					}
				}

				//评论信息
				$aShuoshuoCommentList = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where('shuoshuo_id ='.$aShuoshuoList[0]['id'])->select();
				if(!$aShuoshuoCommentList){
					continue;
				}

				foreach($aShuoshuoCommentList as $aShuoshuoComment){
					//没有父评论信息
					if($aShuoshuoComment['parent_id']){
						$aComment = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where(array('id'=>$aShuoshuoComment['parent_id']))->select();
						if(!$aComment){
							$aEventList[$key]['error_info'] = '此说说父评论信息不存在';
							$aEventList[$key]['table_name'] = 'sns_shuoshuo_comment';
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
						}
					}
					//发布评论或回复评论的用户不存在
					if($aShuoshuoComment['user_id']){
						$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoComment['user_id']))->select();
						if(!$aUser){
							$aEventList[$key]['error_info'] = '发布评论或回复评论的用户不存在';
							$aEventList[$key]['table_name'] = 'sns_shuoshuo_comment';
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
						}
					}else{
						$aEventList[$key]['error_info'] = '发布评论或回复评论的用户不存在';
						$aEventList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']].'用户id为'.$aShuoshuoComment['user_id'];
						$aResult[] = $aEventList[$key];
					}

					//接收评论或接收回复的用户不存在
					if($aShuoshuoComment['replyed_user_id']){
						$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aShuoshuoComment['replyed_user_id']))->select();
						if(!$aUser){
							$aEventList[$key]['error_info'] = '接收评论或接收回复的用户不存在';
							$aEventList[$key]['table_name'] = 'sns_shuoshuo_comment';
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
						}
					}else{
						$aEventList[$key]['error_info'] = '接收评论或接收回复的用户不存在';
						$aEventList[$key]['table_name'] = 'sns_shuoshuo_comment';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']].'用户id为'.$aShuoshuoComment['replyed_user_id'];
						$aResult[] = $aEventList[$key];
					}
				}

			//成为好友数据
			}elseif($aEvent['type'] == $aSnsEvent['become_friends']){

				$where = '(`user_master_id` =' . $aEvent['user_id'] . ' OR `user_slave_id` =' . $aEvent['user_id'] . ')' . ' AND `is_handed`>0';
				$aBecomeFriendsList = $oDboi->table(T_USER_RELATION)->where($where)->orderby('`is_handed` desc')->select();
				if(!$aBecomeFriendsList){
					$aEventList[$key]['error_info'] = '此用户没有成为好友的信息';
					$aEventList[$key]['table_name'] = 'user_relation';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					continue;
				}
				//好友用户不存在
				foreach($aBecomeFriendsList as $aBecomeFriends){
					if($aEvent['user_id'] != $aBecomeFriends['user_master_id']){
						$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aBecomeFriends['user_master_id']))->select();
						if(!$aUser){
							$aEventList[$key]['error_info'] = '此好友用户不存在(此时data_id为不存在的user_id)';
							$aEventList[$key]['table_name'] = 'user_relation';
							$aEventList[$key]['data_id'] = $aBecomeFriends['user_master_id'];
							$aEventList[$key]['user_relation_id'] = $aBecomeFriends['id'];
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
						}
					}elseif(!$aBecomeFriends['user_master_id']){
						$aEventList[$key]['error_info'] = '此好友用户不存在(此时data_id为不存在的user_id)';
						$aEventList[$key]['table_name'] = 'user_relation';
						$aEventList[$key]['data_id'] = $aBecomeFriends['user_master_id'];
						$aEventList[$key]['user_relation_id'] = $aBecomeFriends['id'];
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}
					if($aEvent['user_id'] != $aBecomeFriends['user_slave_id']){
						$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aBecomeFriends['user_slave_id']))->select();
						if(!$aUser){
							$aEventList[$key]['error_info'] = '此好友用户不存在(此时data_id为不存在的user_id)';
							$aEventList[$key]['table_name'] = 'user_relation';
							$aEventList[$key]['data_id'] = $aBecomeFriends['user_slave_id'];
							$aEventList[$key]['user_relation_id'] = $aBecomeFriends['id'];
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
						}
					}elseif(!$aBecomeFriends['user_slave_id']){
						$aEventList[$key]['error_info'] = '此好友用户不存在(此时data_id为不存在的user_id)';
						$aEventList[$key]['table_name'] = 'user_relation';
						$aEventList[$key]['data_id'] = $aBecomeFriends['user_slave_id'];
						$aEventList[$key]['user_relation_id'] = $aBecomeFriends['id'];
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}
				}
			//关卡数据
			}elseif($aEvent['type'] == $aSnsEvent['pass_mission'] || $aEvent['type'] == $aSnsEvent['finish_task']){
				$aUserMissionList = $oDboi->table(T_MISSION_USER_RELATION_INDEX)->where(array('id' => $aEvent['data_id']))->select();
				if(!$aUserMissionList){
					$aEventList[$key]['error_info'] = '此用户的关卡数据不存在';
					$aEventList[$key]['table_name'] = 'mission_user_relation_index';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					continue;
				}
				//关卡不存在
				$aMissionList = $oDboi->table(T_MISSION)->where(array('id' => $aUserMissionList[0]['mission_id']))->select();
				if(!$aMissionList){
					$aEventList[$key]['error_info'] = '此关卡不存在';
					$aEventList[$key]['table_name'] = 'mission';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
				}

			//破记录数据
			}elseif($aEvent['type'] == $aSnsEvent['break_self_record'] || $aEvent['type'] == $aSnsEvent['break_world_record']){
				$aUserMissionList = $oDboi->table(T_MISSION_USER_RELATION_INDEX)->where(array('id' => $aEvent['data_id']))->select();
				if(!$aUserMissionList){
					$aEventList[$key]['error_info'] = '此用户的关卡数据不存在';
					$aEventList[$key]['table_name'] = 'mission_user_relation_index';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					continue;
				}
				//关卡不存在
				$aMissionList = $oDboi->table(T_MISSION)->where(array('id' => $aUserMissionList[0]['mission_id']))->select();
				if(!$aMissionList){
					$aEventList[$key]['error_info'] = '此关卡不存在';
					$aEventList[$key]['table_name'] = 'mission';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
				}

				//破纪录数据为空
				$aMission = $oDboi->table(T_MISSION_USER_RELATION)->where(array('id' => $aUserMissionList[0]['id']))->select();
				if(!$aMission){
					$aEventList[$key]['error_info'] = '此用户破记录信息不存在';
					$aEventList[$key]['table_name'] = 'mission_user_relation';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
				}else{
					$aBreakRecord = json_decode($aMission[0]['break_record'],true);
					if(!$aBreakRecord){
						$aEventList[$key]['error_info'] = '此用户破记录的break_record记录信息为空';
						$aEventList[$key]['table_name'] = 'mission_user_relation';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}
				}

			//勋章升级数据
			}elseif($aEvent['type'] == $aSnsEvent['medal_process']){
				$aMedalList = $oDboi->table(T_MEDAL)->where('id='.$aEvent['user_id'])->select();
				//此用户没有对应的勋章升级数据
				if(!$aMedalList){
					$aEventList[$key]['error_info'] = '此用户没有对应的勋章升级数据';
					$aEventList[$key]['table_name'] = 'medal';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					continue;
				}
				//此用户对应的勋章升级数据为空
				if(!$aMedalList[0]['medal_process']){
					$aEventList[$key]['error_info'] = '此用户对应的勋章升级数据为空';
					$aEventList[$key]['table_name'] = 'medal';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					break;
				}
				$aMedalList[0]['medal_process'] = json_decode($aMedalList[0]['medal_process'],true);
				$aTempData = array();
				$aTempData['medal_type'] = substr($aEvent['data_id'], 0, 1);
				$aTempData['index'] = substr($aEvent['data_id'], 1);
				if($aTempData['medal_type'] == 1){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['challenge_times'])){
								$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['challenge_times']){
								$isHave = 0;
								foreach($aMedal['medal_process']['challenge_times'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 2){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['passed_missions'])){
								$aEventList[$key]['error_info'] = '此用户对应的passed_missions勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['passed_missions']){
								$isHave = 0;
								foreach($aMedal['medal_process']['passed_missions'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 3){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['excellent_missions'])){
								$aEventList[$key]['error_info'] = '此用户对应的excellent_missions勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['excellent_missions']){
								$isHave = 0;
								foreach($aMedal['medal_process']['excellent_missions'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 4){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['perfect_missions'])){
								$aEventList[$key]['error_info'] = '此用户对应的perfect_missions勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['perfect_missions']){
								$isHave = 0;
								foreach($aMedal['medal_process']['perfect_missions'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 5){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['pk_times'])){
								$aEventList[$key]['error_info'] = '此用户对应的pk_times勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['pk_times']){
								$isHave = 0;
								foreach($aMedal['medal_process']['pk_times'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 6){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['pk_win_times'])){
								$aEventList[$key]['error_info'] = '此用户对应的pk_win_times勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['pk_win_times']){
								$isHave = 0;
								foreach($aMedal['medal_process']['pk_win_times'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 7){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['match_times'])){
								$aEventList[$key]['error_info'] = '此用户对应的match_times勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['match_times']){
								$isHave = 0;
								foreach($aMedal['medal_process']['match_times'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 8){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['match_win_times'])){
								$aEventList[$key]['error_info'] = '此用户对应的match_win_times勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['match_win_times']){
								$isHave = 0;
								foreach($aMedal['medal_process']['match_win_times'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 9){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							if(!isset($aMedal['medal_process']['comment_support_times'])){
								$aEventList[$key]['error_info'] = '此用户对应的comment_support_times勋章记录不存在';
								$aEventList[$key]['table_name'] = 'medal';
								$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
								$aResult[] = $aEventList[$key];
							}elseif($aMedal['medal_process']['comment_support_times']){
								$isHave = 0;
								foreach($aMedal['medal_process']['comment_support_times'] as $key2=>$challengeTimes){
									if($aTempData['index'] == $key2){
										$isHave = 1;
									}
								}
								if(!$isHave){
									$aEventList[$key]['error_info'] = '此用户对应的challenge_times勋章与动态记录不相对应！';
									$aEventList[$key]['table_name'] = 'medal';
									$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
									$aResult[] = $aEventList[$key];
								}
							}
							break;
						}
					}
				}

			//比赛数据
			}elseif($aEvent['type'] == $aSnsEvent['registration_match'] || $aEvent['type'] == $aSnsEvent['finish_match'] || $aEvent['type'] == $aSnsEvent['join_match_again'] || $aEvent['type'] == $aSnsEvent['win_match']){
				$aMatchUserRelationList = $oDboi->table(T_MATCH_USER_RELATION)->where(array('id' => $aEvent['data_id']))->select();
				if(!$aMatchUserRelationList){
					$aEventList[$key]['error_info'] = '不存在此场用户的比赛信息';
					$aEventList[$key]['table_name'] = 'match_user_relation';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
					$aResult[] = $aEventList[$key];
					continue;
				}
				//参加比赛的用户信息不存在
				if($aMatchUserRelationList[0]['user_id']){
					$aUser = $oDboi->table(T_PERSONAL)->where(array('id'=>$aMatchUserRelationList[0]['user_id']))->select();
					if(!$aUser){
						$aEventList[$key]['error_info'] = '参加比赛的用户信息不存在';
						$aEventList[$key]['table_name'] = 'match_user_relation';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
					}
				}else{
					$aEventList[$key]['error_info'] = '参加比赛的用户信息不存在';
					$aEventList[$key]['table_name'] = 'match_user_relation';
					$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']].'用户id为'.$aMatchUserRelationList[0]['user_id'];
					$aResult[] = $aEventList[$key];
				}
				//用户参加的比赛不存在
				if($aMatchUserRelationList[0]['match_id']){
					$aMatchList= $oDboi->table(T_MATCH)->where(array('id' =>$aMatchUserRelationList[0]['match_id']))->select();
					if(!$aMatchList){
						$aEventList[$key]['error_info'] = '用户参加的比赛不存在';
						$aEventList[$key]['table_name'] = 'match';
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
						continue;
					}
				}
				//此比赛的题目目录为空
				if(!$aMatchList[0]['es_category_ids']){
						$aEventList[$key]['error_info'] = '此比赛的题目目录为空(此时data_id为比赛id)';
						$aEventList[$key]['table_name'] = 'match';
						$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
				}
				//此比赛的题目设置为空
				if(!$aMatchList[0]['es_set']){
						$aEventList[$key]['error_info'] = '此比赛的题目目录为空(此时data_id为比赛id)';
						$aEventList[$key]['table_name'] = 'match';
						$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
				}
				//此比赛的挑战题目为空
				if(!$aMatchList[0]['es_rule']){
						$aEventList[$key]['error_info'] = '此比赛的挑战题目为空(此时data_id为比赛id)';
						$aEventList[$key]['table_name'] = 'match';
						$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
						$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
						$aResult[] = $aEventList[$key];
				}
				if($aEvent['type'] == $aSnsEvent['win_match']){
					//此比赛没有奖项信息
					if(!json_decode($aMatchList[0]['awards'],true)){
							$aEventList[$key]['error_info'] = '此比赛没有奖项信息(此时data_id为比赛id)';
							$aEventList[$key]['table_name'] = 'match';
							$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
					}
					//此比赛没有获奖人信息信息
					if(!json_decode($aMatchList[0]['winners'],true)){
							$aEventList[$key]['error_info'] = '此比赛没有获奖人信息信息(此时data_id为比赛id)';
							$aEventList[$key]['table_name'] = 'match';
							$aEventList[$key]['data_id'] = $aMatchUserRelationList[0]['match_id'];
							$aEventList[$key]['type'] = $aSnsEventInfo[$aEvent['type']];
							$aResult[] = $aEventList[$key];
					}
				}
			}else{
				if($aEvent['type'] == 20){
					continue;
				}
				//没有此类型
				$aEventList[$key]['error_info'] = '没有此类型的动态数据';
				$aEventList[$key]['table_name'] = 'sns_event';
				$aResult[] = $aEventList[$key];
			}

		}

		assign('aResult', $aResult);
		display('tools/scan_event.html.php');
	}

	public function deleteSnsEventError(){
		if(isset($_POST['sub'])){
			$aIds = post('checkbox',0);
			if(!$aIds){
				alert('你还没选中选项，请选择你要删除的数据！！！',0);
			}else{
				if(count($aIds) == 1){
					if($aIds[0] != 'on'){
						$where = array('id'=>$aIds[0]);
					}else{
						alert('你还没选中选项，请选择你要删除的数据！！！',0);
					}
				}else{
					array_splice($aIds,0,1);
					$where = array('id'=>array('in',$aIds));
				}
			}
		}else{
			$id = get('id');
			if(!$id){
				alert('没有你要删除的数据',0);
			}else{
				$where = array('id'=>$id);
			}
			$where2 = '';
			if(isset($_GET['userRelationId'])){
				$userRelationId = get('userRelationId');
				if($userRelationId){
					$where2 = array('id'=>$userRelationId);
				}
			}
		}

		if(isset($where2) && $where2){
			$oUserRelation = new Model(T_USER_RELATION);
			$deleteResult2 = $oUserRelation->delete($where2);
		}
		$oSnsEvent = new Model(T_SNS_EVENT);
		$deleteResult = $oSnsEvent->delete($where);
		if($deleteResult || (isset($deleteResult2) && $deleteResult2)){
			alert('已成功删除数据');
		}else{
			alert('删除数据失败',0);
		}
	}

	/*
	// 李亚林--修改闯关记录
	public function passMission(){
		$oMission = new Model(T_MISSION);
		$oUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$oUserRelation = new Model(T_MISSION_USER_RELATION);
		$aUserIds = array(36953465,65168048,67845258,43411382,87447509,80344436,39903387,14718479,15629886,58313929,65902523,89470396,63439427,16909681,47336139,34065414,30221572,58433374,34232049,85709338,78674803,60392386,61532073,87340771,56453564,86678220,76261629,32542174,82352875,79293784);
		//删除这些用户的原始数据
		$aMissionUserIdList = $oUserRelationIndex->get('`id`', '`user_id` in (' . implode(',', $aUserIds) . ')');
		$aMissionUserIds = array();
		foreach($aMissionUserIdList as $aMissionUserId){
			$aMissionUserIds[] = $aMissionUserId['id'];
		}
		if($aMissionUserIds){
			$rows = $oUserRelationIndex->delete(array('id' => array('in', $aMissionUserIds)));
			if($rows === false){
				alert('删除mission_user_relation_index表数据出错,id为:' . json_encode($aMissionUserIds), 0);
			}
			$rows = $oUserRelation->delete(array('id' => array('in', $aMissionUserIds)));
			if($rows === false){
				alert('删除mission_user_relation表数据出错,id为:' . json_encode($aMissionUserIds), 0);
			}
		}
		$aSubjectList = array(1, 2, 3);
		foreach($aSubjectList as $subject){
			$aMissionList = $oMission->get('`id`,`recent_record`', '`is_forbidden`!=1 AND `subject_id`=' . $subject, '`orders` ASC');
			foreach($aMissionList as $aMission){
				//给每关随机生成给定用户的记录
				$aMissionUserRelationData = array();
				foreach($aUserIds as $userId){
					$score = rand(6000, 8500);
					$day = rand(1, 17);
					$hour = rand(8, 22);
					$min = rand(0, 59);
					$passTime = mktime($hour, $min, 0, date('m'), $day, date('Y'));
					$finishTask = rand(1800, 3600);
					$taskTime = rand(3600, 7200);
					$esCount = rand(30, 60);
					$correct = rand(50, 70);
					$aTemp = array();
					$aTemp['user_id'] = $userId;
					$aTemp['mission_id'] = $aMission['id'];
					$aTemp['is_task_finish'] = 1;
					$aTemp['task_finish_time'] = $passTime - $taskTime;
					$aTemp['is_pass'] = 1;
					$aTemp['es_count'] = $esCount;
					$aTemp['es_correct_count'] = ceil($esCount * $correct / 100);
					$aTemp['score'] = $score;
					$aTemp['create_time'] = $passTime - $taskTime - $finishTask;
					$aTemp['pass_time'] = $passTime;
					$aTemp['best_score_time'] = $passTime;
					$aMissionUserRelationData[] = $aTemp;
				}
				$count = count($aMissionUserRelationData);
				//按过关时间排序
				for($i = 0; $i < $count - 1; $i++){
					for($j = $i + 1; $j < $count; $j++){
						if($aMissionUserRelationData[$i]['pass_time'] > $aMissionUserRelationData[$j]['pass_time']){
							$aTemp2 = $aMissionUserRelationData[$i];
							$aMissionUserRelationData[$i] = $aMissionUserRelationData[$j];
							$aMissionUserRelationData[$j] = $aTemp2;
						}
					}
				}
				foreach($aMissionUserRelationData as $aMissionUserRelation){
					//插入数据
					$indexId = $oUserRelationIndex->add($aMissionUserRelation);
					if($indexId){
						$aData = array();
						$aData['id'] = $indexId;
						$aData['task_process'] = '[]';
						$aData['current_challenge_process'] = '[]';
						$aData['challenge_history'] = '[]';
						$aData['break_record'] = '';
						$row = $oUserRelation->add($aData);
						if(!$row){
							alert('插入数据到mission_user_relation出错,id为:' . $indexId, 0);
						}
					}else{
						alert('插入数据到mission_user_relation_index出错,数据----:' . json_encode($aMissionUserRelation), 0);
					}
				}
				//取最近的十条记录
				$aRecentTenDataBak = array_slice($aMissionUserRelationData, -10, 10);
				$aRecentTenData = array();
				foreach($aRecentTenDataBak as $aRecentData){
					$aTemp3 = array();
					$aTemp3['user_id'] = $aRecentData['user_id'];
					$aTemp3['pass_time'] = $aRecentData['pass_time'];
					$aTemp3['score'] = $aRecentData['score'];
					$aRecentTenData[] = $aTemp3;
				}
				$aMission['recent_record'] = json_decode($aMission['recent_record'], true);
				//合并伪造的和真实的用户信息
				if($aMission['recent_record']){
					//去掉重复用户
					foreach($aMission['recent_record'] as $key => $aRecordData){
						//分数换算-------------------

						//------------------------
						foreach($aRecentTenData as $aTenData){
							if($aTenData['user_id'] == $aRecordData['user_id']){
								unset($aMission['recent_record'][$key]);
								break;
							}
						}
					}
					$aRecentList = array_merge($aRecentTenData, $aMission['recent_record']);
					//去掉重复的
					for($i = 0; $i < $count - 1; $i++){
						for($j = $i + 1; $j < $count; $j++){
							if($aRecentList[$i]['pass_time'] < $aRecentList[$j]['pass_time']){
								$aTemp2 = $aRecentList[$i];
								$aRecentList[$i] = $aRecentList[$j];
								$aRecentList[$j] = $aTemp2;
							}
						}
					}
					$aRecentList = array_slice($aRecentList, 0, 10);
				}else{
					$aRecentList = $aRecentTenData;
				}
				//更新mission表的recent_record字段
				$challengeCount = rand(100, 150);
				$challengeSuccessCount = rand(50, 80);
				$aUpdateArray = array();
				$aUpdateArray['recent_record'] = json_encode($aRecentList);
				$aUpdateArray['challenge_count'] = array('add', $challengeCount);
				$aUpdateArray['challenge_success_count'] = array('add', $challengeSuccessCount);
				$result = $oMission->update($aUpdateArray, array('id' => $aMission['id']));
				if($result === false){
					alert('修改mission表出错,id为:' . $aMission['id'], 0);
				}
			}
		}
		alert('修改完成了');
	}
	*/



	/*
	//更新用户闯关错题集中的错误数据
	public function updateUserEsWrong(){
		$update = get('update',0);
		if(!$update){
			$updateInfo = "<h1><a href='?m=Tools&a=updateUserEsWrong&update=1'>开始更新数据</a></h1><h3 style='color:#00f;'>此次更新是针对用户错题集中关卡中科目不想对应的数据</h3><h3 style='color:#f00;'>注意：未避免脚本执行错误，请先为user_es_wrong表备份数据！</h3>";
			debug($updateInfo,11);
		}
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$aUserEsWrongList = $oUserEsWrong->get('`mission_id`','','id DESC','','','`mission_id`');
		if($aUserEsWrongList === false){
			alert("网络可能有点慢！！！",0);
		}elseif(!$aUserEsWrongList){
			alert("没有数据可更新！！！！！",0);
		}
		//收集关卡id
		$aMissionId = array();
		foreach($aUserEsWrongList as $aUserEsWrong){
			$aMissionId[] = $aUserEsWrong['mission_id'];
		}

		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`subject_id`',array('id'=>array('in', $aMissionId)));
		if($aMissionList === false){
			alert("网络可能有点慢！！！",0);
		}elseif(!$aMissionList){
			alert("没有数据可更新！！！！！",0);
		}
		$aMisssionRefer = array();
		foreach($aMissionList as $aMission){
			$aMisssionRefer[$aMission['id']] = $aMission;
		}
		foreach($aMissionId as $missionId){
			$aUserEsWrongList2 = $oUserEsWrong->get('`id`','`mission_id`=' . $missionId . ' AND `subject_id`<>'. $aMisssionRefer[$missionId]['subject_id']);
			if(!$aUserEsWrongList2){
				continue;
			}
			$where = '';
			if(count($aUserEsWrongList2) == 1){
				$where = array('id'=>$aUserEsWrongList2[0]['id']);
			}else{
				$aIds = array();
				foreach($aUserEsWrongList2 as $aUserEsWrong2){
					$aIds[] = $aUserEsWrong2['id'];
				}
				$where = array('id'=>array('in', $aIds));
			}
			if(!$where){
				continue;
			}
			$result = $oUserEsWrong->update(array('subject_id'=>$aMisssionRefer[$missionId]['subject_id']), $where);
			if($result){
				echo '更新'.$result.'条数据成功！！<br/>';
			}else{
				echo '更新数据<span style="color:#f00;">失败</span>！！<br/>';
			}
		}
	}
	*/

	//转换分享pk的type
	public function transPkType(){
		$oEvent = new Model(T_SNS_EVENT);
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aEventList = $oEvent->get('', 'type=1', 'id DESC');
		if(!$aEventList){
			alert('没有数据要转换',0);
		}
		$aDeleteId = array();
		$aUpdateId = array();
		foreach($aEventList as $aEvent){
			$aShuoshuo = $oShuoshuo->get('`user_id`,`source_type`',array('id'=>$aEvent['data_id']));
			if($aShuoshuo === false){
				echo '服务器执行错误，id为'.$aEvent['id'].'数据转换<font style="color:#f00;">失败</font>！！！<br />';
				continue;
			}elseif(!$aShuoshuo){
				$aDeleteId[] = $aEvent['id'];
			}else{
				if($aShuoshuo[0]['source_type'] == 2){
					if($aEvent['user_id'] == $aShuoshuo[0]['user_id']){
						$aUpdateId[] = $aEvent['id'];
					}else{
						$aDeleteId[] = $aEvent['id'];
					}
				}
			}
		}

		if($aDeleteId){
			$result = $oEvent->delete(array('id'=>array('in',$aDeleteId)));
			if($result){
				echo '删除错误数据成功，id有' . implode(',', $aDeleteId) . '共删除' . $result . '条！！！<br />';
			}else{
				echo '删除错误数据<font style="color:#f00;">失败</font>！！！<br />';
			}
		}
		if($aUpdateId){
			$result = $oEvent->update(array('type'=>16), array('id'=>array('in',$aUpdateId)));
			if($result){
				echo '转换数据成功，id有' . implode(',', $aUpdateId) . '共转换' . $result . '条！！！<br />';
			}else{
				echo '转换数据<font style="color:#f00;">失败</font>！！！<br />';
			}
		}
	}

	/**
	 * 题目数量情况统计
	 */
	public function mt(){
		$subjectId = get('subject');
		$oMission = m('Mission');
		$oEs = m('Es');
		$aMissionList = $oMission->getOriginalMissionList($subjectId, 1, 999999, 1);
		$aCountList = array();

		foreach($aMissionList as $aMission){
			$aTypeKeyList = array(
				'1' => 'single',
				'2' => 'multiple',
				'3' => 'judgment',
				'4' => 'fillblank',
				'5' => 'word_fillblank',
				'6' => 'read_complex',
				'7' => 'fill_complex',
			);

			$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($subjectId, $aMission['category_ids']);
			$aMission['name'] = str_replace('&nbsp;', ' ', $aMission['name']);
			$aMission['name'] = iconv('UTF-8', 'GBK//IGNORE', $aMission['name']);
			$aCount = array(
				'id' => $aMission['id'],
				'title' => $aMission['name'],
				'count' => array_sum($aCategoryTypeAndCounts),
			);
			foreach($aCategoryTypeAndCounts as $type => $typeAndCounts){
				$aCount[$aTypeKeyList[$type]] = array(
					'count' => $typeAndCounts,
					'percent' => intval($typeAndCounts / $aCount['count'] * 100),
				);
			}
			$aCountList[] = $aCount;
		}

		header('Content-Type: application/vnd.ms-execl');
		header('Content-Disposition: attachment; filename=myExcel.xls');
		header('Pragma: no-cache');
		header('Expires: 0');
		/*first line*/
		foreach(array(
			'关卡id',
			'关卡名称',
			'题目总数',
			'单选题数',
			'单选题占比',
			'多选题数量',
			'多选题占比',
			'判断题数量',
			'判断题占比',
			'填空题数',
			'填空题占比',
			'选词填空题数',
			'选词填空题占比',
			'阅读理解题数',
			'阅读理解题占比',
			'完形填空题数',
			'完形填空题占比',
		) as $columTitle){
			echo iconv('UTF-8', 'GBK//IGNORE', $columTitle) . "\t";
		}
		echo "\t\n";

		foreach($aCountList as $aCount){
			putcol($aCount['id']);
			putcol($aCount['title']);
			putcol($aCount['count']);

			foreach($aTypeKeyList as $aTypeKey){
				if(isset($aCount[$aTypeKey])){
					putcol($aCount[$aTypeKey]['count']);
					putcol($aCount[$aTypeKey]['percent'] . '%');
				}else{
					putcol('--');
					putcol('--');
				}
			}
			echo "\t\n";
		}
	}

	//给数学单选题和多选题结尾”.“号换成“。”号
	public function changeSymbol(){
		$subjectId = get('subjectId',0);
		if(!$subjectId){
			$updateInfo = "<h1><a href='?m=Tools&a=changeSymbol&subjectId=2&type=0'>开始得到数据列表</a></h1>";
			debug($updateInfo,11);
		}
		$type = get('type');

		$oEsLog = new Model(T_ES_INDEX);
		$aEsLogList = $oEsLog->get('`id`,`type_id`','subject_id=' . $subjectId . ' AND (type_id = 1 OR type_id = 2)');
		if(!$aEsLogList){
			alert('没有数据要更新，或者网络可能有点慢！',-1);
		}

		$aEsIds = array();
		$aEsRefer = array();
		foreach($aEsLogList as $aEs){
			$aEsIds[] = $aEs['id'];
			$aEsRefer[$aEs['id']] = $aEs['type_id'];
		}


		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('',array('id'=>array('in', $aEsIds)));

		if(!$aEsList){
			alert('没有数据要更新，或者网络可能有点慢！',-1);
		}


		if($type == 1){
			foreach($aEsList as $key=>$aEs){
				$aEsList[$key]['content_json'] = json_decode($aEs['content_json'],true);
				$symbol = mb_substr($aEsList[$key]['content_json']['content'],-1,1);
				if($symbol == '.'){
					$symbol = mb_substr($aEsList[$key]['content_json']['content'],0,mb_strlen($aEsList[$key]['content_json']['content'])-1);
					$aEsList[$key]['content_json']['content'] = $symbol . '。';
					$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
					$aEsMainContent = $oEsPlugin->build($aEsList[$key]['content_json']);
					$aData = array();
					$aData['content_json'] = $aEsMainContent['content_json'];
					$aData['content_text'] = $aEsMainContent['content_text'];
					//debug($aEsList[$key]['content_json']['content']);
					$result = $oEs->update($aData, array('id'=>$aEs['id']));
					if($result){
						echo 'id为'.$aEs['id'].'转换成功!<br />';
					}else{
						echo 'id为'.$aEs['id'].'转换<span style="color:#f00;">失败！</span><br />';
					}
				}
			}
		}elseif($type == 0){
			debug('<h1><a href="?m=Tools&a=changeSymbol&subjectId=2&type=1">开始全部转换</a></h1>');
			foreach($aEsList as $key=>$aEs){
				$aEsList[$key]['content_json'] = json_decode($aEs['content_json'],true);
				$symbol = mb_substr($aEsList[$key]['content_json']['content'],-1,1);
				if($symbol == '.'){
					$debugContent = '题目内容是：' . $aEsList[$key]['content_json']['content'];
					debug($debugContent);
				}
			}
			debug('<h1><a href="?m=Tools&a=changeSymbol&subjectId=2&type=1">开始全部转换</a></h1>');
		}
	}

	//找到比赛得奖但分数为0的用户
	public function getMatchWinners(){
		$delete = get('delete',0);
		$oSnsEvent = new Model(T_SNS_EVENT);
		$aEventList = $oSnsEvent->get('','type=12');
		if(!$aEventList){
			alert('没有数据或网络可能有点慢',-1);
			return;
		}
		$aMatchIds = array();
		foreach($aEventList as $aEvent){
			$aMatchRelationIds[] = $aEvent['data_id'];
		}

		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('`id`,`user_id`,`match_id`,`best_score`', array('id' => array('in', $aMatchRelationIds)));
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}

		$aMatchIds = array();

		//得到赛事Id
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			if($aMatchUserRelation['best_score'] == 0){
				$aMatchIds[] = $aMatchUserRelation['match_id'];
			}
		}

		if(!$aMatchIds){
			alert('没有数据或网络可能有点慢',-1);
			return;
		}

		foreach($aMatchIds as $id){
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				if($id == $aMatchUserRelation['match_id']){
					if($delete){
						$result = $oSnsEvent->delete('user_id='.$aMatchUserRelation['user_id'].' AND type=12 AND data_id='.$aMatchUserRelation['id']);
						if($result){
							debug($aMatchUserRelation['id'].'------'.$aMatchUserRelation['user_id'].'删除成功！');
						}
					}else{
						debug($aMatchUserRelation['id'].'------'.$aMatchUserRelation['user_id'].'在地址上加&delete=1就能删除所有这些动态数据');
					}
				}
			}
		}
	}

	/*
	 * 替换指定人员英语科目题目中----中文引号为英文引号
	 */
	public function replaceChineseMarkToEnglish(){
		function replace(&$value, $key){
			$value = str_replace("‘", "'", $value);
			$value = str_replace("’", "'", $value);
			$value = str_replace('“', '"', $value);
			$value = str_replace('”', '"', $value);
		}

		$managerId = 87;
		$oEsLog = new Model(T_ES_LOG);
		$aEsIdList = $oEsLog->get('`es_id`', '`subject_id`=3 AND `submiter_user_id`=' . $managerId . ' AND `action`=1');
		$aEsIds = array();
		foreach($aEsIdList as $aEsId){
			$aEsIds[] = $aEsId['es_id'];
		}
		unset($aEsIdList);
		$where = array('id' => array('in', $aEsIds));
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexList = $oEsIndex->get('`id`,`type_id`', $where);
		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('`id`,`content_json`,`content_text`', $where);
		$aEsIndexreferList = array();
		foreach($aEsIndexList as $aEsIndex){
			$aEsIndexreferList[$aEsIndex['id']] = $aEsIndex;
		}
		unset($aEsIndexList);
		foreach($aEsList as $aEs){
			$typeId = $aEsIndexreferList[$aEs['id']]['type_id'];
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$typeId]);
			$aEsContent = $oEsPlugin->resolve($aEs['content_json']);
			array_walk_recursive($aEsContent,"replace");
			$aEsCorrectContent = $oEsPlugin->build($aEsContent);
			$result = $oEs->update($aEsCorrectContent, array('id' => $aEs['id']));
			if($result === false){
				debug('修改题目Id为：' . $aEs['id'] . ' 失败');
				break;
			}elseif($result){
				debug('修改题目Id为：' . $aEs['id'] . ' 成功');
			}
		}
		echo '修改完成!!!!!!!!!!';
	}

	//给指定用户加VIP
	public function addVipToPointUser(){
		$aVipUser1 = array(40137186);
		$aVipUser2 = array(19577027,15947559);
		$expirationTime = time() + 30 * 24 * 3600;
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		foreach($aVipUser1 as $userId){
			$aUpdata = array(
				'vip'	=>	1,
				'vip_expiration_time'	=>	$expirationTime,
			);
			$result = $oUserNumerical->update($aUpdata, array('id' => $userId));
			if($result){
				debug('为用户ID为：' . $userId . ' 添加普通VIP成功');
			}else{
				debug('为用户ID为：' . $userId . ' 添加普通VIP失败');
			}
		}
		foreach($aVipUser2 as $userId){
			$aUpdata = array(
				'vip'	=>	2,
				'vip_expiration_time'	=>	$expirationTime,
			);
			$result = $oUserNumerical->update($aUpdata, array('id' => $userId));
			if($result){
				debug('为用户ID为：' . $userId . ' 添加白金VIP成功');
			}else{
				debug('为用户ID为：' . $userId . ' 添加白金VIP失败');
			}
		}
		echo '执行完成!!!!!!!!!!!!!!!!';
	}

	public function changeMedalNumerical(){
		//清除不要的动态
		$oSnsEvent = new Model(T_SNS_EVENT);
		$result = $oSnsEvent->delete("`type`=8 AND `data_id` not like '2%' and `data_id` not like '6%'");
		if($result === false){
			exit('清除不要的动态失败');
		}
		debug('清除了 ' . $result . ' 条勋章动态');
		//初始化excellent_missions
		$oMedal = new Model(T_MEDAL);
		$result = $oMedal->update(array('excellent_missions' => 0), '1');
		if($result === false){
			exit('初始化优质关卡失败');
		}
		debug('初始化 ' . $result . ' 条优质关卡数据');
		//更新优质关卡数量
		$oMissionUserRelaionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$limitScore = 9000;
		$aUserExcellentMissionList = $oMissionUserRelaionIndex->get('`user_id`,count(*) as `nums`', '`score`>=' . $limitScore, '', '', '', '`user_id`');
		//debug($aUserExcellentMissionList);
		foreach($aUserExcellentMissionList as $aUserExcellentMission){
			$result = $oMedal->update(array('excellent_missions' => $aUserExcellentMission['nums']), array('id' => $aUserExcellentMission['user_id']));
			if($result === false){
				exit('更新优质关卡数量失败');
			}
		}
		debug('更新优质关卡数量成功');
		//清除不要的medal_process
		$aMedalProcessList = $oMedal->get('`id`,`medal_process`', '');
		foreach($aMedalProcessList as $aMedalProcess){
			$aMedalProcess['medal_process'] = json_decode($aMedalProcess['medal_process'], true);
			$aUpdateProcess['medal_process'] = array();
			if(isset($aMedalProcess['medal_process']['passed_missions'])){
				$aUpdateProcess['medal_process']['passed_missions'] = $aMedalProcess['medal_process']['passed_missions'];
			}
			if(isset($aMedalProcess['medal_process']['pk_win_times'])){
				$aUpdateProcess['medal_process']['pk_win_times'] = $aMedalProcess['medal_process']['pk_win_times'];
			}
			$aUpdateProcess['medal_process'] = json_encode($aUpdateProcess['medal_process']);
			$result = $oMedal->update($aUpdateProcess, array('id' => $aMedalProcess['id']));
			if($result === false){
				exit('更新medal_process失败');
			}
		}
		debug('更新medal_process成功');
		//初始化用户奖牌
		$aUpdateMedal = array(
			'gold_medal'	=>	0,
			'silver_medal'	=>	0,
			'cuprum_medal'	=>	0,
		);
		$result = $oMedal->update($aUpdateMedal, '1');
		if($result === false){
			exit('初始化奖牌失败');
		}
		debug('初始化 ' . $result . ' 条奖牌数据');
		//更新用户奖牌
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`winners`', '');
		foreach($aMatchList as $aMatch){
			$aMatch['winners'] = json_decode($aMatch['winners'], true);
			if($aMatch['winners']){
				foreach($aMatch['winners']['top'] as $ranking => $aTop){
					if($ranking == 1){
						$result = $oMedal->update(array('gold_medal' => array('add', 1)), array('id' => $aTop['user_id']));
					}elseif($ranking == 2){
						$result = $oMedal->update(array('silver_medal' => array('add', 1)), array('id' => $aTop['user_id']));

					}elseif($ranking == 3){
						$result = $oMedal->update(array('cuprum_medal' => array('add', 1)), array('id' => $aTop['user_id']));
					}
					if(!$result){
						exit('更新奖牌失败');
					}
				}
			}
		}
		debug('更新奖牌成功');
	}

	/**
	 * 为用户设置指定的金币数量
	 */
	public function setGold(){
		$aIdList = explode(',', get('uid'));
		$gold = intval(get('gold', 18000));
		if(!$aIdList){
			alert(0, 0);
		}
		foreach($aIdList as $key => $id){
			if(strlen($id) != 8){
				unset($aIdList[$key]);
			}
		}
		$oDb = new DBOI();
		$row = $oDb->table(T_USER_NUMERICAL)->where('id in(' . implode(',', $aIdList) . ')')->data(array('gold' => $gold))->update();
		if($row){
			alert('设置成功', 1);
		}else{
			alert('设置失败');
		}
	}

	public function addUserDailyLoginData(){
		$timeY = 2013;
		$timeM = 9;
		$timeD = 1;
		$oDailyRecord = new Model(T_USER_DAILY_LOGIN_RECORD);
		$oUser = new Model(T_USER);
		while(true){
			$arr = array(1,3,5,7,8,10,12);
			if($timeM == 2){
				$day = date('L',strtotime($timeY.'-'.$timeM.'-1')) ? 28 : 29;
			}else{
				$day = in_array($timeM, $arr) ? 31 : 30;
			}
			if($timeD > $day){
				$timeM += 1;
				$timeD = 1;
			}
			if($timeM > 12){
				$timeY += 1;
				$timeM = 1;
			}
			if($timeY == 2014 && $timeM == 5 && $timeD == 21){
				break;
			}
			$startTime = strtotime($timeY . '-' . $timeM . '-' . $timeD);
			$endTime = strtotime($timeY . '-' . $timeM . '-' . $timeD . ' 24:00:00');
			$aData = array();
			$aData['year'] = $timeY;
			$aData['month'] = $timeM;
			$aData['day'] = $timeD;
			//总注册用户
			$aData['all_user_nums'] = $oUser->count('create_time<' . $endTime);

			//-------一天的统计---------//
			$aData['day_login_record'] = $this->getUserTotal($startTime, $endTime);
			$aData['day_login_record'] = json_encode($aData['day_login_record']);

			//----一天每小时的统计-------//
			$aHourSecond = 3600;
			$aHourRecord = array();
			$startTime2 = $startTime;
			$endTime2 = 0;
			for($i=0;$i<24;$i++){
				if($i != 0){
					$startTime2 = $endTime2;
				}
				$endTime2 = $startTime2 + $aHourSecond;
				$aRecord = $this->getUserTotal($startTime2, $endTime2);
				$aData['hour_login_record'][$i]['log_times'] = $aRecord['log_times'];
				$aData['hour_login_record'][$i]['log_user_nums'] = $aRecord['log_user_nums'];
				$aData['province_hour_login_record'][$i]['province_record'] = $aRecord['province_record'];
				$aData['grade_hour_login_record'][$i]['grade_record'] = $aRecord['grade_record'];
				$aData['gender_hour_login_record'][$i]['gender_record'] = $aRecord['gender_record'];
				$aData['source_hour_login_record'][$i]['source_record'] = $aRecord['source_record'];
			}
			$aData['hour_login_record'] = json_encode($aData['hour_login_record']);
			$aData['province_hour_login_record'] = json_encode($aData['province_hour_login_record']);
			$aData['grade_hour_login_record'] = json_encode($aData['grade_hour_login_record']);
			$aData['gender_hour_login_record'] = json_encode($aData['gender_hour_login_record']);
			$aData['source_hour_login_record'] = json_encode($aData['source_hour_login_record']);

			$oDailyRecord->add($aData);

			$timeD++;
		}
	}

	public function addUserDailyMatchData(){
		//$time = time();
		$timeY = 2013;
		$timeM = 9;
		$timeD = 1;
		$oDailyRecord = new Model(T_USER_DAILY_MATCH_RECORD);
		while(true){
			$arr = array(1,3,5,7,8,10,12);
			if($timeM == 2){
				$day = date('L',strtotime($timeY.'-'.$timeM.'-1')) ? 28 : 29;
			}else{
				$day = in_array($timeM, $arr) ? 31 : 30;
			}
			if($timeD > $day){
				$timeM += 1;
				$timeD = 1;
			}
			if($timeM > 12){
				$timeY += 1;
				$timeM = 1;
			}
			if($timeY == 2014 && $timeM == 5 && $timeD == 22){
				break;
			}

			$aData = array();
			$aData['year'] = $timeY;
			$aData['month'] = $timeM;
			$aData['day'] = $timeD;

			//-----一天的记录-----//
			$startTime = strtotime($timeY . '-' . $timeM . '-' . $timeD);
			$endTime = strtotime($timeY . '-' . $timeM . '-' . $timeD . ' 24:00:00');
			//比赛次数
			$aData['day_match_record']['match_times'] = $this->joinMatchTimes($startTime, $endTime);

			//比赛的人数
			$aData['day_match_record']['join_match_user_nums'] = $this->joinMatchUserNums($startTime, $endTime);

			//-----一天每小时的记录----//
			$oneHourSecond = 3600;
			for($i=0;$i<24;$i++){
				$endTime = $startTime + $oneHourSecond;
				$aData['hour_match_record'][$i] = $this->joinMatchUserNums($startTime, $endTime);
				$startTime = $endTime;
			}
			$aData['day_match_record'] = json_encode($aData['day_match_record']);
			$aData['hour_match_record'] = json_encode($aData['hour_match_record']);
			$oDailyRecord->add($aData);

			$timeD++;
		}

	}


	//每年登陆日志的存储--第二个月1号的时候执行
	public function addYearlyLoginData(){
		$timeY = 2013;
		$timeM = 9;
		$oUserLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$oYearlyRecord = new Model(T_USER_YEARLY_LOGIN_RECORD);
		while(true){
			if($timeM > 12){
				$timeY += 1;
				$timeM = 1;
			}
			if($timeY == 2014 && $timeM == 6){
				break;
			}

			$aYearlyRecord = $this->getUserLoginTotalByYear($timeY);

			if(!$aYearlyRecord){
				$aData = array();
				$is_update = false;
			}else{
				$aData = $aYearlyRecord;
				$is_update = true;
			}

			$aData['year'] = $timeY;

			//一年的统计
			$startTime = strtotime($timeY . '-1-1');
			$endTime = strtotime($timeY . '-12-31');

			$aData['year_login_record']['log_times'] = $oUserLoginLog->count('login_time>=' . $startTime .' AND login_time<' . $endTime);
			$aUserList = $oUserLoginLog->get('user_id','login_time<' . $endTime . ' AND login_time>=' . $startTime, '', '', '', 'user_id');
			$aData['year_login_record']['log_user_nums'] = count($aUserList);
			$aTotal = $this->getUserTotal($startTime, $endTime);
			$aData['year_login_record']['province_record'] = $aTotal['province_record'];
			$aData['year_login_record']['gender_record'] = $aTotal['gender_record'];
			$aData['year_login_record']['grade_record'] = $aTotal['grade_record'];
			$aData['year_login_record']['source_record'] = $aTotal['source_record'];

			$arr = array(1,3,5,7,8,10,12);
			//每个月的统计
			if($timeM == 2){
				$day = date('L',strtotime($timeY . '-2-1')) ? 28 : 29;
			}else{
				$day = in_array($timeM, $arr) ? 31 : 30;
			}
			$startTime = strtotime($timeY . '-' . $timeM . '-1');
			$endTime = strtotime($timeY . '-' . $timeM . '-' . $day);
			$aTotal = $this->getUserTotal($startTime, $endTime);
			$aData['month_login_record'][$timeM]['log_times'] = $aTotal['log_times'];
			$aData['month_login_record'][$timeM]['log_user_nums'] = $aTotal['log_user_nums'];
			$aData['province_month_login_record'][$timeM] = $aTotal['province_record'];
			$aData['gender_month_login_record'][$timeM] = $aTotal['gender_record'];
			$aData['grade_month_login_record'][$timeM] = $aTotal['grade_record'];
			$aData['source_month_login_record'][$timeM] = $aTotal['source_record'];

			//每周的统计
			$aDate = $this->getDateByYear($timeY);
			foreach($aDate[$timeM] as $key=>$aDateM){
				$startTime = strtotime($aDateM['startTime']);
				$endTime = strtotime($aDateM['endTime']);
				$aTotal = $this->getUserTotal($startTime, $endTime);
				$aData['week_login_record'][$key]['log_times'] = $aTotal['log_times'];
				$aData['week_login_record'][$key]['log_user_nums'] = $aTotal['log_user_nums'];
				$aData['province_week_login_record'][$key] = $aTotal['province_record'];
				$aData['gender_week_login_record'][$key] = $aTotal['gender_record'];
				$aData['grade_week_login_record'][$key] = $aTotal['grade_record'];
				$aData['source_week_login_record'][$key] = $aTotal['source_record'];
			}

			$aData['year_login_record'] = json_encode($aData['year_login_record']);
			$aData['month_login_record'] = json_encode($aData['month_login_record']);
			$aData['province_month_login_record'] = json_encode($aData['province_month_login_record']);
			$aData['gender_month_login_record'] = json_encode($aData['gender_month_login_record']);
			$aData['grade_month_login_record'] = json_encode($aData['grade_month_login_record']);
			$aData['source_month_login_record'] = json_encode($aData['source_month_login_record']);
			$aData['week_login_record'] = json_encode($aData['week_login_record']);
			$aData['province_week_login_record'] = json_encode($aData['province_week_login_record']);
			$aData['gender_week_login_record'] = json_encode($aData['gender_week_login_record']);
			$aData['grade_week_login_record'] = json_encode($aData['grade_week_login_record']);
			$aData['source_week_login_record'] = json_encode($aData['source_week_login_record']);

			if($is_update){
				$oYearlyRecord->update($aData,array('id'=>$aData['id']));
			}else{
				$oYearlyRecord->add($aData);
			}
			$timeM++;
		}
	}

	public function addMonthlyLoginData(){
		$timeY = 2013;
		$timeM = 9;
		$oUserLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$oMonthLyTimesRecord = new Model(T_USER_LOGIN_TIMES_RECORD);
		while(true){
			if($timeM > 12){
				$timeY += 1;
				$timeM = 1;
			}
			if($timeY == 2014 && $timeM == 5){
				break;
			}

			if(strlen($timeM) == 1){
				$aData['month'] =  $timeY . '0' . $timeM;
			}else{
				$aData['month'] =  $timeY.$timeM;
			}


			$arr = array(1,3,5,7,8,10,12);
			if($timeM == 2){
				$day = date('L',strtotime($timeY . '-2-1')) ? 28 : 29;
			}else{
				$day = in_array($timeM, $arr) ? 31 : 30;
			}
			$startTime = strtotime($timeY . '-' . $timeM . '-1');
			$endTime = strtotime($timeY . '-' . $timeM . '-' . $day);

			$aData['month_login_record'] = array();
			$aData['week_login_record'] = array();
			$aData['day_login_record'] = array();

			//每月统计
			$aData['month_login_record'] = $this->getUserTimes($startTime, $endTime);

			$aData['month_login_record']['all_user_nums'] = count($oUserLoginLog->get('`id`','login_time<' . $endTime . ' AND login_time>=' . $startTime,'','','','user_id'));

			//每周统计
			$aDate = $this->getDateByYear($timeY);
			$aData['week_login_record'] = array();
			foreach($aDate[$timeM] as $key=>$aDateM){
				$startTime = strtotime($aDateM['startTime']);
				$endTime = strtotime($aDateM['endTime']);
				$aData['week_login_record'][$key] = $this->getUserTimes($startTime, $endTime);
			}

			//每日统计
			for($i=1;$i<=$day;$i++){
				$startTime = strtotime($timeY . '-' . $timeM . '-' . $i);
				$endTime = strtotime($timeY . '-' . $timeM . '-' . $i . ' 24:00:00');
				$aData['day_login_record'][$i] = $this->getUserTimes($startTime, $endTime);
			}

			$aData['month_login_record'] = json_encode($aData['month_login_record']);
			$aData['week_login_record'] = json_encode($aData['week_login_record']);
			$aData['day_login_record'] = json_encode($aData['day_login_record']);


			$oMonthLyTimesRecord->add($aData);
			$timeM++;
		}

	}

	public function addMonthlyJoinMatchData(){
		$timeY = 2013;
		$timeM = 9;
		$oMonthlyRecord = new Model(T_USER_MONTHLY_MATCH_RECORD);
		while(true){
			if($timeM > 12){
				$timeY += 1;
				$timeM = 1;
			}
			if($timeY == 2014 && $timeM == 5){
				break;
			}

			if(strlen($timeM) == 1){
				$aData['month'] =  $timeY . '0' . $timeM;
			}else{
				$aData['month'] =  $timeY.$timeM;
			}

			$arr = array(1,3,5,7,8,10,12);
			if($timeM == 2){
				$day = date('L',strtotime($timeY . '-2-1')) ? 28 : 29;
			}else{
				$day = in_array($timeM, $arr) ? 31 : 30;
			}

			//---每月统计----//
			$startTime = strtotime($timeY . '-' . $timeM . '-1');
			$endTime = strtotime($timeY . '-' . $timeM . '-' . $day);
			$aData['join_match_user_nums'] = $this->joinMatchUserNums($startTime, $endTime);


			//----每周的统计----//
			$aData['week_match_record'] = array();
			$aDate = $this->getDateByYear($timeY);
			foreach($aDate[$timeM] as $key=>$aDateM){
				$startTime = strtotime($aDateM['startTime']);
				$endTime = strtotime($aDateM['endTime']);
				$aData['week_match_record'][$key] = $this->joinMatchUserNumsByNatrue($startTime, $endTime);
			}
			$aData['week_match_record'] = json_encode($aData['week_match_record']);

			$oMonthlyRecord->add($aData);
			$timeM++;
		}
	}

	//每周统计比赛---下一周的星期一执行
	public function addWeeklyJoinMatchData(){
		$timeY = 2013;
		$timeW = 1;
		$oWeeklyRecord = new Model(T_USER_WEEKLY_MATCH_TIMES_RECORD);
		while(true){
			if($timeW > $this->getWeekCountByYear($timeY)){
				$timeY += 1;
				$timeW = 1;
			}
			if($timeY == 2014 && $timeW == 21){
				break;
			}
			if(strlen($timeW) == 1){
				$aData['week'] =  $timeY . '0' . $timeW;
			}else{
				$aData['week'] =  $timeY.$timeW;
			}

			$aDate = $this->getDateByYear2($timeY);
			$startTime = strtotime($aDate[$timeW]['startTime']);
			$endTime = strtotime($aDate[$timeW]['endTime']);
			$aData['week_match_times_record'] = $this->getUserNumsByTimes($startTime, $endTime);
			$aData['week_match_times_record'] = json_encode($aData['week_match_times_record'],true);

			$oWeeklyRecord->add($aData);
			$timeW++;
		}
	}

	public function addLogData(){
		debug('<a href="http://m.umfun.dev/?m=Tools&a=addUserDailyLoginData">链接1</a>');
		debug('<a href="http://m.umfun.dev/?m=Tools&a=addUserDailyMatchData">链接2</a>');
		debug('<a href="http://m.umfun.dev/?m=Tools&a=addYearlyLoginData">链接3</a>');
		debug('<a href="http://m.umfun.dev/?m=Tools&a=addMonthlyLoginData">链接4</a>');
		debug('<a href="http://m.umfun.dev/?m=Tools&a=addMonthlyJoinMatchData">链接5</a>');
		debug('<a href="http://m.umfun.dev/?m=Tools&a=addWeeklyJoinMatchData">链接6</a>');
	}
	//按照登录时间段去统计登录次
	private function getUserTimes($startTime, $endTime){
		$aTimes = array();
		for($i=1;$i<31;$i++){
			if($i == 30){
				$aTimes['30+'] = 0;
			}else{
				$aTimes[$i] = 0;
			}
		}

		$oUserLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$aTotal = $oUserLoginLog->get('count(`user_id`) as total','login_time<' . $endTime . ' AND login_time>=' . $startTime,'','','','user_id');
		if(!$aTotal){
			return $aTimes;
		}

		foreach($aTotal as $aCount){
			if($aCount['total'] >= 30){
				$aTimes['30+']++;
			}else{
				$aTimes[$aCount['total']]++;
			}
		}
		return $aTimes;
	}

	//按照时间段去统计数据
	private function getUserTotal($startTime, $endTime){
		$aProvince = array(0=>0, 110000=>0, 120000=>0, 130000=>0, 140000=>0, 150000=>0, 210000=>0, 220000=>0, 230000=>0, 310000=>0, 320000=>0, 330000=>0, 340000=>0, 350000=>0, 360000=>0, 370000=>0, 410000=>0, 420000=>0, 430000=>0, 440000=>0, 450000=>0, 460000=>0, 500000=>0, 510000=>0, 520000=>0, 530000=>0, 540000=>0, 610000=>0, 620000=>0, 630000=>0, 640000=>0,650000=>0);
		$aGrade = array(0=>0,5=>0,6=>0,7=>0,8=>0,9=>0);
		$aGender = array(0,0,0);
		$aSource = array(0,0,0);
		//初始化数据
		$aTotal = array();
		$aTotal['log_times'] = 0;
		$aTotal['log_user_nums'] = 0;
		$aTotal['province_record'] = $aProvince;
		$aTotal['grade_record'] = $aGrade;
		$aTotal['gender_record'] = $aGender;
		$aTotal['source_record'] = $aSource;


		//登陆次数
		$oUserLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$aTotal['log_times'] = $oUserLoginLog->count('login_time>=' . $startTime .' AND login_time<' . $endTime);

		//登陆人数--当天登陆人数
		$aUserList = $oUserLoginLog->get('user_id','login_time<' . $endTime . ' AND login_time>=' . $startTime, '', '', '', 'user_id');
		$aTotal['log_user_nums'] = count($aUserList);

		//收集用户id
		$aUserIds = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['user_id'];
		}

		if(!$aUserIds){
			return $aTotal;
		}
		//用户属性--用户地区--年级
		$oUserClass = new Model(T_USER_CLASS);
		$aUserProvinceList = $oUserClass->get('`province_id`,`grade`','user_id in (' . implode(',',$aUserIds) . ') and is_active = 1');
		$aProvinceAndGrade = $this->getUserProvinceAndGrade($aUserProvinceList);

		$aTotal['province_record'] = $aProvinceAndGrade['province'];
		$aTotal['grade_record'] = $aProvinceAndGrade['grade'];

		//用户属性--用户性别
		$oPersonal = new Model(T_PERSONAL);
		$aUserInfoList = $oPersonal->get('`gender`',array('id'=>array('in',$aUserIds)));
		$aTotal['gender_record'] = $this->getUserGrade($aUserInfoList);

		//用户属性---来源（暂时无法统计）

		return $aTotal;
	}

	//用户属性--用户地区--年级
	private function getUserProvinceAndGrade($aUserProvinceList){
		$aProvince = array(0=>0, 110000=>0, 120000=>0, 130000=>0, 140000=>0, 150000=>0, 210000=>0, 220000=>0, 230000=>0, 310000=>0, 320000=>0, 330000=>0, 340000=>0, 350000=>0, 360000=>0, 370000=>0, 410000=>0, 420000=>0, 430000=>0, 440000=>0, 450000=>0, 460000=>0, 500000=>0, 510000=>0, 520000=>0, 530000=>0, 540000=>0, 610000=>0, 620000=>0, 630000=>0, 640000=>0,650000=>0);
		$aGrade = array(0=>0,5=>0,6=>0,7=>0,8=>0,9=>0);
		$aTotal = array();
		foreach($aUserProvinceList as $aUserProvince){
			if(!$aUserProvince['province_id']){
				$aProvince[0]++;
			}elseif(!$aUserProvince['grade']){
				$aGrade[0]++;
			}else{
				$aProvince[$aUserProvince['province_id']]++;
				$aGrade[$aUserProvince['grade']]++;
			}
		}
		$aTotal['province'] = $aProvince;
		$aTotal['grade'] = $aGrade;
		return $aTotal;
	}

	//用户属性---用户性别
	private function getUserGrade($aUserInfoList){
		$aGender = array(0,0,0);
		foreach($aUserInfoList as $aUserInfo){
			$aGender[$aUserInfo['gender']]++;
		}
		return $aGender;
	}

	//查看每年的记录
	private function getUserLoginTotalByYear($year){
		$year = (int)$year;
		$oUserByYear = new Model(T_USER_YEARLY_LOGIN_RECORD);
		$aUserTotal = $oUserByYear->get('','year=' . $year);
		if(!$aUserTotal){
			return $aUserTotal;
		}

		$aUserTotal[0]['year_login_record'] = json_decode($aUserTotal[0]['year_login_record'],true);
		$aUserTotal[0]['month_login_record'] = json_decode($aUserTotal[0]['month_login_record'],true);
		$aUserTotal[0]['week_login_record'] = json_decode($aUserTotal[0]['week_login_record'],true);
		$aUserTotal[0]['province_month_login_record'] = json_decode($aUserTotal[0]['province_month_login_record'],true);
		$aUserTotal[0]['gender_month_login_record'] = json_decode($aUserTotal[0]['gender_month_login_record'],true);
		$aUserTotal[0]['grade_month_login_record'] = json_decode($aUserTotal[0]['grade_month_login_record'],true);
		$aUserTotal[0]['source_month_login_record'] = json_decode($aUserTotal[0]['source_month_login_record'],true);
		$aUserTotal[0]['province_week_login_record'] = json_decode($aUserTotal[0]['province_week_login_record'],true);
		$aUserTotal[0]['gender_week_login_record'] = json_decode($aUserTotal[0]['gender_week_login_record'],true);
		$aUserTotal[0]['grade_week_login_record'] = json_decode($aUserTotal[0]['grade_week_login_record'],true);
		$aUserTotal[0]['source_week_login_record'] = json_decode($aUserTotal[0]['source_week_login_record'],true);
		return $aUserTotal[0];
	}


	//计算一年的中的周数
	private function getDateByYear($year){
		//计算前一年的总周数
		$beforeY = $year - 1;
		for($i=0;$i<7;$i++){
			$beforeW = $i;
			$day = 31-$i;
			$beforeWeek = (int)date('W',strtotime($beforeY .'-12-'. $day));
			if($beforeWeek != 1){
				break;
			}
		}

		//计算这一年的总周数
		for($i=0;$i<7;$i++){
			$day = 31-$i;
			$nowWeek = (int)date('W',strtotime($year . '-12-' . $day));
			if($nowWeek != 1){
				break;
			}
		}

		$aDate = array();
		for($i=1;$i<=$nowWeek;$i++){
			//如果前一年最后几天是这一年的第一周
			if($beforeW > 0){
				$day = 31- $beforeW;
				$startTime = $beforeY . '-12-' . $day;
				//显示时加多一天显示
				$startTime2 = date('Y-m-d',strtotime($startTime)+24*3600);
				$beforeW = 0;
			}else{
				if($i==1){
					$startTime = $startTime2 = $year . '-1-1';
				}else{
					$startTime2 = date('Y-m-d',strtotime($endTime)+24*3600);
					$startTime = $endTime;
				}
			}

			$time = strtotime($startTime . " +1 week");
			$endTime = date('Y-m-d',$time);
			$endTimeM = (int)date('m',$time);
			$aDate[$endTimeM][$i]['startTime'] = $startTime2;
			$aDate[$endTimeM][$i]['endTime'] = $endTime;
		}
		return $aDate;
	}

	//计算一年的中的周数
	private function getDateByYear2($year){
		//计算前一年的总周数
		$beforeY = $year - 1;
		for($i=0;$i<7;$i++){
			$beforeW = $i;
			$day = 31-$i;
			$beforeWeek = (int)date('W',strtotime($beforeY .'-12-'. $day));
			if($beforeWeek != 1){
				break;
			}
		}

		//计算这一年的总周数
		for($i=0;$i<7;$i++){
			$day = 31-$i;
			$nowWeek = (int)date('W',strtotime($year . '-12-' . $day));
			if($nowWeek != 1){
				break;
			}
		}

		$aDate = array();
		for($i=1;$i<=$nowWeek;$i++){
			//如果前一年最后几天是这一年的第一周
			if($beforeW > 0){
				$day = 31- $beforeW;
				$startTime = $beforeY . '-12-' . $day;
				//显示时加多一天显示
				$startTime2 = date('Y-m-d',strtotime($startTime)+24*3600);
				$beforeW = 0;
			}else{
				if($i==1){
					$startTime = $startTime2 = $year . '-1-1';
				}else{
					$startTime2 = date('Y-m-d',strtotime($endTime)+24*3600);
					$startTime = $endTime;
				}
			}

			$time = strtotime($startTime . " +1 week");
			$endTime = date('Y-m-d',$time);
			//$endTimeM = (int)date('m',$time);
			$aDate[$i]['startTime'] = $startTime2;
			$aDate[$i]['endTime'] = $endTime;
		}
		return $aDate;
	}

	//根据次数分布得到比赛人数
	private function getUserNumsByTimes($startTime, $endTime){
		//初始化数据
		$aData = array();
		for($i=1;$i<=21;$i++){
			if($i == 21){
				$aData['20+'] = 0;
			}else{
				$aData[$i] = 0;
			}
		}

		$oMatch = new Model(T_MATCH_USER_RELATION);
		$aMatchList = $oMatch->get('`user_id`,`match_history`','first_join_time>0');

		$aUserMatchTimes = array();
		if($aMatchList){
			foreach($aMatchList as $aMatch){
				$aMatchHistory = json_decode($aMatch['match_history'],true);
				if(!isset($aUserMatchTimes[$aMatch['user_id']])){
					$aUserMatchTimes[$aMatch['user_id']] = 0;
				}
				if($aMatchHistory){
					foreach($aMatchHistory as $aMatch2){
						$conpTime = $aMatch2['start_time'];
						if($conpTime <= $endTime && $conpTime >= $startTime){
							$aUserMatchTimes[$aMatch['user_id']]++;
						}
					}
				}
			}
		}

		if($aUserMatchTimes){
			foreach($aUserMatchTimes as $aUserTimes){
				if($aUserTimes != 0){
					$aData[$aUserTimes]++;
				}
			}
		}
		return $aData;
	}

	//计算比赛的次数
	private function joinMatchTimes($startTime, $endTime){
		$oMatch = new Model(T_MATCH_USER_RELATION);
		$aMatchList = $oMatch->get('`match_history`','first_join_time>0');
		$times = 0;
		if($aMatchList){
			foreach($aMatchList as $aMatch){
				$aMatchHistory = json_decode($aMatch['match_history'],true);
				if($aMatchHistory){
					foreach($aMatchHistory as $aMatch2){
						$conpTime = $aMatch2['start_time'];
						if($conpTime < $endTime && $conpTime >= $startTime){
							$times++;
						}
					}
				}
			}
		}
		return $times;
	}

	//计算比赛的人数
	private function joinMatchUserNums($startTime, $endTime){
		$oMatch = new Model(T_MATCH_USER_RELATION);
		$userNums = 0;
		$aMatchList = $oMatch->get('`id`','`first_join_time`>=' . $startTime . ' AND `first_join_time`<' . $endTime, '', '', '', 'user_id');
		if($aMatchList){
			$userNums = count($aMatchList);
		}
		return $userNums;
	}


	//计算比赛人数以及按用户年级和科目分布
	private function joinMatchUserNumsByNatrue($startTime, $endTime){
		$oMatchRelation = new Model(T_MATCH_USER_RELATION);
		//初始化数据
		$aData = array(
			'join_match_user_nums'=>0,
 			'chinese'=>array(
			),
			'math'=>array(
			),
			'english'=>array(
			),
			'synthesis'=>array(
			)
		);
		foreach($aData as $key=>$data){
			if(is_array($data)){
				$aData[$key][5] = 0;
				$aData[$key][6] = 0;
				$aData[$key][7] = 0;
				$aData[$key][8] = 0;
				$aData[$key][9] = 0;
				$aData[$key][10] = 0;
				$aData[$key][11] = 0;
			}
		}

		$aMatchRelationList = $oMatchRelation->get('`user_id`,`match_id`,`match_history`','`first_join_time`>0');

		if($aMatchRelationList){
			$aData['join_match_user_nums'] = $this->joinMatchUserNums($startTime, $endTime);
			$aMatchList = array();
			$aMatchIds = array();
			$oMatch = new Model(T_MATCH);
			foreach($aMatchRelationList as $aMatchRelation){
				$times = 0;
				$aMatchHistory = json_decode($aMatchRelation['match_history'],true);
				if($aMatchHistory){
					foreach($aMatchHistory as $aMatch2){
						$conpTime = $aMatch2['start_time'];
						if($conpTime < $endTime && $conpTime >= $startTime){
							$times++;
						}
					}
				}
				$aMatchList[$aMatchRelation['match_id']][$aMatchRelation['user_id']] = $times;
				$aMatchIds[] = $aMatchRelation['match_id'];
			}
			unset($aMatchRelationList);

			$aMatchList2 = $oMatch->get('`id`,`grade_id`,`subject_id`', array('id'=>array('in',$aMatchIds)));
			$aMatchGradeRefer = array();
			if($aMatchList2){
				foreach($aMatchList2 as $aMatch){
					$aMatchList[$aMatch['id']]['subject_id'] = $aMatch['subject_id'];
					$aMatchGradeRefer[$aMatch['id']] = $aMatch['grade_id'];
				}
			}

			foreach($aMatchList as $matchId=>$aMatch){
				if($aMatch['subject_id'] == 1){
					foreach($aMatch as $userId=>$times){
						if($userId != 'subject_id'){
							$aData['chinese'][$aMatchGradeRefer[$matchId]] += $times;
						}
					}
				}else if($aMatch['subject_id'] == 2){
					foreach($aMatch as $userId=>$times){
						if($userId != 'subject_id'){
							$aData['math'][$aMatchGradeRefer[$matchId]] += $times;
						}
					}
				}else if($aMatch['subject_id'] == 3){
					foreach($aMatch as $userId=>$times){
						if($userId != 'subject_id'){
							$aData['english'][$aMatchGradeRefer[$matchId]] += $times;
						}
					}
				}else if($aMatch['subject_id'] == 4){
					foreach($aMatch as $userId=>$times){
						if($userId != 'subject_id'){
							$aData['synthesis'][$aMatchGradeRefer[$matchId]] += $times;
						}
					}
				}
			}

		}
		return $aData;
	}


	//计算一年的总周数
	private function getWeekCountByYear($year){
		for($i=0;$i<7;$i++){
			$day = 31-$i;
			$weekCount = (int)date('W',strtotime($year.'-12-'.$day));
			if($weekCount != 1){
				break;
			}
		}
		return $weekCount;
	}

	//获取题目的答案---外挂专用
	public function getEsDetail(){
		$oDb = new DBOI();
		$postId = (string)post('id');
		if(!is_numeric($postId)){
			$id = (int)Xxtea::decrypt($postId);
		}else{
			$id = $postId;
		}
		$aEs = $oDb->table(T_ES)->where('`id` =' . $id)->select();
		$aEsType = $oDb->fields('`type_id`')->table(T_ES_INDEX)->where('`id`=' . $id)->select();
		if(!$aEs ||!$aEsType){
			alert('找不到指定的题目' . $id, 0);
		}
		$aEs[0]['id'] = $id;
		$aEs[0]['type'] = $aEsType[0]['type_id'];
		$aEs[0]['content_json'] = json_decode($aEs[0]['content_json']);
		alert('读取成功',1,$aEs[0]);
	}


	//将题目upload的图片移动到data下
	public function getRemoveImg(){
		$oEs = new Model(T_ES);
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsList = $oEs->get('`id`,`content_json`','content_json LIKE "%Uploads%"');
		foreach($aEsList as $key=>$aEs){
			$aSub = $oEsIndex->get('`id`,`subject_id`,`type_id`',array('id'=>$aEs['id']));
			if(!in_array($aSub[0]['subject_id'],array(1,2,3))){
				continue;
			}

			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aSub[0]['type_id']]);
			$aEs2 = $oEsPlugin->resolve($aEs['content_json']);
			$GLOBALS['_isUpdata'] = false;
			array_walk_recursive($aEs2, 'removeImg', $aSub[0]);
			if($GLOBALS['_isUpdata']){
				$aEsCorrectContent = $oEsPlugin->build($aEs2);
				//$result1 = $oEs->update($aEsCorrectContent, array('id' => $aEs['id']));
				if($result1){
					echo 'id为' . $aEs['id'] . '数据库旧路径修改成功！<br><br>';
				}else{
					echo 'id为' . $aEs['id'] . '数据库旧路径修改<font style="color:#f00;">失败！</font><br><br>';
				}
			}
		}
		unset($GLOBALS['_isUpdata']);
	}

	//自动发PK
	public function autoSendPk(){
		$aUserIds = array(19577027,86197546,36953465,26326559,82377707,45074914,41934114,24626985,65168048,34043775,11935701,59840388,32472576,10218065,97610494,41121618,29415978,43253324,41975342,39492803,67727703,58313929,16909681,22357414,93331358,69646970,15209394,20869492,57989971,16488460,17103901,41797061,85618206,80943906,98397886,64821292,99479555,35392067,93157395,87391526,35557091,95878133,50003641,49655464,65564339);
		$sendCount = 10;		//每关发起场次配置
		$limitCount = 5;	//PK场每关最少场次
		$currentTime = time();
		//检测大于最少场次的关卡
		$where = '`receiver_user_id`=0 AND `over_time`>' . $currentTime;
		$groupBy = '`mission_id`';
		$oPkIndex = new Model(T_PK_INDEX);
		$aPkCountList = $oPkIndex->get('`mission_id`,count(*) as `nums`', $where, '', '', '', $groupBy);
		$aEnoughMissionIds = array();
		foreach($aPkCountList as $aPkCount){
			if($aPkCount['nums'] >= $limitCount){
				$aEnoughMissionIds[] = $aPkCount['mission_id'];
			}
		}
		unset($aPkCountList);
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`', '`is_forbidden` = 0 AND `grade` >= 5 AND `grade` <= 9');
		$aAllMissionIds = array();
		foreach($aMissionList as $aMission){
			$aAllMissionIds[] = $aMission['id'];
		}
		$aMissionIds = array_diff($aAllMissionIds, $aEnoughMissionIds);
		if(!$aMissionIds){
			alert('不需要添加数据', 1);
		}
		$oEs = m('Es');
		$oPk = new Model(T_PK);
		foreach($aMissionIds as $missionId){
			$where = '`receiver_user_id`=0 AND `over_time`>' . $currentTime . ' AND `mission_id`=' . $missionId;
			$aMissionPkUserList = $oPkIndex->get('`sender_user_id`', $where);
			$aExceptUserIds = array();
			foreach($aMissionPkUserList as $aMissionPkUser){
				$aExceptUserIds[] = $aMissionPkUser['sender_user_id'];
			}
			$aRemindUserIds = array_diff($aUserIds, $aExceptUserIds);
			$aKeys = array_rand($aRemindUserIds, $sendCount);
			$currentTime = time();
			$aMissionInfo = $oMission->get('category_ids', array('id' => $missionId));
			foreach($aKeys as $key){
				$userId = $aRemindUserIds[$key];
				$senderUserStartTime = $currentTime + rand(1, 60);
				//用户在此关卡发起一场PK到PK场
				$aPkIndexData = array();
				$aPkIndexData['sender_user_id'] = $userId;
				$aPkIndexData['receiver_user_id'] = 0;
				$aPkIndexData['sender_user_start_time'] = $senderUserStartTime;
				$aPkIndexData['sender_user_end_time'] = $senderUserStartTime + rand(120, 240);
				$aPkIndexData['receiver_user_start_time'] = 0;
				$aPkIndexData['receiver_user_end_time'] = 0;
				$aPkIndexData['receiver_score'] = 0;
				$aPkIndexData['create_time'] = $currentTime;
				$aPkIndexData['duration'] = 5;
				$aPkIndexData['over_time'] = $currentTime + 7 * 24 * 3600;
				$aPkIndexData['mission_id'] = $missionId;
				$aPkIndexData['es_counts'] = 5;
				$aPkIndexData['attachment_gold'] = 0;
				$aPkIndexData['is_receive_attachment'] = 2;
				$aPkIndexData['winner_user_id'] = 2;
				$aPkIndexData['is_receive_prize'] = 0;
				$aPkIndexData['delete_user_id'] = 0;
				//抽题目
				$aEsResult = $oEs->getEsIdsByCategoryId(explode(',', $aMissionInfo[0]['category_ids']), 5);
				$aSenderEsList = array();
				$aReceiverEsList = array();
				$correctEsCount = 0;
				foreach($aEsResult as $esId){
					$esFlag = rand(0, 1);
					$aSenderEsList[$esId] = $esFlag;
					$aReceiverEsList[$esId] = 2;
					if($esFlag){
						$correctEsCount++;
					}
				}
				$totalTime = $aPkIndexData['duration'] * 60;
				if($correctEsCount){
					$score = intval(($totalTime - ($aPkIndexData['sender_user_end_time'] - $aPkIndexData['sender_user_start_time'])) / $totalTime * 2000 + 8000 * $correctEsCount / $aPkIndexData['es_counts']);
				}else{
					$score = 0;
				}
				$aPkIndexData['sender_score'] = $score;
				$pkId = $oPkIndex->add($aPkIndexData);
				if(!$pkId){
					alert('向pk_index表插入数据失败,mission_id:' . $missionId, 0);
				}
				$aContent = array(
					'sender_es_list'	=> $aSenderEsList,
					'receiver_es_list'	=> $aReceiverEsList
				);
				$aPkData = array();
				$aPkData['id'] = $pkId;
				$aPkData['content'] = json_encode($aContent);
				$result = $oPk->add($aPkData);
				if(!$result){
					alert('向pk表插入数据失败,pk_id:' . $pkId, 0);
				}
			}
		}
		alert('添加PK数据成功!!', 1);
	}

	//删除高中PK及事件
	public function deleteHighPk(){
		$oMission = new Model(T_MISSION);
		$aHighMissionList = $oMission->get('id', '`grade` > 9 OR `grade` < 5');
		if(!$aHighMissionList){
			exit('没有高中关卡啊逗比');
		}
		$aMissionId = array();
		foreach($aHighMissionList as  $aMission){
			$aMissionId[] = $aMission['id'];
		}
		$missionIds = implode(',' , $aMissionId);

		$oPkIndex = new Model(T_PK_INDEX);
		$oPk = new Model(T_PK);
		$aPkList = $oPkIndex->get('id', '`mission_id` IN (' . $missionIds . ')');
		if(!$aPkList){
			exit('没有高中PK啊逗比');
		}
		$aPkId = array();
		foreach($aPkList as  $aPk){
			$aPkId[] = $aPk['id'];
		}
		$pkIds = implode(',' , $aPkId);
		$deletePk = $oPk->delete('`id` IN (' . $pkIds . ')');
		$deletePkIndex = $oPkIndex->delete('`id` IN (' . $pkIds . ')');
		if(!$deletePk || !$deletePkIndex){
			echo '删除PK出错<br>';
		}

		$oEvent = new Model(T_SNS_EVENT);
		$deleteEvent = $oEvent->delete('`data_id` IN (' . $pkIds . ') AND `type` IN(14,15,16)');
		if($deleteEvent === false){
			echo '删除PK事件出错<br>';
		}
		exit('删除成功咯！等放假咯！');
	}


	//删除两个没用的关卡
	public function deleteMission(){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result = $oDboi->table(T_MISSION)->where(array('id'=>array('in', array(936,958))))->delete();
		if(!$result){
			return $result;
		}

		$result2 = $oDboi->table(T_MISSION_USER_RELATION)->where(array('id'=>array('in', array(936,958))))->delete();
		if(!$result2){
			$oDboi->rollBack();
			return false;
		}

		/*$oMission->delete(array('id'=>array('in', array(936,958))));
		$oMission2 = new Model(T_MISSION_USER_RELATION);
		$oMission2->delete(array('id'=>array('in', array(936,958)))); */

		//删除好友动态
		/* $oMission3 = new Model(T_MISSION_USER_RELATION_INDEX);
		$oPk = new Model(T_PK_INDEX);
		$aMissionList = $oMission3->get('`id`','mission_id in (936,958)');
		$aMissionId = array();
		foreach($aMissionList as $aMission){
			$aMissionId[] = $aMission['id'];
		}

		$aPkList = $oPk->get('`id`', 'mission_id in (936,958)');
		$aPkIds = array();
		foreach($aPkList as $aPk){
			$aMissionId[] = $aPk['id'];
			$aPkIds[] = $aPk['id'];
		}
		if($aMissionId){
			$oSns = new Model(T_SNS_EVENT);
			$oSns->delete('data_id in (' . implode(',', $aMissionId) . ')');
		}

		//删除与我相关
		if($aPkIds){
			$oPersonal = new Model(T_PERSONAL_MESSAGE);
			$oPersonal->delete('data_id in (' . implode(',', $aPkIds) . ')');
		}
		$oMission3->delete('mission_id in (936,958)');

		$oPk->delete('mission_id in (936,958)'); */
	}

	public function showTools(){
		display('tools/index.html.php');
	}

	/**
	 * 清除指定表的缓存
	 */
	public function flushCache(){
		$table = (string)get('table');
		if(!$table){
			$table = (string)post('table');
			if(!$table){
				alert('缺少表名', 0);
			}
		}
		$oRedis = new Redis();
		$oRedis->connect($GLOBALS['DB_CONFIG']['REDIS_SERVER']['redis_1']['host']);
		$oRedis->auth($GLOBALS['DB_CONFIG']['REDIS_SERVER']['redis_1']['password']);
		$flushKey = '';
		if($table == '_login'){
			//清除登陆
			$oRedis->select($GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
			$flushKey = 'user_login:*';
		}else{
			$oRedis->select($GLOBALS['DB_CONFIG']['REDIS_PART']);
			$flushKey = 'umfun:' . $table . ':*';
		}

		$aKeys = $oRedis->keys($flushKey);
		$flushCount = count($aKeys);
		foreach($aKeys as $key){
			if(!$oRedis->del($key)){
				alert($key . ' 清理失败<br />', 0);
				$flushCount--;
			}
		}
		alert('共清理了 ' . $flushCount . ' 个缓存数据', 1);
	}

	/**
	 * 解除和教育用户的绑定
	 */
	public function unbindThirdPartyUser(){
		$type = (int)post('type');
		$userId = (int)post('user_id');

		$oDb = new DBOI();
		$aUserList = $oDb->table(T_USER)->where(array('id' => $userId))->select();
		if(!$aUserList){
			alert('找不到该用户', 0);
		}
		$aUser = $aUserList[0];
		if($type == 1 && !$aUser['qq_open_id']){
			alert('该用户没有关联第三方账号', 0);
		}elseif($type == 2 && !$aUser['xxt_id']){
			alert('该用户没有关联第三方账号', 0);
		}

		$aSaveUser = array('id' => $aUser['id']);
		if($type == 1){
			$aSaveUser['qq_open_id'] = '';
		}elseif($type == 2){
			$aSaveUser['xxt_type'] = 0;
			$aSaveUser['xxt_id'] = 0;
		}

		$result = m('User')->setUserIndexInfo($aSaveUser);
		if($result){
			alert('解绑成功', 1, $aUser);
		}else{
			alert('解绑失败', 0, $aSaveUser);
		}
	}

	/**
	 * 绑定第三方用户账号
	 */
	public function bindThirdPartyUser(){
		$type = (int)post('type');
		$userId = (int)post('user_id');
		$thirdPartyUserId = '';
		if($type == 1){
			$thirdPartyUserId = post('qq_open_id');
			if(!preg_match('/[a-zA-Z]+/', $thirdPartyUserId)){
				alert('错误的openId', 0);
			}
		}elseif($type == 2){
			$thirdPartyUserId = (int)post('xxt_user_id');
			if($thirdPartyUserId < 1){
				alert('错误的和教育用户Id', 0);
			}
		}
		$oUser = m('User');
		$aUser = getUserInfo($userId, array('personal'));
		if(!$aUser){
			alert('找不到该用户', 0);
		}elseif($type == 1 && $aQQUser = $oUser->getUserInfoByQqOpenId($thirdPartyUserId)){
			alert('该和教育账号已经绑定了其它账号:' . $aQQUser['id'], 0);
		}elseif($type == 2 && $aXxtUser = $oUser->getUserInfoByXxtId($thirdPartyUserId)){
			alert('该和教育账号已经绑定了其它账号:' . $aXxtUser['id'], 0);
		}

		$aSaveUser = array('id' => $aUser['id']);
		if($type == 1){
			$aSaveUser['qq_open_id'] = $thirdPartyUserId;
		}else{
			$aSaveUser['xxt_id'] = $thirdPartyUserId;
		}
		$result = $oUser->setUserIndexInfo($aSaveUser);

		if($result){
			alert('绑定成功', 1);
		}else{
			alert('绑定失败', 0);
		}
	}

	public function deleteParent(){
		$id = (int)post('id');
		$oDb = new DBOI();
		$row = $oDb->table(T_PARENT)->where('id = ' . $id)->delete();
		if($row){
			alert('删除成功', 1);
		}else{
			alert('删除失败');
		}
	}

	private function _getEsGradeByCategoryId($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$aEsCategoryInfo = $oEsCategory->get('', array('id' => $categoryId));
		if(!$aEsCategoryInfo){
			return false;
		}else{
			$this->_aCategory[] = $aEsCategoryInfo[0];
			if($aEsCategoryInfo[0]['parent_id']){
				return $this->_getEsGradeByCategoryId($aEsCategoryInfo[0]['parent_id']);
			}else{
				if(count($this->_aCategory) >= 2){
					$aGradeCategoryInfo = array_slice($this->_aCategory, -2, 1);
					$categoryName = $aGradeCategoryInfo[0]['name'];
					if(is_int(strpos($categoryName, '五年级'))){
						return 5;
					}elseif(is_int(strpos($categoryName, '六年级'))){
						return 6;
					}elseif(is_int(strpos($categoryName, '七年级'))){
						return 7;
					}elseif(is_int(strpos($categoryName, '八年级'))){
						return 8;
					}elseif(is_int(strpos($categoryName, '九年级'))){
						return 9;
					}else{
						return false;
					}
				}else{
					return false;
				}
			}
		}
	}

	/**
	 * 将选项小于4个的题目找出来
	 */
	public function showChoiceEsForGt4Options(){
		$subject = (int)get('subject', 1);
		$g79 = get('g') ? true : false;
		assign('g79', $g79);
		$oDb = new DBOI();
		$aTmpCategoryList = $oDb->table(T_ES_INDEX)->fields('ec.id,ec.name')->leftjoin(T_ES_CATEGORY, 'as ec on t1.category_id = ec.id')->where('type_id in(1,2) and t1.subject_id = ' . $subject)->groupby('category_id')->select();
		$aCategoryList = array();
		$aEsCategoryGroupList = array();

		$allCount = 0;
		foreach ($aTmpCategoryList as $i => $aTmpCategory) {
			$categoryId = &$aTmpCategory['id'];
			if($g79 && !in_array($this->_getEsGradeByCategoryId($categoryId), range(7, 9))){
				continue;
			}

			$aCategoryList[$categoryId] = $aTmpCategory;
			$aEsList = $oDb->table(T_ES_INDEX)->fields('es.id,es.content_json as es_content,t1.type_id,t1.subject_id')->leftjoin(T_ES, 'on t1.id = es.id')->where('status = 5 and type_id in(1,2) and t1.category_id =' . $categoryId)->select();
			foreach ($aEsList as $j => &$aEs) {
				$aEs['es_content'] = json_decode($aEs['es_content'], 1);
				$optionCount = count($aEs['es_content']['option']);
				if($optionCount > ($g79 ? 3 : 2)){
					unset($aEsList[$j]);
				}

				if($optionCount < ($g79 ? 4 : 3)){
					$allCount++;
				}
			}

			if($aEsList){
				$aEsCategoryGroupList[$categoryId] = $aEsList;
			}
		}


		assign('allCount', $allCount);
		assign('aCategoryList', $aCategoryList);
		assign('aEsCategoryGroupList', $aEsCategoryGroupList);
		display('tools/gt4option.html.php');
	}

	public function decryptEsId(){
		$encryptId = (string)post('encrypt_id');
		alert(Xxtea::decrypt($encryptId), 1);
	}

	public function loginUser(){
		$userId = (int)post('user_id');
		$typeId = (int)post('type');
		$isLogin = false;
		if($typeId == 1){
			$isLogin = User::loginUser($userId);
		}elseif($typeId == 2){
			$isLogin = Parents::loginUser($userId, true);
		}else{
			alert('未知的登陆类型', 0);
		}

		if($isLogin){
			alert('登陆成功', 1);
		}else{
			alert('登陆失败', 0);
		}
	}

	public function logoutUser(){
		$userId = (int)post('user_id');
		$typeId = (int)post('type');
		$isLogout = false;
		if($typeId == 1){
			$isLogout = User::logoutUser($userId);
		}elseif($typeId == 2){
			$isLogout = Parents::logoutUser($userId);
		}else{
			alert('未知的注销类型', 0);
		}

		if($isLogout){
			alert('注销成功', 1);
		}else{
			alert('注销失败', 0);
		}
	}

	/**
	 * 获取日志列表
	 */
	public function getLogsList(){
		$aLogModules = array();
		$hasLog = false;
		foreach(scandir(SYSTEM_LOG_PATH) as $pathName){
			if($pathName == '.' || $pathName == '..' || $pathName == '.svn' || !is_dir(SYSTEM_LOG_PATH . $pathName)){
				continue;
			}

			$aModule = array(
				'name' => $pathName,
				'log_count' => count(scandir(SYSTEM_LOG_PATH . $pathName)) - 3,
			);
			if($aModule['log_count']){
				$hasLog = true;
			}
			$aLogModules[] = $aModule;
		}

		if($hasLog){
			usort($aLogModules, function($aItem1, $aItem2){
				if($aItem1['log_count'] == $aItem2['log_count']){
					return 0;
				}else{
					return $aItem1['log_count'] < $aItem2['log_count'] ? 1 : -1;
				}
			});

			alert('日志列表', 1, $aLogModules);
		}else{
			alert('程序动作状态非常好,暂时没产生任何日志', -1);
		}
	}

	/**
	 * 下载日志文件
	 */
	public function downloadLogFiles(){
		$logsZip = SYSTEM_LOG_PATH . 'umfunlogs' . date('Y-m-d_H_i_s') . '.zip';
		exec('zip -r ' . $logsZip . ' -b ' . SYSTEM_LOG_PATH . ' ../../logs/*');
		$fileSize = filesize($logsZip);
		header('Content-type: application/octet-stream');
		header('Accept-Ranges: bytes');
		header('Accept-Length: ' . $fileSize);
		header('Content-Disposition: attachment; filename=' . basename($logsZip));
		$file = fopen($logsZip, 'r');
		$offset = 0;
		$buffer = 1024;
		while(!feof($file) && $offset < $fileSize){
			$content = fread($file, $buffer);
			$offset += $buffer;
			echo $content;
		}
		fclose($file);

		$backupPath = SYSTEM_ROOT_PATH . '../data/logs_backup/';
		if(!is_writeable($backupPath)){
			unlink($logsZip);
		}else{
			rename($logsZip, $backupPath . basename($logsZip));
		}

		exec('find ' . SYSTEM_LOG_PATH . ' -name \'*\\.log\' | xargs rm -f');
	}

	public function checkStudentLoginInfo() {
		$id = (int)post('id');
		$aLoginInfo = User::getUserLoginInfo($id);
		if(!$aLoginInfo){
			alert('登陆信息中找不到该用户的数据', 0);
		}else{
			alert('', 1, $aLoginInfo);
		}
	}
}

function putcol($str = ''){
	echo $str . "\t";
}