<?php

class EsFeedbackController{

	private $_userId;
	private $_permissionFlag = 'manage_es_feedback';

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('抱歉！您无权进行操作，请联系管理员！', 0);
		}
	}

	public function showList(){
		$aAllowSubject = m('Manager')->getUserAllowedSubjectByUserId($this->_userId);
		if($aAllowSubject === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aAllowSubject){
			alert('没有可操作的科目', 0);
		}
		$subjectId = intval(get('subject_id'));
		if($subjectId < 1){
			$subjectId = Cookie::getDecrypt('lastSubjectId');
			if($subjectId < 1){
				$subjectId = $aAllowSubject[0];
			}
		}
		if(!in_array($subjectId, $aAllowSubject)){
			alert('抱歉，您没有操作这一科目的权限！', 0);
		}
		$aAllowedSubject = array();
		foreach($aAllowSubject as $allowSubjectId){
			if(isset($GLOBALS['SUBJECT'][$allowSubjectId])){
				$aAllowedSubject[$allowSubjectId] = $GLOBALS['SUBJECT'][$allowSubjectId];
			}
		}
		$pageSize = 15;
		$page = intval(get('page', 1));
		if($page < 1){
			$page = 1;
		}
		$oEs = m('Es');
		$feedbackCount = $oEs->getEsFeedbackCount($subjectId, 1);
		if($feedbackCount === false){
			alert('系统有误，请稍后再试！', 0);
		}
		$aFeedbackList = m('Es')->getEsFeedbackList($subjectId, 1, $page, $pageSize, '`create_time` desc');
		if($aFeedbackList === false){
			alert('系统有误，请稍后再试！', 0);
		}
		foreach($aFeedbackList as $key => $aFeedback){
			$feedbackCounts = $oEs->getEsFeedbackCountByEsId($aFeedback['es_id']);
			if($feedbackCounts === false){
				alert('系统有误，请稍后再试！', 0);
			}
			$aFeedbackList[$key]['feedback_counts'] = $feedbackCounts;
		}

		$url = 'http://' . APP_MANAGE . '/?m=EsFeedback&a=showList&subject_id=' . $subjectId;
		$oUser = m('User');
		$oManager = m('Manager');
		$oMission = m('Mission');
		foreach($aFeedbackList as $feedbackKey => $aFeedback){
			if($aFeedback['user_type'] == 1){
				$aUserInfo = $oUser->getUserDetailInfoByUserId($aFeedback['user_id']);
				if($aUserInfo === false){
					alert('抱歉！系统出错，请稍后再试！', 0);
				}
				$name = '';
				if(isset($aUserInfo['name'])){
					$name = $aUserInfo['name'];
				}
			}else{
				$name = $oManager->getUserNameByUserId($aFeedback['user_id']);
				if($name === false){
					alert('抱歉！系统出错，请稍后再试！', 0);
				}
			}
			$aFeedbackList[$feedbackKey]['user_name'] = $name;
			$aEsInfo = $oEs->getEsInfoByEsId($aFeedback['es_id']);
			if($aEsInfo === false){
				alert('系统错误，请稍后再试！', 0);
			}
			$aFeedbackList[$feedbackKey]['content_text'] = isset($aEsInfo['content_text']) ? $aEsInfo['content_text'] : '--';
			$aMissionInfo = $oMission->getMissionInfoById($aFeedback['mission_id']);
			if($aMissionInfo === false){
				alert('系统错误，请稍后再试！', 0);
			}
			$missionName = '';
			if(isset($aMissionInfo['name'])){
				$missionName = $aMissionInfo['name'];
			}
			$aFeedbackList[$feedbackKey]['mission_name'] = $missionName;
		}
		$pageHtml = page(array(
			'url' => $url . '&page=_PAGE_',
			'total' => $feedbackCount,
			'selector' => 1,
			'size' => $pageSize,
			'page' => $page,
		));
		Cookie::setEncrypt('lastSubjectId', $subjectId);
		assign('aFeedbackList', $aFeedbackList);
		assign('subjectId', $subjectId);
		assign('aSubject', $aAllowedSubject);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('es_feedback/feedback_list.html.php');
		displayFooter();
	}

	public function showEsFeedbackDetail(){
		$esId = (int)get('es_id');
		$oEs = m('Es');
		$mEs = \common\model\Es::findOne($esId);
		if(!$mEs){
			alert('抱歉！这条题目不存在！', 0);
		}
		$this->_checkAllowedSubject($mEs['subject_id']);
		assign('status', $mEs['status']);

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$mEs['type_id']];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$mEs['subject_id']])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		assign('sameBaseEsType', $sameBaseEsType);
		assign('aSameEsTypeId', $aSameEsTypeId);
		assign('aCategoryList', Es::getCategoryTreeListBySubjectId($mEs['subject_id']));
		assign('categoryId', $mEs['category_id']);
		assign('subjectId', $mEs['subject_id']);
		assign('esType', $mEs['type_id']);
		assign('aEs', $mEs->toArray());
		$aEsFeedbackList = $oEs->getEsFeedbackListByEsId($esId, 1);
		if($aEsFeedbackList === false){
			alert('系统有误，请稍后再试！', 0);
		}

		$oUser = m('User');
		$oManager = m('Manager');

		foreach($aEsFeedbackList as $key => &$aEsFeedback){
			if($aEsFeedback['user_type'] == 1){
				$aUserInfo = $oUser->getUserDetailInfoByUserId($aEsFeedback['user_id']);
				if($aUserInfo === false){
					alert('系统有误！请稍后再试！', 0);
				}
				$aEsFeedback['user_name'] = $aUserInfo['name'];
			}else{
				$name = $oManager->getUserNameByUserId($aEsFeedback['user_id']);
				$aEsFeedback['user_name'] = $name;
			}
		}
		assign('aEsFeedbackInfo', $aEsFeedbackList);
		assign('esId', $mEs['id']);
		displayHeader();
		display('es_feedback/feedback_detail.html.php');
		displayFooter();
	}

	public function editFeedback(){
		$aHandleParam = post('param');
		if(!is_array($aHandleParam)){
			alert('参数错误', 0);
		}
		$action = intval(post('action')) == 1 ? 1 : 2;

		$oEs = m('Es');
		$oSns = m('Sns');
		$oGame = new Game();
		foreach($aHandleParam as $key => $aParam){
			$aFeedBack = $oEs->getEsFeedbackInfoById(intval($aParam['id']));
			if(!$aFeedBack){
				alert('找不到该反馈,可能已被处理', 0);
			}elseif($aFeedBack['status'] != 1){
				alert('抱歉,该反馈已被处理', 0);
			}
			$this->_checkAllowedSubject($aFeedBack['subject_id']);

			$aFeedBack['status'] = $action == 1 ? 2 : 3;
			if($aFeedBack['user_type'] == 1){
				if($action == 1){
					//奖励前端用户
					$aFeedBack['reward']['gold'] = $GLOBALS['GOLD']['feedback_wrong_es'];
				}else{
					$aFeedBack['reply'] = strval($aParam['reply']);
				}
			}

			$row = $oEs->setEsFeedback($aFeedBack);
			if($row === false){
				alert('第' . ($key + 1) . '条反馈处理出错', 0, 'reload');
			}elseif(!$row){
				alert('第' . ($key + 1) . '条反馈处理失败', 0, 'reload');
			}

			if($aFeedBack['user_type'] == 1){
				if($action == 1){
					//奖励前端用户
					if(!$oGame->rewardFeedbackWrongEs($aFeedBack['user_id'])){
						alert('抱歉！系统出错，请稍后再试！', 0);
					}
				}

				//发送处理消息
				$oSns->addPersonalMessage(array(
					'user_id' => $aFeedBack['user_id'],
					'type' => 10,
					'data_id' => $aFeedBack['id'],
				));
			}
		}

		alert('处理完毕');
	}

	/**
	 * 修改题目
	 */
	public function editEs(){
		$aEs = array();

		//题目信息
		$aEs['id'] = post('id');
		if(!($aEs['id'] >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($aEs['id']);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}

		$aFeedbackEs = $oEs->getEsFeedbackListByEsId($aEs['id']);
		if($aEsInfo['status'] != 5 || !$aFeedbackEs){
			alert('不是反馈的题目不能修改', 0);
		}

		//科目ID
		$subjectId = post('subject_id');
		if(!($subjectId >= 1)){
			alert('非法的科目ID', 0);
		}

		//题目类型
		$esType = post('es_type');
		if(!($esType >= 1)){
			alert('非法的题目类型ID', 0);
		}

		//调用题目插件
		$oEsPlugin = $this->_esFactory($subjectId, $esType);
		if(!is_object($oEsPlugin)){
			alert('错误的科目或题型', 0);
		}
		$aEsMainContent = $oEsPlugin->build($_POST['es']);
		if($oEsPlugin->getError()){
			alert($oEsPlugin->getError(), 0);
		}
		$aEs['content_json'] = $aEsMainContent['content_json'];
		$aEs['content_text'] = $aEsMainContent['content_text'];

		//检查目录
		$aEs['category_id'] = post('category_id');
		if(!($aEs['category_id'] >= 1)){
			alert('非法的目录ID', 0);
		}else{
			$categoryExists = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
			if(!$categoryExists){
				alert('目录不存在', 0);
			}
		}
		$childNums = $oEs->isExistSubCategory($aEs['category_id']);
		if($childNums > 0){
			alert('选择的目录不是最底层目录，请检查', 0);
		}

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$esType];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$subjectId])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		if($sameBaseEsType >= 2){
			$aEs['type_id'] = post('es_type');
			if(!in_array($aEs['type_id'], $aSameEsTypeId)){
				alert('错误的题型', 0);
			}
		}

		//检查是否存在相同题干的题目
		if(intval(get('ignore_same_es')) == 0){
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				$aSameEsIdList = array();
				foreach($aSameEsList as $aSameEs){
					$aSameEsIdList[] = $aSameEs['id'];
				}
				alert('检测到正式题库中已经存相似的题目,是否继续保存?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
			}
		}
		$isUpdataEs = $oEs->setEs($aEs);
		if($isUpdataEs || $isUpdataEs === 0){
			alert('编辑题目成功', 1, 'reload');
		}else{
			alert('编辑题目失败', 0);
		}
	}

	public function deleteFeedback(){
		$esId = intval(post('es_id'));
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if($aEsInfo === false){
			alert('系统有误，请稍后再试！', 0);
		}
		$this->_checkAllowedSubject($aEsInfo['subject_id']);
		$row = $oEs->deleteEsFeedbackByEsId($esId);
		if($row === false){
			alert('抱歉！系统错误，请稍后再试！', 0);
		}elseif($row){
			alert('删除成功！');
		}else{
			alert('删除失败！', 0);
		}
	}

	private function _checkAllowedSubject($subjectId){
		$aAllowSubjectId = m('Manager')->getUserAllowedSubjectByUserId($this->_userId);
		if($aAllowSubjectId === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aAllowSubjectId){
			alert('没有可操作的科目', 0);
		}
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('抱歉！您选的科目有误，请联系管理员！', 0);
		}
		if(!in_array($subjectId, $aAllowSubjectId)){
			alert('您没有管理这一科目的权限', 0);
		}
	}

	/**
	 * 生产插件对象的工厂
	 * @param type $subject
	 * @param type $esType
	 * @return type
	 */
	private function _esFactory($subject, $esType){
		if(!is_numeric($subject) || !is_numeric($esType)){
			wrong('参数错误');
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			wrong('不存在此科目');
		}
		if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
			wrong('不存在此题型');
		}
		if(!in_array($esType, $GLOBALS['SUBJECT_TYPE'][$subject])){
			wrong($GLOBALS['SUBJECT'][$subject] . '科目不存在' . $GLOBALS['ES_TYPE'][$esType]);
		}
		$oEs = esPlugin($GLOBALS['TYPE_RESOLVER'][$esType]);
		return $oEs;
	}

}