<?php
class HelperController{

	/**
	 * 图片上传
	 */
	public static function uploadImage(){
		$filePrefix = str_replace(array('0.', ' '), '', microtime()) . '_' . rand(10000, 99999);
		$oUploader = new UploadFile(512000, 'gif,jpg,jpeg,png,bmp', '', SYSTEM_RESOURCE_PATH . ES_IMAGE_PATH, $filePrefix);
		$uploadFileInfo = $oUploader->uploadOne($_FILES['Filedata']);
		if(!$uploadFileInfo){
			alert('文件上传失败', 0);
		}
		$uploadFileInfo = $uploadFileInfo[0];
		alert(SYSTEM_RESOURCE_URL . '/' . ES_IMAGE_PATH . $uploadFileInfo['savename'], 1, ES_IMAGE_PATH . $uploadFileInfo['savename']);
	}
}