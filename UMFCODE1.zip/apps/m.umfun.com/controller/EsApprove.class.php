<?php
class EsApproveController{

	private $_permissionFlag = 'approve_es';
	private $_userId = 0;
	private $_aEsStatus  = array(
		2	=> '待审核',
		3	=> '待复核',
		5	=> '已复核',
		6	=> '复核不通过'
	);
	private $_startDays = 7;	//默认开始时间是7天前
	private $_aTimeType = array(
		3 => '审核时间',
		5 => '复核时间'
	);

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('您没有权限对此操作', 0);
		}
	}

	/**
	 * 显示题目列表
	 */
	public function showList(){
		$url = '?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);

		//题目状态
		$esStatus = get('esStatus', 2);
		if($esStatus){
			if(!array_key_exists($esStatus, $this->_aEsStatus)){
				alert('错误的题目状态');
			}
			$url .= '&esStatus=' . $esStatus;
		}
		assign('esStatus', $esStatus);

		$oEs =  m('Es');
		if($esStatus != 6){
			//检查是否有复核不通过的题目
			$needFinishEsNums = $oEs->isExistEsNeedFinishByApproverId($this->_userId);
			if($needFinishEsNums){
				displayHeader();
				echo '<script type="text/javascript">UBox.show("您有 ' . $needFinishEsNums . ' 道复核未通过的题目超过1天未处理，请先处理", 0, "?m=EsApprove&a=showList&esStatus=6", 4);</script>';
				displayFooter();
				return;
			}
		}

		//处理搜索条件

		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowedSubject = array();
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		foreach($aAllowSubjectId as $subjectId){
			if(isset($GLOBALS['SUBJECT'][$subjectId])){
				$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
			}
		}
		if(!$aAllowedSubject){
			alert('没有可操作的科目', 0);
		}
		$subject = get('subject', 0);
		if(!$subject){
			$subject = $aAllowSubjectId[0];
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		if(!in_array($subject, $aAllowSubjectId)){
			alert('您没有权限操作此科目', 0);
		}
		$url .= '&subject=' . $subject;
		assign('aSubject', $aAllowedSubject);
		assign('subjectId', $subject);

		//题目类型
		$esType = get('esType', 0);
		if($esType){
			if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
				alert('不存在此题型', 0);
			}
			$url .= '&esType=' . $esType;
		}
		assign('esTypeId', $esType);

		//分页数
		$page = (int)get('page');
		$pageSize = 10;
		if($page < 1){
			$page = 1;
		}

		if($esStatus != 2){
			//时间
			$timeType = intval(get('timeType'));
			if(!array_key_exists($timeType, $this->_aTimeType)){
				$timeType = 3;
			}
			$startTime = get('startTime');
			$endTime = get('endTime');
			$url .= '&timeType=' . $timeType;
			assign('timeType', $timeType);

			//开始时间
			if(!$startTime){
				$startTimeStamp = 0;
			}else{
				$startTimeStamp = strtotime($startTime);
				$url .= '&startTime=' . $startTime;
			}
			if(isset($_COOKIE['approveStartTime'])){
				$startTime = $_COOKIE['approveStartTime'];
			}else{
				setcookie('approveStartTime', $startTime, time() + 3600 * 24 * 30, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
			}
			assign('startTime', $startTime);

			//结束时间
			if(!$endTime){
				$endTimeStamp = time();
			}else{
				$endTimeStamp = strtotime($endTime);
				$url .= '&endTime=' . $endTime;
			}
			if(isset($_COOKIE['approveEndTime'])){
				$endTime = $_COOKIE['approveEndTime'];
			}else{
				setcookie('approveEndTime', $endTime, time() + 3600 * 24 * 30, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
			}
			assign('endTime', $endTime);

			//题目列表
			$esNums = $oEs->getEsCountByApprover($timeType, $startTimeStamp, $endTimeStamp, $this->_userId, $subject, $esType, $esStatus);
			$aEsList = $oEs->getEsListByApprover($page, $pageSize, $this->_userId, $startTimeStamp, $endTimeStamp, $timeType, $subject, $esType, $esStatus);
			$viewFile = 'es_approve/list.html.php';

			//分页HTML
			$aPageInfo = array(
				'url' => $url . '&page=_PAGE_',
				'total' => $esNums,
				'selector' => 1,
				'size' => $pageSize,
				'page' => $page
			);
			$pageHtml = page($aPageInfo);
			assign('pageHtml', $pageHtml);
		}else{
			$aEsList = $oEs->getWaitApproveEsByApprover($this->_userId, $subject, $page, $pageSize, $esType);
			$viewFile = 'es_approve/approve.html.php';
		}
		$aEsPlugin = array();	//存放题目插件对象的数组
		foreach($aEsList as $keyNum => &$aEs){
			$aEs['same_ids'] = array();
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				foreach($aSameEsList as $aSameEs){
					$aEs['same_ids'][] = $aSameEs['id'];
				}
			}

			if(!isset($aEsPlugin[$aEs['subject_id']][$aEs['type_id']])){
				$aEsPlugin[$aEs['subject_id']][$aEs['type_id']] = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
			}
			$aEsList[$keyNum]['es_content'] = $aEsPlugin[$aEs['subject_id']][$aEs['type_id']]->resolve($aEs['content_json']);
			unset($aEsList[$keyNum]['content_json']);
		}
		unset($aEsPlugin);
		assign('aEsList', $aEsList);
		assign('aTimeType', $this->_aTimeType);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aStatus', $this->_aEsStatus);
		displayHeader();
		display($viewFile);
		displayFooter();
	}


	/**
	 * 显示修改题目的界面
	 */
	public function showStatistic(){
		$aDayType = array(
				1 => 3,
				2 => 7,
				3 => 15,
				4 => 30
		);
		assign('aDayType', $aDayType);
		$dayType = get('dayType', 0);
		assign('dayType', $dayType);
		if($dayType){
			if(!array_key_exists($dayType, $aDayType)){
				wrong('错误的类型');
			}

			$endTime = time();
			$startTime = $endTime - 86400 * $aDayType[$dayType];
		}else{
			$startTime = get('startTime');
			$endTime = get('endTime');
			if(!$startTime){
				$startTime = time() - 86400 * 7;
			}else{
				$startTime = strtotime($startTime);
			}
			if(!$endTime){
				$endTime = time();
			}else{
				$endTime = strtotime($endTime);
			}
		}
		assign('startTime', $startTime);
		assign('endTime', $endTime);

		$oEs = m('Es');
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		$aStatistic = array();
		foreach($aAllowSubjectId as $key => $subjectId){
			foreach($GLOBALS['SUBJECT_TYPE'][$subjectId] as $esTypeId){
				$aStatistic[$subjectId][$esTypeId] = $oEs->getStatisticsForApprove($startTime, $endTime, $this->_userId, $subjectId, $esTypeId);
			}
		}
		assign('aStatistic', $aStatistic);

		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);
		displayHeader();
		display('es_approve/statistic.html.php');
		displayFooter();

	}

	/**
	 * 显示修改题目的界面
	 */
	public function showEdit(){
		$esId = get('esId');
		if(!($esId >= 1)){
			wrong('非法的题目ID');
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			wrong('指定的题目不存在');
		}
		if($this->_checkAllowSubject($aEsInfo['subject_id'])){
			wrong('您没有权限操作此科目');
		}

		if($aEsInfo['status'] != 6){
			wrong('题目在未通过复核的状态才可以编辑');
		}
		$oEsPlugin = $this->_esFactory($aEsInfo['subject_id'], $aEsInfo['type_id']);
		$aEsInfo['es_content'] = $oEsPlugin->resolve($aEsInfo['content_json']);

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$aEsInfo['subject_id']])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		assign('sameBaseEsType', $sameBaseEsType);
		assign('aSameEsTypeId', $aSameEsTypeId);

		$oEs = m('Es');
		assign('aCategoryList', Es::getCategoryTreeListBySubjectId($aEsInfo['subject_id']));
		assign('categoryId', $aEsInfo['category_id']);
		assign('subjectId', $aEsInfo['subject_id']);
		assign('esType', $aEsInfo['type_id']);
		assign('id', $aEsInfo['id']);
		assign('aEs', $aEsInfo);
		displayHeader();
		display('es_approve/edit.html.php');
		displayFooter();
	}

	/**
	 * 修改题目
	 */
	public function editEs(){
		$aEs = array();

		//题目信息
		$aEs['id'] = post('id');
		if(!($aEs['id'] >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($aEs['id']);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}
		$this->_checkAllowSubject($aEsInfo['subject_id']);

		if($aEsInfo['status'] != 6){
			alert('该题目已经不是 ' . $this->_aEsStatus[6] . ' 状态，禁止修改', 0);
		}

		//科目ID
		$subjectId = post('subject_id');
		if(!($subjectId >= 1)){
			alert('非法的科目ID', 0);
		}

		//题目类型
		$esType = post('es_type');
		if(!($esType >= 1)){
			alert('非法的题目类型ID', 0);
		}

		//调用题目插件
		$oEsPlugin = $this->_esFactory($subjectId, $esType);
		if(!is_object($oEsPlugin)){
			alert('错误的科目或题型', 0);
		}
		$aEsMainContent = $oEsPlugin->build($_POST['es']);
		if($oEsPlugin->getError()){
			alert($oEsPlugin->getError(), 0);
		}
		$aEs['content_json'] = $aEsMainContent['content_json'];
		$aEs['content_text'] = $aEsMainContent['content_text'];

		//检查目录
		$aEs['category_id'] = post('category_id');
		if(!($aEs['category_id'] >= 1)){
			alert('非法的目录ID', 0);
		}else{
			$categoryExists = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
			if(!$categoryExists){
				alert('目录不存在', 0);
			}
		}
		$childNums = $oEs->isExistSubCategory($aEs['category_id']);
		if($childNums > 0){
			alert('选择的目录不是最底层目录，请检查', 0);
		}

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$esType];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$subjectId])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		if($sameBaseEsType >= 2){
			$aEs['type_id'] = post('es_type');
			if(!in_array($aEs['type_id'], $aSameEsTypeId)){
				alert('错误的题型', 0);
			}
		}

		//检查是否存在相同题干的题目
		if(intval(get('ignore_same_es')) == 0){
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				$aSameEsIdList = array();
				foreach($aSameEsList as $aSameEs){
					$aSameEsIdList[] = $aSameEs['id'];
				}
				alert('检测到正式题库中已经存在相似的题目,是否继续保存?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
			}
		}

		$isUpdataEs = $oEs->setEs($aEs);
		if($isUpdataEs || $isUpdataEs === 0){
			if(post('isSubmit')){
				$aSubmitEs = array();
				$aSubmitEs['id'] = $aEs['id'];
				$aSubmitEs['action'] = 2;
				$aSubmitEs['status'] = 3;
				$aSubmitEs['operating_time'] = time();
				$aSubmitEs['submiter_user_id'] = $this->_userId;
				$aSubmitEs['approver_user_id'] = $aEsInfo['approver_user_id'];
				$aSubmitEs['subject_id'] = $aEsInfo['subject_id'];
				$isSubmitEs = $oEs->changeStatus($aSubmitEs);
				if($isSubmitEs){
					alert('保存并提交复核成功', 1, '?m=EsApprove&a=showList&esStatus=' . $aEsInfo['status'] . '&=subject' . $aEsInfo['subject_id']);
				}else{
					alert('保存提并交复核失败', 0);
				}
			}
			alert('保存题目成功', 1, '?m=EsApprove&a=showList&esStatus=' . $aEsInfo['status'] . '&subject=' . $aEsInfo['subject_id']);
		}else{
			alert('保存题目失败', 0);
		}
	}


	/**
	 * 提交自己被驳回的题目进行审核
	 */
	public function submitEs(){
		$esId = post('esId');
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEs = $oEs->getEsInfoByEsId($esId);
		if(!$aEs){
			alert('题目不存在', 0);
		}
		$this->_checkAllowSubject($aEs['subject_id']);

		if($aEs['status'] == 6){
			if(intval(get('ignore_same_es')) == 0){
				//检查是否存在相似题目
				if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($esId))){
					$aSameEsIdList = array();
					foreach($aSameEsList as $aSameEs){
						$aSameEsIdList[] = $aSameEs['id'];
					}
					alert('检测到正式题库中存在与ID '. $esId .' 相似题目,是否继续提交?(<a target="_blank" href="?m=EsCreate&a=showSameEsList&check_es_id=' . $esId . '&same_ids=' . implode(',', $aSameEsIdList) . '">点击查看相似题目</a>)', -1);
				}
			}

			$isSubmitEs = $oEs->changeStatus(array(
				'id' => $esId,
				'action' => 2,
				'status' => 3,
				'operating_time' => time(),
				'submiter_user_id' => $this->_userId,
				'subject_id' => $aEs['subject_id'],
			));

			if($isSubmitEs){
				alert('提交题目成功', 1, 'reload');
			}else{
				alert('提交题目失败', 0);
			}
		}else{
			alert('提交的题目必须是在复核不通过的状态', 0);
		}
	}

	/**
	 * 通审题目
	 */
	public function approvalEs(){
		$oEs = m('Es');
		$needFinishEsNums = $oEs->isExistEsNeedFinishByApproverId($this->_userId);
		if($needFinishEsNums){
			alert('您有 ' . $needFinishEsNums . ' 道复核未通过的题目超过1天未处理，请先处理', 0);
		}

		$esId = post('esId');
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}
		$this->_checkAllowSubject($aEsInfo['subject_id']);

		$isMyEs = $oEs->isMyWaitApproverEs($this->_userId, $esId);
		if(!$isMyEs){
			alert('题目不属于您', 0);
		}

		if($aEsInfo['status'] == 2){
			$type = post('operationType');
			$aEs = array();
			$aEs['id'] = $esId;
			$aEs['operating_time'] = time();
			$aEs['submiter_user_id'] = $aEsInfo['submiter_user_id'];
			$aEs['approver_user_id'] = $this->_userId;
			$aEs['subject_id'] = $aEsInfo['subject_id'];
			if($type == 1){
				$aEs['action'] = 3;
				$aEs['status'] = 3;
				$sucessMsg = '通审题目成功';
				$failMsg = '通审题目失败';
			}elseif($type == 2){
				$aEs['comment'] = post('comment');
				if(!$aEs['comment']){
					alert('请填写驳回理由', 0);
				}
				$aEs['action'] = 4;
				$aEs['status'] = 4;
				$sucessMsg = '驳回题目成功';
				$failMsg = '驳回题目失败';
			}else{
				alert('非法操作', 0);
			}
			$isSucess = $oEs->changeStatus($aEs);
			if($isSucess){
				alert($sucessMsg, 1, 'reload');
			}else{
				alert($failMsg, 0);
			}
		}else{
			alert('只能通审或发回待审核状态的题目', 0);
		}
	}

	/**
	 * 生产插件对象的工厂
	 * @param type $subject
	 * @param type $esType
	 * @return type
	 */
	private function _esFactory($subject, $esType){
		if(!is_numeric($subject) || !is_numeric($esType)){
			alert('参数错误', 0);
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
			alert('不存在此题型', 0);
		}
		if(!in_array($esType, $GLOBALS['SUBJECT_TYPE'][$subject])){
			alert($GLOBALS['SUBJECT'][$subject] . '科目不存在' . $GLOBALS['ES_TYPE'][$esType], 0);
		}
		$oEs = esPlugin($GLOBALS['TYPE_RESOLVER'][$esType]);
		return $oEs;
	}

	/**
	 * 检查绑定的科目
	 */
	private function _checkAllowSubject($subjectId){
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		if(!in_array($subjectId, $aAllowSubjectId)){
			alert('您没有管理 ' . $GLOBALS['SUBJECT'][$subjectId] . ' 科目目录的权限', 0);
		}
	}
}