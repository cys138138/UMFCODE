<?php
/**
 * 后台首页
 */
class IndexController{

	private $_userId = 0;
	private $_permissionFlag = 'manage_es';
	private $_manageUser = 'manage_user';
	public function __construct(){
		$this->_userId = checkLogin();
	}

	public function index(){
		display('index.html.php');
	}



	/**
	 * 显示后台顶部框架
	 */
	public function showTop(){
		$aUserInfo = m('Manager')->getUserInfoByUserId($this->_userId);
		if($aUserInfo === false){
			wrong('读取用户信息失败');
		}
		$username = $aUserInfo['name'];
		assign('username', $username);
		displayHeader();
		display('top.html.php');
		displayFooter();
	}

	/**
	 * 显示后台左侧框架
	 */
	public function showLeft(){
		$aUserInfo = m('Manager')->getUserInfoByUserId($this->_userId);
		if($aUserInfo === false){
			wrong('读取用户信息失败');
		}
		$aGroup = m('Manager')->getGroupInfoByGroupId($aUserInfo['group_id']);
		if($aGroup === false){
			wrong('读取权限信息失败');
		}
		assign('aUserPermission', $aGroup['permission']);
		assign('isAdmin', $this->_userId == 1);
		displayHeader();
		display('left.html.php');
		displayFooter();
	}

	/**
	 * 显示后台主框架
	 */
	public function showMain(){
		$admin = checkPermission($this->_userId, $this->_permissionFlag);
		$userManage = checkPermission($this->_userId, $this->_manageUser);

		if($admin){
			$oEs = m('Es');
			//$aEsList = $oEs->getEsInfoByEsId(3783);
			//$aEsList['es_content'] = json_decode($aEsList['content_json'],true);
			//unset($aEsList['content_json']);
			$checkPending = $oEs->getEsCount(0, 2);
			$recheck = $oEs->getEsCount(0, 3);
			$chineseEsCount = $oEs->getEsFeedbackCount(1, 1);
			$mathEsCount = $oEs->getEsFeedbackCount(2, 1);
			$englishEsCount = $oEs->getEsFeedbackCount(3, 1);
			$otherEsCount = $oEs->getEsFeedbackCount(4, 1);
			assign('chineseEsCount',$chineseEsCount);
			assign('mathEsCount',$mathEsCount);
			assign('englishEsCount',$englishEsCount);
			assign('otherEsCount',$otherEsCount);
			assign('checkPending',$checkPending);
			assign('recheck',$recheck);
			//assign('aEsList',json_encode($aEsList));
		}
		if($userManage){
			$oUser = m('User');
			$userCheck = $oUser->getUserInfoApproveCount(0);
			assign('userCheck',$userCheck);
		}

		assign('admin',$admin);
		assign('userManage',$userManage);
		displayHeader();
		display('main.html.php');
		displayFooter();
	}

}

