<?php
class ProxyAnnouncementController{
	private $_permissionFlag = 'manage_proxy_announcement';
	private $_userId = 0;
	
	private $_aAnnouncementTypeName = array(
		1 => '公告',
		2 => '代理商申请说明',
		3 => 'api文档'
	);
	
	
	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			wrong('您没有权限对此操作');
		}
	}

	
	//公告列表
	public function showProxyAnnouncementList(){
		$url= '?m=ProxyAnnouncement&a=showProxyAnnouncementList&page=_PAGE_';
		$announcementTitle = get('announcementTitle');
		if($announcementTitle){
			$url .= '&announcementTitle=' . $announcementTitle;
		}
		$publisherId = 0;
		$publisher = get('publisher');
		
		if($publisher){
			//$oManager = new ManagerModel();
			
			//$url .= '&title=' . $title;
		}
		
		
		$createTime = get('createTime');
		$searchCreateTime = 0;
		if($createTime){
			$searchCreateTime = strtotime($createTime);
			$url .= '&createTime=' . $createTime;
		}
		
		$type = intval(get('type'));
		
		if(isset($this->_aAnnouncementTypeName[$type])){
			$url .= '&type=' . $type;
		}else{
			$type = 0;
		}
		
		assign('announcementTitle', $announcementTitle);
		assign('publisher', $publisher);
		assign('createTime', $createTime);
		assign('type', $type);
		
		
		
		
		$oProxy = new ProxyModel();
		$aAnnouncementList = array();
		$pageHtml = '';
		$page = intval(get('page','1'));
		if($page < 1){
			$page = 1;
		}

		$pageSize = 20;
		
		$count = $oProxy->getProxyAnnouncementCount($announcementTitle, $publisherId, $searchCreateTime, $type);
		if($count > 0){
			
			$pageCount = ceil($count/$pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aAnnouncementList = $oProxy->getProxyAnnouncementList($page, $pageSize, $order = 'id DESC',  $announcementTitle, $publisherId, $searchCreateTime, $type);
			if($aAnnouncementList){
				$oManager = m('Manager');
				foreach($aAnnouncementList as $key => $value){
					$aAnnouncementList[$key]['publisherName'] = '';
					$aAnnouncementList[$key]['typeName'] = '';
					if(intval($value['publisher']) > 0){
						$publisherName =  $oManager->getUserNameByUserId(intval($value['publisher']));
						if($publisherName){
							$aAnnouncementList[$key]['publisherName'] = $publisherName;
						}
					} 
					
					if($this->_aAnnouncementTypeName[$value['type']]){
						$aAnnouncementList[$key]['typeName'] = $this->_aAnnouncementTypeName[$value['type']];
					}
				}
			}
			$aPageInfo = array(
				'url' => '?m=ProxyAnnouncement&a=showProxyAnnouncementList&page=_PAGE_',
				'total' => $count,
				'size' => $pageSize,
				'page' => $page,
			);
			$pageHtml = page($aPageInfo);
			
		}
		
		assign('typeArray', $this->_aAnnouncementTypeName);
		assign('aAnnouncementList', $aAnnouncementList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('proxy_announcement/list.html.php');
		displayFooter();
	}


	//添加公告视图
	public function showAdd(){
		assign('announcementType' , $this->_aAnnouncementTypeName);
		assign('validateAddAnnouncementJs', j('announcementTitle'));
		displayHeader();
		display('proxy_announcement/add.html.php');
		displayFooter();	
	}
	
	//添加公告
	public function add(){

		$vAddResult = v('announcementTitle');
		if($vAddResult){
			wrong($vAddResult);
		}
		
		$aData = array(
			'type'			=> intval(post('type',0)),
			'title'			=> post('announcementTitle'),
			'content'		=> post('content'),
			'publisher'		=> Cookie::getDecrypt('userId'),
			'create_time'	=> time()
		);
		if(!$this->_aAnnouncementTypeName[$aData['type']]){
			wrong('公告类型错误');
		}
		
		if(!$aData['content']){
			wrong('公告内容不能为空');
		}
		$oProxy = m('Proxy');
		$announcementId = $oProxy->addProxyAnnouncement($aData);
		if($announcementId){
			header('LOCATION:/?m=ProxyAnnouncement&a=showProxyAnnouncementList');
		}else{
			wrong('添加失败');
		}
	}
	
	//修改视图
	public function showEdit(){
		$id = intval(get('id'));
		$aAnnouncementInfo = array();
		$oProxy = m('Proxy');
		if($id > 0){
			$aResult = $oProxy->getProxyAnnouncementInfoById($id);
			if($aResult){
				$aAnnouncementInfo = $aResult;
				unset($aResult);
				
				assign('aAnnouncementInfo' , $aAnnouncementInfo);
				assign('announcementType' , $this->_aAnnouncementTypeName);
				assign('validateAddAnnouncementJs', j('announcementTitle'));
				displayHeader();
				display('proxy_announcement/edit.html.php');
				displayFooter();
			
			}else{
				wrong('此公告不存在');	
			}
		}else{
			wrong('此公告不存在');
		}
	}
	
	
	
	//修改公告
	public function edit(){
		$id = intval(get('id',0));
		$vAddResult = v('announcementTitle');
		if($vAddResult){
			wrong($vAddResult);
		}
		
		$aData = array(
			'type'			=> intval(post('type',0)),
			'title'			=> post('announcementTitle'),
			'content'		=> post('content'),
			'publisher'		=> Cookie::getDecrypt('userId'),
			'create_time'	=> time()
		);
		if(!$this->_aAnnouncementTypeName[$aData['type']]){
			wrong('公告类型错误');
		}
		
		if(!$aData['content']){
			wrong('公告内容不能为空');
		}
		$oProxy = m('Proxy');
		$aAnnouncementInfo = $oProxy->getProxyAnnouncementInfoById($id);
		if(!$aAnnouncementInfo){
			wrong('Id 非法');
		}else{
			$aData['id'] = $id;
			$aEditResult = $oProxy->editProxyAnnouncement($aData);
			if($aEditResult !== false){
				header('LOCATION:/?m=ProxyAnnouncement&a=showProxyAnnouncementList');
			}else{
				wrong('更新失败');
			}
		}
	}
	
	
	public function del(){
		$id = intval(post('id',0));
		$oProxy = new ProxyModel();
		if($oProxy->deleteProxyAnnouncementById($id)){
			alert('删除成功',1);
		}else{
			alert('删除失败',0);
		}
		
		
	}
}