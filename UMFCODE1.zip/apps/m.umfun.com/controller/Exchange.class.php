<?php
class ExchangeController{

	private $_permissionFlag = 'manage_exchange';
	private $_userId = 0;

	public function __construct(){
		if(get('a') != 'uploadProfile' && get('a') != 'uploadRecommand'){
			$this->_userId = checkLogin();
			if(!checkPermission($this->_userId, $this->_permissionFlag)){
				wrong('您没有权限对此操作');
			}
		}
	}

	public function showList(){
		tipsNewManage();
		$level = intval(get('level'));
		$release = intval(get('release'));
		$recommand = intval(get('recommand'));

		$url = '?m=Exchange&a=showList&page=_PAGE_';
		$page = intval(get('page', 1));
		$pageSize = 10;
		$pageCount = 1;
		$goodsCount = 0;
		$pageHtml = '';
		$aGoodsList = array();
		$aCondition = array();
		if(get('level')){
			$aCondition['level'] = $level;
			$url .= '&level=' . $level;
		}
		if(get('release')){
			$aCondition['release'] = $release;
			$url .= '&release=' . $release;
		}
		if(get('recommand')){
			$aCondition['recommand'] = $recommand;
			$url .= '&recommand=' . $recommand;
		}
		if($page < 1){
			$page = 1;
		}

		$oExchange = m('Exchange');
		$goodsCount = $oExchange->getExchangeGoodsCount($aCondition);
		if($goodsCount === false){
			alert('系统错误', 0);
		}
		if($goodsCount > 0){
			$pageCount = ceil($goodsCount / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aGoodsList = $oExchange->getExchangeGoodsList($aCondition, $page, $pageSize);
			if($aGoodsList === false){
				alert('系统错误', 0);
			}
			if($pageCount > 1){
				$aPageInfo = array(
					'url' 	=> $url,
					'total' => $goodsCount,
					'size' 	=> $pageSize,
					'page' 	=> $page,
				);
				$pageHtml = page($aPageInfo);
			}
		}
		assign('aCondition', $aCondition);
		assign('aGoodsList', $aGoodsList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('exchange/list.html.php');
		displayFooter();
	}

	public function showAdd(){
		$oExchange = m('Exchange');
		$maxOrder = $oExchange->getMaxOrdersInExchangeGoods();
		assign('maxOrder', $maxOrder);
		assign('validateAddGoodsJs', j('exchange_name,exchange_profile,exchange_level,exchange_gold,exchange_stock,exchange_orders,exchange_release,exchange_summary,exchange_description'));
		displayHeader();
		display('exchange/add.html.php');
		displayFooter();
	}

	public function add(){
		$goodsName = post('exchange_name');
		$profile = post('exchange_profile');
		$recommandTime = strtotime(post('recommandTime', 0));
		$rushTime = post('rushTime', 0);
		if($rushTime){
			$rushTime =  strtotime($rushTime);
		}
		$recommand = post('recommand', 0);
		$level = intval(post('exchange_level', 0));
		$gold = intval(post('exchange_gold', 0));
		$originalGold = intval(post('original_gold', 0));
		$stock = intval(post('exchange_stock', 0));
		$orders = intval(post('exchange_orders', 0));
		$type = intval(post('exchange_type', 0));
		$release = intval(post('exchange_release', 0));
		$summary = $_POST['exchange_summary'];
		$description = $_POST['exchange_description'];

		$vAddResult = v('exchange_name,exchange_profile,exchange_level,exchange_gold,exchange_stock,exchange_orders,exchange_release,exchange_summary,exchange_description');
		if($vAddResult){
			alert($vAddResult, 0);
		}

		if(!file_exists(SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_PROFILE_PATH, USER_TMP_PATH, $profile))){
			alert('兑换物品截图上传错误', 0);
		}else{
			$tempProfile = SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_PROFILE_PATH, USER_TMP_PATH, $profile);
		}

		if($recommandTime || $recommand){
			if(!$recommandTime){
				alert('请填写推荐时间', -1);
			}
			if(!$recommand){
				alert('请上传推荐轮显图片', -1);
			}
			if(!file_exists(SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_RECOMMEND_PATH, USER_TMP_PATH, $recommand))){
				alert('推荐轮显图片上传错误', 0);
			}else{
				$tempRecommand = SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_RECOMMEND_PATH, USER_TMP_PATH, $recommand);
			}
		}else{
			$tempRecommand = $recommand;
		}

		$aData = array(
			'profile' => $profile,
			'name' => $goodsName,
			'level' => $level,
			'gold' => $gold,
			'original_gold' => $originalGold,
			'stock' => $stock,
			'support' => 0,
			'sales_volume' => 0,
			'summary' => $summary,
			'description' => $description,
			'create_time' => time(),
			'orders' => $orders,
			'release' => $release,
			'rush_time' => $rushTime,
		);
		if($rushTime){
			$aData['quick_spot'] = rand(1, 100);	//10*10的找茬
		}
		if($recommandTime || $recommand){
			$aData['recommand_time'] = $recommandTime;
			$aData['recommand_image'] = $recommand;
		}

		$oExchange = m('Exchange');
		$isAddScuccess = $oExchange->addExchangeGoods($aData);
		if($isAddScuccess === false){
			alert('系统出错，请稍后再试!', 0);
		}

		if($isAddScuccess){
			if(!rename($tempProfile, SYSTEM_RESOURCE_PATH . $profile)){
				if(file_exists($tempProfile)){
					unlink($tempProfile);
				}
			}
			if($recommand){
				if(!rename($tempRecommand, SYSTEM_RESOURCE_PATH . $recommand)){
					if(file_exists($tempRecommand)){
						unlink($tempRecommand);
					}
				}
			}
		}else{
			if(file_exists($tempProfile)){
				unlink($tempProfile);
			}
			if($recommand){
				if(file_exists($tempRecommand)){
					unlink($tempRecommand);
				}
			}
		}
		alert('兑换物品添加成功！', 1, $isAddScuccess);
	}

	public function showEdit(){
		$id = intval(get('id'));

		$oExchange = m('Exchange');

		$aGoods = $oExchange->getExchangeGoodsInfoById($id);
		if(!$aGoods){
			alert('兑换物品不存在', 0);
		}
		$oExchange = m('Exchange');
		$maxOrder = $oExchange->getMaxOrdersInExchangeGoods();

		assign('maxOrder', $maxOrder);
		assign('aGoods', $aGoods);
		assign('validateEditGoodsJs', j('exchange_name,exchange_profile,exchange_level,exchange_gold,exchange_stock,exchange_orders,exchange_release,exchange_summary,exchange_description'));
		displayHeader();
		display('exchange/edit.html.php');
		displayFooter();
	}

	public function edit(){
		$id = intval(post('exchange_id'));
		$goodsName = post('exchange_name');
		$profile = post('exchange_profile');
		$recommandTime = strtotime(post('recommandTime', 0));
		$rushTime = post('rushTime', 0);
		if($rushTime){
			$rushTime =  strtotime($rushTime);
		}
		$recommand = post('recommand', 0);
		$level = intval(post('exchange_level', 0));
		$gold = intval(post('exchange_gold', 0));
		$originalGold = intval(post('original_gold', 0));
		$stock = intval(post('exchange_stock', 0));
		$orders = intval(post('exchange_orders', 0));
		$type = intval(post('exchange_type', 0));
		$release = intval(post('exchange_release', 0));
		$summary = $_POST['exchange_summary'];
		$description = $_POST['exchange_description'];

		$oExchange = m('Exchange');

		$aGoods = $oExchange->getExchangeGoodsInfoById($id);
		if(!$aGoods){
			alert('兑换物品不存在', 0);
		}

		$vAddResult = v('exchange_name,exchange_profile,exchange_level,exchange_gold,exchange_stock,exchange_orders,exchange_release,exchange_summary,exchange_description');
		if($vAddResult){
			alert($vAddResult, 0);
		}
		if($profile != $aGoods['profile']){
			if(!file_exists(SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_PROFILE_PATH, USER_TMP_PATH, $profile))){
				alert('兑换物品截图上传错误', 0);
			}else{
				$tempProfile = SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_PROFILE_PATH, USER_TMP_PATH, $profile);
			}
		}

		if($recommandTime || $recommand){
			if(!$recommandTime){
				alert('请填写推荐时间', -1);
			}
			if(!$recommand){
				alert('请上传推荐轮显图片', -1);
			}
			if($recommand != $aGoods['recommand_image']){
				if(!file_exists(SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_RECOMMEND_PATH, USER_TMP_PATH, $recommand))){
					alert('推荐轮显图片上传错误', 0);
				}else{
					$tempRecommand = SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_RECOMMEND_PATH, USER_TMP_PATH, $recommand);
				}
			}
		}else{
			$tempRecommand = $recommand;
		}

		$aData = array(
			'id' => $id,
			'profile' => $profile,
			'name' => $goodsName,
			'level' => $level,
			'gold' => $gold,
			'original_gold' => $originalGold,
			'stock' => $stock,
			'summary' => $summary,
			'description' => $description,
			'orders' => $orders,
			'release' => $release,
			'rush_time' => $rushTime,
		);
		if($rushTime){
			$aData['quick_spot'] = rand(1, 100);	//10*10的找茬
		}
		if($recommandTime || $recommand){
			$aData['recommand_time'] = $recommandTime;
			$aData['recommand_image'] = $recommand;
		}

		$isEditScuccess = $oExchange->setExchangeGoods($aData);
		if($isEditScuccess === false){
			alert('系统出错，请稍后再试!', 0);
		}

		if($isEditScuccess){
			if($profile != $aGoods['profile']){
				if(!rename($tempProfile, SYSTEM_RESOURCE_PATH . $profile)){
					if(file_exists($tempProfile)){
						unlink($tempProfile);
					}
				}
			}
			if($recommand != $aGoods['recommand_image']){
				if($recommand){
					if(!rename($tempRecommand, SYSTEM_RESOURCE_PATH . $recommand)){
						if(file_exists($tempRecommand)){
							unlink($tempRecommand);
						}
					}
				}
			}
		}else{
			if(file_exists($tempProfile)){
				unlink($tempProfile);
			}
			if($recommand){
				if(file_exists($tempRecommand)){
					unlink($tempRecommand);
				}
			}
		}

		alert('兑换物品修改成功！', 1, $id);
	}

	public function cancelRecommand(){
		$id = intval(post('id'));
		$oExchange = m('Exchange');

		$aGoods = $oExchange->getExchangeGoodsInfoById($id);
		if(!$aGoods){
			alert('兑换物品不存在', 0);
		}

		$aData = array(
			'id' => $id,
			'recommand_time' => 0
		);

		$isEditScuccess = $oExchange->setExchangeGoods($aData);
		if($isEditScuccess === false){
			alert('系统出错，请稍后再试!', 0);
		}
		alert('取消推荐成功！', 1);
	}

	public function showDetail(){
		$id = intval(get('id'));

		$oExchange = m('Exchange');

		$aGoods = $oExchange->getExchangeGoodsInfoById($id);
		if(!$aGoods){
			alert('兑换物品不存在', 0);
		}

		assign('aGoods', $aGoods);
		displayHeader();
		display('exchange/detail.html.php');
		displayFooter();
	}

	//上传封面
	public function uploadProfile(){
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(307200, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . USER_TMP_PATH,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败".' . $oUploader->getErrorMsg() . '."', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$aWidthAndHeight = array();
		$aWidthAndHeight = getimagesize(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
		if(!$aWidthAndHeight){
			alert('文件上传失败', 0);
		}
		$width = intval($aWidthAndHeight[0]);
		$height = intval($aWidthAndHeight[1]);
		if($width > 400){
			if(file_exists(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽度不能超过400px', 0);
		}
		/*if($width/$height != 0.9){
			if(file_exists(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽高比为9:10', 0);
		}*/
		alert(PRODUCT_PROFILE_PATH . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . USER_TMP_PATH . $uploadFileInfo['savename']);
	}

	public function uploadRecommand(){
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(307200, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . USER_TMP_PATH,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败".' . $oUploader->getErrorMsg() . '."', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$aWidthAndHeight = array();
		$aWidthAndHeight = getimagesize(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
		if(!$aWidthAndHeight){
			alert('文件上传失败', 0);
		}
		$width = intval($aWidthAndHeight[0]);
		$height = intval($aWidthAndHeight[1]);
		/*if($width > 400){
			if(file_exists(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽度不能超过400px', 0);
		}*/
		/*if($width/$height != 0.9){
			if(file_exists(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽高比为9:10', 0);
		}*/
		alert(PRODUCT_RECOMMEND_PATH . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . USER_TMP_PATH . $uploadFileInfo['savename']);
	}

	//删除图片
	public function delProfile(){
		$profile = post('profile');
		if(!$profile){
			alert('数据错误', 0);
		}
		$tmpProfile = SYSTEM_RESOURCE_PATH . str_replace(PRODUCT_PROFILE_PATH, USER_TMP_PATH, $profile);
		if(!file_exists($tmpProfile)){
			alert('文件不存在', 0);
		}
		if(unlink($tmpProfile)){
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}

	//编辑器图片上传
	public function ueditorUpload(){
		$editorId = get('editorid');
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(512000, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . PRODUCT_DESCRIPTION_IMAGE_PATH,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			exit("<script>parent.UM.getEditor('". $editorId ."').getWidgetCallback('image')('', '" . $oUploader->getErrorMsg() . "')</script>");
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		exit("<script>parent.UM.getEditor('". $editorId ."').getWidgetCallback('image')('" . $uploadFileInfo['savename'] . "','" . 'SUCCESS' . "')</script>");
	}

	public function showExchangeList(){
		$url = '?m=Exchange&a=showExchangeList&page=_PAGE_';
		$userId = 0;
		$page = intval(get('page', 1));
		$status = intval(get('status', 0));
		$order = '`id` DESC';
		$pageSize = 10;
		$pageCount = 1;
		$exchangeCount = 0;
		$pageHtml = '';
		$aExchangeList = array();
		$aCondition = array();
		if(get('status')){
			$aCondition['status'] = $status;
			$url .= '&status=' . $status;
		}
		if($page < 1){
			$page = 1;
		}

		$oExchange = m('Exchange');
		$exchangeCount = $oExchange->getExchangRecordsCount($userId, $status);
		if($exchangeCount === false){
			alert('系统错误', 0);
		}
		if($exchangeCount > 0){
			$pageCount = ceil($exchangeCount / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aExchangeList = $oExchange->getExchangRecordsList($userId, $status, $page, $pageSize, 1, $order);
			if($aExchangeList === false){
				alert('系统错误', 0);
			}
			if($pageCount > 1){
				$aPageInfo = array(
					'url' 	=> $url,
					'total' => $exchangeCount,
					'size' 	=> $pageSize,
					'page' 	=> $page,
				);
				$pageHtml = page($aPageInfo);
			}
		}
		assign('status', $status);
		assign('aCondition', $aCondition);
		assign('aExchangeList', $aExchangeList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('exchange/exchange_list.html.php');
		displayFooter();
	}

	public function editExchange(){
		$id = intval(post('id'));
		$expressCompany = post('express_company');
		$expressNumber = post('express_number');

		$oExchange = m('Exchange');
		$aExchange = $oExchange->getExchangRecordsInfoById($id);
		if(!$aExchange){
			alert('兑换记录不存在！', 0);
		}

		if(!$expressCompany){
			alert('请填写快递公司！', -1);
		}
		if(!$expressNumber){
			alert('请填写快递单号！', -1);
		}

		$aData = array(
			'id' => $id,
			'express_company' => $expressCompany,
			'express_number' => $expressNumber,
			'status' => 2
		);
		$isSetSuccess = $oExchange->setExchangRecords($aData);
		if(!$isSetSuccess){
			alert('系统出错，请稍后再试!', 0);
		}

		$aUser = getUserInfo($aExchange['user_id'], array('personal'));
		if($aUser['xxt_data']){
			$this->_sendExchangeGoodsMessageToParentAndShare($aUser, $aExchange);
		}
		alert('操作成功！', 1);
	}

	/*
	 * 后台的兑换商城兑换记录相应的奖品寄出时推送一条应用消息,也向他所在的班圈以及家长推送兑换奖品的信息
	 */
	private function _sendExchangeGoodsMessageToParentAndShare($aUser, $aExchange){
		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($aExchange['goods_id']);
		if(!$aGoods){
			return false;
		}

		//推送一条应用消息
		$contentStr = '您的兑换奖品' . $aGoods['name'] . '已经在' . date('m-d H:i:s') . '由优满分工作人员寄出。';
		$wait7Time = strtotime('+7 Days');
		$aContent = array(
			'City' => $aUser['xxt_data']['CityId'],
			'UserType' => 2,
			'IsOauth' => 0,
			'OthMsgId' => time(),
			'ValidDate' => date('Y-m-d H:i:s', $wait7Time),
			'URL' => url('m=Exchange&a=getGoodsDetail&goods_id=' . $aExchange['goods_id'], '', APP_HOME),
			'Type' => 1,
			'SchoolId' => $aUser['xxt_data']['SchoolId'],
			'Content' => $contentStr
		);

		try{
			$result = Xxt::postAppMessage($aUser['xxt_data']['UserId'], $aContent);
		}catch(XxtException $e){
			$e->log();
		}

		//向家长推送兑换奖品的信息
		$aXxtUserInfo = array();
		try{
			$aXxtUserInfo = Xxt::getStudentInfo($aUser['xxt_data']['UserId'], $aUser['xxt_data']['CityId']);
		}catch(XxtException $e){
			$e->log();
			return false;
			//alert('获取校讯通学生信息失败：' . $e->getMessage(), 0);
		}
		$contentStr = '您的孩子的兑换奖品' . $aGoods['name'] . '已经在' . date('m-d H:i:s') . '由优满分工作人员寄出。';
		$aContent['UserType'] = 3;
		$aContent['Content'] = $contentStr;
		try{
			$result = Xxt::postAppMessage($aXxtUserInfo['StudentEntity']['ParentEntity']['ParentId'], $aContent);
		}catch(XxtException $e){
			$e->log();
		}

		//向他所在的班圈推送兑换奖品的信息
		$contentStr = '我的兑换奖品' . $aGoods['name'] . '已经在' . date('m-d H:i:s') . '由优满分工作人员寄出。';
		$aWeiboParams = array();
		$aWeiboParams['city_id'] = $aUser['xxt_data']['CityId'];
		$aWeiboParams['user_id'] = $aUser['xxt_data']['UserId'];
		$aWeiboParams['role_type'] = 2;
		$aWeiboParams['school_id'] = $aXxtUserInfo['StudentEntity']['SchoolId'];
		$aWeiboParams['class_id'] = $aXxtUserInfo['StudentEntity']['ClassId'];
		$aWeiboParams['content'] = $contentStr;
		$aWeiboParams['from_sys'] = 9;
		$aWeiboParams['msg_type'] = 2;
		$aWeiboParams['has_attachment'] = 0;
		try{
			$result = Xxt::addWeibo($aWeiboParams);
		}catch(XxtException $e){
			$e->log();
		}
	}
}