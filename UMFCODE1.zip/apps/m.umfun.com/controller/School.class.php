<?php

class SchoolController{
	private $_userId = 0;
	private $_permissionFlag = 'manage_user';

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('抱歉！您无权进行操作，请联系管理员！', 0);
		}
	}

	public function showList(){
		$url = 'http://' . APP_MANAGE . '/?m=School&a=showList';
		$oUser = m('User');
		$schoolType = get('school_type');
		if(!isset($schoolType)){
			$schoolType = 1;
		}
		$url .= '&school_type=' . $schoolType;
		$provinceId = intval(get('province_id'));
		$cityId = intval(get('city_id'));
		$districtId = intval(get('areaId'));
		$areaId = 0;
		if($provinceId){
			$url .= '&province_id=' . $provinceId;
			$areaId = $provinceId;
		}
		if($cityId){
			$url .= '&city_id=' . $cityId;
			$areaId = $cityId;
		}
		if($districtId){
			$url .= '&areaId=' . $districtId;
			$areaId = $districtId;
		}
		$pageSize = 15;
		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;
		$offset = ($page - 1) * $pageSize;
		$aSchoolList = $oUser->getSchoolListByAreaId($areaId, $schoolType, $offset, $pageSize);
		if($aSchoolList === false){
			alert('系统出错，请稍后再试', 0);
		}

		foreach($aSchoolList as $key => $aSchool){
			$nums = $oUser->getUserCount(0, 0, 0, $aSchool['id']);
			if($nums === false){
				alert('系统有误，请稍后再试！', 0);
			}
			$aSchoolList[$key]['member_nums'] = $nums;
		}
		$schoolCount = $oUser->getSchoolListByAreaId($areaId, $schoolType);
		if($schoolCount === false){
			alert('系统有误，请稍后再试！', 0);
		}
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => count($schoolCount),
			'size' => $pageSize,
			'page' => $page,
			'subs' => 4,
			'selector' => 1,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('addSchoolValidateJs', j('school_name,areaId'));
		assign('provinceId', $provinceId);
		assign('cityId', $cityId);
		assign('areaId', $districtId);
		assign('aSchoolList', $aSchoolList);
		assign('schoolType', $schoolType);
		displayHeader();
		display('school/school_list.html.php');
		displayFooter();
	}

	public function delete(){
		$oUser = m('User');
		$id = post('id');
		$userCount = $oUser->getUserCount(0, 0, 0, $id);
		if($userCount === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($userCount > 0){
			alert('抱歉！该学校人数不为零，不能删除！', 0);
		}
		$row = $oUser->deleteSchoolBySchoolId($id);
		if($row === false){
			alert('网络可能有点慢，请稍后再试！', 0);
		}elseif($row){
			alert('删除成功!');
		}else{
			alert('删除失败！');
		}
	}

	public function add(){
		$vResult = v('school_name,areaId');
		if($vResult){
			alert($vResult, 0);
		}
		$oUser = m('User');
		$schoolName = post('school_name');
		$areaId = post('areaId');
		$aSchoolData = array(
				'type' => 0,
				'area_id' => $areaId,
				'name' => $schoolName,
		);
		$aSchoolInfo = $oUser->getSchoolInfoByAreaIdAndSchoolName($aSchoolData['area_id'] ,$aSchoolData['name']);
		if($aSchoolInfo === false){
			alert('网络可能有点慢，请稍后再试！', 0);
		}elseif($aSchoolInfo){
			alert('该学校已经存在了!', 0);
		}
		$school_id = $oUser->addSchool($aSchoolData);
		if($school_id === false){
			alert('网络可能有点慢，请稍后再试！', 0);
		}elseif($school_id){
			alert('添加学校成功！');
		}
	}

	public function searchSimilarSchool(){
		$oUser = m('User');
		$schoolName = get('school_name');
		$provinceId = intval(get('province_id'));
		$cityId = intval(get('city_id'));
		$districtId = intval(get('district_id'));
		$areaId = 0;
		if($provinceId){
			$areaId = $provinceId;
		}
		if($cityId){
			$areaId = $cityId;
		}
		if($districtId){
			$areaId = $districtId;
		}

		$aSchoolList = $oUser->getSchoolListByAreaId($areaId);
		if($aSchoolList === false){
			alert('系统有误，请稍后再试！', 0);
		}

		//匹配相似度为75%的学校
		$aSchoolList = $oUser->getSimilarSchoolList($schoolName, $aSchoolList, 75);
		if($aSchoolList === false){
			alert('系统有误，请稍后再试！', 0);
		}
		foreach($aSchoolList as $key=>$aSchool){
			 $nums = $oUser->getUserCount(0, 0, 0, $aSchool['id']);
			if($nums === false){
				alert('系统有误，请稍后再试！', 0);
			}
			$aSchoolList[$key]['member_nums'] = $nums;
		}
		foreach($aSchoolList as $key => $aSchool){
			$aDistrictInfo = $oUser->getAreaInfoByAreaId($aSchool['area_id']);
			if($aDistrictInfo === false){
				alert('系统有误！，请稍后再试！', 0);
			}
			$aSchoolList[$key]['district_name'] = $aDistrictInfo['name'];
			$cityInfo = $oUser->getAreaInfoByAreaId($aDistrictInfo['pid']);
			if($cityInfo === false){
				alert('系统有误！，请稍后再试！', 0);
			}
			$aSchoolList[$key]['city_name'] = $cityInfo['name'];
			$provinceInfo = $oUser->getAreaInfoByAreaId($cityInfo['pid']);
			if($provinceInfo === false){
				alert('系统有误！，请稍后再试！', 0);
			}
			$aSchoolList[$key]['province_name'] = $provinceInfo['name'];
		}
		assign('schoolName', $schoolName);
		assign('aSchoolList', $aSchoolList);
		displayHeader();
		display('school/similar_school.html.php');
		displayFooter();
	}

	public function showEditSchool(){
		$oUser = m('User');

		$schoolId = intval(get('school_id'));
		$aSchoolInfo = $oUser->getSchoolInfoBySchoolId($schoolId);
		if($aSchoolInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		$aSchoolInfo['member_nums'] = $oUser->getUserCount(0, 0, 0, $schoolId);
		assign('editSchoolValidateJs', j('school_name'));
		assign('aSchool', $aSchoolInfo);
		displayHeader();
		display('school/school_edit.html.php');
		displayFooter();
	}

	public function editSchool(){
		$vResult = v('school_name');
		if($vResult){
			alert($vResult, 0);
		}
		$areaId = intval(post('area_id'));
		$oUser = m('User');
		$aSchoolData = array(
			'id' => intval(post('school_id')),
			'type' => intval(post('type')),
			'name' => post('school_name'),
		);
		$aSchoolInfo = $oUser->getSchoolInfoByAreaIdAndSchoolName($areaId,$aSchoolData['name']);
		if($aSchoolInfo === false){
			alert('网络可能有点慢，请稍后再试！', 0);
		}elseif($aSchoolInfo){
			alert('学校已经存在了!', 0);
		}
		$row = $oUser->setSchoolInfo($aSchoolData);
		if($row === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($row){
			alert('修改成功');
		}elseif($row == 0){
			alert('您没有修改！', 0);
		}
	}

	public function showClassList(){
		$oUser = m('User');
		$schoolId = post('id');
		$aClassList = $oUser->getSchoolClassListBySchoolId($schoolId);
		alert('', 1, $aClassList);
	}

	public function addClass(){
		$vResult = v('class_name');
		if($vResult){
			alert($vResult, 0);
		}
		$oUser = m('User');
		$aData = array();
		$aData['user_id'] = 0;  //======================
		$aData['school_id'] = intval(post('school_id'));
		$aData['class'] = post('class_name');
		$aData['grade'] = post('grade');
		$aData['year'] = date("Y");
		$aData['is_active'] = 1;

		//判断所添加班级是否存在
		$aUserInfo = $oUser->isClassExist($aData['year'], $aData['school_id'], $aData['grade'], $aData['class']);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if($aUserInfo){
			alert('该班级已经存在了', 0);
		}
		$classId = $oUser->addClass($aData);
		if($classId === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($classId){
			alert('添加班级成功');
		}else{
			alert('添加班级失败', 0);
		}
	}

	public function deleteClass(){
		$schoolId = intval(post('school_id'));
		$grade = post('grade');
		$class = post('class_name');
		$oUser = m('User');
		$year = date('Y');
		$classNums = $oUser->getClassNumsBySchoolIdAndGradeAndClass($schoolId, $grade, $class, $year);
		if($classNums === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($classNums){
			alert('抱歉，不能删除有学生的班级，请先将学生移动到别的班级', 0);
		}
		$row = $oUser->deleteClassBySchoolIdAndGradeAndClass($schoolId, $grade, $class);
		if($row === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($row){
			alert('删除成功！');
		}else{
			alert('删除失败', 0);
		}
	}

	public function saveClassName(){
		$oUser = m('User');
		$oldClassName = post('oldClassName');
		$aData = array();
		$aData['user_id'] = 0;
		$aData['school_id'] = intval(post('school_id'));
		$aData['class'] = post('newClassName');
		$aData['grade'] = post('grade');
		$aData['year'] = date('Y');
		$aData['is_active'] = 1;

		//判断所添加班级是否存在
		if(!$aData['class']){
			alert('请写入有效的班级!', 0);
		}
		if(!w('noStr("\<\>\(\)`\\+\[\]\{\}~!@#\$%\^;:.,&\*\-_￥\"?\'\/\=,\|")', $aData['class'])){
			alert('抱歉！班级名称不能包含特殊字符！', 0);
		}
		$existClass = $oUser->isClassExist($aData['year'], $aData['school_id'], $aData['grade'], $aData['class']);
		if($existClass === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($existClass){
			alert('班级名称已经存在了', 0);
		}
		$row = $oUser->setClassBySchoolIdAndGradeAndClass($aData['class'], $aData['school_id'], $aData['grade'], $oldClassName);
		if($row === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($row){
			alert('修改成功！');
		}else{
			alert('您没有修改！', 0);
		}
	}
}