<?php
class MissionController{

	private $_userId = 0;
	private $_permissionFlag = 'manage_mission';
	private $_aEsStatus  = array(
		1	=> '已保存',
		2	=> '已提交',
		3	=> '已初审',
		4	=> '已发回',
		5	=> '已通审',
	);

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('抱歉！您无权进行操作，请联系管理员！', 0);
		}
	}

	/**
	*关卡显示列表
	*/
	public function showList(){
		$url = 'http://' . APP_MANAGE . '/?m=Mission&a=showList';
		$oMission = m('Mission');
		$aAllowSubject = m('Manager')->getUserAllowedSubjectByUserId($this->_userId);
		if($aAllowSubject === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aAllowSubject){
			alert('没有可操作的科目', 0);
		}
		$subjectId = intval(get('subject_id'));
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			$subjectId = Cookie::getDecrypt('lastSubjectId');
			if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
				$subjectId = $aAllowSubject[0];
			}
		}
		if(!in_array($subjectId, $aAllowSubject)){
			alert('抱歉，您没有操作这一科目的权限！', 0);
		}
		$aAllowedSubject = array();
		foreach($aAllowSubject as $allowSubjectId){
			if(isset($GLOBALS['SUBJECT'][$allowSubjectId])){
				$aAllowedSubject[$allowSubjectId] = $GLOBALS['SUBJECT'][$allowSubjectId];
			}
		}
		$pageSize = 15;
		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;

		$aCategoryIds = get('categoryId', array());
		$aCategoryIds = $aCategoryIds ? explode(',', $aCategoryIds) : array();
		$aCategoryList = array();
		$titleName = get('title', '');
		$missionCount = 0;
		$oEs = m('Es');
		
		foreach($aCategoryIds as $value){
			$aCategoryList[] = $oEs->getCategoryInfoByCategoryId($value);
		}

		if($aCategoryIds){
			$missionCount = $oMission->getMissionCount($subjectId, $aCategoryIds);
		}elseif($titleName){
			$missionCount = 1;
		}else{
			$missionCount = $oMission->getMissionCount($subjectId);
		}
		
		if($missionCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		if($titleName){
			$aMissionList = $oMission->getOriginalMissionList(0, $page, $pageSize, 1, $aCategoryIds, $titleName);
		}else{
			$aMissionList = $oMission->getOriginalMissionList($subjectId, $page, $pageSize, 1, $aCategoryIds, $titleName);
		}

		if($aMissionList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		$aTypeAndCounts = array();
		foreach($aMissionList as $key => $aMission){
			$aMissionList[$key]['category_name']= array();
			$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($subjectId, $aMission['category_ids']);
			if($aCategoryTypeAndCounts === false){
				alert('抱歉！系统有误，请稍后再试！', 0);
			}
			foreach($aCategoryTypeAndCounts as $typeKey => $typeAndCounts){
				$aTypeAndCounts[$GLOBALS['ES_TYPE'][$typeKey]] = $typeAndCounts;
			}
			if($aCategoryTypeAndCounts === false){
				alert('抱歉！系统出错，请稍后再试！', 0);
			}
			foreach ($aMission['category_ids'] as $idSubscript => $categoryId){
				$aCategoryInfoTree = $oEs->getDetailCategoryTree($categoryId);
				if($aCategoryInfoTree === false){
					alert('系统有误，请稍后再试！');
				}
				$aCategory = array();
				$categoryName = $aCategoryInfoTree['name'] . '&nbsp; - &nbsp;' . $aCategoryInfoTree['child']['name'];
				$aCategory['id'] = $categoryId;
				$aCategory['category_path'] = $categoryName;
				$aMissionList[$key]['category_name'][$idSubscript]= $aCategory;
			}
			$aMissionList[$key]['warehouse_es_counts'] = $aTypeAndCounts;
			$aAllTypeCounts = $oEs->getEsCountByCategoryIds($aMission['category_ids']);
			krsort($aAllTypeCounts);
			if($aAllTypeCounts === false){
				alert('系统错误，稍后再试！', 0);
			}

			$allTypeCounts = '';
			foreach($aAllTypeCounts as $typeCountKey => $typeCounts){
				//通审题目加粗高亮
				if($typeCountKey == 5){
					$allTypeCounts .= $this->_aEsStatus[$typeCountKey] . ' <font color="red"><b>' . $typeCounts . '</b></font> ';
				}else{
					$allTypeCounts .= $this->_aEsStatus[$typeCountKey] . ' <font color="black">' . $typeCounts . '</font> ';
				}
			}
			$aMissionList[$key]['all_es_counts'] = $allTypeCounts;
		}
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_&subject_id=' . $subjectId,
			'total' => $missionCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);
		Cookie::setEncrypt('lastSubjectId', $subjectId);
		assign('aCategoryList', $aCategoryList);
		assign('aSubject', $aAllowedSubject);
		assign('pageHtml', $pageHtml);
		assign('aMissionList' ,$aMissionList);
		assign('subjectId', $subjectId);
		displayHeader();
		display('mission/mission_list.html.php');
		displayFooter();
	}

	/**
	*关卡添加页面
	*/
	public function showAddMission(){
		$aAllowSubject = m('Manager')->getUserAllowedSubjectByUserId($this->_userId);
		if($aAllowSubject === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aAllowSubject){
			alert('没有可操作的科目', 0);
		}
		$subjectId = intval(get('subject_id'));
		if($subjectId < 1){
			$subjectId = Cookie::getDecrypt('lastSubjectId');
			if($subjectId < 1){
				$subjectId = $aAllowSubject[0];
			}
		}
		if(!in_array($subjectId, $aAllowSubject)){
			alert('抱歉，您没有操作这一科目的权限！', 0);
		}
		$aAllowedSubject = array();
		foreach($aAllowSubject as $allowSubjectId){
			if(isset($GLOBALS['SUBJECT'][$allowSubjectId])){
				$aAllowedSubject[$allowSubjectId] = $GLOBALS['SUBJECT'][$allowSubjectId];
			}
		}
		$missionId = intval(get('mission_id'));
		$oMission = m('Mission');
		$maxOrders = 0;
		$minOrders = 0;
		$lastOrders = $oMission->getLastOrders($subjectId);
		if($lastOrders === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$lastOrders){
			$lastOrders = 0;
		}
		if($missionId){
			$aMissionInfo = $oMission->getMissionInfoById($missionId);
			if($aMissionInfo === false){
				alert('系统有误，请稍后再试！', 0);
			}elseif(isset($aMissionInfo['orders'])){
				if($aMissionInfo['orders'] <= 1){
					alert('抱歉！没有空间可以再插入关卡了', 0);
				}
				$maxOrders = $aMissionInfo['orders'];
			}else{
				alert('系统数据有误，请联系管理员！', 0);
			}
			$aPreviousOrders = $oMission->getPreviousOrders($subjectId, $maxOrders);
			if($aPreviousOrders === false){
				alert('系统有误，请稍后再试！', 0);
			}elseif($aPreviousOrders){
				$minOrders = $aPreviousOrders;
			}
			if($maxOrders - $minOrders == 1){
				alert('抱歉，没有空间可以再插入关卡了', 0);
			}
		}
		assign('maxOrders', $maxOrders);
		assign('minOrders', $minOrders);
		assign('lastOrders', $lastOrders);
		$oEs = m('Es');
		$aCategoryList = $oEs->getCategoryDetailedListBySubjectId($subjectId);
		if($aCategoryList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		foreach($aCategoryList as $key => $aCategory){
			$nums = $oEs->isExistSubCategory($aCategory['id']);
			if($nums > 0){
				continue;
			}
			$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($aCategory['subject_id'], array($aCategory['id']));
			if($aCategoryTypeAndCounts === false){
				alert('抱歉！系统有误，请稍后再试！', 0);
			}
			$typeAndCounts = ' [ ';
			foreach($aCategoryTypeAndCounts as $typeKey => $categoryTypeAndCounts){
				$typeAndCounts .= $GLOBALS['ES_TYPE'][$typeKey] . ' : ' . $categoryTypeAndCounts . ' ';
			}
			$typeAndCounts .= ']';
			$aCategoryList[$key]['name'] .= $typeAndCounts;
		}
		assign('aCategoryList', $aCategoryList);
		assign('aSubject', $aAllowedSubject);
		assign('subjectId', $subjectId);
		assign('addMissionValidateJs', j('missionName,missionCorrectCounts,missionDuration,missionBlood,missionOrders'));
		displayHeader();
		display('mission/mission_add.html.php');
		displayFooter();
	}

	/**
	*关卡添加
	*/
	public function addMission(){
		$vResult = v('missionName,missionCorrectCounts,missionDuration,missionBlood,missionOrders');
		if($vResult){
			alert($vResult, 0);
		}
		$oEs = m('Es');
		$subjectId = intval(post('subjectId'));
		$this->_checkAllowedSubject($subjectId);
		$aEsTypeSub = post('esTypeSub');
		if(!$aEsTypeSub && !is_array($aEsTypeSub)){
			alert('抱歉！至少选择一种题型', 0);
		}
		//添加随机题的键名0
		$GLOBALS['SUBJECT_TYPE'][$subjectId][] = 0;
		$aDiff = array_diff($aEsTypeSub, $GLOBALS['SUBJECT_TYPE'][$subjectId]);
		if($aDiff){
			alert('您选的题型有误，请联系管理员！', 0);
		}
		$aCategoryIds = post('missionCategoryIds');
		if(!$aCategoryIds && !is_array($aCategoryIds)){
			alert('请选择关卡知识点！', 0);
		}
		foreach($aCategoryIds as $categoryId){
			$aCategoryInfo = $oEs->getCategoryInfoByCategoryId($categoryId);
			if(!$aCategoryInfo){
				alert('抱歉！您选择的知识点有误，请联系管理员！', 0);
			}
		}
		$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($subjectId, $aCategoryIds);
		if($aCategoryTypeAndCounts === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}
		//添加随机题
		$GLOBALS['ES_TYPE'][0] = '随机题';
		$aChallengeEsCount = array();
		foreach($aEsTypeSub as $key => $typeNums){
			$nums= post('esTypeNums' . $typeNums);
			if($typeNums){
				if($aCategoryTypeAndCounts[$typeNums] < 1){
				alert('题库没有' . $GLOBALS['ES_TYPE'][$typeNums], 0);
				}

				if($nums > $aCategoryTypeAndCounts[$typeNums]){
					alert($GLOBALS['ES_TYPE'][$typeNums] . '的数量不能超过题库的总数量' . $aCategoryTypeAndCounts[$typeNums] . '题', 0);
				}
			}
			if(!w('notNull()', $nums)){
					alert($GLOBALS['ES_TYPE'][$typeNums] . '题数不能为空！', 0);
			}
			if(!w('isNumber()', $nums) || !$nums){
				alert($GLOBALS['ES_TYPE'][$typeNums] . '请填写正整数！', 0);
			}
			$aChallengeEsCount[$key]['es_type_id'] = $typeNums;
			$aChallengeEsCount[$key]['es_count'] = $nums;
		}
		$missionName = post('missionName');
		$correctCounts = array('correct_counts' => post('missionCorrectCounts'));
		$vCategory = v('missionCategoryIds');
		if($vCategory){
			alert($vCategory, 0);
		}
		$blood = post('missionBlood');
		$duration = post('missionDuration');
		$order = post('missionOrders');
		$oMission = m('Mission');
		$isOrder = $oMission->isOrdersExist($subjectId, $order);
		if($isOrder){
			alert('抱歉，这个排序已存在，请重新输入！', 0);
		}
		$aData = array(
			'subject_id' => $subjectId,
			'category_ids' => $aCategoryIds,
			'name' => $missionName,
			'task_content' => $correctCounts,
			'challenge_es_count' => $aChallengeEsCount,
			'challenge_limit_duration' => $duration,
			'challenge_limit_blood' => $blood,
			'challenge_count' => 0,
			'challenge_success_count' => 0,
			'orders' => $order,
			'recent_record' => array(),
		);
		//debug($aData);
		$addMissionId = $oMission->addMission($aData);
		if($addMissionId === false){
			alert('系统有误！请稍后重试！', 0);
		}elseif($addMissionId){
			alert('添加成功！', 1, '?m=Mission&a=showList&subject_id=' . $subjectId);
		}else{
			alert('添加失败！', 0);
		}
	}

	/**
	*关卡详细信息页面
	*/
	public function showMissionDetail(){
		$missionId = intval(get('mission_id'));
		$aMissionInfo = m('Mission')->getMissionInfoById($missionId);
		if($aMissionInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMissionInfo){
			alert('抱歉！数据有误，请联系管理员！', 0);
		}
		$subjectId = $aMissionInfo['subject_id'];
		$this->_checkAllowedSubject($subjectId);
		$oEs = m('Es');
		$aMissionInfo['category_name'] = array();
		$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($subjectId, $aMissionInfo['category_ids']);
		if($aCategoryTypeAndCounts === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}
		$aTypeAndCounts = array();
		foreach($aCategoryTypeAndCounts as $typeKey => $typeAndCounts){
			$aTypeAndCounts[$GLOBALS['ES_TYPE'][$typeKey]] = $typeAndCounts;
		}
		foreach($aMissionInfo['category_ids'] as $key => $categoryId){
			$aCategoryInfoTree = $oEs->getDetailCategoryTree($categoryId);
			$aCategory = array();
			$categoryName = $aCategoryInfoTree['name'] . '&nbsp; - &nbsp;' . $aCategoryInfoTree['child']['name'];
			$aCategory['id'] = $categoryId;
			$aCategory['category_path'] = $categoryName;
			$aMissionInfo['category_name'][$key]= $aCategory;
		}
		$aAllTypeCounts = $oEs->getEsCountByCategoryIds($aCategoryTypeAndCounts);
		if($aAllTypeCounts === false){
			alert('系统错误，稍后再试！', 0);
		}
		krsort($aAllTypeCounts);
		$allTypeCounts = '';
		foreach($aAllTypeCounts as $typeCountKey => $typeCounts){
			//通审题目加粗高亮
			if($typeCountKey == 5){
				$allTypeCounts .= $this->_aEsStatus[$typeCountKey] . ' <font color="red"><b>' . $typeCounts . '</b></font> ';
			}else{
				$allTypeCounts .= $this->_aEsStatus[$typeCountKey] . ' <font color="black">' . $typeCounts . '</font> ';
			}
		}
		$aMissionInfo['all_es_counts'] = $allTypeCounts;
		$aMissionInfo['warehouse_es_counts'] = $aTypeAndCounts;
		assign('aMissionInfo', $aMissionInfo);
		displayHeader();
		display('mission/mission_detail.html.php');
		displayFooter();

	}

	/**
	*关卡编辑页面
	*/
	public function showEditMission(){
		$missionId = intval(get('mission_id'));
		$oMission = m('Mission');
		$aMissionInfo = $oMission->getMissionInfoById($missionId);
		if($aMissionInfo === false){
			alert('抱歉！，系统出错，请稍后再试！', 0);
		}elseif(!$aMissionInfo){
			alert('抱歉！数据出错，请联系管理员！', 0);
		}
		$subjectId = $aMissionInfo['subject_id'];
		$this->_checkAllowedSubject($subjectId);
		$aCategoryList = m('Es')->getCategoryDetailedListBySubjectId($subjectId);
		if($aCategoryList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oEs = m('Es');
		foreach($aCategoryList as $key => $aCategory){
			$nums = $oEs->isExistSubCategory($aCategory['id']);
			if($nums > 0){
				continue;
			}
			$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($aCategory['subject_id'], array($aCategory['id']));
			if($aCategoryTypeAndCounts === false){
				alert('抱歉！系统有误，请稍后再试！', 0);
			}
			$typeAndCounts = '';
			foreach($aCategoryTypeAndCounts as $typeKey => $categoryTypeAndCounts){
				$typeAndCounts .= $GLOBALS['ES_TYPE'][$typeKey] . ' ' . $categoryTypeAndCounts . ' ';

			}
			$aCategoryList[$key]['name'] .= ' - ' . $typeAndCounts;

		}
		assign('aMissionInfo', $aMissionInfo);
		assign('aCategoryList', $aCategoryList);
		assign('editMissionValidateJs', j('missionName,missionCorrectCounts,missionDuration,missionBlood,missionOrders'));
		displayHeader();
		display('mission/mission_edit.html.php');
		displayFooter();
	}

	/**
	*关卡编辑
	*/
	public function editMission(){
		$vResult = v('missionName,missionCorrectCounts,missionDuration,missionBlood,missionOrders');
		if($vResult){
			alert($vResult, 0);
		}
		$oMission = m('Mission');
		$oEs = m('Es');
		$missionId = intval(post('missionId'));
		$aMissionInfo = $oMission->getMissionInfoById($missionId);
		if($aMissionInfo === false){
			alert('抱歉！，系统出错，请稍后再试！', 0);
		}elseif(!$aMissionInfo){
			alert('抱歉！数据出错，请联系管理员！', 0);
		}
		$subjectId = $aMissionInfo['subject_id'];
		$this->_checkAllowedSubject($subjectId);
		$aEsTypeSub = post('esTypeSub');
		if(!$aEsTypeSub && !is_array($aEsTypeSub)){
			alert('抱歉！至少选择一种题型', 0);
		}
		//加上随机的键为0
		$GLOBALS['SUBJECT_TYPE'][$subjectId][] = 0;
		$aDiff = array_diff($aEsTypeSub, $GLOBALS['SUBJECT_TYPE'][$subjectId]);
		if($aDiff){
			alert('您选的题型有误，请联系管理员！', 0);
		}
		$missionName = post('missionName');
		$aCorrectCounts = array('correct_counts' => post('missionCorrectCounts'));
		$aCategoryIds = post('missionCategoryIds');
		if(!$aCategoryIds && !is_array($aCategoryIds)){
			alert('请选择关卡知识点！', 0);
		}
		foreach($aCategoryIds as $categoryId){
			$aCategoryInfo = $oEs->getCategoryInfoByCategoryId($categoryId);
			if(!$aCategoryInfo){
				alert('抱歉！您选择的知识点有误，请联系管理员！', 0);
			}
		}
		$aCategoryTypeAndCounts = $oEs->getEsCountBySubjectAndCategoryIds($subjectId, $aCategoryIds);
		if($aCategoryTypeAndCounts === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}
		$vCategory = v('missionCategoryIds');
		if($vCategory){
			alert($vCategory, 0);
		}
		$blood = post('missionBlood');
		$duration = post('missionDuration');
		$orders = post('missionOrders');
		if($orders != $aMissionInfo['orders']){
			$isOrder = $oMission->isOrdersExist($aMissionInfo['subject_id'], $orders);
			if($isOrder){
				alert('抱歉，这个排序已存在，请重新输入！', 0);
			}
		}
		$aChallengeEsCount = array();
		//添加随机题
		$GLOBALS['ES_TYPE'][0] = '随机题';
		foreach($aEsTypeSub as $key => $typeNums){
			$nums= post('esTypeNums' . $typeNums);
			if($typeNums){
				if($aCategoryTypeAndCounts[$typeNums] < 1){
					alert('题库没有' . $GLOBALS['ES_TYPE'][$typeNums], 0);
				}
				if($nums > $aCategoryTypeAndCounts[$typeNums]){
					alert($GLOBALS['ES_TYPE'][$typeNums] . '的数量不能超过题库的总数量' . $aCategoryTypeAndCounts[$typeNums] . '题', 0);
				}
			}

			if(!w('notNull()', $nums)){
				alert($GLOBALS['ES_TYPE'][$typeNums] . '题数不能为空！', 0);
			}
			if(!w('isNumber()', $nums) || !$nums){
				alert($GLOBALS['ES_TYPE'][$typeNums] . '请填写正整数！', 0);
			}
			$aChallengeEsCount[$key]['es_type_id'] = $typeNums;
			$aChallengeEsCount[$key]['es_count'] = $nums;
		}
		$aData = array(
			'id' => $missionId,
			'subject_id' => $subjectId,
			'category_ids' => $aCategoryIds,
			'name' => $missionName,
			'task_content' => $aCorrectCounts,
			'challenge_es_count' => $aChallengeEsCount,
			'challenge_limit_duration' => $duration,
			'challenge_limit_blood' => $blood,
			'challenge_count' => 0,
			'challenge_success_count' => 0,
			'orders' => $orders,
		);
		$row = $oMission->setMission($aData);
		if($row === false){
			alert('系统有误！请稍后重试！', 0);
		}elseif($row){
			alert('修改成功！', 1, '?m=Mission&a=showList&subject_id=' . $subjectId);
		}elseif($row == 0){
			alert('您没有修改！', 0);
		}
	}

	/**
	*关卡禁用与解除
	*/
	public function deleteMission(){
		$missionId = intval(post('mission_id'));
		$actionCode = intval(post('action_code'));
		$actionName = $actionCode == 1 ? '禁用' : '解除';
		$aData = array(
			'id' => $missionId,
			'is_forbidden' => $actionCode,
		);
		$oMission = m('Mission');
		$aMissionInfo = $oMission->getMissionInfoById($missionId);
		if($aMissionInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMissionInfo){
			alert('抱歉！数据出错，请联系管理员！', 0);
		}
		$this->_checkAllowedSubject($aMissionInfo['subject_id']);
		if($aMissionInfo['is_forbidden'] == $actionCode){
			alert('您的操作有误，请稍后再试！', 0);
		}
		$row = $oMission->setMission($aData);
		if($row === false){
			alert('抱歉，系统有误，请稍后再试！');
		}elseif($row){
			alert($actionName . '成功！');
		}elseif($row == 0){
			alert('您没有修改！', 0);
		}
	}

	private function _checkAllowedSubject($subjectId){
		$aAllowSubjectId = m('Manager')->getUserAllowedSubjectByUserId($this->_userId);
		if($aAllowSubjectId === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aAllowSubjectId){
			alert('没有可操作的科目', 0);
		}
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('抱歉！您选的科目有误，请联系管理员！', 0);
		}
		if(!in_array($subjectId, $aAllowSubjectId)){
			alert('您没有管理 ' . $GLOBALS['SUBJECT'][$subjectId] . '关卡的权限', 0);
		}
	}

	/*
	 * 关卡题目数统计
	 */
	public function showEsCountStatistic(){
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);

		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		$aAllowedSubject = array();
		foreach($aAllowSubjectId  as $subjectId){
			$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
		}
		if(!$aAllowedSubject){
			alert('没有可操作的科目', 0);
		}
		assign('aSubject', $aAllowedSubject);

		$aDayType = array(
			1 => 3,
			2 => 7,
			3 => 15,
			4 => 30,
			5 => 0
		);
		assign('aDayType', $aDayType);
		$dayType = get('dayType', 0);
		assign('dayType', $dayType);
		if($dayType){
			if(!array_key_exists($dayType, $aDayType)){
				alert('错误的类型', 0);
			}

			$endTime = time();
			$startTime = $dayType == 5 ? 1356969600 : $endTime - 86400 * $aDayType[$dayType];
		}else{
			$startTime = get('startTime');
			$endTime = get('endTime');
			if(!$startTime){
				$startTime = time() - 86400 * 7;
			}elseif(!is_numeric($startTime)){
				$startTime = strtotime($startTime);
			}
			if(!$endTime){
				$endTime = time();
			}elseif(!is_numeric($endTime)){
				$endTime = strtotime($endTime);
			}
		}
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		$url .= '&startTime=' . $startTime . '&endTime=' . $endTime;
		//科目ID
		$subject = get('subject', 0);
		if(!$subject){
			if(isset($_COOKIE['lastEsSubjectId'])){
				$subject = $_COOKIE['lastEsSubjectId'];
			}else{
				$subject = $aAllowSubjectId[0];
				setcookie('lastEsSubjectId', $subject, time() + 2592000, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
			}
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		if(!in_array($subject, $aAllowSubjectId )){
			alert('您没有权限操作此科目', 0);
		}
		$url .= '&subject=' . $subject;
		assign('subjectId', $subject);
		$oMission = m('Mission');
		/*$missionCount = $oMission->getMissionCount($subject);
		$pageSize = 15;
		$pageCount = ceil($missionCount/$pageSize);
		$page = get('page', 1);
		if($page < 1){
			$page = 1;
		}elseif($page > $pageCount){
			$page = $pageCount;
		}
		//分页HTML
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $missionCount,
			'selector' => 1,
			'size' => $pageSize,
			'page' => $page
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);*/
		$oEs = m('Es');
		$aMissionEsStatisticList = $oEs->getEsCountForMissionStatistic($subject, $startTime, $endTime);
		assign('aMissionEsStatisticList', $aMissionEsStatisticList);
		displayHeader();
		display('mission/statistic_list.html.php');
		displayFooter();
	}
}