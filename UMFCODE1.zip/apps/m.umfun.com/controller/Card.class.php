<?php
class CardController{
	private $_permissionFlag = 'manage_ub_card';
	private $_userId = 0;

	/*
	private $_aRechargeTypeName = array(
			1 => '购卡充值',
			2 => '支付宝',
			3 => '银联',
			4 => 'API月结'
	);
	*/

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			wrong('您没有权限对此操作');
		}
	}

	//取所有代理商ID和NAME
	private function _getPorxyList(){
		$returnAarray = array();
		$aProxyList = array();
		$oProxy = m('Proxy');
		$aProxyCount = $oProxy->getProxyUserCount();
		if($aProxyCount === false){
			alert('抱歉，系统有误，请稍后再试！', 0);
		}elseif($aProxyCount > 0){
			$aProxyList = $oProxy->getProxyUserList(1, $aProxyCount);
			if($aProxyList === false){
				alert('抱歉！系统错误，请稍后再试！', 0);
			}elseif($aProxyList){
				foreach($aProxyList as $key=>$aProxyInfo){
					$returnAarray[$key]['id'] = $aProxyInfo['id'];
					$returnAarray[$key]['name'] = $aProxyInfo['name'];
				}
			}
		}
		unset($aProxyList);
		return $returnAarray;
	}

	//批次列表
	public function showBatchList(){
		$url = '?m=Card&a=showBatchList&page=_PAGE_';

		$batchId = intval(get('batchId'));
		$money = intval(get('money'));
		$overTime = get('overTime');
		$createTime = get('createTime');
		$cardType = get('cardType');
		$isRelease = get('isRelease');
		$isRecycle = get('isRecycle');
		$proxyId = intval(get('proxyId'));

		if($batchId > 0){
			$url .= '&batchId=' . $batchId;
		}

		if($money > 0){
			$url .= '&money=' . $money;
		}
		if($overTime){
			$url .= '&overTime=' . $overTime;
		}
		if($createTime){
			$url .= '&createTime=' . $createTime;
		}
		if($cardType){
			$url .= '&cardType=' . $cardType;
		}
		if($isRelease){
			$url .= '&isRelease=' . $isRelease;
		}
		
		$page = intval(get('page', 1));
		$pageSize = 20;
		$pageHtml = '';
		$aBatchList = array();

		if($page < 1){
			$page = 1;
		}

		$oRecharge = m('Recharge');
		$count = $oRecharge->getBatchCount($batchId, $money, $overTime, $createTime, $cardType, $isRelease, $isRecycle, $proxyId);
		if($count === false){
			alert('抱歉！系统错误，请稍后再试！', 0);
		}elseif($count > 0){
			$pageCount = ceil($count / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}

			$aBatchList = $oRecharge->getBatchList($batchId, $money, $overTime, $createTime, $cardType, $isRelease, $isRecycle, $proxyId, $page, $pageSize);
			if($aBatchList === false){
				alert('抱歉！系统错误，请稍后再试！', 0);
			}elseif($aBatchList){
				$oProxy = m('Proxy');
				foreach($aBatchList as $key => $aBatchInfo){
					$aBatchList[$key]['proxyName'] = '';
					if($aBatchInfo['proxy_id'] > 0){
						$aProxyInfo = $oProxy->getProxyUserInfoById($aBatchInfo['proxy_id']);
						if($aProxyInfo){
							$aBatchList[$key]['proxyName'] = $aProxyInfo['name'];
						}
					}
				}
			}
			$aPageInfo = array(
				'url' 	=> '?m=Card&a=showBatchList&page=_PAGE_',
				'total' => $count,
				'size' 	=> $pageSize,
				'page' 	=> $page,
			);

			$pageHtml = page($aPageInfo);
		}
		
		$proxyList = $this->_getPorxyList();

		assign('batchId', $batchId);
		assign('money', $money);
		assign('overTime', $overTime);
		assign('createTime', $createTime);
		assign('cardType', $cardType);
		assign('isRelease', $isRelease);
		assign('isRecycle', $isRecycle);
		assign('proxyId', $proxyId);
		assign('proxyList', $proxyList);
		assign('aBatchList', $aBatchList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('card/batch_list.html.php');
		displayFooter();
	}

	//批量回收
	public function batchRecycle(){
		$id = intval(post('id'));
		$oRecharge = m('Recharge');
		$aBatchData = array(
			'id' 			=> $id,
			'is_recycle'	=> 1,
			'recycle_time' 	=> time(),
		);
		$aBatchInfo = $oRecharge->getBatchInfoById($aBatchData['id']);
		if($aBatchInfo === false){
			alert('抱歉！系统错误，请稍后再试！', 0);
		}elseif(!$aBatchInfo){
			alert('批次不存在', 0);
		}elseif($aBatchInfo['is_recycle'] == 1){
			alert('此批次己是回收状态', 0);
		}
		
		$aRecycleResult = $oRecharge->setBatch($aBatchData);
		if($aRecycleResult === false){
			alert('抱歉！系统错误，请稍后再试！', 0);
		}elseif($aRecycleResult){
			alert('回收成功');
		}else{
			alert('回收失败！', 0);
		}
	}

	//批量发行视图
	function showBatchRelease(){
		$aProxyList = $this->_getPorxyList();
		$id = intval(get('id'));
		$aBatchInfo = m('Recharge')->getBatchInfoById($id);
		if($aBatchInfo === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}
		assign('aProxyList', $aProxyList);
		assign('aBatchInfo', $aBatchInfo);
		displayHeader();
		display('card/batch_release.html.php');
		displayFooter();
	}

	//批量发行
	function BatchRelease(){
		$batchId = intval(post('batch_id', 0));
		$proxyId = intval(post('proxy_id', 0));
		$oRecharge = m('Recharge');

		//查询批次是否存在及批次发行状态
		$aBatchInfo = $oRecharge->getBatchInfoByBatchId($batchId);
		if($aBatchInfo === false){
			alert('抱歉！系统错误，请稍后再试！', 0);
		}elseif(!$aBatchInfo){
			alert('批次号不存在', 0);
		}elseif($aBatchInfo['is_release'] == 1){
			alert('此批次己发行', 0);
		}

		//查询代理商是否存在
		$aPrxoyInfo = m('Proxy')->getProxyUserInfoById($proxyId);
		if($aPrxoyInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aPrxoyInfo){
			alert('代理商不存在', 0);
		}

		//更新批次表
		$aBatchData = array(
			'id' 			=> $aBatchInfo['id'],
			'is_release'	=> 1,
			'proxy_id'		=> $proxyId,
			'release_time'	=> time(),
		);
		$aBatchResult = $oRecharge->setBatch($aBatchData);
		if($aBatchResult === false){
			alert('抱歉，系统有误，请稍后再试！', 0);
		}elseif($aBatchResult){
			alert('发行成功');
		}else{
			alert('抱歉！发行失败，请稍后再试！', 0);
		}
	}

	//ub充值卡列表
	public function showUbCardList(){
		$cardId = get('cardId', '');
		$batchId = intval(get('batchId'));
		$money = intval(get('money'));
		$overTime = get('overTime', '');
		$createTime = get('createTime', '');
		$isRelease = get('isRelease', '');
		$isPayed = get('isPayed', '');
		$isRecycle = get('isRecycle', '');
		$proxyId = intval(get('proxyId'));
		$url = '?m=Card&a=showUbCardList&page=_PAGE_';
		if(preg_match('/^[A-Z0-9]{20}$/', $cardId)){
			$url .= '&cardId=' . $cardId;
		}

		if(preg_match('/^\d{10}$/', $batchId)){
			$url .='&batchId=' . $batchId;
		}

		if(w('range(1,10000)', $money)){
			$url .= '&money=' . $money;
		}

		if($overTime){
			$url .= '&overTime=' . $overTime;
		}

		if($createTime){
			$url .= '&createTime=' . $createTime;
		}

		if($isRelease == 0 || $isRelease == 1){
			$url .= '&isRelease=' . $isRelease;
		}

		if($isPayed == 0 || $isPayed == 1){
			$url .= '&isPayed=' . $isPayed;
		}

		if($isRecycle == 0 || $isRecycle == 1){
			$url .= '&isRecycle=' . $isRecycle;
		}

		if($proxyId > 0){
			$url .= '&proxyId=' . $proxyId;
		}

		$pageHtml = '';
		$page = intval(get('page', 1));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 100;
		$aCardList = array();
		$oRecharge = m('Recharge');
		$oProxy = m('Proxy');
		$count = $oRecharge->getUbRechargeCardCount($cardId, $batchId, $isPayed, $money, $createTime, $overTime, $isRelease, $isRecycle, $proxyId);
		if($count === false){
			alert('抱歉！系统错误，请稍后再试！', 0);
		}elseif($count > 0){
			$pageCount = ceil($count / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aCardList = $oRecharge->getUbRechargeCardList($cardId, $batchId, $isPayed, $money, $createTime, $overTime, $isRelease, $isRecycle, $proxyId, $page, $pageSize);
			if($aCardList === false){
				alert('抱歉！系统错误，请稍后再试！', 0);
			}
			$pageHtml = page(array(
				'url' 	=> $url,
				'total' => $count,
				'size' 	=> $pageSize,
				'page' 	=> $page,
			));
		}
		$proxyList = $this->_getPorxyList();

		assign('proxyList', $proxyList);
		assign('cardId', $cardId);
		assign('batchId', $batchId);
		assign('money', $money);
		assign('overTime', $overTime);
		assign('createTime', $createTime);
		assign('isRelease', $isRelease);
		assign('isPayed', $isPayed);
		assign('isRecycle', $isRecycle);
		assign('proxyId', $proxyId);
		assign('aCardList', $aCardList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('card/ub_card_list.html.php');
		displayFooter();
	}

	//UB卡添加视图
	public function showUbCardAdd(){
		assign('validateAddAnnouncementJs', j('batch_id,money,quantity,over_time'));
		//取所有代理商信息
		$aProxyList = $this->_getPorxyList();
		assign('aProxyList', $aProxyList);
		displayHeader();
		display('card/ub_card_add.html.php');
		displayFooter();
	}

	//UB卡添加
	public function ubCardAdd(){
		$vAddResult = v('batch_id,money,quantity,over_time');
		if($vAddResult){
			alert($vAddResult, 0);
		}

		$quantity = intval(post('quantity', 0));
		$batchNo = intval(post('batch_id'));
		$money = intval(post('money'));
		$isRelease = intval(post('is_release', 0));
		$overTime = strtotime(post('over_time', ''));
		$proxyId = intval(post('proxy_id'));

		if(!w('range(1,10000)', $money)){
			alert('金额为1到10000之间的正整数', 0);
		}
		if(!w('range(1,10000)', $quantity)){
			alert('最多只能添加10000张充值卡', 0);
		}

		//如果是发行状态　则要求指定代理商
		if($isRelease == 1){
			if($proxyId > 0){
				$oProxy = m('Proxy');
				$aProxyInfo = $oProxy->getProxyUserInfoById($proxyId);
				if($aProxyInfo === false){
					alert('抱歉！系统有误，请稍后再试！', 0);
				}elseif(!$aProxyInfo){
					alert('代理商不存在', 0);
				}
			}else{
				alert('请指定代理商后发行', 0);
			}
		}elseif($isRelease == 0){
			$proxyId = 0;
		}

		$oRecharge = m('Recharge');
		//查询批次号是否己使用
		$aBatch = $oRecharge->getBatchInfoByBatchId($batchNo);
		if($aBatch === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($aBatch){
			alert('批次号己被使用,请修改批次号', 0);
		}

		//判断卡资源表中可用资源是否够用
		$aCardResourceCount = $oRecharge->getResourceCount();
		if($aCardResourceCount === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aCardResourceCount || $aCardResourceCount < $quantity){
			alert('卡号资源不足', 0);
		}

		//写卡表//
		$cardNums = $oRecharge->addUbRechargeCard(array(
			'batch_id' 		=> $batchNo,
			'card_money' 	=> $money,
			'card_quantity' => $quantity,
			'card_type'		=> 1,
			'over_time'		=> $overTime,
			'is_release' 	=> $isRelease,
			'is_recycle'	=> 0,
			'proxy_id'		=> $proxyId,
			'create_time' 	=> time(),
		));
		if($cardNums === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($cardNums){
			alert('成功添加 ' . $cardNums . ' 张卡片', 1, '?m=Card&a=showMonthCardList');
		}else{
			alert('添加失败，请联系管理员查看错误日志', 0);
		}

		//查询批次号是否己使用
		$aBatchCheckResult = $oRecharge->getBatchInfoByBatchId($batchNo);
		if($aBatchCheckResult === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($aBatchCheckResult){
			alert('批次号己被使用,请修改批次号', 0);
		}

		//创建批次信息
		$aBatchData = array(
			'batch_id' 		=> $batchNo,
			'card_money' 	=> $money,
			'card_quantity' => $quantity,
			'card_type'		=> 1,
			'over_time'		=> $overTime,
			'is_release' 	=> $isRelease,
			'is_recycle'	=> 0,
			'proxy_id'		=> $proxyId,
			'create_time' 	=> time(),
		);
		$aBatchInsertResult = $oRecharge->addBatch($aBatchData);
		if($aBatchInsertResult === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aBatchInsertResult){
			alert('批次信息创建失败', 0);
		}

		//写卡表
		$aResult =$oRecharge->addUbRechargeCard($quantity, $aData);
		if($aResult === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($aResult){
			alert('添加成功');
		}else{
			alert('添加失败', 0);
		}
	}

	/**
	 * UB卡回收
	 */
	/*
	function ubCardRecycle(){
		$id = intval(post('id',0));
		if($id < 1){
			alert('充值卡不存在', 0);
		}
		$oRecharge = new RechargeModel();
		$aCardInfo = $oRecharge->getUbRechargeCardInfoById($id);
		if(!$aCardInfo){
			alert('充值卡不存在', 0);
		}
		if($aCardInfo['is_release'] == 1){
			alert('充值卡己发行,不能回收哦', 0);
		}

		if($aCardInfo['is_payed'] == 1){
			alert('充值卡己充值,不能回收哦', 0);
		}

		$aData = array(
			'id'		 => $id,
			'is_recycle' => 1
		);
		$aResult = $oRecharge->setUbRechargeCardById($aData);
		if($aResult !== false){
			alert('操作成功',1);
		}else{
			alert('操作失败',0);
		}
	}
	

	//UB卡发行 视图
	function showUbCardRelease(){
		$aProxyList = $this->_getPorxyList();
		$id = intval(get('id'));
		$aCardInfo = m('Recharge')->getUbRechargeCardInfoById($id);
		if($aCardInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		assign('aProxyList', $aProxyList);
		assign('aCardInfo', $aCardInfo);
		displayHeader();
		display('card/ub_card_release.html.php');
		displayFooter();
	}


	//UB卡发行
	function ubCardRelease(){
		$aData = array(
			'id' 			=> intval(post('id')),
			'proxy_id'		=> intval(post('proxy_id'))	,
			'is_release'  	=> 1,
			'release_time'	=> time(),
		);
		$aProxyInfo = m('Proxy')->getProxyUserInfoById($aData['proxy_id']);
		if($aProxyInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aProxyInfo){
			alert('代理商不存在', 0);
		}
		$aResult = m('Recharge')->setUbRechargeCardById($aData);
		if($aResult !== false){
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}
	*/
	
	//月费卡列表
	public function showMonthCardList(){
		$cardId = get('cardId');
		$batchId = intval(get('batchId'));
		$month = intval(get('month'));
		$overTime = get('overTime');
		$createTime = get('createTime');
		$cardType = intval(get('cardType'));
		$isRelease = get('isRelease');
		$isPayed = get('isPayed', '');
		$isRecycle = get('isRecycle');
		$proxyId = get('proxyId');

		$url = '?m=Card&a=showMonthCardList&page=_PAGE_';

		if(preg_match('/^[A-Z0-9]{20}$/', $cardId)){
			$url .= '&cardId=' . $cardId;
		}
		if(preg_match('/^\d{10}$/', $batchId)){
			$url .='&batchId=' . $batchId;
		}

		if($month > 0){
			$url .= '&month=' . $month;
		}

		if($overTime){
			$url .= '&overTime=' . $overTime;
		}

		if($createTime){
			$url .= '&createTime=' . $createTime;
		}

		if($cardType == '2' || $cardType == '3'){
			$url .= '&cardType=' . $cardType;
		}

		if($isRelease == '0' || $isRelease == '1'){
			$url .= '&isRelease=' . $isRelease;
		}

		if($isPayed == '0' || $isPayed == '1'){
			$url .= '&isPayed=' . $isPayed;
		}

		if($isRecycle == '0' || $isRecycle == '1'){
			$url .= '&isRecycle=' . $isRecycle;
		}

		if($proxyId > 0){
			$url .= '&proxyId=' . $proxyId;
		}

		$pageHtml = '';
		$page = intval(get('page', 1));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 100;
		$aCardList = array();

		$oRecharge = m('Recharge');
		$count = $oRecharge->getMonthlyFeeRechargeCardCount($cardId, $batchId, $isPayed, $month, $createTime, $overTime, $cardType, $isRelease, $isRecycle, $proxyId);

		if($count === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($count >0){
			$pageCount = ceil($count/$pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aCardList = $oRecharge->getMonthlyFeeRechargeCardList($cardId, $batchId, $isPayed, $month, $createTime, $overTime,  $cardType, $isRelease, $isRecycle, $proxyId, $page, $pageSize);
			if($aCardList === false){
				alert('抱歉！系统有误，请稍后再试！', 0);
			}

			$aPageInfo = array(
				'url' 	=> $url,
				'total' => $count,
				'size' 	=> $pageSize,
				'page' 	=> $page,
			);
			$pageHtml = page($aPageInfo);
		}
		$proxyList = $this->_getPorxyList();

		assign('proxyList', $proxyList);
		assign('cardId', $cardId);
		assign('batchId', $batchId);
		assign('month', $month);
		assign('overTime', $overTime);
		assign('createTime', $createTime);
		assign('cardType', $cardType);
		assign('isRelease', $isRelease);
		assign('isPayed', $isPayed);
		assign('isRecycle', $isRecycle);
		assign('proxyId', $proxyId);
		assign('aCardList', $aCardList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('card/month_card_list.html.php');
		displayFooter();
	}

	//月费卡添加视图
	public function showMonthCardAdd(){
		assign('validateAddAnnouncementJs', j('batch_id,quantity,over_time'));
		assign('aProxyList', $this->_getPorxyList());
		displayHeader();
		display('card/month_card_add.html.php');
		displayFooter();
	}

	//月费卡添加
	public function monthCardAdd(){
		$vAddResult = v('batch_id,quantity,over_time');
		if($vAddResult){
			alert($vAddResult, 0);
		}
		$quantity = intval(post('quantity', 0));
		$cardType = intval(post('card_type', 0));
		$isRelease = intval(post('is_release', 0));
		$overTime = strtotime(post('over_time', ''));
		$proxyId = intval(post('proxy_id'));
		$month = intval(post('month'));
		$batchNo = intval(post('batch_id'));

		if(!w('_in(2,3)', $cardType)){
			alert('发行类型错误' ,0);
		}
		if(!w('range(1,24)', $month)){
			alert('最大有效时长为24个月', 0);
		}
		if(!w('range(1,10000)', $quantity)){
			alert('最多只能添加10000张充值卡', 0);
		}
		if($overTime < strtotime('+6month')){
			alert('至少6个月后才能过期', 0);
		}

		//如果是发行状态　则要求指定代理商
		if($isRelease == 1){
			if($proxyId > 0){
				$oProxy = m('Proxy');
				$aProxyInfo = $oProxy->getProxyUserInfoById($proxyId);
				if($aProxyInfo === false){
					alert('抱歉！系统有误，请稍后再试！', 0);
				}elseif(!$aProxyInfo){
					alert('代理商不存在', 0);
				}
			}else{
				alert('请指定代理商后发行', 0);
			}
		}elseif($isRelease == 0){
			$proxyId = 0;
		}

		$oRecharge = m('Recharge');
		//查询批次号是否己使用
		$aBatch = $oRecharge->getBatchInfoByBatchId($batchNo);
		if($aBatch === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($aBatch){
			alert('批次号己被使用,请修改批次号', 0);
		}

		//写卡表//
		$cardNums = $oRecharge->addMonthlyFeeRechargeCard(array(
			'batch_id' 		=> $batchNo,
			'card_money' 	=> $month,
			'card_quantity' => $quantity,
			'card_type'		=> $cardType,
			'over_time'		=> $overTime,
			'is_release' 	=> $isRelease,
			'is_recycle'	=> 0,
			'proxy_id'		=> $proxyId,
			'create_time' 	=> time(),
		));
		if($cardNums){
			alert('成功添加 ' . $cardNums . ' 张卡片', 1, '?m=Card&a=showMonthCardList');
		}else{
			alert('添加失败，请联系管理员查看错误日志', 0);
		}
	}

	//月费卡回收
	/*
	function monthCardRecycle(){
		$id = intval(post('id', 0));
		if($id < 1){
			alert('充值卡不存在', 0);
		}
		$oRecharge = m('Recharge');
		$aCardInfo = $oRecharge->getMonthlyFeeRechargeCardInfoById($id);
		if($aCardInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aCardInfo){
			alert('充值卡不存在', 0);
		}elseif($aCardInfo['is_release'] == 1){
			alert('充值卡己发行,不能回收哦', 0);
		}elseif($aCardInfo['is_payed'] == 1){
			alert('充值卡己充值,不能回收哦', 0);
		}

		$aData = array(
			'id'		 => $id,
			'is_recycle' => 1,
		);
		$aResult = $oRecharge->setMonthlyFeeRechargeCardById($aData);
		if($aResult !== false){
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}
	

	//月费卡发行视图
	function showMonthCardRelease(){
		$aProxyList = $this->_getPorxyList();
		$id = intval(get('id'));
		$aCardInfo = m('Recharge')->getMonthlyFeeRechargeCardInfoById($id);
		if($aCardInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		assign('aProxyList', $aProxyList);
		assign('aCardInfo', $aCardInfo);
		displayHeader();
		display('card/month_card_release.html.php');
		displayFooter();
	}

	//月费卡发行
	function monthCardRelease(){
		$aData = array(
			'id' 			=> intval(post('id')),
			'proxy_id'		=> intval(post('proxy_id')),
			'is_release' 	=> 1,
			'release_time'	=> time(),
		);
		$aProxyInfo = m('Proxy')->getProxyUserInfoById($aData['proxy_id']);
		if($aProxyInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aProxyInfo){
			alert('代理商不存在', 0);
		}
		$aResult = m('Recharge')->setMonthlyFeeRechargeCardById($aData);
		if($aResult !== false){
			alert('操作成功');
		}else{
			alert('操作失败', 0);
		}
	}
	*/
}