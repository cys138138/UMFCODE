<?php
class AccountController{
	private $_manageManagerFlag = 'manage_manager';
	private $_managePermissionFlag = 'manage_permission';

	public function __construct(){}

	/**
	* 显示登录界面
	*/
	public function showLogin(){
		assign('validateJs', j('email,password,captcha'));
		displayHeader();
		display('account/login.html.php');
		displayFooter();
	}

	/**
	* 登录
	*/
	public function login(){
		$vResult = v('email,password,captcha');
		if($vResult){
			alert($vResult, 0);
		}

		$umfunCaptcha = post('captcha');
		$verifyResult = verify::match('login_captcha', $umfunCaptcha);
		if(!$verifyResult){
			alert('验证码错误，请重新输入', 0);
		}

		$email = post('email');
		$password = post('password');
		$rememberPassword = post('rememberPassword');
		$aUserInfo = m('Manager')->getUserInfoByEmailAndPassword($email, $password);
		if($aUserInfo === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($aUserInfo){
			if($aUserInfo['is_forbidden'] == 1){
				alert('抱歉，您的账号已经被禁用，请联系管理员！', 0);
			}
			$userId = $aUserInfo['id'];
			Cookie::setEncrypt('m_userId', $userId, time() + 99999999999);
			$userAgent = $_SERVER['HTTP_USER_AGENT'];
			$rememberPasswordCode = md5($userAgent . $userId);
			if($rememberPassword == 1){
				Cookie::setXcrypt('m_rememberPassword', $rememberPasswordCode, time() + 31536000);
			}else{
				Cookie::setXcrypt('m_rememberPassword', $rememberPasswordCode);
			}
			alert('登录成功！', 1, '/?m=Index&a=index');
		}else{
			alert('用户名或密码错误！', 0);
		}
	}

	/**
	* 退出
	*/
	public function logOut(){
		Cookie::delete('m_userId');
		Cookie::delete('captcha');
		Cookie::delete('m_rememberPassword');
		Cookie::delete('lastSubjectId');
		header('location:?m=Account&a=showLogin');
	}

	/**
	* 显示个人信息
	*/
	public function showPersonalInfo(){
		$userId = checkLogin();
		$oManager = m('Manager');
		$aPersonalInfo = $oManager->getUserInfoByUserId($userId);
		if($aPersonalInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		$aGroupInfo = $oManager->getGroupInfoByGroupId($aPersonalInfo['group_id']);
		if($aGroupInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		$aPersonalInfo['permissionName'] = array();
		foreach($GLOBALS['PERMISSION'] as $aPermissionLitleGroup){
			foreach($aPermissionLitleGroup['child'] as $key => $aPermission){
				if(!in_array($key, $aGroupInfo['permission'])){
					continue;
				}
				$aPersonalInfo['permissionName'][] = $aPermission['title'];
			}
		}
		$aPersonalInfo['groupName'] = $aGroupInfo['name'];
		assign('validatePersonalInfoJs', j('username', 'checkUsername'));
		assign('validatePasswordJs', j('password'));
		assign('aPersonalInfo', $aPersonalInfo);
		displayHeader();
		display('account/personal_info.html.php');
		displayFooter();
	}

	/**
	* 保存个人信息
	*/
	public function savePersonalInfo(){
		$userId = checkLogin();
		$vPersonalInfo = v('username');
		if($vPersonalInfo){
			alert($vPersonalInfo, 0);
		}
		$name = post('username');
		$aData = array(
			'id' => $userId,
			'name' => $name,
		);
		$saveRow = m('Manager')-> setUserInfo($aData);
		if($saveRow === false){
			alert('系统出错，请稍后再试', 0);
		}elseif($saveRow){
			alert('修改成功');
		}elseif($saveRow == 0){
			alert('您没有修改', 0);
		}
	}

	/**
	* 保存密码
	*/
	public function savePassword(){
		$userId = checkLogin();
		$vPassword = v('password');
		if($vPassword){
			alert($vPassword, 0);
		}
		$oldPassword = post('old_password');
		$newPassword = post('password');
		$oManager = m('Manager');
		$aUserInfo = $oManager->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		if($oManager->xCrypt($oldPassword) != $aUserInfo['password']){
			alert('您输入的原密码有误,请确认！', 0);
		}
		$aData = array(
			'id' => $userId,
			'password' => $newPassword,
		);
		$saveRow = $oManager->setUserInfo($aData);
		if($saveRow === false){
			alert('系统出错，请稍后再试', 0);
		}elseif($saveRow){
			alert('修改成功');
		}elseif($saveRow == 0){
			alert('您没有修改！', 0);
		}
	}

	/**
	* 显示用户列表
	*/
	public function showUserList(){
		tipsNewManage();
		$myUserId = checkLogin();
		$oManager = m('Manager');
		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$referer = getMarkedReferer();
		if(!checkPermission($myUserId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}

        //用户搜索
        //搜索用户类型 -用户名[Default] -用户邮箱
        $searchUserType = intval(get('searchUserType',1));
        $searchUserValue = get('searchUserValue','');
        $starteTime  = strtotime(get('starteTime',0));
        $endTime = strtotime(get('endTime',0));
        $isForbidden = intval(get('isForbidden',0));
        $groupId = intval(get('groupId',0));

        if($isForbidden === 0){
            $isForbidden = '';
        }else{
            $isForbidden = $isForbidden;
        }

        $pageSize = 15;
        $page = intval(get('page', 1));
        $page = $page > 0 ? $page : 1;

        if($searchUserValue || $endTime && $starteTime || $isForbidden || $groupId){

           if($searchUserType == '2'){
                $searchUserEmail = $searchUserValue;
                $searchUserValue = '' ;
            }
            else{
                $searchUserEmail = '';
            }
            $countSearch = $oManager->getUserList($searchUserValue, $searchUserEmail, $starteTime, $endTime, $isForbidden, $groupId,1,1000);
            if($countSearch === false){
                alert('系统出错，请稍后再试', 0);
    		}
            $userCount = count($countSearch);
            $aUserList = $oManager->getUserList($searchUserValue, $searchUserEmail, $starteTime, $endTime, $isForbidden, $groupId, $page, $pageSize);

        }
        else{

             $aUserList = $oManager->getUserListByGroupId();
    		if($aUserList === false){
                alert('系统出错，请稍后再试', 0);
    		}
            $userCount = count($aUserList);

            $offset = ($page - 1) * $pageSize;
    		$aUserList = $oManager->getUserListByGroupId('', '`id` DESC', $offset, $pageSize);
        }

        if($aUserList === false){
            alert('系统出错，请稍后再试', 0);
		}
		foreach($aUserList as $key => $userList){
			$groupName = $oManager->getGroupNameByGroupId($userList['group_id']);
			if($groupName === false){
				alert('系统出错，请稍后再试',0);
			}
   			$aUserList[$key]['group_name'] = $groupName;
   		}

        $url = preg_replace('/&page\=\d+/', '', $url);

		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $userCount,
			'size' => $pageSize,
			'page' => $page,
		);

		$pageHtml = page($aPageInfo);
        assign('countUser', $userCount);
        assign('aGroupList', $oManager->getGroupList());
        assign('baseUrl', $url);
		assign('pageHtml', $pageHtml);
		assign('referer', $referer);
		assign('myUserId', $myUserId);
		assign('aUserList', $aUserList);
		displayHeader();
		display('account/user_list.html.php');
		displayFooter();
	}

	public function checkUserExists(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$username = post('name');
		$isExistsUserName = m('Manager')->getUserCountByName($username);
		if($isExistsUserName === false){
			alert('抱歉，系统有误，请稍后再试！', 0);
		}elseif($isExistsUserName){
			alert('发现已存在同名用户,如果确实不是同一个人,可以继续添加');
		}else{
			alert('还没有人用过这个名字哦', 0);
		}
	}


	/**
	* 显示添加用户页面
	*/
	public function showAddUser(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$aGroupList = m('Manager')->getGroupList();
		if($aGroupList === false){
			alert('系统出错，请稍后再试', 0);
		}
		assign('validateAddUserJs', j('username,email,password,age,gender,address,tel,comment'));
		assign('aGroupList', $aGroupList);
		displayHeader();
		display('account/user_add.html.php');
		displayFooter();
	}

	/**
	* 添加用户
	*/
	public function addUser(){
		$userId = checkLogin();
		$vAddResult = v('username,email,password,age,gender,address,tel,comment');
		if($vAddResult){
			alert($vAddResult, 0);
		}
		$qq = post('qq');
		if(strlen($qq) > 0){
			$isNumber = w('isNumber()', $qq);
			$isLength = w('length(5,12)', $qq);
			if(!$isNumber || !$isLength){
				alert('请输入5到12位的QQ号码');
			}
		}
		if(!checkPermission($userId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$groupId = post('permission_group_id');
		$email = post('email');
		$password = post('password');
		$name = post('username');
		$age = post('age');
		$gender = post('gender');
		$address = post('address');
		$tel = post('tel');
		$comment = post('comment');
		$aSubject = post('subject');
		$oManager = m('Manager');
		$aUserList = $oManager->getUserInfoByEmail($email);
		if($aUserList === false){
			alert('抱歉，系统有误，请稍后再试！', 0);
		}elseif($aUserList){
			alert('这个邮箱已存在，请用另外一个', 0);
		}

		$aPersonalInfo = array(
			'qq' => $qq,
			'age' => $age,
			'gender' => $gender,
			'address' => $address,
			'tel' => $tel,
			'comment' => $comment
		);
		$aData = array(
			'group_id' => $groupId,
			'email' => $email,
			'password' => $password,
			'name' => $name,
			'personal_info' => $aPersonalInfo,
			'allowed_subject' => $aSubject,
			'create_time' => time(),
			'is_forbidden' => 2,
		);
		$addUserId = $oManager->addUser($aData);
		if($addUserId === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($addUserId){
			alert('添加成功', 1, '?m=Account&a=showUserList');
		}else{
			alert('添加失败', 0);
		}
	}

	/**
	* 显示编辑用户页面
	*/
	public function showEditUser(){
		$myUserId = checkLogin();
		$userId = get('id');
		if(!checkPermission($myUserId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$oManager = m('Manager');
		$aUserInfo = $oManager->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		$aGroupList = $oManager->getGroupList();
		if($aGroupList === false){
			alert('系统出错，请稍后再试', 0);
		}
		assign('validateEditUserJs', j('username,qq,age,gender,address,tel,comment'));
		assign('aGroupList', $aGroupList);
		assign('aUserInfo', $aUserInfo);
		displayHeader();
		display('account/user_edit.html.php');
		displayFooter();
	}

	/**
	* 编辑用户
	*/
	public function editUser(){
		$myUserId = checkLogin();
		if(!checkPermission($myUserId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$vEditUser = v('username,qq,age,gender,address,tel,comment');
		if($vEditUser){
			alert($vEditUser, 0);
		}
		$qq = post('qq');
		if(strlen($qq) > 0){
			$isNumber = w('isNumber()', $qq);
			$isLength = w('length(5,12)', $qq);
			if(!$isNumber || !$isLength){
				alert('请输入5到12位的QQ号码');
			}
		}
		$name = post('username');
		$userId = post('user_id');
		$groupId = post('group_id');
		$subject = post('allowed_subject');
		$password = post('password');
		$age = post('age');
		$gender = post('gender');
		$address = post('address');
		$tel = post('tel');
		$comment = post('comment');
		$aPersonalInfo = array(
			'qq' => $qq,
			'age' => $age,
			'gender' => $gender,
			'address' => $address,
			'tel' => $tel,
			'comment' => $comment
		);
		$aData = array(
			'id' => $userId,
			'group_id' => $groupId,
			'name' => $name,
			'personal_info' => $aPersonalInfo,
			'allowed_subject' => $subject,
		);
		if(!$subject){
			$aData['allowed_subject'] = array();
		}
		if($password){
			$vEditUser = v('password');
			if($vEditUser){
				alert($vEditUser, 0);
			}
			$aData['password'] = $password;
		}
		$row = m('Manager')->setUserInfo($aData);
		if($row === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($row){
			alert('修改成功', 1, '?m=Account&a=showUserList');
		}elseif($row == 0){
			alert('您没有修改！', 0);
		}
	}

	/**
	* 删除用户
	*/
	public function deleteUser(){
		$myUserId = checkLogin();
		if(!checkPermission($myUserId, $this->_manageManagerFlag)){
				alert('抱歉，您的权限不足！', 0);
		}
		$userId = post('id');
		if($myUserId == $userId){
			alert('抱歉，无法禁用自己！', 0);
		}
		$row = m('Manager')->deleteUserByUserId($userId);
		if($row === false){
			wrong('系统有误，请稍后再试！', 0);
		}elseif($row){
			alert('删除成功', 1, '?m=Account&a=showUserList');
		}else{
			alert('删除失败', 0);
		}
	}

	/**
	* 激活/禁用操作
	*/
	public function setForbidden(){
		$myUserId = checkLogin();
		if(!checkPermission($myUserId, $this->_manageManagerFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$userId = post('id');
		$tips = post('tips');
		$aData = array(
			'id' => $userId,
			'is_forbidden' => post('forbidden'),
		);
		$idForbidden = m('Manager')->setUserInfo($aData);
		if($idForbidden === false){
			alert('系统出错，请稍后再试', 0);
		}elseif($idForbidden){
			alert($tips . '成功');
		}else{
			alert($tips . '失败', 0);
		}
	}

	/**
	* 显示权限组列表
	*/
	public function showPermissionList(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		$oManager = m('Manager');
		$aGroupList = $oManager->getGroupList();
		if($aGroupList === false){
			alert('系统出错，请稍后再试', 0);
		}
		$userCount = count($aGroupList);
		$pageSize = 15;
		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;
		$offset = ($page - 1) * $pageSize;
		$aGroupList = $oManager->getGroupList('`id` DESC', $offset, $pageSize);
		if($aGroupList === false){
			alert('系统出错，请稍后再试', 0);
		}
		foreach($aGroupList as $key => $aGroup){
			$aGroupList[$key]['members'] = array();
			$aUserList = $oManager->getUserListByGroupId($aGroup['id']);
			foreach($aUserList as $aUser){
				$aGroupList[$key]['members'][] = $aUser['name'];
			}
			$aGroupList[$key]['member_count'] = count($aUserList);
		}

		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $userCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('aGroupList', $aGroupList);
		displayHeader();
		display('account/group_list.html.php');
		displayFooter();
	}

	/**
	* 显示添加权限组页面
	*/
	public function showAddPermissionGroup(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		assign('validateAddGroupJs', j('group_name'));
		displayHeader();
		display('account/group_add.html.php');
		displayFooter();
	}

	/**
	* 添加权限组
	*/
	public function addPermissionGroup(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$vAddGroup = v('group_name');
		if($vAddGroup){
			alert($vAddGroup, 0);
		}
		$groupName = post('group_name');
		$aPermission = post('permission');
		$aGroupResult = array(
			'name' => $groupName,
			'permission' => $aPermission,
		);
		$addGroupId = m('Manager')->addGroup($aGroupResult);
		if($addGroupId === false){
			alert('系统出错，请稍后再试', 0);
		}elseif($addGroupId){
			alert('添加成功', 1, '?m=Account&a=showPermissionList');
		}else{
			alert('添加失败', 0);
		}
	}

	/**
	* 显示编辑权限组页面
	*/
	public function showEditGroup(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$groupId = get('id');
		$aGroupInfo = m('Manager')->getGroupInfoByGroupId($groupId);
		if($aGroupInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		assign('validateEditGroupJs', j('group_name'));
		assign('aGroupInfo', $aGroupInfo);
		displayHeader();
		display('account/group_edit.html.php');
		displayFooter();
	}

	/**
	* 编辑权限组
	*/
	public function editGroup(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$vEditGroup = v('group_name');
		if($vEditGroup){
			alert($vEditGroup, 0);
		}
		$groupId = post('group_id');
		$groupName = post('group_name');
		$aPermission = post('permission');
		$aGroupResult = array(
			'id' => $groupId,
			'name' => $groupName,
			'permission' => $aPermission,
		);
		$row = m('Manager')->setGroupInfo($aGroupResult);
		if($row === false){
			alert('网络可能有点慢，请稍后再试！', 0);
		}elseif($row){
			alert('修改成功', 1, '?m=Account&a=showPermissionList');
		}elseif($row == 0){
			alert('您没有修改', 0);
		}
	}

	/**
	* 显示权限组详情
	*/
	public function showGroupDetail(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$groupId = get('id');
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'] . '&id=' . $groupId;
		$oManager = m('Manager');
		$aUserList = $oManager->getUserListByGroupId($groupId);
		if($aUserList === false){
			alert('系统出错，请稍后再试', 0);
		}
		$userCount = count($aUserList);
		$pageSize = 10;
		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;
		$offset = ($page - 1) * $pageSize;
		$aUserList = $oManager ->getUserListByGroupId($groupId, '', $offset, $pageSize);
		if($aUserList === false){
			alert('系统出错，请稍后再试', 0);
		}

		$groupName = $oManager->getGroupNameByGroupId($groupId);
		if($groupName === false){
			alert('系统出错，请稍后再试', 0);
		}

		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $userCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('groupName', $groupName);
		assign('aUserList', $aUserList);
		displayHeader();
		display('account/group_detail.html.php');
		displayFooter();
	}

	/**
	* 删除权限组
	*/
	public function deleteGroup(){
		$userId = checkLogin();
		if(!checkPermission($userId, $this->_managePermissionFlag)){
			alert('抱歉，您的权限不足！', 0);
		}
		$groupId = post('id');
		$oManager = m('Manager');
		$aUserList = $oManager->getUserListByGroupId($groupId);
		if($aUserList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if(count($aUserList)){
			alert('该分组还有用户，不能删除', 0);
		}

		$row = $oManager->deleteGroupByGroupId($groupId);
		if($row === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($row){
			alert('删除成功');
		}else{
			alert('删除失败', 0);
		}
	}
}