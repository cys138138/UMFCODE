<?php
class SystemController{
	public function showBaseOption(){
		displayHeader();
		display('system/base_option.html.php');
		displayFooter();
	}

	public function showPublicUser(){
		tipsNewManage();
		displayHeader();
		display('system/public_opton.html.php');
		displayFooter();
	}

	public function settingBaseOption(){
		$vResult = v('is_open_system_m,m_close_tip,is_open_system_www,www_close_tip,is_open_system_sns,sns_close_tip,is_open_system_pay,pay_close_tip,is_open_system_proxy,proxy_close_tip');
		if($vResult){
			alert($vResult, 0);
		}

		$aOption = array(
			'is_open_system_m' => post('is_open_system_m'),
			'm_close_tip' => post('m_close_tip'),
			'is_open_system_www' => post('is_open_system_www'),
			'www_close_tip' => post('www_close_tip'),
			'is_open_system_sns' => post('is_open_system_sns'),
			'sns_close_tip' => post('sns_close_tip'),
			'is_open_system_pay' => post('is_open_system_pay'),
			'pay_close_tip' => post('pay_close_tip'),
			'is_open_system_proxy' => post('is_open_system_proxy'),
			'proxy_close_tip' => post('proxy_close_tip'),
		);

		$size = file_put_contents(SYSTEM_ROOT_PATH . 'apps/config/system_switch.config.php', '<?php' . PHP_EOL . '$GLOBALS[\'SYSTEM_SWITCH\'] = ' . var_export($aOption, 1) . ';');
		if($size){
			alert('设置成功');
		}else{
			alert('设置成功, 0');
		}
	}

	public function settingPublicUser(){
		$option= '';
		foreach( explode(',', post('public_list')) as $publicId ){
			if(strlen($publicId) == 8 && is_numeric($publicId)){
				$option .=  $publicId. ','. PHP_EOL ;
			}else{
				alert('很抱歉，检查ID是否都是8为的数字ID', 0);
			}
		}

		$size = file_put_contents(PUBLIC_USER_CONFIG , '<?php' . PHP_EOL . '$GLOBALS[\'PUBLIC_USER_IDS\'] = array(' . PHP_EOL . $option . PHP_EOL . ');');
		if($size){
			alert('设置成功');
		}else{
			alert('设置成功, 0');
		}
	}

	public function showTableOptimize(){
		//连接主服务器--------查询空闲表空间超过1M的表列表
		$db_server_name = 'mysql_master_1';
		$sql = 'SELECT * FROM `information_schema`.`TABLES` WHERE `TABLE_SCHEMA` LIKE "umfun%" AND `DATA_FREE`>=' . (1024 * 1024) . ' AND `ENGINE`="MyISAM"';
		$aTableList = mysql::query($sql, $db_server_name);
		$freeData = 0;
		foreach($aTableList as $aTable){
			$freeData += $aTable['DATA_FREE'];
		}
		assign('freeData', $freeData);
		assign('aTableList', $aTableList);
		displayHeader();
		display('system/table_optimize.html.php');
		displayFooter();
	}

	public function optimizeTable(){
		$aTableList = (array)post('tables');
		if(!$aTableList){
			alert('没有表可以优化啦', 0);
		}
		$dbServerName = 'mysql_master_1';
		foreach($aTableList as $tableName){
			$sql = 'optimize table ' . $tableName;
			if(!mysql::query($sql, $dbServerName, 1)){
				alert('优化出错啦,请重新点击优化', 0);
			}
		}
		alert('优化完成！', 1);
	}
	/**
	 * 显示其他操作视图
	 */
	public function showOtherOperating(){
		displayHeader();
		display('system/control.html.php');
		displayFooter();
	}
	/**
	 * 删除临时文件
	 */
	public function clearTempFile(){
		$tempFilePath = SYSTEM_RESOURCE_PATH . USER_TMP_PATH;
		$aTempFilePath = $this->getAllFileByPath($tempFilePath);
		if(empty($aTempFilePath)){
			alert('没有文件删除');
		}

		$fileNum = 0;
		$fileFailMsg = '';
		$failMsg = '';
		foreach ($aTempFilePath as $aFile) {
			if(!is_file($aFile)){
				continue;
			}
			$fileTime = filemtime($aFile);
			$lastTime = time() - 86400;
			//大于24小时之前的临时文件
			if($fileTime > $lastTime){
				continue;
			}

			$file = is_writable($aFile) && unlink($aFile);
			if($file){
				$fileNum++;
			}else{
				$fileFailMsg .= '\r\n' . $aFile;
			}
		}

		if(!empty($fileFailMsg)){
			$failMsg = '失败文件有:' . $fileFailMsg;
		}
		$str = '删除成功这次共删除 ' . $fileNum . ' 个文件' . $failMsg;
		json_encode(array($str));
		if(json_last_error()){
			alert('坑！', 0);
		}

		alert($str, 1);
	}

	public function getAllFileByPath($path) {
		static $aFilePath = array();
		$currentDir = opendir($path);    //opendir()返回一个目录句柄,失败返回false
		while(($file = readdir($currentDir)) !== false) {
			//readdir()返回打开目录句柄中的一个条目
			$sub_dir = $path .'/' . $file;
			//构建子目录路径
			if($file == '.' || $file == '..') {
				continue;
			} else if(is_dir($sub_dir)) {
				//如果是目录,进行递归
				$this->getAllFileByPath($sub_dir);
			} else {
				//如果是文件,直接输出
				$aFilePath[]=$sub_dir;
			}
		}
		return $aFilePath;
	}
}