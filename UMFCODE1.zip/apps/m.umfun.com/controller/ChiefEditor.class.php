<?php
class ChiefEditorController{
	private $_permissionFlag = 'manage_es';
	private $_userId = 0;
	private $_aEsStatus  = array(
		0 => '无',
		1 => '已保存',
		2 => '待审核',
		3 => '待复核',
		4 => '已发回/申诉',
		5 => '已复核',
		6 => '复核不通过',
		7 => '作废'
	);

	private $_aTimeType = array(
		1 => '创建时间',
		2 => '提交时间',
		3 => '审核时间',
		5 => '复核时间'
	);

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('您没有权限对此操作', 0);
		}
	}

	/**
	 * 显示题目管理
	 */
	public function showEsManage(){
		$url = '?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);

		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		$aAllowedSubject = array();
		foreach($aAllowSubjectId  as $subjectId){
			$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
		}
		if(!$aAllowedSubject){
			alert('没有可操作的科目', 0);
		}
		assign('aSubject', $aAllowedSubject);

		$esIds = get('esIds', '');
		$categroyId = get('category_id', 0);
		assign('esIds', $esIds);
		$oEs = m('Es');
		if($esIds){
			$url .= '&esIds=' . $esIds;
			$aEsId = explode(',', $esIds);
			//题目列表
			$aEsList = array();
			foreach($aEsId as $esid){
				$aEs = $oEs->getEsInfoByEsId($esid);
				if(!$aEs){
					continue;
				}
				if(!in_array($aEs['subject_id'], $aAllowSubjectId)){
					alert('抱歉，您输入的题目ID中带有您无权查看的科目题目', 0);
				}
				$aCategory = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
				$aEs['category_name'] = $aCategory['name'];
				$aEsList[] = $aEs;
			}
			if(!$aEsList){
				alert('找不到这些题目', 0);
			}
			$subject = $aEsList[0]['subject_id'];
			assign('subjectId', $subject);
			assign('esTypeId', $aEsList[0]['type_id']);
			assign('esStatus', 0);
			assign('timeType', 1);
			assign('startTime', '');
			assign('endTime', '');
			assign('creater', 0);
		}else{
			//处理搜索条件
			//科目ID
			$subject = get('subject', 0);
			if(!$subject){
				$subject = $aAllowSubjectId[0];
			}
			if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
				alert('不存在此科目', 0);
			}
			if(!in_array($subject, $aAllowSubjectId )){
				alert('您没有权限操作此科目', 0);
			}
			$url .= '&subject=' . $subject;
			assign('subjectId', $subject);

			//题目类型
			$esType = get('esType', 0);
			if($esType){
				if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
					alert('不存在此题型', 0);
				}
				$url .= '&esType=' . $esType;
			}
			assign('esTypeId', $esType);

			//题目状态
			$esStatus = get('esStatus', 3);
			if($esStatus){
				if(!array_key_exists($esStatus, $this->_aEsStatus)){
					alert('错误的题目状态', 0);
				}
				$url .= '&esStatus=' . $esStatus;
			}
			assign('esStatus', $esStatus);

			//时间
			$timeType = get('timeType', 3);
			$startTime = get('startTime');
			$endTime = get('endTime');
			if(!array_key_exists($timeType, $this->_aTimeType)){
				alert('错误的时间类型', 0);
			}
			$url .= '&timeType=' . $timeType;
			assign('timeType', $timeType);

			//开始时间
			if(!$startTime){
				$startTimeStamp = 0;
			}else{
				$startTimeStamp = strtotime($startTime);
				$url .= '&startTime=' . $startTime;
			}
			if(isset($_COOKIE['chiefStartTime'])){
				$startTime = $_COOKIE['chiefStartTime'];
			}else{
				setcookie('chiefStartTime', $startTime, time() + 2592000, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
			}
			assign('startTime', $startTime);

			//结束时间
			if(!$endTime){
				$endTimeStamp = time();
			}else{
				$endTimeStamp = strtotime($endTime);
				$url .= '&endTime=' . $endTime;
			}
			if(isset($_COOKIE['chiefEndTime'])){
				$endTime = $_COOKIE['chiefEndTime'];
			}else{
				setcookie('chiefEndTime', $endTime, time() + 2592000, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
			}
			assign('endTime', $endTime);

			//创建人
			$creater = get('creater', 0);
			if($creater){
				if(!($creater >= 1)){
					alert('错误的创建人', 0);
				}
				$url .= '&creater=' . $creater;
			}
			assign('creater', $creater);

			//目录
			$aCategroy = $oEs->getCategoryInfoByCategoryId($categroyId);
			if($aCategroy){
				assign('categroyName', $aCategroy['name']);
			}
			if($categroyId){
				$url .= '&category_id=' . $categroyId;
			}

			//分页数
			$page = get('page');
			$pageSize = 10;
			if(!($page >= 1)){
				$page = 1;
			}

			//题目列表
			$oEs =  m('Es');
			if($creater){
				$esNums = $oEs->getEsCountByCreater($timeType, $startTimeStamp, $endTimeStamp, $creater, $subject, $esType, $esStatus, 1, $categroyId);
				$aEsList = $oEs->getEsListByCreater($page, $pageSize, $creater, $startTimeStamp, $endTimeStamp, $timeType, $subject, $esType, $esStatus, 1, $categroyId);
			}else{
				$esNums = $oEs->getEsCountByChiefEditer($timeType, $startTimeStamp, $endTimeStamp, $creater, $subject, $esType, $esStatus, $categroyId);
				$aEsList = $oEs->getEsListByChiefEditer($page, $pageSize, $creater, $startTimeStamp, $endTimeStamp, $timeType, $subject, $esType, $esStatus, $categroyId);
			}

			$autoJump = intval(get('auto_jump'));
			if(count($aEsList) == 0 && $autoJump){
				header('Location:?m=ChiefEditor&a=showEsManage&esStatus=5&subject=' . $subject . '&timeType=' . $timeType);
				exit;
			}

			//分页HTML
			$aPageInfo = array(
				'url' => $url . '&page=_PAGE_',
				'total' => $esNums,
				'selector' => 1,
				'size' => $pageSize,
				'page' => $page
			);
			$pageHtml = page($aPageInfo);
			assign('pageHtml', $pageHtml);
		}

		$aEsPlugin = array();	//存放题目插件对象的数组
		foreach($aEsList as $keyNum => &$aEs){
			$aEs['same_ids'] = array();
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				foreach($aSameEsList as $aSameEs){
					$aEs['same_ids'][] = $aSameEs['id'];
				}
			}

			if(!isset($aEsPlugin[$aEs['subject_id']][$aEs['type_id']])){
				$aEsPlugin[$aEs['subject_id']][$aEs['type_id']] = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
			}
			$oPlugin = &$aEsPlugin[$aEs['subject_id']][$aEs['type_id']];
			$aEsList[$keyNum]['es_content'] = $oPlugin->resolve($aEs['content_json']);
		}
		unset($aEsPlugin);
		if(isset($subject)){
			$aDefaultReason = $GLOBALS['ES_WRONG_REASON'][$subject];
		}else{
			$aDefaultReason = $GLOBALS['ES_WRONG_REASON'][$aEsList[0]['subject_id']];
		}

		//查找审查人
		if(isset($esStatus) && $esStatus == 6){
			foreach($aEsList as &$aEsInfo){
				$aApproverUserInfo = $oEs->getApproverUserInfoById($aEsInfo['id']);
				$aEsInfo['approver_user_name'] = $aApproverUserInfo['name'];
				$aEsInfo['approve_time'] = $aApproverUserInfo['operating_time'];
			}
		}

		//创建人
		$aCreaterList = array();
		$aGroupList = $oManager->getGroupList();
		foreach($aGroupList as $aCurGroup){
			if(in_array('add_es', $aCurGroup['permission'])){
				$aGroupMember = $oManager->getUserListByGroupId($aCurGroup['id']);
				foreach($aGroupMember as $aMember){
					if(!isset($aCreaterList[$aMember['id']]) && in_array($subject, $aMember['allowed_subject'])){
						$aCreaterList[$aMember['id']] = $aMember;
					}
				}
			}
		}
		assign('aCreaterList', $aCreaterList);

		assign('categroyId', $categroyId);
		assign('defaultReason', $aDefaultReason);
		assign('aEsList', $aEsList);
		assign('aTimeType', $this->_aTimeType);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aStatus', $this->_aEsStatus);
		displayHeader();
		display('es_manage/list.html.php');
		displayFooter();
	}

	/**
	 * 复核题目
	 */
	public function approvalEs(){
		$esId = post('esId');
		$aEsInfo = $this->_getEsInfo($esId);

		$this->_checkAllowSubject($aEsInfo['subject_id']);	//检查科目权限
		if($aEsInfo['status'] != 3){
			alert('待复核的题目才能复核通过', 0);
		}else{
			$oEs = m('Es');
			$type = post('action');	//1通过复核，2驳回复核
			$aEs = array();
			$aEs['id'] = $esId;
			$aEs['operating_time'] = time();
			$aEs['subject_id'] = $aEsInfo['subject_id'];
			if($type == 1){
				$aEs['action'] = 5;
				$aEs['status'] = 5;
				$aEs['submiter_user_id'] = $aEsInfo['submiter_user_id'];
				$aEs['approver_user_id'] = $aEsInfo['approver_user_id'];
				$aEs['chief_user_id'] = $this->_userId;
				$isSucess = $oEs->passEndApprove($aEs);
				$sucessMsg = '通过复核题目成功';
				$failMsg = '通过复核题目失败';
			}elseif($type == 2){
				$aEs['action'] = 6;
				$aEs['status'] = 6;
				$aEs['comment'] = post('comment');
				if(!$aEs['comment']){
					alert('请填写驳回理由', 0);
				}
				$aEs['submiter_user_id'] = $aEsInfo['approver_user_id'];
				$aEs['approver_user_id'] = $this->_userId;
				$aEs['chief_user_id'] = $this->_userId;
				$isSucess = $oEs->changeStatus($aEs);
				$sucessMsg = '题目复核驳回成功';
				$failMsg = '题目复核驳回失败';

			}else{
				alert('非法操作', 0);
			}
			if($isSucess){
				alert($sucessMsg, 1);
			}else{
				alert($failMsg, 0);
			}
		}
	}

	/**
	 * 作废题目
	 */
	public function cancleEs(){
		$esId = post('esId');
		$aEsInfo = $this->_getEsInfo($esId);
		$this->_checkAllowSubject($aEsInfo['subject_id']);	//检查科目权限
		if($aEsInfo['status'] != 5){
			alert('终审状态的题目才可以作废', 0);
		}else{
			$oEs = m('Es');
			$aEs = array();
			$aEs['id'] = $esId;
			$aEs['status'] = 7;
			$aEs['subject_id'] = $aEsInfo['subject_id'];

			if(isset($aEsInfo['submiter_user_id']) || isset($aEsInfo['approver_user_id'])){
				$aEs['action'] = 7;
				$aEs['operating_time'] = time();
				if(isset($aEsInfo['submiter_user_id'])){
					$aEs['submiter_user_id'] = $aEsInfo['submiter_user_id'];
				}
				if(isset($aEsInfo['approver_user_id'])){
					$aEs['approver_user_id'] = $aEsInfo['approver_user_id'];
				}
			}
			$isSucess = $oEs->changeStatus($aEs);
			if($isSucess){
				alert('题目作废成功', 1);
			}else{
				alert('题目作废失败', 0);
			}
		}
	}

	/**
	 * 申诉处理
	 */
	public function appeal(){
		$esId = post('esId');
		$aEsInfo = $this->_getEsInfo($esId);
		$this->_checkAllowSubject($aEsInfo['subject_id']);	//检查科目权限
		if($aEsInfo['appeal_status'] == 2){
			$aEsInfo['chief_user_id'] = $this->_userId;
			$aEsInfo['operating_time'] = time();
			$aEsInfo['comment'] = '';
			$oEs = m('Es');
			$action = post('action');
			if($action == 1){
				$isSucess = $oEs->appealSucceed($aEsInfo);
				$sucessMsg = '申诉通过成功';
				$failMsg = '申诉通过失败';
			}elseif($action == 2){
				$isSucess = $oEs->appealFailed($aEsInfo['id']);
				$sucessMsg = '申诉驳回成功';
				$failMsg = '申诉驳回失败';
			}else{
				alert('非法操作', 0);
			}
			if($isSucess){
				alert($sucessMsg, 1, '?m=ChiefEditor&a=showEsManage&esStatus=4');
			}else{
				alert($failMsg, 0);
			}
		}else{
			alert('该题目不是在申诉状态', 0);
		}
	}

	/**
	 * 显示目录管理
	 */
	public function showCatalogueManage(){
		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowSubject = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		if(!$aAllowSubject){
			alert('没有可操作的科目', 0);
		}

		$aAllowedSubject = array();
		foreach($aAllowSubject as $subjectId){
			if(isset($GLOBALS['SUBJECT'][$subjectId])){
				$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
			}
		}
		assign('aSubject', $aAllowedSubject);
		//当前科目
		$subjectId = get('subject');
		if(!$subjectId){
			$subjectId = $aAllowSubject[0];
		}
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		assign('subjectId', $subjectId);

		//当前科目的目录树
		$oEs = m('Es');
		$aCategoryList = $oEs->getCategoryDetailedListBySubjectId($subjectId);
		assign('aCategoryList', $aCategoryList);

		displayHeader();
		display('es_manage/manage_catalogue.html.php');
		displayFooter();
	}

	/**
	 * 统计
	 */
	public function showStatistic(){
		$type = get('type', 1);
		if($type != 1 && $type != 2 && $type != 3){
			alert('错误的统计类型', 0);
		}
		assign('type', $type);

		$subject = get('subject');
		Debug::mark('getUserAllowedSubjectStart');
		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowSubject = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		if(!$aAllowSubject){
			alert('没有可操作的科目', 0);
		}
		Debug::mark('getUserAllowedSubjectEnd');
		$getUserAllowedSubjectTime = Debug::getUseTime('getUserAllowedSubjectStart', 'getUserAllowedSubjectEnd');
		$aAllowedSubject = array();
		foreach($aAllowSubject as $subjectId){
			if(isset($GLOBALS['SUBJECT'][$subjectId])){
				$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
			}
		}
		assign('aSubject', $aAllowedSubject);
		if(!$subject){
			$subject = $aAllowSubject[0];
		}
		assign('subjectId', $subject);

		$aDayType = array(
			1 => 3,
			2 => 7,
			3 => 15,
			4 => 30
		);
		assign('aDayType', $aDayType);
		$dayType = get('dayType', 0);
		assign('dayType', $dayType);
		if($dayType){
			if(!array_key_exists($dayType, $aDayType)){
				alert('错误的类型', 0);
			}

			$endTime = time();
			$startTime = $endTime - 86400 * $aDayType[$dayType];
		}else{
			$startTime = get('startTime');
			$endTime = get('endTime');
			if(!$startTime){
				$startTime = time() - 86400 * 7;
			}else{
				$startTime = strtotime($startTime);
			}
			if(!$endTime){
				$endTime = time();
			}else{
				$endTime = strtotime($endTime);
			}
		}
		assign('startTime', $startTime);
		assign('endTime', $endTime);

		$oEs = m('Es');
		$aStatis = array();
		$aEsMehotd = array(
			1 => 'getStatisticsForCreater',
			2 => 'getStatisticsForApprove',
			3 => 'getStatisticsForChiefEdit'
		);


		if($type == 1){
			$power = 'add_es';
		}elseif($type == 2){
			$power = 'approve_es';
		}elseif($type == 3){
			$power = 'manage_es';
		}
		Debug::mark('getStatisticUserStart');
		$aStatisticUser = array();
		$aGroupList = $oManager->getGroupList();
		foreach($aGroupList as $aCurGroup){
			if(in_array($power, $aCurGroup['permission'])){
				$aGroupMember = $oManager->getUserListByGroupId($aCurGroup['id']);
				foreach($aGroupMember as $aMember){
					if(!isset($aStatisticUser[$aMember['id']])){
						$aStatisticUser[$aMember['id']] = $aMember;
					}
				}
			}
		}
		Debug::mark('getStatisticUserEnd');
		$getStatisticUserTime = Debug::getUseTime('getStatisticUserStart', 'getStatisticUserEnd');
		Debug::mark('getStatisticStart');
		//开始统计每一个要统计的用户的数据
		/*foreach($aStatisticUser as $aMember){
			if(in_array($subject, $aMember['allowed_subject'])){
				$aStatis[$aMember['id']] = $oEs->$aEsMehotd[$type]($startTime, $endTime, $aMember['id'], $subject);
				$aStatis[$aMember['id']]['name'] = $aMember['name'];
			}
		}*/
		$aMemberIds = array();
		foreach($aStatisticUser as $aMember){
			if(in_array($subject, $aMember['allowed_subject'])){
				$aMemberIds[] = $aMember['id'];
			}
		}
		if($type == 1){
			$aManagerIds = $oManager->getCreatedEsManagerIdsBySubject($subject);
			$aMemberIds = array_merge($aMemberIds, $aManagerIds);
			$aMemberIds = array_unique($aMemberIds);
		}
		$aStatisticUser = $oManager->getManagerListByIds($aMemberIds);
		$aStatis = $oEs->$aEsMehotd[$type]($startTime, $endTime, $aMemberIds, $subject);
		foreach($aStatis as $key => $aStati){
			foreach($aStatisticUser as $aMember){
				if($aMember['id'] == $aStati['id']){
					$aStatis[$key]['name'] = $aMember['name'];
				}
			}
		}
		Debug::mark('getStatisticEnd');
		$getStatisticTime = Debug::getUseTime('getStatisticStart', 'getStatisticEnd');
		//组装统计数据
		if($type == 1){
			$creataCount = 0;
			$submitCount = 0;
			$passCount = 0;
			$sendCount = 0;
			$effectCount = 0;
			foreach($aStatis as $key => $statis){
				$creataCount += $statis['create_nums'];
				$submitCount += $statis['submit_times'];
				$passCount += $statis['pass_approve_nums'];
				$sendCount += $statis['sendback_times'];
				$effectCount += $statis['effective_appeal_nums'];
			}
			$aStatis['count']['create_nums'] = $creataCount;
			$aStatis['count']['submit_times'] = $submitCount;
			$aStatis['count']['pass_approve_nums'] = $passCount;
			$aStatis['count']['sendback_times'] = $sendCount;
			$aStatis['count']['effective_appeal_nums'] = $effectCount;
			$aStatis['count']['name'] = '合计';
		}elseif($type == 2){
			$passFirstCount = 0;
			$sendCount = 0;
			$passEndCount = 0;
			$notPassEndCount = 0;
			$effectCount = 0;
			foreach($aStatis as $key => $statis){
				$passFirstCount += $statis['pass_first_approve_nums'];
				$sendCount += $statis['sendback_times'];
				$passEndCount += $statis['pass_end_approve_nums'];
				$notPassEndCount += $statis['not_pass_end_approve_times'];
				$effectCount += $statis['effective_appeal_nums'];
			}
			$aStatis['count']['pass_first_approve_nums'] = $passFirstCount;
			$aStatis['count']['sendback_times'] = $sendCount;
			$aStatis['count']['pass_end_approve_nums'] = $passEndCount;
			$aStatis['count']['not_pass_end_approve_times'] = $notPassEndCount;
			$aStatis['count']['effective_appeal_nums'] = $effectCount;
			$aStatis['count']['name'] = '合计';
		}elseif($type == 3){
			$passEndCount = 0;
			$notPassEndCount = 0;
			$cancleCount = 0;
			foreach($aStatis as $key => $statis){
				$passEndCount += $statis['pass_end_approve_nums'];
				$notPassEndCount += $statis['not_pass_end_approve_times'];
				$cancleCount += $statis['blank_out_nums'];
			}
			$aStatis['count']['pass_end_approve_nums'] = $passEndCount;
			$aStatis['count']['not_pass_end_approve_times'] = $notPassEndCount;
			$aStatis['count']['blank_out_nums'] = $cancleCount;
			$aStatis['count']['name'] = '合计';
		}
		$aRunTimeStatis = array(
			'getUserAllowedSubjectTime' => $getUserAllowedSubjectTime,
			'getStatisticUserTime' => $getStatisticUserTime,
			'getStatisticTime' => $getStatisticTime
		);
		assign('aRunTimeStatis', $aRunTimeStatis);
		assign('aStatis', $aStatis);
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);
		displayHeader();
		display('es_manage/statistic.html.php');
		displayFooter();

	}

	/**
	 * 显示编辑目录
	 */
	public function showEditCatalogue(){
		$catalogueId = get('catagolueId');
		if(!($catalogueId >= 1)){
			alert('目录ID非法', 0);
		}
		$oEs = m('Es');
		$aCatalogueInfo = $oEs->getCategoryInfoByCategoryId($catalogueId);
		if(!$aCatalogueInfo){
			alert('目录不存在', 0);
		}
		assign('aCatalogueInfo', $aCatalogueInfo);

		$aCategoryList = $oEs->getCategoryDetailedListBySubjectId($aCatalogueInfo['subject_id']);
		assign('aCategoryList', $aCategoryList);

		displayHeader();
		display('es_manage/edit_catalogue.html.php');
		displayFooter();
	}

	/**
	 * 编辑目录
	 */
	public function editCatalogue(){
		$aCatalogue = array();

		//科目检查
		$subjectId = post('subject_id');
		if(!($subjectId >= 1)){
			alert('科目ID非法', 0);
		}
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		$this->_checkAllowSubject($subjectId);	//检查科目权限

		$aCatalogue['id'] = post('id');
		if(!($aCatalogue['id'] >= 1)){
			alert('非法的目录ID', 0);
		}
		$aCatalogue['name'] = post('name');
		if(!$aCatalogue['name']){
			alert('目录名称不能为空', 0);
		}
		$aCatalogue['orders'] = post('orders');
		if(!($aCatalogue['orders']) >= 1){
			alert('排序必须为正整数', 0);
		}

		$isRoot = post('catalogue');
		$oEs = m('Es');
		if($isRoot == 0 || $isRoot == 1){
			if($isRoot == 1){
				$aCatalogue['parent_id'] = 0;
			}else{
				$aCatalogue['parent_id'] = post('parent_id');
				if(!($aCatalogue['parent_id'] >= 1)){
					alert('非法的父目录ID', 0);
				}
				$categoryExists = $oEs->getCategoryInfoByCategoryId($aCatalogue['parent_id']);
				if(!$categoryExists){
					alert('父目录不存在', 0);
				}

				//检查所选父目录有没有题目
				$isExistEsInCategory = $oEs->isExistEsInCategory($aCatalogue['parent_id']);
				if($isExistEsInCategory){
					alert('该目录下有题目，不可以作为父目录', 0);
				}

				//检查所选的父目录是否原来父目录的子目录
				$aChildrenCatalogue = $oEs->getCategoryListByCategoryId($aCatalogue['id']);
				if($aChildrenCatalogue){
					$aChildrenId = array();
					foreach($aChildrenCatalogue as $catalogue){
						$aChildrenId[] = $catalogue['id'];
					}
					if(in_array($aCatalogue['parent_id'], $aChildrenId)){
						alert('不能选取该目录或其子目录作为新的父目录', 0);
					}
				}
			}
		}else{
			alert('目录有错', 0);
		}

		$isEditCatalogue = $oEs->setCategory($aCatalogue);
		if($isEditCatalogue || $isEditCatalogue === 0){
			Es::buildCategoryTreeListCacheBySubjectId($subjectId);
			alert('编辑目录成功', 1, '?m=ChiefEditor&a=showCatalogueManage&subject=' . $subjectId);
		}else{
			alert('编辑目录失败', 0);
		}
	}

	/**
	 * 删除目录
	 */
	public function deleteCatalogue(){
		$catalogueId = post('catagolueId');
		if(!($catalogueId >= 1)){
			alert('目录ID非法', 0);
		}
		$oEs = m('Es');

		//科目检查
		$aCatalogueInfo = $oEs->getCategoryInfoByCategoryId($catalogueId);
		if(!$aCatalogueInfo){
			alert('目录不存在', 0);
		}
		$this->_checkAllowSubject($aCatalogueInfo['subject_id']);	//检查科目权限

		//子目录及题目检查
		$isExistEsInCategory = $oEs->isExistEsInCategory($catalogueId);
		if($isExistEsInCategory){
			alert('该目录下有题目，不可以删除', 0);
		}
		$isExistSubCategory = $oEs->isExistSubCategory($catalogueId);
		if($isExistSubCategory){
			alert('该目录下有子目录，不可以删除', 0);
		}
		$isDeleteCatalogue = $oEs->deleteCategory($catalogueId);
		if($isDeleteCatalogue){
			alert('删除目录成功', 1, '?m=ChiefEditor&a=showCatalogueManage&subject=' . $aCatalogueInfo['subject_id']);
		}else{
			alert('删除目录失败', 0);
		}

	}

	/**
	 * 显示添加目录界面
	 */
	public function showCreateCatalogue(){
		$subjectId = get('subject');
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		assign('subjectId', $subjectId);
		assign('aCategoryList', Es::getCategoryTreeListBySubjectId($subjectId));

		$oManager = m('Manager');
		$aAllowSubject = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		if(!$aAllowSubject){
			alert('没有可操作的科目', 0);
		}
		$aAllowedSubject = array();
		foreach($aAllowSubject as $subjectId){
			if(isset($GLOBALS['SUBJECT'][$subjectId])){
				$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
			}
		}
		assign('aSubject', $aAllowedSubject);
		displayHeader();
		display('es_manage/create_catalogue.html.php');
		displayFooter();
	}

	/**
	 * 添加题目反馈
	 */
	 public function addFeedback(){
		$esId = intval(post('es_id'));
		$reason = strval(post('reason'));
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if($aEsInfo === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif(!$aEsInfo){
			alert('题目数据有误，请联系管理员！', 0);
		}
		$this->_checkAllowSubject($aEsInfo['subject_id']);
		if(!w('length(1, 300)', $reason)){
			alert('抱歉！您反馈的信息不宜超过300字节！', 0);
		}
		$aUserFeedbackInfo = $oEs->getEsFeedbackInfoByUserIdAndEsId($this->_userId, $esId, 2);
		if($aUserFeedbackInfo === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($aUserFeedbackInfo && $aUserFeedbackInfo['status'] == 1){
			alert('您已经反馈过该题目，请耐心等待处理！', -1);
		}

		$feedbackId = $oEs->addEsFeedback(array(
			'user_id' => $this->_userId,
			'user_type' => 2,
			'es_id' => $esId,
			'subject_id' => $aEsInfo['subject_id'],
			'status' => 1,
			'reason' => $reason,
			'create_time' => time(),
		));
		if($feedbackId === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($feedbackId){
			alert('反馈成功！');
		}else{
			alert('抱歉！反馈失败，请稍后再试！', 0);
		}
	 }

	/**
	 * 添加目录
	 */
	public function createCatalogue(){
		$aCatalogue = array();

		//科目检查
		$aCatalogue['subject_id'] = post('subject_id');
		if(!($aCatalogue['subject_id'] >= 1)){
			alert('科目ID非法', 0);
		}
		if(!array_key_exists($aCatalogue['subject_id'], $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		$this->_checkAllowSubject($aCatalogue['subject_id']);	//检查科目权限

		$aCatalogue['name'] = post('name');
		if(!$aCatalogue['name']){
			alert('目录名称不能为空');
		}

		$aCatalogue['orders'] = post('orders');
		if(!($aCatalogue['orders']) >= 1){
			alert('排序必须为正整数', 0);
		}

		$isRoot = post('catalogue');
		$oEs = m('Es');
		if($isRoot == 0 || $isRoot == 1){
			if($isRoot == 1){
				$isExistRootCatagory = $oEs->isExistRootCategory($aCatalogue['subject_id']);
				if($isExistRootCatagory){
					alert('该科目已经存在根目录', 0);
				}
				$aCatalogue['parent_id'] = 0;
			}else{
				$aCatalogue['parent_id'] = post('parent_id');
				if(!($aCatalogue['parent_id'] >= 1)){
					alert('非法的父目录ID', 0);
				}
				$categoryExists = $oEs->getCategoryInfoByCategoryId($aCatalogue['parent_id']);
				if(!$categoryExists){
					alert('父目录不存在', 0);
				}

				//检查所选父目录有没有题目
				$isExistEsInCategory = $oEs->isExistEsInCategory($aCatalogue['parent_id']);
				if($isExistEsInCategory){
					alert('该目录下有题目，不可以作为父目录', 0);
				}

			}
		}else{
			alert('目录有错', 0);
		}

		$isCreateCatalogue = $oEs->addEsCategory($aCatalogue);
		if($isCreateCatalogue){
			Es::buildCategoryTreeListCacheBySubjectId($aCatalogue['subject_id']);
			alert('创建目录成功', 1, '?m=ChiefEditor&a=showCatalogueManage&subject=' . $aCatalogue['subject_id']);
		}else{
			alert('创建目录失败', 0);
		}
	}

	/**
	 * 旧题目管理
	 */
	public function showOld2NewEsManage(){
		$url = 'http://' . APP_MANAGE . '/?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);

		//得到用户可操作的科目列表
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		$aAllowedSubject = array();
		foreach($aAllowSubjectId  as $subjectId){
			$aAllowedSubject[$subjectId] = $GLOBALS['SUBJECT'][$subjectId];
		}
		if(!$aAllowedSubject){
			alert('没有可操作的科目', 0);
		}
		assign('aSubject', $aAllowedSubject);

		//科目ID
		$subject = get('subject', 0);
		if(!$subject){
			if(isset($_COOKIE['lastEsSubjectId'])){
				$subject = $_COOKIE['lastEsSubjectId'];
			}else{
				$subject = $aAllowSubjectId[0];
				setcookie('lastEsSubjectId', $subject, time() + 2592000, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
			}
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		if(!in_array($subject, $aAllowSubjectId )){
			alert('您没有权限操作此科目', 0);
		}
		$url .= '&subject=' . $subject;
		assign('subjectId', $subject);

		//题目类型
		$esType = get('esType', 0);
		if($esType){
			if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
			alert('不存在此题型', 0);
			}
			$url .= '&esType=' . $esType;
		}
		assign('esTypeId', $esType);


		//状态
		$esStatus = get('esStatus', 0);
		$aStatus = array(
			0 => '全部',
			1 => '未审',
			2 => '已审'
		);
		if($esStatus){
			$url .= '&esStatus=' . $esStatus;
		}
		assign('esStatus', $esStatus);
		assign('aStatus', $aStatus);

		//目录
		$categroyId = get('category_id', 0);
		$oEs = m('Es');
		$aCategroy = $oEs->getCategoryInfoByCategoryId($categroyId);
		if($aCategroy){
			assign('categroyName', $aCategroy['name']);
		}
		if($categroyId){
			$url .= '&category_id=' . $categroyId;
		}
		assign('categroyId', $categroyId);

		//分页数
		$page = get('page');
		$pageSize = 10;
		if(!($page >= 1)){
			$page = 1;
		}

		$oOld2NewEs = m('OldEs');
		$esNums = $oOld2NewEs->getEsCount($subject, $esType, $categroyId, $esStatus);
		$aEsList = $oOld2NewEs->getEsList($subject, $esType, $categroyId, $page, $pageSize, $esStatus);

		//分页HTML
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $esNums,
			'size' => $pageSize,
			'page' => $page
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);

		$aEsPlugin = array();	//存放题目插件对象的数组
		foreach($aEsList as $keyNum => &$aEs){
			$aEs['same_ids'] = array();
			if($aSameEsList = $oEs->getSimilarEsListByData($aEs, array($aEs['id']))){
				foreach($aSameEsList as $aSameEs){
					$aEs['same_ids'][] = $aSameEs['id'];
				}
			}

			if(!isset($aEsPlugin[$aEs['subject_id']][$aEs['type_id']])){
				$aEsPlugin[$aEs['subject_id']][$aEs['type_id']] = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
			}
			$aEsList[$keyNum]['es_content'] = $aEsPlugin[$aEs['subject_id']][$aEs['type_id']]->resolve($aEs['content_json']);
		}
		unset($aEsPlugin);
		assign('aEsList', $aEsList);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		displayHeader();
		display('es_manage/old_list.html.php');
		displayFooter();
	}


	/**
	 * 旧题转新题
	 */
	public function old2formalEs(){
		$esId = post('id');
		$aEsInfo = $this->_getEsInfo($esId);
		$this->_checkAllowSubject($aEsInfo['subject_id']);	//检查科目权限
		if($aEsInfo['status'] != 0){
			alert('不是旧题目', 0);
		}

		//调用题目插件
		$oEsPlugin = $this->_esFactory($aEsInfo['subject_id'], $aEsInfo['type_id']);
		if(!is_object($oEsPlugin)){
			alert('错误的科目或题型', 0);
		}
		$aEsMainContent = $oEsPlugin->build($_POST['es']);
		if($oEsPlugin->getError()){
			alert($oEsPlugin->getError(), 0);
		}
		$aEs = array();
		$aEs['id'] = $esId;
		$aEs['content_json'] = $aEsMainContent['content_json'];
		$aEs['content_text'] = $aEsMainContent['content_text'];

		//检查目录
		$oEs = m('Es');
		$aEs['category_id'] = post('category_id');
		if(!($aEs['category_id'] >= 1)){
			alert('非法的目录ID', 0);
		}else{
			$categoryExists = $oEs->getCategoryInfoByCategoryId($aEs['category_id']);
			if(!$categoryExists){
				alert('目录不存在', 0);
			}
		}
		$childNums = $oEs->isExistSubCategory($aEs['category_id']);
		if($childNums > 0){
			alert('选择的目录不是最底层目录，请检查', 0);
		}

		$esPluginName = $GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']];
		$sameBaseEsType = 0;
		$aSameEsTypeId = array();
		foreach($GLOBALS['TYPE_RESOLVER'] as $type => $pluginName){
			if($pluginName == $esPluginName && in_array($type, $GLOBALS['SUBJECT_TYPE'][$aEsInfo['subject_id']])){
				$sameBaseEsType++;
				$aSameEsTypeId[] = $type;
			}
		}
		if($sameBaseEsType >= 2){
			$aEs['type_id'] = post('es_type');
			if(!in_array($aEs['type_id'], $aSameEsTypeId)){
				alert('错误的题型', 0);
			}
		}
		$aEs['status'] = 5;
		$aEs['approve_time'] = time();
		$oOld2NewEs = m('OldEs');
		$isSucess = $oOld2NewEs->setEs($aEs);
		if($isSucess){
			alert('入库成功', 1, '?m=ChiefEditor&a=showOld2NewEsManage&esStatus=1');
		}else{
			alert('入库失败', 0);
		}
	}

	/**
	 * 操作旧题目
	 */
	public function operateOldEs(){
		$action = post('action');
		$esId = post('esId');
		$aEsInfo = $this->_getEsInfo($esId);
		if($aEsInfo['status'] != 0){
			alert('不是旧题目', 0);
		}

		$oOld2NewEs = m('OldEs');
		$aEs = array();
		$aEs['id'] = $esId;
		if($action == 1){
			$aEs['status'] = 5;
			$aEs['approve_time'] = time();
			$isSucess = $oOld2NewEs->setEs($aEs);
			if($isSucess){
				alert('入库成功', 1);
			}else{
				alert('入库失败', 0);
			}
		}elseif($action == 2){
			$isDelete = $oOld2NewEs->deleteEs($esId);
			if($isDelete){
				alert('删除成功', 1);
			}else{
				alert('删除失败', 0);
			}
		}else{
			alert('参数错误', 0);
		}
	}


	/**
	 * 显示编辑旧题目
	 */
	public function showEditOldEs(){
		$esId = get('esId');
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			alert('指定的题目不存在', 0);
		}elseif($aEsInfo['status'] != 0){
			alert('禁止编辑该题目!', 0);
		}

		$oEsPlugin = $this->_esFactory($aEsInfo['subject_id'], $aEsInfo['type_id']);
		$aEsInfo['es_content'] = $oEsPlugin->resolve($aEsInfo['content_json']);
		if($esError = $oEsPlugin->getError()){
			alert($esError, 0);
		}

		$oEs = m('Es');
		$aCategoryList = $oEs->getCategoryListBySubjectId($aEsInfo['subject_id']);
		assign('aCategoryList', $aCategoryList);
		assign('categoryId', $aEsInfo['category_id']);
		assign('subjectId', $aEsInfo['subject_id']);
		assign('esType', $aEsInfo['type_id']);
		assign('id', $aEsInfo['id']);
		assign('aEs', $aEsInfo);
		displayHeader();
		display('es_manage/old_edit.html.php');
		displayFooter();
	}

	/**
	 * 旧题审核统计
	*/
	public function approveStatistic(){
		$oDBOI = new DBOI();
		$startTime = get('start_time');
		$endTime = get('end_time');
		if(!$startTime){
			$startTime = date('Y-m-d 00:00:00');
		}
		if(!$endTime){
			$endTime = date('Y-m-d H:i:s');
		}
		$startTimeStamp = strtotime($startTime);
		$endTimeStamp = strtotime($endTime);
		$aAllowSubjectId = m('Manager')->getUserAllowedSubjectByUserId($this->_userId);
		if($aAllowSubjectId === false){
			alert('系统有误，请稍后再试！', 0);
		}
		$condition = implode(',', $aAllowSubjectId);
		$where = '`approve_time` >=' .$startTimeStamp . ' AND `approve_time`<=' . $endTimeStamp . ' AND `subject_id` in(' . $condition . ')';
		$aStatisticCountsList = $oDBOI->fields('`subject_id`, count(*) as nums')->table(T_NEW_AND_OLD_ES_RELATION)->where($where)->groupby('`subject_id`')->select();
		assign('aStatisticCountsList', $aStatisticCountsList);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		displayHeader();
		display('es_manage/approve_statistic.html.php');
		displayFooter();
	}

	/*
	 * 申诉成功题目
	 */
	public function showPassAppealEsList(){
		$url = '?m=' . $_GET['m'] . '&a=' . $_GET['a'];
		assign('baseUrl', $url);
		//分页数
		$page = get('page');
		$pageSize = 10;
		if(!($page >= 1)){
			$page = 1;
		}

		$oEs = m('es');
		$esNums = $oEs->getPassAppealEsCount();
		$aEsList = $oEs->getPassAppealEsList($page, $pageSize);

		//分页HTML
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $esNums,
			'selector' => 1,
			'size' => $pageSize,
			'page' => $page
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		$aEsPlugin = array();	//存放题目插件对象的数组
		foreach($aEsList as $keyNum => &$aEs){
			if(!isset($aEsPlugin[$aEs['subject_id']][$aEs['type_id']])){
				$aEsPlugin[$aEs['subject_id']][$aEs['type_id']] = $this->_esFactory($aEs['subject_id'], $aEs['type_id']);
			}
			$oPlugin = &$aEsPlugin[$aEs['subject_id']][$aEs['type_id']];
			$aEsList[$keyNum]['es_content'] = $oPlugin->resolve($aEs['content_json']);
		}
		unset($aEsPlugin);
		assign('subjectId', $aEsList ? $aEsList[0]['subject_id'] : 0);
		assign('aEsList', $aEsList);
		displayHeader();
		display('es_manage/pass_appeal_list.html.php');
		displayFooter();
	}

	/*
	* 解锁一周前的题目
	*/
	public function unlockApproveEs(){
		$oEs = m('Es');
		$aIds = $oEs->getUnlockApproveEsIds();
		if($aIds === false){
			alert('网络可能有点慢，请稍后再试！',0);
		}elseif(!$aIds){
			alert('没有要解锁的题目！',-1);
		}

		$result = $oEs->deleteLockApproveEsByIds($aIds);
		if($result === false){
			alert('网络可能有点慢，请稍后再试！',0);
		}elseif(!$result){
			alert('没有要解锁的题目！',-1);
		}else{
			alert('所有一周前的题目解锁成功',1);
		}
	}

	//增加解题思路
	public function publishAnalysis() {
		$esId = (int)post('es_id');
		$analysis = (string)post('analysis');
		$mEs = m('Es');
		if(!$aEs = $mEs->getEsInfoByEsId($esId)){
			alert('无效的题目ID', 0);
		}

		if(!w('length(5,500)', $analysis)){
			alert('解题思路内容必须在5到300字以内', 0);
		}

		if($mEs->getEsAnalysisList(array($aEs['id']))){
			alert('此题已有解题思路', 0);
		}

		if($mEs->addEsAnalysis(array(
			'id' => $aEs['id'],
			'user_id' => $this->_userId,
			'user_type' => 2,
			'is_approved' => 1,
			'analysis' => $analysis,
			'create_time' => time(),
		))){
			alert('添加成功', 1);
		}else{
			alert('添加失败', 0);
		}
	}

	/**
	 * 修改题目解题思路
	 */
	public function editAnalysis(){
		$id = intval(post('id', 0));
		$content = (string)Yii::$app->request->post('content');
		if(!$id || !$content){
			alert('参数不正确', 0);
		}
		$mEs = m('Es');
		if(!$aEs = $mEs->getEsInfoByEsId($id)){
			alert('无效的题目ID', 0);
		}

		if(!w('length(5,500)', $content)){
			alert('解题思路内容必须在5到500字以内', 0);
		}

		if($mEs->editEsAnalysis(array(
			'id' => $aEs['id'],
			'user_id' => $this->_userId,
			'user_type' => 2,
			'is_approved' => 1,
			'analysis' => $content,
			'create_time' => time(),
		))){
			alert('修改成功', 1);
		}else{
			alert('修改失败', 0);
		}
	}

	/**
	 * 检查绑定的科目
	 */
	private function _checkAllowSubject($subjectId){
		$oManager = m('Manager');
		$aAllowSubjectId = $oManager->getUserAllowedSubjectByUserId($this->_userId);
		if(!in_array($subjectId, $aAllowSubjectId)){
			alert('您没有管理 ' . $GLOBALS['SUBJECT'][$subjectId] . ' 科目目录的权限', 0);
		}
	}

	/**
	 * 获取题目信息
	 */
	private function _getEsInfo($esId){
		if(!($esId >= 1)){
			alert('非法的题目ID', 0);
		}
		$oEs = m('Es');
		$aEsInfo = $oEs->getEsInfoByEsId($esId);
		if(!$aEsInfo){
			alert('题目不存在', 0);
		}
		return $aEsInfo;
	}

	/**
	 * 生产插件对象的工厂
	 * @param type $subject
	 * @param type $esType
	 * @return type
	 */
	private function _esFactory($subject, $esType){
		if(!is_numeric($subject) || !is_numeric($esType)){
			alert('参数错误', 0);
		}
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('不存在此科目', 0);
		}
		if(!array_key_exists($esType, $GLOBALS['ES_TYPE'])){
			alert('不存在此题型', 0);
		}
		if(!in_array($esType, $GLOBALS['SUBJECT_TYPE'][$subject])){
			alert($GLOBALS['SUBJECT'][$subject] . '科目不存在' . $GLOBALS['ES_TYPE'][$esType], 0);
		}
		$oEs = esPlugin($GLOBALS['TYPE_RESOLVER'][$esType]);
		return $oEs;
	}

}