<?php
	class EduNewsController{

		private $_newsTitle = '';
		private $_newsContent = '';
		private function _checkLength(){
			$newsTitle = post('title');
			$newsTitleLength = iconv_strlen($newsTitle, "UTF-8");
			if(!($newsTitleLength >= 5 && $newsTitleLength <=200)){
				alert('标题请在5-200个字符之间输入', 0);
			}
			$this->_newsTitle = $newsTitle;
			$newsContent = $_POST['content'];
			$newsContentLength = iconv_strlen($newsContent, "UTF-8");
			if(!($newsContentLength >= 5 && $newsContentLength < 10000)){
				alert('内容请在5-10000个字符之间输入', 0);
			}
			$this->_newsContent = $newsContent;
		}

		public function showList(){
			$oEduNews = m('EduNews');
			$pageUrl = '/?m=EduNews&a=showList&page=_PAGE_';
			$newsCount = $oEduNews->getNewsContentCountByCategoryId();
			$aEduNewsList = $oEduNews->getNewsContentListByCategoryId();
			$pageHtml = page(array(
				'url'	=> $pageUrl,
				'total' => $newsCount,
				'size'	=> 5,
				'page'	=> 1,
			));

			$aCategoryList = $oEduNews->getCategoryList();
			assign('aCategoryList', $aCategoryList);
			assign('pageHtml', $pageHtml);
			assign('aEduNewsList', $aEduNewsList);
			display('edu_news/list.html.php');
		}

		public function showAdd(){
			$oEduNews = m('EduNews');
			$aCategoryList = $oEduNews->getCategoryList();
			assign('aCategoryList', $aCategoryList);
			display('edu_news/add.html.php');
		}

		public function showEdit(){
			$oEduNews = m('EduNews');
			$aCategoryList = $oEduNews->getCategoryList();
			$aEduNewsList = $oEduNews->getNewsContentListByCategoryId();
			$id = (int)get('id');
			$aEduNews = $oEduNews->getNewsContentInfo($id);
			if(!$aEduNews){
				alert('找不到该文章', 0);
			}
			assign('aCategoryList', $aCategoryList);
			assign('aEduNews', $aEduNews);
			display('edu_news/edit.html.php');
		}

		public function add(){
/*			$_POST = array(
				'id'          =>32,
				'category'    =>3,
				'title'       =>'123fgfgfg',
				'content'     =>'888这是ddf',
			);*/
			$categoryId = post('category');
			$oEduNews = m('EduNews');
			$aCategoryList = $oEduNews->getCategoryList();
			$isCategory = false;
			foreach ($aCategoryList as $aCategory) {
				if($aCategory['id'] == post('category')){
					$isCategory = true;
					break;
				}
			}
			if(!$isCategory){
				alert('没有此分类资讯', 0);
			}

			$this->_checkLength();
			$aData = array(
				'category_id' => 3,
			    'title' => $this->_newsTitle,
			    'content' => $this->_newsContent,
			    'create_time' => time(),
			);
			$isAddSucess = $oEduNews->addNewsContent($aData);
			if ($isAddSucess) {
				alert('添加成功', 1);
			}else {
				alert('添加失败', 0);
			}
		}

		public function edit(){
			$oEduNews = m('EduNews');
			$categoryId = post('category');
			$isCategory = false;
			$aCategoryList = $oEduNews->getCategoryList();
			foreach ($aCategoryList as $aCategory) {
				if($aCategory['id'] == $categoryId){
					$isCategory = true;
					break;
				}
			}
			if(!$isCategory){
				alert('没有此分类资讯', 0);
			}
			$this ->_checkLength();
			$aData = array(
				'id' => (int)post('id'),
				'category_id' => $categoryId,
				'title' => $this->_newsTitle,
				'content' => $this->_newsContent,
			);
			$isAddSucess = $oEduNews->setNewsContent($aData);
			if ($isAddSucess) {
				alert('编辑成功', 1);
			}else {
				alert('编辑失败', 0);
			}
		}

	}