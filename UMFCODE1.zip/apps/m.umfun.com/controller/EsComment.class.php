<?php
class EsCommentController{
	private $_userId = 0;
	private $_permissionFlag = 'manage_es_comment';
	
	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('抱歉！您无权进行操作，请联系管理员！', 0);
		}
	}
	
	/**
	* 题目评论列表
	*/
	public function showList(){
		$url = 'http://' . APP_MANAGE . '/?m=EsComment&a=showList';
		$pageSize = 15;
		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;
		$oWenwen = m('Wenwen');
		$aCommentList = $oWenwen->getCommentList($page, $pageSize);
		if($aCommentList === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}
		$oUser = m('User');
		foreach($aCommentList as $key => $aComment){
			$aUserInfo = $oUser->getUserDetailInfoByUserId($aComment['user_id']);
			$aCommentList[$key]['user_name'] = $aUserInfo['name'];
		}
		$commentCount = $oWenwen->getAllCommentCount();
		if($commentCount === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}
		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $commentCount,
			'selector' => 1,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);
		assign('aCommentList', $aCommentList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('es_comment/comment_list.html.php');
		displayFooter();
	}
	
	/**
	* 题目评论操作
	*/
	public function approveComment(){
		$commentId = intval(post('comment_id'));
		$approved = intval(post('action_id'));
		if($approved == 0){
			$action = '撤销通过';
		}elseif($approved == 1){
			$action = '审核通过';
		}elseif($approved == -1){
			$action = '屏蔽';
		}else{
			alert('抱歉！您操作有误！', 0);
		}
		$aData = array(
			'id' => $commentId, 
			'approved' => $approved,
		);
		$row = m('Wenwen')->setComment($aData);
		if($row === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}elseif($row){
			alert($action . '成功');
		}elseif($row == 0){
			alert('您没有修改！', 0);
		}
	}
	
	/**
	* 题目评论详情
	*/
	public function showCommentDetail(){
		$esId = intval(get('es_id'));
		$commentId = intval(get('comment_id'));
		$oWenwen = m('Wenwen');
		$aCommentList = $oWenwen->getCommentListByEsId($esId);
		if($aCommentList === false){
			alert('抱歉！系统出错，请稍后再试！', 0);
		}elseif(!$aCommentList){
			alert('抱歉！这条题目评论不存在，请联系管理员！', 0);
		}
		$aEsInfo = m('Es')->getEsInfoByEsId($esId);
		if($aEsInfo === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif(!$aEsInfo){
			alert('抱歉！这条评论的题目不存在，请联系管理员！', 0);
		}
		$isCommentExists = false;
		foreach($aCommentList as $aComment){
			if($aComment['id'] == $commentId){
				$isCommentExists = true;
				break;
			}
			foreach($aComment['child'] as $aChildComment){
				if($aChildComment['id'] == $commentId){
					$isCommentExists = true;
					break;
				}
			}	
		}
		if(!$isCommentExists){
			alert('抱歉！这条题目评论不存在，请联系管理员！', 0);
		}
		$aEsPlugins = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
		$aEsInfo['es_content'] = $aEsPlugins->resolve($aEsInfo['content_json']);
		assign('commentId', $commentId);
		assign('aEs', $aEsInfo);
		assign('aCommentList', $aCommentList);
		displayHeader();
		display('es_comment/comment_detail.html.php');
		displayFooter();
	}
}