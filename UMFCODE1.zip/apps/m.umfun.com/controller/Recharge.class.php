<?php
class RechargeController{
	private $_permissionFlag = 'manage_ub_log';
	private $_userId = 0;
	private $_aRechargeTypeName = array(
			1 => 'U币卡充值',
			2 => '月费卡充值',
			3 => '会员体验卡充值',
			4 => 'U币支付',
			5 => '支付宝',
			6 => '银联在线',
			7 => 'API代理商月结'
	);
	
	private $_aProductList = array(
		'1' => 'Q币充值',
		'2' => '月费充值',
		'3' => '普通会员',
		'4' => '钻石会员',
		'5' => '白金会员',
	);
	
	
	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			wrong('您没有权限对此操作');
		}
	}

	//取所有代理商ID和NAME
	private function getPorxy(){
		$returnAarray = array();
		$aProxyList = array();
		$oProxy = m('Proxy');
		$aProxyCount = $oProxy->getProxyUserCount();
		if( $aProxyCount > 0){
			$aProxyList = $oProxy->getProxyUserList(1, $aProxyCount);
			if($aProxyList){
				foreach($aProxyList as $key=>$aProxyInfo){
					$returnAarray[$key]['id'] = $aProxyInfo['id'];
					$returnAarray[$key]['name'] = $aProxyInfo['name'];
				}
			}
		}
		unset($aProxyList);
		return $returnAarray;
	}
	
	
	//充值列表
	public function showRechargeList(){
		$oRecharge = new RechargeModel();
		$oUser = new UserModel();
		$oRroxy = new ProxyModel();
		$searchUserId = '';
		$searchCreateTime = 0;
		$url = '?m=Recharge&a=showRechargeList&page=_PAGE_';
		
		$rechargeId = intval(get('rechargeId'));
		$serialNumber = get('serialNumber');
		$userId = intval(get('userId'));
		$quantity = intval(get('quantity'));
		$payMoney = floatval(get('payMoney'));
		$createTime = get('createTime');
		$byProxyId = intval(get('byProxyId'));
		$proxyId = intval(get('proxyId'));
		$payType = intval(get('payType'));
		$type = intval(get('type'));
		$payFinish = get('payFinish');
		
		if($rechargeId){
			if(!preg_match('/^\d{5,}$/', $rechargeId)){
				$rechargeId = '';
			}else{
				$url .= '&rechargeId=' . $rechargeId;
			}
		}
		
		if($serialNumber){
			$url .= '&serialNumber=' . $serialNumber;
		}
		
		if($userId > 0){
			$searchUserId = 0;
			if(preg_match('/^\d{8,}$/', $userId)){
				$aSearchUserInfo = $oUser->getUserInfoByUserId($userId);
				if($aSearchUserInfo){
					$searchUserId = $aSearchUserInfo['id'];
				}
			}
			$url .= '&userId=' . $userId;
		}
		
		if($quantity){
			if(!preg_match('/^\d{1,5}$/', $quantity)){
				$quantity = 0;
			}else{
				if(0 > $quantity || $quantity > 10000){
					$quantity = 0;
				}else{
					$url .= '&serialNumber=' . $serialNumber;
				}
			}
		}
		
		if($payMoney){
			if(!preg_match('/^\d{1,5}(\.\d{1,2})?$/', $payMoney)){
				$payMoney = 0;
			}else{
				if( 0 > $payMoney || $payMoney > 10000){
					$payMoney = 0;
				}else{
					$url .= '&payMoney=' . $payMoney;
				}
			}
		}
		
		if($createTime){
			$tmpCreateTime = strtotime($createTime);
			if(date('Y-m-d H:i:s', $tmpCreateTime) == $createTime){
				$searchCreateTime = $tmpCreateTime;
				$url .= '&tmpCreateTime=' . $tmpCreateTime;
			}else{
				$createTime = '';
			}
		}
		
		if($byProxyId > 0){
			$url .= '&byProxyId=' . $byProxyId;
		}
		
		if($proxyId > 0){
			$url .= '&proxyId=' . $proxyId;
		}
		

		if($payType > 0){
			$url .= '&payType=' . $payType;
		}
		
		//让页面默认为U币充值
		if(empty($type) && (intval(get('isProxyCount'))==1)){
			$type = 1;
		}
		
		
		
		if($type > 0){
			$url .= '&type=' . $type;
		}
		
		if($payFinish){
			$url .= '&payFinish=' . $payFinish;	
		}
		
		$page = intval(get('page' , 1));
		$pageSize = 20;
		$aRechargeList = array();
		$pageHtml = '';
		
		if($page < 1){
			$page = 1;
		}
		$count = $oRecharge->getRechargeStatistics($rechargeId, $serialNumber, $searchUserId, $quantity, $payMoney, $searchCreateTime, $proxyId, $byProxyId, $payType, $type, $payFinish);
		
		$pageCount = ceil($count / $pageSize);
		if($page > $pageCount){
			$page = $pageCount;
		}
		
		if($count > 0){
			$aRechargeList = $oRecharge->getRechargeList($page, $pageSize, 'id DESC', $rechargeId, $serialNumber, $searchUserId, $quantity, $payMoney, $searchCreateTime, $proxyId, $byProxyId, $payType, $type, $payFinish);
			if($aRechargeList){
				foreach($aRechargeList as $key => $aRechargeInfo){
					//取会员名及数字帐号
					$aRechargeList[$key]['userName'] = '';
					$aRechargeList[$key]['numberId'] = '';
					if($aRechargeInfo['user_id'] > 0){
						$aPersonalInfo = $oUser->getPersonalInfoByUserId($aRechargeInfo['user_id']);
						if($aPersonalInfo){
							$aRechargeList[$key]['userName'] = $aPersonalInfo['name'];
						}
						
						$aUserInfo = $oUser->getUserInfoByUserId($aRechargeInfo['user_id']);
						
						
					}
					
					//计算实付金额
					if($aRechargeInfo['pay_type'] == 3){
						$aRechargeList[$key]['pay_money'] = '0.00';
					}else{
						$aRechargeList[$key]['pay_money'] = $aRechargeInfo['pay_money'] / 100 ;
						if(substr_count($aRechargeList[$key]['pay_money'],'.') == 0){
							$aRechargeList[$key]['pay_money'] = $aRechargeList[$key]['pay_money']. '.00';
						}						
					}

					//支付类型
					$aRechargeList[$key]['payTypeName'] = $this->_aRechargeTypeName[$aRechargeInfo['pay_type']] ;
					
					//支付类型number
					$aRechargeList[$key]['payType'] = $aRechargeInfo['pay_type'] ;
					
					//取代理商Name
					$aRechargeList[$key]['proxyName'] = '';
					if($aRechargeInfo['proxy_user_id'] > 0){
						$aProxyInfo = $oRroxy->getProxyUserInfoById($aRechargeInfo['proxy_user_id']);
						if($aProxyInfo){
							$aRechargeList[$key]['proxyName'] = $aProxyInfo['name'];
						}
					}
				}
			}
			
			$aPageInfo = array(
				'url' => $url,
				'total' => $count,
				'size' => $pageSize,
				'page' => $page,
			);
			$pageHtml = page($aPageInfo);
		}
		
		$proxyList = $this->getPorxy();		
		
		//总计
		$isProxyCount = intval(get('isProxyCount', 0));	//是否为代理商统计列表		
		if($isProxyCount){
			$commission = (int)get('commission');
			if(!$commission){
				$commission = 100;
			}
			$quantityCount     = 0;
			$pay_moneyCount    = 0;
			$orderNumberCount  = count($aRechargeList);
			
			foreach($aRechargeList as $v){
			  if($v['pay_finish'] != 1 || $v['payType'] == 3){continue;}
				if($type == 2){
				   $pay_moneyCount += $v['quantity'] * 75 * $commission / 100;	
				}else{
				   $pay_moneyCount += $v['quantity'] * $commission / 100;	
				}	
				$quantityCount  += $v['quantity'];	
			}			
			
			assign('quantityCount', $quantityCount);
			assign('pay_moneyCount', $pay_moneyCount);
			assign('orderNumberCount', $orderNumberCount);
			assign('commission', $commission);
		}
		
		assign('isProxyCount', $isProxyCount);		
		assign('rechargeId', $rechargeId);
		assign('serialNumber', $serialNumber);
		assign('userId', $userId);
		assign('quantity', $quantity);
		assign('payMoney', $payMoney);
		assign('createTime', $createTime);
		assign('byProxyId', $byProxyId);
		assign('proxyId', $proxyId);
		assign('payType', $payType);
		assign('type', $type);
		assign('payFinish', $payFinish);		
		assign('aProductList', $this->_aProductList);
		
		assign('payTypeList', $this->_aRechargeTypeName);
		assign('proxyList', $proxyList);
		assign('aRechargeList', $aRechargeList);
		assign('pageHtml', $pageHtml);
		displayHeader();
		display('recharge/list.html.php');
		displayFooter();		
	}
	

	//订单详情
	public function showRechargeInfo(){
		$id = intval(get('id',0));
		if($id < 0 || $id == 0){
			wrong('数据错误');
		}
		
		$oRecharge = m('Recharge');
		$oUser = m('User');
		$oProxy = m('Proxy');
		
		$aRechargeInfo = array();
		$aRechargeInfo = $oRecharge->getRechargeInfoById($id);
		if($aRechargeInfo){
			//取充值者Name
			$aRechargeInfo['usrName'] = '';
			$aPersonalInfo = $oUser->getPersonalInfoByUserId($aRechargeInfo['user_id']);
			if($aPersonalInfo){
				$aRechargeInfo['usrName'] = $aPersonalInfo['name'];
			}
			
			//计算实付金额
			$aRechargeInfo['pay_money'] = $aRechargeInfo['pay_money'] / 100 ;
			if(substr_count($aRechargeInfo['pay_money'],'.') == 0){
				$aRechargeInfo['pay_money'] = $aRechargeInfo['pay_money']. '.00';
			}
			
			//支付类型
			$aRechargeInfo['payTypeName'] = $this->_aRechargeTypeName[$aRechargeInfo['pay_type']] ;
			
			
			//取代理商Name
			$aRechargeInfo['proxyName'] = '';
			if($aRechargeInfo['proxy_user_id'] > 0){
				$aProxyInfo = $oProxy->getProxyUserInfoById($aRechargeInfo['proxy_user_id']);
				if($aProxyInfo){
					$aRechargeInfo['proxyName'] = $aProxyInfo['name'];
				}
			}
			
		}
		
		if($aRechargeInfo){
			assign('aRechargeInfo' , $aRechargeInfo);
			displayHeader();
			display('recharge/info.html.php');
			displayFooter();
		}else{
			wrong('此记录不存在');
		}
		
	}



}

