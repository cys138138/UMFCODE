<?php
class RaidersController{
	private $_permissionFlag = 'manage_raiders';
	private $_userId = 0;
	private $_aExpress = array(
		0 => '-请选择-',
		1 => '顺丰快递',
		2 => '圆通快递',
		3 => '中通快递',
		4 => '申通快递',
		5 => '宅 急 送',
		6 => '邮政EMS',
		7 => '中国邮政'
	);
	private $_aGoods = array(
			0 => '无奖品',
			1 => '一等奖',
			2 => '二等奖',
			3 => '三等奖',
			4 => '幸运奖'

	);

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('您没有权限对此操作', 0);
		}
	}

	/*
	 * 夺宝奖品
	 */
	public function showPrizesList(){

		$page = intval(get('page', 1));
		$pageSize = 20;
		$oRaiders = m('Raiders');
		$aPrizeList = $oRaiders->getPrizeList(0, $page, $pageSize);
		if($aPrizeList === false){
			alert('系统错误', 0);
		}
		assign('aPrizeList', $aPrizeList);

		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$aPrizeCount = $oRaiders->getPrizeCount();
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aPrizeCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);
		assign('aGoods', $this->_aGoods);

		displayHeader();
		display('raiders/prizes.html.php');
		displayFooter();
	}

	//增加奖品视图
	public function showAddPrizes(){
		displayHeader();
		display('raiders/prizes_add.html.php');
		displayFooter();
	}

	//编辑奖品视图
	public function showEditPrizes(){
		$id = intval(get('id'));
		if(!$id){
			alert('非法参数', 0);
		}

		$oRaiders = m('Raiders');
		$aPrizesInfo = $oRaiders->getPrizeInfoById($id);
		if($aPrizesInfo === false){
			alert('系统错误', 0);
		}else if(!$aPrizesInfo){
			alert('不存在数据', 0);
		}
		$aHighMap = $aPrizesInfo['hd_image'];
		//debug($aPrizesInfo['hd_image']);

		assign('aHighMap', $aHighMap);
		assign('aPrizesdInfo', $aPrizesInfo);
		assign('aGoods', $this->_aGoods);
		displayHeader();
		display('raiders/prizes_edit.html.php');
		displayFooter();
	}




	//删除奖品
	public function delPrizes(){
		$id = intval(post('id'));
		if(!$id){
			alert('id错误', 0,$id);
		}
		if(m('Raiders')->deletePrizeById($id)){
			alert('成功',1);
		}else{
			alert('失败', 0);
		}
	}

	/**
	 * 保存奖品信息
	 */
	public function savePrizes(){
		$isSave = post('type') ? true : false;
		$goodProfile = post('good_profile');
		$goodName = post('good_name');
		$nameLength = mb_strlen($goodName, 'UTF-8');
		if($nameLength < 2 || $nameLength > 20){
			//alert('奖品名称只能在2到20字之间', 0);
		}

		$goodLevel = intval(post('good_level'));
		$goodStock = intval(post('good_stock'));
		$goodTotal = intval(post('good_total'));
		$updateFilePath = true;
		if(!$goodProfile || !$goodName || !$goodLevel || !$goodStock || !$goodTotal){
			alert('请仔细填写信息', 0);
		}
		if(!array_key_exists($goodLevel, $this->_aGoods)){
			alert('不存在的奖品等级', 0);
		}

		$oRaiders = m('Raiders');
		if($isSave){
			$id = (int)post('id');
			$aPrizeInfo = $oRaiders->getPrizeInfoById($id);
			if($aPrizeInfo === false){
				alert('系统错误', 0);
			}else if(!$aPrizeInfo){
				alert('不存在的id', 0);
			}
			if($aPrizeInfo['image'] == $goodProfile){
				$updateFilePath = false;
			}
		}

		if($updateFilePath){
			$tmpFile = SYSTEM_RESOURCE_PATH . USER_TMP_PATH . basename($goodProfile);
			if(!file_exists($tmpFile)){
				//alert('111', 0, $tmpFile);
			}else{

				if(!rename($tmpFile, SYSTEM_RESOURCE_PATH . $goodProfile)){
					alert('移动到新文件时失败', 0, $goodProfile);
				}
			}
		}

		$aGoodProfileAtlas = post('map_path_list');
		$aMay = $aNewsAddMay = array();
		$upFileHash = array();
		if(!$isSave){
			foreach ($aGoodProfileAtlas as $aSrc){
				$tmpFile = SYSTEM_RESOURCE_PATH . str_replace(RAIDERS_PROFILE_PATH, USER_TMP_PATH, $aSrc);
				if(!file_exists($tmpFile)){
					//alert('没有找到存放地址', 0);
				}else{
					//拿出临时图片地址
					$aUmfunTempFile = $aUmfunTemp[] = str_replace(SYSTEM_RESOURCE_URL , '/' ,$tmpFile);
					$fileHash = substr($aUmfunTempFile,-18,-4);
					//地址移动处理
					if(!file_exists( $aUmfunTempFile)){
						alert('上传的高清图片不存在', 0, $tmpFile);
					}else{
						//移动函数
						if(rename($aUmfunTempFile, SYSTEM_RESOURCE_PATH . $aSrc)){
							$aMay[$fileHash] = $aSrc;
						}
					}
				}
			}
		}else{
			$aDate = $aPrizeInfo['hd_image'];
			$tmps = array();
			if(!empty($aGoodProfileAtlas)){
				foreach ($aGoodProfileAtlas as $aSrc){
					$upFileHash = substr($aSrc,-18,-4);
					if(isset($aDate) && array_key_exists($upFileHash, $aDate)){
							$tmps[$upFileHash] = $aDate[$upFileHash];
							unset($aDate[$upFileHash]);
					}
					if(!array_key_exists($upFileHash, $tmps)){
						$tmpFile = SYSTEM_RESOURCE_PATH . str_replace(RAIDERS_PROFILE_PATH, USER_TMP_PATH, $aSrc);
						if(!file_exists($tmpFile)){
							//alert('没有找到存放地址', 0, $tmpFile);
						}else{
						//拿出临时图片地址
						$aUmfunTempFile = $aUmfunTemp[] = str_replace(SYSTEM_RESOURCE_URL , '/' ,$tmpFile);
						}
						//移动函数
						if(rename($aUmfunTempFile, SYSTEM_RESOURCE_PATH . $aSrc)){
							$aNewsAddMay[$upFileHash] = $aSrc;
						}
					}
				}
			}
			//删除沉淀数据
			if(isset($aDate)){
				foreach($aDate as $hash => $file){
					if(file_exists(SYSTEM_RESOURCE_PATH . $file) && !unlink(SYSTEM_RESOURCE_PATH . $file)){
						myLog('话题图片删除失败，路径是：' . SYSTEM_RESOURCE_PATH . $file);
					}
				}
			}
			//数组合拼
			$aMay = array_merge($aNewsAddMay, $tmps);
		}

		$aData = array(
			'name' => $goodName,
			'image' => RAIDERS_PROFILE_PATH . basename($goodProfile),
			'level' => $goodLevel,
			'surplus' => $goodStock,
			'hd_image' => $aMay,
			'total' => $goodTotal
		);

		if(!$isSave){
			if($oRaiders->addPrize($aData)){
				alert('增加奖品成功', 1);
			}else{
				alert('增加奖品失败', 0);
			}
		}else{
			$aData['id'] = $id;
			if($oRaiders->setPrize($aData)){
				alert('更新奖品成功', 1);
			}else{
				alert('更新奖品失败', 0);
			}
		}
	}

	/*
	 *  夺宝发货
	 */
	public function showAwardList(){
		$page = intval(get('page', 1));
		$pageSize = 20;
		$oRaiders = m('Raiders');
		$aAwardList = $oRaiders->getAwardList($page, $pageSize);
		if($aAwardList === false){
			alert('系统错误', 0);
		}
		assign('aAwardList', $aAwardList);

		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$aAwardCount = $oRaiders->getAwardCount();
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aAwardCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);

		assign('aExpress', $this->_aExpress);
		displayHeader();
		display('raiders/award.html.php');
		displayFooter();
	}

	//增加发货信息视图
	public function showAddAward(){
		$aPrizeList = m('Raiders')->getPrizeList(0, 1, 500);
		if($aPrizeList === false){
			alert('系统错误', 0);
		}
		assign('aPrizeList', $aPrizeList);
		assign('aExpress', $this->_aExpress);

		displayHeader();
		display('raiders/award_add.html.php');
		displayFooter();
	}

	//编辑发货信息视图
	public function showEditAward(){
		$id = intval(get('id'));
		if(!$id){
			alert('非法参数', 0);
		}
		$oRaiders = m('Raiders');
		$aAwardInfo = $oRaiders->getAwardInfoById($id);
		if($aAwardInfo === false){
			alert('系统错误', 0);
		}else if(!$aAwardInfo){
			alert('不存在数据', 0);
		}
		assign('aAwardInfo', $aAwardInfo);

		$aPrizeList = $oRaiders->getPrizeList(0, 1, 500);
		if($aPrizeList === false){
			alert('系统错误', 0);
		}
		assign('aPrizeList', $aPrizeList);

		assign('aExpress', $this->_aExpress);
		displayHeader();
		display('raiders/award_edit.html.php');
		displayFooter();
	}

	//删除发货信息-----【暂时不用】
	public function delAward(){
		alert('系统禁用此方法', 0);die;
		$id = intval(post('id'));
		if(!$id){
			alert('id错误', 0,$id);
		}
		if(m('Raiders')->deleteAwaedById($id)){
			alert('成功',1);
		}else{
			alert('失败', 0);
		}
	}

	//保存发货信息
	public function saveAward(){
		$type = intval(post('type'));
		if($type != 1 && $type != 2){
			alert('非法参数', 0);
		}

		$userId = intval(post('userId'));
		$prizesId = intval(post('prizesId'));
		$toName = post('toName');
		$toPhone = post('toPhone');
		$toAddress = post('toAddress');
		$expresNameId = intval(post('expresNameId'));
		$expresId = post('expresId');

		if(!$userId || strlen($userId) < 5 || !$prizesId || !$toName || !$toPhone || !$toAddress){
			alert('填写的信息有误', 0,strlen($userId));
		}
		if(!array_key_exists($expresNameId, $this->_aExpress)){
			alert('不存在的快递公司', 0);
		}
		if(!getUserInfo($userId)){
			alert('不存在用户ID', 0);
		}

		$oRaiders = m('Raiders');
		$aPrizeInfo = $oRaiders->getPrizeInfoById($prizesId);
		if($aPrizeInfo === false){
			alert('系统错误', 0);
		}else if(!$aPrizeInfo){
			alert('没有奖品信息', 0);
		}

		$oRaiders = m('Raiders');
		$aPrizeInfo = $oRaiders->getPrizeInfoById($prizesId);
		if($aPrizeInfo === false){
			alert('系统错误', 0);
		}else if(!$aPrizeInfo){
			alert('没有奖品信息', 0);
		}

		$aData = array(
			'user_id' => $userId,
			'prize_id' => $prizesId,
			'user_name' => $toName,
			'user_number' => $toPhone,
			'user_address' => $toAddress,
			'express_info' => $expresNameId . ',' . $expresId
		);

		if($type == 1){
			$aData['create_time'] = time();
			if($oRaiders->addAward($aData)){
				alert('增加货单成功', 1);
			}else{
				alert('增加货单失败', 0);
			}
		}else{
			$id = intval(post('id'));
			if(!$id){
				alert('id错误', 0);
			}
			$aData['id'] = $id;
			$aResult = $oRaiders->setAward($aData);
			if($aResult){
				alert('更新货单成功', 1);
			}else{
				alert('更新货单失败', 0, $aResult);
			}
		}
	}

	public function checkUser(){
		$userId = intval(get('user_id'));
		$aResult = getUserInfo($userId, array('area', 'personal'));
		if(!$aResult){
			alert('ID错误', 0);
		}else{
			alert('正确用户', 1, $aResult);
		}
	}

	/*
	 * 图片上传
	 */
	public function uploadProfile(){
		$profileName = str_replace('.', '',  microtime(true));
		$oUploader = new UploadFile(3072000, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . USER_TMP_PATH,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			alert('文件上传失败".' . $oUploader->getErrorMsg() . '."', 0);
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$aWidthAndHeight = array();
		$aWidthAndHeight = getimagesize(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
		if(!$aWidthAndHeight){
			alert('文件上传失败', 0);
		}
		$width = intval($aWidthAndHeight[0]);
		$height = intval($aWidthAndHeight[1]);
		if($width > 1920){
			if(file_exists(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename'])){
				unlink(SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $uploadFileInfo['savename']);
			}
			alert('图片宽度不能超过1920px', 0);
		}
		alert(RAIDERS_PROFILE_PATH . $uploadFileInfo['savename'], 1, SYSTEM_RESOURCE_URL . USER_TMP_PATH . $uploadFileInfo['savename']);
	}

	public function showJoinList(){
		$page = intval(get('page', 1));
		$pageSize = 10;
		$aCondition = array(
			'user_type'		=>	intval(get('userType', 0)),
			'is_prize'		=>	intval(get('isPrize', -1)),
			'luck_times'	=>	intval(get('luckTimes', -1)),
			'surplus_times'	=>	intval(get('surplus_times', -1)),
			'start_time'	=>  get('startTime', 0),
			'end_time'		=>	get('endTime', 0),
		);
		if($aCondition['start_time']){
			$aCondition['start_time'] = strtotime($aCondition['start_time']);
		}
		if($aCondition['end_time']){
			$aCondition['end_time'] = strtotime($aCondition['end_time']);
		}
		$oRaiders = m('Raiders');
		$aJoinList = $oRaiders->getJoinList($aCondition,$page,$pageSize);
		if($aJoinList === false){
			alert('系统错误', 0);
		}
		//分页
		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$joinCount = $oRaiders->getJoinCount($aCondition);
		if($joinCount === false){
			alert('系统错误',0);
		}
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $joinCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('joinCount', $joinCount);
		assign('pageHtml', $pageHtml);
		assign('aJoinList', $aJoinList);
		displayHeader();
		display('raiders/join.html.php');
		displayFooter();
	}
	//删除奖品
	public function delJoins(){
		$id = intval(post('id'));
		if(!$id){
			alert('id错误', 0,$id);
		}
		if(m('Raiders')->deleteJoinById($id)){
			alert('成功',1);
		}else{
			alert('失败', 0);
		}
	}


}