<?php
class UserController{
	private $_userId = 0;
	private $_permissionFlag = 'manage_user';

	public function __construct(){
		$this->_userId = checkLogin();
		if(!checkPermission($this->_userId, $this->_permissionFlag)){
			alert('抱歉！您无权进行操作，请联系管理员！', 0);
		}

	}

	public function showUserList(){
		$lastLoginTime = 99;
		$oUser = m('User');
		$url = 'http://' . APP_MANAGE . '/?m=User&a=showUserList';
		$account = get('account');
		if($account){
			$startTime = date('Y-m-d 00:00:00');
			$endTime = date('Y-m-d H:i:s');
			$startTimeStamp = 0;
			$endTimeStamp = time();
			$provinceId = 0;
			$cityId = 0;
			$areaId = 0;
			$schoolId = 0;
			$gender = 0;
			$name = '';
			$eMail = -1;
			$userPhone = -1;
			$ageStart = '';
			$ageEnd = '';
			$approveStatus = -1;
			$page = 1;
			$pageSize = 1;
			$userCount = 1;
			$orderByCreateTime = 0;
			$lastLoginTime = 0;
			$vipLevel = '';
		}else{

			$startTime = get('start_time');
			$endTime = get('end_time');
			if(!$startTime){
				$startTime = date('Y-m-d 00:00:00');
			}
			$url .= '&start_time=' . $startTime;

			if(!$endTime){
				$endTime = date('Y-m-d H:i:s');
			}
			$url .= '&end_time=' . $endTime;

			$provinceId = intval(get('province_id'));
			$cityId = intval(get('city_id'));
			$districtId = intval(get('district_id'));
			$areaId = 0;
			if($provinceId){
				$areaId = $provinceId;
				$url .= '&province_id=' . $provinceId;
			}
			if($cityId){
				$areaId = $cityId;
				$url .= '&city_id=' . $cityId;
			}
			if($districtId){
				$areaId = $districtId;
				$url .= '&district_id=' . $districtId;
			}

			$schoolId = intval(get('school_id'));
			if($schoolId){
				$url .= '&school_id=' . $schoolId;
			}

			$gender = intval(get('gender'));
			if($gender){
				$url .= '&gender=' . $gender;
			}

			$name = get('name');
			if($name){
				$url .= '&name=' . $name;
			}

			$eMail = (int)get('e_mail', -1);
			if($eMail== 0 || $eMail){
				$url .= '&e_mail=' . $eMail;
			}

			$userPhone = (int)get('user_phone', -1);
			if($userPhone== 0 || $userPhone){
				$url .= '&user_phone=' . $userPhone;
			}

			$ageStart = get('age_start');
			if($ageStart){
				$url .= '&age_start=' . $ageStart;
			}

			$ageEnd = get('age_end');
			if($ageEnd){
				$url .= '&age_end=' . $ageEnd;
			}

			$approveStatus = intval(get('approve_status',-1));
			if($approveStatus == 0){
				$url .= '&approve_status=' . $approveStatus;
			}

			$vipLevel = intval(get('vipLevel', -1));
			if($vipLevel != -1){
				$url .= '&vipLevel=' . $vipLevel;
			}

			$lastLoginTime = intval(get('last_login_time', -1));
			if($lastLoginTime != 0 && $lastLoginTime != 1){
				$lastLoginTime = 1;
			}

			$url .= '&last_login_time=' . $lastLoginTime;
			$account = '';
			$pageSize = 10;
			//查询之前先将时间字符串转成时间戳
			$startTimeStamp = strtotime($startTime);
			$endTimeStamp = strtotime($endTime);
			$userCount = $oUser->getUserCount($startTimeStamp, $endTimeStamp, $areaId, $schoolId, $gender, $name, $ageStart, $ageEnd, $account, $approveStatus, $vipLevel, $eMail, $userPhone);
			if($userCount === false){
				alert('系统出错，请稍后再试！', 0);
			}
		}

		$page = intval(get('page', 1));
		$page = $page > 0 ? $page : 1;
		$aUserList = $oUser->getUserList($page, $pageSize, $startTimeStamp, $endTimeStamp, $areaId, $schoolId, $gender, $name, $ageStart, $ageEnd, $account, $lastLoginTime, $approveStatus, $vipLevel, $eMail,  $userPhone);
		if($aUserList === false){
			alert('系统出错，请稍后再试', 0);
		}


		$aPageInfo = array(
			'url' => $url . '&page=_PAGE_',
			'total' => $userCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);
		assign('vipLevel', $vipLevel);
		assign('aPublicUser', $GLOBALS['PUBLIC_USER_IDS']);
		assign('approveStatus',$approveStatus);
		assign('account', $account);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		assign('provinceId', $provinceId);
		assign('cityId', $cityId);
		assign('areaId', $areaId);
		assign('schoolId', $schoolId);
		assign('gender', $gender);
		assign('eMail', $eMail);
		assign('userPhone', $userPhone);
		assign('name', $name);
		assign('ageStart', $ageStart);
		assign('ageEnd', $ageEnd);
		assign('lastLoginTime', $lastLoginTime);
		assign('pageHtml', $pageHtml);
		assign('aUserList', $aUserList);
		displayHeader();
		display('user/user_list.html.php');
		displayFooter();
	}

	public function updateApproveStatus(){
		$userId = post('userId');
		$aStatus = post('status');
		$sCount = count($aStatus);
		if($sCount < 0){
			alert('参数有误！提醒失败！',-1);
		}elseif($sCount == 1){
			$status = $aStatus[0];
			if($status != 2 && $status != 3 && $status != 4){
				alert('参数有误！提醒失败！',-1);
			}
		}else{
			foreach($aStatus as $status){
				if($status != 2 && $status != 3 && $status != 4){
					alert('参数有误！提醒失败！',-1);
				}
			}
			$status = 4;
		}

		$aData = array('id'=>$userId,'approve_status'=>$status);
		$oUser = m('User');
		$result = $oUser->setUserIndexInfo($aData);
		if($result){
			alert('提醒用户成功',1);
		}else{
			alert('提醒用户失败，请重新提醒！',-1);
		}
	}


	public function clearApproveStatus(){
		$userId = post('userId');
		$status = 0;
		$aData = array('id'=>$userId,'approve_status'=>$status);
		$oUser = m('User');
		$result = $oUser->setUserIndexInfo($aData);
		if($result){
			alert('取消提醒成功',1);
		}else{
			alert('取消提醒失败！',-1);
		}
	}

	public function showUserInfo(){
		$account = (string)get('account');
		if(!$account){
			alert('缺少查询账号');
		}
		$startTime = 0;
		$endTime = 0;
		$areaId = 0;
		$schoolId = 0;
		$gender = 0;
		$name = '';
		$ageStart = 0;
		$ageEnd = 0;
		$page = 1;
		$pageSize = 1;
		$aUserInfo = m('User')->getUserList($page, $pageSize, $startTime, $endTime, $areaId, $schoolId, $gender, $name, $ageStart, $ageEnd, $account);
		if($aUserInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		$aUserLevelInfo = m('UserNumerical')->getUserNumericalInfoById($aUserInfo[0]['id']);
		if($aUserLevelInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		assign('aUserInfo', $aUserInfo[0]);
		assign('aUserLevelInfo', $aUserLevelInfo);
		displayHeader();
		display('user/user_info.html.php');
		displayFooter();
	}

	public function showStatistics(){
		$startTime = get('start_time');
		$endTime = get('end_time');
		if(!$startTime){
			$startTime = date('Y-m-d 00:00:00');
		}
		if(!$endTime){
			$endTime = date('Y-m-d H:i:s');
		}
		$provinceId = intval(get('province_id'));
		$cityId = intval(get('city_id'));
		$districtId = intval(get('district_id'));
		$areaId = 0;
		if($provinceId){
			$areaId = $provinceId;
		}
		if($cityId){
			$areaId = $cityId;
		}
		if($districtId){
			$areaId = $districtId;
		}
		$oUser = m('User');
		$totalUserCount = $oUser->getUserCount();
		if($totalUserCount === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		//查询之前先将时间字符串转成时间戳
		$aStatisticsList = $oUser->getUserStatistics(strtotime($startTime), strtotime($endTime), $areaId);
		if($aStatisticsList === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}
		//模拟的付费用户的数据
		$aFeeData = array(
			0 => array(
				'fee' => '550',
				'numbers' => 200,
			),

			1 => array(
				'fee' => '650',
				'numbers' => 3000,
			),
			2 => array(
				'fee' => '750',
				'numbers' => 4000,
			),
		);
		$feetotalNewNumber = 7200;
		foreach($aFeeData as $key => $feeData){
			$aFeeData[$key]['percentage'] =$feetotalNewNumber ? round(($feeData['numbers'] / $feetotalNewNumber) * 100, 2) . '%' : '0%';
		}
		assign('totalUserCount', $totalUserCount);
		assign('aStatisticsList', $aStatisticsList);
		assign('provinceId', $provinceId);
		assign('cityId', $cityId);
		assign('areaId', $areaId);
		assign('aFeeData', $aFeeData);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		displayHeader();
		display('user/statistics.html.php');
		displayFooter();
	}

	public function setForbidden(){
		$userId = intval(post('id'));
		$is_forbidden = post('action');
		if($is_forbidden == 1){
			$tips = '禁用';
		}else{
			$tips = '激活';
		}
		$aData = array(
			'id' => $userId,
			'is_forbidden' => $is_forbidden,
		);
		$row = m('User')->setUserIndexInfo($aData);
		if($row === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($row){
			alert($tips . '成功！');
		}else{
			alert($tips . '失败！', 0);
		}
	}

	public function schoolInfo(){
		$oUser = m('User');
		$areaId = post('areaId');
		$aSchoolList = $oUser->getSchoolListByAreaId($areaId);
		if($aSchoolList === false){
			alert('系统出错，请稍后再试', 0);
		}
		alert('success', 1, $aSchoolList);

	}


	//待审核列表　
	public function showApproveInfoList(){
		$oUser = m('user');
		$page = intval(get('page', 1));
		$account = intval(get('account', 0));
		$pageSize = 10;
		$approveCount = 0;
		$aApproveList = array();
        $approveFinish = 0;
		if(preg_match('/^\d{8}$/', $account)){
			$aApproveList = array($oUser->getUserApproveInfo($account));
			if($aApproveList[0] === false){
				alert('系统错误', 0);
			}elseif(!$aApproveList[0]){
				unset($aApproveList[0]);
			}
		}else{
			$approveCount = $oUser->getUserInfoApproveCount($approveFinish);
			if($approveCount === false){
				alert('系统错误', 0);
			}
			if($approveCount > 0){
				$aApproveList = $oUser->getUserInfoApproveList($approveFinish, $page, $pageSize);
			}
		}

		if($aApproveList){
			foreach($aApproveList as &$aApproveInfo){
				$aApproveInfo['approve_name'] = '';
                $aApproveInfo['approve_name_pass_time'] = 1;
				$aApproveInfo['approve_profile'] = '';
                $aApproveInfo['approve_profile_pass_time'] = 1;
				$aApproveInfo['name'] = '';
				$aApproveInfo['profile'] = '';

				if(isset($aApproveInfo['content']['name'])){
					$aApproveInfo['approve_name'] = $aApproveInfo['content']['name']['content'];
					$aApproveInfo['approve_name_pass_time'] = $aApproveInfo['content']['name']['pass_time'];
				}
				if(isset($aApproveInfo['content']['profile'])){
					$aApproveInfo['approve_profile'] = $aApproveInfo['content']['profile']['content'];
					$aApproveInfo['approve_profile_pass_time'] = $aApproveInfo['content']['profile']['pass_time'];
				}

				$aPersonalInfo = $oUser->getPersonalInfoByUserId($aApproveInfo['id']);
				if($aPersonalInfo === false){
					alert('系统错误', 0);
				}
				if($aPersonalInfo){
					$aApproveInfo['name'] = $aPersonalInfo['name'];
					$aApproveInfo['profile'] = $aPersonalInfo['profile'];
				}
			}

		}
		$aPageInfo = array(
			'url' => '/?m=User&a=showApproveInfoList&page=_PAGE_',
			'total' => $approveCount,
			'size' => $pageSize,
			'page' => $page,
		);
		$pageHtml = page($aPageInfo);

		assign('aApproveList', $aApproveList);
		assign('pageHtml', $pageHtml);

		displayHeader();
		display('user/approve_info_list.html.php');
		displayFooter();
	}


	//审核
	public function approveInfo(){
		$aApproveList = post('approve_list');
		if(count($aApproveList) < 1){
            alert('数据错误', 0);
        }
		$oUser = m('user');
		foreach($aApproveList as $aTmpApproveInfo){
			if(!in_array($aTmpApproveInfo['namePass'], array(1, 2)) && !in_array($aTmpApproveInfo['profilePass'], array(1, 2))){
				alert('数据错误', 0);
			}

			$approveUserId = intval($aTmpApproveInfo['userId']);
			$aPersonalInfo = $oUser->getPersonalInfoByUserId($approveUserId);
			$aApproveInfo = $oUser->getUserApproveInfo($approveUserId);
			if(!$aPersonalInfo || !$aApproveInfo){
				alert($approveUserId . '该用户不存在或没有待审资料', 0);
			}
			$aSaveApproveInfo = $aPersonalData = array('id' => $approveUserId);
			$aSaveApproveInfo['content'] = array();

			if($aTmpApproveInfo['namePass'] == 0 && isset($aApproveInfo['content']['name'])){
				//姓名不处理,把待审的姓名取出来
				$aSaveApproveInfo['content']['name'] = $aApproveInfo['content']['name'];
			}else if($aTmpApproveInfo['namePass'] == 1){
				//姓名通审
				$aPersonalData['name'] = $aApproveInfo['content']['name']['content'];
				$aSaveApproveInfo['content']['name'] = array(
					'content' => $aApproveInfo['content']['name']['content'],
					'pass_time' => time()
				);

			}else if($aTmpApproveInfo['namePass'] == 2){
				//姓名不通审
				$aSaveApproveInfo['content']['name'] = array(
					'content' => $aApproveInfo['content']['name']['content'],
					'pass_time' => -1
				);
			}

			if($aTmpApproveInfo['profilePass'] == 0 && isset($aApproveInfo['content']['profile'])){
				//头像不处理
				$aSaveApproveInfo['content']['profile'] = $aApproveInfo['content']['profile'];
			}else if($aTmpApproveInfo['profilePass'] == 1){
				//头像通审
				$aPersonalData['profile'] = str_replace('_approve', '', $aApproveInfo['content']['profile']['content']);
				$aSaveApproveInfo['content']['profile'] = array(
					'content' => $aApproveInfo['content']['profile']['content'],
					'pass_time' => time()
				);
				$tmpFilePath = SYSTEM_RESOURCE_PATH . $aPersonalInfo['profile'];
				if(is_file($tmpFilePath) && file_exists($tmpFilePath) && is_writable($tmpFilePath)){
					unlink($tmpFilePath);
				}else{
					if($aPersonalInfo['profile']){
						myLog('审核后用户源头像删除失败:' . $aPersonalInfo['profile']);
					}
				}
			}else if($aTmpApproveInfo['profilePass'] == 2){
				//头像不通审
				$aSaveApproveInfo['content']['profile'] = array(
					'content' => $aApproveInfo['content']['profile']['content'],
					'pass_time' => -1,
				);
			}

			//更新PERSONAL表
			if(isset($aPersonalData['name']) || isset($aPersonalData['profile'])){
				if($oUser->setUserInfo($aPersonalData) === false){
					myLog('更新ID为:' . $approveUserId . ' 的会员头像地址失败');
					alert('更新ID为:' . $approveUserId . ' 的会员头像地址失败', 0);
				}
			}
			if($aTmpApproveInfo['profilePass'] == 1 && file_exists(SYSTEM_RESOURCE_PATH . $aApproveInfo['content']['profile']['content'])	){
				//头像通过　要重命名文件
				$renameResult = rename(SYSTEM_RESOURCE_PATH . $aApproveInfo['content']['profile']['content'], SYSTEM_RESOURCE_PATH . str_replace('_approve', '', $aApproveInfo['content']['profile']['content']));
				if(!$renameResult){
					myLog('ID为:' . $approveUserId . ' 的会员在审核图像时图像重命名失败');
					alert('ID为:' . $approveUserId . ' 的会员在审核图像时图像重命名失败', 0);
				}
			}

			//更新APPROVE表
			if($aSaveApproveInfo['content']){
				$aSaveApproveInfo['approve_finish'] = 1;
				if(isset($aSaveApproveInfo['content']['name']) && $aSaveApproveInfo['content']['name']['pass_time'] == 0){
					$aSaveApproveInfo['approve_finish'] = 0;
				}
				if(isset($aSaveApproveInfo['content']['profile']) && $aSaveApproveInfo['content']['profile']['pass_time'] == 0){
					$aSaveApproveInfo['approve_finish'] = 0;
				}
				$approveResult = $oUser->setUserInfoApprove($aSaveApproveInfo);
				if($approveResult === false){
					myLog('ID为:' . $approveUserId . ' 的会员更新审核数据时操作失败');
					alert('ID为:' . $approveUserId . ' 的会员更新审核数据时操作失败', 0);
				}
			}

			//更新user审核状态字段
			$aData2 = array();
			$aData2['id'] = $approveUserId;
			$aData2['approve_status'] = 0;
			$oUser->setUserIndexInfo($aData2);
		}
		alert('操作成功', 1);
	}

	//获取教师用户
	public function showTeacherList(){
		tipsNewManage();
		$page = intval(get('page', 1));
		$pageSize = 20;
		$aWhere = array();
		$provinceId = intval(get('provinceId',440000));
		$cityId = intval(get('cityId',0));
		$districtId = intval(get('district_id',0));
		$cityIds = 0;
		$startTime = get('start_time','2013-01-01 00:00:00');
		$endTime = get('end_time',date('Y-m-d H:i:s'));
		$searchUserName = get('user_name','');
		$searchId = get('user_id','');
		$schoolId = intval(get('school_id',0));

		if(get('search')){
			$userId = intval(get('user_id'));
			$userNmae = get('user_name');
			if($provinceId && $cityId){
				$xxtCity = $GLOBALS['XXT_CITY'];
				//目前只有广东的
				foreach ($xxtCity as $k => $aCity){
					if($aCity['city_id'] == $cityId && $provinceId == $aCity['province_id']){
						$cityIds = $k;
					}else if($cityId == 11000000){
						$cityIds = 11000000;
					}
				}
			}else{
				$cityIds = 0;
			}
			$aWhere = array(
				'city_id' => $cityIds,
				'uf_id' => $userId,
				'name' => $userNmae,
				'start_time' =>strtotime($startTime),
				'end_time' =>  strtotime($endTime),
			);
			if($schoolId){
				$aWhere['schoolId'] = $schoolId;
			}
		}

		$oTeacher = m('Teacher');
		$aTeacherList = $oTeacher->getXxtTeacherList($page, $pageSize, $aWhere);
		if($aTeacherList === false){
			alert('系统错误', 0);
		}
		foreach ($aTeacherList as $k => $aTeacher) {
			$aTeacherList[$k]['create_time'] = date('Y-m-d H:i:s',$aTeacher['create_time']);
			$oArea = new Model(T_AREA);
			$aArea = $oArea->get('`name`', '`id`=' . $aTeacher['city_id']);
			if($aArea){
				$aTeacherList[$k]['city_id'] = $aArea[0]['name'];
			}else{
				$aTeacherList[$k]['city_id'] = $this->_convertCity($aTeacher['city_id']);
			}
		}
		assign('aTeacherList', $aTeacherList);

		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$aTeacherCount = $oTeacher->getXxtTeacherCount($aWhere);
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aTeacherCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('tatolNum',$aTeacherCount);
		assign('pageHtml', $pageHtml);
		assign('searchUserName', $searchUserName);
		assign('searchId', $searchId);
		assign('provinceId', $provinceId);
		assign('cityId', $cityId);
		assign('districtId', $districtId);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		assign('schoolId', $schoolId);

		displayHeader();
		display('user/teacher_list.html.php');
		displayFooter();
	}

	//获取家长用户
	public function showParentList(){
		tipsNewManage();
		$page = intval(get('page', 1));
		$pageSize = 20;
		$aWhere = array();
		$provinceId = intval(get('provinceId',440000));
		$cityId = intval(get('cityId',0));
		$cityIds = $cityId;
		$startTime = get('start_time','2013-01-01 00:00:00');
		$endTime = get('end_time',date('Y-m-d H:i:s'));
		$searchUserName = get('user_name','');
		$searchId = get('user_id','');
		if(get('search')){
			$userId = intval(get('user_id'));
			$userNmae = get('user_name');
			if($provinceId && $cityId){
				$xxtCity = $GLOBALS['XXT_CITY'];
				//目前只有广东的
				foreach ($xxtCity as $k => $aCity){
					if($aCity['city_id'] == $cityId && $provinceId == $aCity['province_id']){
						$cityIds = $k;
					//处理未知城市标志的情况
					}else if($cityId == 11000000){
						$cityIds = 11000000;
					}
				}
			}
			$aWhere = array(
				'city_id' => $cityIds,
				'uf_id' => $userId,
				'name' => $userNmae,
				'start_time' =>strtotime($startTime),
				'end_time' =>  strtotime($endTime),
			);
		}

		$oParent = m('Parent');
		$aParentList = $oParent->getXxtParentList($page, $pageSize, $aWhere);
		if($aParentList === false){
			alert('系统错误', 0);
		}
		foreach ($aParentList as $k => $aParen) {
			$aParentList[$k]['create_time'] = date('Y-m-d H:i:s',$aParen['create_time']);
			$aParentList[$k]['city_id'] = $this->_convertCity($aParen['city_id']);
		}
		assign('aParentList', $aParentList);

		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$aParentCount = $oParent->getXxtParentCount($aWhere);
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aParentCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('tatolNum',$aParentCount);
		assign('pageHtml', $pageHtml);
		assign('searchUserName', $searchUserName);
		assign('searchId', $searchId);
		assign('startTime', $startTime);
		assign('endTime', $endTime);
		assign('provinceId', $provinceId);
		assign('cityId', $cityId);
		displayHeader();
		display('user/parent_list.html.php');
		displayFooter();
	}
	private function _convertCity($city){
		if(array_key_exists($city,$GLOBALS['XXT_CITY_CONVERT_NAME'])){
			return $GLOBALS['XXT_CITY_CONVERT_NAME'][$city];
		}
		return '未知';
	}

	public function getUserGold(){
		$userId = intval(post('id'));
		$page = intval(post('page', 1));
		$pageSize = 50;
		if(!$userId){
			alert('参数有误', 0);
		}

		$mUser = m('UserNumerical');
		$aUserGoldLogList = $mUser->getUserGoldRecordList($page, $pageSize, $userId);
		if($aUserGoldLogList === false){
			alert('系统错误!', 0);
		}
		$countUserGoldLog = $mUser->getUserGoldRecordCount($userId);
		if($countUserGoldLog === false){
			alert('系统错误!', 0);
		}

		$aUserGoldLogListAndCount = array(
			'aGoldLogList' => $aUserGoldLogList,
			'pageNumber' => ceil($countUserGoldLog / $pageSize)
		);
		unset($aUserGoldLogList);
		unset($countUserGoldLog);

		alert('加载成功', 1, $aUserGoldLogListAndCount);
	}
}