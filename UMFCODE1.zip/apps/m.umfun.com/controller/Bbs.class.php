<?php
class BbsController{
	private $_permissionConfig = 'manage_bbs_config';
	private $_permissionThread = 'manage_bbs_thread';
	private $_permissionComment = 'manage_bbs_comment';
	private $_userId = 0;

	public function __construct(){
		tipsNewManage();
		$this->_userId = checkLogin();
	}

	//配置
	public function config(){
		if(!checkPermission($this->_userId, $this->_permissionConfig)){
			alert('抱歉，您的权限不足！', 0);
		}
		$aCategory = m('Bbs')->getCategoryList(1, 0);
		assign('aCategory', $aCategory);
		displayHeader();
		display('bbs/config.html.php');
		displayFooter();
	}

	//保存配置
	public function setConfig(){
		$hot = intval(post('bbsHot'));
		$defultChannel = intval(post('defultChannel'));
		if(!$hot || !$defultChannel){
			alert('请仔细填写', 0);
		}

		$option = '	\'hot\' => ' . $hot . ',' . PHP_EOL . '	\'defult_channel\' => ' . $defultChannel;
		$size = file_put_contents(SYSTEM_ROOT_PATH . 'apps/config/bbs.config.php', '<?php' . PHP_EOL . '$GLOBALS[\'BBS\'] = array(' . PHP_EOL . $option . PHP_EOL . ');');
		if($size){
			alert('设置成功');
		}else{
			alert('设置成功, 0');
		}
	}

	//板块列表
	public function category(){
		if(!checkPermission($this->_userId, $this->_permissionConfig)){
			alert('抱歉，您的权限不足！', 0);
		}

		$aCategory = m('Bbs')->getCategoryList(1, 0, array(
			'status' => 0,
			'order' => '`id` desc'
			));
		assign('aCategory', $aCategory);

		displayHeader();
		display('bbs/category.html.php');
		displayFooter();
	}

	public function showTypeList(){
		$oBbs = m('Bbs');
		$aTypeList = $oBbs->getTypeList('`id`>0', 1, 100);
		assign('aTypeList', $aTypeList);

		$aCateList = $oBbs->getCategoryList(1, 100, array('status' => 0, 'order' => '`order` ASC'));
		assign('aCateList', $aCateList);
		display('bbs/type_list.html.php');
	}

	public function addType(){
		$name = post('name');
		$category = intval(post('category'));
		$order = intval(post('order'));
		if(!$name || !$category){
			alert('请填写分类名称和所属板块', -1);
		}
		$oBbs = m('Bbs');
		$aData = array(
			'name' => $name,
			'category_id' => $category,
			'order' => $order,
			'create_time' => time(),
		);
		if($oBbs->addType($aData)){
			alert('算你成功添加咯', 1);
		}else{
			alert('失败', 0);
		}
	}

	public function saveType(){
		$id = intval(post('id'));
		$name = post('name');
		$category = intval(post('category'));
		$order = intval(post('order'));
		if(!$name || !$category){
			alert('请填写分类名称和所属板块', -1);
		}
		if(!$id){
			alert('分类不存在', -1);
		}
		$oBbs = m('Bbs');
		$aData = array(
			'id' => $id,
			'name' => $name,
			'category_id' => $category,
			'order' => $order,
		);
		$result = $oBbs->setType($aData);
		if($result !== false){
			alert('修改成功', 1);
		}else{
			alert('修改失败', 0);
		}
	}

	public function delType(){
		$id = intval(post('id'));
		$oBbs = m('Bbs');
		if($oBbs->delType($id)){
			alert('删除成功', 1);
		}else{
			alert('删除失败', 0);
		}
	}

	public function getTypeInfo(){
		$id = intval(get('id'));
		$oBbs = m('Bbs');
		$aType = $oBbs->getTypeById($id);
		alert('OK', 1, $aType);
	}

	public function getThreadInfo(){
		$id = intval(get('id'));
		$oBbs = m('Bbs');
		$aThread = $oBbs->getThreadInfoById($id);
		alert('OK', 1, $aThread);
	}


	//保存板块列表
	public function saveCategory(){
		$type = intval(get('type', 0));
		$id = intval(post('CategoryId', 0));
		$categoryName = post('CategoryName', '');
		$categoryKeywords = post('CategoryKeywords', '');
		$categoryDescript = post('CategoryDescript', '');
		$categoryOrder = intval(post('CategoryOrder', 0));
		$categoryDescription = post('CategoryDescription', '');
		$categoryIsOpen = intval(post('CategoryIsOpen', 0));

		if(strlen($categoryName) < 6){
			alert('板块名称太短了', -1);
		}
		if($categoryIsOpen != 1 && $categoryIsOpen != 2){
			alert('请选择正确的状态', -1);
		}

		$aCategoryInfo = array(
			'name' => $categoryName,
			'keywords' => $categoryKeywords,
			'descript' => $categoryDescript,
			'description' => $categoryDescription,
			'order' => $categoryOrder ,
			'status' => $categoryIsOpen
		);

		$oBbs = m('Bbs');
		if($type == 1){
			$aCategoryInfo['create_time'] = time();
			$result = $oBbs->addCategory($aCategoryInfo);
		}else if($type == 2){
			if(!$id || !$oBbs->getCategoryInfoById($id)){
				alert('很抱歉，ID错误', -1);
			}
			$aCategoryInfo['id'] = $id;
			$result = $oBbs->setCategory($aCategoryInfo);
		}else{
			alert('感觉我们似乎要好好谈谈', 0);
		}
		if(!$result){
			alert('操作失败', 0);
		}
		alert('操作成功', 1, $result);
	}

	//读取板块信息
	public function getCategoryInfo(){
		$id = intval(get('id', 0));
		if(!$id){
			alert('id错误', -1);
		}

		$aCategoryInfo = m('Bbs')->getCategoryInfoById($id);
		if($aCategoryInfo  === false){
			alert('系统错误', 0);
		}else if(!$aCategoryInfo){
			alert('没有这个板块', -1);
		}
		alert('成功', 1, $aCategoryInfo);
	}

	//删除板块
	public function delCategory(){
		$id = intval(post('id', 0));
		if(!$id){
			alert('id错误' . $id, -1);
		}

		$result = 1;
		//$result = m('Bbs')->delCategoryById($id);
		if($result === false){
			alert('系统错误', 0);
		}else if(!$result){
			alert('找不到这个板块', 0);
		}
		alert('成功', 1, $result);
	}

	//帖子列表
	public function showThreadList(){
		if(!checkPermission($this->_userId, $this->_permissionThread)){
			alert('抱歉，您的权限不足！', 0);
		}

		$threadIds = get('threadIds', '');
		$userId = intval(get('userId', 0));
		$read = intval(get('read', 0));
		$support = intval(get('support', 0));
		$creat_start_time = strtotime(get('creat_start_time', 0));
		$creat_end_time = strtotime(get('creat_end_time', 0));
		$real_start_time = strtotime(get('real_start_time', 0));
		$real_end_time = strtotime(get('real_end_time', 0));
		$isTop = intval(get('isTop', -1));
		$categoryId = intval(get('categoryId', 0));
		$recommend = intval(get('isRecommend', -1));
		$order = intval(get('order', 0));
		$status = intval(get('status', 0));

		$page = intval(get('page', 1));
		$pageSize = 20;

		//帖子列表
		$aThreadCondition = array(
			'category_id'			=> $categoryId,
			'is_recommend'			=> $recommend,
			'is_top'				=> $isTop,
			'statu'					=> $status,
			'user_id'				=> $userId,
			'get_category_name'		=> 1,
			'ids'					=> $threadIds,
			'limit_read_times'		=> $read,
			'create_time_max'		=> $creat_start_time,
			'create_time_min'		=> $creat_end_time,
			'last_reply_time_max'	=> $real_start_time,
			'last_reply_time_min'	=> $real_end_time
		);
		$aFormatOrder = array(
			0 => '`create_time` DESC',
			1 => '`create_time` DESC',
			2 => '`last_reply_time` DESC',
			3 => '`support_times` DESC',
			4 => '`read_times` DESC',
		);
		$oBbs = m('Bbs');
		$aThreadList = $oBbs->getThreadList($page, $pageSize, $aThreadCondition, $aFormatOrder[$order]);
		if($aThreadList === false){
			alert('系统错误', 0);
		}
		assign('aThreadList', $aThreadList);

		//帖子统计
		$aThreadCount = $oBbs->getThreadCount($aThreadCondition);
		if($page > ceil($aThreadCount / $pageSize)){
			$page = 1;
		}

		//帖子列表分页
		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aThreadCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);

		//板块列表
		$aCategoryCondition = array(
			 'statu' => 1,
			 'order' => '`order` ASC'
		 );
		$aCategoryList = m('Bbs')->getCategoryList(1, 0, $aCategoryCondition);
		if($aCategoryList === false){
			alert('系统错误', 0);
		}
		assign('aCategoryList', $aCategoryList);

		$aClassList = m('Bbs')->getTypeList('`id`>0', 1, 30);
		assign('aClassList', $aClassList);

		displayHeader();
		display('bbs/thread.html.php');
		displayFooter();
	}

	//设置置顶与推荐，含取消
	public function setThreadState(){
		$id = intval(post('id', 0));
		$type = intval(post('type', 0));
		$setType = intval(post('setType', 0));
		if(!$id || !$type || ($type != 1 && $type != 2) || !$setType || ($setType != 1 && $setType != 2)){
			alert('不是有效参数', 0);
		}
		$oBbs = m('Bbs');
		$checkId = $oBbs->getThreadInfoById($id);
		if($checkId === false || !$checkId){
			alert('不存在的ID', 0);
		}

		$aState = array('id' => $id);

		if($setType == 1){
			if($type == 1){
				$aState['is_top'] = 1;
			}else if($type == 2){
				$aState['is_top'] = 0;
			}
		}
		if($setType == 2){
			if($type == 1){
				$aState['is_recommend'] = 1;
			}else if($type == 2){
				$aState['is_recommend'] = 0;
			}
		}

		if($oBbs->setThread($aState)){
			//新版话题加精加事件
			if(isset($aState['is_recommend']) && $aState['is_recommend']){
				$aEventData = array(
					'user_id'	=>	$checkId['user_id'],
					'type'		=> 35,
					'data_id'	=>	$id,
					'data'		=>	array(
						'gold' => 0,
						'create_time' => time()
					)
				);
				$oSnsEvent = m('SnsEvent');
				$oSnsEvent->addEvent($aEventData);
			}
			alert('成功', 1);
		}else{
			alert('失败', -1);
		}

	}

	public function setThreadCate(){
		$cate = intval(post('category'));
		$id = intval(post('id'));
		$classifyId = intval(post('classify_id'));
		$oBbs = m('Bbs');
		$aData = array('id' => $id, 'category_id'=>$cate, 'classify_id'=>$classifyId);
		$result = $oBbs->setThread($aData);
		if($result !== false){
			alert('成功', 1);
		}else{
			alert('失败', -1);
		}
	}

	//评论列表
	public function showCommentList(){
		if(!checkPermission($this->_userId, $this->_permissionComment)){
			alert('抱歉，您的权限不足！', 0);
		}

		$page = intval(get('page', 1));
		$pageSize = 20;

		$oBbs = m('Bbs');
		$aCommentTemp =$oBbs->getCommentListByThreadId('', $page, $pageSize, '`create_time` DESC');
		if($aCommentTemp === false){
			alert('系统错误', 0);
		}

		$aComment = array();
		foreach($aCommentTemp as $key => $aCommentValue){
			$aParentInfo = $aCommentValue['parent_id'] ? $aCommentValue['parent_info'] : array();
			$aComment[$key] = array(
				'id' => $aCommentValue['id'],
				'thread_id' => $aCommentValue['thread_id'],
				'parent_id' => $aCommentValue['parent_id'],
				'user_id' => $aCommentValue['user_id'],
				'user_info' => $aCommentValue['user_info'],
				'support_times' => $aCommentValue['support_times'],
				'create_time' => $aCommentValue['create_time'],
				'content' => $aCommentValue['content'],
				'resource_list' => $aCommentValue['resource_list'],
				'parent_info' => $aParentInfo
			);
		}
		unset($aCommentTemp);
		assign('aComment', $aComment);

		//统计
		$countComment = $oBbs->getCommentCountByThreadId();
		if($page > ceil($countComment / $pageSize)){
			$page = 1;
		}

		//分页
		$url = 'http://' . APP_MANAGE . $_SERVER['REQUEST_URI'];
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $countComment,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		$pageHtml = page($aPageInfo);
		assign('pageHtml', $pageHtml);

		displayHeader();
		display('bbs/comment.html.php');
		displayFooter();
	}


	//删除帖子或评论操作
	public function delete(){
		$id = intval(post('id', 0));
		$type = intval(post('type', 0));
		if(!$type && !$id || ($type != 1 && $type != 2)){
			alert('非法操作', -1);
		}
		$oBbs = m('Bbs');
		$status = 0;
		if($type == 1){
			$status = $oBbs->deleteThreadById($id);
		}else if($type == 2){
			$status = $oBbs->deleteComment($id);
		}else{
			alert('请勿非法操作', -1);
		}
		$status ? alert('成功' , 1) : alert('失败', -1);
	}

	/**
	 *获取帖子列表
	 * @return array	获取帖子列表
	 **/
	private function _getThreadList($page = 1, $pageSize = 10, $categoryId = 0, $recommend = -1, $top = -1, $statu = 2, $categoryName = 1, $order = '', $userId = 0){
		//帖子列表
		$aThread = array();
		$aThreadCondition = array(
			'category_id'	=> $categoryId,
			'is_recommend'	=> $recommend,
			'is_top'		=> $top,
			'statu'			=> $statu,
			'user_id'		=> $userId,
			'get_category_name'	=> $categoryName
		);

		$aThread = m('Bbs')->getThreadList($page, $pageSize, $aThreadCondition, $order);
		if($aThread === false){
			return false;
		}
		return $aThread;
	}

}