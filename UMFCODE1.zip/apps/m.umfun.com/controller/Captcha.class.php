<?php
class CaptchaController{
	
	public function __construct(){}
	
	public function display(){
		$name = get('name', 'captcha');
		Verify::display($name);
	}
	
}

