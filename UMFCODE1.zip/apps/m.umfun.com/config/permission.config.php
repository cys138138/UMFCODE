<?php
//权限配置，兼左侧菜单栏结构
$GLOBALS['PERMISSION'] = array(
	array(
		'title' => '题库管理',
		'child' => array(
			'add_es' => array(
				'title' => '出题管理',
				'url' => '?m=EsCreate&a=showList',
			),
			'approve_es' => array(
				'title' => '审核管理',
				'url' => '?m=EsApprove&a=showList',
			),
			'manage_es' => array(
				'title' => '总编中心',
				'url' => '?m=ChiefEditor&a=showEsManage&auto_jump=1',
			),
			'manage_es_feedback' => array(
				'title' => '反馈管理',
				'url' => '?m=EsFeedback&a=showList',
			),
		),
	),
	array(
		'title' => '游戏管理',
		'child' => array(
			'manage_mission' => array(
				'title' => '关卡管理',
				'url' => '?m=Mission&a=showList',
			),
			'manage_match' => array(
				'title' => '赛事列表',
				'url' => '?m=Match&a=showMatchList',
			),
			'manage_es_comment' => array(
				'title' => '题目评论',
				'url' => '?m=EsComment&a=showList',
			),
			'manage_prop' => array(
				'title' => '道具管理',
				'url' => '?m=Prop&a=showList',
			),
			'manage_exchange' => array(
				'title' => '兑换商城',
				'url' => '?m=Exchange&a=showList',
			),
			'manage_raiders' => array(
				'title' => '夺宝管理',
				'url' => '?m=Raiders&a=showAwardList',
			),
			'manage_team' => array(
				'title' => '团队赛管理',
				'url' => '?m=Team&a=showPrizeList',
			),
			'manage_packet' => array(
				'title' => '红包活动',
				'url' => '?m=Packet&a=showJoinList',
			),
			'manage_activity' => array(
				'title' => '奖学金竞猜管理',
				'url' => '?m=Packet&a=showJoinList',
			),
		),
	),
	array(
		'title' => '用户管理',
		'child' => array(
			'manage_manager' => array(
				'title' => '后台用户管理',
				'url' => '?m=Account&a=showUserList',
			),
			'manage_permission' => array(
				'title' => '权限管理',
				'url' => '?m=Account&a=showPermissionList',
			),
			'manage_user' => array(
				'title' => '前台用户管理',
				'url' => '?m=User&a=showUserList',
			),
			'manage_user_parent' => array(
				'title' => '家长管理',
				'url' => '?m=User&a=showParentList',
			),
			'manage_user_teacher' => array(
				'title' => '教师管理',
				'url' => '?m=User&a=showTeacherList',
			),
			'manage_user' => array(
				'title' => '学校管理',
				'url' => '?m=School&a=showList',
			),
			'manage_public_user' => array(
				'title' => '公众号设置',
				'url' => '?m=System&a=showPublicUser',
			),
			'operate_student_data' => array(
				'title' => '操作学生数据',
				'url' => '?m=System&a=showPublicUser',
			),
			'manage_feedback' => array(
				'title' => '反馈管理',
				'url' => '?m=Service&a=showFeedBack',
			),
		),
	),
	array(
		'title' => 'U币管理',
		'child' => array(
			'manage_ub_card' => array(
				'title' => '充值卡管理',
				'url' => '?m=Card&a=showUbCardList',
			),
			'manage_ub_log' => array(
				'title' => '充值记录',
				'url' => '?m=Recharge&a=showRechargeList',
			),
		),
	),
	array(
		'title' => '系统管理',
		'child' => array(
			'system_base_option' => array(
				'title' => '基础设置',
				'url' => '?m=System&a=showBaseOption',
			),
			'style_management' => array(
				'title' => '皮肤管理',
				'url' => '?m=Style&a=showList',
			),
		),
	),
	array(
		'title' => '话题管理',
		'child' => array(
			'manage_bbs_config' => array(
				'title' => '话题配置',
				'url' => '?m=Bbs&a=config',
			),
			'manage_bbs_category' => array(
				'title' => '板块管理',
				'url' => '?m=Bbs&a=category',
			),
			'manage_bbs_thread' => array(
				'title' => '话题列表',
				'url' => '?m=Bbs&a=showThreadList',
			),
			'manage_bbs_comment' => array(
				'title' => '评论列表',
				'url' => '?m=Bbs&a=showCommentList',
			),
			'manage_bbs_type' => array(
				'title' => '分类列表',
				'url' => '?m=Bbs&a=showTypeList',
			),
		),
	),
	array(
		'title' => '内容管理',
		'child' => array(
			'manage_edu_news' => array(
				'title' => '教育资讯',
				'url' => '?m=EduNews&a=showList',
			),
		),
	),

);
