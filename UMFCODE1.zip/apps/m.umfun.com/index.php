<?php
$aTmpParams = $_GET;
require '../../rebuild/apps/home/web/index_old_framework.php';
Yii::$app->db->serverStatusCache = '';	//关闭主从服务器状态缓存
Yii::setAlias('r.css.error', '');
$_GET = $aTmpParams;

include_once PROJECT_PATH . '/config.php';

include_once SYSTEM_APPS_PATH . '/config.php';
include_once __DIR__ . '/config.php';
include_once __DIR__ . '/config/permission.config.php';
include_once SYSTEM_APPS_PATH . '/url.config.php';

abstract class APP{
	public static function start(){
		if(IS_URL_REWRITE){
			self::_urlParse($GLOBALS['URL'][APP_DOMAIN]);
			$GLOBALS['URL_'] = self::_urlRuleExchange($GLOBALS['URL']);
		}
		$m = trim(isset($_GET['m']) ? $_GET['m'] : (IS_URL_REWRITE ? '' : 'Index'));
		$a = trim(isset($_GET['a']) ? $_GET['a'] : (IS_URL_REWRITE ? '' : 'index'));
		$c = ucfirst($m) . 'Controller';
		$compilerFilePath = APP_COMPILER_PATH . $m . '__' . md5($m) . '.compiler.php';
		if(AUTO_COMPILER && is_file($compilerFilePath)){
			include_once $compilerFilePath;
		}else{
			$controllerFile = APP_CONTROLLER_PATH . $m . '.class.php';
			if(!is_file($controllerFile)){
				self::_http404();
			}
			$GLOBALS['COMPILER'] = '';
			self::_loadPath(SYSTEM_APPS_PATH . 'config/');
			self::_loadPath(SYSTEM_APPS_PATH . 'function/');
			include_once SYSTEM_BASE_CLASS;
			$appValidateConfigFile = dirname(dirname(__FILE__)) . '/validate.config.php';
			$appResourceConfigFile = dirname(dirname(__FILE__)) . '/resource.config.php';
			$appFunctionFile = dirname(dirname(__FILE__)) . '/function.php';
			$appControllerConstruct = APP_CONTROLLER_PATH . '/__construct.php';
			if(!AUTO_COMPILER){
				include_once $appValidateConfigFile;
				include_once $appResourceConfigFile;
				include_once $appFunctionFile;
				include_once $appControllerConstruct;
				include_once $controllerFile;
			}else{
				$GLOBALS['COMPILER'] .= $appValidateConfigFile . '||';
				$GLOBALS['COMPILER'] .= $appResourceConfigFile . '||';
				$GLOBALS['COMPILER'] .= $appFunctionFile . '||';
				$GLOBALS['COMPILER'] .= $appControllerConstruct . '||';
				$GLOBALS['COMPILER'] .= $controllerFile . '||';
				$mergeFiles=explode('||', trim($GLOBALS['COMPILER'], '||'));
				$compilerFileContent = '<?php ';
				foreach($mergeFiles as $file){
					$fileContent = trim(file_get_contents($file));
					$fileContent = substr($fileContent, 5);
					if ('?>' == substr($fileContent, -2)){
						$fileContent = substr($fileContent, 0, -2);
					}
					$compilerFileContent .= $fileContent;
				}
				file_put_contents($compilerFilePath, $compilerFileContent);
				unset($compilerFileContent);
				include_once $compilerFilePath;
			}
		}

 		if(class_exists($c)){
			$controller = new $c();
			if(method_exists($controller, $a)){
				$controller->$a();
			}else{
				self::_http404();
			}
		}else{
			self::_http404();
		}
	}

	private static function _urlParse($aRule){
		if(IS_URL_REWRITE){
			$activeUrlString = '';
			$staticUrlString = isset($_GET['__SQS']) ? $_GET['__SQS'] : '';
			unset($_GET['__SQS']);
			if($staticUrlString == ''){
				$activeUrlString = 'm=Index&a=index';
			}else{
				foreach($aRule as $key => $value){
					$matchResult = preg_replace('#' . $key . '#iU', $value, $staticUrlString);
					if($matchResult != $staticUrlString){
						$activeUrlString = $matchResult;
						break;
						echo '<br>' . $activeUrlString . '<br>';
					}
				}
				if(empty($activeUrlString)){
					$activeUrlString = $staticUrlString;
				}
			}
			$aParams = array();
			parse_str($activeUrlString, $aParams);
			if(empty($aParams)){
				return false;
			}else{
				$_GET = array_merge($aParams, $_GET);
				return $activeUrlString;
			}
		}
	}


	private static function _urlRuleExchange($aRules){
		$aRuleExchangeds = array();
		foreach($aRules as $aKey => $aValue){
			$aRule = $aValue;
			$aRuleExchanged = array();
			foreach($aRule as $key => $value){
				$reg = '#\(.*\)#iU';
				$matchCount = 0;
				$aMatchResult = array();
				$matchCount = preg_match_all($reg, $key, $aMatchResult);
				if(!$matchCount){
					$tmpKey = $value;
					$tmpValue = $key;
					if(substr($tmpValue, 0, 1) == '^'){
						$tmpKey = '^' . $tmpKey;
						$tmpValue = ltrim($tmpValue, '^');
					}
					if(substr($tmpValue, -1) == '$'){
						$tmpKey = $tmpKey . '$';
						$tmpValue = rtrim($tmpValue, '$');
					}
				}else{
					$aMatchResult = $aMatchResult[0];
					$aPartern = array();
					for ($i = 0; $i < count($aMatchResult); $i++){
						$aPartern[] = '$' . ($i + 1);
					}
					$tmpKey = str_replace($aPartern, $aMatchResult, $value);
					$tmpValue = $key;
					foreach($aMatchResult as $k => $v){
						$replacedLength = strlen($v);
						$replacedPosition = strpos($tmpValue, $v);
						$leftStr = substr($tmpValue, 0, $replacedPosition);
						$righttStr = substr($tmpValue, $replacedPosition + $replacedLength);
						$tmpValue = $leftStr . $aPartern[$k] . $righttStr;
					}
					if(substr($tmpValue, 0, 1) == '^'){
						$tmpKey = '^' . $tmpKey;
						$tmpValue = ltrim($tmpValue, '^');
					}
					if(substr($tmpValue, -1) == '$'){
						$tmpKey = $tmpKey . '$';
						$tmpValue = rtrim($tmpValue, '$');
					}
				}
				if(!isset($aRuleExchanged[$tmpKey])){
					$aRuleExchanged[$tmpKey] = $tmpValue;
				}
			}
			$aRuleExchangeds[$aKey] = $aRuleExchanged;
		}
		return $aRuleExchangeds;
	}

	private static function _http404(){
		header('HTTP/1.1 404 Not Found');
		include_once dirname(dirname(__FILE__)) . '/404.html';
		exit();
	}

	private static function _loadPath($path){
		$pathHandle = opendir($path);
		while($file = readdir($pathHandle)){
			if($file != '.' && $file != '..'){
				if(substr(strrchr($file, '.'), 1) == 'php'){
					$incldeFile = $path . $file;
					if(!AUTO_COMPILER){
						include_once $incldeFile;
					}else{
						$GLOBALS['COMPILER'] .= $incldeFile . '||';
					}
				}
			}
		}
	}
}

APP::start();
