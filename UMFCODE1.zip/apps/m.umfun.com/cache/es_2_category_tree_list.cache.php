<?php return array (
  0 => 
  array (
    'id' => '1205',
    'parent_id' => '1204',
    'subject_id' => '2',
    'name' => '第一章	有理数',
    'orders' => '1',
  ),
  1 => 
  array (
    'id' => '1143',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第一单元  位置',
    'orders' => '1',
  ),
  2 => 
  array (
    'id' => '1178',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '第一单元  负数',
    'orders' => '1',
  ),
  3 => 
  array (
    'id' => '1098',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第一单元  图形的变换	',
    'orders' => '1',
  ),
  4 => 
  array (
    'id' => '1052',
    'parent_id' => '1051',
    'subject_id' => '2',
    'name' => '1.1小数乘整数',
    'orders' => '1',
  ),
  5 => 
  array (
    'id' => '1317',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '第十六章 二次根式',
    'orders' => '1',
  ),
  6 => 
  array (
    'id' => '1347',
    'parent_id' => '1346',
    'subject_id' => '2',
    'name' => '第二十六章 二次函数',
    'orders' => '1',
  ),
  7 => 
  array (
    'id' => '1391',
    'parent_id' => '1390',
    'subject_id' => '2',
    'name' => '19.1函数',
    'orders' => '1',
  ),
  8 => 
  array (
    'id' => '1373',
    'parent_id' => '1143',
    'subject_id' => '2',
    'name' => '第一单元  位置	',
    'orders' => '1',
  ),
  9 => 
  array (
    'id' => '1376',
    'parent_id' => '1178',
    'subject_id' => '2',
    'name' => '第一单元  负数',
    'orders' => '1',
  ),
  10 => 
  array (
    'id' => '1395',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '第九年级备份',
    'orders' => '1',
  ),
  11 => 
  array (
    'id' => '2578',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '六年级小升出测试',
    'orders' => '1',
  ),
  12 => 
  array (
    'id' => '2579',
    'parent_id' => '2578',
    'subject_id' => '2',
    'name' => '易',
    'orders' => '1',
  ),
  13 => 
  array (
    'id' => '2580',
    'parent_id' => '2578',
    'subject_id' => '2',
    'name' => '中',
    'orders' => '1',
  ),
  14 => 
  array (
    'id' => '2581',
    'parent_id' => '2578',
    'subject_id' => '2',
    'name' => '难',
    'orders' => '1',
  ),
  15 => 
  array (
    'id' => '1051',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第一单元 小数乘法',
    'orders' => '1',
  ),
  16 => 
  array (
    'id' => '1266',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '第十一章三角形　',
    'orders' => '1',
  ),
  17 => 
  array (
    'id' => '1249',
    'parent_id' => '1248',
    'subject_id' => '2',
    'name' => '8.1二元一次方程组',
    'orders' => '1',
  ),
  18 => 
  array (
    'id' => '1231',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '第五章 相交线与平行线',
    'orders' => '1',
  ),
  19 => 
  array (
    'id' => '1277',
    'parent_id' => '1276',
    'subject_id' => '2',
    'name' => '13.1 轴对称',
    'orders' => '1',
  ),
  20 => 
  array (
    'id' => '1050',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版五年级上册',
    'orders' => '1',
  ),
  21 => 
  array (
    'id' => '1049',
    'parent_id' => '0',
    'subject_id' => '2',
    'name' => '数学总目录',
    'orders' => '1',
  ),
  22 => 
  array (
    'id' => '1296',
    'parent_id' => '1295',
    'subject_id' => '2',
    'name' => '17.1反比例函数',
    'orders' => '2',
  ),
  23 => 
  array (
    'id' => '1267',
    'parent_id' => '1266',
    'subject_id' => '2',
    'name' => '11.1 与三角形有关的线段',
    'orders' => '2',
  ),
  24 => 
  array (
    'id' => '1232',
    'parent_id' => '1231',
    'subject_id' => '2',
    'name' => '5.1相交线',
    'orders' => '2',
  ),
  25 => 
  array (
    'id' => '1299',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '第十七章 勾股定理',
    'orders' => '2',
  ),
  26 => 
  array (
    'id' => '1392',
    'parent_id' => '1390',
    'subject_id' => '2',
    'name' => '19.2一次函数',
    'orders' => '2',
  ),
  27 => 
  array (
    'id' => '1144',
    'parent_id' => '1143',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '2',
  ),
  28 => 
  array (
    'id' => '1179',
    'parent_id' => '1178',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '2',
  ),
  29 => 
  array (
    'id' => '1206',
    'parent_id' => '1205',
    'subject_id' => '2',
    'name' => '1.1正数和负数',
    'orders' => '2',
  ),
  30 => 
  array (
    'id' => '1348',
    'parent_id' => '1347',
    'subject_id' => '2',
    'name' => '26.1二次函数及其图象',
    'orders' => '2',
  ),
  31 => 
  array (
    'id' => '1349',
    'parent_id' => '1347',
    'subject_id' => '2',
    'name' => '26.2用函数观点看一元二次方程',
    'orders' => '2',
  ),
  32 => 
  array (
    'id' => '1318',
    'parent_id' => '1317',
    'subject_id' => '2',
    'name' => '16.1二次根式',
    'orders' => '2',
  ),
  33 => 
  array (
    'id' => '1099',
    'parent_id' => '1098',
    'subject_id' => '2',
    'name' => '1.1轴对称	',
    'orders' => '2',
  ),
  34 => 
  array (
    'id' => '1053',
    'parent_id' => '1051',
    'subject_id' => '2',
    'name' => '1.2小数乘小数',
    'orders' => '2',
  ),
  35 => 
  array (
    'id' => '1097',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版五年级下册',
    'orders' => '2',
  ),
  36 => 
  array (
    'id' => '1100',
    'parent_id' => '1098',
    'subject_id' => '2',
    'name' => '1.2旋转与欣赏设计',
    'orders' => '3',
  ),
  37 => 
  array (
    'id' => '1054',
    'parent_id' => '1051',
    'subject_id' => '2',
    'name' => '1.3积的近似数',
    'orders' => '3',
  ),
  38 => 
  array (
    'id' => '1319',
    'parent_id' => '1317',
    'subject_id' => '2',
    'name' => '16.2二次根式的乘除',
    'orders' => '3',
  ),
  39 => 
  array (
    'id' => '1268',
    'parent_id' => '1266',
    'subject_id' => '2',
    'name' => '11.2 与三角形有关的角',
    'orders' => '3',
  ),
  40 => 
  array (
    'id' => '1297',
    'parent_id' => '1295',
    'subject_id' => '2',
    'name' => '17.2实际问题与反比例函数',
    'orders' => '3',
  ),
  41 => 
  array (
    'id' => '1233',
    'parent_id' => '1231',
    'subject_id' => '2',
    'name' => '5.2平行线及其判定',
    'orders' => '3',
  ),
  42 => 
  array (
    'id' => '1207',
    'parent_id' => '1205',
    'subject_id' => '2',
    'name' => '1.2有理数',
    'orders' => '3',
  ),
  43 => 
  array (
    'id' => '1180',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '第二单元  圆柱与圆锥',
    'orders' => '3',
  ),
  44 => 
  array (
    'id' => '1145',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第二单元  分数乘法',
    'orders' => '3',
  ),
  45 => 
  array (
    'id' => '1142',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版六年级上册',
    'orders' => '3',
  ),
  46 => 
  array (
    'id' => '1146',
    'parent_id' => '1145',
    'subject_id' => '2',
    'name' => '2.1分数乘法',
    'orders' => '4',
  ),
  47 => 
  array (
    'id' => '1208',
    'parent_id' => '1205',
    'subject_id' => '2',
    'name' => '1.3有理数的加减法',
    'orders' => '4',
  ),
  48 => 
  array (
    'id' => '1177',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版六年级下册',
    'orders' => '4',
  ),
  49 => 
  array (
    'id' => '1181',
    'parent_id' => '1180',
    'subject_id' => '2',
    'name' => '2.1圆柱',
    'orders' => '4',
  ),
  50 => 
  array (
    'id' => '1269',
    'parent_id' => '1266',
    'subject_id' => '2',
    'name' => '11.3 多边形及其内角和',
    'orders' => '4',
  ),
  51 => 
  array (
    'id' => '1234',
    'parent_id' => '1231',
    'subject_id' => '2',
    'name' => '5.3平行线的性质',
    'orders' => '4',
  ),
  52 => 
  array (
    'id' => '1298',
    'parent_id' => '1295',
    'subject_id' => '2',
    'name' => '第十七章检测',
    'orders' => '4',
  ),
  53 => 
  array (
    'id' => '1101',
    'parent_id' => '1098',
    'subject_id' => '2',
    'name' => '第一单元检测	',
    'orders' => '4',
  ),
  54 => 
  array (
    'id' => '1055',
    'parent_id' => '1051',
    'subject_id' => '2',
    'name' => '1.4	连乘、乘加、乘减',
    'orders' => '4',
  ),
  55 => 
  array (
    'id' => '1320',
    'parent_id' => '1317',
    'subject_id' => '2',
    'name' => '16.3二次根式的加减',
    'orders' => '4',
  ),
  56 => 
  array (
    'id' => '1350',
    'parent_id' => '1347',
    'subject_id' => '2',
    'name' => '26.3实际问题与二次函数',
    'orders' => '4',
  ),
  57 => 
  array (
    'id' => '1300',
    'parent_id' => '1299',
    'subject_id' => '2',
    'name' => '17.1勾股定理',
    'orders' => '5',
  ),
  58 => 
  array (
    'id' => '1351',
    'parent_id' => '1347',
    'subject_id' => '2',
    'name' => '第二十六章检测',
    'orders' => '5',
  ),
  59 => 
  array (
    'id' => '1321',
    'parent_id' => '1317',
    'subject_id' => '2',
    'name' => '第十六章检测',
    'orders' => '5',
  ),
  60 => 
  array (
    'id' => '1056',
    'parent_id' => '1051',
    'subject_id' => '2',
    'name' => '1.5	整数乘法运算定律推广到小数',
    'orders' => '5',
  ),
  61 => 
  array (
    'id' => '1102',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第二单元  因数与倍数',
    'orders' => '5',
  ),
  62 => 
  array (
    'id' => '1209',
    'parent_id' => '1205',
    'subject_id' => '2',
    'name' => '1.4有理数的乘除法',
    'orders' => '5',
  ),
  63 => 
  array (
    'id' => '1182',
    'parent_id' => '1180',
    'subject_id' => '2',
    'name' => '2.2圆锥',
    'orders' => '5',
  ),
  64 => 
  array (
    'id' => '1204',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版七年级上册',
    'orders' => '5',
  ),
  65 => 
  array (
    'id' => '1147',
    'parent_id' => '1145',
    'subject_id' => '2',
    'name' => '2.2解决问题',
    'orders' => '5',
  ),
  66 => 
  array (
    'id' => '1235',
    'parent_id' => '1231',
    'subject_id' => '2',
    'name' => '5.4平移',
    'orders' => '5',
  ),
  67 => 
  array (
    'id' => '1270',
    'parent_id' => '1266',
    'subject_id' => '2',
    'name' => '第十一章检测',
    'orders' => '5',
  ),
  68 => 
  array (
    'id' => '1393',
    'parent_id' => '1390',
    'subject_id' => '2',
    'name' => '19.3课题学习 选择方案',
    'orders' => '5',
  ),
  69 => 
  array (
    'id' => '1440',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '5',
  ),
  70 => 
  array (
    'id' => '1394',
    'parent_id' => '1390',
    'subject_id' => '2',
    'name' => '第十九章检测',
    'orders' => '6',
  ),
  71 => 
  array (
    'id' => '1230',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版七年级下册',
    'orders' => '6',
  ),
  72 => 
  array (
    'id' => '1236',
    'parent_id' => '1231',
    'subject_id' => '2',
    'name' => '第五章检测',
    'orders' => '6',
  ),
  73 => 
  array (
    'id' => '1271',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '第十二章  全等三角形',
    'orders' => '6',
  ),
  74 => 
  array (
    'id' => '1352',
    'parent_id' => '1346',
    'subject_id' => '2',
    'name' => '第二十七章 相似',
    'orders' => '6',
  ),
  75 => 
  array (
    'id' => '1322',
    'parent_id' => '1316',
    'subject_id' => '2',
    'name' => '第二十二章 一元二次方程',
    'orders' => '6',
  ),
  76 => 
  array (
    'id' => '1304',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '第十八章 平行四边形',
    'orders' => '6',
  ),
  77 => 
  array (
    'id' => '1303',
    'parent_id' => '1395',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '6',
  ),
  78 => 
  array (
    'id' => '1183',
    'parent_id' => '1180',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '6',
  ),
  79 => 
  array (
    'id' => '1210',
    'parent_id' => '1205',
    'subject_id' => '2',
    'name' => '1.5有理数的乘方',
    'orders' => '6',
  ),
  80 => 
  array (
    'id' => '1148',
    'parent_id' => '1145',
    'subject_id' => '2',
    'name' => '2.3倒数的认识',
    'orders' => '6',
  ),
  81 => 
  array (
    'id' => '1057',
    'parent_id' => '1051',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '6',
  ),
  82 => 
  array (
    'id' => '1103',
    'parent_id' => '1102',
    'subject_id' => '2',
    'name' => '2.1因数和倍数',
    'orders' => '6',
  ),
  83 => 
  array (
    'id' => '1104',
    'parent_id' => '1102',
    'subject_id' => '2',
    'name' => '2.2 2、5、3的倍数的特征',
    'orders' => '7',
  ),
  84 => 
  array (
    'id' => '1060',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第二单元 小数除法',
    'orders' => '7',
  ),
  85 => 
  array (
    'id' => '1184',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '第三单元  比例',
    'orders' => '7',
  ),
  86 => 
  array (
    'id' => '1211',
    'parent_id' => '1205',
    'subject_id' => '2',
    'name' => '第一章检测',
    'orders' => '7',
  ),
  87 => 
  array (
    'id' => '1149',
    'parent_id' => '1145',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '7',
  ),
  88 => 
  array (
    'id' => '1323',
    'parent_id' => '1322',
    'subject_id' => '2',
    'name' => '22.1一元二次方程',
    'orders' => '7',
  ),
  89 => 
  array (
    'id' => '1390',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '第十九章一次函数',
    'orders' => '7',
  ),
  90 => 
  array (
    'id' => '1301',
    'parent_id' => '1299',
    'subject_id' => '2',
    'name' => '17.2勾股定理的逆定理',
    'orders' => '7',
  ),
  91 => 
  array (
    'id' => '1353',
    'parent_id' => '1352',
    'subject_id' => '2',
    'name' => '27.1图形的相似',
    'orders' => '7',
  ),
  92 => 
  array (
    'id' => '1265',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版八年级上册',
    'orders' => '7',
  ),
  93 => 
  array (
    'id' => '1272',
    'parent_id' => '1271',
    'subject_id' => '2',
    'name' => '12.1 全等三角形',
    'orders' => '7',
  ),
  94 => 
  array (
    'id' => '1237',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '第六章 实数',
    'orders' => '7',
  ),
  95 => 
  array (
    'id' => '1294',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版八年级下册',
    'orders' => '8',
  ),
  96 => 
  array (
    'id' => '1238',
    'parent_id' => '1237',
    'subject_id' => '2',
    'name' => '6.1平方根',
    'orders' => '8',
  ),
  97 => 
  array (
    'id' => '1273',
    'parent_id' => '1271',
    'subject_id' => '2',
    'name' => '12.2 三角形全等的判定',
    'orders' => '8',
  ),
  98 => 
  array (
    'id' => '1302',
    'parent_id' => '1299',
    'subject_id' => '2',
    'name' => '第十七章检测',
    'orders' => '8',
  ),
  99 => 
  array (
    'id' => '1354',
    'parent_id' => '1352',
    'subject_id' => '2',
    'name' => '27.2相似三角形',
    'orders' => '8',
  ),
  100 => 
  array (
    'id' => '1324',
    'parent_id' => '1322',
    'subject_id' => '2',
    'name' => '22.2降次——解一元二次方程',
    'orders' => '8',
  ),
  101 => 
  array (
    'id' => '1185',
    'parent_id' => '1184',
    'subject_id' => '2',
    'name' => '3.1比例的意义和基本性质',
    'orders' => '8',
  ),
  102 => 
  array (
    'id' => '1150',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第三单元  分数除法',
    'orders' => '8',
  ),
  103 => 
  array (
    'id' => '1212',
    'parent_id' => '1204',
    'subject_id' => '2',
    'name' => '第二章 整式的加减',
    'orders' => '8',
  ),
  104 => 
  array (
    'id' => '1105',
    'parent_id' => '1102',
    'subject_id' => '2',
    'name' => '2.3质数和合数	',
    'orders' => '8',
  ),
  105 => 
  array (
    'id' => '1061',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '2.1小数除以整数	',
    'orders' => '8',
  ),
  106 => 
  array (
    'id' => '1062',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '2.2一个数除以小数	',
    'orders' => '9',
  ),
  107 => 
  array (
    'id' => '1106',
    'parent_id' => '1102',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '9',
  ),
  108 => 
  array (
    'id' => '1213',
    'parent_id' => '1212',
    'subject_id' => '2',
    'name' => '2.1整式',
    'orders' => '9',
  ),
  109 => 
  array (
    'id' => '1151',
    'parent_id' => '1150',
    'subject_id' => '2',
    'name' => '3.1分数除法',
    'orders' => '9',
  ),
  110 => 
  array (
    'id' => '1186',
    'parent_id' => '1184',
    'subject_id' => '2',
    'name' => '3.2正比例和反比例的意义',
    'orders' => '9',
  ),
  111 => 
  array (
    'id' => '1355',
    'parent_id' => '1352',
    'subject_id' => '2',
    'name' => '27.3位似',
    'orders' => '9',
  ),
  112 => 
  array (
    'id' => '1316',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版九年级上册',
    'orders' => '9',
  ),
  113 => 
  array (
    'id' => '1325',
    'parent_id' => '1322',
    'subject_id' => '2',
    'name' => '22.3实际问题与一元二次方程',
    'orders' => '9',
  ),
  114 => 
  array (
    'id' => '1274',
    'parent_id' => '1271',
    'subject_id' => '2',
    'name' => '12.3 角的平分线的性质',
    'orders' => '9',
  ),
  115 => 
  array (
    'id' => '1239',
    'parent_id' => '1237',
    'subject_id' => '2',
    'name' => '6.2立方根',
    'orders' => '9',
  ),
  116 => 
  array (
    'id' => '1240',
    'parent_id' => '1237',
    'subject_id' => '2',
    'name' => '6.3实数',
    'orders' => '10',
  ),
  117 => 
  array (
    'id' => '1275',
    'parent_id' => '1271',
    'subject_id' => '2',
    'name' => '第十二章检测',
    'orders' => '10',
  ),
  118 => 
  array (
    'id' => '1356',
    'parent_id' => '1352',
    'subject_id' => '2',
    'name' => '第二十七章检测',
    'orders' => '10',
  ),
  119 => 
  array (
    'id' => '1346',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版九年级下册',
    'orders' => '10',
  ),
  120 => 
  array (
    'id' => '1326',
    'parent_id' => '1322',
    'subject_id' => '2',
    'name' => '第二十二章检测',
    'orders' => '10',
  ),
  121 => 
  array (
    'id' => '1152',
    'parent_id' => '1150',
    'subject_id' => '2',
    'name' => '3.2解决问题',
    'orders' => '10',
  ),
  122 => 
  array (
    'id' => '1214',
    'parent_id' => '1212',
    'subject_id' => '2',
    'name' => '2.2整式的加减',
    'orders' => '10',
  ),
  123 => 
  array (
    'id' => '1187',
    'parent_id' => '1184',
    'subject_id' => '2',
    'name' => '3.3比例的应用',
    'orders' => '10',
  ),
  124 => 
  array (
    'id' => '1063',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '2.3商的近似数',
    'orders' => '10',
  ),
  125 => 
  array (
    'id' => '1107',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第三单元  长方体和正方体	',
    'orders' => '10',
  ),
  126 => 
  array (
    'id' => '1108',
    'parent_id' => '1107',
    'subject_id' => '2',
    'name' => '3.1长方体和正方体的认识',
    'orders' => '11',
  ),
  127 => 
  array (
    'id' => '1064',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '2.4循环小数',
    'orders' => '11',
  ),
  128 => 
  array (
    'id' => '1188',
    'parent_id' => '1184',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '11',
  ),
  129 => 
  array (
    'id' => '1215',
    'parent_id' => '1212',
    'subject_id' => '2',
    'name' => '第二章检测',
    'orders' => '11',
  ),
  130 => 
  array (
    'id' => '1153',
    'parent_id' => '1150',
    'subject_id' => '2',
    'name' => '3.3比和比的应用',
    'orders' => '11',
  ),
  131 => 
  array (
    'id' => '1357',
    'parent_id' => '1346',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '11',
  ),
  132 => 
  array (
    'id' => '1305',
    'parent_id' => '1304',
    'subject_id' => '2',
    'name' => '18.1平行四边形',
    'orders' => '11',
  ),
  133 => 
  array (
    'id' => '1327',
    'parent_id' => '1316',
    'subject_id' => '2',
    'name' => '第二十三章 旋转',
    'orders' => '11',
  ),
  134 => 
  array (
    'id' => '1276',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '第十三章 轴对称',
    'orders' => '11',
  ),
  135 => 
  array (
    'id' => '1241',
    'parent_id' => '1237',
    'subject_id' => '2',
    'name' => '第六章检测',
    'orders' => '11',
  ),
  136 => 
  array (
    'id' => '1242',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '第七章 平面直角坐标系',
    'orders' => '12',
  ),
  137 => 
  array (
    'id' => '1329',
    'parent_id' => '1327',
    'subject_id' => '2',
    'name' => '23.1图形的旋转',
    'orders' => '12',
  ),
  138 => 
  array (
    'id' => '1358',
    'parent_id' => '1346',
    'subject_id' => '2',
    'name' => '第二十八章 锐角三角函数',
    'orders' => '12',
  ),
  139 => 
  array (
    'id' => '1306',
    'parent_id' => '1304',
    'subject_id' => '2',
    'name' => '18.2特殊的平行四边形',
    'orders' => '12',
  ),
  140 => 
  array (
    'id' => '1216',
    'parent_id' => '1204',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '12',
  ),
  141 => 
  array (
    'id' => '1154',
    'parent_id' => '1150',
    'subject_id' => '2',
    'name' => '第三单元检测  ',
    'orders' => '12',
  ),
  142 => 
  array (
    'id' => '1189',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '课题：自行车里的数学	',
    'orders' => '12',
  ),
  143 => 
  array (
    'id' => '1109',
    'parent_id' => '1107',
    'subject_id' => '2',
    'name' => '3.2长方体、正方体表面积',
    'orders' => '12',
  ),
  144 => 
  array (
    'id' => '1066',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '2.6	解决问题	',
    'orders' => '12',
  ),
  145 => 
  array (
    'id' => '1065',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '2.5用计算器探索规律',
    'orders' => '12',
  ),
  146 => 
  array (
    'id' => '1110',
    'parent_id' => '1107',
    'subject_id' => '2',
    'name' => '3.3长方体和正方体的体积',
    'orders' => '13',
  ),
  147 => 
  array (
    'id' => '1155',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第四单元  圆',
    'orders' => '13',
  ),
  148 => 
  array (
    'id' => '1217',
    'parent_id' => '1204',
    'subject_id' => '2',
    'name' => '第三章 一元一次方程',
    'orders' => '13',
  ),
  149 => 
  array (
    'id' => '1190',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '期中检测',
    'orders' => '13',
  ),
  150 => 
  array (
    'id' => '1359',
    'parent_id' => '1358',
    'subject_id' => '2',
    'name' => '28.1锐角三角函数',
    'orders' => '13',
  ),
  151 => 
  array (
    'id' => '1328',
    'parent_id' => '1327',
    'subject_id' => '2',
    'name' => '23.2中心对称',
    'orders' => '13',
  ),
  152 => 
  array (
    'id' => '1278',
    'parent_id' => '1276',
    'subject_id' => '2',
    'name' => '13.2 作轴对称图形',
    'orders' => '13',
  ),
  153 => 
  array (
    'id' => '1243',
    'parent_id' => '1242',
    'subject_id' => '2',
    'name' => '7.1平面直角坐标系',
    'orders' => '13',
  ),
  154 => 
  array (
    'id' => '1244',
    'parent_id' => '1242',
    'subject_id' => '2',
    'name' => '7.2坐标方法的简单应用',
    'orders' => '14',
  ),
  155 => 
  array (
    'id' => '1279',
    'parent_id' => '1276',
    'subject_id' => '2',
    'name' => '13.3等腰三角形',
    'orders' => '14',
  ),
  156 => 
  array (
    'id' => '1377',
    'parent_id' => '1191',
    'subject_id' => '2',
    'name' => '第四单元  统计',
    'orders' => '14',
  ),
  157 => 
  array (
    'id' => '1360',
    'parent_id' => '1358',
    'subject_id' => '2',
    'name' => '28.2解直角三角形',
    'orders' => '14',
  ),
  158 => 
  array (
    'id' => '1330',
    'parent_id' => '1327',
    'subject_id' => '2',
    'name' => '23.3课题学习 图案设计',
    'orders' => '14',
  ),
  159 => 
  array (
    'id' => '1191',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '第四单元  统计',
    'orders' => '14',
  ),
  160 => 
  array (
    'id' => '1218',
    'parent_id' => '1217',
    'subject_id' => '2',
    'name' => '3.1从算式到方程',
    'orders' => '14',
  ),
  161 => 
  array (
    'id' => '1156',
    'parent_id' => '1155',
    'subject_id' => '2',
    'name' => '4.1认识圆	',
    'orders' => '14',
  ),
  162 => 
  array (
    'id' => '1067',
    'parent_id' => '1060',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '14',
  ),
  163 => 
  array (
    'id' => '1111',
    'parent_id' => '1107',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '14',
  ),
  164 => 
  array (
    'id' => '1069',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第三单元  观察物体',
    'orders' => '15',
  ),
  165 => 
  array (
    'id' => '1112',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '课题：粉刷围墙	',
    'orders' => '15',
  ),
  166 => 
  array (
    'id' => '1192',
    'parent_id' => '1191',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '15',
  ),
  167 => 
  array (
    'id' => '1157',
    'parent_id' => '1155',
    'subject_id' => '2',
    'name' => '4.2圆的周长',
    'orders' => '15',
  ),
  168 => 
  array (
    'id' => '1219',
    'parent_id' => '1217',
    'subject_id' => '2',
    'name' => '3.2解一元一次方程（一）    ——合并同类项与移项',
    'orders' => '15',
  ),
  169 => 
  array (
    'id' => '1331',
    'parent_id' => '1327',
    'subject_id' => '2',
    'name' => '第二十三章检测',
    'orders' => '15',
  ),
  170 => 
  array (
    'id' => '1370',
    'parent_id' => '1069',
    'subject_id' => '2',
    'name' => '第三单元  观察物体',
    'orders' => '15',
  ),
  171 => 
  array (
    'id' => '1361',
    'parent_id' => '1358',
    'subject_id' => '2',
    'name' => '第二十八章检测',
    'orders' => '15',
  ),
  172 => 
  array (
    'id' => '1309',
    'parent_id' => '1304',
    'subject_id' => '2',
    'name' => '第十八章检测',
    'orders' => '15',
  ),
  173 => 
  array (
    'id' => '1280',
    'parent_id' => '1276',
    'subject_id' => '2',
    'name' => '课题学习 最短路径问题',
    'orders' => '15',
  ),
  174 => 
  array (
    'id' => '1245',
    'parent_id' => '1242',
    'subject_id' => '2',
    'name' => '第七章检测',
    'orders' => '15',
  ),
  175 => 
  array (
    'id' => '1247',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '16',
  ),
  176 => 
  array (
    'id' => '1281',
    'parent_id' => '1276',
    'subject_id' => '2',
    'name' => '第十三章检测',
    'orders' => '16',
  ),
  177 => 
  array (
    'id' => '1362',
    'parent_id' => '1346',
    'subject_id' => '2',
    'name' => '第二十九章 投影与视图',
    'orders' => '16',
  ),
  178 => 
  array (
    'id' => '1310',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '第二十章 数据的分析',
    'orders' => '16',
  ),
  179 => 
  array (
    'id' => '1378',
    'parent_id' => '1193',
    'subject_id' => '2',
    'name' => '第五单元  数学广角	',
    'orders' => '16',
  ),
  180 => 
  array (
    'id' => '1332',
    'parent_id' => '1316',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '16',
  ),
  181 => 
  array (
    'id' => '1441',
    'parent_id' => '1294',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '16',
  ),
  182 => 
  array (
    'id' => '1158',
    'parent_id' => '1155',
    'subject_id' => '2',
    'name' => '4.3圆的面积',
    'orders' => '16',
  ),
  183 => 
  array (
    'id' => '1193',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '第5单元  数学广角',
    'orders' => '16',
  ),
  184 => 
  array (
    'id' => '1220',
    'parent_id' => '1217',
    'subject_id' => '2',
    'name' => '3.3解一元一次方程（二）   ——去括号与去分母',
    'orders' => '16',
  ),
  185 => 
  array (
    'id' => '1113',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '16',
  ),
  186 => 
  array (
    'id' => '1070',
    'parent_id' => '1069',
    'subject_id' => '2',
    'name' => '第三单元检测	',
    'orders' => '16',
  ),
  187 => 
  array (
    'id' => '1071',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第四单元  简易方程	',
    'orders' => '17',
  ),
  188 => 
  array (
    'id' => '1114',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第四单元  分数的意义和性质',
    'orders' => '17',
  ),
  189 => 
  array (
    'id' => '1159',
    'parent_id' => '1155',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '17',
  ),
  190 => 
  array (
    'id' => '1194',
    'parent_id' => '1193',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '17',
  ),
  191 => 
  array (
    'id' => '1282',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '17',
  ),
  192 => 
  array (
    'id' => '1248',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '第八章 二元一次方程组',
    'orders' => '17',
  ),
  193 => 
  array (
    'id' => '1221',
    'parent_id' => '1217',
    'subject_id' => '2',
    'name' => '3.4实际问题与一元一次方程',
    'orders' => '17',
  ),
  194 => 
  array (
    'id' => '1363',
    'parent_id' => '1362',
    'subject_id' => '2',
    'name' => '29.1投影',
    'orders' => '17',
  ),
  195 => 
  array (
    'id' => '1333',
    'parent_id' => '1316',
    'subject_id' => '2',
    'name' => '第二十四章 圆',
    'orders' => '17',
  ),
  196 => 
  array (
    'id' => '1311',
    'parent_id' => '1310',
    'subject_id' => '2',
    'name' => '20.1数据的集中趋势',
    'orders' => '17',
  ),
  197 => 
  array (
    'id' => '1334',
    'parent_id' => '1333',
    'subject_id' => '2',
    'name' => '24.1圆',
    'orders' => '18',
  ),
  198 => 
  array (
    'id' => '1364',
    'parent_id' => '1362',
    'subject_id' => '2',
    'name' => '29.2三视图',
    'orders' => '18',
  ),
  199 => 
  array (
    'id' => '1312',
    'parent_id' => '1310',
    'subject_id' => '2',
    'name' => '20.2数据的波动程度',
    'orders' => '18',
  ),
  200 => 
  array (
    'id' => '1283',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '第十四章 整式的乘除与因式分解',
    'orders' => '18',
  ),
  201 => 
  array (
    'id' => '1222',
    'parent_id' => '1217',
    'subject_id' => '2',
    'name' => '第三章检测',
    'orders' => '18',
  ),
  202 => 
  array (
    'id' => '1072',
    'parent_id' => '1071',
    'subject_id' => '2',
    'name' => '4. 1用字母表示数	',
    'orders' => '18',
  ),
  203 => 
  array (
    'id' => '1116',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '4.1分数的意义',
    'orders' => '18',
  ),
  204 => 
  array (
    'id' => '1160',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '课题：确定起跑线',
    'orders' => '18',
  ),
  205 => 
  array (
    'id' => '1195',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '课题：节约用水',
    'orders' => '18',
  ),
  206 => 
  array (
    'id' => '1196',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '第6单元  整理与复习',
    'orders' => '19',
  ),
  207 => 
  array (
    'id' => '1161',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '19',
  ),
  208 => 
  array (
    'id' => '1073',
    'parent_id' => '1071',
    'subject_id' => '2',
    'name' => '4.2解简易方程',
    'orders' => '19',
  ),
  209 => 
  array (
    'id' => '1117',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '4.2真分数与假分数',
    'orders' => '19',
  ),
  210 => 
  array (
    'id' => '1335',
    'parent_id' => '1333',
    'subject_id' => '2',
    'name' => '24.2点、直线、圆和圆的位置关系',
    'orders' => '19',
  ),
  211 => 
  array (
    'id' => '1365',
    'parent_id' => '1362',
    'subject_id' => '2',
    'name' => '29.3课题学习 制作立体模型',
    'orders' => '19',
  ),
  212 => 
  array (
    'id' => '1313',
    'parent_id' => '1310',
    'subject_id' => '2',
    'name' => '20.3课题学习 体质健康测试中的数据分析',
    'orders' => '19',
  ),
  213 => 
  array (
    'id' => '1250',
    'parent_id' => '1248',
    'subject_id' => '2',
    'name' => '8.2消元——解二元一次方程组',
    'orders' => '19',
  ),
  214 => 
  array (
    'id' => '1284',
    'parent_id' => '1283',
    'subject_id' => '2',
    'name' => '14.1整式的乘法',
    'orders' => '19',
  ),
  215 => 
  array (
    'id' => '1223',
    'parent_id' => '1204',
    'subject_id' => '2',
    'name' => '第四章 几何图形初步',
    'orders' => '19',
  ),
  216 => 
  array (
    'id' => '1251',
    'parent_id' => '1248',
    'subject_id' => '2',
    'name' => '8.3实际问题与二元一次方程组',
    'orders' => '20',
  ),
  217 => 
  array (
    'id' => '1224',
    'parent_id' => '1223',
    'subject_id' => '2',
    'name' => '4.1几何图形',
    'orders' => '20',
  ),
  218 => 
  array (
    'id' => '1285',
    'parent_id' => '1283',
    'subject_id' => '2',
    'name' => '14.2乘法公式',
    'orders' => '20',
  ),
  219 => 
  array (
    'id' => '1314',
    'parent_id' => '1310',
    'subject_id' => '2',
    'name' => '第二十章检测',
    'orders' => '20',
  ),
  220 => 
  array (
    'id' => '1336',
    'parent_id' => '1333',
    'subject_id' => '2',
    'name' => '24.3正多边形和圆',
    'orders' => '20',
  ),
  221 => 
  array (
    'id' => '1366',
    'parent_id' => '1362',
    'subject_id' => '2',
    'name' => '第二十九章检测',
    'orders' => '20',
  ),
  222 => 
  array (
    'id' => '1197',
    'parent_id' => '1196',
    'subject_id' => '2',
    'name' => '6.1数与代数	',
    'orders' => '20',
  ),
  223 => 
  array (
    'id' => '1162',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第五单元  百分数	',
    'orders' => '20',
  ),
  224 => 
  array (
    'id' => '1118',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '4.3分数的基本性质',
    'orders' => '20',
  ),
  225 => 
  array (
    'id' => '1074',
    'parent_id' => '1071',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '20',
  ),
  226 => 
  array (
    'id' => '1119',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '4.4约分',
    'orders' => '21',
  ),
  227 => 
  array (
    'id' => '1163',
    'parent_id' => '1162',
    'subject_id' => '2',
    'name' => '5.1百分数的意义和写法	',
    'orders' => '21',
  ),
  228 => 
  array (
    'id' => '1198',
    'parent_id' => '1196',
    'subject_id' => '2',
    'name' => '6.2空间与图形',
    'orders' => '21',
  ),
  229 => 
  array (
    'id' => '1286',
    'parent_id' => '1283',
    'subject_id' => '2',
    'name' => '14.3因式分解',
    'orders' => '21',
  ),
  230 => 
  array (
    'id' => '1225',
    'parent_id' => '1223',
    'subject_id' => '2',
    'name' => '4.2直线、射线、线段',
    'orders' => '21',
  ),
  231 => 
  array (
    'id' => '1252',
    'parent_id' => '1248',
    'subject_id' => '2',
    'name' => '8.4三元一次方程组的解法',
    'orders' => '21',
  ),
  232 => 
  array (
    'id' => '1315',
    'parent_id' => '1395',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '21',
  ),
  233 => 
  array (
    'id' => '1337',
    'parent_id' => '1333',
    'subject_id' => '2',
    'name' => '24.4弧长和扇形面积',
    'orders' => '21',
  ),
  234 => 
  array (
    'id' => '1367',
    'parent_id' => '1346',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '21',
  ),
  235 => 
  array (
    'id' => '1338',
    'parent_id' => '1333',
    'subject_id' => '2',
    'name' => '第二十四章检测',
    'orders' => '22',
  ),
  236 => 
  array (
    'id' => '1287',
    'parent_id' => '1283',
    'subject_id' => '2',
    'name' => '第十四章检测',
    'orders' => '22',
  ),
  237 => 
  array (
    'id' => '1253',
    'parent_id' => '1248',
    'subject_id' => '2',
    'name' => '第八章检测',
    'orders' => '22',
  ),
  238 => 
  array (
    'id' => '1226',
    'parent_id' => '1223',
    'subject_id' => '2',
    'name' => '4.3角',
    'orders' => '22',
  ),
  239 => 
  array (
    'id' => '1076',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '22',
  ),
  240 => 
  array (
    'id' => '1120',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '4.5通分',
    'orders' => '22',
  ),
  241 => 
  array (
    'id' => '1164',
    'parent_id' => '1162',
    'subject_id' => '2',
    'name' => '5.2百分数和分数、小数的互化',
    'orders' => '22',
  ),
  242 => 
  array (
    'id' => '1199',
    'parent_id' => '1196',
    'subject_id' => '2',
    'name' => '6.3统计与可能性',
    'orders' => '22',
  ),
  243 => 
  array (
    'id' => '1165',
    'parent_id' => '1162',
    'subject_id' => '2',
    'name' => '5.3用百分数解决问题',
    'orders' => '23',
  ),
  244 => 
  array (
    'id' => '1200',
    'parent_id' => '1196',
    'subject_id' => '2',
    'name' => '6.4综合应用	',
    'orders' => '23',
  ),
  245 => 
  array (
    'id' => '1121',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '4.6分数和小数的互化',
    'orders' => '23',
  ),
  246 => 
  array (
    'id' => '1077',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第五单元  多边形的面积',
    'orders' => '23',
  ),
  247 => 
  array (
    'id' => '1339',
    'parent_id' => '1316',
    'subject_id' => '2',
    'name' => '第二十五章 概率初步',
    'orders' => '23',
  ),
  248 => 
  array (
    'id' => '1227',
    'parent_id' => '1223',
    'subject_id' => '2',
    'name' => '4.4课题学习 设计制作长方体形状的包装纸盒',
    'orders' => '23',
  ),
  249 => 
  array (
    'id' => '1288',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '第十五章 分式',
    'orders' => '23',
  ),
  250 => 
  array (
    'id' => '1254',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '第九章 不等式与不等式组',
    'orders' => '23',
  ),
  251 => 
  array (
    'id' => '1289',
    'parent_id' => '1288',
    'subject_id' => '2',
    'name' => '15.1分式',
    'orders' => '24',
  ),
  252 => 
  array (
    'id' => '1228',
    'parent_id' => '1223',
    'subject_id' => '2',
    'name' => '第四章检测',
    'orders' => '24',
  ),
  253 => 
  array (
    'id' => '1255',
    'parent_id' => '1254',
    'subject_id' => '2',
    'name' => '9.1不等式',
    'orders' => '24',
  ),
  254 => 
  array (
    'id' => '1340',
    'parent_id' => '1339',
    'subject_id' => '2',
    'name' => '25.1随机事件与概率',
    'orders' => '24',
  ),
  255 => 
  array (
    'id' => '1166',
    'parent_id' => '1162',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '24',
  ),
  256 => 
  array (
    'id' => '1201',
    'parent_id' => '1196',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '24',
  ),
  257 => 
  array (
    'id' => '1122',
    'parent_id' => '1114',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '24',
  ),
  258 => 
  array (
    'id' => '1078',
    'parent_id' => '1077',
    'subject_id' => '2',
    'name' => '5.1平行四边形的面积',
    'orders' => '24',
  ),
  259 => 
  array (
    'id' => '1123',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第五单元  分数的加法和减法',
    'orders' => '25',
  ),
  260 => 
  array (
    'id' => '1079',
    'parent_id' => '1077',
    'subject_id' => '2',
    'name' => '5.2三角形的面积',
    'orders' => '25',
  ),
  261 => 
  array (
    'id' => '1202',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '25',
  ),
  262 => 
  array (
    'id' => '1167',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第六单元  统计',
    'orders' => '25',
  ),
  263 => 
  array (
    'id' => '1290',
    'parent_id' => '1288',
    'subject_id' => '2',
    'name' => '15.2分式的运算',
    'orders' => '25',
  ),
  264 => 
  array (
    'id' => '1229',
    'parent_id' => '1204',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '25',
  ),
  265 => 
  array (
    'id' => '1256',
    'parent_id' => '1254',
    'subject_id' => '2',
    'name' => '9.2一元一次不等式',
    'orders' => '25',
  ),
  266 => 
  array (
    'id' => '1341',
    'parent_id' => '1339',
    'subject_id' => '2',
    'name' => '25.2用列举法求概率',
    'orders' => '25',
  ),
  267 => 
  array (
    'id' => '1342',
    'parent_id' => '1339',
    'subject_id' => '2',
    'name' => '25.3用频率估计概率',
    'orders' => '26',
  ),
  268 => 
  array (
    'id' => '1374',
    'parent_id' => '1167',
    'subject_id' => '2',
    'name' => '第六单元  统计',
    'orders' => '26',
  ),
  269 => 
  array (
    'id' => '1257',
    'parent_id' => '1254',
    'subject_id' => '2',
    'name' => '9.3一元一次不等式组',
    'orders' => '26',
  ),
  270 => 
  array (
    'id' => '1291',
    'parent_id' => '1288',
    'subject_id' => '2',
    'name' => '15.3分式方程',
    'orders' => '26',
  ),
  271 => 
  array (
    'id' => '1124',
    'parent_id' => '1123',
    'subject_id' => '2',
    'name' => '5.1同分母分数加、减法',
    'orders' => '26',
  ),
  272 => 
  array (
    'id' => '1080',
    'parent_id' => '1077',
    'subject_id' => '2',
    'name' => '5.3梯形的面积',
    'orders' => '26',
  ),
  273 => 
  array (
    'id' => '1203',
    'parent_id' => '1177',
    'subject_id' => '2',
    'name' => '毕业升学冲刺测试',
    'orders' => '26',
  ),
  274 => 
  array (
    'id' => '1168',
    'parent_id' => '1167',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '26',
  ),
  275 => 
  array (
    'id' => '1169',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '课题：合理存款	',
    'orders' => '27',
  ),
  276 => 
  array (
    'id' => '1125',
    'parent_id' => '1123',
    'subject_id' => '2',
    'name' => '5.2异分母分数加、减法',
    'orders' => '27',
  ),
  277 => 
  array (
    'id' => '1081',
    'parent_id' => '1077',
    'subject_id' => '2',
    'name' => '5.4组合图形的面积',
    'orders' => '27',
  ),
  278 => 
  array (
    'id' => '1343',
    'parent_id' => '1339',
    'subject_id' => '2',
    'name' => '25.4课题学习 键盘上字母的排列规律',
    'orders' => '27',
  ),
  279 => 
  array (
    'id' => '1258',
    'parent_id' => '1254',
    'subject_id' => '2',
    'name' => '第九章检测',
    'orders' => '27',
  ),
  280 => 
  array (
    'id' => '1292',
    'parent_id' => '1288',
    'subject_id' => '2',
    'name' => '第十五章检测',
    'orders' => '27',
  ),
  281 => 
  array (
    'id' => '1259',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '第十章 数据的收集、整理与描述',
    'orders' => '28',
  ),
  282 => 
  array (
    'id' => '1293',
    'parent_id' => '1265',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '28',
  ),
  283 => 
  array (
    'id' => '1344',
    'parent_id' => '1339',
    'subject_id' => '2',
    'name' => '第二十五章检测',
    'orders' => '28',
  ),
  284 => 
  array (
    'id' => '1375',
    'parent_id' => '1170',
    'subject_id' => '2',
    'name' => '第七单元  数学广角',
    'orders' => '28',
  ),
  285 => 
  array (
    'id' => '1170',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第七单元  数学广角',
    'orders' => '28',
  ),
  286 => 
  array (
    'id' => '1082',
    'parent_id' => '1077',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '28',
  ),
  287 => 
  array (
    'id' => '1126',
    'parent_id' => '1123',
    'subject_id' => '2',
    'name' => '5.3分数加减混合运算',
    'orders' => '28',
  ),
  288 => 
  array (
    'id' => '1127',
    'parent_id' => '1123',
    'subject_id' => '2',
    'name' => '第五单元检测	',
    'orders' => '29',
  ),
  289 => 
  array (
    'id' => '1084',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第六单元 统计与可能性',
    'orders' => '29',
  ),
  290 => 
  array (
    'id' => '1171',
    'parent_id' => '1170',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '29',
  ),
  291 => 
  array (
    'id' => '1260',
    'parent_id' => '1259',
    'subject_id' => '2',
    'name' => '10.1统计调查',
    'orders' => '29',
  ),
  292 => 
  array (
    'id' => '1345',
    'parent_id' => '1316',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '29',
  ),
  293 => 
  array (
    'id' => '1371',
    'parent_id' => '1084',
    'subject_id' => '2',
    'name' => '第六单元 统计与可能性',
    'orders' => '29',
  ),
  294 => 
  array (
    'id' => '1308',
    'parent_id' => '1395',
    'subject_id' => '2',
    'name' => '19.4课题学习 重心',
    'orders' => '30',
  ),
  295 => 
  array (
    'id' => '1307',
    'parent_id' => '1395',
    'subject_id' => '2',
    'name' => '19.3梯形',
    'orders' => '30',
  ),
  296 => 
  array (
    'id' => '1261',
    'parent_id' => '1259',
    'subject_id' => '2',
    'name' => '10.2直方图',
    'orders' => '30',
  ),
  297 => 
  array (
    'id' => '1128',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第六单元  统计',
    'orders' => '30',
  ),
  298 => 
  array (
    'id' => '1085',
    'parent_id' => '1084',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '30',
  ),
  299 => 
  array (
    'id' => '1172',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '第八单元  总复习',
    'orders' => '30',
  ),
  300 => 
  array (
    'id' => '1173',
    'parent_id' => '1172',
    'subject_id' => '2',
    'name' => '8.1分数乘、除法',
    'orders' => '31',
  ),
  301 => 
  array (
    'id' => '1086',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '课题：铺一铺',
    'orders' => '31',
  ),
  302 => 
  array (
    'id' => '1129',
    'parent_id' => '1128',
    'subject_id' => '2',
    'name' => '6.1中位数和众数',
    'orders' => '31',
  ),
  303 => 
  array (
    'id' => '1262',
    'parent_id' => '1259',
    'subject_id' => '2',
    'name' => '10.3课题学习 从数据谈节水',
    'orders' => '31',
  ),
  304 => 
  array (
    'id' => '1263',
    'parent_id' => '1259',
    'subject_id' => '2',
    'name' => '第十章检测',
    'orders' => '32',
  ),
  305 => 
  array (
    'id' => '1130',
    'parent_id' => '1128',
    'subject_id' => '2',
    'name' => '6.2折线统计图',
    'orders' => '32',
  ),
  306 => 
  array (
    'id' => '1087',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第七单元  数学广角',
    'orders' => '32',
  ),
  307 => 
  array (
    'id' => '1372',
    'parent_id' => '1087',
    'subject_id' => '2',
    'name' => '第七单元  数学广角',
    'orders' => '32',
  ),
  308 => 
  array (
    'id' => '1174',
    'parent_id' => '1172',
    'subject_id' => '2',
    'name' => '8.2百分数',
    'orders' => '32',
  ),
  309 => 
  array (
    'id' => '1379',
    'parent_id' => '1172',
    'subject_id' => '2',
    'name' => '8.3空间与图形',
    'orders' => '33',
  ),
  310 => 
  array (
    'id' => '1264',
    'parent_id' => '1230',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '33',
  ),
  311 => 
  array (
    'id' => '1088',
    'parent_id' => '1087',
    'subject_id' => '2',
    'name' => '第七单元检测	',
    'orders' => '33',
  ),
  312 => 
  array (
    'id' => '1131',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '课题：打电话',
    'orders' => '33',
  ),
  313 => 
  array (
    'id' => '1132',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第七单元  数学广角	',
    'orders' => '34',
  ),
  314 => 
  array (
    'id' => '1089',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '第八单元总复习',
    'orders' => '34',
  ),
  315 => 
  array (
    'id' => '1176',
    'parent_id' => '1142',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '34',
  ),
  316 => 
  array (
    'id' => '1175',
    'parent_id' => '1172',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '34',
  ),
  317 => 
  array (
    'id' => '1380',
    'parent_id' => '1172',
    'subject_id' => '2',
    'name' => '8.4统计',
    'orders' => '34',
  ),
  318 => 
  array (
    'id' => '1133',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第六、七单元检测',
    'orders' => '35',
  ),
  319 => 
  array (
    'id' => '1091',
    'parent_id' => '1089',
    'subject_id' => '2',
    'name' => '8.1小数的乘、除法',
    'orders' => '35',
  ),
  320 => 
  array (
    'id' => '1134',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '第八单元  总复习',
    'orders' => '36',
  ),
  321 => 
  array (
    'id' => '1092',
    'parent_id' => '1089',
    'subject_id' => '2',
    'name' => '8.2简易方程',
    'orders' => '36',
  ),
  322 => 
  array (
    'id' => '1093',
    'parent_id' => '1089',
    'subject_id' => '2',
    'name' => '8.3多边形的面积',
    'orders' => '37',
  ),
  323 => 
  array (
    'id' => '1135',
    'parent_id' => '1134',
    'subject_id' => '2',
    'name' => '8.1因数与倍数',
    'orders' => '37',
  ),
  324 => 
  array (
    'id' => '1094',
    'parent_id' => '1089',
    'subject_id' => '2',
    'name' => '8.4可能性',
    'orders' => '38',
  ),
  325 => 
  array (
    'id' => '1136',
    'parent_id' => '1134',
    'subject_id' => '2',
    'name' => '8.2分数的意义和性质',
    'orders' => '38',
  ),
  326 => 
  array (
    'id' => '1137',
    'parent_id' => '1134',
    'subject_id' => '2',
    'name' => '8.3分数的加法和减法',
    'orders' => '39',
  ),
  327 => 
  array (
    'id' => '1095',
    'parent_id' => '1089',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '39',
  ),
  328 => 
  array (
    'id' => '1096',
    'parent_id' => '1050',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '40',
  ),
  329 => 
  array (
    'id' => '1138',
    'parent_id' => '1134',
    'subject_id' => '2',
    'name' => '8.4空间与图形',
    'orders' => '40',
  ),
  330 => 
  array (
    'id' => '1139',
    'parent_id' => '1134',
    'subject_id' => '2',
    'name' => '8.5统计与数学广角',
    'orders' => '41',
  ),
  331 => 
  array (
    'id' => '1140',
    'parent_id' => '1134',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '42',
  ),
  332 => 
  array (
    'id' => '1141',
    'parent_id' => '1097',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '43',
  ),
  333 => 
  array (
    'id' => '1295',
    'parent_id' => '1395',
    'subject_id' => '2',
    'name' => '第十七章 反比例函数',
    'orders' => '50',
  ),
  334 => 
  array (
    'id' => '2053',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版（2013）一年级上册',
    'orders' => '571',
  ),
  335 => 
  array (
    'id' => '2054',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第一单元 准备课',
    'orders' => '572',
  ),
  336 => 
  array (
    'id' => '2055',
    'parent_id' => '2054',
    'subject_id' => '2',
    'name' => '1.1 数一数',
    'orders' => '573',
  ),
  337 => 
  array (
    'id' => '2056',
    'parent_id' => '2054',
    'subject_id' => '2',
    'name' => '1.2 比多少',
    'orders' => '574',
  ),
  338 => 
  array (
    'id' => '2057',
    'parent_id' => '2054',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '575',
  ),
  339 => 
  array (
    'id' => '2058',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第二单元 位置',
    'orders' => '576',
  ),
  340 => 
  array (
    'id' => '2059',
    'parent_id' => '2058',
    'subject_id' => '2',
    'name' => '2.1 上、下、前、后',
    'orders' => '577',
  ),
  341 => 
  array (
    'id' => '2060',
    'parent_id' => '2058',
    'subject_id' => '2',
    'name' => '2.2 左、右',
    'orders' => '578',
  ),
  342 => 
  array (
    'id' => '2061',
    'parent_id' => '2058',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '579',
  ),
  343 => 
  array (
    'id' => '2062',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第三单元 1~5的认识和加减法',
    'orders' => '580',
  ),
  344 => 
  array (
    'id' => '2063',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.1 1~5的认识',
    'orders' => '581',
  ),
  345 => 
  array (
    'id' => '2064',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.2 比大小',
    'orders' => '582',
  ),
  346 => 
  array (
    'id' => '2065',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.3 第几',
    'orders' => '583',
  ),
  347 => 
  array (
    'id' => '2066',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.4 分与合',
    'orders' => '584',
  ),
  348 => 
  array (
    'id' => '2067',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.5 加法',
    'orders' => '585',
  ),
  349 => 
  array (
    'id' => '2068',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.6 减法',
    'orders' => '586',
  ),
  350 => 
  array (
    'id' => '2069',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.7 0',
    'orders' => '587',
  ),
  351 => 
  array (
    'id' => '2070',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '3.8 整理和复习',
    'orders' => '588',
  ),
  352 => 
  array (
    'id' => '2071',
    'parent_id' => '2062',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '589',
  ),
  353 => 
  array (
    'id' => '2072',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第四单元 认识图形（一）',
    'orders' => '590',
  ),
  354 => 
  array (
    'id' => '2073',
    'parent_id' => '2072',
    'subject_id' => '2',
    'name' => '4.1 认识长方体、正方体、圆柱、球',
    'orders' => '591',
  ),
  355 => 
  array (
    'id' => '2074',
    'parent_id' => '2072',
    'subject_id' => '2',
    'name' => '4.2解决问题',
    'orders' => '592',
  ),
  356 => 
  array (
    'id' => '2075',
    'parent_id' => '2072',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '593',
  ),
  357 => 
  array (
    'id' => '2076',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第五单元 6~10的认识和加减法',
    'orders' => '594',
  ),
  358 => 
  array (
    'id' => '2077',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '5.1 6和7',
    'orders' => '595',
  ),
  359 => 
  array (
    'id' => '2078',
    'parent_id' => '2077',
    'subject_id' => '2',
    'name' => '5.1.1 6、7的认识',
    'orders' => '596',
  ),
  360 => 
  array (
    'id' => '2079',
    'parent_id' => '2077',
    'subject_id' => '2',
    'name' => '5.1.2 6、7的加减法',
    'orders' => '597',
  ),
  361 => 
  array (
    'id' => '2080',
    'parent_id' => '2077',
    'subject_id' => '2',
    'name' => '5.1.3解决问题',
    'orders' => '598',
  ),
  362 => 
  array (
    'id' => '2081',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '5.2 8和9',
    'orders' => '599',
  ),
  363 => 
  array (
    'id' => '2082',
    'parent_id' => '2081',
    'subject_id' => '2',
    'name' => '5.2.1 8、9的认识',
    'orders' => '600',
  ),
  364 => 
  array (
    'id' => '2083',
    'parent_id' => '2081',
    'subject_id' => '2',
    'name' => '5.2.2 8、9的加减法',
    'orders' => '601',
  ),
  365 => 
  array (
    'id' => '2084',
    'parent_id' => '2081',
    'subject_id' => '2',
    'name' => '5.2.3 解决问题',
    'orders' => '602',
  ),
  366 => 
  array (
    'id' => '2085',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '5.3 10',
    'orders' => '603',
  ),
  367 => 
  array (
    'id' => '2086',
    'parent_id' => '2085',
    'subject_id' => '2',
    'name' => '5.3.1 10的认识',
    'orders' => '604',
  ),
  368 => 
  array (
    'id' => '2087',
    'parent_id' => '2085',
    'subject_id' => '2',
    'name' => '5.3.2 10的加减法',
    'orders' => '605',
  ),
  369 => 
  array (
    'id' => '2088',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '5.4 连加 连减',
    'orders' => '606',
  ),
  370 => 
  array (
    'id' => '2089',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '5.5 加减混合',
    'orders' => '607',
  ),
  371 => 
  array (
    'id' => '2090',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '5.6 整理和复习',
    'orders' => '608',
  ),
  372 => 
  array (
    'id' => '2091',
    'parent_id' => '2076',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '609',
  ),
  373 => 
  array (
    'id' => '2092',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '期中检测',
    'orders' => '610',
  ),
  374 => 
  array (
    'id' => '2093',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第六单元 11~20各数的认识',
    'orders' => '611',
  ),
  375 => 
  array (
    'id' => '2094',
    'parent_id' => '2093',
    'subject_id' => '2',
    'name' => '6.1 11~20各数的认识和读写法',
    'orders' => '612',
  ),
  376 => 
  array (
    'id' => '2095',
    'parent_id' => '2093',
    'subject_id' => '2',
    'name' => '6.2 10加几、十几加几和相应的减法',
    'orders' => '613',
  ),
  377 => 
  array (
    'id' => '2096',
    'parent_id' => '2093',
    'subject_id' => '2',
    'name' => '6.3 解决问题',
    'orders' => '614',
  ),
  378 => 
  array (
    'id' => '2097',
    'parent_id' => '2093',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '615',
  ),
  379 => 
  array (
    'id' => '2098',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '数学乐园',
    'orders' => '616',
  ),
  380 => 
  array (
    'id' => '2099',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第七单元 认识钟表',
    'orders' => '617',
  ),
  381 => 
  array (
    'id' => '2100',
    'parent_id' => '2099',
    'subject_id' => '2',
    'name' => '7.1 认识钟表',
    'orders' => '618',
  ),
  382 => 
  array (
    'id' => '2101',
    'parent_id' => '2099',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '619',
  ),
  383 => 
  array (
    'id' => '2102',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第八单元 20以内的进位加法',
    'orders' => '620',
  ),
  384 => 
  array (
    'id' => '2103',
    'parent_id' => '2102',
    'subject_id' => '2',
    'name' => '8.1 9加几',
    'orders' => '621',
  ),
  385 => 
  array (
    'id' => '2104',
    'parent_id' => '2102',
    'subject_id' => '2',
    'name' => '8.2 8、7、6加几',
    'orders' => '622',
  ),
  386 => 
  array (
    'id' => '2105',
    'parent_id' => '2102',
    'subject_id' => '2',
    'name' => '8.3 5、4、3、2加几',
    'orders' => '623',
  ),
  387 => 
  array (
    'id' => '2106',
    'parent_id' => '2102',
    'subject_id' => '2',
    'name' => '8.4 解决问题',
    'orders' => '624',
  ),
  388 => 
  array (
    'id' => '2107',
    'parent_id' => '2102',
    'subject_id' => '2',
    'name' => '8.5 整理和复习',
    'orders' => '625',
  ),
  389 => 
  array (
    'id' => '2108',
    'parent_id' => '2102',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '626',
  ),
  390 => 
  array (
    'id' => '2109',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '第九单元 总复习',
    'orders' => '627',
  ),
  391 => 
  array (
    'id' => '2110',
    'parent_id' => '2109',
    'subject_id' => '2',
    'name' => '9.1 数的认识',
    'orders' => '628',
  ),
  392 => 
  array (
    'id' => '2111',
    'parent_id' => '2109',
    'subject_id' => '2',
    'name' => '9.2 数的计算',
    'orders' => '629',
  ),
  393 => 
  array (
    'id' => '2112',
    'parent_id' => '2109',
    'subject_id' => '2',
    'name' => '9.3 认识图形和钟表',
    'orders' => '630',
  ),
  394 => 
  array (
    'id' => '2113',
    'parent_id' => '2109',
    'subject_id' => '2',
    'name' => '第九单元检测',
    'orders' => '631',
  ),
  395 => 
  array (
    'id' => '2114',
    'parent_id' => '2053',
    'subject_id' => '2',
    'name' => '期末试卷',
    'orders' => '632',
  ),
  396 => 
  array (
    'id' => '2115',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版（2013）一年级下册',
    'orders' => '634',
  ),
  397 => 
  array (
    'id' => '2116',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第一单元 认识图形',
    'orders' => '635',
  ),
  398 => 
  array (
    'id' => '2117',
    'parent_id' => '2116',
    'subject_id' => '2',
    'name' => '1.1 认识图形',
    'orders' => '636',
  ),
  399 => 
  array (
    'id' => '2118',
    'parent_id' => '2116',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '637',
  ),
  400 => 
  array (
    'id' => '2119',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第二单元 20以内的退位减法',
    'orders' => '638',
  ),
  401 => 
  array (
    'id' => '2120',
    'parent_id' => '2119',
    'subject_id' => '2',
    'name' => '2.1 十几减9',
    'orders' => '639',
  ),
  402 => 
  array (
    'id' => '2121',
    'parent_id' => '2119',
    'subject_id' => '2',
    'name' => '2.2 十几减8、7、6',
    'orders' => '640',
  ),
  403 => 
  array (
    'id' => '2122',
    'parent_id' => '2119',
    'subject_id' => '2',
    'name' => '2.3 十几减5、4、3、2',
    'orders' => '641',
  ),
  404 => 
  array (
    'id' => '2123',
    'parent_id' => '2119',
    'subject_id' => '2',
    'name' => '2.4 解决问题',
    'orders' => '642',
  ),
  405 => 
  array (
    'id' => '2124',
    'parent_id' => '2119',
    'subject_id' => '2',
    'name' => '2.5 整理和复习',
    'orders' => '643',
  ),
  406 => 
  array (
    'id' => '2125',
    'parent_id' => '2119',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '644',
  ),
  407 => 
  array (
    'id' => '2126',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第三单元 分类与整理',
    'orders' => '645',
  ),
  408 => 
  array (
    'id' => '2127',
    'parent_id' => '2126',
    'subject_id' => '2',
    'name' => '3.1 分类整理',
    'orders' => '646',
  ),
  409 => 
  array (
    'id' => '2128',
    'parent_id' => '2126',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '647',
  ),
  410 => 
  array (
    'id' => '2129',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第四单元 100以内数的认识',
    'orders' => '648',
  ),
  411 => 
  array (
    'id' => '2130',
    'parent_id' => '2129',
    'subject_id' => '2',
    'name' => '4.1 数数 数的组成 读数和写数',
    'orders' => '649',
  ),
  412 => 
  array (
    'id' => '2131',
    'parent_id' => '2129',
    'subject_id' => '2',
    'name' => '4.2 数的顺序、比较大小',
    'orders' => '650',
  ),
  413 => 
  array (
    'id' => '2132',
    'parent_id' => '2129',
    'subject_id' => '2',
    'name' => '4.3 解决问题',
    'orders' => '651',
  ),
  414 => 
  array (
    'id' => '2133',
    'parent_id' => '2129',
    'subject_id' => '2',
    'name' => '4.4 整十数加一位数及相应的减法',
    'orders' => '652',
  ),
  415 => 
  array (
    'id' => '2134',
    'parent_id' => '2129',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '653',
  ),
  416 => 
  array (
    'id' => '2135',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '摆一摆，想一想',
    'orders' => '654',
  ),
  417 => 
  array (
    'id' => '2136',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第五单元 认识人民币',
    'orders' => '655',
  ),
  418 => 
  array (
    'id' => '2137',
    'parent_id' => '2136',
    'subject_id' => '2',
    'name' => '5.1 认识人民币',
    'orders' => '656',
  ),
  419 => 
  array (
    'id' => '2138',
    'parent_id' => '2136',
    'subject_id' => '2',
    'name' => '5.2 简单的计算',
    'orders' => '657',
  ),
  420 => 
  array (
    'id' => '2139',
    'parent_id' => '2136',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '658',
  ),
  421 => 
  array (
    'id' => '2140',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '659',
  ),
  422 => 
  array (
    'id' => '2141',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第六单元 100以内的加法和减法（一）',
    'orders' => '660',
  ),
  423 => 
  array (
    'id' => '2142',
    'parent_id' => '2141',
    'subject_id' => '2',
    'name' => '6.1 整十数加、减整十数',
    'orders' => '661',
  ),
  424 => 
  array (
    'id' => '2143',
    'parent_id' => '2141',
    'subject_id' => '2',
    'name' => '6.2 两位数加一位数、整十数',
    'orders' => '662',
  ),
  425 => 
  array (
    'id' => '2144',
    'parent_id' => '2141',
    'subject_id' => '2',
    'name' => '6.3 两位数减一位数、整十数',
    'orders' => '663',
  ),
  426 => 
  array (
    'id' => '2145',
    'parent_id' => '2144',
    'subject_id' => '2',
    'name' => '6.3.1 两位数减一位数、整十数',
    'orders' => '664',
  ),
  427 => 
  array (
    'id' => '2146',
    'parent_id' => '2144',
    'subject_id' => '2',
    'name' => '6.3.2 认识小括号',
    'orders' => '665',
  ),
  428 => 
  array (
    'id' => '2147',
    'parent_id' => '2144',
    'subject_id' => '2',
    'name' => '6.3.3 解决问题',
    'orders' => '666',
  ),
  429 => 
  array (
    'id' => '2148',
    'parent_id' => '2141',
    'subject_id' => '2',
    'name' => '6.4 整理和复习',
    'orders' => '667',
  ),
  430 => 
  array (
    'id' => '2149',
    'parent_id' => '2141',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '668',
  ),
  431 => 
  array (
    'id' => '2150',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第七单元 找规律',
    'orders' => '669',
  ),
  432 => 
  array (
    'id' => '2151',
    'parent_id' => '2150',
    'subject_id' => '2',
    'name' => '7.1 找规律',
    'orders' => '670',
  ),
  433 => 
  array (
    'id' => '2152',
    'parent_id' => '2150',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '671',
  ),
  434 => 
  array (
    'id' => '2153',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '第八单元 总复习',
    'orders' => '672',
  ),
  435 => 
  array (
    'id' => '2154',
    'parent_id' => '2153',
    'subject_id' => '2',
    'name' => '8.1 数和代数',
    'orders' => '673',
  ),
  436 => 
  array (
    'id' => '2155',
    'parent_id' => '2153',
    'subject_id' => '2',
    'name' => '8.2 图形和几何',
    'orders' => '674',
  ),
  437 => 
  array (
    'id' => '2156',
    'parent_id' => '2153',
    'subject_id' => '2',
    'name' => '8.3 统计与概率',
    'orders' => '675',
  ),
  438 => 
  array (
    'id' => '2157',
    'parent_id' => '2153',
    'subject_id' => '2',
    'name' => '第八章检测',
    'orders' => '676',
  ),
  439 => 
  array (
    'id' => '2158',
    'parent_id' => '2115',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '677',
  ),
  440 => 
  array (
    'id' => '2159',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版（2013）二年级上册',
    'orders' => '679',
  ),
  441 => 
  array (
    'id' => '2160',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第一单元 长度单位',
    'orders' => '680',
  ),
  442 => 
  array (
    'id' => '2161',
    'parent_id' => '2160',
    'subject_id' => '2',
    'name' => '1.1 统一长度单位',
    'orders' => '681',
  ),
  443 => 
  array (
    'id' => '2162',
    'parent_id' => '2160',
    'subject_id' => '2',
    'name' => '1.2 认识厘米',
    'orders' => '682',
  ),
  444 => 
  array (
    'id' => '2163',
    'parent_id' => '2160',
    'subject_id' => '2',
    'name' => '1.3 认识米',
    'orders' => '683',
  ),
  445 => 
  array (
    'id' => '2164',
    'parent_id' => '2160',
    'subject_id' => '2',
    'name' => '1.4 认识线段',
    'orders' => '684',
  ),
  446 => 
  array (
    'id' => '2165',
    'parent_id' => '2160',
    'subject_id' => '2',
    'name' => '1.5 解决问题',
    'orders' => '685',
  ),
  447 => 
  array (
    'id' => '2166',
    'parent_id' => '2160',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '686',
  ),
  448 => 
  array (
    'id' => '2167',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第二单元 100以内的加法和减法（二）',
    'orders' => '687',
  ),
  449 => 
  array (
    'id' => '2168',
    'parent_id' => '2167',
    'subject_id' => '2',
    'name' => '2.1 加法',
    'orders' => '688',
  ),
  450 => 
  array (
    'id' => '2169',
    'parent_id' => '2168',
    'subject_id' => '2',
    'name' => '2.1.1 不进位加（一）',
    'orders' => '689',
  ),
  451 => 
  array (
    'id' => '2170',
    'parent_id' => '2168',
    'subject_id' => '2',
    'name' => '2.1.2 不进位加（二）',
    'orders' => '690',
  ),
  452 => 
  array (
    'id' => '2171',
    'parent_id' => '2168',
    'subject_id' => '2',
    'name' => '2.1.3 进位加',
    'orders' => '691',
  ),
  453 => 
  array (
    'id' => '2172',
    'parent_id' => '2167',
    'subject_id' => '2',
    'name' => '2.2 减法',
    'orders' => '692',
  ),
  454 => 
  array (
    'id' => '2173',
    'parent_id' => '2172',
    'subject_id' => '2',
    'name' => '2.2.1 不退位减',
    'orders' => '693',
  ),
  455 => 
  array (
    'id' => '2174',
    'parent_id' => '2172',
    'subject_id' => '2',
    'name' => '2.2.2 退位减',
    'orders' => '694',
  ),
  456 => 
  array (
    'id' => '2175',
    'parent_id' => '2172',
    'subject_id' => '2',
    'name' => '2.2.3 解决问题',
    'orders' => '695',
  ),
  457 => 
  array (
    'id' => '2176',
    'parent_id' => '2167',
    'subject_id' => '2',
    'name' => '2.3 连加、连减和加减混合',
    'orders' => '696',
  ),
  458 => 
  array (
    'id' => '2177',
    'parent_id' => '2176',
    'subject_id' => '2',
    'name' => '2.3.1 连加、连减',
    'orders' => '697',
  ),
  459 => 
  array (
    'id' => '2178',
    'parent_id' => '2176',
    'subject_id' => '2',
    'name' => '2.3.2 加减混合',
    'orders' => '698',
  ),
  460 => 
  array (
    'id' => '2179',
    'parent_id' => '2176',
    'subject_id' => '2',
    'name' => '2.3.3 解决问题',
    'orders' => '699',
  ),
  461 => 
  array (
    'id' => '2180',
    'parent_id' => '2167',
    'subject_id' => '2',
    'name' => '2.4 整理和复习',
    'orders' => '700',
  ),
  462 => 
  array (
    'id' => '2181',
    'parent_id' => '2167',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '701',
  ),
  463 => 
  array (
    'id' => '2182',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第三单元 角的初步认识',
    'orders' => '702',
  ),
  464 => 
  array (
    'id' => '2183',
    'parent_id' => '2182',
    'subject_id' => '2',
    'name' => '3.1 角的初步认识',
    'orders' => '703',
  ),
  465 => 
  array (
    'id' => '2184',
    'parent_id' => '2182',
    'subject_id' => '2',
    'name' => '3.2 直角、锐角和钝角的初步认识',
    'orders' => '704',
  ),
  466 => 
  array (
    'id' => '2185',
    'parent_id' => '2182',
    'subject_id' => '2',
    'name' => '3.3 解决问题',
    'orders' => '705',
  ),
  467 => 
  array (
    'id' => '2186',
    'parent_id' => '2182',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '706',
  ),
  468 => 
  array (
    'id' => '2187',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第四单元 表内乘法（一）',
    'orders' => '707',
  ),
  469 => 
  array (
    'id' => '2188',
    'parent_id' => '2187',
    'subject_id' => '2',
    'name' => '4.1 乘法的初步认识',
    'orders' => '708',
  ),
  470 => 
  array (
    'id' => '2189',
    'parent_id' => '2187',
    'subject_id' => '2',
    'name' => '4.2 2~6的乘法口诀',
    'orders' => '709',
  ),
  471 => 
  array (
    'id' => '2190',
    'parent_id' => '2189',
    'subject_id' => '2',
    'name' => '4.2.1 5的乘法口诀',
    'orders' => '710',
  ),
  472 => 
  array (
    'id' => '2191',
    'parent_id' => '2189',
    'subject_id' => '2',
    'name' => '4.2.2 2、3、4的乘法口诀',
    'orders' => '711',
  ),
  473 => 
  array (
    'id' => '2192',
    'parent_id' => '2189',
    'subject_id' => '2',
    'name' => '4.2.3 乘加 乘减',
    'orders' => '712',
  ),
  474 => 
  array (
    'id' => '2193',
    'parent_id' => '2189',
    'subject_id' => '2',
    'name' => '4.3.4 6的乘法口诀',
    'orders' => '713',
  ),
  475 => 
  array (
    'id' => '2194',
    'parent_id' => '2189',
    'subject_id' => '2',
    'name' => '4.3.5 解决问题',
    'orders' => '714',
  ),
  476 => 
  array (
    'id' => '2195',
    'parent_id' => '2187',
    'subject_id' => '2',
    'name' => '4.3 整理和复习',
    'orders' => '715',
  ),
  477 => 
  array (
    'id' => '2196',
    'parent_id' => '2187',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '716',
  ),
  478 => 
  array (
    'id' => '2197',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '期中检测',
    'orders' => '717',
  ),
  479 => 
  array (
    'id' => '2198',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第五单元 观察物体（一）',
    'orders' => '718',
  ),
  480 => 
  array (
    'id' => '2199',
    'parent_id' => '2198',
    'subject_id' => '2',
    'name' => '5.1 观察物体',
    'orders' => '719',
  ),
  481 => 
  array (
    'id' => '2200',
    'parent_id' => '2198',
    'subject_id' => '2',
    'name' => '5.2 解决问题',
    'orders' => '720',
  ),
  482 => 
  array (
    'id' => '2201',
    'parent_id' => '2198',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '721',
  ),
  483 => 
  array (
    'id' => '2202',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第六单元 表内乘法',
    'orders' => '722',
  ),
  484 => 
  array (
    'id' => '2203',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '6.1 7的乘法口诀',
    'orders' => '723',
  ),
  485 => 
  array (
    'id' => '2204',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '6.2 8的乘法口诀',
    'orders' => '724',
  ),
  486 => 
  array (
    'id' => '2205',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '6.3 解决问题',
    'orders' => '725',
  ),
  487 => 
  array (
    'id' => '2206',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '6.4 9的乘法口诀',
    'orders' => '726',
  ),
  488 => 
  array (
    'id' => '2207',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '6.5 解决问题',
    'orders' => '727',
  ),
  489 => 
  array (
    'id' => '2208',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '6.6 整理和复习',
    'orders' => '728',
  ),
  490 => 
  array (
    'id' => '2209',
    'parent_id' => '2202',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '729',
  ),
  491 => 
  array (
    'id' => '2210',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '量一量，比一比',
    'orders' => '730',
  ),
  492 => 
  array (
    'id' => '2211',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第七单元 认识时间',
    'orders' => '731',
  ),
  493 => 
  array (
    'id' => '2212',
    'parent_id' => '2211',
    'subject_id' => '2',
    'name' => '7.1 认识分和几时几分',
    'orders' => '732',
  ),
  494 => 
  array (
    'id' => '2213',
    'parent_id' => '2211',
    'subject_id' => '2',
    'name' => '7.2 解决问题',
    'orders' => '733',
  ),
  495 => 
  array (
    'id' => '2214',
    'parent_id' => '2211',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '734',
  ),
  496 => 
  array (
    'id' => '2215',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第八单元 数学广角——搭配（一）',
    'orders' => '735',
  ),
  497 => 
  array (
    'id' => '2216',
    'parent_id' => '2215',
    'subject_id' => '2',
    'name' => '8.1 简单的排列',
    'orders' => '736',
  ),
  498 => 
  array (
    'id' => '2217',
    'parent_id' => '2215',
    'subject_id' => '2',
    'name' => '8.2 简单的组合',
    'orders' => '737',
  ),
  499 => 
  array (
    'id' => '2218',
    'parent_id' => '2215',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '738',
  ),
  500 => 
  array (
    'id' => '2219',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '第九单元 总复习',
    'orders' => '739',
  ),
  501 => 
  array (
    'id' => '2220',
    'parent_id' => '2219',
    'subject_id' => '2',
    'name' => '9.1 总复习',
    'orders' => '740',
  ),
  502 => 
  array (
    'id' => '2221',
    'parent_id' => '2219',
    'subject_id' => '2',
    'name' => '第九章检测',
    'orders' => '741',
  ),
  503 => 
  array (
    'id' => '2222',
    'parent_id' => '2159',
    'subject_id' => '2',
    'name' => '期末检测',
    'orders' => '742',
  ),
  504 => 
  array (
    'id' => '2223',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版（2013）二年级下册',
    'orders' => '744',
  ),
  505 => 
  array (
    'id' => '2224',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第一单元 数据收集整理',
    'orders' => '745',
  ),
  506 => 
  array (
    'id' => '2225',
    'parent_id' => '2224',
    'subject_id' => '2',
    'name' => '1.1 数据收集整理',
    'orders' => '746',
  ),
  507 => 
  array (
    'id' => '2226',
    'parent_id' => '2224',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '747',
  ),
  508 => 
  array (
    'id' => '2227',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第二单元 表内除法（一）',
    'orders' => '748',
  ),
  509 => 
  array (
    'id' => '2228',
    'parent_id' => '2227',
    'subject_id' => '2',
    'name' => '2.1 除法的初步认识',
    'orders' => '749',
  ),
  510 => 
  array (
    'id' => '2229',
    'parent_id' => '2228',
    'subject_id' => '2',
    'name' => '2.1.1 平均分',
    'orders' => '750',
  ),
  511 => 
  array (
    'id' => '2230',
    'parent_id' => '2228',
    'subject_id' => '2',
    'name' => '2.1.2 除法',
    'orders' => '751',
  ),
  512 => 
  array (
    'id' => '2231',
    'parent_id' => '2227',
    'subject_id' => '2',
    'name' => '2.2 用2~6的乘法口诀求商',
    'orders' => '752',
  ),
  513 => 
  array (
    'id' => '2232',
    'parent_id' => '2227',
    'subject_id' => '2',
    'name' => '2.3 解决问题',
    'orders' => '753',
  ),
  514 => 
  array (
    'id' => '2233',
    'parent_id' => '2227',
    'subject_id' => '2',
    'name' => '2.4 整理和复习',
    'orders' => '754',
  ),
  515 => 
  array (
    'id' => '2234',
    'parent_id' => '2227',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '755',
  ),
  516 => 
  array (
    'id' => '2235',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第三单元 图形的运动（一）',
    'orders' => '756',
  ),
  517 => 
  array (
    'id' => '2236',
    'parent_id' => '2235',
    'subject_id' => '2',
    'name' => '3.1 图形的运动',
    'orders' => '757',
  ),
  518 => 
  array (
    'id' => '2237',
    'parent_id' => '2235',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '758',
  ),
  519 => 
  array (
    'id' => '2238',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第四单元 表内除法 （二）',
    'orders' => '759',
  ),
  520 => 
  array (
    'id' => '2239',
    'parent_id' => '2238',
    'subject_id' => '2',
    'name' => '4.1 用7、8、9的乘法口诀求商',
    'orders' => '760',
  ),
  521 => 
  array (
    'id' => '2240',
    'parent_id' => '2238',
    'subject_id' => '2',
    'name' => '4.2 整理和复习',
    'orders' => '761',
  ),
  522 => 
  array (
    'id' => '2241',
    'parent_id' => '2238',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '762',
  ),
  523 => 
  array (
    'id' => '2242',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第五单元 混合运算',
    'orders' => '763',
  ),
  524 => 
  array (
    'id' => '2243',
    'parent_id' => '2242',
    'subject_id' => '2',
    'name' => '5.1 混合运算',
    'orders' => '764',
  ),
  525 => 
  array (
    'id' => '2244',
    'parent_id' => '2242',
    'subject_id' => '2',
    'name' => '5.2 解决问题',
    'orders' => '765',
  ),
  526 => 
  array (
    'id' => '2245',
    'parent_id' => '2242',
    'subject_id' => '2',
    'name' => '5.3 整理和复习',
    'orders' => '766',
  ),
  527 => 
  array (
    'id' => '2246',
    'parent_id' => '2242',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '767',
  ),
  528 => 
  array (
    'id' => '2247',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '期中检测',
    'orders' => '768',
  ),
  529 => 
  array (
    'id' => '2248',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第六单元 有余数的除法',
    'orders' => '769',
  ),
  530 => 
  array (
    'id' => '2249',
    'parent_id' => '2248',
    'subject_id' => '2',
    'name' => '6.1 有余数的除法',
    'orders' => '770',
  ),
  531 => 
  array (
    'id' => '2250',
    'parent_id' => '2248',
    'subject_id' => '2',
    'name' => '6.2 解决问题',
    'orders' => '771',
  ),
  532 => 
  array (
    'id' => '2251',
    'parent_id' => '2248',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '772',
  ),
  533 => 
  array (
    'id' => '2252',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第七单元 万以内的认识',
    'orders' => '773',
  ),
  534 => 
  array (
    'id' => '2253',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '7.1 1000以内数的认识',
    'orders' => '774',
  ),
  535 => 
  array (
    'id' => '2254',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '7.2 10000以内数的认识',
    'orders' => '775',
  ),
  536 => 
  array (
    'id' => '2255',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '7.3 比较1000以内的数的大小',
    'orders' => '776',
  ),
  537 => 
  array (
    'id' => '2256',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '7.4 比较10000以内数的大小、近似数',
    'orders' => '777',
  ),
  538 => 
  array (
    'id' => '2257',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '7.5 整百、整千数加减法',
    'orders' => '778',
  ),
  539 => 
  array (
    'id' => '2258',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '7.6 解决问题',
    'orders' => '779',
  ),
  540 => 
  array (
    'id' => '2259',
    'parent_id' => '2252',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '780',
  ),
  541 => 
  array (
    'id' => '2260',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第八单元 克和千克',
    'orders' => '781',
  ),
  542 => 
  array (
    'id' => '2261',
    'parent_id' => '2260',
    'subject_id' => '2',
    'name' => '8.1 克和千克',
    'orders' => '782',
  ),
  543 => 
  array (
    'id' => '2262',
    'parent_id' => '2260',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '783',
  ),
  544 => 
  array (
    'id' => '2263',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第九单元 数学广角——推理',
    'orders' => '784',
  ),
  545 => 
  array (
    'id' => '2264',
    'parent_id' => '2263',
    'subject_id' => '2',
    'name' => '9.1 推理',
    'orders' => '785',
  ),
  546 => 
  array (
    'id' => '2265',
    'parent_id' => '2263',
    'subject_id' => '2',
    'name' => '第九单元检测',
    'orders' => '786',
  ),
  547 => 
  array (
    'id' => '2266',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '第十单元 总复习',
    'orders' => '787',
  ),
  548 => 
  array (
    'id' => '2267',
    'parent_id' => '2266',
    'subject_id' => '2',
    'name' => '10.1 总复习',
    'orders' => '788',
  ),
  549 => 
  array (
    'id' => '2268',
    'parent_id' => '2266',
    'subject_id' => '2',
    'name' => '第十章检测',
    'orders' => '789',
  ),
  550 => 
  array (
    'id' => '2269',
    'parent_id' => '2223',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '790',
  ),
  551 => 
  array (
    'id' => '2270',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版（2013）三年级上册',
    'orders' => '792',
  ),
  552 => 
  array (
    'id' => '2271',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第一单元 时、分、秒',
    'orders' => '793',
  ),
  553 => 
  array (
    'id' => '2272',
    'parent_id' => '2271',
    'subject_id' => '2',
    'name' => '1.1 认识秒',
    'orders' => '794',
  ),
  554 => 
  array (
    'id' => '2273',
    'parent_id' => '2271',
    'subject_id' => '2',
    'name' => '1.2时间的计算',
    'orders' => '795',
  ),
  555 => 
  array (
    'id' => '2274',
    'parent_id' => '2271',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '796',
  ),
  556 => 
  array (
    'id' => '2275',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第二单元 万以内的加法和减法（一）',
    'orders' => '797',
  ),
  557 => 
  array (
    'id' => '2276',
    'parent_id' => '2275',
    'subject_id' => '2',
    'name' => '2.1 两位数的进位加法',
    'orders' => '798',
  ),
  558 => 
  array (
    'id' => '2277',
    'parent_id' => '2275',
    'subject_id' => '2',
    'name' => '2.2 两位数的退位减法',
    'orders' => '799',
  ),
  559 => 
  array (
    'id' => '2278',
    'parent_id' => '2275',
    'subject_id' => '2',
    'name' => '2.3 末尾是0的三位数的加减法',
    'orders' => '800',
  ),
  560 => 
  array (
    'id' => '2279',
    'parent_id' => '2275',
    'subject_id' => '2',
    'name' => '2.4 三位数加减法的估算',
    'orders' => '801',
  ),
  561 => 
  array (
    'id' => '2280',
    'parent_id' => '2275',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '802',
  ),
  562 => 
  array (
    'id' => '2281',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第三单元 测量',
    'orders' => '803',
  ),
  563 => 
  array (
    'id' => '2282',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '3.1 毫米的认识',
    'orders' => '804',
  ),
  564 => 
  array (
    'id' => '2283',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '3.2 分米的认识',
    'orders' => '805',
  ),
  565 => 
  array (
    'id' => '2284',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '3.3 千米的认识',
    'orders' => '806',
  ),
  566 => 
  array (
    'id' => '2285',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '3.4 长度单位的应用',
    'orders' => '807',
  ),
  567 => 
  array (
    'id' => '2286',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '3.5 吨的认识',
    'orders' => '808',
  ),
  568 => 
  array (
    'id' => '2287',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '3.6 质量单位的应用',
    'orders' => '809',
  ),
  569 => 
  array (
    'id' => '2288',
    'parent_id' => '2281',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '810',
  ),
  570 => 
  array (
    'id' => '2289',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第四单元 万以内的加法和减法（二）',
    'orders' => '811',
  ),
  571 => 
  array (
    'id' => '2290',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '4.1 三位数加三位数（不进位、不连续进位）',
    'orders' => '812',
  ),
  572 => 
  array (
    'id' => '2291',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '4.2 三位数的连续进位加法',
    'orders' => '813',
  ),
  573 => 
  array (
    'id' => '2292',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '4.3 三位数的退位减法',
    'orders' => '814',
  ),
  574 => 
  array (
    'id' => '2293',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '4.4 被减数中间或末尾有0的三位数减法',
    'orders' => '815',
  ),
  575 => 
  array (
    'id' => '2294',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '4.5 解决问题',
    'orders' => '816',
  ),
  576 => 
  array (
    'id' => '2295',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '4.6 整理和复习',
    'orders' => '817',
  ),
  577 => 
  array (
    'id' => '2296',
    'parent_id' => '2289',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '818',
  ),
  578 => 
  array (
    'id' => '2297',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '期中测试',
    'orders' => '819',
  ),
  579 => 
  array (
    'id' => '2298',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第五单元 倍的认识',
    'orders' => '820',
  ),
  580 => 
  array (
    'id' => '2299',
    'parent_id' => '2298',
    'subject_id' => '2',
    'name' => '5.1 认识倍',
    'orders' => '821',
  ),
  581 => 
  array (
    'id' => '2300',
    'parent_id' => '2298',
    'subject_id' => '2',
    'name' => '5.2 倍的应用',
    'orders' => '822',
  ),
  582 => 
  array (
    'id' => '2301',
    'parent_id' => '2298',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '823',
  ),
  583 => 
  array (
    'id' => '2302',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第六单元 多位数乘一位数',
    'orders' => '824',
  ),
  584 => 
  array (
    'id' => '2303',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.1 口算乘法',
    'orders' => '825',
  ),
  585 => 
  array (
    'id' => '2304',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.2 笔算乘法',
    'orders' => '826',
  ),
  586 => 
  array (
    'id' => '2305',
    'parent_id' => '2304',
    'subject_id' => '2',
    'name' => '6.2.1 多位数乘一位数的笔算乘法（不进位）',
    'orders' => '827',
  ),
  587 => 
  array (
    'id' => '2306',
    'parent_id' => '2304',
    'subject_id' => '2',
    'name' => '6.2.2 多位数乘一位数的笔算乘法（进位）',
    'orders' => '828',
  ),
  588 => 
  array (
    'id' => '2307',
    'parent_id' => '2304',
    'subject_id' => '2',
    'name' => '6.2.3 多位数乘一位数的笔算乘法（连续进位）',
    'orders' => '829',
  ),
  589 => 
  array (
    'id' => '2308',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.3 中间有0的多位数乘一位数',
    'orders' => '830',
  ),
  590 => 
  array (
    'id' => '2309',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.4 末尾有0的多位数乘一位数',
    'orders' => '831',
  ),
  591 => 
  array (
    'id' => '2310',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.5 估算',
    'orders' => '832',
  ),
  592 => 
  array (
    'id' => '2311',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.6 乘除混合运算',
    'orders' => '833',
  ),
  593 => 
  array (
    'id' => '2312',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '6.7 整理和复习',
    'orders' => '834',
  ),
  594 => 
  array (
    'id' => '2313',
    'parent_id' => '2302',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '835',
  ),
  595 => 
  array (
    'id' => '2314',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第七单元 长方形和正方形',
    'orders' => '836',
  ),
  596 => 
  array (
    'id' => '2315',
    'parent_id' => '2314',
    'subject_id' => '2',
    'name' => '7.1 认识四边形',
    'orders' => '837',
  ),
  597 => 
  array (
    'id' => '2316',
    'parent_id' => '2314',
    'subject_id' => '2',
    'name' => '7.2 认识长方形和正方形',
    'orders' => '838',
  ),
  598 => 
  array (
    'id' => '2317',
    'parent_id' => '2314',
    'subject_id' => '2',
    'name' => '7.3 认识周长',
    'orders' => '839',
  ),
  599 => 
  array (
    'id' => '2318',
    'parent_id' => '2314',
    'subject_id' => '2',
    'name' => '7.4 计算长方形和正方形的周长',
    'orders' => '840',
  ),
  600 => 
  array (
    'id' => '2319',
    'parent_id' => '2314',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '841',
  ),
  601 => 
  array (
    'id' => '2320',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第八单元 分数的初步认识',
    'orders' => '842',
  ),
  602 => 
  array (
    'id' => '2321',
    'parent_id' => '2320',
    'subject_id' => '2',
    'name' => '8.1 几分之一',
    'orders' => '843',
  ),
  603 => 
  array (
    'id' => '2322',
    'parent_id' => '2320',
    'subject_id' => '2',
    'name' => '8.2 几分之几',
    'orders' => '844',
  ),
  604 => 
  array (
    'id' => '2323',
    'parent_id' => '2320',
    'subject_id' => '2',
    'name' => '8.3 分数的简单计算',
    'orders' => '845',
  ),
  605 => 
  array (
    'id' => '2324',
    'parent_id' => '2320',
    'subject_id' => '2',
    'name' => '8.4 分数的简单应用',
    'orders' => '846',
  ),
  606 => 
  array (
    'id' => '2325',
    'parent_id' => '2320',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '847',
  ),
  607 => 
  array (
    'id' => '2326',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第九单元 数学广角——集合',
    'orders' => '848',
  ),
  608 => 
  array (
    'id' => '2327',
    'parent_id' => '2326',
    'subject_id' => '2',
    'name' => '9.1  数学广角——集合',
    'orders' => '849',
  ),
  609 => 
  array (
    'id' => '2328',
    'parent_id' => '2326',
    'subject_id' => '2',
    'name' => '第九单元检测',
    'orders' => '850',
  ),
  610 => 
  array (
    'id' => '2329',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '第十单元 总复习',
    'orders' => '851',
  ),
  611 => 
  array (
    'id' => '2330',
    'parent_id' => '2329',
    'subject_id' => '2',
    'name' => '10.1 总复习',
    'orders' => '852',
  ),
  612 => 
  array (
    'id' => '2331',
    'parent_id' => '2329',
    'subject_id' => '2',
    'name' => '第十章检测',
    'orders' => '853',
  ),
  613 => 
  array (
    'id' => '2332',
    'parent_id' => '2270',
    'subject_id' => '2',
    'name' => '期末检测',
    'orders' => '854',
  ),
  614 => 
  array (
    'id' => '2333',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版三年级下册',
    'orders' => '856',
  ),
  615 => 
  array (
    'id' => '2334',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第一单元 位置和方向',
    'orders' => '857',
  ),
  616 => 
  array (
    'id' => '2335',
    'parent_id' => '2334',
    'subject_id' => '2',
    'name' => '1.1 认识东、南、西、北',
    'orders' => '858',
  ),
  617 => 
  array (
    'id' => '2336',
    'parent_id' => '2334',
    'subject_id' => '2',
    'name' => '1.2 认识简单的路线图（四个方向）',
    'orders' => '859',
  ),
  618 => 
  array (
    'id' => '2337',
    'parent_id' => '2334',
    'subject_id' => '2',
    'name' => '1.3 认识东北、东南、西北、西南',
    'orders' => '860',
  ),
  619 => 
  array (
    'id' => '2338',
    'parent_id' => '2334',
    'subject_id' => '2',
    'name' => '1.4 认识简单的路线图（八个方向）',
    'orders' => '861',
  ),
  620 => 
  array (
    'id' => '2339',
    'parent_id' => '2334',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '862',
  ),
  621 => 
  array (
    'id' => '2340',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第二单元 除数是一位数的除法',
    'orders' => '863',
  ),
  622 => 
  array (
    'id' => '2341',
    'parent_id' => '2340',
    'subject_id' => '2',
    'name' => '2.1 口算除法',
    'orders' => '864',
  ),
  623 => 
  array (
    'id' => '2342',
    'parent_id' => '2341',
    'subject_id' => '2',
    'name' => '2.1.1 一位数除商是整十、  整百、  整千的数',
    'orders' => '865',
  ),
  624 => 
  array (
    'id' => '2343',
    'parent_id' => '2341',
    'subject_id' => '2',
    'name' => '2.1.2 除法的估算',
    'orders' => '866',
  ),
  625 => 
  array (
    'id' => '2344',
    'parent_id' => '2340',
    'subject_id' => '2',
    'name' => '2.2 笔算除法',
    'orders' => '867',
  ),
  626 => 
  array (
    'id' => '2345',
    'parent_id' => '2344',
    'subject_id' => '2',
    'name' => '2.2.1 一位数除两位数',
    'orders' => '868',
  ),
  627 => 
  array (
    'id' => '2346',
    'parent_id' => '2344',
    'subject_id' => '2',
    'name' => '2.2.2 一位数除三位数',
    'orders' => '869',
  ),
  628 => 
  array (
    'id' => '2347',
    'parent_id' => '2344',
    'subject_id' => '2',
    'name' => '2.2.3 除法的验算',
    'orders' => '870',
  ),
  629 => 
  array (
    'id' => '2348',
    'parent_id' => '2344',
    'subject_id' => '2',
    'name' => '2.2.4 商中间有零和末尾有零的除法',
    'orders' => '871',
  ),
  630 => 
  array (
    'id' => '2349',
    'parent_id' => '2340',
    'subject_id' => '2',
    'name' => '2.3 整理和复习',
    'orders' => '872',
  ),
  631 => 
  array (
    'id' => '2350',
    'parent_id' => '2340',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '873',
  ),
  632 => 
  array (
    'id' => '2351',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第三单元 统计',
    'orders' => '874',
  ),
  633 => 
  array (
    'id' => '2352',
    'parent_id' => '2351',
    'subject_id' => '2',
    'name' => '3.1 简单的数据分析',
    'orders' => '875',
  ),
  634 => 
  array (
    'id' => '2353',
    'parent_id' => '2351',
    'subject_id' => '2',
    'name' => '3.2 平均数',
    'orders' => '876',
  ),
  635 => 
  array (
    'id' => '2354',
    'parent_id' => '2351',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '877',
  ),
  636 => 
  array (
    'id' => '2360',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第四单元 两位数乘两位数',
    'orders' => '878',
  ),
  637 => 
  array (
    'id' => '2361',
    'parent_id' => '2360',
    'subject_id' => '2',
    'name' => '4.1 口算乘法',
    'orders' => '879',
  ),
  638 => 
  array (
    'id' => '2362',
    'parent_id' => '2361',
    'subject_id' => '2',
    'name' => '4.1.1 口算乘法',
    'orders' => '880',
  ),
  639 => 
  array (
    'id' => '2363',
    'parent_id' => '2361',
    'subject_id' => '2',
    'name' => '4.1.2 两位数乘两位数的乘法估算',
    'orders' => '881',
  ),
  640 => 
  array (
    'id' => '2364',
    'parent_id' => '2360',
    'subject_id' => '2',
    'name' => '4.2 笔算乘法',
    'orders' => '882',
  ),
  641 => 
  array (
    'id' => '2365',
    'parent_id' => '2364',
    'subject_id' => '2',
    'name' => '4.2.1 不进位的笔算乘法',
    'orders' => '883',
  ),
  642 => 
  array (
    'id' => '2366',
    'parent_id' => '2364',
    'subject_id' => '2',
    'name' => '4.2.2 进位的笔算乘法',
    'orders' => '884',
  ),
  643 => 
  array (
    'id' => '2369',
    'parent_id' => '2360',
    'subject_id' => '2',
    'name' => '4.3乘法两步计算解决问题',
    'orders' => '885',
  ),
  644 => 
  array (
    'id' => '2370',
    'parent_id' => '2360',
    'subject_id' => '2',
    'name' => '4.4 除法两步计算解决问题',
    'orders' => '886',
  ),
  645 => 
  array (
    'id' => '2367',
    'parent_id' => '2360',
    'subject_id' => '2',
    'name' => '4.5 整理和复习',
    'orders' => '887',
  ),
  646 => 
  array (
    'id' => '2368',
    'parent_id' => '2360',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '888',
  ),
  647 => 
  array (
    'id' => '2371',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第五单元 面积',
    'orders' => '889',
  ),
  648 => 
  array (
    'id' => '2372',
    'parent_id' => '2371',
    'subject_id' => '2',
    'name' => '5.1 面积和面积单位',
    'orders' => '890',
  ),
  649 => 
  array (
    'id' => '2373',
    'parent_id' => '2372',
    'subject_id' => '2',
    'name' => '5.1.1 面积和面积单位',
    'orders' => '891',
  ),
  650 => 
  array (
    'id' => '2374',
    'parent_id' => '2372',
    'subject_id' => '2',
    'name' => '5.1.2 长度单位和面积单位的对比',
    'orders' => '892',
  ),
  651 => 
  array (
    'id' => '2375',
    'parent_id' => '2371',
    'subject_id' => '2',
    'name' => '5.2 长方形、正方形面积的计算',
    'orders' => '893',
  ),
  652 => 
  array (
    'id' => '2376',
    'parent_id' => '2375',
    'subject_id' => '2',
    'name' => '5.2.1 长方形、正方形面积的计算',
    'orders' => '894',
  ),
  653 => 
  array (
    'id' => '2377',
    'parent_id' => '2375',
    'subject_id' => '2',
    'name' => '5.2.2 长方形、正方形面积计算的应用',
    'orders' => '895',
  ),
  654 => 
  array (
    'id' => '2378',
    'parent_id' => '2371',
    'subject_id' => '2',
    'name' => '5.3 面积单位间间的进率',
    'orders' => '896',
  ),
  655 => 
  array (
    'id' => '2379',
    'parent_id' => '2371',
    'subject_id' => '2',
    'name' => '5.4 公顷、平方千米',
    'orders' => '897',
  ),
  656 => 
  array (
    'id' => '2380',
    'parent_id' => '2371',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '898',
  ),
  657 => 
  array (
    'id' => '2355',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第六单元 年、月、日',
    'orders' => '899',
  ),
  658 => 
  array (
    'id' => '2356',
    'parent_id' => '2355',
    'subject_id' => '2',
    'name' => '6.1 年、月、日',
    'orders' => '900',
  ),
  659 => 
  array (
    'id' => '2357',
    'parent_id' => '2355',
    'subject_id' => '2',
    'name' => '6.2 24小时计时法',
    'orders' => '901',
  ),
  660 => 
  array (
    'id' => '2358',
    'parent_id' => '2355',
    'subject_id' => '2',
    'name' => '6.3 制作年历',
    'orders' => '902',
  ),
  661 => 
  array (
    'id' => '2359',
    'parent_id' => '2355',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '903',
  ),
  662 => 
  array (
    'id' => '2381',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第七单元 小数的初步认识',
    'orders' => '904',
  ),
  663 => 
  array (
    'id' => '2382',
    'parent_id' => '2381',
    'subject_id' => '2',
    'name' => '7.1 认识小数',
    'orders' => '905',
  ),
  664 => 
  array (
    'id' => '2383',
    'parent_id' => '2382',
    'subject_id' => '2',
    'name' => '7.1.1 认识小数',
    'orders' => '906',
  ),
  665 => 
  array (
    'id' => '2384',
    'parent_id' => '2382',
    'subject_id' => '2',
    'name' => '7.1.2 小数的大小比较',
    'orders' => '907',
  ),
  666 => 
  array (
    'id' => '2385',
    'parent_id' => '2381',
    'subject_id' => '2',
    'name' => '7.2 简单的小数加、减法',
    'orders' => '908',
  ),
  667 => 
  array (
    'id' => '2386',
    'parent_id' => '2381',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '909',
  ),
  668 => 
  array (
    'id' => '2387',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第八单元 数学广角',
    'orders' => '910',
  ),
  669 => 
  array (
    'id' => '2388',
    'parent_id' => '2387',
    'subject_id' => '2',
    'name' => '8.1 数学广角（1）',
    'orders' => '911',
  ),
  670 => 
  array (
    'id' => '2389',
    'parent_id' => '2387',
    'subject_id' => '2',
    'name' => '8.2 数学广角（二）',
    'orders' => '912',
  ),
  671 => 
  array (
    'id' => '2390',
    'parent_id' => '2387',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '913',
  ),
  672 => 
  array (
    'id' => '2391',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '第九单元 总复习',
    'orders' => '914',
  ),
  673 => 
  array (
    'id' => '2393',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.1 位置和方向',
    'orders' => '915',
  ),
  674 => 
  array (
    'id' => '2394',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.2 除数是一位数的除法',
    'orders' => '916',
  ),
  675 => 
  array (
    'id' => '2395',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.3 两位数乘两位数',
    'orders' => '917',
  ),
  676 => 
  array (
    'id' => '2396',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.4 统计',
    'orders' => '918',
  ),
  677 => 
  array (
    'id' => '2398',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.5 面积',
    'orders' => '919',
  ),
  678 => 
  array (
    'id' => '2397',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.6年、月、日',
    'orders' => '920',
  ),
  679 => 
  array (
    'id' => '2399',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.7 小数的初步认识',
    'orders' => '921',
  ),
  680 => 
  array (
    'id' => '2392',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.8解决问题（一）',
    'orders' => '922',
  ),
  681 => 
  array (
    'id' => '2400',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '9.9 解决问题（二）',
    'orders' => '924',
  ),
  682 => 
  array (
    'id' => '2401',
    'parent_id' => '2391',
    'subject_id' => '2',
    'name' => '第九章检测',
    'orders' => '925',
  ),
  683 => 
  array (
    'id' => '2402',
    'parent_id' => '2333',
    'subject_id' => '2',
    'name' => '期末检测',
    'orders' => '926',
  ),
  684 => 
  array (
    'id' => '2403',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版四年级上册',
    'orders' => '928',
  ),
  685 => 
  array (
    'id' => '2404',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第一单元 大数的认识',
    'orders' => '929',
  ),
  686 => 
  array (
    'id' => '2405',
    'parent_id' => '2404',
    'subject_id' => '2',
    'name' => '1.1 亿以内数的认识',
    'orders' => '930',
  ),
  687 => 
  array (
    'id' => '2406',
    'parent_id' => '2405',
    'subject_id' => '2',
    'name' => '1.1.1 认识亿以内数的计数单位、进率以及数位、数级',
    'orders' => '931',
  ),
  688 => 
  array (
    'id' => '2407',
    'parent_id' => '2405',
    'subject_id' => '2',
    'name' => '1.1.2 亿以内数的读法',
    'orders' => '932',
  ),
  689 => 
  array (
    'id' => '2408',
    'parent_id' => '2405',
    'subject_id' => '2',
    'name' => '1.1.3 亿以内数的写法',
    'orders' => '933',
  ),
  690 => 
  array (
    'id' => '2409',
    'parent_id' => '2405',
    'subject_id' => '2',
    'name' => '1.1.4 亿以内数的大小比较',
    'orders' => '934',
  ),
  691 => 
  array (
    'id' => '2410',
    'parent_id' => '2405',
    'subject_id' => '2',
    'name' => '1.1.5 亿以内数的改写',
    'orders' => '935',
  ),
  692 => 
  array (
    'id' => '2411',
    'parent_id' => '2404',
    'subject_id' => '2',
    'name' => '1.2 数的产生、十进制计数法',
    'orders' => '936',
  ),
  693 => 
  array (
    'id' => '2412',
    'parent_id' => '2404',
    'subject_id' => '2',
    'name' => '1.3 亿以上数的认识',
    'orders' => '937',
  ),
  694 => 
  array (
    'id' => '2413',
    'parent_id' => '2412',
    'subject_id' => '2',
    'name' => '1.3.1 亿以上数的读写和写法',
    'orders' => '938',
  ),
  695 => 
  array (
    'id' => '2414',
    'parent_id' => '2412',
    'subject_id' => '2',
    'name' => '1.3.2 亿以上数的改写和求近似数',
    'orders' => '939',
  ),
  696 => 
  array (
    'id' => '2415',
    'parent_id' => '2404',
    'subject_id' => '2',
    'name' => '1.4 计算工具的认识、算盘、计算器',
    'orders' => '940',
  ),
  697 => 
  array (
    'id' => '2416',
    'parent_id' => '2404',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '941',
  ),
  698 => 
  array (
    'id' => '2417',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第二单元 公顷和平方千米',
    'orders' => '942',
  ),
  699 => 
  array (
    'id' => '2418',
    'parent_id' => '2417',
    'subject_id' => '2',
    'name' => '2.1 公顷的认识',
    'orders' => '943',
  ),
  700 => 
  array (
    'id' => '2419',
    'parent_id' => '2417',
    'subject_id' => '2',
    'name' => '2.2 平方千米的认识',
    'orders' => '944',
  ),
  701 => 
  array (
    'id' => '2420',
    'parent_id' => '2417',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '945',
  ),
  702 => 
  array (
    'id' => '2421',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第三单元 角的度量',
    'orders' => '946',
  ),
  703 => 
  array (
    'id' => '2422',
    'parent_id' => '2421',
    'subject_id' => '2',
    'name' => '3.1 线段 直线 射线',
    'orders' => '947',
  ),
  704 => 
  array (
    'id' => '2423',
    'parent_id' => '2421',
    'subject_id' => '2',
    'name' => '3.2 角',
    'orders' => '948',
  ),
  705 => 
  array (
    'id' => '2424',
    'parent_id' => '2421',
    'subject_id' => '2',
    'name' => '3.3 角的度量',
    'orders' => '949',
  ),
  706 => 
  array (
    'id' => '2425',
    'parent_id' => '2421',
    'subject_id' => '2',
    'name' => '3.4 角的分类',
    'orders' => '950',
  ),
  707 => 
  array (
    'id' => '2426',
    'parent_id' => '2421',
    'subject_id' => '2',
    'name' => '3.5 画角',
    'orders' => '951',
  ),
  708 => 
  array (
    'id' => '2427',
    'parent_id' => '2421',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '952',
  ),
  709 => 
  array (
    'id' => '2428',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第四单元 三位数乘两位数',
    'orders' => '953',
  ),
  710 => 
  array (
    'id' => '2429',
    'parent_id' => '2428',
    'subject_id' => '2',
    'name' => '4.1 三位数乘两位数的笔算方法',
    'orders' => '954',
  ),
  711 => 
  array (
    'id' => '2430',
    'parent_id' => '2428',
    'subject_id' => '2',
    'name' => '4.2 因数中间或末尾有0的乘法的笔算方法',
    'orders' => '955',
  ),
  712 => 
  array (
    'id' => '2431',
    'parent_id' => '2428',
    'subject_id' => '2',
    'name' => '4.3 积的变化规律',
    'orders' => '956',
  ),
  713 => 
  array (
    'id' => '2432',
    'parent_id' => '2428',
    'subject_id' => '2',
    'name' => '4.4 认识常见的数量关系',
    'orders' => '957',
  ),
  714 => 
  array (
    'id' => '2433',
    'parent_id' => '2428',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '958',
  ),
  715 => 
  array (
    'id' => '2434',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '期中检测',
    'orders' => '959',
  ),
  716 => 
  array (
    'id' => '2435',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第五单元 平行四边形和梯形',
    'orders' => '960',
  ),
  717 => 
  array (
    'id' => '2436',
    'parent_id' => '2435',
    'subject_id' => '2',
    'name' => '5.1 平行与垂直',
    'orders' => '961',
  ),
  718 => 
  array (
    'id' => '2437',
    'parent_id' => '2435',
    'subject_id' => '2',
    'name' => '5.2 垂线的画法',
    'orders' => '962',
  ),
  719 => 
  array (
    'id' => '2438',
    'parent_id' => '2435',
    'subject_id' => '2',
    'name' => '5.3 长方形、正方形的画法',
    'orders' => '963',
  ),
  720 => 
  array (
    'id' => '2439',
    'parent_id' => '2435',
    'subject_id' => '2',
    'name' => '5.4 平行四边系和梯形',
    'orders' => '964',
  ),
  721 => 
  array (
    'id' => '2440',
    'parent_id' => '2439',
    'subject_id' => '2',
    'name' => '5.4.1 平行四边形的认识',
    'orders' => '965',
  ),
  722 => 
  array (
    'id' => '2441',
    'parent_id' => '2439',
    'subject_id' => '2',
    'name' => '5.4.2 梯形的认识',
    'orders' => '966',
  ),
  723 => 
  array (
    'id' => '2442',
    'parent_id' => '2435',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '967',
  ),
  724 => 
  array (
    'id' => '2443',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第六单元 除数是两位数的除法',
    'orders' => '968',
  ),
  725 => 
  array (
    'id' => '2444',
    'parent_id' => '2443',
    'subject_id' => '2',
    'name' => '6.1 口算除法',
    'orders' => '969',
  ),
  726 => 
  array (
    'id' => '2445',
    'parent_id' => '2443',
    'subject_id' => '2',
    'name' => '6.2 笔算除法',
    'orders' => '970',
  ),
  727 => 
  array (
    'id' => '2446',
    'parent_id' => '2445',
    'subject_id' => '2',
    'name' => '6.2.1 商是一位数的笔算除法（除数是整十数）',
    'orders' => '971',
  ),
  728 => 
  array (
    'id' => '2447',
    'parent_id' => '2445',
    'subject_id' => '2',
    'name' => '6.2.2 商是一位数的笔算除法（除数是非整十数）（一）',
    'orders' => '972',
  ),
  729 => 
  array (
    'id' => '2448',
    'parent_id' => '2445',
    'subject_id' => '2',
    'name' => '6.2.3 商是一位数的笔算除法（除数是非整十数）（二）',
    'orders' => '973',
  ),
  730 => 
  array (
    'id' => '2449',
    'parent_id' => '2445',
    'subject_id' => '2',
    'name' => '6.2.4 商是两位数的笔算除法',
    'orders' => '974',
  ),
  731 => 
  array (
    'id' => '2450',
    'parent_id' => '2445',
    'subject_id' => '2',
    'name' => '6.2.5 商的变化规律',
    'orders' => '975',
  ),
  732 => 
  array (
    'id' => '2451',
    'parent_id' => '2445',
    'subject_id' => '2',
    'name' => '6.2.6 应用商不变的规律简算',
    'orders' => '976',
  ),
  733 => 
  array (
    'id' => '2452',
    'parent_id' => '2443',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '977',
  ),
  734 => 
  array (
    'id' => '2453',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第七单元 条形统计图',
    'orders' => '978',
  ),
  735 => 
  array (
    'id' => '2454',
    'parent_id' => '2453',
    'subject_id' => '2',
    'name' => '7.1 认识条形统计图（一）',
    'orders' => '979',
  ),
  736 => 
  array (
    'id' => '2455',
    'parent_id' => '2453',
    'subject_id' => '2',
    'name' => '7.2 认识条形统计图（二）',
    'orders' => '980',
  ),
  737 => 
  array (
    'id' => '2456',
    'parent_id' => '2453',
    'subject_id' => '2',
    'name' => '7.3 认识条形统计图（三）',
    'orders' => '981',
  ),
  738 => 
  array (
    'id' => '2457',
    'parent_id' => '2453',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '982',
  ),
  739 => 
  array (
    'id' => '2458',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第八单元 数学广角——优化',
    'orders' => '983',
  ),
  740 => 
  array (
    'id' => '2459',
    'parent_id' => '2458',
    'subject_id' => '2',
    'name' => '8.1 优化时间',
    'orders' => '984',
  ),
  741 => 
  array (
    'id' => '2460',
    'parent_id' => '2458',
    'subject_id' => '2',
    'name' => '8.2 数学中的对策问题',
    'orders' => '985',
  ),
  742 => 
  array (
    'id' => '2461',
    'parent_id' => '2458',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '986',
  ),
  743 => 
  array (
    'id' => '2462',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '第九单元 总复习',
    'orders' => '987',
  ),
  744 => 
  array (
    'id' => '2463',
    'parent_id' => '2462',
    'subject_id' => '2',
    'name' => '9.1 数与代数',
    'orders' => '988',
  ),
  745 => 
  array (
    'id' => '2464',
    'parent_id' => '2462',
    'subject_id' => '2',
    'name' => '9.2 图形与几何',
    'orders' => '989',
  ),
  746 => 
  array (
    'id' => '2465',
    'parent_id' => '2462',
    'subject_id' => '2',
    'name' => '9.3 统计',
    'orders' => '990',
  ),
  747 => 
  array (
    'id' => '2466',
    'parent_id' => '2462',
    'subject_id' => '2',
    'name' => '第九单元检测',
    'orders' => '991',
  ),
  748 => 
  array (
    'id' => '2467',
    'parent_id' => '2403',
    'subject_id' => '2',
    'name' => '期末检测',
    'orders' => '992',
  ),
  749 => 
  array (
    'id' => '2468',
    'parent_id' => '1049',
    'subject_id' => '2',
    'name' => '人教版四年级下册',
    'orders' => '994',
  ),
  750 => 
  array (
    'id' => '2469',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第一单元 四则运算',
    'orders' => '995',
  ),
  751 => 
  array (
    'id' => '2470',
    'parent_id' => '2469',
    'subject_id' => '2',
    'name' => '1.1 加减混合运算',
    'orders' => '996',
  ),
  752 => 
  array (
    'id' => '2471',
    'parent_id' => '2469',
    'subject_id' => '2',
    'name' => '1.2 乘除混合运算',
    'orders' => '997',
  ),
  753 => 
  array (
    'id' => '2472',
    'parent_id' => '2469',
    'subject_id' => '2',
    'name' => '1.3 含两级运算的混合运算',
    'orders' => '998',
  ),
  754 => 
  array (
    'id' => '2473',
    'parent_id' => '2469',
    'subject_id' => '2',
    'name' => '1.4 带小括号的混合运算',
    'orders' => '999',
  ),
  755 => 
  array (
    'id' => '2474',
    'parent_id' => '2469',
    'subject_id' => '2',
    'name' => '1.5 有关0的运算',
    'orders' => '1000',
  ),
  756 => 
  array (
    'id' => '2475',
    'parent_id' => '2469',
    'subject_id' => '2',
    'name' => '第一单元检测',
    'orders' => '1001',
  ),
  757 => 
  array (
    'id' => '2476',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第二单元 位置与方向',
    'orders' => '1002',
  ),
  758 => 
  array (
    'id' => '2477',
    'parent_id' => '2476',
    'subject_id' => '2',
    'name' => '2.1 确定位置与方向',
    'orders' => '1003',
  ),
  759 => 
  array (
    'id' => '2478',
    'parent_id' => '2476',
    'subject_id' => '2',
    'name' => '2.2 认识路线',
    'orders' => '1004',
  ),
  760 => 
  array (
    'id' => '2479',
    'parent_id' => '2476',
    'subject_id' => '2',
    'name' => '2.3位置关系的相对性',
    'orders' => '1005',
  ),
  761 => 
  array (
    'id' => '2480',
    'parent_id' => '2476',
    'subject_id' => '2',
    'name' => '第二单元检测',
    'orders' => '1006',
  ),
  762 => 
  array (
    'id' => '2481',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第三单元 运算定律与简便计算',
    'orders' => '1007',
  ),
  763 => 
  array (
    'id' => '2482',
    'parent_id' => '2481',
    'subject_id' => '2',
    'name' => '3.1 加法运算定律',
    'orders' => '1008',
  ),
  764 => 
  array (
    'id' => '2483',
    'parent_id' => '2482',
    'subject_id' => '2',
    'name' => '3.1.1 加法交换律',
    'orders' => '1009',
  ),
  765 => 
  array (
    'id' => '2484',
    'parent_id' => '2482',
    'subject_id' => '2',
    'name' => '3.1.2 加法结合律',
    'orders' => '1010',
  ),
  766 => 
  array (
    'id' => '2485',
    'parent_id' => '2482',
    'subject_id' => '2',
    'name' => '3.1.3 加法运算律',
    'orders' => '1011',
  ),
  767 => 
  array (
    'id' => '2486',
    'parent_id' => '2481',
    'subject_id' => '2',
    'name' => '3.2 乘法运算定律',
    'orders' => '1012',
  ),
  768 => 
  array (
    'id' => '2487',
    'parent_id' => '2486',
    'subject_id' => '2',
    'name' => '3.2.1 乘法交换律',
    'orders' => '1013',
  ),
  769 => 
  array (
    'id' => '2488',
    'parent_id' => '2486',
    'subject_id' => '2',
    'name' => '3.2.2 乘法结合律',
    'orders' => '1014',
  ),
  770 => 
  array (
    'id' => '2489',
    'parent_id' => '2486',
    'subject_id' => '2',
    'name' => '3.2.3 乘法分配律',
    'orders' => '1015',
  ),
  771 => 
  array (
    'id' => '2490',
    'parent_id' => '2481',
    'subject_id' => '2',
    'name' => '3.3 简便运算',
    'orders' => '1016',
  ),
  772 => 
  array (
    'id' => '2491',
    'parent_id' => '2490',
    'subject_id' => '2',
    'name' => '3.3.1 连减的简便计算',
    'orders' => '1017',
  ),
  773 => 
  array (
    'id' => '2492',
    'parent_id' => '2490',
    'subject_id' => '2',
    'name' => '3.3.2 加减计算的灵活运用',
    'orders' => '1018',
  ),
  774 => 
  array (
    'id' => '2493',
    'parent_id' => '2490',
    'subject_id' => '2',
    'name' => '3.3.3 连除的简便计算',
    'orders' => '1019',
  ),
  775 => 
  array (
    'id' => '2494',
    'parent_id' => '2490',
    'subject_id' => '2',
    'name' => '3.3.4 乘除的灵活运用',
    'orders' => '1020',
  ),
  776 => 
  array (
    'id' => '2495',
    'parent_id' => '2490',
    'subject_id' => '2',
    'name' => '3.3.5 乘加的灵活运用',
    'orders' => '1021',
  ),
  777 => 
  array (
    'id' => '2496',
    'parent_id' => '2481',
    'subject_id' => '2',
    'name' => '第三单元检测',
    'orders' => '1022',
  ),
  778 => 
  array (
    'id' => '2497',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第四单元 小数的意义和性质',
    'orders' => '1023',
  ),
  779 => 
  array (
    'id' => '2498',
    'parent_id' => '2497',
    'subject_id' => '2',
    'name' => '4.1 小数的意义和读写法',
    'orders' => '1024',
  ),
  780 => 
  array (
    'id' => '2499',
    'parent_id' => '2498',
    'subject_id' => '2',
    'name' => '4.1.1 小数的产生和意义',
    'orders' => '1025',
  ),
  781 => 
  array (
    'id' => '2500',
    'parent_id' => '2498',
    'subject_id' => '2',
    'name' => '4.1.2 小数的读法和写法',
    'orders' => '1026',
  ),
  782 => 
  array (
    'id' => '2501',
    'parent_id' => '2497',
    'subject_id' => '2',
    'name' => '4.2 小数的性质和大小比较',
    'orders' => '1027',
  ),
  783 => 
  array (
    'id' => '2502',
    'parent_id' => '2501',
    'subject_id' => '2',
    'name' => '4.2.1 小数的性质',
    'orders' => '1028',
  ),
  784 => 
  array (
    'id' => '2503',
    'parent_id' => '2501',
    'subject_id' => '2',
    'name' => '4.2.2 小数的大小比较',
    'orders' => '1029',
  ),
  785 => 
  array (
    'id' => '2504',
    'parent_id' => '2501',
    'subject_id' => '2',
    'name' => '4.2.3 小数点移动',
    'orders' => '1030',
  ),
  786 => 
  array (
    'id' => '2505',
    'parent_id' => '2497',
    'subject_id' => '2',
    'name' => '4.3 生活中的小数',
    'orders' => '1031',
  ),
  787 => 
  array (
    'id' => '2506',
    'parent_id' => '2497',
    'subject_id' => '2',
    'name' => '4.4 求一个数的近似数',
    'orders' => '1032',
  ),
  788 => 
  array (
    'id' => '2507',
    'parent_id' => '2506',
    'subject_id' => '2',
    'name' => '4.4.1 用四舍五入法求一个小数的近似数',
    'orders' => '1033',
  ),
  789 => 
  array (
    'id' => '2508',
    'parent_id' => '2506',
    'subject_id' => '2',
    'name' => '4.4.2 改写用“万”或“亿”作单位的数',
    'orders' => '1034',
  ),
  790 => 
  array (
    'id' => '2509',
    'parent_id' => '2497',
    'subject_id' => '2',
    'name' => '第四单元检测',
    'orders' => '1035',
  ),
  791 => 
  array (
    'id' => '2510',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '期中检测',
    'orders' => '1036',
  ),
  792 => 
  array (
    'id' => '2511',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第五单元',
    'orders' => '1037',
  ),
  793 => 
  array (
    'id' => '2512',
    'parent_id' => '2511',
    'subject_id' => '2',
    'name' => '5.1 三角形的特性',
    'orders' => '1038',
  ),
  794 => 
  array (
    'id' => '2513',
    'parent_id' => '2511',
    'subject_id' => '2',
    'name' => '5.2 三角形的分类',
    'orders' => '1039',
  ),
  795 => 
  array (
    'id' => '2514',
    'parent_id' => '2511',
    'subject_id' => '2',
    'name' => '5.3 三角形的内角和',
    'orders' => '1040',
  ),
  796 => 
  array (
    'id' => '2515',
    'parent_id' => '2511',
    'subject_id' => '2',
    'name' => '5.4 图形的拼组',
    'orders' => '1041',
  ),
  797 => 
  array (
    'id' => '2516',
    'parent_id' => '2511',
    'subject_id' => '2',
    'name' => '第五单元检测',
    'orders' => '1042',
  ),
  798 => 
  array (
    'id' => '2517',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第六单元 小数的加法和减法',
    'orders' => '1043',
  ),
  799 => 
  array (
    'id' => '2518',
    'parent_id' => '2517',
    'subject_id' => '2',
    'name' => '6.1 小数的加法和减法',
    'orders' => '1044',
  ),
  800 => 
  array (
    'id' => '2519',
    'parent_id' => '2517',
    'subject_id' => '2',
    'name' => '6.2 小数加减法的混合运算',
    'orders' => '1045',
  ),
  801 => 
  array (
    'id' => '2520',
    'parent_id' => '2517',
    'subject_id' => '2',
    'name' => '6.3 小数加减法的简便算法',
    'orders' => '1046',
  ),
  802 => 
  array (
    'id' => '2521',
    'parent_id' => '2517',
    'subject_id' => '2',
    'name' => '第六单元检测',
    'orders' => '1047',
  ),
  803 => 
  array (
    'id' => '2522',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第七单元 统计',
    'orders' => '1048',
  ),
  804 => 
  array (
    'id' => '2523',
    'parent_id' => '2522',
    'subject_id' => '2',
    'name' => '7.1 折线统计图',
    'orders' => '1049',
  ),
  805 => 
  array (
    'id' => '2524',
    'parent_id' => '2522',
    'subject_id' => '2',
    'name' => '第七单元检测',
    'orders' => '1050',
  ),
  806 => 
  array (
    'id' => '2525',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第八单元 数学广角',
    'orders' => '1051',
  ),
  807 => 
  array (
    'id' => '2526',
    'parent_id' => '2525',
    'subject_id' => '2',
    'name' => '8.1 植树问题',
    'orders' => '1052',
  ),
  808 => 
  array (
    'id' => '2527',
    'parent_id' => '2525',
    'subject_id' => '2',
    'name' => '8.2 方正问题',
    'orders' => '1053',
  ),
  809 => 
  array (
    'id' => '2528',
    'parent_id' => '2525',
    'subject_id' => '2',
    'name' => '第八单元检测',
    'orders' => '1054',
  ),
  810 => 
  array (
    'id' => '2529',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '第九单元 总复习',
    'orders' => '1055',
  ),
  811 => 
  array (
    'id' => '2530',
    'parent_id' => '2529',
    'subject_id' => '2',
    'name' => '9.1 小数',
    'orders' => '1056',
  ),
  812 => 
  array (
    'id' => '2531',
    'parent_id' => '2529',
    'subject_id' => '2',
    'name' => '9.2 四则运算和运算定律',
    'orders' => '1057',
  ),
  813 => 
  array (
    'id' => '2532',
    'parent_id' => '2529',
    'subject_id' => '2',
    'name' => '9.3 空间与图形',
    'orders' => '1058',
  ),
  814 => 
  array (
    'id' => '2533',
    'parent_id' => '2529',
    'subject_id' => '2',
    'name' => '9.4 统计',
    'orders' => '1059',
  ),
  815 => 
  array (
    'id' => '2534',
    'parent_id' => '2468',
    'subject_id' => '2',
    'name' => '期末测试',
    'orders' => '1060',
  ),
);