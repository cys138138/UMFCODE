<?php return array (
  0 => 
  array (
    'id' => '1381',
    'parent_id' => '0',
    'subject_id' => '4',
    'name' => '科普趣味题',
    'orders' => '1',
  ),
  1 => 
  array (
    'id' => '2590',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '国学知识',
    'orders' => '1',
  ),
  2 => 
  array (
    'id' => '2591',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '趣味成语',
    'orders' => '1',
  ),
  3 => 
  array (
    'id' => '2592',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '地理常识',
    'orders' => '1',
  ),
  4 => 
  array (
    'id' => '2593',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '文明礼仪',
    'orders' => '1',
  ),
  5 => 
  array (
    'id' => '2594',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '环保低碳生活知识',
    'orders' => '1',
  ),
  6 => 
  array (
    'id' => '2595',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '歇后语',
    'orders' => '1',
  ),
  7 => 
  array (
    'id' => '2596',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '安全用药知识',
    'orders' => '1',
  ),
  8 => 
  array (
    'id' => '2597',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '趣味谜语',
    'orders' => '1',
  ),
  9 => 
  array (
    'id' => '2598',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '自然科学',
    'orders' => '1',
  ),
  10 => 
  array (
    'id' => '2599',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '传统节日',
    'orders' => '1',
  ),
  11 => 
  array (
    'id' => '2589',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '自然灾害防范知识',
    'orders' => '1',
  ),
  12 => 
  array (
    'id' => '2588',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '青少年法律知识',
    'orders' => '1',
  ),
  13 => 
  array (
    'id' => '2587',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '健康小知识',
    'orders' => '1',
  ),
  14 => 
  array (
    'id' => '1382',
    'parent_id' => '1381',
    'subject_id' => '4',
    'name' => '七年级科普趣味题',
    'orders' => '1',
  ),
  15 => 
  array (
    'id' => '1383',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '科普题',
    'orders' => '1',
  ),
  16 => 
  array (
    'id' => '1384',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '趣味题',
    'orders' => '1',
  ),
  17 => 
  array (
    'id' => '1442',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '趣味体育',
    'orders' => '1',
  ),
  18 => 
  array (
    'id' => '1443',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '趣味科技',
    'orders' => '1',
  ),
  19 => 
  array (
    'id' => '1444',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '趣味生活',
    'orders' => '1',
  ),
  20 => 
  array (
    'id' => '1445',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '消防知识',
    'orders' => '1',
  ),
  21 => 
  array (
    'id' => '1446',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '安全知识',
    'orders' => '1',
  ),
  22 => 
  array (
    'id' => '1447',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '交通安全',
    'orders' => '1',
  ),
  23 => 
  array (
    'id' => '2535',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '春节知识问答',
    'orders' => '1',
  ),
  24 => 
  array (
    'id' => '2600',
    'parent_id' => '1382',
    'subject_id' => '4',
    'name' => '中国四大名着知识',
    'orders' => '1',
  ),
);