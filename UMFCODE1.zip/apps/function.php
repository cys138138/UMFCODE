<?php
function get($key, $defaultValue = null, $htmlFilter = 1){
	return Safe::get($key, $defaultValue, $htmlFilter);
}

function post($key, $defaultValue = null, $htmlFilter = 1){
	return Safe::post($key, $defaultValue, $htmlFilter);
}

if(!function_exists('debug')){
	function debug($data, $mode = Debug::MODE_NORMAL){
		Debug::dump($data, $mode, true);
	}
}

function myLog($data, $filePath = APP_LOG_FILE){
	$oException = Yii::$app->buildError(is_string($data) ? $data : 'APP出错了', false, is_array($data) ? $data : null);
	Yii::error((string)$oException);
}

function halt($errorMessage, $isShowError = false, $xData = array()){
	$oException = Yii::$app->buildError($errorMessage, $isShowError, $xData);
	Yii::error((string)$oException);
}

function alert($msg, $status = 1, $data = ''){
	$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty($_POST['ajax']) || !empty($_GET['ajax']);
	if(!$isAjax){
		if($data && is_scalar($data)){
			exit('<script type="text/javascript">location.href = "' . $data . '"</script>');
		}

		assign('status', $status);
		assign('msg', $msg);
		display('response.html.php');
		exit();
	}

	header('Content-Type:application/json; charset=utf-8');
	$aResult = array(
		'status' => $status,
		'msg' => $msg,
		'notice' => Yii::$app->notifytion->get(),
		'data' => $data,
	);

	if(isset($GLOBALS['UPDATE']) && $status){
		$aResult['update'] = $GLOBALS['UPDATE'];
	}

	$json = json_encode($aResult);

	if($jsonError = json_last_error()){
		$json = json_encode(array(
			'status' => 0,
			'msg' => '抱歉,数据处理出错!',
			'data' => $jsonError == JSON_ERROR_UTF8 ? 1 : 0,
		));
	}

	$callBack = (string)get('jsoncallback');
	if($callBack){
		//jQuery跨域支持
		exit($callBack . '(' . $json . ')');
	}else{
		exit($json);
	}
}

function wrong($message){
	assign('message', $message);
	display('wrong.html.php');
	exit();
}

function setRefererMark(){
	$referer = getReferer();
	if(!$referer){
		$referer = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	}
	echo '<input type="hidden" name="_HSIFJSDHJ768fsHSDF_" value="' . base64_encode($referer) . '" />';

}

function getMarkedReferer($method = 'post'){
	$referer = $method('_HSIFJSDHJ768fsHSDF_', '');
	$referer = $referer ? base64_decode(urldecode($referer)) : 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	return $referer;
}

function getReferer(){
	$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
	return $referer;
}

/**
 * 邮件发送快捷函数
 * @param type $options 发送选项,包含键名有 to(必须):收件人, subject(必须):邮件标题, content(必须), cc(可选):抄送人, bcc(可选):秘密抄送人
 * @return type
 */
function email($options){
	//检查是否包含必须的参数
	$aCheckKeys = array('to', 'subject', 'name', 'content');
	foreach($aCheckKeys as $checkKey){
		if(!array_key_exists($checkKey, $options)){
			alert('邮件参数缺少 '. $checkKey, 0);
		}
	}

	//处理抄送人
	if(!isset($options['cc'])){
		$options['cc'] = '';
	}
	$emailHtml = '<!doctype html><html><head><meta charset="UTF-8"><title>' . $options['subject'] . '</title></head><body style="margin:0;padding:0;"><div style="color:#f30;border-bottom:2px solid #f30;padding:15px 30px;margin:0;"><h2 style="font-size:30px;font-family:Microsoft Yahei;margin:0;">' . $options['subject'] . '</h2></div><div style="font-size:16px;color:#000;font-family:Microsoft Yahei;margin:0;padding:30px;border-bottom:2px solid #f30;"><div style="margin-bottom:30px;">' . $options['name'] . '，你好！</div><div style="margin-bottom:30px;">' . $options['content'] . '</div><div style="font-size:16px;color:#444;margin-bottom:30px;">UMFun团队<br />' . date('Y年n月j日 H:i:s') . '</div><div style="color:#aaa;font-size:12px;">出于安全考虑，以上内容如果非您本人，请不要理会此邮件，我们对此为你带来的不便表示歉意！<br />这是一封由机器人自动发送的邮件，请勿回复该邮件。<br />若有任何疑问，请与我们取得联系：<a href="http://' . APP_ABOUT . '/contact.html">联系我们</a><br /></div></div><div style="height:50px;padding:20px 30px;font-size:12px;color:#666;"><div><a href="http://' . APP_HOME . '" style="color:#666;text-decoration:none;">UMFun</a> |<a href="http://' . APP_SERVICE . '/feedback.html" style="color:#666;text-decoration:none;">用户反馈</a> |<a href="http://' . APP_ABOUT . '" style="color:#666;text-decoration:none;">关于优满分</a> |<a href="http://' . APP_ABOUT . '/contact.html" style="color:#666;text-decoration:none;">联系我们</a></div><div style="color:#666;margin-bottom:10px;">Copyright © 优满分（' . APP_HOME . '）2013 All Rights Reserved.</div></div></body></html>';

	//处理秘密抄送人
	if(!isset($options['bcc'])){
		$options['bcc'] = '';
	}

	return Mail::send($options['to'], $options['subject'], $emailHtml, $options['cc'], $options['bcc']);
}

function page($aPageInfo){
	$aPageInfo['labels'] = array(
		'first'		=>	'首页',
		'previous'	=>	'上一页',
		'next'		=>	'下一页',
		'last'		=>	'尾页',
	);
	$oPage = new Pagination($aPageInfo);
	return $oPage->fetch();
}

function assign($key, $value){
	$GLOBALS['VIEW']->assign($key, $value);
}

function display($viewFileName){
	$htmlCode = $GLOBALS['VIEW']->fetch($viewFileName);
	echo $htmlCode;
}

function fetch($viewFileName){
	return $GLOBALS['VIEW']->fetch($viewFileName);
}

function url($url, $otherParams = '', $domain = APP_DOMAIN){
	$activeUrlString = $url;
	$resultUrl = '';
	if(IS_URL_REWRITE){
		$aRule = $GLOBALS['URL_'][$domain];
		if(!$aRule){
			return $resultUrl;
		}
		foreach($aRule as $key => $value){
			$matchResult = preg_replace('#' . $key . '#iU', $value, $activeUrlString);
			if($matchResult != $activeUrlString){
				$resultUrl = $matchResult;
				break;
			}
		}
		if($resultUrl){
			$resultUrl = 'http://' . $domain . '/' . stripslashes($resultUrl);
			if($otherParams){
				$aParams = array();
				parse_str($otherParams, $aParams);
				$aParams = array_map('urlencode', $aParams);
				$encodedParamString = http_build_query($aParams);
				$resultUrl .= '?' . $encodedParamString;
			}
		}else{
			$aParams = array();
			parse_str($otherParams, $aParams);
			$aParams = array_map('urlencode', $aParams);
			$encodedParamString = http_build_query($aParams);
			$resultUrl = 'http://' . $domain . '/?' . $activeUrlString . '&' . $encodedParamString;
		}
	}else{
		$aParams = array();
		parse_str($otherParams, $aParams);
		$aParams = array_map('urlencode', $aParams);
		$encodedParamString = http_build_query($aParams);
		$resultUrl = 'http://' . $domain . '/?' . $activeUrlString . '&' . $encodedParamString;
	}
	return $resultUrl;
}


//==========================================================
function v($fields, $method = 'post'){
	return Validate::check($fields, $method, $GLOBALS['VAILDATE']);
}

function j($fields = '', $functionName = 'checkForm' , $errorCallBackName = ''){
	return Validate::bulidJavascriptCode($fields, $functionName , $errorCallBackName, $GLOBALS['VAILDATE']);
}

function w($rule, $checkValue){
	Validate::setCheckValue($checkValue);
	eval('$result = Validate::' . $rule . ';');
	return $result;
}

//==========================================================
//项目专用函数

/**
 * 获得题目插件类对象
 * @param type $pluginName 插件名称
 * @return object
 */
function esPlugin($pluginName){
	$classFile = APPS_PLUGIN_PATH . $pluginName . '/' . $GLOBALS['RESOLVER_CLASS'][$pluginName] . '.class.php';
	if(file_exists($classFile)){
		include_once($classFile);
		$oPlugin = new $GLOBALS['RESOLVER_CLASS'][$pluginName];
		return $oPlugin;
	}else{
		return null;
	}
}

/**
 * 获得道具插件对象
 */
function propPlugin($userId){
	$baseClassFile = APPS_PLUGIN_PATH . 'prop/' . 'Prop.class.php';
	$propClassFile = APPS_PLUGIN_PATH . 'prop/' . 'UseProp.class.php';
	if(file_exists($baseClassFile) && file_exists($propClassFile)){
		include_once($baseClassFile);
		include_once($propClassFile);
		$oPlugin = new UseProp($userId);
		return $oPlugin;
	}else{
		return null;
	}
}

/**
 * 更新用户分数和等级
 */
function addAccumulatePoints($userId, $action, $esCount = 0){
	$classFile = APPS_PLUGIN_PATH . '/accumulate_points/AccumulatePoints.class.php';
	if(file_exists($classFile)){
		include_once($classFile);
		$oAccumulatePoints = new AccumulatePoints();
		$aResult = $oAccumulatePoints->addAccumulatePoints($userId, $action, $esCount);
		return $aResult;
	}else{
		return null;
	}
}

/**
 * 更新勋章的方法
 */
function addMedalCount($userId, $action, $missionId = 0){
	$classFile = APPS_PLUGIN_PATH . '/medal/Medal.class.php';
	if(file_exists($classFile)){
		include_once($classFile);
		$oMedal = new Medal();
		$result = $oMedal->addMedalCount($userId, $action, $missionId);
		return $result;
	}else{
		return null;
	}
}

/**
 * 定时裁决超时PK
 */
function execOverTimePkJudgment($pkId = 0){
	$classFile = APPS_PLUGIN_PATH . '/pk_judgment/PkJudgment.class.php';
	if(file_exists($classFile)){
		include_once($classFile);
		$oPkJudgment = new PkJudgment();
		$aResult = $oPkJudgment->execOverTimePkJudgment($pkId);
		return $aResult;
	}else{
		return null;
	}
}

/**
 *模型缓存方法
 * @staticvar array $model
 * @param type $modelName 模型名称
 * @return object
 */
function m($modelName){
	$modelName .= 'Model';
	static $aModel = array();
	if(!isset($aModel[$modelName])){
		if(class_exists($modelName)){
			$aModel[$modelName] = new $modelName();
		}else{
			halt('实例化 ' . $modelName . ' 模型失败');
		}
	}
	return $aModel[$modelName];
}

/*
 *用户登录验证
 */
 function checkUserLogin($finishStep = 6){
	//必须完成的步骤
	static $aUser = [];

	if($aUser){
		return $aUser;
	}

	$aUser = isLogin();
	if(!$aUser){
		$logoutTips = '请先登陆';
		$userId = Cookie::getDecrypt('userId');
		if($userId){
			$aLoginInfo = User::getUserLoginInfo($userId);
			if($aLoginInfo){
				if($aLoginInfo['ip'] == getClientIP()){
					User::deleteUserLoginInfo($userId);
				}else{
					$logoutTips = '您的帐号在别处登陆，您已被迫下线';
				}
			}else{
				$logoutTips = '您的登陆信息已失效';
			}
		}

		if(!Yii::$app->request->isAjax){
			Yii::$app->student->loginRequired();
		}else{
			Yii::$app->student->loginRequired(true);
		}
		Yii::$app->response->send();
		exit;
	}

	/*if(Yii::$app->student->isOverReloginTime){
		Yii::$app->student->lastActiveTime = NOW_TIME;
		Yii::$app->response->redirect(Yii::$app->student->reloginUrl)->send();
		exit;
	}*/

	assign('gXxtUserId', $aUser['xxt_id']);

	//登录成功后判断用户是否填写了个人信息，如没填则跳转到填写页面
	$aJumpInfo = array(
		array(
			'message' => '跳转首页',
			'url' => url('m=Index&a=Index', '', APP_HOME)
		),
		array(
			'message' => '请先将个人资料填写完整',
			//'url' => url('m=Account&a=showPerfectUserInformation', '', APP_HOME)
			'url' => Yii::$app->urlManagerLogin->createUrl('register/student-create-success')
		),
	);

	if($aUser['is_forbidden'] == 1){
		alert('抱歉！您已经被禁用,请联系管理员', 0);
	}elseif(empty($aUser['name']) && $finishStep > 3){
		alert($aJumpInfo[1]['message'], 301, $aJumpInfo[1]['url']);
	}else{
		if(!empty($aUser['name']) && $finishStep > 1 && $finishStep < 4){
			alert($aJumpInfo[0]['message'], 302, $aJumpInfo[0]['url']);
		}
	}
	return $aUser;
}

function isLogin(){
	static $aUser = null;
	if($aUser){
		return $aUser;
	}

	if(Yii::$app->student->isGuest){
		return false;
	}

	$mStudent = Yii::$app->student->identity;
	$aUser = $mStudent->toArray(['id', 'xxt_type', 'xxt_id', 'email', 'mobile', 'is_forbidden', 'name', 'last_login_time', 'profile', 'style_id', 'new_feed_flag', 'approve_status', 'password']);


	$aUser['css_file'] = '';
	if($aUser['style_id']){
		$mStyle = \common\model\Style::findOne($aUser['style_id']);
		$aUser['css_file'] = $mStyle->getCssFile();
	}
	return $aUser;
}

/**
 * 检查代理商是否登陆
 * @return mixed 成功后返回用户信息,不成功则返回false
 */
function isProxyLogin(){
	$proxyId = intval(Cookie::getDecrypt('proxyId'));
	if($proxyId > 0){
		$proxyXID = trim(Cookie::getXcrypt('proxyXID'));
		$proxyAgent = $_SERVER['HTTP_USER_AGENT'];
		if($proxyXID == Xxtea::xCrypt(md5($proxyAgent . $proxyId))){
			$oProxy = m('Proxy');
			$aProxyInfo = $oProxy->getProxyUserInfoById($proxyId);
			return $aProxyInfo;
		}else{
			return false;
		}
	}else{
		return false;
	}
}

/*
 *工具导航条
 */
function displayToolBar($userId){
	$oUser = m('User');
	$aUserInformation = $oUser->getPersonalInfoByUserId($userId);
	echo getToolbar($aUserInformation);
}

function getToolBar($aUserInformation){
	assign('aUserInformation', $aUserInformation);
	return fetch('toolbar.html.php');
}



//取得客户端IP
function getClientIP(){
	return Yii::$app->request->userIP;
}

function getVipName($name, $vip){
	if(!$vip){
		return $name;
	}elseif($vip == 1){
		return  '<span style="color:#F00">' . $name . '</span>';
	}elseif($vip == 2 || $vip == 3){
		return  '<span style="color:#F8A501">' . $name . '</span>';
	}
	return $name;
}

//===========================支付宝相关函数===================================

/**
 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
 * @param $para 需要拼接的数组
 * return 拼接完成以后的字符串
 */
function createLinkstring($para) {
	$arg  = "";
	while (list ($key, $val) = each ($para)) {
		$arg.=$key."=".$val."&";
	}
	//去掉最后一个&字符
	$arg = substr($arg,0,count($arg)-2);
	//如果存在转义字符，那么去掉转义
	if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}
	return $arg;
}

/**
 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串，并对字符串做urlencode编码
 * @param $para 需要拼接的数组
 * return 拼接完成以后的字符串
 */
function createLinkstringUrlencode($para) {
	$arg  = "";
	while (list ($key, $val) = each ($para)) {
		$arg.=$key."=".urlencode($val)."&";
	}
	//去掉最后一个&字符
	$arg = substr($arg,0,count($arg)-2);

	//如果存在转义字符，那么去掉转义
	if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}

	return $arg;
}
/**
 * 除去数组中的空值和签名参数
 * @param $para 签名参数组
 * return 去掉空值与签名参数后的新签名参数组
 */
function paraFilter($para) {
	$para_filter = array();
	while (list ($key, $val) = each ($para)) {
		if($key == "sign" || $key == "sign_type" || $val == "")continue;
		else	$para_filter[$key] = $para[$key];
	}
	return $para_filter;
}
/**
 * 对数组排序
 * @param $para 排序前的数组
 * return 排序后的数组
 */
function argSort($para) {
	ksort($para);
	reset($para);
	return $para;
}
/**
 * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
 * 注意：服务器需要开通fopen配置
 * @param $word 要写入日志里的文本内容 默认值：空值
 */
function logResult($word='') {
	Yii::error('支付宝接口出错', false, $word);
}

/**
 * 远程获取数据，POST模式
 * 注意：
 * 1.使用Crul需要修改服务器中php.ini文件的设置，找到php_curl.dll去掉前面的";"就行了
 * 2.文件夹中cacert.pem是SSL证书请保证其路径有效，目前默认路径是：getcwd().'\\cacert.pem'
 * @param $url 指定URL完整路径地址
 * @param $cacert_url 指定当前工作目录绝对路径
 * @param $para 请求的数据
 * @param $input_charset 编码格式。默认值：空值
 * return 远程输出的数据
 */
function getHttpResponsePOST($url, $cacert_url, $para, $input_charset = '') {
	if (trim($input_charset) != '') {
		$url = $url."_input_charset=".$input_charset;
	}
	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);//SSL证书认证
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);//严格认证
	curl_setopt($curl, CURLOPT_CAINFO,$cacert_url);//证书地址
	curl_setopt($curl, CURLOPT_HEADER, 0 ); // 过滤HTTP头
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
	curl_setopt($curl, CURLOPT_POST, true); // post传输数据
	curl_setopt($curl, CURLOPT_POSTFIELDS, $para);// post传输数据
	$responseText = curl_exec($curl);
	//var_dump( curl_error($curl) );//如果执行curl过程中出现异常，可打开此开关，以便查看异常内容
	curl_close($curl);

	return $responseText;
}

/**
 * 远程获取数据，GET模式
 * 注意：
 * 1.使用Crul需要修改服务器中php.ini文件的设置，找到php_curl.dll去掉前面的";"就行了
 * 2.文件夹中cacert.pem是SSL证书请保证其路径有效，目前默认路径是：getcwd().'\\cacert.pem'
 * @param $url 指定URL完整路径地址
 * @param $cacert_url 指定当前工作目录绝对路径
 * return 远程输出的数据
 */
function getHttpResponseGET($url,$cacert_url) {
	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_HEADER, 0 ); // 过滤HTTP头
	curl_setopt($curl,CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);//SSL证书认证
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);//严格认证
	curl_setopt($curl, CURLOPT_CAINFO, $cacert_url);//证书地址
	$responseText = curl_exec($curl);
	myLog($url);
	//var_dump(curl_error($curl));//如果执行curl过程中出现异常，可打开此开关，以便查看异常内容
	curl_close($curl);

	return $responseText;
}

/**
 * 实现多种字符编码方式
 * @param $input 需要编码的字符串
 * @param $_output_charset 输出的编码格式
 * @param $_input_charset 输入的编码格式
 * return 编码后的字符串
 */
function charsetEncode($input,$_output_charset ,$_input_charset) {
	$output = "";
	if(!isset($_output_charset) )$_output_charset  = $_input_charset;
	if($_input_charset == $_output_charset || $input ==null ) {
		$output = $input;
	} elseif (function_exists("mb_convert_encoding")) {
		$output = mb_convert_encoding($input,$_output_charset,$_input_charset);
	} elseif(function_exists("iconv")) {
		$output = iconv($_input_charset,$_output_charset,$input);
	} else die("sorry, you have no libs support for charset change.");
	return $output;
}
/**
 * 实现多种字符解码方式
 * @param $input 需要解码的字符串
 * @param $_output_charset 输出的解码格式
 * @param $_input_charset 输入的解码格式
 * return 解码后的字符串
 */
function charsetDecode($input,$_input_charset ,$_output_charset) {
	$output = "";
	if(!isset($_input_charset) )$_input_charset  = $_input_charset ;
	if($_input_charset == $_output_charset || $input ==null ) {
		$output = $input;
	} elseif (function_exists("mb_convert_encoding")) {
		$output = mb_convert_encoding($input,$_output_charset,$_input_charset);
	} elseif(function_exists("iconv")) {
		$output = iconv($_input_charset,$_output_charset,$input);
	} else die("sorry, you have no libs support for charset changes.");
	return $output;
}

/**
 * 签名字符串
 * @param $prestr 需要签名的字符串
 * @param $key 私钥
 * return 签名结果
 */
function md5Sign($prestr, $key) {
	$prestr = $prestr . $key;
	return md5($prestr);
}

/**
 * 验证签名
 * @param $prestr 需要签名的字符串
 * @param $sign 签名结果
 * @param $key 私钥
 * return 签名结果
 */
function md5Verify($prestr, $sign, $key) {
	$prestr = $prestr . $key;
	$mysgin = md5($prestr);

	if($mysgin == $sign) {
		return true;
	}
	else {
		return false;
	}
}
//===========================支付宝相关函数结束===================================

function getCreateTime($time){
	$str = "";
	if($time > 0){
		$seconds = time() - $time;
		if($seconds < 60 || $seconds == 60){
			$str = "1分钟前";
		}else{
			if($seconds > 3600 * 24 * 30 * 12){
				$str = ceil($seconds / (3600 * 24 * 30 * 12));
				$str .= "年前";
			}elseif($seconds > 3600 * 24 * 30){
				$str = ceil($seconds / (3600 * 24 * 30));
				$str .= "个月前";
			}elseif($seconds > 3600 * 24){
				$str = ceil($seconds / (3600 * 24));
				$str .= "天前";
			}elseif($seconds > 3600){
				$str = ceil($seconds / 3600);
				$str .= "小时前";
			}elseif($seconds > 60){
				$str = ceil($seconds / 60);
				$str .= "分钟前";
			}
		}
	}
	return $str;
}

function isComputer(){
	return Yii::$app->client->isComputer;
}

//家长登陆
function isParentLogin(){
	if(Yii::$app->parent->isGuest){
		return false;
	}
	return Yii::$app->parent->identity->toArray();
}
//家长登陆
function checkParentLogin($cilen = 0){
	if(Yii::$app->client->isComputer){
		$aUrl = array(0 => PC_API_LOGIN_URL, 1 => url('m=Parents&a=showHome'));
	}else{
		$aUrl = array(0 => XXT_API_LOGIN_URL, 1 => url('m=Parents&a=showLogin'));
	}
	$aUser = isParentLogin();
	if(!$aUser){
		header('Location:' . $aUrl[$cilen]);
		exit;
	}else{
		return $aUser;
	}
}


//检测是否登陆---林云龙
function isTeacherLogin(){
	$id = Cookie::getDecrypt('teacherId');
	if(!$id){
		return false;
	}
	//$autoLoginCookie = Cookie::getXcrypt('teacherAutoLogin');
	//if(!$autoLoginCookie){
		//return false;
	//}
	//$userAgent = $_SERVER['HTTP_USER_AGENT'];
	//$autoLoginCode = Xxtea::xcrypt(md5($userAgent . $id));
	//if($autoLoginCookie == $autoLoginCode){
		$oTeacher = m('Teacher');
		$aTeacher = $oTeacher->getTeacherInfoById($id);
		if($aTeacher === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif(!$aTeacher){
			return false;
		}
		return $aTeacher;
	//}else{
		//return false;
	//}
}

function checkTeacherLogin(){
	$aUser = isTeacherLogin();
	if(!$aUser){
		header('Location:' . url('m=Account&a=showLogin'));
		exit;
	}else{
		return $aUser;
	}
}

//发送手机短信--林云龙
function sendMobileMessage($mobile, $msgText){
	if(!$msgText){
		return -1;
	}
	$url = 'http://utf8.sms.webchinese.cn/?Uid=' . SEND_MESSAGE_USER . '&Key=' . SEND_MESSAGE_KEY . '&smsMob=' . $mobile . '&smsText=' . $msgText;
	$ch = curl_init();
	$timeout = 5;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$returnStatus = curl_exec($ch);
	curl_close($ch);
	return $returnStatus;
}