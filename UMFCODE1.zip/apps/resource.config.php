<?php
global $aLocal;
$resourceVersion = '?v=2014-1225-3691';
$GLOBALS['RESOURCE'] = array(
	'version' => $resourceVersion,



	/* =============================================================================
	#
	#     FileName	: 	【新版 - 静态资源】
	#       Author	:	赵欢磊
	#      History	:	20131218	添加整理
	#
	============================================================================= */


	/* ---------------------------- JS ---------------------- */
	//jquery
	'jquery2'						=>	SYSTEM_RESOURCE_URL . '/view2/script/jquery-1.9.1.min.js' . $resourceVersion,
	//全局JS
	'script_global2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/script_global.js' . $resourceVersion . 3,
	//首页-注册流程
	'script_account2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/script_account.js' . $resourceVersion,
	//个人中心
	'script_center2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/script_center.js' . $resourceVersion,
	//家长、老师入口
	'script_entrance2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/script_entrance.js' . $resourceVersion,
	//道具
	'jquery_porp'					=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.prop.js' . $resourceVersion,
	//VIP
	'script_vip'					=>	SYSTEM_RESOURCE_URL . '/view2/script/script_vip.js' . $resourceVersion,
	//话题
	'script_topic'					=>	SYSTEM_RESOURCE_URL . '/view2/script/script_topic.js' . $resourceVersion,
	//公共js类库
	'library'						=>	SYSTEM_RESOURCE_URL . '/view2/script/library.js' . $resourceVersion,
	//zepto框架
	'zepto.min'						=> SYSTEM_RESOURCE_URL . '/view2/app/parents/scripts/zepto.min.js?1.1.4' . $resourceVersion,
	'zepto.cookie.min'				=> SYSTEM_RESOURCE_URL . '/view2/app/parents/scripts/zepto.cookie.min.js' . $resourceVersion,

	//Chart报表插件
	'chart.min'						=> SYSTEM_RESOURCE_URL . '/view2/app/parents/scripts/chart.min.js' . $resourceVersion,

	//V2.5过渡V3导航样式
	'old_css'						=> '/v1/css/old-css.css' . $resourceVersion . '1',




	/* 插件 */

	//IE6 PNG透明
	'dd_belated_png2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/dd_belated_png_0.0.8a-min.js' . $resourceVersion,
	//表单select美化
	'jquery_easydropdown2'			=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jquery.easydropdown.js' . $resourceVersion,
	//旋转插件 - 转盘
	'jQuery_rotate2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery_rotate.2.2.js' . $resourceVersion,
	'jQuery_turntable'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.turntable.js' . $resourceVersion,
	//地区选择器
	'place_selector2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.place_selector.js' . $resourceVersion,
	'school_selector2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.school_selector.js' . $resourceVersion,
	'class_selector2'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.class_selector.js' . $resourceVersion,
	'script_message'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.message.js' . $resourceVersion . 2,
	'script_event'					=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.event.js' . $resourceVersion,
	'script_ualert'					=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.ualert.js' . $resourceVersion,
	'script_shuoshuo'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.shuoshuo.js' . $resourceVersion,
	'script_ume_editor'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/ume_editor/jQuery.ume_editor.js' . $resourceVersion,
	'script_jscharts'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jscharts.js' . $resourceVersion,
	'script_log'					=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jquery.log.js' . $resourceVersion,

	'script_player'					=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/player.js' . $resourceVersion,
	'script_ajaxupload'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jquery.ajax_upload.js' . $resourceVersion,

	//layer轻量弹窗提示插件
	'layer_min'						=>	SYSTEM_RESOURCE_URL . '/view3/pc/plugin/layer/layer.min.js' . $resourceVersion,

	//gallery图片弹窗插件
	'gallery' 						=> 	array(
		'path' 						=> 	SYSTEM_RESOURCE_URL . '/view2/script/plugin/gallery/',
		'css' 						=> 	'jquery.gallery.css' . $resourceVersion,
		'js' 						=> 	'jquery.gallery.js' . $resourceVersion,
	),

	//后台修改解题思路
	'analysis'						=>	SYSTEM_RESOURCE_URL . '/view3/pc/plugin/jquery.analysis.js' . $resourceVersion . 1,





	/* ---------------------------- CSS ---------------------- */
	//全局样式
	'style_global2'					=>	SYSTEM_RESOURCE_URL . '/view2/style/style_global.css' . $resourceVersion . 4,
	//首页-注册流程
	'style_account2'				=>	SYSTEM_RESOURCE_URL . '/view2/style/style_account.css' . $resourceVersion,
	//个人中心
	'style_center2'					=>	SYSTEM_RESOURCE_URL . '/view2/style/style_center.css' . $resourceVersion . 5,
	//帮助中心
	'style_help2'					=>	SYSTEM_RESOURCE_URL . '/view2/style/style_help.css' . $resourceVersion,
	//家长、老师入口
	'style_entrance2'				=>	SYSTEM_RESOURCE_URL . '/view2/style/style_entrance.css' . $resourceVersion,
	'style_education_main'			=>	SYSTEM_RESOURCE_URL . '/view2/style/style_education.css' . $resourceVersion,


	//VIP
	'style_vip'						=>	SYSTEM_RESOURCE_URL . '/view2/style/style_vip.css' . $resourceVersion,

	//插件样式
	'style_plugins2'				=>	SYSTEM_RESOURCE_URL . '/view2/style/style_plugins.css' . $resourceVersion,
	'style_es'						=>	SYSTEM_RESOURCE_URL . '/view2/style/style_es.css' . $resourceVersion . 1,
	'style_header'					=>	SYSTEM_RESOURCE_URL . '/view2/style/style_header.css' . $resourceVersion . 1,
	'style_content'					=>	SYSTEM_RESOURCE_URL . '/view2/style/style_content.css' . $resourceVersion . 1,
	'style_exchange'				=>	SYSTEM_RESOURCE_URL . '/view2/style/style_exchange.css' . $resourceVersion,
	'style_competition'				=>	SYSTEM_RESOURCE_URL . '/view2/style/style_competition.css' . $resourceVersion . 1,
	'style_topic'				    =>	SYSTEM_RESOURCE_URL . '/view2/style/style_topic.css' . $resourceVersion . 1,


	//2014教师节
	'spec_teacher'				    =>	SYSTEM_RESOURCE_URL . '/view2/style/spec_teacher.css' . $resourceVersion,

	//活动大厅
	'activity_center'				=>	SYSTEM_RESOURCE_URL . '/view2/style/activity/activity_center.css' . $resourceVersion,
	'activity_mission'				=>	SYSTEM_RESOURCE_URL . '/view2/style/activity/spec_mission.css' . $resourceVersion,

	//201411家长新版
	'normalize-v3'					=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/styles/normalize-v3.css' . $resourceVersion,
	'pc-parents'					=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/styles/pc-parents.css' . $resourceVersion,

	'pc-parents-img-01'				=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/images/1.jpg' . $resourceVersion,
	'pc-parents-img-02'				=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/images/2.png' . $resourceVersion,
	'pc-parents-img-03'				=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/images/3.jpg' . $resourceVersion,
	'pc-parents-img-04'				=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/images/4.jpg' . $resourceVersion,
	'pc-parents-img-05'				=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/images/5.jpg' . $resourceVersion,
	'pc-parents-img-logo'			=>	SYSTEM_RESOURCE_URL . '/view2/pc/parents/images/logo.png' . $resourceVersion,




	/* ------------------------------- Img --------------------------- */
	'favicon'					=>	SYSTEM_RESOURCE_URL . 'favicon_v1.ico' . $resourceVersion,
	//转盘背景
	'ly_plate'					=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/ly_plate.png' . $resourceVersion,
	'ly_plate2'					=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/ly_plate2.png' . $resourceVersion,
	'rotate_start'				=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/rotate_start.png' . $resourceVersion,
	'account_plate'				=>	SYSTEM_RESOURCE_URL . '/view2/images/account/turntable.png' . $resourceVersion,
	//抽奖奖品图片
	'next'						=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/next.png' . $resourceVersion,
	'gold'						=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/gold.png' . $resourceVersion,
	'points'					=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/points.png' . $resourceVersion,
	'prop'					    =>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/prop.png' . $resourceVersion,
	'fail_cards'				=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/animals/fail_cards_2.png' . $resourceVersion,
	'animal_cards_all'					=>	SYSTEM_RESOURCE_URL . '/view2/images/turn_table/animals/animal_cards_all.jpg' . $resourceVersion,
	//头部显示活动广告
	'activity_adv_b'			=>	SYSTEM_RESOURCE_URL . '/view2/images/global/duobao_b.jpg' . $resourceVersion . 1,
	'activity_adv_s'			=>	SYSTEM_RESOURCE_URL . '/view2/images/global/duobao_s.jpg' . $resourceVersion . 1,
	'activity_adv_s1'			=>	SYSTEM_RESOURCE_URL . '/view2/images/global/activity_teacher_s.jpg' . $resourceVersion . 1,
	'activity_adv_exchange'		=>	'/v1/banner/common-top-exchange.jpg' . $resourceVersion . 4,
	'activity_adv_team'			=>	SYSTEM_RESOURCE_URL . '/view2/images/global/activity_team.jpg' . $resourceVersion . 2,
	'activity_adv_packet'		=>	SYSTEM_RESOURCE_URL . '/view2/images/global/red_packet.jpg' . $resourceVersion,














	/* =============================================================================
	#
	#     FileName	: 	【旧版 - 静态资源】
	#       Author	:	赵欢磊
	#      History	:	20131218	整理
	#
	============================================================================= */


	/* ------------------------------- Img --------------------------- */
	'banner_tuijian'  				=>	SYSTEM_RESOURCE_URL . 'view2/images/banner/tuijian.jpg' . $resourceVersion,
	'foot_img'  					=>	SYSTEM_RESOURCE_URL . 'view/image/foot_img_v1.jpg' . $resourceVersion,
	'image_del'  					=>	SYSTEM_RESOURCE_URL . 'view/image/image_del.jpg' . $resourceVersion,
	'image_bg'  					=>	SYSTEM_RESOURCE_URL . 'view/image/image_v1.jpg' . $resourceVersion,
	'login_bg' 						=>	SYSTEM_RESOURCE_URL . 'view/image/login_bg.jpg' . $resourceVersion,
	'school_information_column'  	=>	SYSTEM_RESOURCE_URL . 'view/image/school_information_column.jpg' . $resourceVersion,
	'success'  						=>	SYSTEM_RESOURCE_URL . 'view/image/success.jpg' . $resourceVersion,
	'sumfun' 						=>	SYSTEM_RESOURCE_URL . 'view/image/sumfun_v1.jpg' . $resourceVersion,
	'umfun_logo'  					=>	SYSTEM_RESOURCE_URL . 'view/image/umfun_logo_v1.jpg' . $resourceVersion,
	'upload'  						=>	SYSTEM_RESOURCE_URL . 'view/image/upload.jpg' . $resourceVersion,
	'user_information_column' 		=>	SYSTEM_RESOURCE_URL . 'view/image/user_information_column.jpg' . $resourceVersion,
	'user_notice' 					=>	SYSTEM_RESOURCE_URL . 'view/image/user_notice.jpg' . $resourceVersion,
	'es_delete' 					=>	SYSTEM_RESOURCE_URL . 'view/image/es/btn_delete.png' . $resourceVersion,
	'qb_activity_share_banner' 		=>	SYSTEM_RESOURCE_URL . 'view/image//match/activity_share_banner.jpg' . $resourceVersion,
	'profile_error'					=>	SYSTEM_RESOURCE_URL . 'view/image/global/head_error.png' . $resourceVersion,
	'profile_male'					=>	SYSTEM_RESOURCE_URL . 'data/user//default/male_100.jpg' . $resourceVersion,
	'profile_female'				=>	SYSTEM_RESOURCE_URL . 'data/user//default/female_100.jpg' . $resourceVersion,
	'image_error'					=>	SYSTEM_RESOURCE_URL . '/view/image/global/img_error.png' . $resourceVersion,
	'check_point'  					=>	SYSTEM_RESOURCE_URL . 'view2/images/home/check_point.png' . $resourceVersion,
	'check_match'  					=>	SYSTEM_RESOURCE_URL . 'view2/images/home/check_match.png' . $resourceVersion,
	'check_pk'  					=>	SYSTEM_RESOURCE_URL . 'view2/images/home/check_pk.png' . $resourceVersion,
	'new_version_pk_tips'  			=>	SYSTEM_RESOURCE_URL . 'view3/img/new_version_pk_tips.jpg' . $resourceVersion,
	'loading'  						=>	SYSTEM_RESOURCE_URL . 'view2/images/global/loading.gif' . $resourceVersion,
	'medal_pk_nomedal'  			=>	SYSTEM_RESOURCE_URL . 'view2/images/global/nomedal.png' . $resourceVersion,
	'no_passed_mission_medal'  			=>	SYSTEM_RESOURCE_URL . 'view2/images/global/no_passed_mission_medal.png' . $resourceVersion,
	'no_excellent_mission_medal'  			=>	SYSTEM_RESOURCE_URL . 'view2/images/global/no_excellent_mission_medal.png' . $resourceVersion,
	'style_turntable'				=>	SYSTEM_RESOURCE_URL . '/view2/style/style_turn_table.css' . $resourceVersion,

	'pk_coming_soon_s'				=>	SYSTEM_RESOURCE_URL . 'view2/images/global/pk_coming_soon_s.jpg' . $resourceVersion,
	'pk_coming_soon_l'				=>	SYSTEM_RESOURCE_URL . 'view2/images/global/pk_coming_soon_l.jpg' . $resourceVersion,

	/* ------------------------------ CSS --------------------------- */
	'style_home'	=>	SYSTEM_RESOURCE_URL . '/view/css/style_home_v1.css' . $resourceVersion,
	'style_manage'	=>	SYSTEM_RESOURCE_URL . '/view2/style/style_manage.css?v=1',
	'style_proxy'	=>	SYSTEM_RESOURCE_URL . '/view/css/style_proxy_v1.css' . $resourceVersion,
	'style_study'	=>	SYSTEM_RESOURCE_URL . '/view2/style/style_study.css' . $resourceVersion,
	'style_global'	=>	SYSTEM_RESOURCE_URL . '/view/css/style_global_v1.css' . $resourceVersion,
	'style_index'	=>	SYSTEM_RESOURCE_URL . '/view/css/style_index_v2.css' . $resourceVersion,
	'imgareaselect_default'	=>	SYSTEM_RESOURCE_URL . '/view/css/imgareaselect_default.css' . $resourceVersion,


	//比赛中心
	'style_match'	=>	SYSTEM_RESOURCE_URL . '/view/css/style_match.css' . $resourceVersion,
	//PK
	'style_pk'		=>	SYSTEM_RESOURCE_URL . '/view/css/style_pk.css' . $resourceVersion,
	'style_ranking'		=>	SYSTEM_RESOURCE_URL . '/view2/style/style_ranking.css' . $resourceVersion,


	/* ---------------------------- JavaScript ---------------------- */
	'jquery'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/jQuery191_v1.js' . $resourceVersion,
	'common'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/common_v1.js' . $resourceVersion,
	'jQuery_autocomplete'	=>	SYSTEM_RESOURCE_URL . '/view/javascript/jQuery.autocomplete_v1.js' . $resourceVersion,
	'player'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/player.js' . $resourceVersion,
	'public'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/public_v1.js' . $resourceVersion,
	'slides'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/slides_v1.js' . $resourceVersion,
	'validater'				=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.validate.js' . $resourceVersion,
	'script_home'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/script_home_v1.js' . $resourceVersion,
	'script_sns'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/script_sns_v1.js' . $resourceVersion,
	'script_study'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/script_study_v1.js' . $resourceVersion,
	'fuckie'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/fuckie_v1.js' . $resourceVersion,

	//比赛中心
	'script_match'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/script_match.js' . $resourceVersion,
	//PK
	'script_pk'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/script_pk.js' . $resourceVersion,



	'class_selector'		=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/jQuery.class_selector.js' . $resourceVersion,
	'jquery_cookie'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/jquery.cookie.js' . $resourceVersion,
	'place_selector'		=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/jQuery.place_selector.js' . $resourceVersion,
	'school_list'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/jQuery.school_list.js' . $resourceVersion,
	'char_inputer'			=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.char_inputer.js' . $resourceVersion,
	'es'					=>  SYSTEM_RESOURCE_URL . '/view2/script/plugin/jQuery.es.js' . $resourceVersion . 3,
	'dd_belated_png'		=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/dd_belated_png_0.0.8a-min.js' . $resourceVersion,
	'imgareaselect'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/jquery.imgareaselect.pack.js' . $resourceVersion,
	'ajaxfileupload'		=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/ajaxfileupload.js' . $resourceVersion,
	'script_global'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/script_global_v1.js' . $resourceVersion,
	'es_feedback'			=>	SYSTEM_RESOURCE_URL . 'view2/script/plugin/jQuery.es_feedback.js' . $resourceVersion,

	'areaschool'	=>  array(
		'path' 				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/area_school/',
		'classSelector'  	=>	'jQuery.classSelector.js' . $resourceVersion,
		'schoolList'   		=>	'jQuery.schoolList.js' . $resourceVersion,
	),
	'wdatepicker'	=>  array(
		'path' 				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/data_picker/v1/',
		'css'  				=>	'skin/WdatePicker.css' . $resourceVersion,
		'js'   				=>	'WdatePicker.js' . $resourceVersion,
	),
	'dtree'			=>	array(
		'path' 				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/dtree/v1/',
		'css'  				=>	'dtree.css' . $resourceVersion,
		'js'   				=>	'dtree.js' . $resourceVersion,
	),
	'style_ubox'			=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/ubox/ubox.css' . $resourceVersion,
	'script_ubox'			=>	SYSTEM_RESOURCE_URL . '/view2/script/plugin/ubox/ubox.js' . $resourceVersion,
	'ubox' 			=> array(
		'path' => SYSTEM_RESOURCE_URL . '/view2/script/plugin/ubox/',
		'css' => 'ubox.css' . $resourceVersion,
		'js' => 'ubox.js' . $resourceVersion,
	),
	'ualert' 			=> array(
		'path' => SYSTEM_RESOURCE_URL . '/view/javascript/plugin/',
		'js' => 'jQuery.ualert.js' . $resourceVersion,
	),
	'uploadify'		=>  array(
		'path'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/uploadify/v1/',
		'css'  				=>	'uploadify.css' . $resourceVersion,
		'js'   				=>	'jquery.uploadify.min.js' . $resourceVersion,
		'swf' 				=>	'uploadify.swf' . $resourceVersion,
		'button_image'		=>	'upload.jpg' . $resourceVersion,
		'delete_image'		=>	'image_del.gif' . $resourceVersion,
	),
	'easydialog'	=>	array(
		'path'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/easydialog/v1/',
		'css'				=>	'easydialog.css' . $resourceVersion,
		'js'				=>	'easydialog.js' . $resourceVersion,
	),
	'js_mathjax'		=>	$aLocal['resource']['mathjax'],
	'amcharts'		=>	array(
		'path'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/amcharts/v1/',
		'imgPath'			=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/amcharts/v1/images/',
		'js'				=>	'amcharts.js' . $resourceVersion,
	),

	'style_ueditor' => SYSTEM_RESOURCE_URL . '/view/javascript/plugin/ueditor/v1/themes/default/css/umeditor.css' . $resourceVersion,
	'script_ueditor' => SYSTEM_RESOURCE_URL . '/view/javascript/plugin/ueditor/v1/umeditor.min.js' . $resourceVersion . 1,
	'config_ueditor' => SYSTEM_RESOURCE_URL . '/view/javascript/plugin/ueditor/v1/umeditor.config.js' . $resourceVersion,
	'lang_ueditor' => SYSTEM_RESOURCE_URL . '/view/javascript/plugin/ueditor/v1/lang/zh-cn/zh-cn.js' . $resourceVersion,

	'ueditor'		=>	array(
		'path'				=>	SYSTEM_RESOURCE_URL . '/view/javascript/plugin/ueditor/v1/',
		'css'				=>  'themes/default/css/umeditor.css' . $resourceVersion,
		'config'			=>	'umeditor.config.js' . $resourceVersion,
		'min'				=>	'umeditor.min.js' . $resourceVersion,
		'zh-cn'				=>	'lang/zh-cn/zh-cn.js' . $resourceVersion,
	),




	//移动端
	'm_zepto'				=>	SYSTEM_RESOURCE_URL . '/view2/script/zepto.min.js' . $resourceVersion,
	'm_xxt_global'			=>	SYSTEM_RESOURCE_URL . '/view2/script/xxt_global.js' . $resourceVersion,
	'm_global_js'			=>	SYSTEM_RESOURCE_URL . '/view2/script/mobile/global.js' . $resourceVersion,
	'm_global_parent_js'	=>	SYSTEM_RESOURCE_URL . '/view2/script/mobile/xxt_global_parents.js' . $resourceVersion,
	'm_global_teacher'		=>	SYSTEM_RESOURCE_URL . '/view2/script/mobile/global-teacher.js' . $resourceVersion,
	'm_amazeui_js'			=>	SYSTEM_RESOURCE_URL . '/view2/script/mobile/amazeui.min.js' . $resourceVersion,
	'm_amazeui_min'			=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/amazeui.min.css' . $resourceVersion . 1,
	'lazyload'				=>	SYSTEM_RESOURCE_URL . '/view2/script/mobile/jquery.lazyload.js' . $resourceVersion,

	'm_style_global'		=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/global.css' . $resourceVersion . 1,

	'm_style_teacher'		=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/global-teacher.css' . $resourceVersion,
	'm_style_parent'		=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/global_parents.css' . $resourceVersion,
	'm_style_parent_intro'	=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/parents-intro.css' . $resourceVersion,
	'm_style_typo'			=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/typo.css' . $resourceVersion,
	'm_style_umfun_intro'	=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/umfun-intro.css' . $resourceVersion,

	//201411学生端
	'm_stu_img_banner'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-banner.jpg' . $resourceVersion . 2,
	'm_stu_img_banner_exchange'	=>	'/v1/banner/exchange-top.jpg' . $resourceVersion,
	'm_stu_img_excute'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-excute.jpg' . $resourceVersion,
	'm_stu_img_team'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/team_banner.jpg' . $resourceVersion . 2,
	'm_stu_img_exchange'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-exchange.jpg' . $resourceVersion,
	'm_stu_img_match'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-match.jpg' . $resourceVersion,
	'm_stu_img_rank'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-rank.jpg' . $resourceVersion . '1',
	'm_stu_img_rank1'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-rank1.jpg' . $resourceVersion . '1',
	'm_stu_img_activity1'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-activity1.jpg' . $resourceVersion,
	'm_stu_img_activity2'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-activity2.jpg' . $resourceVersion,
	'm_stu_team_activity2'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/stu-team-adv.jpg' . $resourceVersion . 1,
	'm_stu_exchange_activity'		=>	'/v1/banner/exchange-small.jpg' . $resourceVersion,
	'm_stu_mother_day'		=>	'/v1/banner/topic-small.jpg' . $resourceVersion . 1,
	'm_stu_red_packet'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/red-packet.jpg' . $resourceVersion,
	'm_stu_red_packet_top'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/red-packet-top.jpg' . $resourceVersion,
	'm_stu_img_banner_mission'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/m_stu_img_banner_mission.jpg' . $resourceVersion,
	'm_stu_img_banner_xxt_logo'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/img-banner-xxt-logo.jpg' . $resourceVersion,
	'm_stu_img_banner_scholarshipguess'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/scholarshipguess-banner.jpg' . $resourceVersion,
	'm_stu_img_duang'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/duang.jpg' . $resourceVersion,
	'm_stu_ico_notice'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/ico_notice.png' . $resourceVersion,






	//APP教师端 CSS
	'm_style_education_infor'	=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/style_education_infor.css' . $resourceVersion,

	'm_style_es'			=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/m_style_es.css' . $resourceVersion,
	'm_img_logo'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-home-logo.png' . $resourceVersion,
	'm_img_loading'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/loading.png' . $resourceVersion,
	'm_img_home_bg'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-home-bg.jpg' . $resourceVersion,
	'm_img_inner_bg'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-inner-bg.jpg' . $resourceVersion,
	'm_title_ranking_bg'	=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-ranking.png' . $resourceVersion,
	'm_img_inner_bg'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-inner-bg.jpg' . $resourceVersion,
	'm_img_title_select'	=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-select.png' . $resourceVersion,
	'm_img_title_execute'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-execute.png' . $resourceVersion,
	'm_img_title_practice'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-practice.png' . $resourceVersion,
	'm_img_title_challenge'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-challenge.png' . $resourceVersion,
	'm_img_card_back'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/card-back.png' . $resourceVersion,
	'm_img_mycard'			=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-mycard.png' . $resourceVersion,
	'm_img_lottery'			=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/lottery.png' . $resourceVersion,
	'm_img_share_b'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/share_b.png' . $resourceVersion,
	'm_img_share_m'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/share_m.png' . $resourceVersion,


	'm_parent_logo'			=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/logo.png' . $resourceVersion,
	'm_parent_home_img'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/home-img.png' . $resourceVersion,
	'm_parent_intro_1'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/1.png' . $resourceVersion,
	'm_parent_intro_2'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/2.png' . $resourceVersion,
	'm_parent_intro_3'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/3.png' . $resourceVersion,
	'm_parent_intro_4'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/4.png' . $resourceVersion,
	'm_parent_intro_5'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/5.png' . $resourceVersion,
	'm_parent_intro_6'		=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/6.png' . $resourceVersion,
	'm_parent_intro_bq_1'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/bq/bq1.jpg' . $resourceVersion,
	'm_parent_intro_bq_2'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/bq/bq2.jpg' . $resourceVersion,
	'm_parent_intro_bq_3'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/bq/bq3.jpg' . $resourceVersion,
	'm_parent_intro_bq_4'	=>   SYSTEM_RESOURCE_URL . '/view2/images/mobile/parents-intro/bq/bq4.jpg' . $resourceVersion,


	//教师端图片资源
	'm_teacher_logo'		=> SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/logo_t.png' . $resourceVersion,
	'm_teacher_load'		=> SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/loading.gif' . $resourceVersion,
	'm_teacher_home_bg'		=> SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/home-bg.png' . $resourceVersion,
	'm_teacher_home_img'	=> SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/home-img-t.png' . $resourceVersion,
	'm_teacher_back'		=> SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/icon-back.png' . $resourceVersion,

	//比赛
	'm_match_title'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-match-center.png' . $resourceVersion,
	'm_match_bg'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-inner-bg.jpg' . $resourceVersion,
	'm_match_detail'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/um-title-match-detail.png' . $resourceVersion,
	'm_match_loadmore'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/loadmore.png' . $resourceVersion,
	//新比赛资源
	'm_match_css'			=>	'/v1/css/match.css' . $resourceVersion . 2,
	'm_match_list_js'		=>	'/v1/js/page/match-list.js' . $resourceVersion . 2,
	'm_match_detail_js'		=>	'/v1/js/page/match-detail.js' . $resourceVersion . 2,
	'm_match_join_form_js'	=>	'/v1/js/page/match-join-form.js' . $resourceVersion . 3,
	'm_match_do_js'			=>	'/v1/js/page/match-do.js' . $resourceVersion . 2,
	'm_match_awards_gold_one'		=>	'/v1/img/gold_one.png' . $resourceVersion,
	'm_match_awards_gold_two'		=>	'/v1/img/gold_two.png' . $resourceVersion,
	'm_match_awards_gold_three'		=>	'/v1/img/gold_three.png' . $resourceVersion,

	//2014移动端教师节
	'm_spec_teacher'		=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/spec_teacher.css' . $resourceVersion,
	'active-s'				=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/active-s.png' . $resourceVersion,
	'b-active-s'				=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/b-active-s.png' . $resourceVersion,
	'b-active-b'				=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/b-active-b.png' . $resourceVersion,
	'active-b'				=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/active-b.png' . $resourceVersion,
	'no_teacher'			=>	SYSTEM_RESOURCE_URL . '/view2/images/spec_teacher/no_teacher.png' . $resourceVersion,
	'over'					=>	SYSTEM_RESOURCE_URL . '/view2/images/spec_teacher/over.png' . $resourceVersion,

	// 学生端切换家长端按钮
	'tabpar'				=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/images/tabpar.png' . $resourceVersion,

	//活动大厅
	'm_style_base'			=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/base.css' . $resourceVersion,
	'm_activity_center'		=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/activity_center.css' . $resourceVersion,
	'm_activity_mission'	=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/spec_mission.css' . $resourceVersion . 1,
	'm_activity_global'		=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/activity_global.css' . $resourceVersion . 1,
	'm_activity_global2'	=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity_global.css' . $resourceVersion,

	'm_activity_img_bg'			=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/activity_center/bg.jpg' . $resourceVersion,
	'm_activity_img_mbg1'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/mbg1.jpg' . $resourceVersion,
	'm_activity_img_mbg11'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/mbg11.jpg' . $resourceVersion,

	'm_activity_img_pre2'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/pre2.jpg' . $resourceVersion,
	'm_activity_img_pre3'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/pre3.jpg' . $resourceVersion,
	'm_activity_img_pre4'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/pre4.jpg' . $resourceVersion,
	'm_activity_img_pre5'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/pre5.jpg' . $resourceVersion,
	'm_activity_img_pre6'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_mission/pre6.jpg' . $resourceVersion,
	'm_activity_intro_4'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/intro/4.jpg' . $resourceVersion,

	//争分夺宝
	'style_duobao'				=>	SYSTEM_RESOURCE_URL . '/view2/style/activity/spec_duobao.css?v=2014-1202-1028-' . $resourceVersion,
	'p2circle'					=>	SYSTEM_RESOURCE_URL . '/view2/images/activity/spec_duobao/p2circle.png?v=2014-1022-1126-' . $resourceVersion,
	'p3circle'					=>	SYSTEM_RESOURCE_URL . '/view2/images/activity/spec_duobao/p3circle.png?v=2014-1022-1126-' . $resourceVersion,
	's3circle'					=>	SYSTEM_RESOURCE_URL . '/view2/images/activity/spec_duobao/s3circle.png?v=2014-1022-1126-' . $resourceVersion,

	'm_style_es_duobao'			=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/m_style_es.css?v=2014-1022-1126-' . $resourceVersion,
	'm_style_duobao'			=>	SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/spec_duobao.css?v=2014-1202-1028-' . $resourceVersion . 1,
	'cardbg'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/cardbg.png?v=2014-1022-1126-' . $resourceVersion,
	'coin'						=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/coin.png?v=2014-1022-1126-' . $resourceVersion,
	'continue'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/continue.png?v=2014-1022-1126-' . $resourceVersion,
	'db-bg1'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-bg1.jpg?v=2014-1022-1126-' . $resourceVersion . 1,
	'db-bg2'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-bg2.jpg?v=2014-1022-1126-' . $resourceVersion . 1,
	'db-dialog-title-fail'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-dialog-title-fail.png?v=2014-1022-1126-' . $resourceVersion,
	'db-dialog-title-form'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-dialog-title-form.png?v=2014-1022-1126-' . $resourceVersion,
	'db-dialog-title-lucky'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-dialog-title-lucky.png?v=2014-1022-1126-' . $resourceVersion,
	'db-dialog-title-win'		=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-dialog-title-win.png?v=2014-1022-1126-' . $resourceVersion,
	'db-title1'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-title1.jpg?v=2014-1022-1126-' . $resourceVersion,
	'db-title2'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-title2.jpg?v=2014-1022-1126-' . $resourceVersion,
	'db-title3'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-title3.jpg?v=2014-1022-1126-' . $resourceVersion,
	'db-title4'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-title4.jpg?v=2014-1022-1126-' . $resourceVersion,
	'find-FZM'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/find-FZM.png?v=2014-1022-1126-' . $resourceVersion,
	'game-bg'					=>	SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/game-bg.png?v=2014-1022-1126-1' . $resourceVersion,
	'huafei'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/huafei.png?v=2014-1022-1126-' . $resourceVersion,
	'db-title5'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/db-title5.jpg?v=2014-1022-1126-' . $resourceVersion . 1,
	'gallery_css'				=>  SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/lightGallery/lightGallery.css?v=2014-1022-1126-' . $resourceVersion,
	'gallery_js'				=>  SYSTEM_RESOURCE_URL . '/view2/style/mobile/activity/lightGallery/lightGallery.min.js?v=2014-1022-1126-' . $resourceVersion,
	'duo_1-1'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/1-1.png?v=2014-1022-1126-' . $resourceVersion,
	'duo_1-2'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/1-2.png?v=2014-1022-1126-' . $resourceVersion,
	'duo_1-3'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/1-3.png?v=2014-1022-1126-' . $resourceVersion,
	'duo_1-4'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/1-4.png?v=2014-1022-1126-' . $resourceVersion,
	'blank'						=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/blank.gif?v=2014-1022-1126-' . $resourceVersion,
	'FZMblank'					=>  SYSTEM_RESOURCE_URL . '/view2/images/mobile/activity/spec_duobao/FZMblank.gif?v=2014-1022-1126-' . $resourceVersion,




	//2014-10家长端新版
	'amazeui'					=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/scripts/amazeui.js' . $resourceVersion,
	'm_new_parents_app'			=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/scripts/app.js' . $resourceVersion,

	'm_new_parents_amazeui_min_css'	=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/styles/amazeui.min.css' . $resourceVersion . 1,

	'm_new_parents_no_data_bg'	=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/images/bg1.jpg' . $resourceVersion,
	'm_new_parents_main_bg'		=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/images/main-banner.jpg' . $resourceVersion,
	'm_new_parents_about_bg'	=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/images/about.jpg' . $resourceVersion,
	'parents_pbj_banner'	=>	SYSTEM_RESOURCE_URL . '/view2/app/parents/images/banner-pbj-mobile.jpg' . $resourceVersion,

	//兑换商城
	'exchange_adv'				=>	SYSTEM_RESOURCE_URL . '/view2/images/exchange/exchange_adv.jpg' . $resourceVersion,
	'exchange_quick1'			=>	SYSTEM_RESOURCE_URL . '/view2/images/exchange/find1.png' . $resourceVersion,
	'exchange_quick2'			=>	SYSTEM_RESOURCE_URL . '/view2/images/exchange/find2.png' . $resourceVersion,
	'exchange_quick3'			=>	SYSTEM_RESOURCE_URL . '/view2/images/exchange/find3.png' . $resourceVersion,
	'exchange_quick4'			=>	SYSTEM_RESOURCE_URL . '/view2/images/exchange/find4.png' . $resourceVersion,


	//团队赛活动
	'dfdj_p_css'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/css/dfdj.css' . $resourceVersion,
	'dfdj_image1'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/1.jpg' . $resourceVersion . 1,
	'dfdj_image21'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/21.jpg' . $resourceVersion,
	'dfdj_image22'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/22.jpg' . $resourceVersion,
	'dfdj_image23'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/23.jpg' . $resourceVersion,
	'dfdj_image31'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/31.jpg' . $resourceVersion,
	'dfdj_image32'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/32.jpg' . $resourceVersion,
	'dfdj_image33'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/parents/dist/img/33.jpg' . $resourceVersion,

	'dfdj_stu_main'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/css/dfdj.css?v=2015-0105-1759',
	'dfdj_stu_sprite'			=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/css/sprite.css' . $resourceVersion,
	'dfdj_stu_banner'			=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/img/banner.jpg' . $resourceVersion . 1,
	'dfdj_stu_r'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/img/r.png' . $resourceVersion,
	'dfdj_stu_w'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/img/w.png' . $resourceVersion,
	'dfdj_round1_1'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/img/round1_1.jpg' . $resourceVersion,
	'dfdj_round1_2'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/img/round1_2.jpg' . $resourceVersion,
	'dfdj_round1_3'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/img/round1_3.jpg' . $resourceVersion,
	'dfdj_stu_modal'			=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/js/bootstrap-modal.js' . $resourceVersion,
	'dfdj_stu_tab'				=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/js/bootstrap-tab.js' . $resourceVersion,
	'dfdj_stu_dropdown'			=>	SYSTEM_RESOURCE_URL . '/view2/activity/webapp/dfdj/students/dist/js/bootstrap-dropdown.js' . $resourceVersion,

	'dfdj_award_dfdj'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/css/dfdj.css' . $resourceVersion,
	'dfdj_award_sprite'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/css/sprite.css' . $resourceVersion,
	'dfdj_award_banner'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/img/banner.jpg' . $resourceVersion,
	'dfdj_award_bg1'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/img/bg1.jpg' . $resourceVersion,
	'dfdj_award_bg2'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/img/bg2.jpg' . $resourceVersion,
	'dfdj_award_bg3'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/img/bg3.jpg' . $resourceVersion,
	'dfdj_award_bg4'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/img/bg4.jpg' . $resourceVersion,
	'dfdj_award_sd'		    	=>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/img/sd.png' . $resourceVersion,
	'dfdj_award_dropdown'		=>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/js/bootstrap-dropdown.js' . $resourceVersion,
	'dfdj_award_tab'		    =>	SYSTEM_RESOURCE_URL . '/view2/activity/pc/dfdj/students/dist/js/bootstrap-tab.js' . $resourceVersion,
	'script_ui1'		    =>	SYSTEM_RESOURCE_URL . '/view3/pc/plugin/ui1/ui.js' . $resourceVersion,
	'yh_banner_big'	=> '/v1/banner/yh_big.png',
	'yh_banner_small'	=> '/v1/banner/yh_small.png',
	//'script_layer'	=> SYSTEM_RESOURCE_URL . '/view3/pc/plugin/layer/layer.min.js',
	'script_layer'	=> 'http://res.sentsin.com/lay/lib/layer/layer.js?v=1.9.0',


 );
unset($resourceVersion);


