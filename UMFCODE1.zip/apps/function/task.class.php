<?php
/**
 * @author 罗启军 <455538375@qq.com>
 * @date 2014-7-17
 */
class Task{

	/**
	 * 更新每日任务进度
	 */
	public static function refreshTask($userId, $taskId){
		$oUserBehavior = m('UserBehavior');
		$aTaskList = $oUserBehavior->getUserDailyBehaviorInfo($userId);
		if(isset($aTaskList['task'])){
			foreach($aTaskList['task'] as $key => $aTask){
				if($aTask['task_id'] == $taskId && $aTask['finish_times'] < $GLOBALS['POINT']['daily_tasks'][$taskId]['times']){
					$aTaskList['task'][$key]['finish_times']++;
					if($aTaskList['task'][$key]['finish_times'] == $GLOBALS['POINT']['daily_tasks'][$taskId]['times']){
						$aTaskList['task'][$key]['status'] = 2;
					}
					$oUserBehavior->setUserDailyBehavior($aTaskList);
					break;
				}
			}
		}
	}
	
}