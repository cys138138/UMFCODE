<?php

class Parents{

	public static function loginChildren(){
		$aParentUserInfo = checkParentLogin();
		$studentId = isset($aParentUserInfo['user_ids'][0]) && $aParentUserInfo['user_ids'][0] ? $aParentUserInfo['user_ids'][0] : 0;
		if(!$studentId){
			if(isset($aParentUserInfo['xxt_data']['CityId']) && isset($aParentUserInfo['xxt_data']['UserId'])){
				try{
					$aReasult = Xxt::getParentInfo($aParentUserInfo['xxt_data']['CityId'], $aParentUserInfo['xxt_data']['UserId']);
				}catch(XxtException $e){
					halt($e->getMessage() . '获取和教育家长信息失败！', true);
				}
				$aXxtParentInfo = $aReasult;

				//注册学生账号
				if($aXxtParentInfo){
					if(isset($aXxtParentInfo['StuUserId']) && $aXxtParentInfo['StuUserId']){
						//再次检查用户是否存在
						$aChildUserInfo = m('User')->getUserInfoByXxtId($aXxtParentInfo['StuUserId']);
						if(empty($aChildUserInfo)){
							$registerStudentId = User::registerByXXT($aXxtParentInfo['StuUserId'], array('UserId' => $aXxtParentInfo['StuUserId'], 'CityId' => $aParentUserInfo['xxt_data']['CityId'], 'RoleType' => 2));
							if(!$registerStudentId){
								halt('家长登陆孩子时注册孩子账号失败', false, $aXxtParentInfo['StuUserId']);
							}
							$studentId = $registerStudentId;
						}else{
							$studentId = $aChildUserInfo['id'];
						}

						$aData = array(
							'id' => $aParentUserInfo['id'],
							'user_ids' => $studentId
						);
						$oParent = m('Parent');
						$isSetSuccess = $oParent->setParentInfo($aData, array('id' => $aParentUserInfo['id']));
						if(!$isSetSuccess){
							$aParent = $oParent->getParentInfoById($aParentUserInfo['id']);
							halt('更新家长信息失败', false, array($isSetSuccess, $aParent, $aData, $aParentUserInfo));
						}
					}
				}
			}
		}

		if(!$studentId){
			alert('抱歉,登陆失败', 0);
		}
		User::loginUser($studentId);
		User::loginFromParent($studentId);
	}

	public static function loginUser($parentId, $autoLogin = 0){
		Cookie::setEncrypt('id', $parentId, time() + 31536000);
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$autoLoginCode = md5($userAgent . $parentId);
		if($autoLogin == 1){
			Cookie::setXcrypt('parentAutoLogin', $autoLoginCode, time() + 31536000);
		}else{
			Cookie::setXcrypt('parentAutoLogin', $autoLoginCode);
		}
		return true;
	}

	public static function logoutUser($parentId){
		Cookie::delete('parentAutoLogin');
		Cookie::delete('mobile');
		return true;
	}


	//---------------------------新版 2014-10-22--------------------------------------
	//statistics('esMode', array('type' => 'mission', 'subject' => 1, 'add_type' => 1));
	public static function statistics($type, $aRequestData){
		$aModeType = array(
			'esMode'		 => '_upEsMode',
			'mission'		 => '_upMission',
			'match'			 => '_upMatch'
		);
		if(!array_key_exists($type, $aModeType)){
			alert('参数有误', 0);
		}

		$aData = isset($aRequestData) ? $aRequestData : array();
		if($type == 'match'){
			//当颁奖时，外部会传入该键
			$aUserLoginInfo['id'] = $aData['user_id'];
			unset($aData['user_id']);
		}else{
			$aUserLoginInfo = isLogin() ? isLogin() : array();
		}

		$mParentModel = m('Parent');
		$aMonthUserInfo = self::_getMonthUserInfo($aUserLoginInfo['id']);
		if(!$aMonthUserInfo){
			$aUserInfo = self::_initUserData($aUserLoginInfo['id']);

			if(!$mParentModel->addUserMonthStatistics($aUserInfo)){
				alert('初始本月用户数据失败', 0);
			}

			//初始化后重新赋值
			$aMonthUserInfo = self::_getMonthUserInfo($aUserLoginInfo['id']);
		}

		if(!$aMonthUserInfo || $aMonthUserInfo === false){
			halt('统计题目错误信息时，读取学生的统计信息为空', true);
		}
		self::$aModeType[$type]($aMonthUserInfo, $aData);
	}

	private static function _upEsMode($aMonthUserInfo, $aData){
		$aModeType = array(
			'mission',
			'pk',
			'match'
		);
		if(!in_array($aData['type'], $aModeType)){
			alert('不存在的类型', 0);
		}
		$aSubject = array(
			1,
			2,
			3
		);
		if(in_array($aData['subject'], $aSubject)){
			if($aData['add_type'] === 1){
				++$aMonthUserInfo['statistics']['es'][$aData['type']][$aData['subject']]['es_total'];
			}elseif($aData['add_type'] === 2){
				++$aMonthUserInfo['statistics']['es'][$aData['type']][$aData['subject']]['es_total'];
				++$aMonthUserInfo['statistics']['es'][$aData['type']][$aData['subject']]['es_wrong'];
			}elseif($aData['add_type'] === 3){
				$aMonthUserInfo['statistics']['es'][$aData['type']][$aData['subject']]['es_wrong'] += $aData['es_wrong'];
			}
			$aMonthUserInfo['score'] = self::autoCountScore($aMonthUserInfo['statistics']);
			if(m('Parent')->setUserMonthStatistics($aMonthUserInfo) === false){
				halt('更新和教育家长端学生答题信息数据失败', true);
			}
		}
	}

	private static function _upMission($aMonthUserInfo, $aData){
			$aMonthUserInfo['statistics']['mission'][$aData['mission_id']] = $aData;
			$aMonthUserInfo['score'] = self::autoCountScore($aMonthUserInfo['statistics']);
			if(!m('Parent')->setUserMonthStatistics($aMonthUserInfo)){
				halt('更新和教育家长端学生闯关数据失败1', true);
			}

	}

	private static function _upMatch($aMonthUserInfo, $aData){
		if(empty($aMonthUserInfo)){
			halt('更新学生比赛获奖统计失败', false, array($aMonthUserInfo, $aData));
		}
		$aMonthUserInfo['statistics']['match'][] = $aData;
		$aMonthUserInfo['score'] = self::autoCountScore($aMonthUserInfo['statistics']);
		if(!m('Parent')->setUserMonthStatistics($aMonthUserInfo)){
			halt('更新和教育家长端学生闯关数据失败', true);
		}
	}

	//能力值计算方法
	public static function autoCountScore($aUserMonthStatistics){
		$matchPrizeCount = $allMissionScoreCount = $passMissionCount = $esWrongCount = $esAllCount = 0;
		foreach($aUserMonthStatistics['es'] as $key => $aSubjectList){
			if($key == 'es_repair_count'){
				continue;
			}
			foreach($aSubjectList as $aSubject){
				$esAllCount += $aSubject['es_total'];
				$esWrongCount += $aSubject['es_wrong'];
			}
		}
		$passMissionCount = count($aUserMonthStatistics['mission']);
		foreach($aUserMonthStatistics['mission'] as $aMissionInfo){
			$allMissionScoreCount += $aMissionInfo['score'];
		}
		$matchPrizeCount = count($aUserMonthStatistics['match']);
		$systemFullScore = 100;
		if($esAllCount < 50){
			return 0;
		}
		$missionScore = 0;
		if($passMissionCount){
			$missionAvgScorePercent = $allMissionScoreCount / $passMissionCount / 100 / 100;
			$systemMissionScore = 5;
			if($passMissionCount == 1 || $passMissionCount == 2){
				$missionScore = $systemMissionScore * $missionAvgScorePercent;
			}elseif($passMissionCount == 3 || $passMissionCount == 4){
				$systemMissionScore = 10;
				$missionScore = $systemMissionScore * $missionAvgScorePercent;
			}elseif($passMissionCount >= 5){
				$systemMissionScore = 15;
				$missionScore = 15 * $missionAvgScorePercent;
			}
			$systemFullScore -= $systemMissionScore;
		}
		$matchScore = 0;
		if($matchPrizeCount){
			$systemMatchScore = 15;
			$matchScore = $systemMatchScore;
			$systemFullScore -= $systemMatchScore;
		}
		$esScore = 0;
		$systemEsScore = 2;
		if($esAllCount >= 80 && $esAllCount < 110){
			$systemEsScore = 3;
		}elseif($esAllCount >= 110 && $esAllCount < 150){
			$systemEsScore = 4;
		}elseif($esAllCount >= 150){
			$systemEsScore = 5;
		}
		$esScore = $systemEsScore;
		$systemFullScore -= $systemEsScore;

		$correctScore = $systemFullScore * ($esAllCount - $esWrongCount) / $esAllCount;
		return $missionScore + $matchScore + $esScore + $correctScore;
	}

	private static function _getMonthUserInfo($userId){
		$aMonthUserInfo =  m('Parent')->getUserMonthStatisticsInfo($userId, date('Ym'));
		if(!$aMonthUserInfo){
			return false;
		}else{
			return $aMonthUserInfo;
		}
	}

	private static function _initUserData($userId = 0){
		$aUserInfo = getUserInfo($userId, array('personal','area','class'));
		if($aUserInfo === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => null);
		}
		return array(
			'user_id' => $aUserInfo['id'],
			'month' => date('Ym'),
			'city_id' => $aUserInfo['city_id'],
			'school_id' => $aUserInfo['school_id'],
			'grade' => $aUserInfo['grade'],
			'class' => $aUserInfo['class'],
			'score' => 0,
			'statistics' => array(
				'es' =>	array(
					'es_repair_count' => 0,
					'mission' => array(
						1 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
						2 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
						3 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
					),
					'pk' => array(
						1 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
						2 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
						3 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
					),
					'match' => array(
						1 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
						2 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
						3 => array(
							'es_total' => 0,
							'es_wrong' => 0
						),
					)
				),
				'mission' => array(),
				'match' => array()
			),
		);
	}


}