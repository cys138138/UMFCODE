<?php
class Match{

	private $_userId = 0;
	private $_aUser = array();

	function __construct(){
		$this->_aUser = isLogin();
		$this->_userId = intval($this->_aUser['id']);
	}


	/*
	 * Ajax比赛排行榜
	 */
	public function matchRankingList($page = 0, $matchId = 0, $pageSize = 10){
		if($page < 0){
			return array('msg' => '所传参数有误', 'status' => -1, 'data' => '');
		}

		//最多查看5页
		if($page > 5){
			$page = 1;
		}

		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($matchId);
		if($aMatchInfo === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}elseif(!$aMatchInfo){
			return array('msg' => '抱歉，不存在此场比赛！', 'status' => -1, 'data' => '');
		}

		$aMatchRankingList = $oMatch->getMatchRankingList($matchId, $page, $pageSize);
		if($aMatchRankingList === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}
		if(!$aMatchRankingList && $page > 1){
			return array('msg' => '最后一页了哦', 'status' => -1, 'data' => '');
		}

		foreach($aMatchRankingList as $key => $aRank){
			$aMatchRankingList[$key]['rankNum'] = $key + $pageSize * ($page - 1) + 1;
			$aMatchRankingList[$key]['best_score'] = $aMatchRankingList[$key]['best_score'] / 100;
			$oUserNumerical = m('UserNumerical');
			$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($aRank['id']);
			if($aUserNumerical === false){
				return array('msg' => '系统错误', 'status' => 0, 'data' => '');
			}
			$aMatchRankingList[$key] = array_merge($aMatchRankingList[$key], $aUserNumerical);

			$aUserInfo = getUserInfo($aRank['id'], ['class']);
			if($aUserInfo){
				$aMatchRankingList[$key]['school'] = $aUserInfo['school_name'];
				$aMatchRankingList[$key]['class'] = $aUserInfo['grade'] . '年级 ' . $aUserInfo['class'];
			}else{
				$aMatchRankingList[$key]['school'] = '--';
				$aMatchRankingList[$key]['class'] = '--';
			}
		}
		return array('msg' => '', 'status' => 1, 'data' => $aMatchRankingList);
	}

	//Ajax我的赛事列表
	// @getType = 0 电脑  1和教育
	public function getMatchListByUser($type = 1, $page = 0, $pageSize = 0, $prizeFlag, $getType = 0){
		$aOrderArray = array(
			1 => '',					//默认排序
			2 => '`create_time` DESC',	//参赛时间排序
			3 => '`best_score` DESC',	//最高得分排序
			4 => '`ranking` ASC'		//排名排序排序
		);
		if($page < 1 || !isset($aOrderArray[$type]) || ($prizeFlag != 1 && $prizeFlag != 0 )){
			return array('msg' => '参数非法', 'status' => 0, 'data' =>'');
		}
		$oMatch = new MatchModel();
		$aMatchList = $oMatch->getUserMatchListNew($this->_userId, $page, $pageSize, $aOrderArray[$type], $prizeFlag);
		if($aMatchList === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}

		$now = time();
		$aSubjectArray = $this->_getSubjectList();
		$aGradeArray = $this->_gradeArray;
		foreach ($aMatchList as &$aMatchInfo){

			//状态
			$aMatchInfo['status'] = 0; //己结束
			if($aMatchInfo['match_end_time'] > $now ){
				$aMatchInfo['status'] = 1; //再次参赛
				if(
						($aMatchInfo['match_user_relation']['remainder_es_ids'] && $aMatchInfo['match_user_relation']['start_time'] == 0 && $aMatchInfo['match_user_relation']['end_time'] == 0)
						||
						($aMatchInfo['match_user_relation']['remainder_es_ids'] && $aMatchInfo['match_user_relation']['start_time'] > 0 && ($now - $aMatchInfo['match_user_relation']['start_time'] < $aMatchInfo['duration'] * 60))
				){
					$aMatchInfo['status'] = 2; //继续末完成比赛
				}
			}else{
				//己结束的查看是否可领取奖励
				if(isset($aMatchInfo['winners']['top']) && $aMatchInfo['winners']['top']){
					foreach($aMatchInfo['winners']['top'] as $aTop){
						if($aTop['user_id'] == $this->_userId && $aTop['receive_time'] == 0){
							$aMatchInfo['status'] = 3; //领取奖励\
							break;
						}
					}

				}

				if($aMatchInfo['status'] != 3 && isset($aMatchInfo['winners']['rand']) && $aMatchInfo['winners']['rand']){
					foreach($aMatchInfo['winners']['rand'] as $aRand){
						if($aRand['user_id'] == $this->_userId && $aRand['receive_time'] == 0){
							$aMatchInfo['status'] = 3; //领取奖励
							break;
						}
					}
				}
			}

			//参赛人数
			$registrationCount = $oMatch->getRegistrationCountByMatchId($aMatchInfo['id']);
			if($registrationCount === false){
				return array('msg' => '系统错误', 'status' => 0, 'data' => '');
			}
			$aMatchInfo['registration_count'] = $registrationCount;

			//排名及最高得分
			if($aMatchInfo['match_user_relation']['best_score'] > 0){
				$aMatchInfo['match_user_relation']['best_score'] = $aMatchInfo['match_user_relation']['best_score'] / 100;
			}else{
				$aMatchInfo['match_user_relation']['best_score'] = $aMatchInfo['match_user_relation']['best_score'] / 100;
				$aMatchInfo['match_user_relation']['ranking'] = '--';
			}

			//年级和科目字符串
			$aMatchInfo['grade_str'] = '';
			if(isset($aGradeArray[$aMatchInfo['grade_id']])){
				$aMatchInfo['grade_str'] = $aGradeArray[$aMatchInfo['grade_id']];
			}
			if(isset($aSubjectArray[$aMatchInfo['subject_id']])){
				$aMatchInfo['grade_str'] .= $aSubjectArray[$aMatchInfo['subject_id']];
			}

			if($aMatchInfo['grade_str']){
				$aMatchInfo['grade_str'] = '【' . $aMatchInfo['grade_str'] . '】';
			}
		}

		if($getType){
			//赛事总数
			$matchCount = $oMatch->getUserMatchCount($this->_userId);
			if($matchCount === false){
				return array('msg' => '系统错误', 'status' => 0, 'data' => '');
			}
			$aData = array(
				'aMatchList' => $aMatchList,
				'pageCount' => ceil($matchCount / $pageSize)
			);

			unset($aMatchList);
			unset($pageCount);
			return array('msg' => '请求成功', 'status' => 1, 'data' => $aData);
		}else{
			return array('msg' => '请求成功', 'status' => 1, 'data' => $aMatchList);
		}

	}

	//ajax取赛事分页列表
	public function moreMatchList($page = 1, $type = 'all', $pageSize = 30){
		if($page < 1){
			return array('msg' => '数据错误', 'status' => 0, 'data' => '');
		}

		$order = '`id` DESC';
		$aCondition = array();
		$aMatchList = array();
		$pageCount = 1;
		$oMatch = m('Match');
		if($type == 'all'){
			if($this->_aUser['xxt_id']){
				$aCondition['is_xxt_user'] = 1;
			}else{
				$aCondition['is_xxt_user'] = 0;
			}
			$aCondition['status'] = 8;
			$aCondition['xxt_type'] = $this->_aUser['xxt_type'];
			$order = '`match_start_time` ASC';
			$aMatchList = $oMatch->getMatchList($aCondition, $page, $pageSize, $order, true, $this->_userId);
		}else{
			$aMatchList = $oMatch->getUserMatchList($this->_userId, $aCondition, $page, $pageSize, $order);
		}
		if($aMatchList === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}
		if($aMatchList){
			$matchCount = $oMatch->getMatchCount($aCondition);
			if($matchCount === false){
				return array('msg' => '系统错误', 'status' => 0, 'data' => '');
			}
			$pageCount = ceil($matchCount / $pageSize);
			$now = time();
			$aSubjectArrary = $this->_getSubjectList();
			foreach($aMatchList as &$aMatchInfo){
				$aMatchInfo['profile'] = SYSTEM_RESOURCE_URL .$aMatchInfo['profile'];
				$aMatchInfo['grade_name'] = isset($this->_gradeArray[$aMatchInfo['grade_id']]) ? $this->_gradeArray[$aMatchInfo['grade_id']] : '';
				$aMatchInfo['subject_name'] = isset($aSubjectArrary[$aMatchInfo['subject_id']]) ? $aSubjectArrary[$aMatchInfo['subject_id']] : '';
				$aMatchInfo['match_time_str'] = date('n月j日 H:i', $aMatchInfo['match_start_time']) . ' - ' . date('n月j日 H:i', $aMatchInfo['match_end_time']);

				$aMatchInfo['status'] = 0; //己结束
				if($aMatchInfo['match_start_time'] > $now){
					$aMatchInfo['status'] = 2; //倒计时
					$second = $aMatchInfo['match_start_time'] - $now;
					$aMatchInfo['aBeginTime'] = $this->_getTimeGo($second);
				}elseif($aMatchInfo['match_start_time'] <= $now && $now < $aMatchInfo['match_end_time']) {
					$aMatchInfo['status'] = 1;	//比赛中
					$second = $aMatchInfo['match_end_time'] - $now;
					$aMatchInfo['aBeginTime'] = $this->_getTimeGo($second);
				}


				$registrationCount = $oMatch->getRegistrationCountByMatchId($aMatchInfo['id']);
				if($registrationCount === false){
					return array('msg' => '系统错误', 'status' => 0, 'data' => '');
					break;
				}
				$aMatchInfo['registration_count'] = $registrationCount;
				$aMatchInfo['es_count'] = 0;
				foreach($aMatchInfo['es_rule'] as $rule){
					$aMatchInfo['es_count'] = $aMatchInfo['es_count'] + $rule['es_count'];
				}
				if($aMatchInfo['limit_grades']){
					$aMatchInfo['limit_grades'] = $this->_getGradeArrayToString($aMatchInfo['limit_grades']);
				}else{
					$aMatchInfo['limit_grades'] = 0;
				}
			}
		}
		$aData = array(
			'aMatchList' => $aMatchList,
			'pageCount' => $pageCount
		);

		unset($aMatchList);
		unset($pageCount);
		return array('msg' => '读取成功', 'status' => 1, 'data' => $aData);
	}

	/*
	 *检查用户是否符合报名条件
	 */
	public function checkUserJoinStatus($matchId){
		if(!$matchId){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}

		$oMatch = m('Match');
		$aMatch = $oMatch->getMatchInfoById($matchId);
		if($aMatch === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}
		if(!$aMatch){
			return array('msg' => '赛事不存在！', 'status' => 0, 'data' => '');
		}

		$aMyMatch = $oMatch->getMatchUserRelationInfo($this->_userId, $matchId);
		if($aMyMatch === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}

		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}
		$aUserNumerical = array_merge(getUserInfo($this->_userId, array('class')), $aUserNumerical);

		$aJoinResult = array(
			'level_limit' => 1,
			'gold_limit' => 1,
			'address' => $aMyMatch,
			'match_info' => $aMatch,
		);

		if($aMatch['limit_level'] && $aUserNumerical['level'] < $aMatch['limit_level']){
			$aJoinResult['level_limit'] = 0;
		}

		if($aMatch['registration_fee'] && $aUserNumerical['gold'] < $aMatch['registration_fee'] ){
			$aJoinResult['gold_limit'] = 0;
		}
		if($aMatch['limit_grades']){
			if(!in_array($aUserNumerical['grade'], $aMatch['limit_grades'])){
				return array('msg' => '该场比赛仅限' . $this->_getGradeArrayToString($aMatch['limit_grades']) . '参加', 'status' => 0, 'data' => '');
			}
		}
		if($aMatch['limit_xxt_type']){
			if(!in_array($aUserNumerical['xxt_type'], $aMatch['limit_xxt_type'])){
				return array('msg' => '您不能参加这场比赛', 'status' => 0, 'data' => '');
			}
		}

		if($aMatch['limit_xxt'] && !$aUserNumerical['xxt_id']){
			return array('msg' => '很抱歉！您不是和教育用户无法参加该场比赛', 'status' => 0, 'data' => '');
		}

		$checkTeam = $this->_checkTeamMatch($aMatch);	//团队赛判断
		if($checkTeam !== true){
			return $checkTeam;
		}

		return array('msg' => $aMatch['limit_grades'], 'status' => 1, 'data' => $aJoinResult);
	}

	private function _getGradeArrayToString($aGradeArray){
		$gradeNmae = '';
		foreach($aGradeArray as $grade){
			$gradeNmae .= $GLOBALS['UMF_GRADE'][$grade] . ',';
		}
		return substr($gradeNmae, 0, -1);
	}

	private function _checkTeamMatch($aMatch){
		//团队赛判断
		if($aMatch['is_team_match']){
			$oTeam = m('Team');
			$aTeamMatch = $oTeam->getTeamMatchByLitteMatch($aMatch['id']);
			if($aTeamMatch){
				$aJoin = $oTeam->checkCreate($aTeamMatch['id'], $this->_userId);
				if(!$aJoin || !$aJoin['member_one']){
					return array('msg' => '该赛事为团队赛，请先到活动页面组建队伍', 'status' => -1, 'data' => '');
				}
				if($aTeamMatch['second_match_id'] == $aMatch['id']){
					$firstTotal = $aJoin['first_one_score'];
					$memberCount = 1;
					$passScore = Team::ONE_AVERAGE;
					if($aJoin['member_two']){
						$memberCount = 2;
						$passScore = Team::TWO_AVERAGE;
						$firstTotal += $aJoin['first_two_score'];
					}
					if($aJoin['member_three']){
						$memberCount = 3;
						$passScore = Team::THREE_AVERAGE;
						$firstTotal += $aJoin['first_three_score'];
					}
					if(($firstTotal / $memberCount) < $passScore){
						return array('msg' => '您的团队现在有 '. $memberCount .' 名成员，平均分要达到 ' . $passScore . ' 分才可以参加第二轮', 'status' => -1, 'data' => '');
					}

				}
			}
		}
		return true;
	}

	//参加比赛
	// @getType = 0 电脑  1和教育
	public function join($matchId = 0, $areaId = 0, $aUserOption = array(), $getType = 0){

		if($getType){
			$vResult = v('mobile,detailedPlace');
		}else{
			$vResult = v('mobile,detailedPlace,areaId');
		}

		if($vResult){
			return array('msg' => $vResult, 'status' => 0, 'data' => '');

		}

		$oUser = m('User');
		if(!$getType){
			$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
			if($aAreaInfo === false){
				return array('msg' => '网络可能有点慢，请稍后再试!!', 'status' => 0, 'data' => '');
			}else if(!$aAreaInfo){
				return array('msg' => '非法的地区!', 'status' => 0, 'data' => '');
			}
		}

		$aUserData = array();
		$aUserData['name'] = $aUserOption['name'];
		$aUserData['call_phone'] = $aUserOption['call_phone'];
		$aUserData['qq'] = isset($aUserOption['qq']) ? $aUserOption['qq'] : '';
		$aUserData['address'] = $aUserOption['address'];
		if(!$getType){
			$aUserData['area_id'] = $areaId;
			$aUserData['province_id'] = $aUserOption['province_id'];
			$aUserData['city_id'] = $aUserOption['city_id'];
		}

		//判断用户有没有收货地址和电话
		$aUser = $oUser->getUserDetailInfoByUserId($this->_userId);
		if(!$aUser['call_phone'] || !$aUser['address']){
			$aData = array(
				'id' => $this->_userId,
				'call_phone' => $aUserData['call_phone'],
				'address' => $aUserData['address']
			);
			$isSetSuccess = $oUser->setUserInfo($aData);
			if(!$isSetSuccess){
				alert('网络可能有点慢，请稍后再试!', 0);
			}
		}

		$oMatch = m('Match');
		$aMatch = $oMatch->getMatchInfoById($matchId);
		if($aMatch === false){
			return array('msg' => '系统错误!', 'status' => 0, 'data' => '');
		}
		if(!$aMatch){
			return array('msg' => '赛事不存在!', 'status' => 0, 'data' => '');
		}

		$nowTime = time();
		if($aMatch['match_end_time'] <= $nowTime){
			return array('msg' => '抱歉，比赛己经结束了哦！', 'status' => -1, 'data' => '');
		}elseif($aMatch['match_start_time'] > $nowTime){
			return array('msg' => '比赛还没开始哦！等比赛开始了再参加比赛吧', 'status' => -1, 'data' => '');
		}

		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}

		$aMyMatch = $oMatch->getMatchUserRelationInfo($this->_userId, $matchId);
		if($aMyMatch === false){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}
		if($aMyMatch){
			return array('msg' => '抱歉，您已经报过名了哦!', 'status' => -1, 'data' => '');
		}

		$checkTeam = $this->_checkTeamMatch($aMatch);	//团队赛判断
		if($checkTeam !== true){
			return $checkTeam;
		}

		$aJoinResult = array(
			'level_limit' => 1,
			'gold_limit' => 1
		);

		$isCanRegister = true;
		if($aMatch['limit_level'] && $aUserNumerical['level'] < $aMatch['limit_level']){
			$aJoinResult['level_limit'] = 0;
			$isCanRegister = false;
		}

		if($aMatch['registration_fee'] && $aUserNumerical['gold'] < $aMatch['registration_fee']){
			$aJoinResult['gold_limit'] = 0;
			$isCanRegister = false;
		}

		$aRemainderEsIds = $getType ? array() : $oMatch->distributeEsList($aMatch['es_rule'], $aMatch['es_set']);

		if($isCanRegister){
			//每日任务 参加2场比赛
			Task::refreshTask($this->_userId, 7);

			$aData = array(
				'user_id' => $this->_userId,
				'match_id' => $matchId,
				'remainder_es_ids' => $aRemainderEsIds,
				'create_time' => $nowTime,
				'remainder_match_times' => $aMatch['limit_times'],
				'address' => $aUserData,
			);
			$isJoinSuccess = $oMatch->registrationAction($aData, $aMatch['registration_fee']);
			if($isJoinSuccess === false){
				return array('msg' => '系统错误', 'status' => 0, 'data' => '');
			}
			$aJoinResult['join_result'] = $isJoinSuccess;
			return array('msg' => '参赛成功', 'status' => 1, 'data' => $aJoinResult);
		}else{
			$aJoinResult['join_result'] = 0;
			return array('msg' => '参赛失败', 'status' => -1, 'data' => '');
		}
	}

	//再次参加比赛
	// @getType = 0 电脑  1和教育
	public function reJoin($matchId = 0, $areaId = 0, $aUserOption = array(), $getType = 0){

		$oMatch = m('Match');
		$aMatch = $oMatch->getMatchInfoById($matchId);
		if($aMatch === false){
			return array('msg' => '抱歉，系统出错，请稍后再试！', 'status' => 0, 'data' => '');
		}
		if(!$aMatch){
			return array('msg' => '赛事不存在！', 'status' => -1, 'data' => '');
		}
		if(!$getType){
			$vResult = v('mobile,detailedPlace,areaId');
			if($vResult){
				return array('msg' => $vResult, 'status' => -1, 'data' => '');
			}
		}

		$aUserData = array();
		$aUserData['name'] = $aUserOption['name'];
		$aUserData['call_phone'] = $aUserOption['call_phone'];
		$aUserData['qq'] = isset($aUserOption['qq']) ? $aUserOption['qq'] : '';
		$aUserData['address'] = $aUserOption['address'];

		$oUser = m('User');

		//判断用户有没有收货地址和电话
		$aUser = $oUser->getUserDetailInfoByUserId($this->_userId);
		if(!$aUser['call_phone'] || !$aUser['address']){
			$aData = array(
				'id' => $this->_userId,
				'call_phone' => $aUserData['call_phone'],
				'address' => $aUserData['address']
			);
			$isSetSuccess = $oUser->setUserInfo($aData);
			if(!$isSetSuccess){
				alert('网络可能有点慢，请稍后再试!', 0);
			}
		}

		if(!$getType){
			$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
			if($aAreaInfo === false){
				return array('msg' => '网络可能有点慢，请稍后再试', 'status' => 0, 'data' => '');
			}else if(!$aAreaInfo){
				return array('msg' => '非法的地区', 'status' => 0, 'data' => '');
			}

			$aUserData['area_id'] = $areaId;
			$aUserData['province_id'] = $aUserOption['province_id'];
			$aUserData['city_id'] = $aUserOption['city_id'];
		}

		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			return array('msg' => '网络可能有点慢，请稍后再试', 'status' => 0, 'data' => '');
		}

		$aMyMatch = $oMatch->getMatchUserRelationInfo($this->_userId, $matchId);
		if($aMyMatch === false){
			return array('msg' => '网络可能有点慢，请稍后再试', 'status' => 0, 'data' => '');
		}
		if(!$aMyMatch){
			return array('msg' => '抱歉，没有您之前的参赛记录哦！', 'status' => -1, 'data' => '');
		}
		$aJoinResult = array();
		$nowTime = time();
		if($aMatch['match_end_time'] <= $nowTime){
			return array('msg' => '抱歉，比赛已经结束了哦！', 'status' => -1, 'data' => '');
		}elseif($aMatch['match_start_time'] > $nowTime){
			return array('msg' => '比赛还没开始哦！等比赛开始了再参加比赛吧！', 'status' => -1, 'data' => '');
		}

		if($aMyMatch['remainder_match_times'] <= 0 && $aMatch['limit_times']){
			return array('msg' => '参赛机会用完了哦，等结果吧！', 'status' => -1, 'data' => '');
		}

		$isCanReJoin = true;
		$aJoinResult['gold_limit'] = true;
		if($aMatch['rejoin_fee'] && $aUserNumerical['gold'] < $aMatch['rejoin_fee'] ){
			$aJoinResult['gold_limit'] = false;
			$isCanReJoin = false;
		}

		$aRemainderEsIds = $getType ? array() : $oMatch->distributeEsList($aMatch['es_rule'], $aMatch['es_set']);
		if($isCanReJoin){
			$aMyMatch['address'] = $aUserData;
			$aMyMatch['remainder_es_ids'] = $aRemainderEsIds;
			$isReJoinSuccess = $oMatch->joinMatchAgain($aMyMatch, $aMatch['rejoin_fee']);
			if($isReJoinSuccess === false){
				return array('msg' => '抱歉，系统出错，请稍后再试！', 'status' => 0, 'data' => '');
			}
			if(!$isReJoinSuccess){
				return array('msg' => '再次参赛失败！', 'status' => -1, 'data' => '');
			}
			return array('msg' => '再次参赛成功！', 'status' => 1, 'data' => $aJoinResult);
		}else{
			return array('msg' => '再次参赛失败,金币不足', 'status' => 1 , 'data' => $aJoinResult);
		}

	}


	public function getReJoinUserList($page, $matchId){
		$pageSize = 50;

		if(!$matchId){
			return array('msg' => '系统错误!!', 'status' => 0, 'data' => '');
		}

		$oMatch = m('Match');
		$aMatch = $oMatch->getMatchInfoById($matchId);
		if($aMatch === false){
			return array('msg' => '系统错误!!', 'status' => 0, 'data' => '');
		}
		if(!$aMatch){
			return array('msg' => '赛事不在!!', 'status' => 0, 'data' => '');
		}
		$aReJoinUserList = array();
		if($aMatch['match_start_time'] < time()){
			$aReJoinUserList = $oMatch->getRejoinMatchUserList($matchId, $page, $pageSize);
			if($aReJoinUserList){
				foreach($aReJoinUserList as $key => $aRejoinUser){
					$aReJoinUserList[$key]['rejoin_time_str'] = getCreateTime($aReJoinUserList[$key]['last_rejoin_time']);
				}
			}
		}
		if($aReJoinUserList === false){
			return array('msg' => '读取再次参赛数据失败!', 'status' => -1, 'data' => array());
		}else{
			return array('msg' => '读取再次参赛数据成功!', 'status' => 1, 'data' => $aReJoinUserList);
		}
	}

	/*
	 *比赛开始
	 */
	public function startMatch($myMatchId){
		$oMatch = m('Match');

		$aMyMatch = $oMatch->getMatchUserRelationInfoById($myMatchId);
		if(!$aMyMatch){
			return array('msg' => '你没有参加该比赛', 'status' => 0, 'data' => '');
		}

		if($aMyMatch['user_id'] != $this->_userId){
			return array('msg' => '你没有参加该比赛', 'status' => 0, 'data' => '');
		}

		$aMatch = $oMatch->getMatchInfoById($aMyMatch['match_id']);
		if(!$aMatch){
			return array('msg' => '没有找到该场比赛', 'status' => 0, 'data' => '');
		}


		$now = time();
		if($now < $aMatch['match_start_time']){
			return array('msg' => '比赛还没开始呢', 'status' => 3, 'data' => '');
		}
		if($now > $aMatch['match_end_time']){
			return array('msg' => '比赛时间已经结束啦', 'status' => 2, 'data' => '');
		}

		$aMyMatch['start_time'] = time();
		$aHistory = array(
			'start_time' => time(),
			'end_time' => 0,
			'score' => 0,
		);
		array_push($aMyMatch['match_history'], $aHistory);
		if($oMatch->setMatchUserRelation($aMyMatch) === false){
				return array('msg' => '系统出错', 'status' => 0, 'data' => '');
		}
		return array('msg' => '去吧骚年！去争取自己的荣誉', 'status' => 1, 'data' => '');
	}


	/*
	 *比赛作答处理
	 */
	public function markingMatchAnswer($aMatchAnswer){

		if(!$this->_checkMatch($aMatchAnswer)){
			return array('msg' => '作答格式有错', 'status' => 0, 'data' => '');
		}
		$oMatch = m('Match');
		$aMyMatch = $oMatch->getMatchUserRelationInfoById($aMatchAnswer['match_id']);
		if(!$aMyMatch){
			return array('msg' => '你没有参加该比赛', 'status' => 0, 'data' => '');
		}

		if($aMyMatch['user_id'] != $this->_userId){
			return array('msg' => '你没有参加该比赛', 'status' => 0, 'data' => '');
		}

		$aMatch = $oMatch->getMatchInfoById($aMyMatch['match_id']);
		if(!$aMatch){
			return array('msg' => '赛事不存在', 'status' => 0, 'data' => '');
		}
		$now = time();
		if(!($now >= $aMatch['match_start_time'] && $now <= $aMatch['match_end_time'])){
			if($now > $aMatch['match_end_time']){
				return array('msg' => '比赛已经结束了', 'status' => 0, 'data' => '');
			}
			return array('msg' => '现在不是比赛时间喔', 'status' => 0, 'data' => '');
		}

		if($now > ($aMyMatch['start_time'] + $aMatch['duration'] * 60)){
			return array('msg' => '该次比赛已经结束', 'status' => 2, 'data' => '');
		}

		$aMatchAnswer['user_answer']['id'] = Xxtea::decrypt($aMatchAnswer['user_answer']['id']);
		$oEs = m('Es');
		$aEsInfo = $oEs->getOfficialEsInfoById($aMatchAnswer['user_answer']['id']);
		if(!$aEsInfo){
			return array('msg' => 'ID为 ' . $aMatchAnswer['answer']['id'] . ' 的题目不存在', 'status' => 0, 'data' => '');
		}

		if($aMatchAnswer['user_answer']['id'] != current($aMyMatch['remainder_es_ids'])){
			$aResult['next_es'] = $this->_nextEs($aMyMatch['remainder_es_ids']);
			return array('msg' => '下一题哈哈哈', 'status' => 1, 'data' => $aResult);
			//alert('ID为 <b>' . $aMatchAnswer['user_answer']['id'] . '</b> 不是该次分发给您的题目喔', 0);
		}

		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
		$aResult = $oEsPlugin->getCorrectness($aEsInfo['content_json'], $aMatchAnswer['user_answer']['answer']);
		$isPass = $aResult['pass'];
		unset($aResult['pass']);
		unset($aResult['scale']);
		//答完一道题目后
		$oGame = new Game();

		$aStatistic = array(
				'type' => 'match',
				'subject' => $aEsInfo['subject_id'],
				'add_type' => 1
			);
		if($isPass){
			if(!$oGame->afertRightEs($this->_userId, $aEsInfo, $aMatchAnswer['get_time'], Cookie::get('meut'), 2, $aMyMatch['correct_es_count'],  1)){
				return array('msg' => '出错了', 'status' => 0, 'data' => '');
			}
		}else{
			$aStatistic['add_type'] = 2;
			if(!$oGame->afertWrongEs($this->_userId, $aEsInfo, $aMatchAnswer['user_answer']['answer'], 0, $aMatchAnswer['get_time'], Cookie::get('meut'))){
				return array('msg' => '出错了', 'status' => 0, 'data' => '');
			}
		}
		//和教育家长端学生数据收集
		Parents::statistics('esMode', $aStatistic);
		//更新我的比赛记录
		$aUpdateMyMatch = array();
		$aUpdateMyMatch['id'] = $aMyMatch['id'];
		if($isPass){
			$aUpdateMyMatch['correct_es_count'] = $aMyMatch['correct_es_count'] + 1;
		}else{
			$aUpdateMyMatch['correct_es_count'] = $aMyMatch['correct_es_count'];
		}
		array_shift($aMyMatch['remainder_es_ids']);
		$aUpdateMyMatch['remainder_es_ids'] = $aMyMatch['remainder_es_ids'];

		$doEsCount = 0;
		foreach($aMatch['es_rule'] as $aMyEs){
			foreach($aMyEs as $key => $es){
				if($key == 'es_count'){
					$doEsCount += $es;
				}
			}
		}

		if(count($aUpdateMyMatch['remainder_es_ids']) == 0){
			$aUpdateMyMatch['end_time'] = $now;

			//时光凝结道具
			$oProp = propPlugin($this->_userId);
			if($oProp->checkSgnj($this->_userId, $aMatch['id'])){
				$aUpdateMyMatch['end_time'] = $aUpdateMyMatch['end_time'] - 30;
				if($aUpdateMyMatch['end_time'] < $aMyMatch['start_time']){
					$aUpdateMyMatch['end_time'] = $aMyMatch['start_time'];
				}
			}

			if($aUpdateMyMatch['correct_es_count']){
				$oNum = new Numerical();
				$oNum->addAccumulatePoints($this->_userId, 23, $aUpdateMyMatch['correct_es_count']);
				$totalTime = $aMatch['duration'] * 60;
				$score = intval(($totalTime - ($aUpdateMyMatch['end_time'] - $aMyMatch['start_time'])) / $totalTime * 2000 + 8000 * $aUpdateMyMatch['correct_es_count'] / $doEsCount);
			}else{
				$score = 0;
			}

			//每日任务 80分+
			if($aMyMatch['best_score'] < 8000 && $score >= 8000){
				Task::refreshTask($this->_userId, 8);
			}

			if($score > $aMyMatch['best_score']){
				$aUpdateMyMatch['best_score'] = $score;
				$aUpdateMyMatch['best_score_time'] = $now;
			}
			if(!$aMyMatch['first_finish_time']){
				$aUpdateMyMatch['first_finish_time'] = $now;
			}

			$i = count($aMyMatch['match_history']) - 1;
			if(isset($aMyMatch['match_history'][$i]) && $aMyMatch['match_history'][$i]['end_time'] == 0){
				$aMyMatch['match_history'][$i]['end_time'] = time();
				$aMyMatch['match_history'][$i]['score'] = $score;
				$aUpdateMyMatch['match_history'] = $aMyMatch['match_history'];
			}

			//团队赛逻辑
			if($aMatch['is_team_match']){
				$oTeam = m('Team');
				$aTeamMatch = $oTeam->getTeamMatchByLitteMatch($aMatch['id']);
				if($aTeamMatch){
					$aJoin = $oTeam->checkCreate($aTeamMatch['id'], $this->_userId);
					if($aJoin){
						if($aTeamMatch['first_match_id'] == $aMatch['id']){
							$sequence = 'first';
						}else{
							$sequence = 'second';
						}
						if($aJoin['member_one'] == $this->_userId){
							$member = 'one';
						}elseif($aJoin['member_two'] == $this->_userId){
							$member = 'two';
						}else{
							$member = 'three';
						}
						$aJoinData = array(
							'id' => $aJoin['id'],
							$sequence.'_'.$member.'_score' => intval($score/100),
						);
						$oTeam->setJoin($aJoinData);
					}
				}
			}
		}

		if(!$oMatch->setMatchUserRelation($aUpdateMyMatch)){
			return array('msg' => '出错了', 'status' => 0, 'data' => '');
		}

		//返回下一题或结束
		if(count($aUpdateMyMatch['remainder_es_ids']) == 0){
			$aResult['result']['score'] = $score / 100;
			$aResult['result']['rank'] = $oMatch->getMatchRanking($aMyMatch['match_id'], $score);
			$aResult['result']['correct_rate'] = intval($aUpdateMyMatch['correct_es_count'] / $doEsCount * 100);
			$aResult['result']['use_time'] = $aUpdateMyMatch['end_time'] - $aMyMatch['start_time'];
			$aResult['result']['correct_es_count'] = $aUpdateMyMatch['correct_es_count'];
			$aResult['result']['points'] = $GLOBALS['POINT']['es'] * $aUpdateMyMatch['correct_es_count'];

			//首次完成比赛事件
//			if(!$aMyMatch['first_finish_time']){
//				$aMatchEvent = array();
//				$aMatchEvent['user_id'] = $this->_userId;
//				$aMatchEvent['type'] = 11;
//				$aMatchEvent['data_id'] = $aMyMatch['id'];
//				$oSns = m('SnsEvent');
//				if(!$oSns->addEvent($aMatchEvent)){
//					return array('msg' => '出错了', 'status' => 0, 'data' => '');
//				}
//			}

			//每次都写动态
			$aEventData = array(
				'user_id'	=>	$this->_userId,
				'type'		=> 24,
				'data_id'	=>	$aMyMatch['id'],
				'data'		=>	array(
					'match_id' => $aMyMatch['match_id'],
					'score' => $score,
					'create_time' => time(),
				)
			);
			$oSnsEvent = m('SnsEvent');
			if(!$oSnsEvent->addEvent($aEventData)){
				return array('msg' => '出错了', 'status' => 0, 'data' => '');
			}

			//myLog(json_encode(array($doEsCount,$aUpdateMyMatch['correct_es_count'],$aResult['result']['correct_es_count'],$doEsCount - $aUpdateMyMatch['correct_es_count'])));
			return array('msg' => '恭喜你顺利过关！^-^ 真厉害', 'status' => 200, 'data' => $aResult);
		}else{
			$aResult['next_es'] = $this->_nextEs($aMyMatch['remainder_es_ids']);
			$curEsIndex = $doEsCount - count($aMyMatch['remainder_es_ids']);
			$correctRate = intval($aUpdateMyMatch['correct_es_count'] / $curEsIndex * 100);
			if(intval($doEsCount * 2 / 3) == $curEsIndex || intval($doEsCount * 1 / 3) == $curEsIndex){
				if($correctRate >= 90){
					$status = 300;
				}elseif($correctRate >= 60 && $correctRate < 90){
					$status = 400;
				}else{
					$status = 500;
				}

				return array('msg' => '下一题哈哈哈', 'status' => $status, 'data' => $aResult);
			}
			return array('msg' => '下一题哈哈哈', 'status' => 1, 'data' => $aResult);
		}

	}

	/*
	 *时间到了自动完成比赛
	 */
	public function autoFinishMatch($id){
		$oMatch = m('Match');
		$aMyMatch = $oMatch->getMatchUserRelationInfoById($id);
		if(!$aMyMatch){
			return array('msg' => '你没有参加该比赛', 'status' => 0, 'data' => '');
		}

		if($aMyMatch['user_id'] != $this->_userId){
			return array('msg' => '你没有参加该比赛', 'status' => 0, 'data' => '');
		}

		$aMatch = $oMatch->getMatchInfoById($aMyMatch['match_id']);
		if(!$aMatch){
			return array('msg' => '赛事不存在', 'status' => 0, 'data' => '');
		}
		$now = time();

		if(!$aMyMatch['start_time']){
			return array('msg' => '您还没开始比赛', 'status' => 0, 'data' => '');
		}
		if($now < ($aMyMatch['start_time'] + $aMatch['duration'] * 60)){
			return array('msg' => '该次比赛还没结束喔', 'status' => 0, 'data' => '');
		}
		if($now > $aMatch['match_end_time']){
			return array('msg' => '比赛时间已经结束', 'status' => 0, 'data' => '');
		}

		//更新我的比赛记录
		$aUpdateMyMatch = array();
		$aUpdateMyMatch['id'] = $aMyMatch['id'];
		if($isPass){
			$aUpdateMyMatch['correct_es_count'] = $aMyMatch['correct_es_count'] + 1;
		}else{
			$aUpdateMyMatch['correct_es_count'] = $aMyMatch['correct_es_count'];
		}

		$aUpdateMyMatch['remainder_es_ids'] = array();
		$aUpdateMyMatch['end_time'] = $now;

		$doEsCount = 0;
		foreach($aMatch['es_rule'] as $aMyEs){
			foreach($aMyEs as $key => $es){
				if($key == 'es_count'){
					$doEsCount += $es;
				}
			}
		}

		if($aUpdateMyMatch['correct_es_count']){
			$totalTime = $aMatch['duration'] * 60;
			$score = intval(($totalTime - ($aUpdateMyMatch['end_time'] - $aMyMatch['start_time'])) / $totalTime * 2000 + 8000 * $aUpdateMyMatch['correct_es_count'] / $doEsCount);
		}else{
			$score = 0;
		}
		if($score > $aMyMatch['best_score']){
			$aUpdateMyMatch['best_score'] = $score;
			$aUpdateMyMatch['best_score_time'] = $now;
		}
		if(!$aMyMatch['first_finish_time']){
			$aUpdateMyMatch['first_finish_time'] = $now;
		}

		if(!$oMatch->setMatchUserRelation($aUpdateMyMatch)){
			return array('msg' => '系统错误', 'status' => 0, 'data' => '');
		}

		//首次完成比赛事件
//		if(!$aMyMatch['first_finish_time']){
//			$aMatchEvent = array();
//			$aMatchEvent['user_id'] = $this->_userId;
//			$aMatchEvent['type'] = 11;
//			$aMatchEvent['data_id'] = $aMyMatch['id'];
//			$oSns = m('Sns');
//			if(!$oSns->addEvent($aMatchEvent)){
//				return array('msg' => '系统错误', 'status' => 0, 'data' => '');
//			}
//		}

		//每次都写动态
		$aEventData = array(
			'user_id'	=>	$this->_userId,
			'type'		=> 24,
			'data_id'	=>	$aMyMatch['id'],
			'data'		=>	array(
				'match_id' => $aMyMatch['match_id'],
				'score' => $score,
				'create_time' => time(),
			)
		);
		$oSnsEvent = m('SnsEvent');
		if(!$oSnsEvent->addEvent($aEventData)){
			return array('msg' => '出错了', 'status' => 0, 'data' => '');
		}

		$aResult = array();
		$aResult['result']['score'] = $score / 100;
		$aResult['result']['rank'] = $oMatch->getMatchRanking($aMyMatch['match_id'], $score);

		$aResult['result']['correct_rate'] = intval($aUpdateMyMatch['correct_es_count'] / $doEsCount * 100);
		$aResult['result']['use_time'] = $aUpdateMyMatch['end_time'] - $aMyMatch['start_time'];
		return array('msg' => '恭喜你顺利过关！^-^ 真厉害', 'status' => 1, 'data' => $aResult);
	}

	/*
	 *领奖
	 */
	public function acceptPrize($matchId = 0){
		$oMatch = m('Match');
		$aMatch = $oMatch->getMatchInfoById($matchId);
		if(!$aMatch){
			return array('msg' => '赛事不存在!',  'status' => -1, 'data' => '');
		}
		$now = time();
		if($now < $aMatch['match_end_time']){
			return array('msg' => '比赛还没结束呢，急什么嘛!', 'status' => -1, 'data' => '');
		}
		if(!$aMatch['winners']){
			return array('msg' => '等待发奖中!',  'status' => -1, 'data' => '');
		}
		$prizeResult = $oMatch->receivePrize($this->_userId, $matchId);
		if($prizeResult){
			$aUserPrize = array();
			foreach($aMatch['winners'] as $type => $aPrizeType){
				if(is_array($aPrizeType) && $aPrizeType){
					foreach($aPrizeType as $order => $aUser){
						if($aUser['user_id'] == $this->_userId && $aUser['receive_time'] == 0){
							$aUserPrize['type'] = $type;
							$aUserPrize['order'] = $order;
							break;
						}
					}
				}
			}
			if($aUserPrize){
				//经验
				$aRewardInfo = array();
				$aRewardInfo['total_join'] = $oMatch->getRegistrationCountByMatchId($matchId);
				if($aUserPrize['type'] == 'top'){
					$aPrize = $aMatch['awards'][$aUserPrize['type']][$aUserPrize['order']];
					$aRewardInfo['ranking'] = $aUserPrize['order'];
				}else{
					$aPrize = $aMatch['awards'][$aUserPrize['type']];
					$aRewardInfo['ranking'] = 'lucky';
				}

				//金币
				if(isset($aPrize['gold']) && $aPrize['gold']){
					$gold = $aPrize['gold'];
				}else{
					$gold = 0;
				}

				$oGame = new Game();
				if(!$oGame->getMatchReward($this->_userId, $aRewardInfo, $gold)){
					return array('msg' => '领奖失败!', 'status' => 0, 'data' => '');
				}
				$aMyRelationInfo = $oMatch->getMatchUserRelationInfo($this->_userId, $matchId);
				if($aMyRelationInfo === false){
					return array('msg' => '系统错误!', 'status' => 0, 'data' => '');
				}
				$aThisResult = array();
				$aThisResult['show_type'] = 'ACCEPTMATCHPRIZE';
				$aThisResult['custom_data']['match_name'] = $aMatch['name'];
				$aThisResult['custom_data']['best_score'] = $aMyRelationInfo['best_score'] / 100;
				$aThisResult['custom_data']['ranking'] = $aMyRelationInfo['ranking'];
				$aThisResult['custom_data']['best_score_time'] = $aMyRelationInfo['best_score_time'];
				$oGame->setResult($aThisResult);
			}else{
				return array('msg' => '您没有得到奖励喔!', 'status' => 0, 'data' => '');
			}
		}else{
			return array('msg' => '领奖失败!', 'status' => 0, 'data' => '');
		}
		return array('msg' => '恭喜您!!!你领取了一份大奖励', 'status' => 1, 'data' => '');
	}


	//科目
	private function _getSubjectList(){
		$subjectArray = array();
		foreach($GLOBALS['SUBJECT'] as $key=> $subject){
			$subjectArray[$key] = $subject;
		}
		$subjectArray[99] = '综合';
		return $subjectArray;
	}

	//年级列表
	private $_gradeArray = array(
		/*
		1	=>	'一年级',
		2	=>	'二年级',
		3	=>	'三年级',
		4	=>	'四年级',
		 */
		5	=>	'五年级',
		6	=>	'六年级',
		7	=>	'初一',
		8	=>	'初二',
		9	=>	'初三',
		10	=>	'小升初',
		11	=>	'中考'
	);

	//返回倒计时的yy-mm-dd
	private function _getTimeGo($seconds){
		$aBeginTime = array(
			'day'	=> '00',
			'hour'	=> '00',
			'minute'=> '00',
			'second'=> '00'
		);

		$daySecond = 86400;
		$hourSecond = 3600;
		$minuteSecond = 60;

		if($seconds / $daySecond > 1){
			$aBeginTime['day'] = floor($seconds / $daySecond);
			if($aBeginTime['day'] < 10){
				$aBeginTime['day'] = '0' . $aBeginTime['day'];
			}
			$seconds = $seconds - ($aBeginTime['day'] * $daySecond);
		}

		if($seconds > $hourSecond){
			$aBeginTime['hour'] = floor($seconds / $hourSecond);
			if($aBeginTime['hour'] < 10){
				$aBeginTime['hour'] = '0' . $aBeginTime['hour'];
			}
			$seconds = $seconds - ($aBeginTime['hour'] * $hourSecond);
		}
		if($seconds > $minuteSecond){
			$aBeginTime['minute'] = floor($seconds / $minuteSecond);
			if($aBeginTime['minute'] < 10){
				$aBeginTime['minute'] = '0' . $aBeginTime['minute'];
			}
			$seconds = $seconds - ($aBeginTime['minute'] * $minuteSecond);
		}
		$aBeginTime['second'] = $seconds;
		if($aBeginTime['second'] < 10){
			$aBeginTime['second'] =  '0' . $aBeginTime['second'];
		}
		return $aBeginTime;
	}

	/**
	 *检查作答格式
	 */
	private function _checkMatch($aMatchAnswer){
		if(!isset($aMatchAnswer['match_id']) || !isset($aMatchAnswer['user_answer']) || !isset($aMatchAnswer['get_time'])){
			return false;
		}
		if(!is_numeric($aMatchAnswer['match_id']) || !is_array($aMatchAnswer['user_answer'])){
			return false;
		}
		if(!isset($aMatchAnswer['user_answer']['id']) || !isset($aMatchAnswer['user_answer']['answer'])){
			return false;
		}
		return true;
	}

	/**
	 *下一条题目
	 */
	private function _nextEs($aEsId){
		if(!is_array($aEsId)){
			return array('msg' => '网络可能有点慢!', 'status' => 0, 'data' => '');
		}
		if(!$aEsId){
			return array('msg' => '哎唷没有下一题了啦!', 'status' => 0, 'data' => '');
		}

		$oEs = m('Es');
		$nextEsId = current($aEsId);
		$aNextEs = $oEs->getOfficialEsInfoById($nextEsId);
		if(!$aNextEs){
			return array('msg' => '获取ID为 <b>' . $nextEsId . '</b> 的下一题时出错啦啦啦', 'status' => 0, 'data' => '');
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aNextEs['type_id']]);
		$aNextEs['es_content'] = $oEsPlugin->resolve($aNextEs['content_json']);
		$aNextEs['es_content'] = $oEsPlugin->removeAnswer($aNextEs['es_content']);
		$aNextEs['id'] = Xxtea::encrypt($aNextEs['id']);
		$now = time();
		$aNextEs['get_time'] = Xxtea::encrypt($now);
		Cookie::set('meut', md5($now));
		return $aNextEs;
	}

	public function getMatchStatus($aMatch){
		$matchStatus = 0;
		$nowTime = time();
		$aMyMatch = $aMatch['match_user_relation'];
		if($aMatch['registration_start_time'] > $nowTime){
			//未开始报名（马上报名按钮不可用）
			$matchStatus = 1;
		}elseif($aMatch['registration_end_time'] > $nowTime){
			//正在报名
			if($aMyMatch){
				if($aMatch['match_start_time'] > $nowTime){
					//用户已报名（准备参赛）
					$matchStatus = 3;
				}else{
					if(!$aMyMatch['start_time']){
						//开赛时间与报名时间重叠
						$matchStatus = 10;
						if(intval($aMyMatch['start_time']) + intval($aMatch['duration']) * 60 > $nowTime && $aMyMatch['remainder_es_ids']){
							$matchStatus = 6;
						}
					}else{
						//已经进入过比赛（再次参赛）
						//$matchStatus = 7;
						if($aMyMatch['start_time'] && intval($aMyMatch['start_time']) + intval($aMatch['duration']) * 60 > $nowTime && $aMyMatch['remainder_es_ids']){
							//还在比赛中（继续未完赛事）
							$matchStatus = 6;
						}else{
							//比赛超时，本次比赛结束（再次参赛）
							$matchStatus = 7;
						}
					}
				}
			}else{
				//用户未报名（马上报名）
				$matchStatus = 2;
			}
		}elseif($aMatch['match_start_time'] > $nowTime){
			//未开赛
			$matchStatus = 4;
			if(!$aMyMatch){
				$matchStatus = 12;
			}
		}elseif($aMatch['match_end_time'] > $nowTime){
			//比赛进行中
			if($aMyMatch){
				//用户已报名
				if($aMyMatch['start_time'] == 0){
					//用户可以进入赛事，但还没进入赛事（立即参赛）
					$matchStatus = 5;
				}else{
					//用户已经进入过赛事了
					if($aMyMatch['start_time'] && intval($aMyMatch['start_time']) + intval($aMatch['duration']) * 60 > $nowTime && $aMyMatch['remainder_es_ids']){
						//还在比赛中（继续未完赛事）
						$matchStatus = 6;
					}else{
						//比赛超时，本次比赛结束（再次参赛）
						$matchStatus = 7;
					}
				}
			}else{
				//用户未报名
				if($aMatch['registration_end_time'] && $aMatch['registration_end_time'] < $nowTime){
					$matchStatus = 8;
				}else{
					$matchStatus = 2;
				}
			}
		}else{
			//比赛结束
			$matchStatus = 9;
			//查询是否得奖
		}
		return $matchStatus;
	}
}