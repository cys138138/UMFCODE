<?php
/**
 * 题目业务对象
 * @author Administrator
 */
class Es{
	const lIMIT_ANSWERCOUNT = 5;
	const EASY_LEVEL = 1;
	const NORMAL_LEVEL = 2;
	const HARD_LEVEL = 3;
	public static function buildCategoryTreeListCacheBySubjectId($subjectId){
		$aCategoryTreeList = m('Es')->getCategoryListBySubjectId($subjectId);
		return file_put_contents(APP_CACHE_PATH . 'es_' . $subjectId .  '_category_tree_list.cache.php', '<?php return ' . var_export($aCategoryTreeList, 1) . ';');
	}

	public static function getCategoryTreeListBySubjectId($subjectId){
		$cacheFile = APP_CACHE_PATH . 'es_' . $subjectId .  '_category_tree_list.cache.php';
		if(file_exists($cacheFile)){
			return include($cacheFile);
		}else{
			self::buildCategoryTreeListCacheBySubjectId($subjectId);
			return self::getCategoryTreeListBySubjectId($subjectId);
		}
	}

	public static function getEsLevel($aEs){
		if($aEs['answer_counts'] < self::lIMIT_ANSWERCOUNT){
			return self::EASY_LEVEL;
		}
		$oEs = m('es');
		$positionPercent = $oEs->getEsCorrectPercentRanking($aEs['category_id'], $aEs['correct_percent']);
		if($positionPercent === false){
			return false;
		}
		if($positionPercent <= 30){
			return self::EASY_LEVEL;
		}elseif($positionPercent > 30 && $positionPercent <= 70){
			return self::NORMAL_LEVEL;
		}else{
			return self::HARD_LEVEL;
		}
	}
}
