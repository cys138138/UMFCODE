<?php

class Mission{

	/**
	 * 根据科目id获取关卡列表
	 * 表单参数: subjectId, page, from_mission_list
	 */
	public static function getUserMissionList($myUserId, $pageSize = 14){
		$subjectId = intval(post('subjectId', 0));
		$page = intval(post('page', 1));
		$fromMissionList = intval(post('from_mission_list'));

		if(!isset($GLOBALS['SUBJECT'][$subjectId])){
			alert('科目错误', 0);
		}
		$aReturnData = array(
			'pageCount'	=> 0,
			'isCurrentMission' => 0,
			'missionList' => array()
		);

		$oMission = m('Mission');
		$missionCount = $oMission->getUserMissionCount($subjectId);
		if($missionCount === false){
			alert('系统错误', 0);
		}
		if($missionCount < 1){
			alert('该科目还没有关卡数据', 0);
		}
		$pageCount = ceil($missionCount / $pageSize);
		if($page < 1 || $page > $pageCount){
			alert('数据错误', 0);
		}
		$aMissionList = $oMission->getUserMissionList($myUserId, $subjectId, $page, $pageSize);
		if($aMissionList === false){
			alert('系统错误', 0);
		}

		if($aMissionList){
			//当前关卡
			$aCurrentMissionInfo = $oMission->getCurrentMission($myUserId);
			if($aCurrentMissionInfo === false){
				alert('系统错误', 0);
			}
			if(isset($aCurrentMissionInfo[$subjectId])){
				$aReturnData['isCurrentMission'] = 1;
			}
			foreach($aMissionList as $key => $aMissionInfo){
				if(isset($aMissionInfo['is_pass']) && $aMissionInfo['is_pass'] == 1 ){
					$aMissionList[$key]['start_num'] = self::_getStarByPoint($aMissionInfo['score']);
				}
			}

			if($fromMissionList == 1){
				$cookieSubjectId = Cookie::get('mission_list_subject_id');
				if($cookieSubjectId != $subjectId){
					Cookie::set('mission_list_subject_id', $subjectId);
				}
				if(!$aCurrentMissionInfo){
					alert('去设置关卡welcome页面', 2, url('m=Mission&a=showSelectStartMissionWelcome'));
				}elseif(!isset($aCurrentMissionInfo[$subjectId])){
					alert('去设置关卡init页面', 2, url('m=Mission&a=initMission&subject_id=' . $subjectId));
				}
			}
		}

		$aReturnData['pageCount'] = $pageCount;
		$aReturnData['missionList'] = $aMissionList;
		alert('关卡列表', 1, $aReturnData);
	}

	/**
	 * 根据获取某关卡详细信息
	 * 表单参数: subjectId, mission_id
	 */
	public static function getUserMissionDetail($myUserId){
		$missionId = intval(post('mission_id'));
		$subjectId = intval(post('subject_id'));

		$oMission = m('Mission');
		$aMissoinInfo = $oMission->getUserMissionDetailInfo($missionId, $myUserId);
		if($aMissoinInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		if($aMissoinInfo){
			if(isset($aMissoinInfo['user_mission_info']['task_finish_time']) && $aMissoinInfo['user_mission_info']['task_finish_time']){
				$aMissoinInfo['user_mission_info']['task_finish_time'] = date('Y-m-d H:i:s', $aMissoinInfo['user_mission_info']['task_finish_time']);
			}else{
				$aMissoinInfo['user_mission_info']['task_finish_time'] = 0;
			}
			if(isset($aMissoinInfo['user_mission_info']['pass_time']) && $aMissoinInfo['user_mission_info']['pass_time']){
				$aMissoinInfo['user_mission_info']['pass_time'] = date('Y-m-d H:i:s', $aMissoinInfo['user_mission_info']['pass_time']);
			}else{
				$aMissoinInfo['user_mission_info']['pass_time'] = 0;
			}

			$aMissoinInfo['mission_success_rate'] = $aMissoinInfo['challenge_count'] != 0 ? intval(($aMissoinInfo['challenge_success_count'] / $aMissoinInfo['challenge_count']) * 10000) / 100 : 0;
			if(!isset($aMissoinInfo['user_mission_info']['es_count'])){
				$aMissoinInfo['user_mission_info']['es_count'] = 0;
			}
			if(!isset($aMissoinInfo['user_mission_info']['es_correct_count'])){
				$aMissoinInfo['user_mission_info']['es_correct_count'] = 0;
			}
			if(!isset($aMissoinInfo['user_mission_info']['score'])){
				$aMissoinInfo['user_mission_info']['score'] = 0;
			}else{
				$aMissoinInfo['user_mission_info']['score'] = $aMissoinInfo['user_mission_info']['score'] / 100;
			}
			$aMissoinInfo['user_mission_info']['mission_es_correct_rate'] = $aMissoinInfo['user_mission_info']['es_count'] != 0 ? intval(($aMissoinInfo['user_mission_info']['es_correct_count'] / $aMissoinInfo['user_mission_info']['es_count']) * 10000) / 100 : 0;

			$oEs = m('Es');
			$userFavouriteEsCount = $oEs->getUserFavouriteEsCount($myUserId, $subjectId, $missionId);
			if($userFavouriteEsCount === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aMissoinInfo['user_mission_info']['favourite'] = $userFavouriteEsCount;

			$userWrongEsCount = $oEs->getUserWrongEsCount($myUserId, $subjectId, 0, 0, $missionId);
			if($userWrongEsCount === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aMissoinInfo['user_mission_info']['wrong'] = $userWrongEsCount;
		}
		alert('关卡信息', 1, $aMissoinInfo);
	}

	/**
	 * 获取系统关卡统计信息
	 */
	public static function getMissionStatistics($myUserId){
		$oMission = m('Mission');
		$aCurrentMissionInfo = $oMission->getCurrentMission($myUserId);
		if($aCurrentMissionInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		//获取关卡个数和题目个数
		$missionTotalCount = $oMission->getUserMissionCount();
		$oEs = m('Es');
		$esTotalCount = $oEs->getOfficialEsCount();
		$aSubject = $GLOBALS['SUBJECT'];
		$aMissionList = array();
		foreach($aSubject as $key=>$value){
			$aSubjectMissionList = $oMission->getOriginalMissionList($key, null, null);
			//分年级，以关卡名字第一位数字区分；比如：关卡‘52044 3.1长方体和正方体的认识’为5年级
			$aMissionList[$key][5] = array();
			$aMissionList[$key][6] = array();
			$aMissionList[$key][7] = array();
			$aMissionList[$key][8] = array();
			$aMissionList[$key][9] = array();
			foreach($aSubjectMissionList as $k => $aSubjectMission){
				$missionName = trim($aSubjectMission['name']);
				$grade = substr($missionName, 0, 1);
				if($grade == 5){
					array_push($aMissionList[$key][5], $aSubjectMission);
				}elseif($grade == 6){
					array_push($aMissionList[$key][6], $aSubjectMission);
				}elseif($grade == 7){
					array_push($aMissionList[$key][7], $aSubjectMission);
				}elseif($grade == 8){
					array_push($aMissionList[$key][8], $aSubjectMission);
				}elseif($grade == 9){
					array_push($aMissionList[$key][9], $aSubjectMission);
				}else{
					array_push($aMissionList[$key][9], $aSubjectMission);
				}
			}
		}
		$aData = array(
			'sys_total_mission_count' => $missionTotalCount,
			'sys_total_es_count' => $esTotalCount,
			'current_user_mission_process_info' => $aCurrentMissionInfo,
			'sys_total_mission_list' => $aMissionList
		);
		alert('系统关卡统计信息', 1, $aData);
	}

	/**
	 *	获取下一条题目信息
	 *	表单参数：mission_id, from, do_ids
	 */
	public static function getNextEs($myUserId, $aEsType = array()){
		$missionId = post('mission_id');
		$from = post('from');
		$aDoIds = post('do_ids');

		//验证请求来源
		if(!in_array($from, array('exercise', 'challenge'))){
			alert('非法的来源', 0);
		}
		if(!is_array($aDoIds)){
			alert('参数错误', 0);
		}

		$aShowedEs = array();
		if($aDoIds){
			foreach($aDoIds as $id){
				$aShowedEs[] = Xxtea::decrypt($id);
			}
		}

		$result = self::getNextEsInfo($missionId, $from, $aShowedEs, $myUserId, $aEsType);
		if($result == 1){
			alert('非法的关卡ID', 0);
		}elseif($result == 2){
			alert('关卡不存在', 0);
		}elseif($result == 3 || $result == 4 || $result == 8){
			alert('参数错误', 0);
		}elseif($result == 5){
			alert('找不到练习的题目', 0);
		}elseif($result == 6){
			alert('您必须完成练习任务才可以进入挑战喔', 0);
		}elseif($result == 7){
			alert('该次挑战已经成功过关啦', 0);
		}elseif($result == 8){
			alert('抱歉，抽题出错');
		}
		alert('下一条题目', 1, array('new_es' => $result));
	}

	public static function getNextEsInfo($missionId, $from, $aShowedEs = array(0), $myUserId, $aEsType = array()){

		//读出关卡信息
		$oMission = m('Mission');
		if(!($missionId >= 1)){
			return 1;
		}
		$aMission = $oMission->getMissionInfoById($missionId);
		if(!$aMission){
			return 2;
		}
		$aMyMission = $oMission->getUserMissionInfo($missionId, $myUserId);
		if(!$aMyMission){
			return 2;
		}


		$now = time();
		if($from == 'exercise'){
			if($aShowedEs){
				if(!is_array($aShowedEs)){
					return 3;
				}
				foreach($aShowedEs as $esId){
					if(!is_numeric($esId)){
						return 4;
					}
				}
			}


			$aEs = $oMission->getRandomEsListByMissionExerciseCondition($aMission['category_ids'], 1, $aShowedEs, $aEsType);
			if(!$aEs){
				$aEs = $oMission->getRandomEsListByMissionExerciseCondition($aMission['category_ids'], 1, array(0), $aEsType);
			}
			if(!$aEs){
				return 5;
			}
			while($aEs[0]['id'] == $aMyMission['last_es_id']){
				$aEs = $oMission->getRandomEsListByMissionExerciseCondition($aMission['category_ids'], 1, array(0), $aEsType);
			}
			if(!isset($aEs[0])){
				myLog('读取题目出错,题目数据是:' . var_export($aEs, 1));
			}
			if($aEs[0]['id'] == $aMyMission['last_es_id']){
				return 8;
			}
			$aEs = $aEs[0];
			$aEs['hard_level'] = es::getEsLevel($aEs);
			if(!$aEs['hard_level']){
				return 8;
			}
			$oUser = m('User');
			foreach($aEs['recent_record'] as $key => $aRecord){
				$aUserInfo = $oUser->getPersonalInfoByUserId($aRecord['user_id']);
				if($aUserInfo){
					$aEs['recent_record'][$key]['name'] = $aUserInfo['name'];
					$aEs['recent_record'][$key]['avatar'] = $aUserInfo['profile'];
				}
			}
			$aEs['ts'] = Xxtea::encrypt($now);
			Cookie::set('et', md5($now));
		}elseif($from == 'challenge'){
			if(count($aMyMission['current_challenge_process']['es_list']) == 0){
				return 7;
			}

			$aEs = current($aMyMission['current_challenge_process']['es_list']);
			$aEs['cs'] = Xxtea::encrypt($now);
			Cookie::set('ct', md5($now));
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
		$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
		$aEs['es_content'] = $oEsPlugin->removeAnswer($aEs['es_content']);
		$oWenwen = m('Wenwen');
		$aEs['comment_count'] = $oWenwen->getCommentCount($aEs['id']);
		$aEs['id'] = Xxtea::encrypt($aEs['id']);
		unset($oWenwen);
		unset($aEs['content_json']);
		unset($aEs['content_text']);
		unset($oEsPlugin);
		return $aEs;
	}

	/**
	 * 判断练习作答结果
	 * 表单参数：mission_id, user_answer[id], user_answer[type], user_answer[answer][], ts
	 */
	public static function markingUserExerciseAnswer($myUserId, $taskType){
		$oMission = m('Mission');
		$aChallengeAnswer = $_POST;
		if(!self::_checkChallenge($aChallengeAnswer, true)){
			alert('作答格式有错', 0);
		}

		$aMissoinInfo = $oMission->getMissionInfoById($aChallengeAnswer['mission_id']);
		if(!$aMissoinInfo){
			alert('关卡不存在', 0);
		}

		$aChallengeAnswer['user_answer']['id'] = Xxtea::decrypt($aChallengeAnswer['user_answer']['id']);
		$oEs = m('Es');
		$aEsInfo = $oEs->getOfficialEsInfoById($aChallengeAnswer['user_answer']['id']);
		if(!$aEsInfo){
			alert('ID为 ' . $aChallengeAnswer['answer']['id'] . ' 的题目不存在', 0);
		}

		//更新相关数据
		//$aChallengeAnswer['mission_id'] = 1;
		$aMyMission = $oMission->getUserMissionInfo($aChallengeAnswer['mission_id'], $myUserId);
		if(!$aMyMission){
			alert('您还不能进入该关卡喔', 0);
		}
		if($aChallengeAnswer['user_answer']['id'] == $aMyMission['last_es_id']){
			alert('不能连续做相同的题目', 0);
		}

		//个人任务统计
		$aMissionCount = array();
		$aMissionCount['last_es_id'] = $aChallengeAnswer['user_answer']['id'];
		$aMissionCount['id'] = $aMyMission['id'];
		$aMissionCount['es_count'] = $aMyMission['es_count'] + 1;


		//个人数值统计
		$oUserNumerical = m('UserNumerical');
		$aCurrentNumeric = $oUserNumerical->getUserNumericalInfoById($myUserId);

		//获取正确性
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
		$aResult = $oEsPlugin->getCorrectness($aEsInfo['content_json'], $aChallengeAnswer['user_answer']['answer']);
		$aAnswerIndex = array();
		if(isset($aChallengeAnswer['user_answer']['answer'][0])){
			if(is_array($aChallengeAnswer['user_answer']['answer'][0]) && isset($aChallengeAnswer['user_answer']['answer'][0]['index'])){
				foreach($aChallengeAnswer['user_answer']['answer'] as $key => $aAnswerContent){
					$aAnswerIndex[] = $aAnswerContent['index'];
				}
			}
		}
		$aResult['answer'] = $oEsPlugin->getAnswer($aEsInfo['content_json'], $aAnswerIndex);

		if($oEsPlugin->getError()){
			alert($oEsPlugin->getError(), 0);
		}
		$aResult['id'] = Xxtea::encrypt($aEsInfo['id']);

		$oGame = new Game();
		$aMissionCount['es_correct_count'] = $aMyMission['es_correct_count'];
		if($aResult['pass']){
			$aMissionCount['es_correct_count'] = $aMyMission['es_correct_count'] + 1;
			if(!$aMyMission['is_task_finish']){
				$aMissionCount['task_process'] = $aMyMission['task_process'] + 1;
			}

			if(!$oGame->afertRightEs($myUserId, $aEsInfo, $aChallengeAnswer['ts'], Cookie::get('et'), 1, $aMissionCount['es_correct_count'])){	//普通答对题目
				alert('抱歉，网络可能有点慢', 0);
			}
			if(($aMyMission['task_process'] + 1) >= $aMissoinInfo['task_content']['correct_counts'] && $aMyMission['is_task_finish'] != 1){
				$aTaskEvent = array(
					'user_id' => $myUserId,
					'type' => $taskType,
					'data_id' => $aMyMission['id'],
				);

				$rightRate = $aMissionCount['es_correct_count'] / $aMissionCount['es_count'];
				if(!$oGame->firstFinishPractice($aTaskEvent, $rightRate)){	//首次修炼完成
					alert('抱歉，网络可能有点慢', 0);
				}

				$now = time();
				$aMissionCount['task_finish_time'] = $now;
				$aMissionCount['is_task_finish'] = 1;
				$aMissionCount['lottery_draw_status'] = 1;

				$aThisResult = array();
				$aThisResult['show_type'] = 'TASKCOMPLETE';
				$aThisResult['custom_data']['time'] = $now;
				$aThisResult['custom_data']['correct_rate'] = intval($rightRate  * 100 + 0.5);
				$oGame->setResult($aThisResult);
			}
		}else{
			if(!$oGame->afertWrongEs($myUserId, $aEsInfo, $aChallengeAnswer['user_answer']['answer'], $aChallengeAnswer['mission_id'], $aChallengeAnswer['ts'], Cookie::get('et'))){		//普通答错题目
				alert('抱歉，网络可能有点慢', 0);
			}
		}
		if(!$oMission->setUserMission($aMissionCount)){
			alert('网络可能有点慢', 0);
		}

		//最新正确题目数
		$aResult['right_nums'] = $aMyMission['task_process'] + 1;

		if($aResult['pass']){
			$points = isset($GLOBALS['UPDATE']) ? $GLOBALS['UPDATE']['numerical_data']['accumulate'] : 0;
			if($points){
				$points = intval($points - $aCurrentNumeric['accumulate_points']);
			}
			$aResult['points'] = $points;

			Parents::statistics('esMode', array(
				'type' => 'mission',
				'subject' => $aMissoinInfo['subject_id'],
				'add_type' => 1
			));
			alert('回答正确', 1, $aResult);
		}else{
			Parents::statistics('esMode', array(
				'type' => 'mission',
				'subject' => $aMissoinInfo['subject_id'],
				'add_type' => 2
			));
			alert('回答错误', 1, $aResult);
		}
	}

	/**
	 * 判断挑战作答结果
	 * 表单参数：mission_id, user_answer[id], user_answer[type], user_answer[answer][], cs
	 */
	public static function markingUserChallengeAnswer($myUserId, $challengeType){
		$oMission = m('Mission');
		$aChallengeAnswer = $_POST;
		if(!self::_checkChallenge($aChallengeAnswer, false)){
			alert('作答格式有错', 0);
		}

		$aMissoinInfo = $oMission->getMissionInfoById($aChallengeAnswer['mission_id']);
		if(!$aMissoinInfo){
			alert('关卡不存在', 0);
		}

		$oEs = m('Es');
		$aChallengeAnswer['user_answer']['id'] = Xxtea::decrypt($aChallengeAnswer['user_answer']['id']);
		$aEsInfo = $oEs->getOfficialEsInfoById($aChallengeAnswer['user_answer']['id']);
		if(!$aEsInfo){
			alert('ID为 ' . $aChallengeAnswer['answer']['id'] . ' 的题目不存在', 0);
		}

		//更新相关数据
		$aMyMission = $oMission->getUserMissionInfo($aChallengeAnswer['mission_id'], $myUserId);
		if(!$aMyMission){
			alert('您还不能进入该关卡喔', 0);
		}

		if(!$aMyMission['is_task_finish']){
			alert('您还没有完成本关的基础练习', 0);
		}

		$aMyEsList = $aMyMission['current_challenge_process'];
		if(!array_key_exists($aChallengeAnswer['user_answer']['id'], $aMyEsList['es_list'])){
			alert('ID为 <b>' . $aChallengeAnswer['user_answer']['id'] . '</b> 该题不是本次挑战的题目喔', 0);
		}
		unset($aMyEsList['es_list'][$aChallengeAnswer['user_answer']['id']]);
		$now = time();
		$cs = Xxtea::decrypt($aChallengeAnswer['cs']);
		$useTime = $now - $cs;

		$aMyEsList['time'] = $aMyEsList['time'] + $useTime;

		$oProp = propPlugin($myUserId);
		//时光凝结道具
		if($checkSgnj = $oProp->checkSgnj($myUserId, $aChallengeAnswer['mission_id'])){
			$aMyEsList['time'] = $aMyEsList['time'] - $useTime;
		}


		$oGame = new Game();
		if($aMyEsList['time'] >= ($aMissoinInfo['challenge_limit_duration'] * 60)){
			$aResult['remain_time'] = 0;
			$aResult['wrong_es_count'] = $oEs->getUserWrongEsCount($myUserId, 0, 0, $aMyMission['mission_id']);
			//返回失败结果
			$aThisResult['show_type'] = 'MISSIONFAILD';
			$aThisResult['custom_data']['time'] = $now;
			$aThisResult['custom_data']['best_score'] = $aMyMission['score'];
			$aThisResult['custom_data']['mission_correct_rate'] = intval($aMyMission['es_correct_count'] / $aMyMission['es_count'] * 100);
			$oGame->setResult($aThisResult);
			alert('时间到！你输了哦，刷新重来吧', 400, $aResult);
		}

		//获取正确性
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
		$aResult = $oEsPlugin->getCorrectness($aEsInfo['content_json'], $aChallengeAnswer['user_answer']['answer']);
		$aAnswerIndex = array();
		if(isset($aChallengeAnswer['user_answer']['answer'][0])){
			if(is_array($aChallengeAnswer['user_answer']['answer'][0]) && isset($aChallengeAnswer['user_answer']['answer'][0]['index'])){
				foreach($aChallengeAnswer['user_answer']['answer'] as $key => $aAnswerContent){
					$aAnswerIndex[] = $aAnswerContent['index'];
				}
			}
		}
		$aResult['answer'] = $oEsPlugin->getAnswer($aEsInfo['content_json'], $aAnswerIndex);

		if($oEsPlugin->getError()){
			alert($oEsPlugin->getError(), 0);
		}
		$aResult['id'] = Xxtea::encrypt($aEsInfo['id']);

		//个人任务统计
		$aMissionCount = array(
			'id' => $aMyMission['id'],
			'last_es_id' => $aChallengeAnswer['user_answer']['id'],
			'es_count' => $aMyMission['es_count'] + 1,
		);

		//个人数值统计
		$oUserNumerical = m('UserNumerical');
		$aCurrentNumeric = $oUserNumerical->getUserNumericalInfoById($myUserId);

		if($aResult['pass']){
			$aMyEsList['rightEsCount']++;
			$aMissionCount['es_correct_count'] = $aMyMission['es_correct_count'] + 1;
			if(!$oGame->afertRightEs($myUserId, $aEsInfo, $aChallengeAnswer['cs'], Cookie::get('cs'), 1, $aMissionCount['es_correct_count'])){	//普通答对题目
				alert('抱歉，网络可能有点慢', 0);
			}
		}else{
			if(!$oGame->afertWrongEs($myUserId, $aEsInfo, $aChallengeAnswer['user_answer']['answer'], $aChallengeAnswer['mission_id'], $aChallengeAnswer['cs'], Cookie::get('cs'))){		//普通答错题目
				alert('抱歉，网络可能有点慢', 0);
			}

			$aMyEsList['life'] = $aMyEsList['life'] - 1;
			if($aMyEsList['life'] <= 0){
				$aResult['result']['remain_time'] = $aMissoinInfo['challenge_limit_duration'] * 60 - $aMyEsList['time'];
				$aResult['result']['wrong_es_count'] = $oEs->getUserWrongEsCount($myUserId, 0, 0, $aMyMission['mission_id']);

				//返回失败结果
				$aThisResult = array();
				$aThisResult['show_type'] = 'MISSIONFAILD';
				$aThisResult['custom_data']['time'] = $now;
				$aThisResult['custom_data']['best_score'] = $aMyMission['score'];
				$aThisResult['custom_data']['mission_correct_rate'] = intval($aMyMission['es_correct_count'] / $aMyMission['es_count'] * 100);
				$oGame->setResult($aThisResult);
				$aMissionCount['current_challenge_process'] = $aMyEsList;
				$oMission->setUserMission($aMissionCount);
				alert('噢，你很努力！但是真不幸，还是输了，没事，再接再励吧！', 400, $aResult);
			}
		}

		$aMissionCount['current_challenge_process'] = $aMyEsList;
		if(count($aMyEsList['es_list']) == 0){
			//每日任务  通过新关卡
			if(!$aMyMission['is_pass']){
				if($aMissoinInfo['subject_id'] == 1){
					$taskId = 2;
				}elseif($aMissoinInfo['subject_id'] == 2){
					$taskId = 3;
				}elseif($aMissoinInfo['subject_id'] == 3){
					$taskId = 4;
				}
				Task::refreshTask($myUserId, $taskId);
			}

			$passMissionNum = $oMission->getPassMissionUserCount($aMissoinInfo['id']);
			$topScore = $oMission->getMissionRecordScore($aMissoinInfo['id']);

			$challengeEs = 0;
			foreach($aMissoinInfo['challenge_es_count'] as $aThisEsType){
				$challengeEs = $challengeEs + $aThisEsType['es_count'];
			}
			$thisCorrcetRate = $aMyEsList['rightEsCount'] / $challengeEs;
			$totalTime = $aMissoinInfo['challenge_limit_duration'] * 60;
			$leftTime = $aMissoinInfo['challenge_limit_duration'] * 60 - $aMyEsList['time'];
			$thisScore = intval($leftTime / $totalTime * 2000 + 8000 * $thisCorrcetRate);

			//每日任务 90+分
			if($aMyMission['score'] < 9000 && $thisScore >= 9000){
				Task::refreshTask($myUserId, 1);
			}

			//系统关卡数据
			$aSysMissionCount = array();
			$aSysMissionCount['id'] = $aMissoinInfo['id'];
			$aSysMissionCount['challenge_success_count'] = $aMissoinInfo['challenge_success_count'] + 1;
			$aPassRecored = array(
				'user_id' => $myUserId,
				'pass_time' => $now,
				'score' => $thisScore
			);

			$isExistsMe = false;
			$recordNums = count($aMissoinInfo['recent_record']);
			foreach($aMissoinInfo['recent_record'] as $key => $aRecord){
				if($aRecord['user_id'] == $myUserId){
					$isExistsMe = $key;
					break;
				}
			}
			if($isExistsMe !== false){
				if($thisScore > $aMissoinInfo['recent_record'][$isExistsMe]['score']){
					$aMissoinInfo['recent_record'][$isExistsMe] = $aPassRecored;
				}
			}elseif($recordNums < 10){
				array_unshift($aMissoinInfo['recent_record'], $aPassRecored);
			}elseif($recordNums >= 10){
				$minRecord = 0;
				for($j = 1; $j <= ($recordNums - 1); $j++){
					if($aMissoinInfo['recent_record'][$minRecord]['score'] > $aMissoinInfo['recent_record'][$j]['score']){
						$minRecord = $j;
					}
				}
				if($thisScore > $aMissoinInfo['recent_record'][$minRecord]['score']){
					unset($aMissoinInfo['recent_record'][$minRecord]);
					array_unshift($aMissoinInfo['recent_record'], $aPassRecored);
				}
			}

			$aSysMissionCount['recent_record'] = $aMissoinInfo['recent_record'];
			if(!$oMission->setMission($aSysMissionCount)){
				alert('抱歉，网络可能有点慢', 0);
			}

			//个人关卡
			$aMissionCount['is_pass'] = 1;
			if(!$aMyMission['pass_time']){
				$aMissionCount['pass_time'] = $now;
			}
			if($thisScore > $aMyMission['score']){
				$aMissionCount['best_score_time'] = $now;
				$aMissionCount['score'] = $thisScore;
				//校讯通家长端学生数据收集
				Parents::statistics('mission', array(
					'mission_id' => $aMyMission['mission_id'],
					'subject_id' => $aMissoinInfo['subject_id'],
					'score' => $thisScore,
					'create_time' => time()
				));
			}
			$aMissionCount['lottery_draw_status'] = 1;

			$aChistory = array();
			$aChistory['pass_time'] = $now;
			$aChistory['duration'] = $aMyEsList['time'];
			$aChistory['use_blood'] = $aMissoinInfo['challenge_limit_blood'] - $aMyEsList['life'];
			$aChistory['score'] = $thisScore;
			array_unshift($aMyMission['challenge_history'], $aChistory);
			$aMissionCount['challenge_history'] = $aMyMission['challenge_history'];

			//破纪录
			$aMissionCount['break_record'] = array();
			if($thisScore > $aMyMission['score'] && $aMyMission['is_pass']){
				$aMissionCount['break_record']['my_record'] = $thisScore - $aMyMission['score'];
			}
			if($thisScore > $topScore){
				$aMissionCount['break_record']['world_record'] = array(
					'my_score' => $thisScore,
					'world_score' => $topScore,
					'create_time' => $now,
				);
			}
			if(!$aMissionCount['break_record']){
				unset($aMissionCount['break_record']);
			}
		}
		if(!$oMission->setUserMission($aMissionCount)){
			alert('抱歉，网络可能有点慢', 0);
		}

		if(count($aMyEsList['es_list']) == 0){
			//成功挑战之后
			if(!$oGame->successChallenge($aMyMission, $aMissoinInfo, $challengeType, $aMyEsList['time'], $aMyEsList['rightEsCount'], $thisScore, $topScore, $passMissionNum)){
				alert('抱歉，网络可能有点慢', 0);
			}

			//自动开启下一关
			$aNextMission = $oMission->getNextMissionInfo($aMissoinInfo['subject_id'], $aMissoinInfo['orders']);
			if($aNextMission){
				if(!$oMission->getUserMissionInfo($aNextMission['id'], $myUserId)){
					$aNewMission = array();
					$aNewMission['user_id'] = $myUserId;
					$aNewMission['mission_id'] = $aNextMission['id'];
					$aNewMission['is_task_finish'] = 0;
					$aNewMission['is_pass'] = 0;
					$aNewMission['es_count'] = 0;
					$aNewMission['es_correct_count'] = 0;
					$aNewMission['score'] = 0;
					$aNewMission['create_time'] = $now;
					$aNewMission['pass_time'] = 0;
					$aNewMission['best_score_time'] = 0;
					$aNewMission['last_es_id'] = 0;
					$aNewMission['task_process'] = 0;
					$aNewMission['current_challenge_process'] = array();
					$aNewMission['challenge_history'] = array();
					if(!$oMission->addUserMission($aNewMission)){
						alert('抱歉，网络可能有点慢', 0);
					}
				}
			}

			$aResult['result']['score'] = $thisScore / 100;
			$aResult['result']['rank'] = $oMission->getMissionScoreRanking($aMyMission['mission_id'], $thisScore);
			$aResult['result']['remain_time'] = $aMissoinInfo['challenge_limit_duration'] * 60 - $aMyEsList['time'];
			$aResult['result']['wrong_es_count'] = $oEs->getUserWrongEsCount($myUserId, 0, 0, $aMyMission['mission_id']);
			if(!isset($aNextMission['id'])){
				$aNextMission['id'] = 0;
			}
			$aResult['result']['next_mission_id'] = $aNextMission['id'];

			//返回结果
			$challengeEs = 0;
			foreach($aMissoinInfo['challenge_es_count'] as $aThisEsType){
				$challengeEs = $challengeEs + $aThisEsType['es_count'];
			}
			$corrcetRate = intval($aMyEsList['rightEsCount'] / $challengeEs * 100);

			$aThisResult = array();
			$aThisResult['show_type'] = 'MISSIONSUCCESS';
			$aThisResult['custom_data']['time'] = $now;
			$aThisResult['custom_data']['correct_rate'] = $corrcetRate;
			$aThisResult['custom_data']['score'] = $thisScore / 100;
			$aThisResult['custom_data']['wrong_es_count'] = $aMissoinInfo['challenge_limit_blood'] - $aMyEsList['life'];
			$aThisResult['custom_data']['spand_time'] = $aMyEsList['time'];
			$aThisResult['custom_data']['best_score'] = $thisScore > $aMyMission['score'] ? $thisScore / 100 : $aMyMission['score'] / 100;
			if($aResult['pass']){
				$missionRightCount = $aMyMission['es_correct_count'] + 1;
			}else{
				$missionRightCount = $aMyMission['es_correct_count'];
			}
			$aThisResult['custom_data']['mission_correct_rate'] = intval($missionRightCount / $aMissionCount['es_count'] * 100);
			if(count($aMyMission['challenge_history']) == 1){
				$aThisResult['custom_data']['lottery_draw'] = 1;
			}


			//我在好友中的排名
			$oSns = m('Sns');
			$userIds = $oSns->getUserFriendIds($myUserId);
			if($userIds){
				$userIds .= ',' . $myUserId;
			}else{
				$userIds = $myUserId;
			}
			$aFriendRanking = $oMission->getTopScoreUserListByMissionIdAndUserIds($aMyMission['mission_id'], explode(',', $userIds));
			foreach($aFriendRanking as $key => $aFriend){
				if($myUserId == $aFriend['user_id']){
					$friendRanking = $key + 1;
					break;
				}
			}
			$aThisResult['custom_data']['in_friend_ranking'] = $friendRanking;
			$oGame->setResult($aThisResult);
			alert('恭喜你顺利过关！^-^ 真厉害', 200, $aResult);
		}

		$aResult['rightEsCount'] = $aMyMission['es_correct_count'];

		if($aResult['pass']){
			$points = isset($GLOBALS['UPDATE']) ? $GLOBALS['UPDATE']['numerical_data']['accumulate'] : 0;
			if($points){
				$points = intval($points - $aCurrentNumeric['accumulate_points']);
			}
			$aResult['points'] = $points;

			//校讯通家长端学生数据收集
			Parents::statistics('esMode', array(
				'type' => 'mission',
				'subject' => $aMissoinInfo['subject_id'],
				'add_type' => 1
			));

			alert('恭喜你答对了！', 1, $aResult);
		}else{
			//校讯通家长端学生数据收集
			Parents::statistics('esMode', array(
				'type' => 'mission',
				'subject' => $aMissoinInfo['subject_id'],
				'add_type' => 2
			));

			alert('答错了，加油哦！', 1, $aResult);
		}
	}

	/**
	 * 获取某一关卡的排行榜信息
	 * 表单参数：missionId
	 */
	public static function getWorldRankListByMissionId($myUserId){
		$missionId = intval(post('missionId'));
		if(!$missionId){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $myUserId);
		if($aMyMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMyMission['score'] = $aMyMission['score'] / 100;
		foreach($aMyMission['challenge_history'] as $key => $aHistory){
			$aMyMission['challenge_history'][$key]['score'] = $aMyMission['challenge_history'][$key]['score'] / 100;
		}
		$aWorldRanking = $oMission->getTopScoreUserListByMissionId($missionId, 1, 10);
		if($aWorldRanking === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$defeatPercent = $oMission->getDefeatedPercent($aMyMission['mission_id'], $aMyMission['score'] * 100);
		if($defeatPercent === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aData = array(
			'mission_info' => $aMyMission,
			'defeat_percent' => $defeatPercent,
			'world_rank_list' => $aWorldRanking
		);
		alert('关卡的排行榜信息', 1, $aData);
	}

	/**
	 * 用户初始化关卡
	 */
	public static function setSelectStartMission($myUserId){
		$englishInitMissionId = post('englishInitMissionId');
		$mathInitMissionId = post('mathInitMissionId');
		$chineseInitMissionId = post('chineseInitMissionId');

		if(!$chineseInitMissionId && !$mathInitMissionId && !$englishInitMissionId){
			alert('系统出错，请稍后再试', 0);
		}

		$oMission = m('Mission');
		$aMissionIds = array();
		if($chineseInitMissionId){
			$aChineseMissionInfo = $oMission->getMissionInfoById($chineseInitMissionId);
			if($aChineseMissionInfo === false){
				alert('系统出错，请稍后再试', 0);
			}
			if(!$aChineseMissionInfo){
				alert('设置的语文关卡不存在', 0);
			}
			$aMissionIds['chinese'] = $chineseInitMissionId;
		}
		if($englishInitMissionId){
			$aEnglishMissionInfo = $oMission->getMissionInfoById($englishInitMissionId);
			if($aEnglishMissionInfo === false){
				alert('系统出错，请稍后再试', 0);
			}
			if(!$aEnglishMissionInfo){
				alert('设置的英语关卡不存在', 0);
			}
			$aMissionIds['english'] = $englishInitMissionId;
		}
		if($mathInitMissionId){
			$aMathMissionInfo = $oMission->getMissionInfoById($mathInitMissionId);
			if($aMathMissionInfo === false){
				alert('系统出错，请稍后再试', 0);
			}
			if(!$aMathMissionInfo){
				alert('设置的数学关卡不存在', 0);
			}
			$aMissionIds['math'] = $mathInitMissionId;
		}

		$missionUserId = $oMission->initUserMission($aMissionIds, $myUserId);
		if($missionUserId === false){
			alert('系统出错,请稍后再试', 0);
		}elseif(!$missionUserId){
			alert('设置起始关卡失败', 0);
		}

		$url = url('m=Mission&a=showMissionList');
		if($englishInitMissionId){
			$url = url('m=Mission&a=showMissionList&subject_id=3');
		}
		if($mathInitMissionId){
			$url = url('m=Mission&a=showMissionList&subject_id=2');
		}
		if($chineseInitMissionId){
			$url = url('m=Mission&a=showMissionList&subject_id=1');
		}

		alert('关卡初始化成功!', 2, $url);
	}

	/*
	* 修炼完成--抽奖(生肖卡)
	*/
	public static function lotteryDrawForZodiac($myUserId){
		//检测有没有抽奖的机会
		$missionId = intval(post('missionId',0));
		if(!$missionId){
			alert('非法参数！', -1);
		}

		$oMission = m('Mission');
		$aMissionInfo = $oMission->getUserMissionInfo($missionId, $myUserId);
		if(!$aMissionInfo){
			alert('不存在此关卡哦！', -1);
		}

		if($aMissionInfo['is_task_finish'] != 1){
			alert('你还没有完成这关的修炼哦！', -1);
		}

		if($aMissionInfo['lottery_draw_status'] > 1 || $aMissionInfo['is_pass'] > 0){
			alert('这一关你已经抽过奖了哦！', -1);
		}

		//奖品信息配置
		$aPrizeList = $GLOBALS['ZODIAC_PRIZE'];
		foreach($aPrizeList as $key => $aPrize){
			if($aPrize['rank'] > 12){
				unset($aPrizeList[$key]);
			}
		}



		//得到用户的物品信息
		$oUserGoods = m('UserExtend');
		$aUserGoods = $oUserGoods->getUserGoodsInfo($myUserId);
		$countCards = 0;
		$count = count($aPrizeList);
		if($aUserGoods){
			$countCards = count($aUserGoods['cards']);
			if($countCards == 11){
				foreach($aPrizeList as $key => $aPrize){
					if(!in_array($aPrize['rank'], $aUserGoods['cards'])){
						$aPrizeList[$key]['chance'] = 0;
					}
				}
			}
		}

		//随机数
		$aChance = array();
		foreach($aPrizeList as $aPrize){
			$aChance[$aPrize['rank']] = $aPrize['chance'];
		}
		$rand = self::_randChance($aChance);

		//转盘位置配置
		$aTarget = array(
			1 => mt_rand(-10, 10),
			12 => mt_rand(20, 40),
			11 => mt_rand(50, 70),
			10 => mt_rand(80, 100),
			9 => mt_rand(110, 130),
			8 => mt_rand(140, 160),
			7 => mt_rand(170, 190),
			6 => mt_rand(200, 220),
			5 => mt_rand(230, 250),
			4 => mt_rand(260, 280),
			3 => mt_rand(290, 310),
			2 => mt_rand(320, 340),
		);

		//计算转盘位置
		$rotateValue = $aTarget[$rand];
		if($rotateValue < 0){
			$rotateValue = 360 + $rotateValue;
		}

		//更新用户卡片信息
		$isExistsCard = false;
		if($aUserGoods){
			if(!in_array($rand, $aUserGoods['cards'])){
				$aUserGoods['cards'][] = $rand;
				$result = $oUserGoods->setUserGoods($aUserGoods);
				if(!$result){
					alert('网络可能有点慢！请重新抽奖！', -1);
				}
				$countCards += 1;
			}else{
				$isExistsCard = true;
			}
		}else{
			$aUserGoods = array(
				'id' => $myUserId,
				'cards' => array($rand)
			);
			$result = $oUserGoods->addUserGoods($aUserGoods);
			if(!$result){
				alert('网络可能有点慢！请重新抽奖！', -1);
			}
			$countCards += 1;
		}

		//更新领奖状态
		$oMission->setUserMission(array(
			'id' => $aMissionInfo['id'],
			'lottery_draw_status' => 2
		));

		$aPrize = array();
		foreach($aPrizeList as $aPrize2){
			if($aPrize2['rank'] == $rand){
				$aPrize = $aPrize2;
				break;
			}
		}

		unset($aMissionInfo);
		alert('success', 1, array(
			'rotateValue' => $rotateValue,
			'isExistsCard' => $isExistsCard,
			'countCards' => $countCards,
			'zodiac' => array(
				'rank' => $rand,
				'prize' => $aPrize['prize'],
			)
		));
	}

	/*
	* PC版修炼完成--抽奖(生肖卡)
	*/
	public static function lotteryDrawForZodiacPC($myUserId){
		//检测有没有抽奖的机会
		$missionId = intval(post('missionId',0));
		if(!$missionId){
			alert('非法参数！', -1);
		}

		$oMission = m('Mission');
		$aMissionInfo = $oMission->getUserMissionInfo($missionId, $myUserId);
		if(!$aMissionInfo){
			alert('不存在此关卡哦！', -1);
		}

		if($aMissionInfo['is_task_finish'] != 1){
			alert('你还没有完成这关的修炼哦！', -1);
		}

		if($aMissionInfo['lottery_draw_status'] > 1 || $aMissionInfo['is_pass'] > 0){
			alert('这一关你已经抽过奖了哦！', -1);
		}

		//奖品信息配置
		$aPrizeList = $GLOBALS['ZODIAC_PRIZE'];

		//得到用户的物品信息
		$oUserGoods = m('UserExtend');
		$aUserGoods = $oUserGoods->getUserGoodsInfo($myUserId);
		$countCards = 0;
		$count = count($aPrizeList);
		if($aUserGoods){
			$countCards = count($aUserGoods['cards']);
		}

		//分二层随机
		//1.第一层随机：生肖 VS 金币或空
		$rankNumber = mt_rand(1, 3);
		//2.第二层随机:
		if($rankNumber == 1){
			//a.如果第一层随机到 生肖
			foreach($aPrizeList as $key => $aPrize){
				if($aPrize['rank'] > 12){
					$aPrizeList[$key]['chance'] = 0;
				}
			}

			if($aUserGoods){
				//当用户已有11张生肖卡时
				if($countCards == 11){
					//找出用户还没抽到的那张生肖
					foreach($aPrizeList as $key => $aPrize){
						if(!in_array($aPrize['rank'], $aUserGoods['cards'])){
							$aPrizeList[$key]['chance'] = 0;
							break;
						}
					}
				}
			}
		}else{
			//b.如果第一层随机到 金币或空
			foreach($aPrizeList as $key => $aPrize){
				if($aPrize['rank'] <= 12){
					$aPrizeList[$key]['chance'] = 0;
				}
			}
		}



		//随机数
		$aChance = array();
		foreach($aPrizeList as $aPrize){
			$aChance[$aPrize['rank']] = $aPrize['chance'];
		}
		$rand = self::_randChance($aChance);

		//计算转盘位置
			//转盘位置配置
		$aTarget = array(
			13 => mt_rand(1, 22),
			12 => mt_rand(23, 44),
			11 => mt_rand(47, 66),
			10 => mt_rand(69, 89),
			15 => mt_rand(92, 111),
			9 => mt_rand(114, 134),
			8 => mt_rand(137, 156),
			7 => mt_rand(159, 179),
			14 => mt_rand(182, 201),
			6 => mt_rand(204, 224),
			5 => mt_rand(227, 246),
			4 => mt_rand(249, 269),
			16 => mt_rand(272, 291),
			3 => mt_rand(294, 314),
			2 => mt_rand(317, 336),
			1 => mt_rand(339, 359),
		);
		$rotateValue = $aTarget[$rand];
		if($rotateValue < 0){
			$rotateValue = 360 + $rotateValue;
		}

		//更新用户卡片信息
		$isExistsCard = false;
		if($rand <= 12){
			if($aUserGoods){
				if(!in_array($rand, $aUserGoods['cards'])){
					$aUserGoods['cards'][] = $rand;
					$result = $oUserGoods->setUserGoods($aUserGoods);
					if(!$result){
						alert('网络可能有点慢！请重新抽奖！', -1);
					}
					$countCards += 1;
				}else{
					$isExistsCard = true;
				}
			}else{
				$aUserGoods = array(
					'id' => $myUserId,
					'cards' => array($rand)
				);
				$result = $oUserGoods->addUserGoods($aUserGoods);
				if(!$result){
					alert('网络可能有点慢！请重新抽奖！', -1);
				}
				$countCards += 1;
			}
		}
		//更新领奖状态
		$oMission->setUserMission(array(
			'id' => $aMissionInfo['id'],
			'lottery_draw_status' => 2
		));

		$aPrize = array();
		foreach($aPrizeList as $aPrize2){
			if($aPrize2['rank'] == $rand){
				$aPrize = $aPrize2;
				break;
			}
		}

		$oNum = new Numerical();
		if($rand == 15){
			$aPrize['prize'] = $GLOBALS['GOLD']['rand_gold5'];
			if(!$oNum->addMoney($myUserId, 15)){
				alert('网络可能有点慢！', 0);
			}
		}
		if($rand == 16){
			$aPrize['prize'] = $GLOBALS['GOLD']['rand_gold10'];
			if(!$oNum->addMoney($myUserId, 16)){
				alert('网络可能有点慢！', 0);
			}
		}

		unset($aMissionInfo);
		alert('success', 1, array(
			'rotateValue' => $rotateValue,
			'isExistsCard' => $isExistsCard,
			'countCards' => $countCards,
			'zodiac' => array(
				'rank' => $rand,
				'prize' => $aPrize['prize'],
			)
		));
	}

	/**
	 *	计算关卡星星
	 */
	private static function _getStarByPoint($point){
		if($point < 5600){
			return 0;
		}
		for($i = 5; $i >= 1; $i--){
			$starPoin = 5600 + ($i - 1) * 1000;
			if($point >= $starPoin){
				return $i;
			}
		}
	}

	/**
	 *检查作答格式
	 */
	private static function _checkChallenge($aChallengeAnswer, $isExerice){
		if($isExerice){
			if(!isset($aChallengeAnswer['ts'])){
				return false;
			}
		}else{
			if(!isset($aChallengeAnswer['cs'])){
				return false;
			}
		}
		if(!isset($aChallengeAnswer['mission_id']) || !isset($aChallengeAnswer['user_answer'])){
			return false;
		}
		if(!is_numeric($aChallengeAnswer['mission_id']) || !is_array($aChallengeAnswer['user_answer'])){
			return false;
		}
		if(!isset($aChallengeAnswer['user_answer']['id']) || !isset($aChallengeAnswer['user_answer']['answer'])){
			return false;
		}
		return true;
	}

	//随机概率算法--专用于抽奖
	private static function _randChance($aChance){
		$sum = array_sum($aChance);
		foreach($aChance as $key => $chance){
			$rand = mt_rand(1, $sum);
			if($rand <= $chance){
				$result = $key;
				break;
			}else{
				$sum -= $chance;
			}
		}
		unset($aChance);
		return $result;
	}

	//获取按科目和年级分的关卡列表
	public static function getSubjectGradeMissionList(){
		$oMission = m('Mission');
		$aSubject = $GLOBALS['SUBJECT'];
		$aMissionList = array();
		foreach($aSubject as $key => $value){
			$aSubjectMissionList = $oMission->getOriginalMissionList($key, null, null);
			if($key == 4){
				$aMissionList[$key][9] = $aMissionList[$key][8] = $aMissionList[$key][7] = $aMissionList[$key][6] = $aMissionList[$key][5] = $aSubjectMissionList;
				continue;
			}
			//分年级，以关卡名字第一位数字区分；比如：关卡‘52044 3.1长方体和正方体的认识’为5年级
			$aMissionList[$key][5] = array();
			$aMissionList[$key][6] = array();
			$aMissionList[$key][7] = array();
			$aMissionList[$key][8] = array();
			$aMissionList[$key][9] = array();
			foreach($aSubjectMissionList as $k => $aSubjectMission){
				$missionName = trim($aSubjectMission['name']);
				$grade = $aSubjectMission['grade'];//mb_substr($missionName, 0, 1, 'UTF-8');
				if($grade >= 5 && $grade <= 9){
					$aSubjectMission['name'] = mb_substr($missionName, 5, mb_strlen($missionName, 'UTF-8'), 'UTF-8');
				}
				if($grade == 5){
					$aSubjectMission['name'] = '五年级' . $aSubjectMission['name'];
					array_push($aMissionList[$key][5], $aSubjectMission);
				}elseif($grade == 6){
					$aSubjectMission['name'] = '六年级' . $aSubjectMission['name'];
					array_push($aMissionList[$key][6], $aSubjectMission);
				}elseif($grade == 7){
					$aSubjectMission['name'] = '初一' . $aSubjectMission['name'];
					array_push($aMissionList[$key][7], $aSubjectMission);
				}elseif($grade == 8){
					$aSubjectMission['name'] = '初二' . $aSubjectMission['name'];
					array_push($aMissionList[$key][8], $aSubjectMission);
				}elseif($grade == 9){
					$aSubjectMission['name'] = '初三' . $aSubjectMission['name'];
					array_push($aMissionList[$key][9], $aSubjectMission);
				}else{
					//$aSubjectMission['name'] = '九年级' . $aSubjectMission['name'];
					//array_push($aMissionList[$key][9], $aSubjectMission);
				}
			}
		}
		return $aMissionList;
	}

	public static function convertMissionList($aMissionList){
		$aGradeList = $GLOBALS['GRADE'];
		foreach($aMissionList as $key => $aMission){
			$missionName = trim($aMission['name']);
			$grade = $aMission['grade'];

			if(is_numeric(mb_substr($missionName, 0, 1, 'UTF-8'))){
				$missionName = mb_substr($missionName, 5, mb_strlen($missionName, 'UTF-8') - 5, 'UTF-8');
			}
			if(isset($aGradeList[$grade])){
				$missionName = $aGradeList[$grade] . ' ' .  $missionName;
			}else{
				$missionName = $aMission['name'];
			}
			$aMissionList[$key]['name'] = $missionName;
		}
		return $aMissionList;
	}
}