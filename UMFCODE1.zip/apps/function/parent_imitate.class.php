<?php
class ParentImitate{
	const USER_ID =	15947559;	//模拟账户的学生id
	const OVER_TIME = 86400;	//过期时间设为一天
	//获取用户信息
	public static function getUserInfo($aDetail = array()){
		return getUserInfo(self::USER_ID, $aDetail);
	}

	//报告页详细
	public static function getUserMonthStatisticsInfo($month){
		$oParent = m('parent');
		return $oParent->getUserMonthStatisticsInfo(self::USER_ID, $month);
	}

	//报告页面列表
	public static function getUserMonthStatisticsList(){
		$oParent = m('parent');
		return $oParent->getUserMonthStatisticsList(self::USER_ID);
	}

	//辅导页统计 ：错题数，待修复，已修复
	public static function getUserEsWrongStatistics($parentId){
		$rand = self::_getAnalogRandom();
		$parentId = $parentId . $rand;
		$aStatistics = self::_getRedisDataByKey('parent_imitate_es_wrong_statistics:' . $parentId);
		if(!$aStatistics){
			$aStatisticsList = self::_addUserEsWrongStatistics($parentId);
			if($aStatisticsList === false){
				return false;
			}
			return $aStatisticsList['statistics'];
		}
		return $aStatistics;
	}

	//辅导页按月份的列表
	public static function getUserEsWrongMonthStatistics($parentId){
		$rand = self::_getAnalogRandom();
		$parentId = $parentId . $rand;
		$aStatistics = self::_getUserEsWrongMonthDetailStatistics($parentId);
		if(!$aStatistics){
			return $aStatistics;
		}
		ksort($aStatistics);
		$aReturnData = array();
		foreach($aStatistics as $month => $aMonthStatistis){
			$aTemp = array();
			$aTemp['month'] = $month;
			$aTemp['num'] = count($aMonthStatistis['es_list']);
			$aTemp['es_repair_count'] = $aMonthStatistis['es_repair_count'];
			array_unshift($aReturnData, $aTemp);
		}
		return $aReturnData;
	}

	//辅导页按关卡的列表
	public static function getUserEsWrongMissionStatistics($parentId, $subjectId, $page, $pageSize){
		$rand = self::_getAnalogRandom();
		$parentId = $parentId . $rand;
		$aStatistics = self::_getUserEsWrongMissionDetailStatistics($parentId);
		if(!$aStatistics){
			return $aStatistics;
		}
		if(!isset($aStatistics[$subjectId])){
			return array('mission_list' => array(), 'all_count' => 0);
		}
		$allCount = count($aStatistics[$subjectId]);
		$aSubjectList = $aStatistics[$subjectId];
		$aReturnData = array();
		$offect = ($page - 1) * $pageSize;
		$end = $offect + $pageSize - 1;
		$i = 0;
		$aMissionIds = array();
		foreach($aSubjectList as $missionId => $aMission){
			if($i > $end){
				break;
			}elseif($i >= $offect){
				$aTemp = array();
				$aTemp['mission_id'] = $missionId;
				$aTemp['nums'] = count($aMission['es_list']);
				$aTemp['es_repair_count'] = $aMission['es_repair_count'];
				$aReturnData[] = $aTemp;
				$aMissionIds[] = $missionId;
			}
			$i++;
		}
		$oMission = m('mission');
		$aMissionList = $oMission->getMissionListByIds($aMissionIds);
		if($aMissionList === false){
			return false;
		}
		foreach($aReturnData as $key => $aReturn){
			foreach($aMissionList as $aMission){
				if($aMission['id'] == $aReturn['mission_id']){
					$aReturnData[$key]['mission_name'] = $aMission['name'];
				}
			}
		}
		return array('mission_list' => $aReturnData, 'all_count' => $allCount);
	}

	//修复错题
	public static function repairUserEsWrong($parentId, $esId){
		$rand = self::_getAnalogRandom();
		$parentId = $parentId . $rand;
		$aSubjectMissionList = self::_getUserEsWrongMissionDetailStatistics($parentId);
		if($aSubjectMissionList === false){
			return false;
		}
		//debug($aSubjectMissionList);
		$deleteMission = 0;
		$deleteMonth = 0;
		$isFind = 0;
		foreach($aSubjectMissionList as $subjectId => $aSubjectMission){
			foreach($aSubjectMission as $missionId => $aMission){
				foreach($aMission['es_list'] as $esKey => $aEs){
					if($aEs['es_id'] == $esId){
						unset($aSubjectMissionList[$subjectId][$missionId]['es_list'][$esKey]);
						$aSubjectMissionList[$subjectId][$missionId]['es_repair_count'] += 1;
						if(!$aSubjectMissionList[$subjectId][$missionId]['es_list']){
							unset($aSubjectMissionList[$subjectId][$missionId]);
							if(!$aSubjectMissionList[$subjectId]){
								unset($aSubjectMissionList[$subjectId]);
								$deleteMission = 1;
							}
						}
						$isFind = 1;
						break;
					}
				}
			}
		}
		//debug($aSubjectMissionList);
		$aMonthStatisticsList = self::_getUserEsWrongMonthDetailStatistics($parentId);
		if($aMonthStatisticsList === false){
			return false;
		}
		foreach($aMonthStatisticsList as $month => $aMonthStatistics){
			foreach($aMonthStatistics['es_list'] as $esKey => $aEs){
				if($aEs['es_id'] == $esId){
					unset($aMonthStatisticsList[$month]['es_list'][$esKey]);
					if(!$aMonthStatisticsList[$month]['es_list']){
						unset($aMonthStatisticsList[$month]);
						$deleteMonth = 1;
					}else{
						$aMonthStatisticsList[$month]['es_repair_count'] += 1;
					}
					$isFind = 1;
					break;
				}
			}
		}
		if(!$isFind){
			return 0;
		}
		$aStatistics = self::getUserEsWrongStatistics($parentId);
		$aStatistics['wrong_es_count'] -= 1;
		$aStatistics['es_repair_count'] += 1;
		if($deleteMission){
			self::_deleteReidsDataByKey('parent_imitate_es_wrong_mission:' . $parentId);
		}
		if($deleteMonth){
			self::_deleteReidsDataByKey('parent_imitate_es_wrong_month:' . $parentId);
		}
		return self::_setParentImitate($parentId, $aStatistics, $aMonthStatisticsList, $aSubjectMissionList);
	}

	/*获取错误信息
	 * type：mission或month
	 * dataId:mission_id或month
	 */
	public static function getUserEsWrongInfo($parentId, $type, $dataId, $offect){
		$rand = self::_getAnalogRandom();
		$parentId = $parentId . $rand;
		$aEsList = array();
		if($type == 'mission'){
			$aSubjectStatisticsList = self::_getUserEsWrongMissionDetailStatistics($parentId);
			if($aSubjectStatisticsList === false){
				return false;
			}
			$aEsList = array();
			foreach($aSubjectStatisticsList as $aSubjectStatistics){
				if(isset($aSubjectStatistics[$dataId])){
					$aEsList = $aSubjectStatistics[$dataId]['es_list'];
					break;
				}
			}
		}elseif($type == 'month'){
			$aMonthStatisticsList = self::_getUserEsWrongMonthDetailStatistics($parentId);
			if(isset($aMonthStatisticsList[$dataId])){
				$aEsList = $aMonthStatisticsList[$dataId]['es_list'];
			}
		}else{
			return array();
		}
		if(!$aEsList){
			return $aEsList;
		}
		$i = 0;
		foreach($aEsList as $aEs){
			if($i == $offect){
				return $aEs;
			}
			$i++;
		}
	}

	private static function _getUserEsWrongMissionDetailStatistics($parentId){
		$aStatistics = self::_getRedisDataByKey('parent_imitate_es_wrong_mission:' . $parentId);
		if(!$aStatistics){
			$aStatisticsList = self::_addUserEsWrongStatistics($parentId);
			if($aStatisticsList === false){
				return false;
			}
			$aStatistics =  $aStatisticsList['mission'];
		}else{
			$aStatistics = self::_decodeData($aStatistics);
		}
		return $aStatistics;
	}

	private static function _getUserEsWrongMonthDetailStatistics($parentId){
		$aStatistics = self::_getRedisDataByKey('parent_imitate_es_wrong_month:' . $parentId);
		if(!$aStatistics){
			$aStatisticsList = self::_addUserEsWrongStatistics($parentId);
			if($aStatisticsList === false){
				return false;
			}
			$aStatistics = $aStatisticsList['month'];
		}else{
			$aStatistics = self::_decodeData($aStatistics);
		}
		return $aStatistics;
	}

	private static function _getRedisDataByKey($key){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		return $oRedis->getOne($key);
	}

	private static function _deleteReidsDataByKey($key){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		return $oRedis->deleteOne($key);
	}

	private static function _addUserEsWrongStatistics($parentId){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . self::USER_ID;
		$aAllUserEsWrongList = $oUserEsWrong->get('`subject_id`,`mission_id`,`es_id`,`create_time`', $where, '`create_time` DESC');
		if($aAllUserEsWrongList === false){
			return $aAllUserEsWrongList;
		}
		$aMonthData = array();
		$aMissionData = array();
		$allWrongEsCount = count($aAllUserEsWrongList);	//待修复题目数
		foreach($aAllUserEsWrongList as $aAllUserEsWrong){
			$month = date('Ym', $aAllUserEsWrong['create_time']);
			$aMonthTemp = array();
			$aMonthTemp['es_id']	= $aAllUserEsWrong['es_id'];
			$aMonthTemp['mission_id'] = $aAllUserEsWrong['mission_id'];
			$aMonthData[$month]['es_list'][] = $aMonthTemp;
			$aMonthData[$month]['es_repair_count']	= 0;
			$aMissionTemp = array();
			$aMissionTemp['es_id'] = $aAllUserEsWrong['es_id'];
			$aMissionTemp['month']	= $month;
			$aMissionData[$aAllUserEsWrong['subject_id']][$aAllUserEsWrong['mission_id']]['es_list'][] = $aMissionTemp;
			$aMissionData[$aAllUserEsWrong['subject_id']][$aAllUserEsWrong['mission_id']]['es_repair_count'] = 0;
		}
		unset($aAllUserEsWrongList);
		$oMission = new Model(T_MISSION_USER_RELATION_INDEX);
		$aMissionUserList = $oMission->get('`mission_id`,`es_count`,`es_correct_count`,`es_repair_count`', '`user_id`=' . self::USER_ID);
		if($aMissionUserList === false){
			return false;
		}
		//关卡修复题目统计
		foreach($aMissionUserList as $aMissionUser){
			if($aMissionUser['es_repair_count']){
				foreach($aMissionData as $subject => $aMissionList){
					if(isset($aMissionList[$aMissionUser['mission_id']])){
						$aMissionData[$subject][$aMissionUser['mission_id']]['es_repair_count'] = $aMissionUser['es_repair_count'];
						break;
					}
				}
			}
		}
		unset($aMissionList);
		//月修复记录
		$allWrongEsTimes = 0;	//总错题次数
		$allRepairEsCount = 0;	//总修复题目数量
		$oParent = m('parent');
		$aUserMonthStatisticsList = $oParent->getUserMonthStatisticsList(self::USER_ID);
		if($aUserMonthStatisticsList === false){
			return false;
		}
		foreach($aUserMonthStatisticsList as $aUserMonthStatistics){
			if($aUserMonthStatistics['statistics']['es']['es_repair_count']){
				if(isset($aMonthData[$aUserMonthStatistics['month']]['es_repair_count'])){
					$aMonthData[$aUserMonthStatistics['month']]['es_repair_count'] = $aUserMonthStatistics['statistics']['es']['es_repair_count'];
					$allRepairEsCount += $aUserMonthStatistics['statistics']['es']['es_repair_count'];
				}
			}
			foreach($aUserMonthStatistics['statistics']['es']['mission'] as $aSubject){
				$allWrongEsTimes += $aSubject['es_wrong'];
			}
		}
		unset($aUserMonthStatisticsList);
		$aStatistics = array(
			'wrong_es_times'	=>	$allWrongEsTimes,
			'wrong_es_count'	=>	$allWrongEsCount,
			'es_repair_count'	=>	$allRepairEsCount,
		);
		//存到redis数据库里面
		//存统计信息
		self::_setParentImitate($parentId, $aStatistics, $aMonthData, $aMissionData);
		return array(
			'statistics'	=>	$aStatistics,
			'month'			=>	$aMonthData,
			'mission'		=>	$aMissionData,
		);
	}

	private static function _setParentImitate($parentId, $aStatistics, $aMonthData, $aMissionData){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return 0;
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return 0;
		}
		foreach($aMonthData as $key => $aMonth){
			$aMonthData[$key] = json_encode($aMonth);
		}
		foreach($aMissionData as $key => $aMission){
			$aMissionData[$key] = json_encode($aMission);
		}
		$oRedis->redis->multi(Redis::PIPELINE);
		$oRedis->add('parent_imitate_es_wrong_statistics:' . $parentId, $aStatistics);
		$oRedis->add('parent_imitate_es_wrong_month:' . $parentId, $aMonthData);
		$oRedis->add('parent_imitate_es_wrong_mission:' . $parentId, $aMissionData);
		$oRedis->expire('parent_imitate_es_wrong_statistics:' . $parentId, self::OVER_TIME);
		$oRedis->expire('parent_imitate_es_wrong_month:' . $parentId, self::OVER_TIME);
		$oRedis->expire('parent_imitate_es_wrong_mission:' . $parentId, self::OVER_TIME);
		$aReulst = $oRedis->redis->exec();
		if($aReulst[0] && $aReulst[1] && $aReulst[2]){
			return true;
		}
	}

	private static function _decodeData($aDataList){
		foreach($aDataList as $key => $aData){
			$aDataList[$key] = json_decode($aData, true);
		}
		return $aDataList;
	}

	private static function _getAnalogRandom(){
		if(Cookie::isSetted('analogRandom')){
			return Cookie::get('analogRandom');
		}
		$rand = md5(microtime());
		Cookie::set('analogRandom', $rand);
	}
}

