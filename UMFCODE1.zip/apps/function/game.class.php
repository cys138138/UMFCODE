<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-12-30
 */
class Game{

	/**
	 * 普通答对题目
	 * @@param $from 1 闯关  2 比赛
	 */
	public function afertRightEs($userId, $aEsInfo, $gotTime, $gotTimeCookie, $from, $rightCount, $isMatch = 0){
		if(!$this->afterFinishEs($userId, $aEsInfo, $gotTime, $gotTimeCookie, 1)){
			return false;
		}
		if($from == 1){
			$accumulateLimit = $GLOBALS['POINT']['mission']['limit_es'];
		}elseif($from == 2){
			$accumulateLimit = $GLOBALS['POINT']['match']['limit_es'];
		}else{
			return false;
		}
		if($rightCount <= $accumulateLimit && !$isMatch){
			$oNum = new Numerical();
			$result = $oNum->addAccumulatePoints($userId, 7);
			if($result){
				return true;
			}else{
				return false;
			}
		}
		return true;
	}


	/**
	 * 首次完成修炼
	 */
	public function firstFinishPractice($data, $rightRate){
		$oSns = m('SnsEvent');
		$aTaskEvent = array(
			'user_id' => $data['user_id'],
			'type' => $data['type'],
			'data_id' => $data['data_id'],
		);
		if(!$oSns->addEvent($aTaskEvent)){
			return false;
		}

		$oNum = new Numerical();
		if(!$oNum->addAccumulatePoints($data['user_id'], 8, $rightRate)){
			return false;
		}
		return true;
	}

	/**
	 * 普通答错题目
	 */
	public function afertWrongEs($userId, $aEsInfo, $aUserAnswer, $missionId, $gotTime, $gotTimeCookie){
		if(!$this->afterFinishEs($userId, $aEsInfo, $gotTime, $gotTimeCookie, 0)){
			return false;
		}

		if($missionId){
			$aWrongEs = array();
			$aWrongEs['create_time'] = time();
			$aWrongEs['answer_last'] = $aUserAnswer;
			$oEs = m('Es');
			$aIsWronged = $oEs->getUserWrongEsByUserIdAndEsId($userId, $aEsInfo['id']);
			if($aIsWronged){
				$aWrongEs['id'] = $aIsWronged['id'];
				if(!$oEs->setUserEsWrong($aWrongEs)){
					return false;
				}
			}else{
				$aWrongEs['subject_id'] = $aEsInfo['subject_id'];
				$aWrongEs['es_id'] = $aEsInfo['id'];
				$aWrongEs['is_ignore'] = 2;
				$aWrongEs['user_id'] = $userId;
				$aWrongEs['mission_id'] = $missionId;
				$aWrongEs['type_id'] = $aEsInfo['type_id'];
				if(!$oEs->addUserEsWrong($aWrongEs)){
					return false;
				}
				$GLOBALS['UPDATE']['numerical_data']['error'] = $oEs->getUserWrongEsCount($userId);
			}
		}
		return true;
	}

	/**
	 * 成功挑战包括首次和以后
	 */
	public function successChallenge($aMyMission, $aMissoinInfo, $eventType, $useTime, $rightEsCount, $thisScore, $topScore, $passMissionNum){
		$oNum = new Numerical();
		$oSns = m('SnsEvent');
		if($aMyMission['is_pass'] != 1){
			$aTaskEvent = array();
			$aTaskEvent['user_id'] = $aMyMission['user_id'];
			$aTaskEvent['type'] = $eventType;
			$aTaskEvent['data_id'] = $aMyMission['id'];
			if(!$oSns->addEvent($aTaskEvent)){
				return false;
			}

			$challengeEs = 0;
			foreach($aMissoinInfo['challenge_es_count'] as $aThisEsType){
				$challengeEs = $challengeEs + $aThisEsType['es_count'];
			}
			$corrcetRate = $rightEsCount / $challengeEs;
			$aChallenge = array(
				'total_time' => $aMissoinInfo['challenge_limit_duration'] * 60,
				'remaining_time' => $aMissoinInfo['challenge_limit_duration'] * 60 - $useTime,
				'corrcet_rate' => $corrcetRate,
			);
			if(!$oNum->addAccumulatePoints($aMyMission['user_id'], 9, $aChallenge)){
				return false;
			}
			//过关咱将
			if(!$oNum->addMedal($aMyMission['user_id'], 2)){
				return false;
			}
		}

		//箭无虚发
		if($aMyMission['score'] < $GLOBALS['EXCELLENT_MISSIONS_SCORE'] && $thisScore >= $GLOBALS['EXCELLENT_MISSIONS_SCORE']){
			if(!$oNum->addMedal($aMyMission['user_id'], 3)){
				return false;
			}
		}

		//破自己记录
		if($thisScore > $aMyMission['score'] && $aMyMission['is_pass']){
			$breakMyselfReword = intval(($thisScore - $aMyMission['score']) / $thisScore * $GLOBALS['POINT']['mission']['first_finish_mission_base']);
			if(!$oNum->addAccumulatePoints($aMyMission['user_id'], 10, $breakMyselfReword)){
				return false;
			}
			$GLOBALS['UPDATE']['custom_data']['personal_record'] = ($thisScore - $aMyMission['score']) / 100;
			$aTaskEvent = array();
			$aTaskEvent['user_id'] = $aMyMission['user_id'];
			$aTaskEvent['type'] = 90;
			$aTaskEvent['data_id'] = $aMyMission['id'];
			if(!$oSns->addEvent($aTaskEvent)){
				return false;
			}
		}
		//破世界记录
		if($thisScore > $topScore){
			if(!$oNum->addAccumulatePoints($aMyMission['user_id'], 11, $passMissionNum)){
				return false;
			}
			$GLOBALS['UPDATE']['custom_data']['world_record'] = ($thisScore - $topScore) / 100;
			$aTaskEvent = array();
			$aTaskEvent['user_id'] = $aMyMission['user_id'];
			$aTaskEvent['type'] = 91;
			$aTaskEvent['data_id'] = $aMyMission['id'];
			if(!$oSns->addEvent($aTaskEvent)){
				return false;
			}
		}
		return true;
	}

	/**
	 * PK领奖后
	 */
	public function afterPKEnd($master, $slaver, $winner){
		$oNum = new Numerical();
		//if(!$oNum->addMedal($winner, 6)){
			//return false;
		//}
		return true;
	}

	/**
	 * PK领奖
	 */
	public function acceptPKReword($userId, $points, $isReceiveGold, $gold){
		$oNum = new Numerical();
		if($isReceiveGold == 1 && $gold){
			if(!$oNum->addMoney($userId, 5, $gold)){
				return false;
			}
		}
		if($oNum->addAccumulatePoints($userId, 12, $points) === false){
			return false;
		}
		return true;
	}

	/**
	 * 答完一道题目后
	 */
	public function afterFinishEs($userId, $aEsInfo, $gotTime, $gotTimeCookie, $isRight){
		$aEsCount = array();
		$aEsCount['id'] = $aEsInfo['id'];
		$aEsCount['answer_counts'] = $aEsInfo['answer_counts'] + 1;
		$ts = Xxtea::decrypt($gotTime);
		$useTime = time() - $ts;
		if($useTime <= MAX_ANSWER_ES_TIME && md5($ts) == $gotTimeCookie){
			$aEsCount['answer_time_total'] = $aEsInfo['answer_time_total'] + $useTime;
		}

		foreach($aEsInfo['recent_record'] as $key => $aRecord){
			if($aRecord['user_id'] == $userId){
				unset($aEsInfo['recent_record'][$key]);
			}
		}
		if(count($aEsInfo['recent_record']) >= 10){
			array_pop($aEsInfo['recent_record']);
		}
		$aAnswerRecord = array(
			'user_id' => $userId,
			'create_time' => time(),
			'answer_time' => $useTime,
			'is_correct' => $isRight,
		);
		array_unshift($aEsInfo['recent_record'], $aAnswerRecord);
		$aEsCount['recent_record'] = $aEsInfo['recent_record'];

		if($isRight){
			$aEsCount['correct_counts'] = $aEsInfo['correct_counts'] + 1;
		}else{
			$aEsCount['correct_counts'] = $aEsInfo['correct_counts'];
		}
		$aEsCount['correct_percent'] = round($aEsCount['correct_counts'] / $aEsCount['answer_counts'] * 100);
		$oEs = m('Es');
		if(!$oEs->setEs($aEsCount)){
			return false;
		}
		return true;
	}

	/**
	 * 签到后
	 */
	public function afterSign($userId, $continueDadys){
		$oNum = new Numerical();
		if(!$oNum->addMoney($userId, 1, $continueDadys)){
			return false;
		}
		return true;
	}


	/**
	 * 领取赛事奖励
	 */
	public function getMatchReward($userId, $aData, $gold){
		$oNum = new Numerical();
		if(!$oNum->addAccumulatePoints($userId, 13, $aData) || !$oNum->addMoney($userId, 6, $gold)){
			return false;
		}
		return true;
	}

	/**
	 * 发说说之后
	 */
	public function afterPublishShuo($userId){
		$oNum = new Numerical();
		if(!$oNum->addAccumulatePoints($userId, 6)){
			return false;
		}
		return true;
	}

	/**
	 * 加好友之后
	 */
	public function afterAddFriend($userId){
		$oNum = new Numerical();
		if(!$oNum->addAccumulatePoints($userId, 15)){
			return false;
		}
		return true;
	}


	/**
	 * 设置不同类型业务的返回结果
	 */
	public function setResult($aResult){
		$GLOBALS['UPDATE']['show_type'] = $aResult['show_type'];
		foreach($aResult['custom_data'] as $key => $val){
			$GLOBALS['UPDATE']['custom_data'][$key] = $val;
		}
	}

	/**
	 * 设置不同类型业务的返回结果
	 */
	public function getMissionMaxScore(){
		return $GLOBALS['POINT']['es'] * $GLOBALS['POINT']['mission']['limit_es'] + $GLOBALS['POINT']['mission']['practice_extra_base'] + $GLOBALS['POINT']['mission']['first_finish_mission_base'];
	}

	/**
	 * 错题反馈奖励金币
	 */
	public function rewardFeedbackWrongEs($userId){
		$oNum = new Numerical();
		if(!$oNum->addMoney($userId, 2)){
			return false;
		}
		return true;
	}

	/**
	 * 注册成功后
	 */
	public function afterRegistered($userId){
		$oNum = new Numerical();
		if(!$oNum->addAccumulatePoints($userId, 17)){
			return false;
		}
		return true;
	}

}