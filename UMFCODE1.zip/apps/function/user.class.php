<?php
use common\model\Student;
use common\model\SystemConfig;
/*detail为除了用户默认信息的其他信息配置
 $aDetail = array(){
 *	'personal',
 * 'invite_code',
 * 'area',
 * 'class',
 * 'numerical',
 * }
 */
function getUserInfo($userId, $aDetail = array()){
	$oUser = m('user');
	return $oUser->getUserDetailPersonalInfoByUserId($userId, $aDetail);
}

function getUserFriendIds($userId){
	$oSns = m('sns');
	return $oSns->getUserFriendIdList($userId);
}

function getUserListByUserIds($aUserIds, $aDetail = array()){
	if(!$aUserIds){
		return array();
	}
	$oUser = m('user');
	return $oUser->getUserDetailPersonalListByUserIds($aUserIds, $aDetail);
}

//可能认识的人
function getProbably(){
	$aUser = isLogin();
	$userId = $aUser['id'];
	$oSns = m('Sns');
	$aUserFriendInfo = $oSns->getUserFriendInfo($userId);
	$aFriendIds = array();
	if($aUserFriendInfo){
		$friendIds = '';
		foreach($aUserFriendInfo['friends'] as $ids){
			$friendIds .= ',' . trim($ids, ',');
		}
		$aFriendIds = array_filter(explode(',', trim($friendIds, ',')));
	}

	$aProbablyList = $oSns->getUserProbalyFriendList($userId);
	if($aProbablyList){
		foreach($aProbablyList as $key => &$value){
			if(in_array($value['id'], $aFriendIds)){
				unset($aProbablyList[$key]);
			}else{
				$aUserRelation = $oSns->getUserRelationInfo('`user_master_id` = ' . $userId . ' AND `user_slave_id` = ' . $value['id']);
				if($aUserRelation){
					$value['is_apply'] = 1;
				}else{
					$value['is_apply'] = 0;
				}
			}
		}
	}
	return $aProbablyList;
}

class User{

	/**
	 * 用户登陆处理
	 * 表单参数: email(邮箱账号或手机或数字ID), password, rempass（可选）
	 */
	public static function login(){
		alert('抱歉,本接口已停用', 0);
		limitCheck('LOGIN');
		//验证账号可以为邮箱和数字账号
		$idStr = strtolower(post('email'));
		$isEmail = w('isEmail()', $idStr);
		$isNumber = w('isNumber(8)', $idStr);
		$isMobile = w('isPhone()', $idStr);
		if(!$isEmail && !$isNumber && !$isMobile){
			alert('请填写正确的账号', -1);
		}

		$vResult = v('password');
		if($vResult){
			alert($vResult, -1);
		}

		$password = post('password');
		$autoLogin = post('rempass') ? true : false;//默认不记住登陆
		$reference = base64_decode(urldecode(get('reference')));
		$oUser = m('User');
		$aUserInfo = array();
		//先判断是邮箱还是数字账号，再调用各自的方法
		if($isEmail){
			$aUserInfo = $oUser->getUserInfoByEmailAndPassword($idStr, $password);
		}else if($isNumber){
			$aUserInfo = $oUser->getUserInfoByNumberIdAndPassword($idStr, $password);
		}else if($isMobile){
			$aUserInfo = $oUser->getUserInfoByMobileAndPassword($idStr, $password);

		}
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo){
			limitAdd('LOGIN');
			alert('账号或密码错误！', -1);
		}

		if($aUserInfo['is_forbidden'] == 1){
			alert('抱歉，您已经被禁用！', -1);
		}

		//设置登陆信息
		self::_setLoginCookie($aUserInfo, $autoLogin);


		$isAndroid = defined('CLIENT_SYSTEM') ? (CLIENT_SYSTEM == 'android') : false;
		if($isAndroid){
			//安卓的需要，检查是否完善资料
			checkUserLogin();
			alert('登陆成功！', 1, array('id' => $aUserInfo['id'], 'email' => $aUserInfo['email'], 'mobile' => $aUserInfo['mobile']));
		}else{
			alert('登陆成功！', 1, $reference ? $reference : url('m=Index&a=index'));
		}
	}

	/**
	* 登出处理
	*/
	public static function logout(){
		$jumpUrl = urldecode(get('jump'));
		if(!$jumpUrl = base64_decode($jumpUrl)){
			$jumpUrl = url('m=Login&a=showLogin', '', APP_LOGIN);
		}

		$userId = Cookie::getDecrypt('userId');
		if($userId){
			$aLoginInfo = User::getUserLoginInfo($userId);
			if($aLoginInfo && $aLoginInfo['ip'] == getClientIP()){
				User::deleteUserLoginInfo($userId);
			}
		}

		Cookie::delete('autoLogin');
		Cookie::delete('userId');
		Cookie::delete('loginToken');
		Cookie::delete('lastActiveTime' . $userId);
		if(get('referer') != ''){
			$reference = base64_encode(get('referer'));
		}else{
			$reference = base64_encode(getReferer());
		}
		$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty($_POST['ajax']) || !empty($_GET['ajax']);
		if(!$isAjax){
			header('location:' . $jumpUrl);
		}else{
			alert('登出成功', 1, $jumpUrl);
		}
	}

	/**
	 * 检查账号是否注册过
	 * 表单参数: email(邮箱账号或手机或数字ID)
	 */
	public static function checkAccountExist(){
		$account = strtolower(post('email'));
		$isEmail = w('isEmail()', $account);
		$isMobile = w('isPhone()', $account);
		if(!$isEmail && !$isMobile){
			alert('请填写正确的账号', -1);
		}
		$oUser = m('User');
		if($isEmail){
			$num = $oUser->isEmailExist($account);
		}else if($isMobile){
			$num = $oUser->isMobileExist($account);
		}

		if($num === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if($num){
			if($isEmail){
				alert('该邮箱已经注册过了!', -1);
			}elseif($isMobile){
				alert('该手机已经注册过了!', -1);
			}
		}else{
			if($isEmail){
				alert('邮箱正确!', 1);
			}elseif($isMobile){
				alert('手机正确!', 1);
			}
		}
	}

	/**
	 * 注册处理
	 * 表单参数：email_register, password_register, is_read_register, invitation_register, captcha_register
	 */
	public static function register(){
		$vResult = v('password_register,is_read_register');
		if($vResult){
			alert($vResult, 0);
		}
		$oUser = m('User');
		//检查验证码只能是8位、5位或为空和是否有效
		$inviteCode = intval(post('invitation_register'));
		$eightNumInviteCode = w('isNumber(8)', $inviteCode);

		if($inviteCode && !$eightNumInviteCode){
			alert('邀请码格式不对!', 0);
		}elseif($eightNumInviteCode){
			$numberIdExist = $oUser->isNumberIdExist($inviteCode);
			if(!$numberIdExist){
				alert('邀请码不正确或不存在!', 0);
			}
		}
		//验证邮箱
		$emailRegister = strtolower(post('email_register'));
		$isEmail = w('isEmail()', $emailRegister);
		$isMobile = w('isPhone()', $emailRegister);
		$isAndroid = defined('CLIENT_SYSTEM') ? (CLIENT_SYSTEM == 'android') : false;
		if(!($isAndroid && $isMobile)){
			//检查验证码是否正确
			$registerCaptcha = post('captcha_register');
			if(!Verify::match('loginCaptcha', $registerCaptcha)){
				alert('验证码错误！', 0);
			}
		}
		if(!$isEmail && !$isMobile){
			alert('邮箱或手机格式错误!', 0);
		}

		$password = post('password_register');
		$userId = 0;
		//验证邮箱是否已经存在数据库了
		if($isEmail){
			$userId = self::registerByEamil($emailRegister, $password, intval($eightNumInviteCode));
		}else if($isMobile){
			$userId = self::registerByTel($emailRegister, $password, intval($eightNumInviteCode));
		}

		self::loginUser($userId);
		//设置vip
		$mSystemConfig = SystemConfig::findOne(SystemConfig::ID_REGISTER_SEND_VIP);
		$mStudent = Student::findOne($userId);
		if(isset($mSystemConfig->content[0]) && $mSystemConfig->content[0]){
			$mStudent->set('vip', $mSystemConfig->content[0]['vip']);
			$mStudent->set('vip_expiration_time', NOW_TIME + $mSystemConfig->content[0]['days'] * SystemConfig::REGISTER_SEND_VIP_DATUM);
			$mStudent->save();
		}

		//注册后做钩子处理(对邀请码为5位和8位的进行处理)
		$aDataHook = array();
		$aDataHook['user_id'] = $userId;
		$aDataHook['invite_code'] = $inviteCode;
		$aDataHook['eight_number_invite_code'] = $eightNumInviteCode;
		self::_afterRegister($aDataHook);//邀请人经验累积

		//每日任务
		if($inviteCode){
			Task::refreshTask($inviteCode, 0);
		}

		$aInvitaionUserInfo = '';
		if($inviteCode > 0){
			//增加一条邀请记录
			$oUserInvitation = m('UserInvitation');
			$aAddUserInvitaionData = array(
				'id' => $userId,
				'invite_code' => $inviteCode
			);
			$userInvitation = $oUserInvitation->setUserInvitation($aAddUserInvitaionData);
			if($userInvitation === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			//读取邀请人信息
			$aInvitaionUserInfo = $oUser->getUserDetailInfoByUserId($inviteCode);
			if($aInvitaionUserInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}elseif(!$aInvitaionUserInfo){
				alert('抱歉,系统出错,注册失败', 0);
			}
		}
		alert('注册成功，快去完善资料吧!', 1, array('password' => $password, 'number_id' => $userId, 'email' => $emailRegister, 'invitaion' => $aInvitaionUserInfo, 'mobile' => $emailRegister,));
	}

	/**
	 * 使用QQ账号登陆、注册
	 */
	public static function doQQAccountLogin(){
		include_once SYSTEM_BASE_PATH . 'library/QQConnect/qqConnectAPI.php';
		$code = Xxtea::decrypt((string)get('code'));
		if(!$code){
			alert('系统出错，请稍后再试', 0);
		}
		$aCode = explode(',', $code);
		if(count($aCode) != 2){
			alert('系统出错，请稍后再试', 0);
		}
		$openId = $aCode[0];
		$accessToken = $aCode[1];
		/*$qc = new QC();
		//QQ登录成功后的回调地址,主要保存access token
		$accessToken = $qc->qq_callback();
		//获取用户标示id
		$openId = $qc->get_openid();
		*/
		$qc = new QC($accessToken, $openId);
		if(!$openId){
			alert('QQ账号登陆出错！', 0);
		}

		if(!$openId){
			alert('QQ账号登陆出错！', 0);
		}

		$aQQAccount = $qc->get_user_info();
		if($aQQAccount['ret'] == 0){
			$nickname = $aQQAccount['nickname'];
			$gender = 0;
			if($aQQAccount['gender'] == '男'){
				$gender = 1;
			}elseif($aQQAccount['gender'] == '女'){
				$gender = 2;
			}
			$qqAccountImg = $aQQAccount['figureurl_qq_2'] ? $aQQAccount['figureurl_qq_2'] : $aQQAccount['figureurl_qq_1'];
		}else{
			alert('获取QQ账号信息出错！', 0);
		}

		$oUser = m('User');
		$aUser = $oUser->getUserInfoByQqOpenId($openId);
		if($aUser === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		//判断是否已注册过了
		if(!$aUser){
			$qqOpenId = Cookie::get('qqOpenId');
			if(!$qqOpenId){
				Cookie::set('qqOpenId', $openId, time() + 15);
			}else{
				if($qqOpenId == $openId || $qqOpenId){
					$gotoUrl = url('m=Account&a=doQQAccountLogin&code=' . $code);
					assign('gotoUrl', $gotoUrl);
					display('account/wait_qq_login.html.php');
					exit;
				}
			}

			$userId = self::registerByQQ($openId, $aQQAccount);
			self::loginUser($userId);

			$code = Xxtea::encrypt($nickname);
			$gotoUrl = url('m=Account&a=showPerfectUserInformation&from=qq&code=' . $code);
			Cookie::delete('qqOpenId');
		}else{
			//登录
			if($aUser['is_forbidden'] == 1){
				alert('抱歉，您已经被禁用！', -1);
			}

			self::loginUser($aUser['id']);
			$gotoUrl = url('m=Index&a=index');
		}
		echo '<script type="text/javascript">location.href="' . $gotoUrl . '"</script>';
	}

	/**
	 * 绑定QQ账号
	 */
	public static function bindQQaccount(){
		$idStr = strtolower(post('email'));
		$password = post('password');
		$code = post('code');
		$code = Xxtea::decrypt($code);
		if(!$code){
			alert('系统出错，请稍后再试', 0);
		}
		$aCode = explode(',', $code);
		if(count($aCode) != 2){
			alert('系统出错，请稍后再试', 0);
		}
		$openId = $aCode[0];

		$isEmail = w('isEmail()', $idStr);
		$isNumber = w('isNumber(8)', $idStr);
		$isMobile = w('isPhone()', $idStr);
		if(!$isEmail && !$isNumber && !$isMobile){
			alert('请填写正确的账号', -1);
		}

		$vResult = v('password');
		if($vResult){
			alert($vResult, -1);
		}

		$oUser = m('User');
		$aUser = $oUser->getUserInfoByQqOpenId($openId);
		if($aUser === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		if($aUser){
			alert('绑定失败，此QQ已被系统其它账号绑定', 0);
		}

		if($isEmail){
			$aUserInfo = $oUser->getUserInfoByEmailAndPassword($idStr, $password);
		}else if($isNumber){
			$aUserInfo = $oUser->getUserInfoByNumberIdAndPassword($idStr, $password);
		}else if($isMobile){
			$aUserInfo = $oUser->getUserInfoByMobileAndPassword($idStr, $password);
		}

		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo){
			alert('账号或密码错误！', -1);
		}

		$aData = array(
			'id' => $aUserInfo['id'],
			'qq_open_id' => $openId
		);
		$isSetSuccess = $oUser->setUserIndexInfo($aData);
		if(!$isSetSuccess){
			alert('系统出错，请稍后再试', 0);
		}

		//登录
		if($aUserInfo['is_forbidden'] == 1){
			alert('抱歉，您已经被禁用！', -1);
		}
		self::_setLoginCookie($aUserInfo, 0);

		alert('绑定成功', 1);
	}

	/**
	 * 使用和教育账号登陆、注册
	 */
	public static function doXxtAccountLogin(){
		$isComputer = isComputer();
		//$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty($_POST['ajax']) || !empty($_GET['ajax']);
		$token = (string)get('token');
		if(!$token){
			$token = (string)get('Token');
			if(!$token){
				$token = (string)post('token');
				if(!$token){
					$token = (string)post('Token');
					if(!$token){
						alert('未收到和教育登陆token', 0, XXT_API_LOGIN_URL);
					}
				}
			}
		}

		//通过和教育接口获取和教育用户信息
		try{
			$aXxtUser = Xxt::getLoginInfo($token);

		}catch(XxtException $e){
			//display('notice.html.php');exit;
			$code = $e->getCode();
			if($code == 517){
				if(IS_DISPLAY_ERROR){
					alert(var_export($e->getData(), 1), 0);
				}else{
					alert('抱歉,服务器与和教育的连接失败,请稍后再试', 0);
				}
			}elseif($code == 627){
				halt($e->getMessage(), true);
			}

			alert('和教育登陆令牌无效，一般是因为超时或者您重复刷新登陆界面造成的哦', 0);
		}

		if($aXxtUser['RoleType'] == 1){
			//教师登陆
			$oTeacher = m('Teacher');
			$aTeacher = $oTeacher->getTeacherInfoByExtendCode($aXxtUser['UserId'], 2);
			if($aTeacher === false){
				halt('读取本地教师记录失败');
			}elseif($aTeacher){
				if(!$aTeacher['school_id']){
					$aData = array(
						'id'		=>	$aTeacher['id'],
						'school_id'	=>	$aXxtUser['SchoolId'],
						'city_id'	=>	$aXxtUser['CityId'],
					);
					$oTeacher->setTeacher($aData);
				}
				//登录账号
				$teacherId = $aTeacher['id'];
				self::_setLoginLog($teacherId, 3);

				//更新教师的班级学生信息 每隔一天更新一次
				if((time() - $aTeacher['check_time']) > 72000){
					$aClassInfo = self::_getXxtTeacherClassStudentInfo($aXxtUser);
					if(!$aClassInfo){
						$aClassInfo = self::_getXxtTeacherClassStudentInfo($aXxtUser);
						if(!$aClassInfo){
							alert('您好像还没有登记班级和学生', 0);
						}
					}
					$isUpdateSuccess = $oTeacher->saveTeacherRelations($teacherId, $aClassInfo);
					if(!$isUpdateSuccess){
						halt('保存师生关系失败', 0);
					}
				}
			}else{
				//注册账号
				if(!($aXxtUser['UserId'] > 0)){
					halt('该和教育老师没有UserId', false, $aXxtUser);
				}
				if(!isset($aXxtUser['UserId']) || !isset($aXxtUser['UserName']) || !($aXxtUser['UserId'] > 0) || !$aXxtUser['UserName']){
					halt('该和教育老师没有用户名', false, $aXxtUser);
				}
				$aData = array(
					'extend_type' => 2,
					'extend_code' => $aXxtUser['UserId'],
					'name' => $aXxtUser['UserName'],
					'create_time' => time(),
					'check_time' => 0,
					'city_id'	=>	$aXxtUser['CityId'],
					'school_id'	=>	$aXxtUser['SchoolId'],
				);
				$isAddSuccess = $oTeacher->addTeacher($aData);
				if($isAddSuccess === false){
					halt('添加老师失败');
				}
				$teacherId = $isAddSuccess;
				//保存教师的班级学生信息
				$aClassInfo = self::_getXxtTeacherClassStudentInfo($aXxtUser);
				if(!$aClassInfo){
					$aClassInfo = self::_getXxtTeacherClassStudentInfo($aXxtUser);
					if(!$aClassInfo){
						alert('您好像还没有登记班级和学生', 0);
					}
				}
				$isUpdateSuccess = $oTeacher->saveTeacherRelations($teacherId, $aClassInfo);
				if(!$isUpdateSuccess){
					halt('保存师生关系失败');
				}
			}
			Cookie::setEncrypt('teacherId', $teacherId, time() + 31536000);
			$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
			$autoLoginCode = md5($userAgent . $teacherId);
			if($autoLoginCode == 1){
				Cookie::setXcrypt('teacherAutoLogin', $autoLoginCode, time() + 31536000);
			}else{
				Cookie::setXcrypt('teacherAutoLogin', $autoLoginCode);
			}

			if($isComputer){
				header('location:' . url('m=Index&a=index', '', APP_TEACHER));
			}else{
				//alert('', 3, url('m=Index&a=index', '', APP_T_XXT));
				header('location:' . url('m=Index&a=index', '', APP_T_XXT));
			}
			exit;
		}elseif($aXxtUser['RoleType'] == 2){
			$oUser = m('User');
			$aUser = $oUser->getUserInfoByXxtId($aXxtUser['UserId']);
			if($aUser === false){
				halt('根据和教育ID获取用户信息失败');
			}

			if($aUser){
				//2015年2月1日检查数据状态确认是否删除该段代码 start
				$aUserInfo = getUserInfo($aUser['id'], array('personal'));

				if(!$aUserInfo['xxt_data']){
					$aData = array(
						'id' => $aUser['id'],
						'xxt_data' => $aXxtUser
					);
					$isSetSuccess = $oUser->setUserInfo($aData);
					if(!$isSetSuccess){
						halt('和教育用户再次登陆时更新xxt_data失败');
					}
				}
				//2015年2月1日检查数据状态确认是否删除该段代码 end


				//登录账号
				if($aUser['is_forbidden'] == 1){
					alert('抱歉，您已经被禁用！', -1);
				}
				self::loginUser($aUser['id']);
				self::loginFromXxt($aUser['id']);
				if($isComputer){
					header('location:' . url('m=Index&a=index', '', APP_HOME));
					exit;
				}
				header('location:' . url('m=Index&a=index', '', APP_XXT));
				exit;
			}else{
				//注册账号

				//获取和教育地市标识与UMFun地区ID对照列表
				$aUserCity = isset($GLOBALS['XXT_CITY'][$aXxtUser['CityId']]) ? $GLOBALS['XXT_CITY'][$aXxtUser['CityId']] : null;
				if(!(isset($aXxtUser['CityId']) && $aXxtUser['CityId'] && $aUserCity)){
					halt('该和教育用户的CityId不存在或未登记', false, $aXxtUser);
				}

				self::registerByXXT($aXxtUser['UserId'], $aXxtUser);
				//获取用户的个人信息
				$aUser = $oUser->getUserInfoByXxtId($aXxtUser['UserId']);
				if($aUser){
					self::loginUser($aUser['id']);
					self::loginFromXxt($aUser['id']);
				}else{
					halt('和教育用户注册流程出错了', true, $aXxtUser);
				}

				//记录注册后第一次进入首页
				Cookie::setEncrypt('isRegisterComplete', 1, time() + 31536000);

				if($isComputer){
					header('location:' . url('m=Index&a=index', 'r=1', APP_HOME));
					exit;
				}
				header('location:' . url('m=Index&a=index', 'r=1', APP_XXT));
				exit;
			}
		}elseif($aXxtUser['RoleType'] == 3){
			$oParent = m('Parent');
			$aParent = $oParent->getParentInfoByExtendCode($aXxtUser['UserId'], 2);
			if($aParent === false){
				halt('根据和教育ID获取家长信息失败');
			}elseif($aParent){
				//登录账号
				$parentId = $aParent['id'];
				$aData = array(
					'id' => $aParent['id'],
					'xxt_data' => $aXxtUser
				);
				if(!$aParent['city_id']){
					$aData['city_id'] = $aXxtUser['CityId'];
				}
				if(!$aParent['name']){
					$aData['name'] = $aXxtUser['UserName'];
				}
				if(!$aParent['city_id'] || !$aParent['name'] || !$aParent['xxt_data']){
					$isSetSuccess = $oParent->setParentInfo($aData, array('id' => $aParent['id']));
					if(!$isSetSuccess){
						halt('更新家长信息出错', false, $aData);
					}
				}
				self::_setLoginLog($parentId, 2);
				//检查关联孩子账号
				if(!$aParent['user_ids']){
					if(!isset($aXxtUser['CityId']) || !isset($aXxtUser['UserId']) || !$aXxtUser['CityId'] || !($aXxtUser['UserId'] > 0)){
						halt('该和教育用户ID或地区ID有误');
					}

					try{
						$aReasult = Xxt::getParentInfo($aXxtUser['CityId'], $aXxtUser['UserId']);
					}catch(XxtException $e){
						halt('获取和教育家长信息失败！', true, $e->getData());
					}

					$aXxtParent = $aReasult;
					if(isset($aXxtParent['StuUserId']) && $aXxtParent['StuUserId']){
						$oUser = m('User');
						$aChildUser = $oUser->getUserInfoByXxtId($aXxtParent['StuUserId']);
						if($aChildUser === false){
							halt('根据和教育ID获取学生信息失败');
						}
						if($aChildUser){
							$childId = $aChildUser['id'];
							$aData = array(
								'id' => $aParent['id'],
								'user_ids' => $childId
							);
							$isSetSuccess = $oParent->setParentInfo($aData, array('id' => $aParent['id']));
							if(!$isSetSuccess){
								halt('更新家长信息失败');
							}
						}
					}
				}
			}else{
				//注册账号
				if(!isset($aXxtUser['CityId']) || !isset($aXxtUser['UserId']) || !$aXxtUser['CityId'] || !($aXxtUser['UserId'] > 0)){
					halt('该和教育用户ID或地区ID有误');
				}

				try{
					$aReasult = Xxt::getParentInfo($aXxtUser['CityId'], $aXxtUser['UserId']);
				}catch(XxtException $e){
					halt('获取和教育家长信息失败', false, array(
						'param' => $aXxtUser,
						'result' => $e->getData()
					));
				}

				$aXxtParent = $aReasult;
				$childId = '';
				if(isset($aXxtParent['StuUserId'])){
					$oUser = m('User');
					$aChildUser = $oUser->getUserInfoByXxtId($aXxtParent['StuUserId']);
					if($aChildUser === false){
						halt('根据和教育ID获取学生信息失败', false, $aXxtParent);
					}
					if($aChildUser){
						$childId = $aChildUser['id'];
					}
				}

				$aData = array(
					'extend_type' => 2,
					'extend_code' => $aXxtUser['UserId'],
					'user_ids' => $childId,
					'password' => '',
					'city_id' => $aXxtUser['CityId'],
					'name' => $aXxtUser['UserName'],
					'xxt_data' => $aXxtUser,
					'create_time' => time(),
				);
				$aParent = $oParent->getParentInfoByExtendCode($aXxtUser['UserId'], 2);
				if($aParent === false){
					halt('根据和教育ID获取家长信息失败', false, $aXxtUser);
				}elseif($aParent){
					//登录账号
					$parentId = $aParent['id'];
				}else{
					$isAddSuccess = $oParent->addParentInfo($aData);
					if($isAddSuccess === false){
						halt('添加家长失败', false, $aData);
					}
					$parentId = $isAddSuccess;
				}

			}
			Cookie::setEncrypt('parentId', $parentId, time() + 31536000);
			$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
			$autoLoginCode = md5($userAgent . $parentId);
			if($autoLoginCode == 1){
				Cookie::setXcrypt('parentAutoLogin', $autoLoginCode, time() + 31536000);
			}else{
				Cookie::setXcrypt('parentAutoLogin', $autoLoginCode);
			}

			if($isComputer){
				header('location:' . url('m=Index&a=index', '', APP_PARENT));
			}else{
				header('location:' . url('m=Index&a=index', '', APP_P_XXT));
			}
			exit;
		}

	}

	/**
	 * 和教育家长帮孩子开通账号
	 * 表单参数: cs
	 */
	public static function doXxtAccountRegister(){

		$cs = post('cs');
		if(!$cs){
			alert('错误的家长信息', 0);
		}
		$csStr = Xxtea::decrypt($cs);
		$aCs = explode(',', $csStr);
		if(count($aCs) != 2){
			alert('错误的家长信息', 0);
		}
		$xxtParentId = intval($aCs[0]);
		$xxtCityId = $aCs[1];

		try{
			$aReasult = Xxt::getParentInfo($xxtCityId, $xxtParentId);
		}catch(XxtException $e){
			halt($e->getMessage() . '获取和教育家长信息失败！', true);
		}
		$aXxtParentInfo = $aReasult;

		//注册学生账号
		if($aXxtParentInfo){
			if(isset($aXxtParentInfo['StuUserId']) && $aXxtParentInfo['StuUserId']){
				$oUser = m('User');
				$aChildUser = $oUser->getUserInfoByXxtId($aXxtParentInfo['StuUserId']);
				if($aChildUser){
					halt('进入了重复注册流程', false, $aXxtParentInfo);
				}else{

					self::registerByXXT($aXxtParentInfo['StuUserId'], array('UserId' => $aXxtParentInfo['StuUserId'], 'CityId' => $xxtCityId, 'RoleType' => 2));
				}
				//注册家长账号
				$oParent = m('Parent');
				$aParent = $oParent->getParentInfoByExtendCode($xxtParentId, 2);
				if(!$aParent){
					alert('网络可能有点慢，请稍后再试', 0);
				}
				/*if($aParent){
					alert('网络可能有点慢，请稍后再试4', 0);
				}else{
					//注册账号
					$childId = '';
					$childName = '';
					if(isset($aXxtParentInfo['StuUserId'])){
						$oUser = m('User');
						$aChildUser = $oUser->getUserInfoByXxtId($aXxtParentInfo['StuUserId']);
						if($aChildUser === false){
							alert('网络可能有点慢，请稍后再试5', 0);
						}
						if($aChildUser){
							$childId = $aChildUser['id'];
						}else{
							alert('网络可能有点慢，请稍后再试6', 0);
						}
					}else{
						alert('抱歉！在和教育里找不到您的孩子信息', 0);
					}
					$aData = array(
						'extend_type' => 2,
						'extend_code' => $xxtParentId,
						'user_ids' => $childId,
						'password' => '',
						'create_time' => time(),
					);
					$aParent = $oParent->getParentInfoByExtendCode($xxtParentId, 2);
					if($aParent === false){
						alert('网络可能有点慢，请稍后再试7', 0);
					}elseif($aParent){
						//登录账号
						$parentId = $aParent['id'];
					}else{
						$isAddSuccess = $oParent->addParentInfo($aData);
						if($isAddSuccess === false){
							alert('网络可能有点慢，请稍后再试8', 0);
						}
						$parentId = $isAddSuccess;
					}

				}*/

				$parentId = $aParent['id'];
				Cookie::setEncrypt('id', $parentId, time() + 31536000);
				$userAgent = $_SERVER['HTTP_USER_AGENT'];
				$autoLoginCode = md5($userAgent . $parentId);
				if($autoLoginCode == 1){
					Cookie::setXcrypt('parentAutoLogin', $autoLoginCode, time() + 31536000);
				}else{
					Cookie::setXcrypt('parentAutoLogin', $autoLoginCode);
				}
				$isComputer = isComputer();
				if($isComputer){
					alert('账号开通成功！', 1, url('m=Index&a=index', '', APP_PARENT));
				}else{
					alert('账号开通成功！', 1, url('m=Index&a=index', '', APP_P_XXT));
				}
				exit;
			}else{
				alert('抱歉！在和教育里找不到您的孩子信息', 0);
			}
		}else{
			alert('获取和教育数据出错！', 0);
		}
	}

	/**
	 * 标记一个学生用户的登陆是来自家长的
	 * @param type $userId
	 * @return type
	 */
	public static function loginFromParent($userId){
		$aLoginInfo = self::getUserLoginInfo($userId);
		if(!$aLoginInfo){
			halt('获取用户登陆信息失败');
		}
		$aParent = isParentLogin();
		if(!$aParent){
			halt('获取家长登陆信息失败');
		}
		$aLoginInfo['parent'] = $aParent['id'];
		self::setUserLoginInfo($userId, $aLoginInfo, 0);
		return $aParent['id'];
	}

	public static function logoutUser($userId){
		$aLoginInfo = User::getUserLoginInfo($userId);
		if($aLoginInfo && $aLoginInfo['ip'] == getClientIP()){
			User::deleteUserLoginInfo($userId);
		}

		Cookie::delete('autoLogin');
		Cookie::delete('userId');
		Cookie::delete('loginToken');
		Cookie::delete('lastActiveTime' . $userId);
		return true;
	}

	public static function loginUser($userId){
		$oUser = m('User');

		$aUser = $oUser->getUserInfoByUserId($userId);

		if($aUser === false){
			return false;
		}

		self::_setLoginCookie($aUser, 0);
		return true;
	}

	public static function registerByEamil($email, $password, $eightNumInviteCode = 0){
		$oUser = m('User');

		$result1 = $oUser->isEmailExist($email);
		if($result1){
			alert('抱歉，该邮箱已经存在了', 0);
		}

		$aData = array(
			'email' => $email,
			'password' => $password,
			'create_time' => time(),
			'is_forbidden' => 0
		);

		if($eightNumInviteCode){
			$aData['Lottery_draw_status'] = 0;
		}else{
			$aData['Lottery_draw_status'] = 1;//没资格抽奖
		}

		$aData = self::_getRegisterNumberAccount($aData, $eightNumInviteCode);
		self::_addRegisterUserNumerical($aData['id']);

		return $aData['id'];
	}

	public static function registerByTel($telephoneNumber, $password, $eightNumInviteCode = 0){
		$oUser = m('User');

		$result1 = $oUser->isMobileExist($telephoneNumber);
		if($result1){
			alert('抱歉，该手机已经存在了', 0);
		}

		$aData = array(
			'mobile' => $telephoneNumber,
			'password' => $password,
			'create_time' => time(),
			'is_forbidden' => 0
		);

		if($eightNumInviteCode){
			$aData['Lottery_draw_status'] = 0;
		}else{
			$aData['Lottery_draw_status'] = 1;//没资格抽奖
		}

		$aData = self::_getRegisterNumberAccount($aData, $eightNumInviteCode);
		self::_addRegisterUserNumerical($aData['id']);

		return $aData['id'];
	}

	public static function registerByQQ($openId, $aQQAccount){
		$nickname = $aQQAccount['nickname'];
		$gender = 0;
		if($aQQAccount['gender'] == '男'){
			$gender = 1;
		}elseif($aQQAccount['gender'] == '女'){
			$gender = 2;
		}
		$qqAccountImg = $aQQAccount['figureurl_qq_2'] ? $aQQAccount['figureurl_qq_2'] : $aQQAccount['figureurl_qq_1'];

		//注册
		$aData = array(
			'email' => '',
			'mobile' => 0,
			'password' => '',
			'create_time' => time(),
			'is_forbidden' => 0,
			'Lottery_draw_status' => 1,
			'qq_open_id' => $openId
		);

		$aData = self::_getRegisterNumberAccount($aData, 0);
		self::_addRegisterUserNumerical($aData['id']);

		//保存QQ头像
		$twoNumberId = substr($aData['id'], -2) . '/';
		if(!file_exists(SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId)){
			mkdir(SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId);
		}
		$rand = rand(1000, 9999);
		$profilePath = SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId . $rand . $aData['id'] . '.jpg';
		$profile = USER_PROFILE_PATH . $twoNumberId . $rand . $aData['id'] . '.jpg';
		@file_put_contents($profilePath, @file_get_contents($qqAccountImg));

		$aPersonal = array(
			'id' => $aData['id'],
			'profile' => $profile,
			'gender' => $gender
		);

		$aBaseInfo = array('personal' => $aPersonal);

		self::perfectInformation($aBaseInfo);

		return $aData['id'];
	}

	public static function registerByXXT($xxtUserId, $aXXTData){
		$aXxtStudentRegisterBaseInfo = self::buildXxtStudentRegisterBaseInfo($xxtUserId, $aXXTData['CityId']);
		if(isset($aXXTData['LoginName'])){
			if(isset($aXxtStudentRegisterBaseInfo['personal']) && is_array($aXxtStudentRegisterBaseInfo['personal'])){
				$aXxtStudentRegisterBaseInfo['personal']['xxt_data'] = $aXXTData;
			}

		}

		self::perfectInformation($aXxtStudentRegisterBaseInfo);
		self::autoBecomeFriend($aXxtStudentRegisterBaseInfo['class']);
		self::sendXxtWeibo($aXxtStudentRegisterBaseInfo, $aXXTData);
		if($aXxtStudentRegisterBaseInfo['personal']['id']){
			return $aXxtStudentRegisterBaseInfo['personal']['id'];
		}else{
			myLog($aXxtStudentRegisterBaseInfo);
			return 0;
		}
	}

	//自动加好友
	public static function autoBecomeFriend($aUserClassInfo){
		//先查询用户那个学校 年级 班级
		$aUserClassCondition = array();
		$aUserClassCondition['year'] = $aUserClassInfo['year'];
		$aUserClassCondition['city_id'] = $aUserClassInfo['city_id'];
		$aUserClassCondition['is_active'] = $aUserClassInfo['is_active'];
		$aUserClassCondition['grade'] = $aUserClassInfo['grade'];
		$aUserClassCondition['school_id'] = $aUserClassInfo['school_id'];
		$aUserClassCondition['class'] = $aUserClassInfo['class'];

		//获取某个用户里面班的所有信息
		$oUser = m('User');
		$aClassList = $oUser->getClassListByCondition($aUserClassCondition);
		if($aClassList === false){
			myLog('网络可能有点慢');
		}elseif(!$aClassList){
			return;
		}

		//获取某个用户里面班的所有 ID
		$aClassUserIds = array();
		foreach ($aClassList as $key => $value){
			$aClassUserIds[] = $value['user_id'];
		}
		$oSns = m('Sns');
		$autoAddClassFriends = $oSns->autoBecomeFriendWithUsers($aUserClassInfo['user_id'], $aClassUserIds);
		if(!$autoAddClassFriends){
			myLog('加好友失败，用户ID为：' . $aUserClassInfo['user_id'] . ' 好友id集合：' . implode(',', $aClassUserIds));
		}
	}

	//发送一条微博班圈
	public static function sendXxtWeibo($aXxtStudentRegisterBaseInfo, $aXxtClassInfo){
		$xxtClassId = $aXxtStudentRegisterBaseInfo['class_id'];
		$aWeiboParams = array();
		$aWeiboParams['city_id'] = $aXxtClassInfo['CityId'];
		$aWeiboParams['user_id'] = $aXxtClassInfo['UserId'];
		$aWeiboParams['role_type'] = $aXxtClassInfo['RoleType'];
		$aWeiboParams['school_id'] = $aXxtStudentRegisterBaseInfo['SchoolId'];
		$aWeiboParams['class_id'] = $xxtClassId;
		$aWeiboParams['content'] = '点了优满分就不能自拔了，同学们慎重点啊，好了我要继续玩了!';
		$aWeiboParams['from_sys'] = 9;
		$aWeiboParams['msg_type'] = 2;
		$aWeiboParams['has_attachment'] = 0;
		$result = false;
		try{
			$result = Xxt::addWeibo($aWeiboParams);
		}catch(XxtException $e){
			$e->log();
		}
	}

	public static function buildXxtStudentRegisterBaseInfo($xxtId, $xxtCityId){
		try{
			$aReasult = Xxt::getStudentInfo($xxtId, $xxtCityId);
		}catch(XxtException $e){
			halt($e->getMessage(), true, $e->getData());
		}

		$aXxtUserDetail = $aReasult;
		if($aXxtUserDetail){
			//注册学生账号
			$aPersonal = array();
			if(isset($GLOBALS['XXT_CITY'][$xxtCityId])){
				//获取地区
				$aPersonal['area_id'] = $GLOBALS['XXT_CITY'][$xxtCityId]['area_id'];
			}else{
				alert('获取和教育地区数据出错！', 0);
			}

			if($aXxtUserDetail){
				//获取班级ID
				$classId = 0;
				if(isset($aXxtUserDetail['StudentEntity']['ClassId'])){
					$classId = $aXxtUserDetail['StudentEntity']['ClassId'];
				}else{
					myLog('抱歉，在和教育没找到您对应的班级信息，不能正常使用优满分！' . PHP_EOL . var_export($aXxtUserDetail, 1));
					alert('抱歉，在和教育没找到您对应的班级信息，不能正常使用优满分！', 0);
				}
				//查询和教育班级信息
				try{
					$aReasult = Xxt::getClassInfo($classId);
				}catch(XxtException $e){
					halt($e->getMessage() . '抱歉，在和教育没找到您对应的班级信息，不能正常使用优满分！', true);
				}
				$aXxtClassInfo = $aReasult;
				if(!isset($aXxtClassInfo['SchoolId']) || !($aXxtClassInfo['SchoolId'] > 0)){
					myLog('该家长的孩子学校ID异常' . PHP_EOL . var_export($aXxtClassInfo, 1));
					alert('学校ID有误！', 0);
				}
				//查询和教育学校信息
				try{
					$aReasult = Xxt::getSchoolInfo($aXxtClassInfo['SchoolId']);
				}catch(XxtException $e){
					halt($e->getMessage() . '获取孩子的学校信息失败！', true);
				}
				$aXxtSchoolInfo = $aReasult;
			}else{
				alert('获取和教育数据出错！', 0);
			}

			//1.获取数字账号ID和保存邮箱信息
			if(!isset($aXxtUserDetail['StudentEntity']['StudentId']) || !($aXxtUserDetail['StudentEntity']['StudentId'] > 0)){
				myLog('该家长的孩子用户ID有误' . PHP_EOL . var_export($aXxtUserDetail, 1));
				alert('用户ID有误！', 0);
			}

			$oUser = m('User');
			$aUser = $oUser->getUserInfoByXxtId($aXxtUserDetail['StudentEntity']['StudentId']);
			if($aUser === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			if($aUser){
				myLog('进入了重复注册流程');
				alert('系统出错', 0);
			}

			$aData = array(
				'email' => isset($aXxtUserDetail['StudentEntity']['EMail']) && w('isEmail()', $aXxtUserDetail['StudentEntity']['EMail']) ? $aXxtUserDetail['StudentEntity']['EMail'] : '',
				'mobile' => 0,
				'password' => '',
				'create_time' => time(),
				'is_forbidden' => 0,
				'Lottery_draw_status' => 1,
				'xxt_type' => 2,
				'xxt_id' => $aXxtUserDetail['StudentEntity']['StudentId']
			);

			$aData = self::_getRegisterNumberAccount($aData, 0);
			self::_addRegisterUserNumerical($aData['id']);

			//设置VIP3一个月
			$aNumericalData = array(
				'id' => $aData['id'],
				'vip' => 3,
				'vip_expiration_time' => time() + 60 * 60 * 24 * 30
			);

			//2.保存姓名、性别、头像和地区信息
			$aPersonal['id'] = $aData['id'];
			$aXxtUserDetail['StudentEntity']['HeadImage'] = '';
			//保存头像
			if(isset($aXxtUserDetail['StudentEntity']['HeadImage']) && $aXxtUserDetail['StudentEntity']['HeadImage']){
				$twoNumberId = substr($aData['id'], -2) . '/';
				if(!file_exists(SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId)){
					mkdir(SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId);
				}
				$rand = rand(1000, 9999);
				$profilePath = SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId . $rand . $aData['id'] . '.jpg';
				$profile = USER_PROFILE_PATH . $twoNumberId . $rand . $aData['id'] . '.jpg';
				$imageUrl = '';
				$aPathUrl = parse_url($aXxtUserDetail['StudentEntity']['HeadImage']);
				if(isset($aPathUrl['host']) && $aPathUrl['host']){
					$imageUrl = $aXxtUserDetail['StudentEntity']['HeadImage'];
				}else{
					$imageUrl = XXT_IMG_DOMAIN . $aXxtUserDetail['StudentEntity']['HeadImage'];
				}
				@file_put_contents($profilePath, @file_get_contents($imageUrl));
				$aPersonal['profile'] = $profile;
			}

			//获取性别
			$gender = 0;
			if(isset($aXxtUserDetail['StudentEntity']['Sex']) && $aXxtUserDetail['StudentEntity']['Sex']){
				if($aXxtUserDetail['StudentEntity']['Sex'] == '男'){
					$gender = 1;
				}elseif($aXxtUserDetail['StudentEntity']['Sex'] == '女'){
					$gender = 2;
				}
			}
			$aPersonal['gender'] = $gender;
			if(isset($aXxtUserDetail['StudentEntity']['UserName']) && $aXxtUserDetail['StudentEntity']['UserName']){
				$aPersonal['name'] = $aXxtUserDetail['StudentEntity']['UserName'];
			}elseif(isset($aXxtUserDetail['StudentEntity']['UserName']) && $aXxtUserDetail['StudentEntity']['UserName']){
				$aPersonal['name'] = $aXxtUserDetail['StudentEntity']['UserName'];
			}else{
				myLog('该家长的孩子姓名有误' . PHP_EOL . var_export($aXxtUserDetail['StudentEntity'], 1));
				alert('缺少孩子姓名！', 0);
			}
			//$aPersonal['xxt_data'] = $aXxtUserDetail['StudentEntity'];

			$oStyle = m('Style');
			$aStyle = $oStyle->getDefaultStyleInfo();
			if($aStyle === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			if($aStyle){
				$aPersonal['style_id'] = $aStyle['id'];
			}

			if(!isset($aXxtSchoolInfo['SchoolName']) || !$aXxtSchoolInfo['SchoolName']){
				myLog('该家长孩子的学校名称有误' . PHP_EOL . var_export($aXxtSchoolInfo, 1));
				alert('抱歉，您孩子的学校名称异常！', 0);
			}

			$oUser = m('User');
			//判断学校是否存在
			$aSchool = $oUser->getSchoolInfoByAreaIdAndSchoolName($GLOBALS['XXT_CITY'][$xxtCityId]['city_id'], $aXxtSchoolInfo['SchoolName'], 1);
			if($aSchool === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			if($aXxtClassInfo['Bank'] < 1 || $aXxtClassInfo['Bank'] > 9){
				$grade = $aXxtClassInfo['Bank'] < 1 ? 1 : 9;
				if(!$aSchool){
					$aSchoolList = $oUser->getSchoolListByAreaId($GLOBALS['XXT_CITY'][$xxtCityId]['area_id']);
					if($aSchoolList === false){
						alert('网络可能有点慢,请稍后再试!', 0);
					}elseif($aSchoolList){
						$aSchool = $aSchoolList[0];
					}
				}
				$aXxtClassInfo['ClassName'] = '1班';
			}else{
				$grade = $aXxtClassInfo['Bank'];
			}

			if($aSchool){
				$schoolId = $aSchool['id'];
				$schoolAreaId = $aSchool['area_id'];
			}else{
				$aSchoolData = array(
					'area_id' => $GLOBALS['XXT_CITY'][$xxtCityId]['area_id'],
					'name' => $aXxtSchoolInfo['SchoolName']
				);
				$schoolId = $oUser->addSchool($aSchoolData);
				if($schoolId === false){
					alert('网络可能有点慢，请稍后再试', 0);
				}
				$schoolAreaId = $aSchoolData['area_id'];
			}

			$aPersonal['area_id'] = $schoolAreaId;

			$aClassData = array(
				'user_id' => $aData['id'],
				'year' => date('Y', time()),
				'province_id' => $GLOBALS['XXT_CITY'][$xxtCityId]['province_id'],
				'city_id' => $GLOBALS['XXT_CITY'][$xxtCityId]['city_id'],
				'area_id' => $schoolAreaId,
				'is_active' => 1,
				'grade' => $grade,
				'school_id' => $schoolId,
				'class' => $aXxtClassInfo['ClassName']

			);

			return array(
				'personal' => $aPersonal,
				'class' => $aClassData,
				'numerical' => $aNumericalData,
				'class_id' => $classId,
				'SchoolId'	=>	$aXxtSchoolInfo['SchoolId'],
			);
		}else{
			alert('抱歉！在和教育里找不到学生信息', 0);
		}
	}

	public static function perfectInformation($aDataInfo){
		if(!$aDataInfo){
			alert('抱歉！完善用户信息失败', 0);
		}

		$oUser = m('User');
		if(isset($aDataInfo['user']['xxt_id']) && $aDataInfo['user']['xxt_id']){
			$aUser = $oUser->getUserInfoByXxtId($aDataInfo['user']['xxt_id']);
			if($aUser){
				myLog('和教育用户登陆的时候进入了注册流程了,uid:' . $aDataInfo['user']['xxt_id']);
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}

		if(isset($aDataInfo['numerical']) && $aDataInfo['numerical']){
			$oUserNumerical = m('UserNumerical');

			$setResult = $oUserNumerical->setUserNumerical($aDataInfo['numerical']);
			if($setResult === false){
				alert('系统出错，请稍后再试', 0);
			}
		}

		if(isset($aDataInfo['personal']) && $aDataInfo['personal']){
			$isSetSuccess = $oUser->setUserInfo($aDataInfo['personal']);
			if($isSetSuccess === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}

		if(isset($aDataInfo['class']) && $aDataInfo['class']){
			$isAddSuccess = $oUser->addClass($aDataInfo['class']);
			if($isAddSuccess === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}

	}

	/**
	 * 向手机发送短信
	 * 表单参数: mobile, type, captcha(可选)
	 */
	public static function sendMobileMessage(){
		$mobile = post('mobile');
		$sendType = intval(post('type'));
		$captcha = post('captcha');
		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}

		if($captcha){
			$isCaptcha = w('length(5, 5)', $captcha);
			if(!$isCaptcha){
				alert('验证码格式不正确', -1);
			}
			if(!Verify::match('captcha', $captcha)){
				alert('验证码错误！', -1);
			}
		}
		//验证手机号是否存在
		$oUser = m('User');
		$isMobileExist = $oUser->isMobileExist($mobile);
		if($sendType == 1){
			if($isMobileExist){
				alert('抱歉，系统已绑定此手机账号！', -1);
			}
		}elseif($sendType == 2){
			if(!$isMobileExist){
				alert('抱歉，系统找不到此手机账号！', -1);
			}
		}
		$nextVerify =  Xxtea::xcrypt('nextVerify');
		//验证发送验证码时间超过一分钟没
		if(Cookie::isSetted($nextVerify)){
			$nextTime = Cookie::getDecrypt($nextVerify);
			if(time() < $nextTime){
				alert('请稍后再试', 0);
			}
		}
		//取得6位数的手机验证码
		$time = str_replace('.', '', microtime(true));
		$start = rand(0, strlen($time) - 6);
		$code = substr($time, $start, 6);

		if($sendType == 1){
			$msgText = urlencode('您好，您在优满分系统申请绑定手机，您的验证码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作 【优满分】');
		}elseif($sendType == 2){
			$msgText = urlencode('您好，您在优满分系统通过手机找回密码，您的验证码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作 【优满分】');
		}elseif($sendType == 3){
			$msgText = urlencode('您好，优满分系统通过手机验证身份的真实性，您的验证码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作 【优满分】');
		}
		$url = 'http://utf8.sms.webchinese.cn/?Uid=' . SEND_MESSAGE_USER . '&Key=' . SEND_MESSAGE_KEY . '&smsMob=' . $mobile . '&smsText=' . $msgText;
		$returnStatus = 0;
		if(function_exists('file_get_contents')){
			$returnStatus = file_get_contents($url);
		}else{
			$returnStatus = sendMobileMessage($mobile, $msgText);
		}

		if($returnStatus > 0){
			//下次发送时间　60秒以后
			Cookie::setEncrypt($nextVerify , time() + 60);

			$cookieName = Xxtea::xcrypt($mobile);
			$endTime = time() + 600;
			Cookie::setEncrypt($cookieName, $code . '|' . $endTime);
		}
		alert('短信已发送，请及时查看手机短信以便完成操作！', 1);
	}

	/**
	 * 验证手机校验码
	 * 表单参数: mobile, mobileCode, captcha(可选)
	 */
	public static function verifyMobileMessage(){
		$mobile = post('mobile');
		$mobileCode = post('mobileCode');
		$captcha = post('captcha');

		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}
		$isMobileCode = w('isNumber(6)', $mobileCode);
		if(!$isMobileCode){
			alert('手机校验码格式不正确', -1);
		}
		if($captcha){
			$isCaptcha = w('length(5, 5)', $captcha);
			if(!$isCaptcha){
				alert('验证码格式不正确', -1);
			}
			if(!Verify::match('captcha', $captcha)){
				alert('验证码错误！', -1);
			}
		}
		//验证码不存在
		$cookieName = Xxtea::xcrypt($mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('手机校验码错误', -1);
		}

		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('手机校验码错误', -1);
		}

		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('手机校验码错误', -1);
		}

		if($mobileCode != $verifyArray[0]){
			alert('手机校验码错误', -1);
		}

		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}

		$nowTime = time();
		$endTime = $nowTime + 900;
		$encodeStr = Xxtea::encrypt($nowTime . $mobile . $endTime);

		alert('验证成功！', 1, $encodeStr);
	}

	/**
	 * 根据地区id获取学校信息
	 * 表单参数：areaId
	 */
	public static function getSchoolListByAreaId(){
		$oUser = m('User');
		$areaId = post('areaId');
		$isAreaId = w('range(110101, 659004)', $areaId);
		if(!$isAreaId){
			alert('无效的地区ID', -1);
		}
		$aSchoolList = $oUser->getSchoolListByAreaId($areaId);
		if($aSchoolList === false){
			alert('网络可能有点慢,请稍后再试!', 0);
		}elseif($aSchoolList){
			alert('获取成功', 1, $aSchoolList);
		}
	}

	/**
	 * 获取班级信息
	 * 表单参数：schoolId
	 */
	public static function getClassListBySchoolId(){
		$schoolId = (int)post('schoolId');
		if($schoolId < 1){
			alert('无效的学校ID', -1);
		}

		$oUser = m('User');
		$aClassList = $oUser->getClassListBySchoolId($schoolId);
		if($aClassList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else{
			alert('学校班级列表', 1, $aClassList);
		}
	}

	/**
	 * 保存用户姓名、地区和学校信息处理
	 * 表单参数：trueName_register, provinceId_register, cityId_register, areaId_register, schoolId_register, gradeId_register, className_register
	 */
	public static function saveUserInformation(){
		$aUser = checkUserLogin(1);
		$userId = $aUser['id'];

		$vResult = v('trueName_register,provinceId_register,cityId_register,areaId_register,schoolId_register,gradeId_register,className_register');

		if($vResult){
			alert($vResult, -1);
		}
		$oUser = m('User');
		//验证有没有这个地区代码
		$areaId = post('areaId_register');
		$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
		if($aAreaInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aAreaInfo){
			alert('非法的地区', -1);
		}

		//先添加学校信息   createRegisterInfo
		self::_schoolInfoHandle($userId);


		//计算默认的皮肤ID
		$oStyle = m('Style');
		$aStyleList = $oStyle->getStyleList();
		$defaultStyleId = 0;
		foreach($aStyleList as $aStyle){
			if($aStyle['is_default']){
				$defaultStyleId = $aStyle['id'];
			}
		}

		$row = $oUser->setUserInfo(array(
			'id' 		=> $userId,
			'name'		=> post('trueName_register'),
			'area_id'	=> $areaId,
			'accept_pk_count' => 1,
			'style_id' => $defaultStyleId,
		));

		if(!$row){
			alert('抱歉,更新用户资料失败', 0);
		}

		self::_updateRegisterUserProbablyFriends($userId);	//更新用户可能认识的好友
		//增加个人信息
		if($row){
			alert('资料保存成功!', 1);
		}else{
			alert('完善资料失败!', 0);
		}
	}

	/**
	 * 获取用户信息
	 * 表单参数：userId（可选，默认为当前登陆用户）
	 */
	public static function getUserInfo(){
		$aUser = checkUserLogin();
		$curUserId = $aUser['id'];
		$userId = intval(post('user_id', $curUserId));
		if($userId == 0){
			$userId = $curUserId;
		}
		if(!$userId){
			alert('用户ID不能为空', 0);
		}
		$aUserInfo = getUserInfo($userId, array('area', 'personal'));
		$oUser = m('User');
		$aUser = $oUser->getUserDetailInfoByUserId($userId);
		if(!$aUser){
			alert('找不到用户信息', 0);
		}
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($userId);
		if($aUserNumerical === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aUser = array_merge($aUser, $aUserNumerical);
		$aUser = array_merge($aUser, $aUserInfo);
		$aUser['age'] = $aUser['birth_date'] ? date('Y') - date('Y', $aUser['birth_date']) : '0';
		$aBirthDay = explode('-', date('Y-m-d', $aUser['birth_date']));
		$constellation = self::_getConstellation($aBirthDay[1], $aBirthDay[2]);
		$aUser['constellation'] = $constellation;
		$aUser['is_friend'] = 2;
		if($userId != $curUserId){
			$aFriendIds = getUserFriendIds($curUserId);
			if(in_array($userId, $aFriendIds) || in_array($userId, $GLOBALS['PUBLIC_USER_IDS']) || in_array($curUserId, $GLOBALS['PUBLIC_USER_IDS'])){
				$aUser['is_friend'] = 1;
			}else{
				$aUser['is_friend'] = 0;
			}
			unset($aUser['mobile']);
		}
		$aUserApproveInfo = $oUser->getUserApproveInfo($userId);
		if($aUserApproveInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		if($aUserApproveInfo){
			if($aUserApproveInfo['approve_finish'] == 0){
				$aUser['hasApproveInfo'] = 1;
				if(isset($aUserApproveInfo['content']['name'])){
					$aUser['approveUserName'] = $aUserApproveInfo['content']['name']['content'];
				}else{
					$aUser['approveUserName'] = '';
				}
				if(isset($aUserApproveInfo['content']['profile'])){
					$aUser['approveProfile'] = $aUserApproveInfo['content']['profile']['content'];
				}else{
					$aUser['approveProfile'] = '';
				}
			}else{
				$aUser['hasApproveInfo'] = 0;
			}
		}else{
			$aUser['hasApproveInfo'] = 0;
		}
		$aUserPersonal = $oUser->getPersonalInfoByUserId($userId);
		if(!$aUserPersonal){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}else{
			$aUser['is_email_active'] = $aUserPersonal['is_email_active'];
		}

		unset($aUser['password']);
		unset($aUser['proxy_id']);
		unset($aUser['is_forbidden']);
		unset($aUser['lottery_draw_status']);
		unset($aUser['lottery_draw_time']);
		unset($aUser['accept_pk_count']);
		unset($aUser['ub']);
		unset($aUser['gold']);
		//unset($aUser['accumulate_points']);
		//unset($aUser['vip']);
		unset($aUser['birth_day']);
		alert('用户信息', 1, $aUser);
	}

	/**
	 * 修改用户信息处理
	 * (可选)表单参数：username, mobile, signature, detailedPlace, areaId, gender, year, month, day
	 */
	public static function editUserInformation(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];

		$oUser = m('User');
		$aData = array();
		if(post('signature')){
			$vResult = v('signature');
			if($vResult){
				alert($vResult, 0);
			}
		}
		$aData['signature'] = post('signature');
		if(post('username')){
			$vResult = v('username');
			if($vResult){
				alert($vResult, 0);
			}
		}
		if(post('mobile')){
			$vResult = v('mobile');
			if($vResult){
				alert($vResult, 0);
			}
		}
		$aData['call_phone'] = post('mobile');
		if(post('detailedPlace')){
			$vResult = v('detailedPlace');
			if($vResult){
				alert($vResult, 0);
			}
		}
		$aData['address'] = post('detailedPlace');
		if(post('areaId')){
			$vResult = v('areaId');
			if($vResult){
				alert($vResult, 0);
			}

			$areaId = post('areaId');
			$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
			if($aAreaInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$aAreaInfo){
				alert('非法的地区', 0);
			}
			$aData['area_id'] = intval(post('areaId'));
		}
		$aData['id'] = $userId;
		if(post('gender')){
			if(intval(post('gender')) == 1 || intval(post('gender')) == 2){
				$aData['gender'] = intval(post('gender'));
			}
		}
		$year = intval(post('year'));
		$month = intval(post('month'));
		$day = intval(post('day'));
		if($year && $month && $day){
			$aData['birth_date'] = mktime(0, 0, 0, $month, $day, $year);
		}elseif(!$year && !$month && !$day){
			$aData['birth_date'] = mktime(0, 0, 0, $month, $day, $year);
		}

		$approveRow = 0;
		$aUserInfo = $oUser->getUserDetailInfoByUserId($userId);
		if(post('username')){
			if($aUserInfo['name'] != post('username')){
				$approveResult = $oUser->getUserApproveInfo($userId);
				if($approveResult === false){
								alert('系统错误', 0);
				}
				$approveData = array(
					'id' => $userId,
					'content' => array(
						'name' => array(
							'content'   => post('username'),
							'pass_time' => 0
						)
					),
				   'approve_finish' => 0,
				   'create_time' => time()
				);

				if($approveResult){
					if(isset($approveResult['content']['profile'])){
						$approveData['content']['profile'] = $approveResult['content']['profile'];
					}
					if((isset($approveResult['content']['name']) && $approveResult['content']['name']['content'] != post('username')) || !isset($approveResult['content']['name'])){
						$approveRow = $oUser->setUserInfoApprove($approveData);
					}
				}else{
					$approveRow = $oUser->addUserInfoApprove($approveData);
				}

				if($approveRow === false){
					alert('系统错误', 0);
				}
			}
		}
		$approveRow = $approveRow ? 1 : 0;
		$row = $oUser->setUserInfo($aData);

		if($row === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}else if($row){
			alert('更改成功!', 1 , array('is_edit_name' => $approveRow));
		}else{
			if($approveRow){
				$aData2 = array();
				$aData2['id'] = $userId;
				$aData2['approve_status'] = 1;
				$oUser->setUserIndexInfo($aData2);
				if(substr(DOMAIN_EXTEND, -3) == 'com'){
					$aOptions = array(
						'to' => USER_APPROVER_EMIAL,
						'subject' => 'UMFun 用户资料审核提醒！',
						'name' => USER_APPROVER_EMIAL,
						'content' => '用户' . $aUser['name'] . 'ID为' . $userId . '提交了姓名审核信息！<br /><a href="http://' . APP_MANAGE .'/?m=User&a=showApproveInfoList&account=' . $userId . '" style="color:#f00;">立即前往</a>为其审核!',
					);
					email($aOptions);
				}
				alert('更改成功!', 1 , array('is_edit_name' => $approveRow));
			}else{
				alert('信息没有修改!', 1);
			}
		}
	}

	/**
	 * 修改头像处理
	 * 表单参数：x, y, w, h, cssWidth, cssHeight, pic
	 */
	public static function editProfile(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];

		$oUser = m('User');
		$approveResult = $oUser->getUserApproveInfo($userId);
		if($approveResult === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}

		$aData = array();
		$rand = rand(1000, 9999);
		$imgBasename = $rand . $userId . '_approve.jpg';
		$twoNumberId = substr($userId, -2) . '/';
		$isAndroid = defined('CLIENT_SYSTEM') ? (CLIENT_SYSTEM == 'android') : false;
		if(!$isAndroid){
			//利用GD库来作裁剪操作
			$x = intval(post('x', 0));
			$y = intval(post('y', 0));
			$w = intval(post('w', 0));
			$h = intval(post('h', 0));
			$cssWidth = intval(post('cssWidth', 0));
			$cssHeight = intval(post('cssHeight', 0));
			$filename = trim((string)post('pic'));
			if(!$filename){
				alert('保存失败，请上传头像!', 0);
			}
			if($filename == 'male_300.jpg' || $filename == 'female_300.jpg'){
				$filename = SYSTEM_RESOURCE_PATH . '/' . USER_DEFAULT_PATH . $filename;
			}else{
				$filename = SYSTEM_RESOURCE_PATH . '/' . $filename;
			}
			$size = @getimagesize($filename); //获取图片的相关信息
			$width = $size['0'];
			$height = $size['1'];
			$percenWidth =  $width/$cssWidth;
			$percenHeight = $height/$cssHeight;
			////////////////
			$uploadBanner = $filename;

			if(!file_exists(SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId)){
				mkdir(SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId);
			}
			$sliceBanner = SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId . $imgBasename;
			$src_pic = self::_getImageHander($uploadBanner);
			if(!$src_pic){
				alert('保存失败!', -1);
			}
			$dst_pic = imagecreatetruecolor(130, 130);  //新建一个真彩色图像
			$bg = imagecolorallocate($dst_pic, 255, 255, 255);
			imagefill($dst_pic, 0, 0, $bg);

			imagecopyresampled($dst_pic, $src_pic, 0, 0, $x * $percenWidth, $y * $percenHeight, 130, 130, $w * $percenWidth, $h * $percenHeight);  //缩放图像.
			imagejpeg($dst_pic, $sliceBanner,100);  //// 输出给浏览器
			imagedestroy($src_pic);
			imagedestroy($dst_pic);
		}else{
			$filePrefix = $rand . $userId;
			$oUploader = new UploadFile(2097152, 'gif,jpg,jpeg,png,bmp', '', SYSTEM_RESOURCE_PATH . USER_PROFILE_PATH . $twoNumberId, $filePrefix . '_approve');
			$oUploader->uploadReplace = true;
			$uploadFileInfo = $oUploader->upload();
			if(!$uploadFileInfo){
				$aData['msg'] = $oUploader->getErrorMsg();
				$aData['error'] = 'error';
				alert('网络可能有点慢，请稍后再试!', 0, $aData);
			}else{
				$uploadFileInfo =  $oUploader->getUploadFileInfo();
				$uploadFileInfo = $uploadFileInfo[0];
				$aData['src'] = SYSTEM_RESOURCE_URL . '/' . USER_PROFILE_PATH . $twoNumberId . $imgBasename;
				$size = @getimagesize(SYSTEM_RESOURCE_PATH . '/' . USER_PROFILE_PATH . $twoNumberId . $imgBasename);
				$aData['image_width'] = $size[0];
				$aData['image_height'] = $size[1];
				$aData['path'] = USER_PROFILE_PATH . $twoNumberId . $imgBasename;
			}
		}

		$approveData = array(
			'id' => $userId,
			'content' => array(
				'profile' => array(
					'content' => USER_PROFILE_PATH . $twoNumberId . $imgBasename,
					 'pass_time' => 0
				)
			),
			'approve_finish' => 0,
			'create_time' => time()
		);
		if($approveResult){
			if(isset($approveResult['content']['name'])){
				$approveData['content']['name'] = $approveResult['content']['name'];
			}
			$result = $oUser->setUserInfoApprove($approveData);
		}else{
			$result = $oUser->addUserInfoApprove($approveData);
		}

		if($result === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}else{
			$aData2 = array();
			$aData2['id'] = $userId;
			$aData2['approve_status'] = 1;
			$oUser->setUserIndexInfo($aData2);
			if(substr(DOMAIN_EXTEND, -3) == 'com'){
				$aOptions = array(
					'to' => USER_APPROVER_EMIAL,
					'subject' => 'UMFun 用户资料审核提醒！',
					'name' => USER_APPROVER_EMIAL,
					'content' => '用户' . $aUser['name'] . 'ID为' . $userId . '提交了头像审核信息！<br /><a href="http://' . APP_MANAGE .'/?m=User&a=showApproveInfoList&account=' . $userId . '" style="color:#f00;">立即前往</a>为其审核!',
				);
				email($aOptions);
			}

			alert('保存成功! 请等待头像审核', 1, $aData);
		}
	}

	/**
	 * 重设用户密码
	 * 表单参数：password, enPassword, captcha
	 */
	public static function resetPassword(){
		$vResult = v('password');
		if($vResult){
			alert($vResult, -1);
		}

		$password = post('password');
		$enPassword = post('enPassword');
		$aUser = checkUserLogin();
		if(!$aUser){
			alert('请登录后再操作!', 0);
		}
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByNumberIdAndPassword($aUser['id'], $enPassword);
		if(!$aUserInfo){
			alert('用户密码不正确!', -2);
		}

		$result = $oUser->setUserPasswordByNumberId($aUser['id'], $password);
		if($result === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}else{
			alert('修改密码成功', 1);
		}
	}

	 /**
	 * 激活邮箱的邮件
	 * 表单参数：email, limit_captcha
	 */
	public static function sendActiveEmail(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$email = post('email') ? post('email') : $aUser['email'];
		$captcha = post('limitCaptcha') ? post('limitCaptcha'): post('limit_captcha');

		$isEmail = w('isEmail()', $email);
		if(!$isEmail){
			alert('邮箱格式不正确！', -1);
		}
		if(!Verify::match('limitCaptcha', $captcha)){
			alert('验证码错误！', -1);
		}

		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if(!$aUserInfo){
			alert('用户不存在', -1);
		}

		$aUser = $oUser->getPersonalInfoByUserId($userId);
		if($aUser['is_email_active']){
			alert('邮箱已经验证', -1);
		}
		$isAndroid = defined('CLIENT_SYSTEM') ? (CLIENT_SYSTEM == 'android') : false;
		if($isAndroid){
			$num = $oUser->isEmailExist($email);
			if($num && $aUserInfo['email'] != $email){
				alert('该邮箱已经注册过了!', -1);
			}elseif($aUserInfo['email'] && $aUserInfo['email'] != $email){
				alert('邮箱错误!', -1);
			}elseif(!$num){
				$aData = array(
					'id' => $userId,
					'email' => $email
				);
				$isSetSuccess = $oUser->setUserInfo($aData);
				if(!$isSetSuccess){
					alert('网络可能有点慢，请稍后再试!', 0);
				}
			}
		}
		$nowTime = time();
		$endTime = $nowTime + 60 * 15;
		$addTwoTime = null;
		for($i = 0; $i < strlen($nowTime); $i++){
			$addTwoTime .= substr($nowTime, $i, 1);
			$addTwoTime .= substr($endTime, strlen($endTime) - $i - 1, 1);
		}
		$addTwoTime .= $aUserInfo['id'] . $aUserInfo['email'];
		$addTwoTime = urlencode(base64_encode($addTwoTime));

		$options = array(
			'to' => $aUserInfo['email'],
			'subject' => '激活UMFun邮箱',
			'name' => isset($aUser['name']) ? $aUser['name'] : $aUser['email'],
			'content' => '这是一封你在UMFun(优满分 ' . APP_HOME . ')激活邮箱的邮件! 请在15分钟内点击以下链接来激活邮箱：' . url('m=Account&a=showSettingEmail', 'action=' . $addTwoTime)
 . ', 如果以上链接无法打开，请复制以上网址并粘贴至浏览器手动打开！邮箱重设后请妥善保管并牢记，祝您心情愉快，谢谢！'
		);
		if(email($options)){
			alert('激活账户邮箱的邮件已发送，请登陆邮箱查看！', 1);
		}else{
			alert('发送邮件失败', 0);
		}
	}

	/**
	 * 获取用户签到信息
	 */
	public static function getMarkInfo(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$isMarked = 0;
		$todayStr = '';
		$day = date('w');
		$weekarray = array("天", "一", "二", "三", "四", "五", "六");

		//金币初始化为第一天的金币数量
		$gold = 1;

		if(isset($weekarray[$day])){
			$todayStr .= '星期' . $weekarray[$day];
		}

		$oUserBehavior = m('UserBehavior');
		$aMarkInfo = array();
		$markTotal = 0;
		$markContinuous = 0;
		$aMarkInfo =  $oUserBehavior->getMarkInfoById($userId);
		if($aMarkInfo === false){
			alert('页面加载错误', 0);
		}
		if(!$aMarkInfo){
			$aData = array(
				'id'			=> $userId,
				'mark_total' 	=> 0,
				'mark_continuous'=> 0,
				'last_mark_date'=> 20131219
			);
			$result = $oUserBehavior->addMark($aData);
			if(!$result){
				alert('签到失败', 0);
			}
			$aMarkInfo =  $oUserBehavior->getMarkInfoById($userId);
			if($aMarkInfo === false){
				alert('页面加载错误', 0);
			}
		}
		if($aMarkInfo){
			$markTotal = $aMarkInfo['mark_total'];

			if($aMarkInfo['last_mark_date'] == date('Ymd') || $aMarkInfo['last_mark_date'] == date('Ymd', strtotime("-1 day"))){
				$markContinuous = $aMarkInfo['mark_continuous'];
			}

			if($aMarkInfo['last_mark_date'] == date('Ymd')){
				$isMarked = 1;
			}
			if($markContinuous <= 2){
				$addGold = $GLOBALS['GOLD']['mark'][2];
			}elseif($markContinuous > 2 && $markContinuous <= 6){
				$addGold = $GLOBALS['GOLD']['mark'][6];
			}elseif($markContinuous > 6 && $markContinuous <= 14){
				$addGold = $GLOBALS['GOLD']['mark'][14];
			}elseif($markContinuous > 14 && $markContinuous <= 30){
				$addGold = $GLOBALS['GOLD']['mark'][30];
			}elseif($markContinuous > 30){
				$addGold = $GLOBALS['GOLD']['mark'][31];
			}
		}

		$aFriendIdIds = array();
		$aFriendIdIds = getUserFriendIds($userId);
		$aFriendIdIds[] = $userId;
		$aMarkRankingList = $oUserBehavior->getMarkRankingList(1,'', $aFriendIdIds);
		if($aMarkRankingList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		foreach($aMarkRankingList as $key=>$aMarkRanking){
			if($aMarkRanking['id'] == $userId){
				$myMarkRanking = $key+1;
				break;
			}
		}
		$aResultData = array(
			'is_marked' => $isMarked,
			'week_str' => $todayStr,
			'today_date' => date('Y.m.d'),
			'mark_total_day' => $markTotal,
			'continue_mark_day' => $markContinuous,
			'today_gold' => $addGold,
			'friend_mark_rank' => $myMarkRanking,
		);

		alert('签到信息', 1, $aResultData);
	}

	public static function mark(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUserBehavior = m('UserBehavior');
		$aMarkInfo = $oUserBehavior->getMarkInfoById($userId);
		if($aMarkInfo === false){
			alert('数据错误', 0);
		}elseif(!$aMarkInfo){
			$aData = array(
				'id' => $userId,
				'mark_total' => 1,
				'mark_continuous' => 1,
				'last_mark_date'=> date('Ymd'),
			);
			$result = $oUserBehavior->addMark($aData);
		}else{
			if($aMarkInfo['last_mark_date'] == date('Ymd')){
				alert('今天己经签到过了哦', -1);
			}

			$aData = array(
				'id' => $userId,
				'mark_total' => $aMarkInfo['mark_total'] + 1 ,
				'last_mark_date'=> date('Ymd'),
			);

			if($aMarkInfo['last_mark_date'] == date('Ymd', strtotime("-1 day"))){
				$aData['mark_continuous'] = $aMarkInfo['mark_continuous'] + 1;
			}else{
				$aData['mark_continuous'] = 1;
			}
			$result = $oUserBehavior->setMark($aData);
		}

		if(!$result){
			alert('签到失败', 0);
		}
		//加金币
		$oGame = new Game();
		$markResult = $oGame->afterSign($userId, $aData['mark_continuous']);
		if($markResult){
			$aThisResult = array();
			//$aThisResult['show_type'] = 'SIGNSUCCESS';
			//$aThisResult['custom_data']['time'] = time();
			//$aThisResult['custom_data']['continue_sign'] = $aData['mark_continuous'];
			//$oGame->setResult($aThisResult);
			alert('签到成功', 1);
		}else{
			//回滚
			$returnData = array(
				'id'				=> $userId,
				'mark_total'		=> 0,
				'mark_continuous'	=> 0,
				'last_mark_date'	=> 0
			);
			if($aMarkInfo){
				$returnData['mark_total'] = $aMarkInfo['mark_total'];
				$returnData['mark_continuous'] = $aMarkInfo['mark_continuous'];
				$returnData['last_mark_date'] = $aMarkInfo['last_mark_date'];
			}
			$oUserBehavior->setMark($returnData);
			alert('签到失败', 0);
		}
	}

	public static function markRankingList(){
		$page = intval(post('page', 1));
		$orderType = intval(post('order_type', 1));
		$groupType = intval(post('group_type', 0));
		$pageSize = 8;
		//签到天数及连续签到天数列表
		/*$aFriendIdIdsArray = $this->_getFriendIds();
		$returnHtml = '';
		if($aFriendIdIdsArray){
			$returnHtml = $this->_getMarkList($aFriendIdIdsArray, $orderType, $page);
		}*/

		$aUser = checkUserLogin();
		$userId = $aUser['id'];

		$oUserBehavior = m('UserBehavior');
		$aFriendIdIds = array();
		if($groupType == 1){
			$aFriendIdIds = getUserFriendIds($userId);
			array_push($aFriendIdIds, $userId);
		}

		$order = '`mark_continuous` desc';
		if($orderType == 2){
			$order = '`mark_total` desc';
		}
		$markTotal = $oUserBehavior->getMarkRankingCount(array($userId));
		if($markTotal === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		$aMarkRankingList = $oUserBehavior->getMarkRankingList($page, $pageSize, $aFriendIdIds, $order);
		if($aMarkRankingList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		foreach($aMarkRankingList as $key => $aMarkRanking){
			$aMarkRankingList[$key]['rankNumber'] = ($page - 1) * $pageSize + ($key + 1);
			$aMarkRankingList[$key]['user_info'] = getUserInfo($aMarkRanking['id']);
		}
		alert('签到排名列表', 1, $aMarkRankingList);
	}

	public static function buildLoginFlag($aUser){
		return md5(getClientIP() . $aUser['id'] . mt_rand((int)$aUser['id'], 9999999999));
	}

	/**
	 * 添加记录经验数值等操作
	 */
	private static function _addRegisterUserNumerical($userId){
		$oUserNumerical = m('UserNumerical');
		$aData = array(
			'id' => $userId,
			'level' => 1,
			'gold' => 0,
			'accumulate_points' => 0,
			'vip' => 0
		);
		$setResult = $oUserNumerical->setUserNumerical($aData);
		if($setResult === false){
			alert('系统出错，请稍后再试', 0);
		}
	}

	/**
	 *注册之后的回调函数，分别是5位数、8位数的邀请码
	 */
	private static function _afterRegister($aDataHook){
		if($aDataHook['eight_number_invite_code']){
			//经验
			$oGame = new Game();
			$aRresult = $oGame->afterRegistered($aDataHook['invite_code']);
			if(empty($aRresult)){
				alert('推荐注册加经验失败', 0);
			}
		}
	}

	/**
	 * 学校信息处理
	 */
	private static function _schoolInfoHandle($userId){
		//注意前端班级的value
		$provinceId = intval(post('provinceId_register'));
		$cityId = intval(post('cityId_register'));
		$areaId = intval(post('areaId_register'));
		$oUser = m('User');
		//验证地区
		$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
		if($aAreaInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aAreaInfo){
			alert('非法的地区', 0);
		}

		$aData = array(
			'user_id' => $userId,
			'school_id' => intval(post('schoolId_register')),
			'class' => post('className_register'),
			'grade' => post('gradeId_register'),
			'year' => date('Y', time()),
			'province_id' => $provinceId,
			'city_id' => $cityId,
			'area_id' => $areaId,
			'is_active' => 1,
		);

		if($aData['school_id'] != 0){
			$aSchoolInfo = $oUser->getSchoolInfoBySchoolId($aData['school_id']);
			if($aSchoolInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$aSchoolInfo){
				alert('非法的学校', 0);
			}
		}

		if($aData['class'] != 0){
			//验证班级是否存在
			$counts = $oUser->isClassExist($aData['year'], $aData['school_id'], $aData['grade'], $aData['class']);
			if($counts === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$counts){
				for($j = 1; $j < 21; $j++){
					$aClassList[] = $j;// . '班';
				}
				if(!in_array($aData['class'], $aClassList)){
					alert('无效的班级，暂时支持1-20', 0);
				}
			}
		}

		//如果学校id小于1，则为添加学校
		if($aData['school_id'] < 1){
			//判断用户要添加的学校是不是存在
			$schoolName = post('addSchoolName_register');
			if(!$schoolName){
				alert('请添加学校!', 0);
			}

			$aSchoolData = array(
				'area_id' => $areaId,
				'name' => $schoolName,
			);

			$aSchoolInfo = $oUser->getSchoolInfoByAreaIdAndSchoolName($aSchoolData['area_id'] ,$aSchoolData['name']);
			if($aSchoolInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if($aSchoolInfo){
				alert('该学校已经存在了!', 0);
			}
		}

		//如果班级id为0，则为添加班级
		if($aData['class'] == 0){
			//判断用户要添加的班级存不存在
			$addClassName = post('addClassName_register');
			if(!$addClassName){
				alert('请写入有效的班级!', 0);
			}
			//用户填写班级，前端默认填充班作显示。
			if(preg_match('/班$/', $addClassName) === 0){
				$addClassName = $addClassName . '班';
			}
			$aUserInfo = $oUser->isClassExist($aData['year'], $aData['school_id'], $aData['grade'], $addClassName);
			if($aUserInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if($aUserInfo){
				alert('该班级已经存在了', 0);
			}else{
				for($j = 1; $j < 21; $j++){
					$aClassList1[] = $j . '班';
				}
				if(in_array($addClassName, $aClassList1)){
					alert('抱歉，该班级已经存在了！', 0);
				}
				$aData['class'] = $addClassName;
			}
		}

		if(isset($aSchoolInfo) && !$aSchoolInfo){
			//如果数据库中不存在用户添加的学校就创建
			$aSchoolData['type'] = '';
			$aData['school_id'] = $oUser->addSchool($aSchoolData);
			if($aData['school_id'] === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}

		//添加班级
		$classId = $oUser->addClass($aData);
		if($classId === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$classId){
			alert('学校信息填写失败', 0);
		}
	}

	/**
	 * 更新注册用户可能认识的朋友
	 */
	private static function _updateRegisterUserProbablyFriends($userId){
		$oSns = m('Sns');
		$probablyFriends = $oSns->cheakProbablyFriends($userId);
		if($probablyFriends === false){
			alert('系统出错，请稍后再试', 0);
		}
	}

	/**
	 *获取指定日期对应星座
	 * @param integer $month 月份 1-12
	 * @param integer $day 日期 1-31
	 * @return boolean|string
	 */
	private static function _getConstellation($month, $day){
		$day   = intval($day);
		$month = intval($month);
		if ($month < 1 || $month > 12 || $day < 1 || $day > 31){
			return false;
		}
		$signs = array(
			array('20'=>'水瓶座'),
			array('19'=>'双鱼座'),
			array('21'=>'白羊座'),
			array('20'=>'金牛座'),
			array('21'=>'双子座'),
			array('22'=>'巨蟹座'),
			array('23'=>'狮子座'),
			array('23'=>'处女座'),
			array('23'=>'天秤座'),
			array('24'=>'天蝎座'),
			array('22'=>'射手座'),
			array('22'=>'摩羯座')
		);
		list($start, $name) = each($signs[$month-1]);
		if ($day < $start)
		list($start, $name) = each($signs[($month-2 < 0) ? 11 : $month-2]);
		return $name;
	}

	private static function _getImageHander($url){
		$aMime=@getimagesize($url); //获取图片的相关信息mime] => image/jpeg
		switch($aMime['mime']){
			case 'image/jpeg': $im = imagecreatefromjpeg($url); //打开图片
				break;
			case 'image/gif' : $im = imagecreatefromgif($url);
				break;
			case 'image/png' : $im = imagecreatefrompng($url);
				break;
			default:
				$im=false;
				break;
		}
		return $im;
	}

	private static function _getRegisterNumberAccount($aData, $inviteCode){
		$oUser = m('User');
		$numberAccount = $oUser->getRegisterNumberAccount();
		if($numberAccount === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($numberAccount){
			$aData['id'] = $numberAccount;
		}else{
			alert('抱歉,系统出错,注册失败', 0);
		}

		//添加注册的用户
		$registerResult = $oUser->userRegister($aData, $inviteCode);
		if($registerResult === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$registerResult){
			alert('注册失败', 0);
		}
		return $aData;
	}

	private static function _setRegisterCookie($aUser){
		$now = time();
		$userId = &$aUser['id'];
		$token = User::buildLoginFlag($aUser);

		//登陆信息
		$aLoginInfo = array(
			'token' => $token,
			'ip' => getClientIP(),
			'agent' => strtolower($_SERVER['HTTP_USER_AGENT']),
		);
		Cookie::setEncrypt('loginToken', $token);
		Cookie::setEncrypt('userId', $userId);
		User::setUserLoginInfo($userId, $aLoginInfo, 3600);

		//注册成功后让用户呈现登陆状态,记录cookie一年
		Cookie::setEncrypt('lastActiveTime' . $userId, $now, $now + RELOGIN_OVERTIME);
	}

	private static function _setLoginCookie($aUser, $autoLogin){
		$mStudent = Student::findOne($aUser['id']);
		if(!$mStudent){
			halt('非法的学生账号');
		}
		return Yii::$app->student->login($mStudent);
		/*
		$oUser = m('User');
		$userId = &$aUser['id'];
		$now = time();
		$token = '';
		$clientIp = getClientIP();

		$aLoginInfo = User::getUserLoginInfo($userId);
		if($aLoginInfo && $aLoginInfo['ip'] == $clientIp){
			$token = $aLoginInfo['token'];
			unset($aLoginInfo['parent']);
			unset($aLoginInfo['from_xxt']);
		}else{
			$token = User::buildLoginFlag($aUser);
			//登陆信息
			$aLoginInfo = array(
				'token' => $token,
				'ip' => $clientIp,
				'agent' => strtolower($_SERVER['HTTP_USER_AGENT']),
			);
		}

		$cookieOverTime = 0;
		$loginInfoOverTime = 3600;
		if($autoLogin){
			$cookieOverTime = $now + 31536000;
			$loginInfoOverTime = 0;
		}
		Cookie::setEncrypt('autoLogin', $autoLogin ? 1 : 0, $cookieOverTime);
		Cookie::setEncrypt('loginToken', $token, $cookieOverTime);
		Cookie::setEncrypt('userId', $userId, $cookieOverTime);
		User::setUserLoginInfo($userId, $aLoginInfo, $loginInfoOverTime);

		//更新上次活动时间
		$lastActiveTime = intval(Cookie::getDecrypt('lastActiveTime' . $userId));
		if(!$lastActiveTime){
			self::_setLoginLog($userId, 1);
		}
		Cookie::setEncrypt('lastActiveTime' . $userId, $now, $now + RELOGIN_OVERTIME);

		//更新最后登陆时间
		$lastLoginDayTime = strtotime(date('Y-m-d', $aUser['last_login_time']));
		$todayTime = strtotime(date('Y-m-d', $now));
		if($lastLoginDayTime < $todayTime){
			$oUser->setUserIndexInfo(array(
				'id' => $userId,
				'last_login_time' => $now,
			));
		}

		if(m('Sns')->cheakProbablyFriends($userId) === false){
			alert('系统出错，请稍后再试', 0);
		}
		*/
	}

	private static function _getXxtTeacherClassStudentInfo($aXxtUser){
		try{
			$aReasult = Xxt::getClassTeacher($aXxtUser['UserId']);
		}catch(XxtException $e){
			halt($e->getMessage(), true, $e->getCode());
		}

		$aXxtTeacher = $aReasult;
		$aClassInfo = array();
		if(isset($aXxtTeacher['Relations']['ClassTeacherRelation']) && $aXxtTeacher['Relations']['ClassTeacherRelation']){
			if(isset($aXxtTeacher['Relations']['ClassTeacherRelation'][0])){
				foreach($aXxtTeacher['Relations']['ClassTeacherRelation'] as $aRelation){
					$aClass = array(
						'ClassId' => $aRelation['ClassId'],
						'ClassName' => $aRelation['ClassName'],
						'GradeId' => $aRelation['GradeId'],
						'GradeName' => $aRelation['GradeName'],
						'SubjectList' => isset($aRelation['SubjectList']) ? $aRelation['SubjectList'] : array(),
						'student_list' => array()
					);
					try{
						$aReasult = Xxt::getClassInfo($aRelation['ClassId']);
					}catch(XxtException $e){
						alert('抱歉，在和教育没找到您对应的班级信息，不能正常使用优满分！', 0);
					}
					$aXxtClass = $aReasult;
					$aClass['Bank'] = $aXxtClass['Bank'];
					try{
						$aReasult = Xxt::getClassStudent($aXxtUser['CityId'], $aRelation['ClassId']);
					}catch(XxtException $e){
						alert('抱歉，在和教育没找到您对应的学生信息，不能正常使用优满分！', 0);
					}

					$aXxtClassStudent = $aReasult;
					if($aXxtClassStudent){
						if(isset($aXxtClassStudent['StudentInfo'][0])){
							foreach($aXxtClassStudent['StudentInfo'] as $k => $aStudent){
								$aStudentInfo = array(
									'StudentId' => intval($aStudent['StudentId']),
									'UserName' => $aStudent['UserName']
								);
								array_push($aClass['student_list'], $aStudentInfo);
							}
						}else{
							$aStudent = $aXxtClassStudent['StudentInfo'];
							$aStudentInfo = array(
								'StudentId' => intval($aStudent['StudentId']),
								'UserName' => $aStudent['UserName']
							);
							array_push($aClass['student_list'], $aStudentInfo);
						}
					}
					array_push($aClassInfo, $aClass);
				}
			}else{
				$aRelation = $aXxtTeacher['Relations']['ClassTeacherRelation'];
				$aClass = array(
					'ClassId' => $aRelation['ClassId'],
					'ClassName' => $aRelation['ClassName'],
					'GradeId' => $aRelation['GradeId'],
					'GradeName' => $aRelation['GradeName'],
					'SubjectList' => isset($aRelation['SubjectList']) ? $aRelation['SubjectList'] : array(),
					'student_list' => array()
				);

				try{
					$aReasult = Xxt::getClassInfo($aRelation['ClassId']);
				}catch(XxtException $e){
					alert('抱歉，在和教育没找到您对应的班级信息，不能正常使用优满分！', 0);
				}

				$aXxtClass = $aReasult;
				$aClass['Bank'] = $aXxtClass['Bank'];
				try{
					$aReasult = Xxt::getClassStudent($aXxtUser['CityId'], $aRelation['ClassId']);
				}catch(XxtException $e){
					alert('抱歉，在和教育没找到您对应的学生信息，不能正常使用优满分！', 0);
				}

				$aXxtClassStudent = $aReasult;
				if($aXxtClassStudent){
					if(isset($aXxtClassStudent['StudentInfo'][0])){
						foreach($aXxtClassStudent['StudentInfo'] as $k => $aStudent){
							$aStudentInfo = array(
								'StudentId' => intval($aStudent['StudentId']),
								'UserName' => $aStudent['UserName']
							);
							array_push($aClass['student_list'], $aStudentInfo);
						}
					}else{
						$aStudent = $aXxtClassStudent['StudentInfo'];
						$aStudentInfo = array(
							'StudentId' => intval($aStudent['StudentId']),
							'UserName' => $aStudent['UserName']
						);
						array_push($aClass['student_list'], $aStudentInfo);
					}
				}
				array_push($aClassInfo, $aClass);

			}
		}else{
			return array();
		}
		return $aClassInfo;
	}

	/*
	 * 记录用户登录记录
	 * @param integer $userId
	 * @param integer $type  1=学生 2=家长 3=老师
	 * No return
	 */
	private static  function _setLoginLog($userId, $type){
		$isComputor = isComputer();
		if($isComputor){
			$clientType = 1;
		}else{
			$clientType = 2;
		}
		m('User')->addUserLoginLog(array(
			'user_id' => $userId,
			'login_time' => time(),
			'user_type'	=>	$type,
			'client_type'	=>	$clientType,
		));
	}

	public static function getUserLoginInfo($userId){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		return $oRedis->getOne('user_login:' . $userId);
	}

	public static function setUserLoginInfo($userId, $aData, $overTime){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return 0;
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return 0;
		}
		$key = 'user_login:' . $userId;
		$oRedis->redis->multi(Redis::PIPELINE);
		$oRedis->delete($key);
		$oRedis->add($key, $aData);
		if($overTime){
			$oRedis->expire($key, $overTime);
		}
		$aResult = $oRedis->redis->exec();
		return $aResult[1];
	}

	public static function deleteUserLoginInfo($userId){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		return $oRedis->deleteOne('user_login:' . $userId);
	}

	public static function expireUserLoginInfo($userId, $overTime){
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		$oRedis = new RedisCache();
		$oRedis->connect(DEFAULT_REDIS_SERVER, $GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART']);
		if(!$GLOBALS['DB_CONFIG']['REDIS_SERVER'][DEFAULT_REDIS_SERVER]['is_active']){
			return array();
		}
		return $oRedis->expireOne('user_login:' . $userId, $overTime);
	}

	public static function loginParent(){
		$aUser = checkUserLogin();
		if(!User::isLoginFromParent($aUser['id'])){
			halt('您的登陆并非来自家长切换，无法切换回到家长账户', true, $aUser);
		}
		$aParent = isParentLogin();
		if(!$aParent){
			halt('获取家长登陆信息失败');
		}
		Parents::loginUser($aParent['id']);
		User::logoutUser($aUser['id']);
	}

	/**
	 * 判断一个学生是否来自家长切换的登陆
	 * @param type $userId
	 * @return type
	 */
	public static function isLoginFromParent($userId){
		$aLoginInfo = self::getUserLoginInfo($userId);
		return isset($aLoginInfo['parent']);
	}

	/**
	 * 判断一个学生是否来自和教育登陆
	 * @param type $userId
	 * @return type
	 */
	public static function isLoginFromXxt($userId){
		$aLoginInfo = self::getUserLoginInfo($userId);
		if(!isset($aLoginInfo['from_xxt']) && !isset($aLoginInfo['parent'])){
			return false;
		}else{
			return true;
		}
	}

	/**
	 * 标记用户是来自和教育登陆的
	 * @param type $userId
	 * @return boolean
	 */
	public static function loginFromXxt($userId){
		$aLoginInfo = self::getUserLoginInfo($userId);
		if(!$aLoginInfo){
			return false;
		}
		$aLoginInfo['from_xxt'] = true;
		return self::setUserLoginInfo($userId, $aLoginInfo, 0) ? true : false;
	}

	/**
	 * 判断一个学生是否来自和教育登陆
	 * @param type $userId
	 * @return type
	 */
	public static function isReadIndexGuide($userId){
		$aLimit = m('Limit')->getLimitInfo($userId, 'note');
		if(!$aLimit || !$aLimit['note']){
			return false;
		}

		if(isset($aLimit['note']['read_index_guide'])){
			if($aLimit['note']['read_index_guide'] < 1){
				return false;
			}
		}else{
			return false;
		}

		return true;
	}

	/**
	 * 用户阅读引导后更新标记
	 * @param integer $userId
	 * @return boolean
	 */
	public static function readIndexGuide($userId){
		$aLimit = m('Limit')->getLimitInfo($userId, 'note');
		$result = false;
		if(!$aLimit){
			$alimitInfo = array('id' => $userId , 'note' => array(
				'read_index_guide' => time()
			));
			$limitModel = m('limit');
			$result = $limitModel->addLimit($alimitInfo);
		}else{
			$result = m('Limit')->setLimit(array(
				'id' => $userId,
				'note' => array(
					'read_index_guide' => time()
				)
			));
		}

		return $result ? true : false;
	}

	//注册时,检查该班级学生的注册数量,发现数量满足3的倍数则向班圈发送一条微博推广----------班级内和教育用户数量————(消息发给没来的人，并附上已经来的人名单..)
	public static function sendWeiboWhenConditionMeet($aXxtUser){
		$isRegisterComplete = Cookie::getDecrypt('isRegisterComplete');

		if($isRegisterComplete == 1){
			Cookie::delete('isRegisterComplete');
		}else{
			return false;
		}

		$aStudentInfo = Xxt::getStudentInfo($aXxtUser['UserId'], $aXxtUser['CityId']);
		if(isset($aStudentInfo['StudentEntity']['ClassId']) && $aStudentInfo['StudentEntity']['ClassId']){
			$classId = $aStudentInfo['StudentEntity']['ClassId'];
			$oUser = m('User');
			$aUserIds = $oUser->getClassXxtUserIds($aXxtUser['SchoolId'], $classId);

			if($aUserIds){
				$studentCount = count($aUserIds);
				$aUmfunUser = array();
				$aXxtIds = array();
				$contentStr = '你们的小伙伴：';
				foreach($aUserIds as $id){
					$aUmfunUser[$id] = getUserInfo($id, array('personal'));
					if(isset($aUmfunUser[$id]['xxt_data']) && is_array($aUmfunUser[$id]['xxt_data'])){
						array_push($aXxtIds, $aUmfunUser[$id]['xxt_data']['UserId']);
						$contentStr .= $aUmfunUser[$id]['name'] . ',';
					}
				}
				$contentStr .= '已经加入优满分了，快来跟他们一起玩吧！';
				$wait7Time = strtotime('+7 Days');
				$aContent = array(
					'City' => $aXxtUser['CityId'],
					'UserType' => 2,
					'IsOauth' => 0,
					'OthMsgId' => 0,
					'ValidDate' => date('Y-m-d H:i:s', $wait7Time),
					'URL' => url('m=Index&a=index', '', APP_HOME),
					'Type' => 1,
					'SchoolId' => $aXxtUser['SchoolId'],
					'Content' => $contentStr
				);

				if($studentCount && $studentCount % 3 == 0){
					$aXxtClassStudent = Xxt::getClassStudent($aXxtUser['CityId'], $classId);
					if($aXxtClassStudent){
						if(isset($aXxtClassStudent['StudentInfo'][0])){
							foreach($aXxtClassStudent['StudentInfo'] as $k => $aStudent){
								if(!in_array(intval($aStudent['StudentId']), $aXxtIds)){
									Xxt::postAppMessage($aStudent['StudentId'], $aContent);
								}
							}
						}else{
							$aStudent = $aXxtClassStudent['StudentInfo'];
							if(!in_array(intval($aStudent['StudentId']), $aXxtIds)){
								Xxt::postAppMessage($aStudent['StudentId'], $aContent);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 申请加好友
	 * @param string $verify_text_info 申请内容信息
	 * @param integer $user_id	申请朋友的ID
	 * @param integer $thisUserId	当前用户的ID
	 * @return JSON 返回alert消息状态
	 */
	public static function apply($verify_text_info, $user_id, $thisUserId){
		$verifyTextInfo = $verify_text_info;
		$isLength = w('length(0, 50)', $verifyTextInfo);
		if(!$isLength){
			alert('验证信息不能超过50个字符', -1);
		}

		$userSlaveId = intval($user_id);
	   if(!$userSlaveId){
		   alert('参数错误', -1);
	   }
	   if($thisUserId == $userSlaveId){
		   alert('不能加自己为好友', -1);
	   }

	   //查询是否己经是好友关系
	   $aFriendId = getUserFriendIds($thisUserId);
	   if(in_array($userSlaveId, $aFriendId)){
		   alert('该用户已经是你的好友', -1);
	   }

	   $oSns = m('Sns');
	   //查询是否己经发送 "他加我" 请求
	   $aSlaveInfo = $oSns->getUserRelationInfo('`user_master_id` = ' . $userSlaveId . ' AND `user_slave_id` = ' . $thisUserId);
	   if($aSlaveInfo){
		   //如果己经存在　"他加我" 记录，则互加为好友
		   $result = $oSns->agreeFriendApply($thisUserId, $userSlaveId);
		   if($result){
			   alert('添加好友成功，你又多一名小伙伴啦', 2);
		   }else{
			   alert('网络可能有点慢，请稍后再试', 0);
		   }
	   }else{
		   limitCheck('APPLY_FRIEND');
		   $aData = array(
			   'user_master_id' => $thisUserId,
			   'user_slave_id' => $userSlaveId,
			   'create_time' => time(),
			   'confirm_message' => $verifyTextInfo
		   );
		   $isApplySuccess = $oSns->applyFriend($aData);
		   if($isApplySuccess){
			   //限制与经验
			   limitAdd('APPLY_FRIEND');
			   $limit = limitCheck('FRIEND_ACCUMULATE');
			   if($limit){
				   $oGame = new Game();
				   if(!$oGame->afterAddFriend($thisUserId)){
					   alert('程序执行错误，请稍后重试', 0);
				   }
				   limitAdd('FRIEND_ACCUMULATE');
			   }
			   alert('好友申请信息已发送成功！', 1);
		   }else{
			   alert('申请好友失败，请重新操作', 0);
		   }
	   }
	}

}