<?php
class Activity{
	const CLIENT_MOBILE = 0;
	const CLIENT_PC = 1;
	const MISSION_START_TIME = 1428595200; //活动开始时间
	const MISSION_END_TIME = 1433865600; //活动结束时间
	const MISSION_GIFT_PC_PATH = 'data/activity/mission/pc/';
	const MISSION_GIFT_MOBILE_PATH = 'data/activity/mission/mobile/';

	function __construct(){}

	public static function showActicity($clientType){
		$aUserInfo = isLogin();
		if(!$aUserInfo){
			$aParentInfo = isParentLogin();
			if($aParentInfo){
				$aUserInfo = array(
					'id' => 0,
					'name' => '',
					'xxt_type' => $aParentInfo['extend_type']
				);
			}else{
				checkUserLogin();
			}
		}

		$aActivityList = array(
			array(),
			array(),
			array()
		);
		$time = time();
		foreach($GLOBALS['ACTIVE']['activity_center'] as $aValue){
			if($aUserInfo['xxt_type'] == 3 && $aValue['title'] == '闯关有礼'){
				$aValue['start_time'] = self::MISSION_START_TIME;
				$aValue['end_time'] = self::MISSION_END_TIME;
				$aValue['hall_img'] = 'data/activity/center/033.jpg';
			}
			if($time > $aValue['start_time'] && $time < $aValue['end_time']){
				$aActivityList[2][] = array_merge($aValue, array(
					'css' => 'ving'
				));
			}else if($time < $aValue['start_time'] && $time < $aValue['end_time']){
				$aActivityList[1][] = array_merge($aValue, array(
					'css' => 'vpre'
				));
			}else if($time > $aValue['start_time'] && $time > $aValue['end_time']){
				$aActivityList[0][] = array_merge($aValue, array(
					'css' => 'ved'
				));
			}
		}

		assign('aActivityList', $aActivityList);
		assign('aUserInfo', $aUserInfo);
		if($clientType == self::CLIENT_PC){
			display('activity/nav.html.php');
		}
		display('activity/activity_center.html.php');
		if($clientType == self::CLIENT_PC){
			displayFooter();
		}
	}

	public static function showMission(){
		$aUserInfo = isLogin();
		if(!$aUserInfo){
			$aParentInfo = isParentLogin();
			if($aParentInfo){
				$aUserInfo = array(
					'id' => 0,
					'name' => '',
					'xxt_type' => $aParentInfo['extend_type']
				);
			}else{
				checkUserLogin();
			}
		}
		//奖品
		$aGift = array(
			1 => array(
				1 => '篮球',
				2 => '小米充电宝',
				3 => '镶钻水晶沙漏',
				4 => '小学生学习文具组合套装'
			),
			2 => array(
				1 => '休闲时尚电子表',
				2 => '高达玩具模型',
				3 => '绿猪存钱罐',
				4 => '雷速登闪电冲线遥控车'
			),
			3 => array(
				1 => '懒人静音学生闹钟 ',
				2 => '护眼台灯',
				3 => '手套',
				4 => '男士围巾'
			),
			4 => array(
				1 => '女士围巾',
				2 => '拖鞋',
				3 => '时尚简约电子表',
				4 => '红绳手链'
			)
		);
		assign('aGift', $aGift);

		assign('giftPc', self::MISSION_GIFT_PC_PATH);
		assign('giftMobile', self::MISSION_GIFT_MOBILE_PATH);

		//计算往期排行周
		$startWeek = date('W', self::MISSION_START_TIME);
		$endWeek = date('W', self::MISSION_END_TIME);
		$currentWeek = date('W');
		if($startWeek > $endWeek){
			$flag = 1;	//未开时
		}elseif($startWeek == $currentWeek){
			$flag = 2;	//第一周
		}elseif($startWeek < $currentWeek && $currentWeek <= $endWeek){
			$flag = 3;	//进行中
		}else{
			$flag = 4;	//结束
		}

		$aWeekList = array();
		if($flag == 3){
			for($i = $startWeek; $i < $currentWeek; $i++){
				$aWeekList[] = array(
					'year' => date('Y'),
					'week' => $i
				);
			}
		}elseif($flag == 4){
			for($i = $startWeek; $i <= $endWeek; $i++){
				$aWeekList[] = array(
					'year' => date('Y'),
					'week' => $i
				);
			}
		}
		assign('aWeekList', array_reverse($aWeekList));

		//本周排行
		$startTime = strtotime(date('Y') . 'W' . date('W'));
		$endTime = strtotime('+1 week', $startTime) - 1;
		$mMission = m('Mission');
		if($aUserInfo['xxt_type'] == 3){
			$aCondition = array(
				'xxt_type' => 3,
				'start_time' => $startTime,
				'end_time' => $endTime
			);
			$aControl = array(
				'page' => 1,
				'page_size' => 10
			);
			$aWeekMissionRankingList = $mMission->getXxtTypePassMissionCountRankingList($aCondition, $aControl);
		}else{
			$aWeekMissionRankingList = $mMission->getPassMissionCountRankingList(1, 10, 0, $startTime, $endTime, array('class'));
		}
		if($aWeekMissionRankingList === false){
			alert('系统出错，请稍后再试', 0);
		}
		assign('aWeekMissionRankingList', $aWeekMissionRankingList);

		assign('isActivityStatus', $flag);
		assign('aUserInfo', $aUserInfo);
		assign('missionActivityEndTime', self::MISSION_END_TIME);
		display('activity/activity_mission.html.php');
	}

	public static function getWeekRankingList(){
		$aUserInfo = isLogin();
		if(!$aUserInfo){
			$aParentInfo = isParentLogin();
			if($aParentInfo){
				$aUserInfo = array(
					'id' => 0,
					'name' => '',
					'xxt_type' => $aParentInfo['extend_type']
				);
			}else{
				checkUserLogin();
			}
		}
		$year = intval(post('year'));
		$week = intval(post('weeks'));
		if(!$year || !$week){
			alert($week . '参数错误' .$year, 0);
		}

		$startTime = strtotime($year . 'W' . $week);
		$endTime = strtotime('+1 week', $startTime) - 1;
		if($aUserInfo['xxt_type'] == 3){
			$aCondition = array(
				'xxt_type' => 3,
				'start_time' => $startTime,
				'end_time' => $endTime
			);
			$aControl = array(
				'page' => 1,
				'page_size' => 10
			);
			$aWeekMissionRankingList = m('Mission')->getXxtTypePassMissionCountRankingList($aCondition, $aControl);
		}else{
			$aWeekMissionRankingList = m('Mission')->getPassMissionCountRankingList(1, 10, 0, $startTime, $endTime, array('class'));
		}
		if($aWeekMissionRankingList === false){
			alert('系统出错，请稍后再试', 0);
		}
		alert('获取成功', 1, $aWeekMissionRankingList);
	}

	public static function getBbsMission(){
		$oBbs = m('Bbs');
		$aArticle = $oBbs->getThreadInfoById(186);
		$aArticle = str_replace('<p><strong><span style="color:#ff0000">活动链接：</span><a href="http://www.umfun.com/activity/mission.html" target="_self"><span style="color:#000000">http://www.umfun.com/activity/mission.html</span></a></strong></p>', '', $aArticle);
		assign('aArticle', $aArticle);
		display('activity/bbs_mission.html.php');
	}
}
