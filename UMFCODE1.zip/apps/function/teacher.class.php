<?php

class Teacher{

	/**
	 * 获取题目详情
	 */
	public static function getEsDetail($id){
		$oEs = m('Es');
		$aEs = $oEs->getOfficialEsInfoById($id);
		if(!$aEs){
			return false;
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
		$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
		$aEs['id'] = Xxtea::encrypt($aEs['id']);
		return $aEs;
	}


	/**
	 * 获取关卡列表
	 */
	public static function getMissionList($gradeId, $subjectId){
		$oMission = m('Mission');
		$aMissionList = array();
		$aSubjectMissionList = $oMission->getOriginalMissionList($subjectId, null, null);
		if(!$aSubjectMissionList){
			return $aSubjectMissionList;
		}
		//分年级，以关卡名字第一位数字区分；比如：关卡‘52044 3.1长方体和正方体的认识’为5年级
		foreach($aSubjectMissionList as $aSubjectMission){
			$missionName = trim($aSubjectMission['name']);
			$grade = substr($missionName, 0, 1);
			if($grade == $gradeId){
				array_push($aMissionList, $aSubjectMission);
			}
		}
		return $aMissionList;
	}

	/**
	 * 获取学生成绩列表
	 */
	public static function getStudentMarkList($page, $missionId, $aUserIds){
		if(!is_array($aUserIds)){
			return false;
		}
		if(!$aUserIds){
			$aUserIds = array(0);
		}
		$orderType = intval(post('orderType'));
		if($orderType == 1){
			$order = '`score` DESC';
		}else{
			$order = '`score` ASC';
		}
		if($page < 0){
			$page = 1;
		}
		$oMission = m('Mission');
		$aStudent = array();
		$aStudent['list'] = $oMission->getTopScoreUserListByMissionIdAndUserIds($missionId, $aUserIds, $order, $page, 10);
		$nums = $oMission->getTopScoreUserCountByMissionIdAndUserIds($missionId, $aUserIds);
		if($nums){
			$aStudent['total_page'] = ceil($nums / 10);
		}else{
			$aStudent['total_page'] = 1;
		}
		return $aStudent;
	}

	/**
	 * 获取题目列表
	 */
	public static function getEsList($page, $missionId, $type){
		if($type == 1){
			$order = 'correct_percent ASC';
		}else{
			$order = 'correct_percent DESC';
		}
		$oEs = m('Es');
		$aEs = array();
		$aEs['list'] = $oEs->getOfficialEsListByMissionId($missionId, $page, 10, $order);
		if(!$aEs['list']){
			$aEs['list'] = array();
		}
		foreach($aEs['list'] as $key => $aThisEs){
			$aEs['list'][$key]['id'] = Xxtea::encrypt($aThisEs['id']);
		}
		$nums = $oEs->getOfficialEsCountByMissionId($missionId);
		if($nums){
			$aEs['total_page'] = ceil($nums / 10);
		}else{
			$aEs['total_page'] = 1;
		}
		return $aEs;
	}
	/**
	 *  文章列表
	 *
	 */
	public static function showEducation($name){
		$oTeacher = m('EduNews');
		$aNewsContentList = $oTeacher->getNewsContentList();
		if($aNewsContentList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		assign('aNewsContentList', $aNewsContentList);
		displayHeader('教育资讯', $name);
		display('education/education_list.html.php');
		displayFooter();
	}

	/**
	 *  文章内容
	 *
	 */
	public static function showArticle($id, $name){
		$teacherListId = (int)$id;
		if(!$teacherListId){
			alert('参数有误！', 0);
		}

		$oTeacher = m('EduNews');
		$aNewsContentInfo = $oTeacher->getNewsContentInfo($id);
		if($aNewsContentInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		if(!$aNewsContentInfo){
			alert('参数有误', 0);
		}

		assign('aNewsContentInfo', $aNewsContentInfo);
		displayHeader('教育资讯', $name);
		display('education/article.html.php');
		displayFooter();
	}

}