<?php

/**
 * 【需要外部加载用户信息】
 */

class TeachersDay{

	const CLIENT_MOBILE = 0;
	const CLIENT_PC = 1;

	/**
	 * 展示
	 * $type = 0 手机   1 PC
	 */
	public static function showActivity($clientType = 0){
		$aUserInfo = isLogin();
		$userId = intval($aUserInfo['id']);
		$oTeachersDay = m('TeacherDay');
		//当前学生数据信息
		$aThisUserSend = $oTeachersDay->getTeacherDayStudentInfo($userId);
		if($aThisUserSend === false){
			alert('系统错误', 0 );
		}else if(!$aThisUserSend){
			$aThisUserSend = array(
				'id' => $userId,
				'xin_number' => 0,
				'today_remainder_number' => 1,
				'last_send_time' => 0,
				'share_time' => 0
			);

			if($aUserInfo['xxt_id']){
				$oTeachersDay->addTeacherDayStudent($aThisUserSend);
				$aThisUserSend = $oTeachersDay->getTeacherDayStudentInfo($userId);
			}
		}
		assign('aThisUserSend', $aThisUserSend);

		//达到50心排行版
		$a50XinTeacher = $oTeachersDay->getReachPointNumTeacherList(5, 1);
		$count50XinTeacher = $oTeachersDay->getReachPointNumTeacherCount(1);
		assign('a50XinTeacher', $a50XinTeacher);
		assign('count50XinTeacher', $count50XinTeacher);
		
		//教师礼品
		$aGift = array(
			'xin100' =>	array('name' => '价值200元京东购物券', 'min' => '', 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/1.jpg' . $GLOBALS['RESOURCE']['version']),
			'xin50' => 	array('name' => '精美贺卡1张', 'min' => '', 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/2.jpg' . $GLOBALS['RESOURCE']['version']),
			'teacher' => array(
				array('name' => '茶具', 'min' => '第1名', 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/3.jpg' . $GLOBALS['RESOURCE']['version']),
				array('name' => '脊椎按摩器', 'min' => '2-5名', 'max' => 20, 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/4.jpg' . $GLOBALS['RESOURCE']['version']),
				array('name' => '棉性椅垫', 'min' => '6-20名', 'max' => 30, 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/5.jpg' . $GLOBALS['RESOURCE']['version'])
			) ,
			'student' => array(
				array('name' => '自行车', 'min' => '第1名', 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/6.jpg' . $GLOBALS['RESOURCE']['version']),
				array('name' => '键盘鼠标套', 'min' => '2-5名', 'max' => 20, 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/7.jpg' . $GLOBALS['RESOURCE']['version']),
				array('name' => '30Q币', 'min' => '6-20名', 'max' => 30, 'link' => '#', 'img' => SYSTEM_RESOURCE_URL . '/data/activity/teachers_day/8.jpg' . $GLOBALS['RESOURCE']['version'])
			)
		);
		assign('aGift', $aGift);
		
		//学生排行榜
		$aStudentRankList = $oTeachersDay->getStudentRankingList(20);
		if($aStudentRankList === false){
			alert('系统错误', 0 );
		}
		foreach($aStudentRankList as $key => $aStudentRankInfo){
			$studenSchoolName = $aStudentRankInfo['user_info']['school_name'];
			$aStudentRankList[$key]['user_info']['school_name'] = $studenSchoolName == '和教育产品经理学校' ? '广州新概念实验学校' : $studenSchoolName;
		}
		assign('aStudentRankList', $aStudentRankList);
		
		assign('aUserInfo', $aUserInfo);
		display('activity/nav.html.php');
		display('activity/teachers_day.html.php');
		if($clientType){
			displayFooter();
		}
		
	}

	/**
	 * 分享一条微博
	 */
	public static function share(){
		alert('很感谢您的参与，活动已经圆满落幕，期待您的下次参与。', -1);

		$content = '用心感恩，教师节献礼。参与赢大奖，赶快来参加吧~';
		$aUserInfo = self::_getUserInfo();
		if(empty($aUserInfo['xxt_id'])){
			alert('您不是和教育用户', -1);
		}
		
		$oTeachersDay = m('TeacherDay');
		$aCheckThisUser = $oTeachersDay->getTeacherDayStudentInfo($aUserInfo['id']);
		if($aCheckThisUser === false){
			alert('系统错误', 0 );
		}else if($aCheckThisUser){
			if($aCheckThisUser['share_time'] > strtotime(date('Y-m-d 00:00:00')) || $aCheckThisUser['today_remainder_number'] > 2 ){
				alert('很抱歉，您已经分享过了,请明天继续加油', -1);
			}
		}

		$aContent = array(
			'Content' => $content,
			'MsgType' => 1,
			'HasAttachment' => 0,
			'PathAndName' => '',
			'ThumbPath' => '',
			'City' => $aUserInfo['xxt_data']['CityId']
		);
		$aReasult = Xxt::postAddWeibo($aUserInfo['xxt_data']['UserId'], $aContent);
		if($aReasult['Result'] != 200){
			alert($aReasult, 0);
		}
		
		$aStudent = array(
			'id' => $aUserInfo['id'],
			'share_time' => time()
		);
		if(!$aCheckThisUser){
			$aStudent['today_remainder_number'] = 2;
			$aResult = $oTeachersDay->addTeacherDayStudent($aStudent);
		}else{
			if($aCheckThisUser['today_remainder_number'] < 3){
				$aStudent['today_remainder_number'] = array('add', 1) ;
			}
			$aResult = $oTeachersDay->updateTeacherDayStudent($aStudent);
		}
		$aResult ? alert('分享成功', 1) : alert('分享失败', 0) ;
	}

	/**
	 * 赠送
	 */
	public static function giving(){
		alert('很感谢您的参与，活动已经圆满落幕，期待您的下次参与。', -1);

		$aUserInfo = self::_getUserInfo();
		if(empty($aUserInfo['xxt_id'])){
			alert('您不是和教育用户', -1);
		}

		$cityId = post('cityId');
		$teachersId = intval(post('teacherId', 0));
		$id = intval(post('id', 0));
		if(!$teachersId || !$cityId || strlen($cityId) > 5){
			alert('错误的参数', 0);
		}
		
		$oTeachersDay = m('TeacherDay');
		$aTeachers = $oTeachersDay->getTeacherDayTeacherInfo($teachersId, $cityId);
		if($aTeachers === false){
			alert('系统错误', 0);
		}
		
		try{
			$aTeacherInfo = Xxt::getTeacherInfo($teachersId, $cityId);
			$aSchoolInfo = Xxt::getSchoolInfo($aTeacherInfo['SchoolId']);
		}catch(XxtException $e){
			halt($e->getMessage());
		}
		
		$aTeachersData = array(
			'xxt_teacher_id' => $teachersId,
			'city_id' => $cityId,
			'last_receive_time' => time(),
			'xxt_data' => array(
				'teacher_info' => $aTeacherInfo,
				'school_info' => $aSchoolInfo
			)
		);

		if(!$aTeachers){
			$aCheckThisUser = $oTeachersDay->getTeacherDayStudentInfo($aUserInfo['id']);
			if($aCheckThisUser === false){
				alert('系统错误', 0 );
			}else if($aCheckThisUser){
				if($aCheckThisUser['today_remainder_number'] == 0){
					alert('您今天可用赠送心已经使用完，请明天继续加油喔!', -1);
				}
				$aUpdateStudent = array(
					'id' => $aUserInfo['id'],
					'xin_number' =>  array('add', 1),
					'today_remainder_number' => array('sub', 1),
					'last_send_time' => time()
				);
				
				$aStudentResult = $oTeachersDay->updateTeacherDayStudent($aUpdateStudent);
				if(!$aStudentResult){
					alert('赠送失败', 0);
				}
			}
			
			$aTeachersData['xin_number'] = 1;
			$aResult = $oTeachersDay->addTeacherDayTeacher($aTeachersData);
		}else{
			if(!$id){
				alert('错误的参数', 0);
			}
			
			$aCheckThisUser = $oTeachersDay->getTeacherDayStudentInfo($aUserInfo['id']);
			if($aCheckThisUser === false){
				alert('系统错误', 0 );
			}else if($aCheckThisUser){
				if($aCheckThisUser['today_remainder_number'] == 0){
					alert('您今天可用赠送心已经使用完，请明天继续加油喔!', -1);
				}
				$aUpdateStudent = array(
					'id' => $aUserInfo['id'],
					'xin_number' =>  array('add', 1),
					'today_remainder_number' => array('sub', 1),
					'last_send_time' => time()
				);
				
				$aStudentResult = $oTeachersDay->updateTeacherDayStudent($aUpdateStudent);
				if(!$aStudentResult){
					alert('赠送失败', 0);
				}
			}
			
			if($aTeachers['xin_number'] == 99 ){
				$aTeachersData['reach_100_time'] = time();
			}
			
			$aTeachersData['id'] = $id;
			$aTeachersData['xin_number'] = array('add', 1);
			$aResult = $oTeachersDay->updateTeacehrDayTeacher($aTeachersData);
		}
		$aResult ? alert('赠送成功', 1) : alert('赠送失败', 0) ;
	}

	/**
	 * Ajax获取教师列表
	 */
	public static function getXxtTeacherList(){
		$aStudentXxtId = self::_getUserInfo();
		if(!$aStudentXxtId['xxt_id']){
			alert('您不是和教育用户', 0);
		}
		if(!$aStudentXxtId['xxt_data']){
			alert('很抱歉，您数据不完整，请尝试使用和教育账号方式登陆', 0);
		}
		
		try{
			$aXxtStudenInfo = Xxt::getStudentInfo($aStudentXxtId['xxt_data']['UserId'], $aStudentXxtId['xxt_data']['CityId']);
		}catch(XxtException $e){
			halt($e->getMessage());
		}
		
		$aStudenClassAndSchool = array(
			'class_id' => $aXxtStudenInfo['StudentEntity']['ClassId'],
			'school_id' => $aXxtStudenInfo['StudentEntity']['SchoolId']
		);

		$aXxClassAndTeacherInfo = Xxt::getClassAndTeacher($aStudenClassAndSchool['class_id']);
		if($aXxClassAndTeacherInfo['Result'] != 200){
			alert($aXxClassAndTeacherInfo['Desc'], 0);
		}

		$oTeachersDay = m('TeacherDay');
		//转换数组，前台操作比较方便
		foreach($aXxClassAndTeacherInfo['MSG_BODY']['Relations'] as $key => $aVal){
			if(isset($aVal['TeacherId'])){
				$aTeachers = $oTeachersDay->getTeacherDayTeacherInfo($aVal['TeacherId'], $aStudentXxtId['xxt_data']['CityId']);
				$aTeachersInfo = array();
				if(!$aTeachers){
					$aTeachersInfo = array(
						'id' => 0,
						'xin_number' => 0,
						'today_remainder_number' => 0,
						'last_send_time' => 0,
						'share_time' => 0,
						'xxt_data' => ''
					);
				}else{
					$aTeachersInfo = $aTeachers;
				}
				$aXxtteacherList[] = array_merge($aTeachersInfo, $aVal);
			}else{
				foreach($aVal as $k => $teacherInfo){
					$aTeachers = $oTeachersDay->getTeacherDayTeacherInfo($teacherInfo['TeacherId'], $aStudentXxtId['xxt_data']['CityId']);
					$aTeachersInfo = array();
					if(!$aTeachers){
						$aTeachersInfo = array(
							'id' => 0,
							'xin_number' => 0,
							'today_remainder_number' => 0,
							'last_send_time' => 0,
							'share_time' => 0,
							'xxt_data' => ''
						);
					}else{
						$aTeachersInfo = $aTeachers;
					}
					$aXxtteacherList[] = array_merge($aTeachersInfo, $teacherInfo);
				}
			}
			
		}
		alert($aStudentXxtId['xxt_data']['CityId'], 1, $aXxtteacherList);
	}

	private static function _getUserInfo(){
		$aUser = isLogin();
		if(!$aUser){
			alert('您必须先使用广东和教育学生账号登陆才能参与本次活动', 0);
		}
		return getUserInfo($aUser['id'], array('personal'));
	}
}