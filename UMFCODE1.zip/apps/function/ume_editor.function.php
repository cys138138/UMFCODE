<?php

/**
 * 将左右两边的空格和回车都去掉,中间的回车换成空格
 */
function ueTrim($content){
	$content = preg_replace('/<div><br><\/div>|<br>|<br\/>|<\/br>|<p>&nbsp;<\/p>/', ' ', $content);
	$content = preg_replace('/\s+/', ' ', $content);
	return $content;
}


/**
 * 返回过滤表情和@用户标记后所计算出来的字数长度,一个表情和一个@标记占一个字数长度
 */
function ueGetLength($content){
	$content = preg_replace('/&lt;/', '<', $content);
	$content = preg_replace('/&gt;/', '>', $content);
	$content = preg_replace('/<button[^>]+>[^<]+<\/button>|<img[^>]+>|\[at\]([^\[]+)\[\/at\]|\[face\]([^\[]+)\[\/face\]/', '#', $content);
	$content = preg_replace('/<div>|<\/div>|<br>|<br\/>|<\/br>|<p>|&nbsp;|<\/p>/', ' ', $content);
	$content = trim(preg_replace('/\s+/', ' ', $content));
	return mb_strlen($content);
}

/*
* 按照规则转换html到存储状态的字符串
*/

function ueEncodeContent($content){
	$atHtmlNull = '#&lt;button[^&]+&gt;&lt;\/button&gt;#i';
	$expressionHtml = '#&lt;img[^&]+sign="([^"]+)"[^&]*&gt;#i';
	$buttonBefore = '#&lt;button[^&]+&gt;#i';
	$buttonAfter = '#&lt;\/button&gt;#i';
	$putOffBr = '#&lt;\/br&gt;|&lt;br&gt;|&lt;br\/&gt;#i';
	$putOffHtml = '#&lt;[^&]+&gt;#i';
	$putOffSpace = '#\s+#i';
	$content = preg_replace($atHtmlNull, '', $content);
	$content = preg_replace($expressionHtml, '$1', $content);
	$content = preg_replace($buttonBefore, '[at]', $content);
	$content = preg_replace($buttonAfter, '[/at]', $content);
	$content = preg_replace($putOffBr, ' ', $content);
	$content = preg_replace($putOffHtml, '', $content);
	$content = preg_replace($putOffSpace, ' ', $content);
	return $content;	
}