<?php

/**
 * 团队赛事业务层
 * 罗启军
 * 455538375@qq.com
 * 很多时候，乐观的态度和好听的话帮不了你。
 */

class Team{
	//const FIRST_LUCKY_SCORE = 180;	//第一轮比赛可以抽奖的分数
	//const SECOND_LUCKY_SCORE = 180;	//第二轮比赛可以抽奖的分数
	const ONE_AVERAGE = 75;	//1人俊级平均分
	const TWO_AVERAGE = 65;	//2人俊级平均分
	const THREE_AVERAGE = 50;	//3人俊级平均分
	const FIRST_LUCKY_NUMS = 60;	//第一轮幸运奖数量
	const SECOND_LUCKY_NUMS = 30;	//第二轮幸运奖数量

	/**
	 * 新建队伍
	 */
	public static function createTeam(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$aUser = $aResult['data'];
		$now = time();
		if($now < $aUser['first_match']['match_start_time'] || $now > $aUser['first_match']['match_end_time']){
			alert('现在不是第一轮比赛时间，不能创建队伍', -1);
		}
		$oTeam = m('Team');
		$aTeam = $oTeam->checkCreate($aUser['match_id'], $aUser['id']);
		if($aTeam){
			alert('您在 ' . $aTeam['name'] . ' 队伍当中，不能重复创建队伍', -1);
		}
		$name = post('name');
		if(!$name){
			alert('给您的队伍起个霸气的名字吧', -1);
		}
		$aData = array(
			'name' => $name,
			'member_one' => $aUser['id'],
			'match_id' => $aUser['match_id'],
			'prize_list' => array('first_lucky' => 0, 'second_lucky' => 0, 'rank' => 0),	//对应1轮幸运奖，2轮幸运奖，名次奖励
			'create_time' => $now,
		);
		$teamId = $oTeam->addJoin($aData);
		if($teamId){
			$aData['id'] = $teamId;
			alert('成功创建队伍 ', 1, $aData);
		}else{
			alert('创建队伍失败', 0);
		}
	}


	/**
	 * 加入队伍
	 */
	public static function joinTeam(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$aUser = $aResult['data'];
		$now = time();
		if($now < $aUser['first_match']['match_start_time'] || $now > $aUser['first_match']['match_end_time']){
			alert('现在不是第一轮比赛时间，不能加入队伍', -1);
		}
		
		$id = intval(post('id'));
		$oTeam = m('Team');
		$aTeam = $oTeam->getJoinById($id);
		if(!$aTeam){
			alert('ID为 ' . $id . ' 的队伍不存在，请和您的小伙伴确认一下', -1);
		}
		$aCreater = $oTeam->getUserInfoById($aTeam['member_one']);
		if($aTeam['member_three'] && $aTeam['member_two']){
			alert('<em>“' . $aCreater['name'] . '”</em>创建的队伍人数满了', -1);
		}
		if($aTeam['member_one'] == $aUser['id'] || $aTeam['member_two'] == $aUser['id'] || $aTeam['member_three'] == $aUser['id']){
			alert('您已经在<em>“' . $aCreater['name'] . '”</em>的队伍了', -1);
		}
		
		$aCheckTeam = $oTeam->checkJoin($aUser['match_id'], $aUser['id']);
		$memberNums = 0;
		if($aCheckTeam){
			$memberNums++;
			if($aCheckTeam['member_two']){
				$memberNums++;
			}
			if($aCheckTeam['member_three']){
				$memberNums++;
			}
			if($memberNums >= 2){
				alert('您所在的<em>“' . $aCheckTeam['name'] . '”</em>队伍人数达到2人以上，不能加入其他队伍啦', -1);
			}
		}
		
		$aData = array('id' => $aTeam['id']);
		if(!$aTeam['member_two']){
			$aData['member_two'] = $aUser['id'];
			if($aCheckTeam){
				$aData['first_two_score'] = $aCheckTeam['first_one_score'];
			}
		}else{
			$aData['member_three'] = $aUser['id'];
			if($aCheckTeam){
				$aData['first_three_score'] = $aCheckTeam['first_one_score'];
			}
		}
		$set = $oTeam->setJoin($aData);
		if($set){
			if($aCheckTeam){
				$oTeam->deleteJoinById($aCheckTeam['id']);
			}
			alert('成功加入 ' . $aTeam['name'], 1, $aCreater);
		}else{
			alert('加入队伍失败', 0);
		}

	}

	/**
	 * 抽奖
	 */
	public static function luckDraw(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$aUser = $aResult['data'];

		$oTeam = m('Team');
		$id = intval(post('id'));
		$aTeam = $oTeam->getJoinById($id);
		if(!$aTeam){
			alert('ID为 ' . $id . ' 的队伍不存在', -1);
		}
		if($aUser['id'] != $aTeam['member_one']){
			alert('队长才可以抽奖喔', -1);
		}
		
		$round = intval(post('round'));
		if($round == 1){
			$sequence = 'first';
			$name = '一';
			$limitPrizes = self::FIRST_LUCKY_NUMS;
		}else{
			$sequence = 'second';
			$name = '二';
			$limitPrizes = self::SECOND_LUCKY_NUMS;
		}
		if($aTeam['prize_list'][$sequence.'_lucky'] != 0){
			alert('你们的队伍已经抽过第' . $name . '轮幸运奖', -1);
		}

		$memberCount = 1;
		$passScore = Team::ONE_AVERAGE;
		$total = $aTeam[$sequence.'_one_score'];
		if($aTeam['member_two']){
			$memberCount = 2;
			$passScore = Team::TWO_AVERAGE;
			$total += $aTeam[$sequence.'_two_score'];
		}
		if($aTeam['member_three']){
			$memberCount = 3;
			$passScore = Team::THREE_AVERAGE;
			$total += $aTeam[$sequence.'_three_score'];
		}
		if(($total / $memberCount) < $passScore){
			alert('您的团队现在有 '. $memberCount .' 名成员，平均分要达到 ' . $passScore . ' 分才进行第' . $name . '轮抽奖', -1);
		}

		$aMatch = $oTeam->getMatchById($aTeam['match_id']);
		$prize = $sequence.'_lucky';
		$prizeCount = $oTeam->countLuckyPrizes($aTeam['match_id'], $prize);
		if($prizeCount >= $limitPrizes){
			$rand = rand(6, 100);
		}else{
			$rand = rand(1, 100);
		}
		if($rand >= 1 && $rand <= 5){
			$aTeam['prize_list'][$sequence.'_lucky'] = $aMatch['prizes'][$sequence.'_lucky'];
			$aData = array('id' => $aTeam['id'], 'prize_list' => $aTeam['prize_list']);
			$oTeam->setJoin($aData);
			$prizeId = 0;
			alert('恭喜抽中幸运奖', 1, $prizeId);
		}elseif($rand >= 6 && $rand <= 20){
			if($round == 1){
				$gold = 20;
			}else{
				$gold = 30;
			}
			$prizeId = 4;
		}elseif($rand >= 21 && $rand <= 40){
			if($round == 1){
				$gold = 10;
			}else{
				$gold = 20;
			}
			$prizeId = 3;
		}elseif($rand >= 41 && $rand <= 70){
			if($round == 1){
				$gold = 5;
			}else{
				$gold = 10;
			}
			$prizeId = 2;
		}elseif($rand >= 71 && $rand <= 100){
			if($round == 1){
				$gold = 2;
			}else{
				$gold = 5;
			}
			$prizeId = 1;
		}
		$aTeam['prize_list'][$sequence.'_lucky'] = -1;
		$aData = array('id' => $aTeam['id'], 'prize_list' => $aTeam['prize_list']);
		$oTeam->setJoin($aData);

		$oNum = new Numerical();
		$oNum->addMoney($aTeam['member_one'], 17, $gold);
		if($aTeam['member_two']){
			$oNum->addMoney($aTeam['member_two'], 17, $gold);
		}
		if($aTeam['member_three']){
			$oNum->addMoney($aTeam['member_three'], 17, $gold);
		}
		alert('恭喜抽中 ' . $gold . ' 金币', 1, $prizeId);

	}

	/**
	 * 填写地址信息
	 */
	public static function fillInfo(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$aUser = $aResult['data'];

		$oTeam = m('Team');
		$id = intval(post('id'));
		$aTeam = $oTeam->getJoinById($id);
		if(!$aTeam){
			alert('ID为 ' . $id . ' 的队伍不存在', -1);
		}

		if($aTeam['member_one'] != $aUser['id'] && $aTeam['member_two'] != $aUser['id'] && $aTeam['member_three'] != $aUser['id']){
			alert('喂喂那个谁，这个不是你的队伍喔，改什么改', -1);
		}
		$phone = post('phone');
		$address = post('address');
		$consignee = post('consignee');
		if(!$phone){
			alert('请填写收奖品人联系电话', -1);
		}
		if(!$address){
			alert('请填写收奖品人地址', -1);
		}
		if(!$consignee){
			alert('请填写收奖品人姓名', -1);
		}
		$aData = array(
			'id' => $aTeam['id'],
			'phone' => $phone,
			'address' => $address,
			'consignee' => $consignee,
		);
		if($oTeam->setJoin($aData)){
			alert('修改成功', 1);
		}else{
			alert('修改失败', 0);
		}

	}


	/**
	 * 检查活动信息
	 */
	public static function checkActive(){
		$oTeam = m('Team');
		$id = $oTeam->getNewestMatchId(0);
		if(!$id){
			return array('status' => 2, 'msg' => '赛事不存在', 'data' => '');
		}
		$aMatch = $oTeam->getMatchById($id);
		if(!$aMatch){
			return array('status' => 2, 'msg' => '赛事不存在', 'data' => '');
		}

		$oMatch = m('Match');
		$aFirstMatch = $oMatch->getMatchInfoById($aMatch['first_match_id']);
		if(!$aFirstMatch){
			return array('status' => 2, 'msg' => '赛事不存在', 'data' => '');
		}
		if($aFirstMatch['match_start_time'] > time()){
			return array('status' => 3, 'msg' => '该赛事还未开始', 'data' => '');
		}

		$aSecondMatch = $oMatch->getMatchInfoById($aMatch['second_match_id']);
		if(!$aSecondMatch){
			return array('status' => 2, 'msg' => '赛事不存在', 'data' => '');
		}
		if($aSecondMatch['match_end_time'] < time()){
			return array('status' => 3, 'msg' => '该赛事已经结束', 'data' => '');
		}

		$aUser = isLogin();
		if($aUser){
			$oUser = m('User');
			$aUserInfo = $oUser->getPersonalInfoByUserId($aUser['id']);
			if(!$aUser['xxt_id']){
				return array('status' => 4, 'msg' => '抱歉！本活动只限广东和教育用户参加', 'data' => '');
			}
			$aUser['xxt_data'] = $aUserInfo['xxt_data'];
		}else{
			return array('status' => 5, 'msg' => '请先登陆', 'data' => '');
		}
		$aUser['match_id'] = $id;
		$aUser['match'] = $aMatch;
		$aUser['first_match'] = $aFirstMatch;
		$aUser['second_match'] = $aSecondMatch;
		return array('status' => 1, 'msg' => 'OK', 'data' => $aUser);


	}


}