<?php
/**
 * Description of vip_permission
 *
 * @author Administrator
 */
class Vip{
	private $_userId = 0;
	private $_aNum = array();

	public function __construct($userId){
		$this->_userId = $userId;
		$oNum = m('UserNumerical');
		if($aNum = $oNum->getUserNumericalInfoById($this->_userId)){
			$this->_aNum = $aNum;
		}elseif($aNum === false){
			alert('抱歉，网络可能有点慢', 0);
		}
	}

	/**
	 * 判断是否VIP用户
	 * @return boolean
	 */
	public function isVip(){
		if($this->_aNum['vip'] && $this->_aNum['vip_expiration_time'] > time()){
			return $this->_aNum;
		}else{
			return false;
		}
	}

	/**
	 * 判断是否超过了限制修复错题的限制
	 * @return boolean
	 */
	public function isAllowRepairWrongEs(){
		$mVip = m('Vip');
		$aVipPrivitege = $mVip->getVipPrivitegeInfo($this->_userId);
		if(!$aVipPrivitege){
			alert('读取会员信息出错', 0);
		}
		return $aVipPrivitege;
		if(date('Ymd') >= date('Ymd', $aVipPrivitege['last_repair_time']) || $aVipPrivitege['repair_es_count'] < $GLOBALS['VIP'][$this->_aNum['vip']]['repair_wrong']){
			return $aVipPrivitege;
		}else{
			return false;
		}
	}
}
