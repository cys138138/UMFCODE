<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-12-27
 */
class Numerical{
	private $_aPointType = array(
		1,	//新手任务：闯关成功
		2,	//新手任务：PK，自己完成
		3,	//新手任务：报名一场比赛
		4,	//新手任务：完善个人资料
		5,	//新手任务：激活邮箱
		6,	//说说
		7,	//普通答对题目
		8,	//修炼完成
		9,	//挑战完成
		10,	//破自己记录
		11,	//破世界记录
		12,	//PK胜利奖励
		13, //比赛奖励
		14,	//蓝宝箱
		15, //加好友
		16, //勋章升级
		17, //被邀请注册
		18, //注册抽奖、安慰奖
		19, //注册抽奖、一等奖
		20, //注册抽奖、二等奖
		21, //注册抽奖、三等奖
		22, //会员每日大礼包,包括金币经验和道具
		23, //比赛结束
		24, //每日任务
	);

	private $_aMedalType = array(
		//1,	//身经百战
		2,	//过关斩将
		3,	//箭无虚发
		//4,	//毫发无损
		//5,	//PK战神
		6,	//PK胜者
		//7,	//赛事达人
		//8,	//赛事奖者
		//9,	//妙语连珠
	);

	public static $aIdMedalRelation = array(
		/**1 => array(
				'db_field' => 'challenge_times',
				'config_key' => 'CHALLENGE_TIMES_MEDAL',
			),
		*/
		2 => array(
				'db_field' => 'passed_missions',
				'config_key' => 'PASSED_MISSIONS_MEDAL',
			),
		3 => array(
				'db_field' => 'excellent_missions',
				'config_key' => 'EXCELLENT_MISSIONS_MEDAL',
			),
		/**
		4 => array(
				'db_field' => 'perfect_missions',
				'config_key' => 'PERFECT_MISSIONS_MEDAL',
			),
		5 => array(
				'db_field' => 'pk_times',
				'config_key' => 'PK_ZHAN_MEDAL',
			),
		*/
		6 => array(
				'db_field' => 'pk_win_times',
				'config_key' => 'PK_WIN_MEDAL',
			),
		/**
		7 => array(
				'db_field' => 'match_times',
				'config_key' => 'MATCH_DA_MEDAL',
			),
		8 => array(
				'db_field' => 'match_win_times',
				'config_key' => 'MATCH_REWARD_MEDAL',
			),
		9 => array(
				'db_field' => 'comment_support_times',
				'config_key' => 'SPARKLING_DISCOURSE_MEDAL',
			),
		**/
	);

	/**
	 * 添加用户的经验
	 * @param $userId
	 * @param $action
	 * @param $esCount
	 */
	public function addAccumulatePoints($userId, $action, $data = 0){
		if(!in_array($action, $this->_aPointType)){
			return false;
		}
		$aUserNumeric = array();
		$aUserNumeric['id'] = $userId;
		$oUserNumerical = m('UserNumerical');
		$aCurrentNumeric = $oUserNumerical->getUserNumericalInfoById($userId);

		if(!$aCurrentNumeric){
			$aCurrentNumeric = array(
				'id' => $userId,
				'ub' => 0,
				'level' => 1,
				'gold' => 0,
				'accumulate_points' => 0,
				'vip' => 0,
				'integral_card_expiration_time' => 0,
				'vip_expiration_time' => 0,
			);
			if(!$oUserNumerical->addUserNumerical($aCurrentNumeric)){
				return false;
			}
		}
		$aUserNumeric['accumulate_points'] = $aCurrentNumeric['accumulate_points'];
		$currentPoints = $aCurrentNumeric['accumulate_points'];

		if($action == 1){
			$addPoint = $GLOBALS['POINT']['new']['mission'];
		}elseif($action == 2){
			$addPoint = $GLOBALS['POINT']['new']['pk'];
		}elseif($action == 3){
			$addPoint = $GLOBALS['POINT']['new']['join_match'];
		}elseif($action == 4){
			$addPoint = $GLOBALS['POINT']['new']['perfect_information'];
		}elseif($action == 5){
			$addPoint = $GLOBALS['POINT']['new']['active_email'];
		}elseif($action == 6){
			$addPoint = $GLOBALS['POINT']['shuoshuo'];
		}elseif($action == 7){
			$addPoint = $GLOBALS['POINT']['es'];
		}elseif($action == 8){
			$addPoint = intval($GLOBALS['POINT']['mission']['practice_extra_base'] * $data);
			if(isset($GLOBALS['UPDATE']['custom_data']['add_accumulate_points'])){
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] += $addPoint;
			}else{
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] = $addPoint;
			}
		}elseif($action == 9){
			$addPoint = intval($data['remaining_time'] / $data['total_time'] * 20 +
			($GLOBALS['POINT']['mission']['first_finish_mission_base'] - 20) * $data['corrcet_rate']);
			if(isset($GLOBALS['UPDATE']['custom_data']['add_accumulate_points'])){
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] += $addPoint;
			}else{
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] = $addPoint;
			}
		}elseif($action == 10){
			$addPoint = $data;
			if(isset($GLOBALS['UPDATE']['custom_data']['add_accumulate_points'])){
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] += $addPoint;
			}else{
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] = $addPoint;
			}
		}elseif($action == 11){
			$addPoint = intval($data / 100);
			if($addPoint < $GLOBALS['POINT']['mission']['breaking_world_record_min']){
				$addPoint = $GLOBALS['POINT']['mission']['breaking_world_record_min'];
			}elseif($addPoint > $GLOBALS['POINT']['mission']['breaking_world_record_max']){
				$addPoint = $GLOBALS['POINT']['mission']['breaking_world_record_max'];
			}

			if(isset($GLOBALS['UPDATE']['custom_data']['add_accumulate_points'])){
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] += $addPoint;
			}else{
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] = $addPoint;
			}
		}elseif($action == 12){
			$addPoint = $data;
			if(isset($GLOBALS['UPDATE']['custom_data']['add_accumulate_points'])){
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] += $addPoint;
			}else{
				$GLOBALS['UPDATE']['custom_data']['add_accumulate_points'] = $addPoint;
			}
		}elseif($action == 13){
			if($data['total_join'] < $GLOBALS['POINT']['match']['limit_join_min']){
				$data['total_join'] = $GLOBALS['POINT']['match']['limit_join_min'] / 10;
			}elseif($data['total_join'] > $GLOBALS['POINT']['match']['limit_join_max']){
				$data['total_join'] = $GLOBALS['POINT']['match']['limit_join_max'] / 10;
			}
			if($data['ranking'] == 1){
				$rate = $GLOBALS['POINT']['match']['first_rate'];
			}elseif($data['ranking'] == 2){
				$rate = $GLOBALS['POINT']['match']['second_rate'];
			}elseif($data['ranking'] == 3){
				$rate = $GLOBALS['POINT']['match']['third_rate'];
			}elseif($data['ranking'] >= 4 && $data['ranking'] <= 10){
				$rate = $GLOBALS['POINT']['match']['excellent_rate'];
			}elseif($data['ranking'] == 'lucky'){
				$rate = $GLOBALS['POINT']['match']['lucky_rate'];
			}
			if(is_numeric($data['ranking'])){
				//if(!$this->addMedal($userId, 8)){
					//return false;
				//}
			}
			$addPoint = intval($data['total_join'] * $rate);
		}elseif($action == 14){
			//蓝宝箱需要钥匙暂时不做
		}elseif($action == 15){
			$addPoint = $GLOBALS['POINT']['add_friend'];
		}elseif($action == 16){
			$addPoint = $data;
		}elseif($action == 17){
			$addPoint = $GLOBALS['POINT']['new']['invited'];
		}elseif($action == 18){//rotate
			$addPoint = $GLOBALS['POINT']['rotate_prizes'][3];
		}elseif($action == 19){
			$addPoint = $GLOBALS['POINT']['rotate_prizes'][4];
		}elseif($action == 20){
			$addPoint = $GLOBALS['POINT']['rotate_prizes'][5];
		}elseif($action == 21){
			$addPoint = $GLOBALS['POINT']['rotate_prizes'][6];
		}elseif($action == 22){
			$addPoint = $GLOBALS['VIP'][$data]['day_points'];
		}elseif($action == 23){
			$addPoint = $GLOBALS['POINT']['es'] * $data;
		}elseif($action == 24){
			$addPoint = $GLOBALS['POINT']['daily_tasks'][$data]['point'];
		}

		/*
		$GLOBALS['UPDATE']['numerical_data'] = array(
			'level' => 32,
			'accumulate' => 3400,
			'gold' => 3400,
			'ub' => 3400,
			'medal' => 9,
			'toy' => 10,
			'fav' => 3400,
			'error' => 3400
		);

		$result = array(
			'numerical_data' => array(
				'level' => 32,
				'accumulate' => 3400,
				'gold' => 3400,
				'ub' => 3400,
				'medal' => 9,
				'toy' => 3400,
				'fav' => 3400,
				'error' => 3400
			),
		);
		*/
		$now = time();
		if($aCurrentNumeric['integral_card_expiration_time'] > $now){
			$addPoint = $addPoint * 2;
		}
		if($aCurrentNumeric['vip_expiration_time'] > $now){
			$addPoint = intval($addPoint * $GLOBALS['VIP'][$aCurrentNumeric['vip']]['update']);
		}
		if($aCurrentNumeric['level'] < $this->updateUserLevel(end($GLOBALS['LEVEL']))){
			$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $addPoint;
		}
		if($aUserNumeric['accumulate_points'] > $currentPoints){
			$GLOBALS['UPDATE']['numerical_data']['accumulate'] = $aUserNumeric['accumulate_points'];
			$afterLevel = $this->updateUserLevel($aUserNumeric['accumulate_points']);
			if($afterLevel > $aCurrentNumeric['level']){
				$aUser = isLogin();
				if(isset($aUser['id']) && $userId == $aUser['id']){
					$GLOBALS['UPDATE']['numerical_data']['level'] = $afterLevel;
					$GLOBALS['UPDATE']['top_alert']['level'] = $afterLevel;
				}
				$aUserNumeric['level'] = $afterLevel;
				if(($afterLevel <= 40 && $afterLevel % 2 == 0) || $afterLevel > 40){
					if(!$this->addMoney($userId, 7, $afterLevel)){
						return false;
					}
				}
			}
			if($oUserNumerical->setUserNumerical($aUserNumeric) === false){
				return false;
			}
			return true;
		}
		return true;
	}

	/**
	 * 计算用户等级
	 * @param $userId
	 */
	public static function updateUserLevel($points){
		$count = count($GLOBALS['LEVEL']);
		for($i = $count - 1; $i >= 0; $i--){
			if($points >= $GLOBALS['LEVEL'][$i]){
				return $i + 1;
			}
		}
	}

	/**
	 * 添加Money U币或者金币
	 * @param $action 1签到  2错题反馈 3首次激活邮箱 4U币 5 PK金币 6比赛奖励 7个人升级奖励  8勋章升级
	 * 9注册抽奖-特等奖 10注册抽奖-一等奖 11注册抽奖-二等奖 12注册抽奖-三等奖 13会员每日大礼包 14每日任务 15抽将加5金币 16抽将加10金币 17团队比赛抽奖
	 */
	public function addMoney($userId, $action, $data = 0){
		if(!in_array($action, array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17))){
			return false;
		}

		$oUserNumerical = m('UserNumerical');
		$aUserNumeric = $oUserNumerical->getUserNumericalInfoById($userId);
		$currentGold = $aUserNumeric['gold'];
		$currentUB = $aUserNumeric['ub'];
		$addGold = 0;
		$addUb = 0;
		if($action == 1){
			//连续的天数
			$addGold = \common\business\Gold::getGold(\common\model\UserNumerical::CURRENCY_SCENE_Mark, ['markContinuousDay' => $data]);

			//下一天加的金币
			$nextContinueDay = $data + 1;
			if($nextContinueDay <= 2){
				$nextGold = $GLOBALS['GOLD']['mark'][2];
			}elseif($nextContinueDay > 2 && $nextContinueDay <= 6){
				$nextGold = $GLOBALS['GOLD']['mark'][6];
			}elseif($nextContinueDay > 6 && $nextContinueDay <= 14){
				$nextGold = $GLOBALS['GOLD']['mark'][14];
			}elseif($nextContinueDay > 14 && $nextContinueDay <= 30){
				$nextGold = $GLOBALS['GOLD']['mark'][30];
			}elseif($nextContinueDay > 30){
				$nextGold = $GLOBALS['GOLD']['mark'][31];
			}
			$GLOBALS['UPDATE']['custom_data']['gold'] = $addGold;
			$GLOBALS['UPDATE']['custom_data']['next_day_gold'] = $nextGold;

			//写动态从第六天开始，以后每天都写动态
			if($data >= 6){
				$aEventData = array(
					'user_id'	=> $userId,
					'type'		=> 21,
					'data_id'	=> 0,
					'data'		=>	[
						'gold' => $addGold,
						'day' => $data,
						'create_time' => time(),
					]
				);
				$oSnsEvent = m('SnsEvent');
				$oSnsEvent->addEvent($aEventData);
			}

		}elseif($action == 2){
			$addGold = $GLOBALS['GOLD']['feedback_wrong_es'];
		}elseif($action == 3){
			$addGold = $GLOBALS['GOLD']['verificate_mail'];
			//绑定了邮箱  写动态
			$aEventData = array(
				'user_id'	=> $userId,
				'type'		=> 30,
				'data_id'	=> 0,
				'data'		=>	[
					'gold' => $addGold,
					'create_time' => time(),
				]
			);
			$oSnsEvent = m('SnsEvent');
			$oSnsEvent->addEvent($aEventData);

		}elseif($action == 4){
			$addUb = $data;
		}elseif($action == 5){
			$addGold = $data;
		}elseif($action == 6){
			$addGold = $data;
		}elseif($action == 7){
			$addGold = $data;
		}elseif($action == 8){
			$addGold = $data;
		}elseif($action == 9){//rotate
			$addGold = $GLOBALS['GOLD']['rotate_prizes'][2];
		}elseif($action == 10){
			$addGold = $GLOBALS['GOLD']['rotate_prizes'][4];
		}elseif($action == 11){
			$addGold = $GLOBALS['GOLD']['rotate_prizes'][5];
		}elseif($action == 12){
			$addGold = $GLOBALS['GOLD']['rotate_prizes'][6];
		}elseif($action == 13){
			$addGold = $GLOBALS['VIP'][$data]['day_gold'];
			//写动态 领取了每日大礼包获得
			$aEventData = array(
				'user_id'	=> $userId,
				'type'		=> 29,
				'data_id'	=> 0,
				'data'		=>	[
					'gold' => $addGold,
					'create_time' => time(),
				]
			);
			$oSnsEvent = m('SnsEvent');
			$oSnsEvent->addEvent($aEventData);

		}elseif($action == 14){
			$addGold = $GLOBALS['POINT']['daily_tasks'][$data]['gold'];
		}elseif($action == 15){
			$addGold = $GLOBALS['GOLD']['rand_gold5'];
		}elseif($action == 16){
			$addGold = $GLOBALS['GOLD']['rand_gold10'];
		}elseif($action == 17){
			$addGold = $data;
		}

		$aUserNumeric['gold'] += $addGold;
		$aUserNumeric['ub'] += $addUb;

		if($aUserNumeric['gold'] > $currentGold){
			$GLOBALS['UPDATE']['numerical_data']['gold'] = $aUserNumeric['gold'];
		}
		if($aUserNumeric['ub'] > $currentUB){
			$GLOBALS['UPDATE']['numerical_data']['ub'] = $aUserNumeric['ub'];
		}
		$mStudent = \common\model\Student::findOne($userId);
		return $mStudent->addCurrency($addGold, $action);
		/*if($oUserNumerical->setUserNumerical($aUserNumeric) === false){
			return false;
		}else{
			if($addGold){
				$aGoldRecord = array(
					'user_id' => $userId,
					'get_type' => $action,
					'number' => $addGold,
					'create_time' => time(),
				);
				$oUserNumerical->addUserGoldRecord($aGoldRecord);
			}
			return true;
		}*/
	}

	/**
	 * 累加用户勋章统计
	 */
	public function addMedal($userId, $action){
		if(!in_array($action, $this->_aMedalType)){
			return false;
		}
		$oUserNumerical = m('UserNumerical');
		$aUserMedal = $oUserNumerical->getMedalInfoById($userId);
		if(!$aUserMedal){
			$aUserMedal = array();
			$aUserMedal['id'] = $userId;
			$aUserMedal['passed_missions'] = 0;
			$aUserMedal['excellent_missions'] = 0;
			$aUserMedal['pk_win_times'] = 0;
			$aUserMedal['gold_medal'] = 0;
			$aUserMedal['silver_medal'] = 0;
			$aUserMedal['cuprum_medal'] = 0;
			$aUserMedal['medal_process'] = array();
			if(!$oUserNumerical->addMedal($aUserMedal)){
				return false;
			}
		}

		$updateLevel = 0;
		$aMedal = array('id' => $userId);
		$dbField = self::$aIdMedalRelation[$action]['db_field'];	//勋章所对应的数据库字段名
		$configKey = self::$aIdMedalRelation[$action]['config_key'];	//序章所对应的配置的键值
		$aMedal[$dbField] = $aUserMedal[$dbField] + 1;

		if($aUserMedal[$dbField] >= $GLOBALS[$configKey][1]['nums']){
			$topLevel = count($GLOBALS[$configKey]);
			for($i = ($topLevel - 1); $i >= 1; $i--){
				$j = $i + 1;
				if($aUserMedal[$dbField] < $GLOBALS[$configKey][$j]['nums'] && $aMedal[$dbField] >= $GLOBALS[$configKey][$j]['nums']){
					$updateLevel = $j;
					break;
				}
			}
		}elseif($aMedal[$dbField] >= $GLOBALS[$configKey][1]['nums']){
			$updateLevel = 1;
		}

		if($updateLevel !== 0){
			if($updateLevel == 1){	//新勋章
				$medalNums = 0;
				foreach(self::$aIdMedalRelation as $medalId => $aSysMedal){
					if($aUserMedal[$aSysMedal['db_field']] >= $GLOBALS[$aSysMedal['config_key']][1]['nums']){
						$medalNums++;
					}
				}
				$medalNums++;
				$GLOBALS['UPDATE']['numerical_data']['medal'] = $medalNums;
			}
			$GLOBALS['UPDATE']['top_alert']['medal_level'] = array($action => $updateLevel);

			//更新勋章升级历史
			if(isset($aUserMedal['medal_process'][$dbField])){
				$aUserMedal['medal_process'][$dbField][$updateLevel] = time();
			}else{
				$aUserMedal['medal_process'][$dbField] = array($updateLevel => time());
			}
			$aMedal['medal_process'] = $aUserMedal['medal_process'];

			//勋章升级事件
			$oSns = m('SnsEvent');
			$aEvent = array(
				'user_id' => $userId,
				'type' => 8,
				'data_id' => $action . $updateLevel,
			);
			if(!$oSns->addEvent($aEvent)){
				return false;
			}

			//勋章升级加经验
			if(!$this->addAccumulatePoints($userId, 16, $GLOBALS[$configKey][$updateLevel]['point']) || !$this->addMoney($userId, 8, $GLOBALS[$configKey][$updateLevel]['gold'])){
				return false;
			}
		}

		if(!$oUserNumerical->setMedal($aMedal)){
			return false;
		}

		if($action == 2){
			$GLOBALS['UPDATE']['custom_data']['mission_medal'] = 1;
		}else if($action == 3){
			$GLOBALS['UPDATE']['custom_data']['mission_decoration'] = 1;
		}
		return $aMedal[$dbField];
	}

	/**
	 * 计算勋章等级
	 */
	public function countLevel($action, $val){
		$key = self::$aIdMedalRelation[$action]['config_key'];
		$topLevel = count($GLOBALS[$key]);
		for($i = $topLevel; $i >= 1; $i--){
			if($i == $topLevel){
				if($val >= $GLOBALS[$key][$i]['nums']){
					return $i;
				}
			}elseif($val >= $GLOBALS[$key][$i]['nums'] && $val < $GLOBALS[$key][($i + 1)]['nums']){
				return $i;
			}
		}
		return 0;
	}

}