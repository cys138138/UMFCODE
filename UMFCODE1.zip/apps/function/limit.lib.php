<?php
function limitAdd($type, $qq = 0){
	$oLimit = m('limit');
	$field = strtolower($type);
	$currentTime = time();
	if($type == 'LOGIN'){
		//取IP地址，并拼接
		$originalIp = $_SERVER["REMOTE_ADDR"];
		$aIp = explode('.', $originalIp);
		unset($aIp[0]);
		$ip = '';
		foreach($aIp as $key => $val){
			if($key == 1){
				$ip .= $val;
			}else{
				$length = strlen($val);
				if($length == 1){
					$val = '00' . $val;
				}elseif($length == 2){
					$val = '00' . $val;
				}
				$ip .= $val;
			}
		}
		$ip = intval($ip);
		$aLimitInfo = $oLimit->getLoginLimitInfo($ip, $field);
		if($aLimitInfo === false){
			return false;
		}elseif(!$aLimitInfo){	//如果没有该IP的记录，则添加
			$oLimit->addLoginLimit(array('id' => $ip, $field => json_encode(array($currentTime))));
			return true;
		}
	}elseif($type == 'SEND_EMAIL'){
		$beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));	//今天开始时间戳
		$result = $oLimit->deleteEmailLimit($beginToday);
		if($result === false){
			return false;
		}
		return $oLimit->addEmailLimit(array('id' => $qq, 'create_time' => time()));
	}else{
		$aUserInfo = checkUserLogin();
		$userId = $aUserInfo['id'];	//取得当前用户id
		$aLimitInfo = $oLimit->getLimitInfo($userId, $field);
		if($aLimitInfo === false){
			return false;
		}elseif(!$aLimitInfo){	//如果没有该用户的记录，则添加
			$oLimit->addLimit(array('id' => $userId, $field => json_encode(array($currentTime))));
			return true;
		}
	}
	$limitConfig = include dirname(__DIR__) . '/config/limit.config.php';
	$aLimit = explode(',', $limitConfig[$type]);
	$aNewLog = array();	//新的日志
	if(count($aLimit) == 1){	//如果没有配置时间段，则当做一天
		$todayStartStamp = strtotime(date('Y-m-d') . ' 00:00:00');	//今天的开始时间戳
		if($aLimitInfo[$field] == ''){
			$aLimitInfo[$field] = array();
		}
		foreach($aLimitInfo[$field] as $time){
			if($time > $todayStartStamp){	//如果今天的日志则保存
				$aNewLog[] = $time;
			}
		}
		$aNewLog[] = $currentTime;
		//更新
		if(count($aNewLog) > $aLimit[0]){
			return true;
		}
		$result = $oLimit->setLimit(array('id' => $userId, $field => json_encode($aNewLog)));
	}else{
		if($aLimitInfo[$field] == ''){
			$aLimitInfo[$field] = array();
		}
		foreach($aLimitInfo[$field] as $time){
			if($time > $currentTime - $aLimit[1]){	//如果是duration内的日志则保存
				$aNewLog[] = $time;
			}
		}
		//先将本次的加上
		$aNewLog[] = $currentTime;
		//更新
		if($type == 'LOGIN'){
			$result = $oLimit->setLoginLimit(array('id' => $ip, $field => json_encode($aNewLog)));
		}else{
			$result = $oLimit->setLimit(array('id' => $userId, $field => json_encode($aNewLog)));
		}
	}
	return $result;
}

function limitCheck($type, $qq = 0){
	if(checkCaptcha($type)){
		return true;
	}
	$oLimit = m('limit');
	$field = strtolower($type);
	$currentTime = time();
	if($type == 'LOGIN'){
		//取IP地址，并拼接
		$originalIp = $_SERVER["REMOTE_ADDR"];
		$aIp = explode('.', $originalIp);
		unset($aIp[0]);
		$ip = '';
		foreach($aIp as $key => $val){
			if($key == 1){
				$ip .= $val;
			}else{
				$length = strlen($val);
				if($length == 1){
					$val = '00' . $val;
				}elseif($length == 2){
					$val = '00' . $val;
				}
				$ip .= $val;
			}
		}
		$ip = intval($ip);
		$aLimitInfo = $oLimit->getLoginLimitInfo($ip, $field);
	}elseif($type == 'SEND_EMAIL'){
		$beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));	//今天开始时间戳
		$aEmailLimitInfo = $oLimit->getEmailLimitInfo($qq);
		if($aEmailLimitInfo === false){
			return false;
		}elseif($aEmailLimitInfo){
			if($aEmailLimitInfo['create_time'] > $beginToday){
				return false;
			}
		}
		$result = $oLimit->deleteEmailLimit($beginToday);
		if($result === false){
			return false;
		}
		return true;
	}else{
		$aUserInfo = checkUserLogin();
		$userId = $aUserInfo['id'];
		$aLimitInfo = $oLimit->getLimitInfo($userId, $field);
	}
	if($aLimitInfo === false){
		return false;
	}elseif(!$aLimitInfo){	//如果没有该用户或IP的记录，则添加
		return true;
	}
	$limitConfig = include dirname(__DIR__) . '/config/limit.config.php';
	$aLimit = explode(',', $limitConfig[$type]);
	$aNewLog = array();	//新的日志--时间段内的日志
	$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty($_POST['ajax']) || !empty($_GET['ajax']);
	if(count($aLimit) == 1){	//如果没有配置时间段，则当做一天
		$todayStartStamp = strtotime(date('Y-m-d') . ' 00:00:00');	//今天的开始时间戳
		if($aLimitInfo[$field] == ''){
			$aLimitInfo[$field] = array();
		}
		foreach($aLimitInfo[$field] as $time){
			if($time > $todayStartStamp){	//如果今天的日志则保存
				$aNewLog[] = $time;
			}
		}
		if(count($aNewLog) >= $aLimit[0]){
			if(!$isAjax){
				return false;
			}
			showLimitCaptcha($type);
			return false;
		}
	}else{
		if($aLimitInfo[$field] == ''){
			$aLimitInfo[$field] = array();
		}
		foreach($aLimitInfo[$field] as $time){
			if($time > $currentTime - $aLimit[1]){	//如果是duration内的日志则保存
				$aNewLog[] = $time;
			}
		}
		if(count($aNewLog) >= $aLimit[0]){
			if(!$isAjax){
				return false;
			}
			showLimitCaptcha($type);
			return false;
		}
	}
	return true;
}

function checkCaptcha($type){
	if($type == 'LOGIN' || $type == 'SNS' || $type == 'APPLY_FRIEND' || $type == 'DELETE_FRIEND' || $type == 'SEND_EMAIL'){
		if($type == 'LOGIN'){
			$captchaKey = 'loginCaptcha';
			$limitCaptcha = post('captcha');
		}else{
			$captchaKey = 'limitCaptcha';
			$limitCaptcha = post('limit_captcha');
		}

		if($limitCaptcha != '' && $limitCaptcha != '请输入验证码'){
			if(!Verify::match($captchaKey, $limitCaptcha)){
				showLimitCaptcha($type, '验证码错误！');
			}else{
				return true;
			}
		}
	}
	return false;
}

function showLimitCaptcha($type, $msg = '请输入验证码'){
	if($type == 'LOGIN' || $type == 'SNS' || $type == 'APPLY_FRIEND' || $type == 'DELETE_FRIEND' || $type == 'SEND_EMAIL'){
		$customData = $_POST;
		$customData['__post_url__'] = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
		$customData['__msg__'] = $msg;
		$customData['__limit_type__'] = $type;
		$GLOBALS['UPDATE']['show_type'] = 'LIMITCAPTCHA';
		$GLOBALS['UPDATE']['custom_data'] = $customData;
		alert($msg, 2);
	}
}