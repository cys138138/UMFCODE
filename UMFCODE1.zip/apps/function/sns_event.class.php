<?php
class SnsEvent{
	public static function filterEventList($aEventList, $aFriendsId = array()){
		$aMethods = array(
			'1' => '_filterPublishShuoShuo',
			'3' => '_filterBeFriendEvent',
			'6' => '_filterPassMissionChallengeEvent',
			'7' => '_filterPassMissionExerciseEvent',
			'90' => '_filterPassMissionChallengeEvent',
			'91' => '_filterBreakThroughMissionEvent',
			'8' => '_filterUpdateMedalEvent',
			'9' => '_filterMatchEvent',
			'11' => '_filterMatchEvent',
			'17' => '_filterMatchEvent',
			'12' => '_filterMatchEvent',
			'16' => '_filterPublishShuoShuo',
			'80' => '_filterPublishShuoShuo',
			'20' => '_filterExchange',
		);
		$aNewEventList = array();
		$aPublicUser = array();

		foreach($aEventList as $aTmpEvent){
			if(isset($aTmpEvent['data']) && !$aTmpEvent['data']){
				continue;
			}
			if($aTmpEvent['type'] == 3){
				$aEvent = self::$aMethods[$aTmpEvent['type']]($aTmpEvent, $aFriendsId);
			}else{
				$aEvent = self::$aMethods[$aTmpEvent['type']]($aTmpEvent);
			}

			$aEvent['id'] = $aTmpEvent['id'];
			$aEvent['is_public'] = $aEvent['user']['is_public'] = in_array($aEvent['user']['id'], $GLOBALS['PUBLIC_USER_IDS']) ? 1 : 0;
			$aEvent['match_limit_award_day'] = isset($GLOBALS['MATCH_AWARD']) ? $GLOBALS['MATCH_AWARD'] : 7;
			
			$aNewEventList[] = $aEvent;
		}
		return $aNewEventList;
	}

	/**
	 * 过滤发表/转发说说的事件数据  type=1,16,80
	 * @param type $aEvent
	 * @param type $aOption
	 * @return type
	 */
	private static function _filterPublishShuoShuo($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'shuoshuo_id' => $aEvent['data']['id'],
			'content' => $aEvent['data']['content'],
			'images' => array(),
			'time' => $aEvent['data']['create_time'],
			'transmit_times' => $aEvent['data']['transmit_times'],
			'views' => $aEvent['data']['views'],
			'comment' => array(),
			'comment_count' => $aEvent['data']['comment_count'],
		);

		if(isset($aEvent['data']['images'])){
			foreach($aEvent['data']['images'] as $images){
				$aResult['images'][] = array(
					'src' => SYSTEM_RESOURCE_URL . $images,
					'thumb' => SYSTEM_RESOURCE_URL . dirname($images) . '/' . SHUOSHUO_IMAGE_THUMB_PREFIX . basename($images),
				);
			}
		}

		$aUser = isLogin();
		$currentUserId = &$aUser['id'];
		foreach($aEvent['data']['comment'] as $aRootComment){
			$aFilterRootComment = array(
				'id' => $aRootComment['id'],
				'content' => $aRootComment['content'],
				'time' => $aRootComment['create_time'],
				'user' => array(
					'id' => $aRootComment['user_info']['id'],
					'name' => $aRootComment['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aRootComment['user_info']['profile'],
					'vip' => $aRootComment['user_info']['vip'],
				),
				'reply_count' => $aRootComment['reply_count'],
				'reply' => array(),
			);
			foreach($aRootComment['reply'] as $aCommentReply){
				$aFilterRootComment['reply'][] = array(
					'id' => $aCommentReply['id'],
					'content' => $aCommentReply['content'],
					'time' => $aCommentReply['create_time'],
					'user' => array(
						'id' => $aCommentReply['user_info']['id'],
						'name' => $aCommentReply['user_info']['name'],
						'profile' => SYSTEM_RESOURCE_URL . $aCommentReply['user_info']['profile'],
						'vip' => $aCommentReply['user_info']['vip'],
					),
					'reply_user' => $aCommentReply['reply_user_info']['id'] != $currentUserId ? array(
						'id' => $aCommentReply['reply_user_info']['id'],
						'name' => $aCommentReply['reply_user_info']['name'],
						'profile' => SYSTEM_RESOURCE_URL . $aCommentReply['reply_user_info']['profile'],
						'vip' => $aCommentReply['reply_user_info']['vip'],
					) : array(),	//如果是当前登陆用户那就没必要组装用户信息了,直接从登陆信息里面取就好了
				);
			}
			$aResult['comment'][] = $aFilterRootComment;
		}

		if($aEvent['data']['source_type'] == 3){
			$aMatch = &$aEvent['data']['source_info'];
			$aResult['source'] = array(
				'id' => $aMatch['match_id'],
				'title' => $aMatch['match_name'],
				'description' => $aMatch['description'],
				'image' => SYSTEM_RESOURCE_URL . $aMatch['match_profile'],
				'score' => $aMatch['best_score'],
				'champion_score' => $aMatch['champion_score'],
				'member_count' => $aMatch['member_count'],
				'start_time' => $aMatch['match_start_time'],
				'end_time' => $aMatch['match_end_time'],
				'is_win' => $aMatch['win_info'] ? 1 : 0,	//是否赢得奖励了
				'source' => array(),
			);
			if($aResult['source']['is_win']){
				$aResult['source']['is_in_ranking'] = $aMatch['win_info']['type'] == 1 ? 1 : 0;	//是否排名奖,否则就是幸运奖
				$aResult['source']['ranking'] = $aMatch['win_info']['ranking'];
			}

		}elseif($aEvent['data']['source_type'] == 2){
			$aPk = &$aEvent['data']['source_info'];
			$isSender = $aResult['user']['id'] == $aPk['sender_user_id'];
			$aSource = array();
			if($isSender){
				$aSource = array(
					'opposite_user' => $aPk['receiver_user_info'],
					'my_score' => $aPk['sender_score'],
					'opposite_score' => $aPk['receiver_score'],
				);
			}else{
				$aSource = array(
					'opposite_user' => $aPk['sender_user_info'],
					'my_score' => $aPk['receiver_score'],
					'opposite_score' => $aPk['sender_score'],
				);
			}
			$aSource['id'] = $aPk['id'];
			$aSource['mission_id'] = $aPk['mission_id'];
			$aSource['mission_title'] = $aPk['mission_name'];
			$aSource['pk_send_time'] = $aPk['create_time'];
			$aSource['pk_over_time'] = $aPk['over_time'];
			$aSource['duration'] = $aPk['duration'];
			$aSource['es_count'] = $aPk['es_counts'];
			$aSource['opposite_user']['profile'] = SYSTEM_RESOURCE_URL . $aSource['opposite_user']['profile'];	//拼头像地址
			$aSource['opposite_user']['is_sender'] = $isSender ? 0 : 1;	//确定描述的另一方是否发起者
			$aResult['source'] = &$aSource;

		}elseif($aEvent['data']['source_type'] == 1 && $aEvent['data']['source_info']){
			$aSource = &$aEvent['data']['source_info'];
			$aResult['source'] = array(
				'id' => $aSource['id'],
				'user' => array(
					'id' => $aSource['user_info']['id'],
					'name' => $aSource['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aSource['user_info']['profile'],
					'vip' => $aSource['user_info']['vip'],
				),
				'content' => $aSource['content'],
				'images' => array(),
			);

			if($aEvent['id'] == 9968){
				//header('xx:' . var_export($aResult['source']['images'], 1));
			}
			foreach($aSource['images'] as $images){
				$aResult['source']['images'][] = array(
					'src' => SYSTEM_RESOURCE_URL . $images,
					'thumb' => SYSTEM_RESOURCE_URL . dirname($images) . '/' . SHUOSHUO_IMAGE_THUMB_PREFIX . basename($images),
				);
			}
		}else{
			$aResult['source'] = array();
		}

		$aResult['support_count'] = $aEvent['data']['support_count'];
		$aResult['comment_count'] = $aEvent['data']['comment_count'];
		$aResult['support'] = &$aEvent['data']['support'];
		foreach($aResult['support'] as &$aSupport){
			$aSupport['profile'] = SYSTEM_RESOURCE_URL . $aSupport['profile'];
		}

		return $aResult;
	}

	/**
	 * 过滤成为好友事件数据  type=2
	 * @param type $aEvent
	 * @param type $aOption
	 * @return type
	 */
	private static function _filterBeFriendEvent($aEvent, $aFriendsId){
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'time' => $aEvent['data_id'],
			'friend' => array(),
		);
		foreach($aEvent['data'] as $aFriend){
			$aResult['friend'][] = array(
				'id' => $aFriend['id'],
				'name' => $aFriend['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aFriend['profile'],
				'is_friend' => in_array($aFriend['id'], $aFriendsId) ? 1 : 0,
				'vip' => $aFriend['vip'],
			);
		}

		return $aResult;
	}

	/**
	 * 过滤通过关卡修炼事件数据  type=7
	 * @param type $aEvent
	 * @param type $aOption
	 */
	private static function _filterPassMissionExerciseEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'mission' => array(),
		);
		foreach($aEvent['data'] as $aMission){
			$aResult['mission'][] = array(
				'id' => $aMission['id'],
				'title' => $aMission['mission_name'],
				'time' => $aMission['task_finish_time'],
			);
		}

		return $aResult;
	}

	/**
	 * 过滤通过关卡挑战事件数据  type=6,90
	 * @param type $aEvent
	 * @param type $aOption
	 */
	private static function _filterPassMissionChallengeEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'mission' => array(),
		);
		if($aEvent['type'] == 6){
			foreach($aEvent['data'] as $aMission){
				$aResult['mission'][] = array(
					'id' => $aMission['id'],
					'title' => $aMission['mission_name'],
					'time' => $aMission['pass_time'],
					'score' => $aMission['score'],
					'pass_exercise_time' => $aMission['pass_time'],
					'over_percent' => $aMission['over_percent'],
				);
			}
		}elseif($aEvent['type'] == 90){
			$aResult['mission'] = array(
				'id' => $aEvent['data']['id'],
				'title' => $aEvent['data']['mission_name'],
				'time' => $aEvent['data']['pass_time'],
				'score' => $aEvent['data']['score'],
				'my_record' => $aEvent['data']['challenge_info']['my_record'],
				'pass_exercise_time' => $aEvent['data']['pass_time'],
				'pass_challenge_time' => $aEvent['data']['task_finish_time'],
				'over_percent' => $aEvent['data']['over_percent'],
			);
		}

		return $aResult;
	}

	/**
	 * 过滤通过关卡挑战事件数据  type=91
	 * @param type $aEvent
	 * @param type $aOption
	 */
	private static function _filterBreakThroughMissionEvent($aEvent){
		$aMission = &$aEvent['data'];
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'time' => $aMission['pass_time'],
			'mission' => array(
				'id' => $aMission['id'],
				'title' => $aMission['mission_name'],
				'pass_excercise_time' => $aMission['task_finish_time'],
				'pass_challenge_time' => $aMission['pass_time'],
			),
		);

		//如果破了闯关得分记录
		$aResult['mission']['result'] = array(
			'my_score' => $aMission['challenge_info']['world_record']['my_score'],
			'world_score' => $aMission['challenge_info']['world_record']['world_score'],
		);

		return $aResult;
	}

	/**
	 * 过滤勋章升级事件数据, type=8
	 * @param type $aEvent
	 * @param type $aOption
	 * @return type
	 */
	private static function _filterUpdateMedalEvent($aEvent){
		$aMedalLevel = substr($aEvent['data_id'], 1);
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'time' => $aEvent['data']['medal_info'][$aMedalLevel],
			'medal_type' => $aEvent['data']['medal_type'],
			'medal_name' => $GLOBALS['MEDAL_EVENT'][$aEvent['data']['medal_type']],
			'medal_image' => $GLOBALS['MEDAL_IMG'][$aEvent['data']['medal_type']],
			'medal_level' => $aMedalLevel,
		);

		return $aResult;
	}

	/**
	 * 过滤比赛事件数据  type=9,11,12,17
	 * @param type $aEvent
	 * @param type $aOption
	 * @return type
	 */
	private static function _filterMatchEvent($aEvent){
		$aData = &$aEvent['data'];
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'match_id' => $aData['match_id'],
			'grade_id' => $aData['grade_id'],
			'subject_id' => $aData['subject_id'],
			'ranking' => $aData['ranking'],
			'score' => $aData['best_score'],
			'champion_score' => $aData['champion_score'],
			'title' => $aData['match_name'],
			'description' => $aData['description'],
			'image' => SYSTEM_RESOURCE_URL . $aData['match_profile'],
			'start_time' => $aData['match_start_time'],
			'end_time' => $aData['match_end_time'],
			'member_count' => $aData['member_count'],
			'time' => 0,
			'first_finish_time' => $aData['first_finish_time'],
			'join_time' => $aData['create_time'],
			'last_rejoin_time' => $aData['last_rejoin_time'],
			'win_type' => 0,
			'users' => array(),
		);

		if($aEvent['type'] == 9){
			$aResult['time'] = $aData['create_time'];
		}elseif($aEvent['type'] == 11){
			$aResult['time'] = $aData['first_finish_time'];
		}elseif($aEvent['type'] == 12){
			$aResult['time'] = $aData['match_end_time'];
			$aResult['join_time'] = $aData['create_time'];
			$aResult['rejoin_join_time'] = $aData['last_rejoin_time'];
			if($aData['win_info']){
				$aResult['win_type'] = $aData['win_info']['type'];
			}

			foreach($aData['users'] as $aWinner){
				$aResult['users'][] = array(
					'id' => $aWinner['user_info']['id'],
					'name' => $aWinner['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aWinner['user_info']['profile'],
					'vip' => $aWinner['user_info']['vip'],
				);
			}

		}elseif($aEvent['type'] == 17){
			$aResult['time'] = $aData['last_rejoin_time'];
			$aResult['join_time'] = $aData['create_time'];
		}

		return $aResult;
	}

	/**
	 * 兑换礼品事件数据
	 * @param type $aEvent
	 * @return type
	 */
	private static function _filterExchange($aEvent){
		return array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'time' => $aEvent['data']['create_time'],
			'goods' => array(
				'id' => $aEvent['data']['goods_id'],
				'name' => $aEvent['data']['name'],
				'level' => $aEvent['data']['level'],
				'gold' => $aEvent['data']['gold'],
				'stock' => $aEvent['data']['stock'],
				'support' => $aEvent['data']['support'],
			),
		);
	}
}

function addSnsEvent($aData){
	$oSnsEvent = m('SnsEvent');
	return $oSnsEvent->addEvent($aData);
}

function deleteSnsEvent($id = '', $userId = '', $type = '', $dataId = ''){
	$oSnsEvent = m('SnsEvent');
	return $oSnsEvent->deleteEvent($id, $userId, $type, $dataId);
}

function getEventList($aUserIds = array(), $aFriendsId = array(), $aEventTypes = array(), $page = 1,  $pageSize = 20, $matchId = 0){
	$aFriendsId = array_unique($aFriendsId);
	$aEventList = m('SnsEvent')->getEventList($aUserIds, $aFriendsId, $aEventTypes, $page,  $pageSize, $matchId);
	return SnsEvent::filterEventList($aEventList, $aFriendsId);
}
