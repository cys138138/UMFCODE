<?php
/**
 * Description 校讯通 通用操作
 *
 * @author Administrator
 */
class Xxt{
	/**
	 * 获取校讯通用户登陆信息
	 * @param string $token 一次性登陆令牌
	 * @return array 登陆信息
	 * @throws XxtException 校讯通异常
	 */
	public static function getLoginInfo($token){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('CHK_OAUTH', array('Token' => $token));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('CHK_OAUTH', $aReasult);
		}
	}
	
	public static function getClassTeacher($teacherId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_CLASS_TEACHER', array('TeacherId' => $teacherId));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_CLASS_TEACHER', $aReasult);
		}
	}
	
	public static function getClassStudent($cityId, $classId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_CLASS_STUDENT', array('CityId' => $cityId, 'ClassId' => $classId));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_CLASS_STUDENT', $aReasult);
		}
	}
	
	public static function getParentInfo($cityId, $userId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_PARENT_INFO', array('CityId' => $cityId, 'UserId' => $userId));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_PARENT_INFO', $aReasult);
		}
	}
		
	/**
	 * 读取学生数据
	 * @param $userId 校讯通用户ID
	 * @param $cityId 城市ID
	 */
	public static function getStudentInfo($userId, $cityId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_STUDENT_INFO', array(
			'UserId' => $userId,
			'CityId' => $cityId
		));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_STUDENT_INFO', $aReasult);
		}
	}

	/**
	 * 读取教师数据
	 * @param $userId 校讯通用户ID
	 * @param $cityId 城市ID
	 */
	public static function getTeacherInfo($userId, $cityId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_TEACHER_INFO', array(
			'UserId' => $userId,
			'CityId' => $cityId
		));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_TEACHER_INFO', $aReasult);
		}
	}
	
	public static function getClassInfo($classId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_CLASS', array(
			'ClassId' => $classId,
		));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_CLASS', $aReasult);
		}
	}

	/**
	 * 读取教师与班级间的关系
	 * @param $classId 班级ID
	 * @param $teacherId 校讯通教师ID
	 * 【注意：两项可以有一项为空】
	 */
	public static function getClassAndTeacher($classId = '', $teacherId = ''){
		$aParams = array(
			'ClassId' => $classId,
			'TeacherId' => $teacherId
		);
		return self::_getXxtInfo('QRY_CLASS_TEACHER', $aParams);
	}

	/**
	 * 读取学校信息
	 * @param $schoolId 学校ID
	 */
	public static function getSchoolInfo($schoolId){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('QRY_SCHOOL', array(
			'SchoolId' => $schoolId,
		));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('QRY_SCHOOL', $aReasult);
		}
	}
	
	/**
	 * 给用户推送应用消息
	 * @param $userId 校讯通用户ID
	 * @param $aContent 内容 array = (
	 * 		'UserType' => 2,	1教师  2学生  3家长
	 * 		'IsOauth' => 0,		1开启单点登录
	 * 		'OthMsgId' => 0,	我们的消息ID，唯一的
	 * 		'ValidDate' => date('Y-m-d H:i:s'),  该消息的有效期
	 * 		'URL' => APP_HOME,	消息的地址
	 * 		'Type' => 1,		1普通消息   2推广消息   9其他消息
	 * 		'Content' => '',	消息通知的内容长度为500
	 *		'City' => 'cs',		城市标记代码  
	 *		'SchoolId' => 0		学校ID
	 * )
	 * @throws XxtException 校讯通异常
	 */
	public static function postAppMessage($userId, $aContent){
		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest('SEND_SYS_PUBLIC_MESSAGE', array(
			'CityId'		=> $aContent['City'],
			'UserId'		=> intval($userId),
			'SchoolId'		=> $aContent['SchoolId'],
			'UserType'		=> intval($aContent['UserType']),
			'IsOauth'		=> intval($aContent['IsOauth']),
			'OthMsgId'		=> $aContent['OthMsgId'],
			'ValidDate'		=> $aContent['ValidDate'],
			'MessageURL'	=> $aContent['URL'],
			'MessageType'	=> intval($aContent['Type']),
			'MessageContent'=> $aContent['Content']
		));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return $aReasult['MSG_BODY'];
		}else{
			throw new XxtException('SEND_SYS_PUBLIC_MESSAGE', $aReasult);
		}
	}
	
	/**
	 * 发送微博
	 * @param type $aParams 微博参数
	 * @return boolean 是否发送成功
	 * @throws XxtException 校讯通异常
	 */
	public static function addWeibo($aParams){
		$oXxtApi = new XxtApi();
		$aParams['content'] = str_replace(
			array('&nbsp;', '&lt;', '&gt;'),
			array(' ', '<', '>'),
			$aParams['content']
		);
		$aReasult = $oXxtApi->sendRequest('ADD_WEIBO_MSG', array(
			'CityId'	=> $aParams['city_id'],
			'UserId'	=> $aParams['user_id'],
			'RoleType'	=> $aParams['role_type'],
			'SchoolId'	=> $aParams['school_id'],
			'ClassId'	=> $aParams['class_id'],
			'Content'	=> $aParams['content'],
			'FromSys'	=> $aParams['from_sys'],
			'MsgType'	=> $aParams['msg_type'],
			'HasAttachment'	=> $aParams['has_attachment'],
		));
		if(isset($aReasult['Result']) && $aReasult['Result'] == 200 && is_array($aReasult['MSG_BODY'])){
			return true;
		}else{
			throw new XxtException('ADD_WEIBO_MSG', $aReasult);
		}
	}

	/**
	 * 增加一条微博到校讯通微博
	 * @param $extendID 校讯通用户ID
	 * @param $aContent 微博内容 array = (
	 * 		'Content' => '内容',
	 * 		'MsgType' => 1,		1学校圈 ： 2班圈 ： 3教师圈
	 *		'City' => 'cs',		城市标记代码
	 * 		'HasAttachment' => 0,	1开启(!备注：校讯通那边无法查看，当0时以下两个参数可为空)
	 * 			'PathAndName' => '附件实体地址',
	 * 			'ThumbPath' => '缩略图',	客户端才使用
	 * )
	 * @param $userType 1老师 2学生 3家长
	 * @param $userId   优满分用户ID，教师和家长用
	 */
	public static function postAddWeibo($extendID, $aContent = array('HasAttachment' => 0, 'PathAndName' => '' , 'ThumbPath' => ''), $userType = 2, $userId = 0){
		if($userType == 2){
			$aStudentInfo = self::_getStudentInfo($extendID, $aContent['City']);
			if(empty($aStudentInfo['Desc'])){
				$schoolId = intval($aStudentInfo['MSG_BODY']['StudentEntity']['SchoolId']);
				$classId = intval($aStudentInfo['MSG_BODY']['StudentEntity']['ClassId']);
			}else{
				return $aStudentInfo['Desc'];
			}
		}elseif($userType == 1){
			$oTeacher = m('Teacher');
			$aTeacher = $oTeacher->getTeacherInfoById($userId);
			$schoolId = intval($aTeacher['school_id']);
			if(isset($aTeacher['relations'][0])){
				$classId = intval($aTeacher['relations'][0]['ClassId']);
			}else{
				$classId = 0;
			}
		}else{
			$oParent = m('Parent');
			$aParent = $oParent->getParentInfoById($userId);
			$schoolId = intval($aParent['xxt_data']['SchoolId']);
			$classId = 0;
		}
		$aContent['Content'] = preg_replace('/&nbsp;/', ' ', $aContent['Content']);
		$aContent['Content'] = preg_replace('/&lt;/', '<', $aContent['Content']);
		$aContent['Content'] = preg_replace('/&gt;/', '>', $aContent['Content']);
		$aParams = array(
			'CityId'	=> $aContent['City'],
			'UserId'	=> intval($extendID),
			'RoleType'	=> $userType,
			'SchoolId'	=> $schoolId,
			'ClassId'	=> $classId,
			'Content'	=> $aContent['Content'],
			'FromSys'	=> 9,
			'MsgType'	=> intval($aContent['MsgType']),
			'HasAttachment'	=> intval($aContent['HasAttachment']),
			'WeiboMsgAttachmentList' => array(
				'PathAndName'	=> $aContent['PathAndName'],
				'ThumbPath' 	=> $aContent['ThumbPath']
			)
		);

		return self::_getXxtInfo('ADD_WEIBO_MSG', $aParams);
	}

	/**
	 * 转发到校讯通校圈
	 * @param $userId 校讯通用户ID
	 * @param $aShareContent 微博内容 array = (
	 * 		'Content' => '内容',
	 * 		'LinkTitle' => '链接的标题',
	 * 		'Url' => '我方地址链接',
	 * 		'Desc' => '链接的内容描述',
	 * 		'ThumbPic' => '图片地址',
	 *		'City' => 'cs'  城市标记代码  
	 * )
	 */
	public static function postShareWeibo($userId, $aShareContent){
		$aShareContent['Content'] = '#优满分#' . $aShareContent['Content'];
		$aStudentInfo = self::_getStudentInfo($userId, $aShareContent['City']);
		if(empty($aStudentInfo['Desc'])){
			$schoolId = intval($aStudentInfo['MSG_BODY']['StudentEntity']['SchoolId']);
			$classId = intval($aStudentInfo['MSG_BODY']['StudentEntity']['ClassId']);
		}else{
			return $aStudentInfo;
		}

		$aParams = array(
			'CityId'	=> $aShareContent['City'],
			'UserId'	=> $userId,
			'RoleType'	=> 2,
			'SchoolId'	=> $schoolId,
			'ClassId'	=> $classId,
			'Content'	=> $aShareContent['Content'],
			'FromSys'	=> 9,
			'LinkTitle'	=> $aShareContent['Title'],
			'LinkUrl'	=> $aShareContent['Url'],
			'LinkDesc'	=> $aShareContent['Desc'],
			'ThumbPic'	=> $aShareContent['ThumbPic']
		);

		return self::_getXxtInfo('SHARE_WEIBO_MSG', $aParams);
	}

	/**
	 * 读取校讯通学生信息
	 * @param $userId 校讯通学生ID
	 */
	private static function _getStudentInfo($userId, $cityId){
		$aParams = array(
			'CityId' => $cityId,
			'UserId' => $userId
		);

		return self::_getXxtInfo('QRY_STUDENT_INFO', $aParams);
	}

	/**
	 * 校讯通 通用读取方法
	 */
	private static function _getXxtInfo($msgType, $aParams){
		if(!$msgType && !$aParams){
			return array('Desc' => '参数非法', 'Result' => 0);
		}

		$oXxtApi = new XxtApi();
		$aReasult = $oXxtApi->sendRequest($msgType, $aParams);
		
		if($aReasult['Result'] == 200){
			return array('MSG_BODY' => $aReasult['MSG_BODY'], 'Result' => $aReasult['Result']);
		}else{
			return array('Desc' => $aReasult['Desc'], 'Result' => $aReasult['Result']);
		}
	}

}