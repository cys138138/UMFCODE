<?php

/**
 * 争分夺宝业务层 罗启军
 */

class Takejewels{
	public static $aMissionTimeH5 = array(50, 45, 35, 30, 20, 15, 10, 8, 5, 5);	//每个关卡的时间限制，单位秒
	const END_TIME = 1451404800;	//活动结束时间2015-12-30 00:00:00 
	const DAILY_JOIN_TIMES = 3;	//用户每天可以参加的次数
	const DAILY_LUCK_TIMES = 3;	//用户每天可以抽奖的次数
	const NEXT_JOIN_DAY_TIME = 4;	//中奖后几天后可以再参与
	
	/**
	 * 初始化用户数据
	 */
	public static function initUser(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			return 4;
		}
		$aUserInfo = $aResult['data'];
		if($aUserInfo){
			$userId = intval($aUserInfo['id']);
			$userType = intval($aUserInfo['user_type']);
			$oRaiders = m('Raiders');
			$aUserAct = $oRaiders->getJoinInfoByUserIdAndUserType($userId, $userType);
			$now = time();
			if($aUserAct){
				if(date('Ymd', $aUserAct['reset_time']) < date('Ymd', $now)){
					$aUserAct['reset_time'] = $now;
					$aUserAct['luck_times'] = self::DAILY_LUCK_TIMES;
					$aUserAct['surplus_times'] = self::DAILY_JOIN_TIMES;
					$oRaiders->setJoin($aUserAct);
				}
				return true;
			}else{
				if($aUserInfo['user_type'] == 2 && $aUserInfo['xxt_id'] || $aUserInfo['user_type'] == 1 || $aUserInfo['user_type'] == 3){
					$aUserAct = array(
						'user_id' => $userId,
						'user_type' => $aUserInfo['user_type'],
						'create_time' => $now,
						'mission_start_time' => 0,
						'award_time' => 0,
						'surplus_times' => self::DAILY_JOIN_TIMES,
						'reset_time' => $now,
						'share_time' => 0,
						'luck_times' => self::DAILY_LUCK_TIMES,
						'process' => array(),
					);
					$oRaiders->addJoin($aUserAct);
					return true;
				}else{
					return 3;	//不是校讯通用户
				}
			}
		}else{
			return 2;	//没有登录
		}
	}
	
	
	/**
	 * 开始游戏
	 */
	public static function startGame(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$oRaiders = m('Raiders');
		$aUser = $aResult['data'];
		$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUser['id'], $aUser['user_type']);
		if(!$aJoin){
			alert('抱歉，您不是校讯通用户', -1);
		}
		$now = time();
		$nextJoinTime = $aJoin['award_time'] + 86400 * self::NEXT_JOIN_DAY_TIME;
		if($nextJoinTime > $now){
			alert('抱歉！您得到 ' . date('m-d H:i', $nextJoinTime) . ' 才可以再次参加游戏喔', -1);
		}
		if(!$aJoin['surplus_times']){
			alert('抱歉！您得到今天的机会已经用完了，明天继续努力吧', -1);
		}
		
		$aJoin['process'] = array();
		$aJoin['surplus_times'] = $aJoin['surplus_times'] - 1;
		$aJoin['join_count'] = $aJoin['join_count'] + 1;
		$oEs = m('Es');
		$aFunEsCat1 = array(1384);
		$aFunEsCat2 = array(1442, 1383, 1444);	//1443趣味科技暂时去掉减少难度
		//$aEsIds1 = $oEs->getEsIdsByCategoryId($aFunEsCat1, 8);	//趣味考场
		$aEsIds1 = $oEs->getPointCorrectPercentEsIds($aFunEsCat1, 8, 90);	//按正确率查题目ID
		$aEsIds = $oEs->getEsIdsByCategoryId($aFunEsCat2, 12);	//其他趣味题12道
		$aEsIds = array_merge($aEsIds1, $aEsIds);
		for($i = 0; $i < 10; $i++){
			$aMission = array(
				$aEsIds[2 * $i] => 0,
				$aEsIds[2 * $i + 1] => 0,
				'quick_spot' => rand(1, 64),	//8*8的找茬
				'quick_result' => 0,
			);
			array_push($aJoin['process'], $aMission);
		}
		if($oRaiders->setJoin($aJoin)){
			alert('OK', 1);
		}else{
			alert('抱歉！系统出错，请刷新后重试', 0);
		}
	}
	
	/**
	 * 获取题目或找茬图片
	 */
	public static function getNext(){
		$aCheck = self::checkActive();
		if($aCheck['status'] != 1){
			alert($aCheck['msg'], -1);
		}
		
		$oRaiders = m('Raiders');
		$aUser = $aCheck['data'];
		$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUser['id'], $aUser['user_type']);
		if(!$aJoin){
			alert('抱歉！您不是广西校讯通用户', -1);
		}
		$aProcess = $aJoin['process'];
		if(!$aProcess){
			alert('您还没有开始游戏呢', -1);
		}
		
		$type = 0;	//记录是题目还是找茬
		$currentMission = -1;
		$remainTime = 0;	//当前关剩余时间
		$esIndex = 0;
		foreach($aProcess as $missionIndex => $aMission){
			$i = 0;
			foreach($aMission as $key => $content){
				if(is_numeric($key) && !$content){
					$type = 1;
					$esId = $key;
					$currentMission = $missionIndex;
					if($i == 0){
						$remainTime = Takejewels::$aMissionTimeH5[$currentMission];
						$aJoin['mission_start_time'] = time();
						$oRaiders->setJoin($aJoin);
					}
					break 2;
				}else if($key == 'quick_result' &&  !$content){
					$type = 2;
					if($aMission['quick_spot'] % 8 > 0){
						$xCoordinate = 8 - ($aMission['quick_spot'] % 8) + 1;
					}else{
						$xCoordinate = 1;
					}
					
					$yCoordinate = 8 - ceil($aMission['quick_spot'] / 8) + 1;
					$currentMission = $missionIndex;
					break 2;
				}
				$i++;
				if($key != 'quick_spot'){
					$esIndex++;
				}
			}
		}
		if(!$type){
			alert('游戏已经结束', -1);
		}else{
			$expTime = $aJoin['mission_start_time'] + Takejewels::$aMissionTimeH5[$currentMission];
			if(time() >= $expTime){
				//alert('时间到咯', -1);
			}
			
			if($type == 1){
				$oEs = m('Es');
				$aEs = $oEs->getEsInfoByEsId($esId);
				if(!$aEs){
					alert('题目数据掉失', -1);
				}
				$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
				$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
				//$aEs['es_content'] = $oEsPlugin->removeAnswer($aEs['es_content']);
				$aEs['id'] = Xxtea::encrypt($aEs['id']);
				unset($aEs['content_json']);
				unset($aEs['content_text']);
				alert('next', 1, array('type' => $type, 'result' => $aEs, 'remain_time' => $remainTime, 'index' => $esIndex, 'mission' => $currentMission));
			}else{
				alert('next', 1, array('type' => $type, 'result' => array('x' => $xCoordinate, 'y' => $yCoordinate), 'index' => $esIndex, 'mission' => $currentMission));
			}
		}
		
	}
	
	/**
	 * 答题处理或找茬处理
	 */
	public static function answerQuestion(){
		$aCheck = self::checkActive();
		if($aCheck['status'] != 1){
			alert($aCheck['msg'], -1);
		}
		
		$oRaiders = m('Raiders');
		$aUser = $aCheck['data'];
		$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUser['id'], $aUser['user_type']);
		if(!$aJoin){
			alert('抱歉！您不是广西校讯通用户', -1);
		}
		$aProcess = $aJoin['process'];
		if(!$aProcess){
			alert('您还没有开始游戏呢', -1);
		}
		
		$type = 0;	//记录是题目还是找茬
		$remainTime = 0;	//当前关剩余时间
		$currentMission = -1;
		foreach($aProcess as $missionIndex => $aMission){
			foreach($aMission as $key => $content){
				if(is_numeric($key) && !$content){
					$type = 1;
					$esId = $key;
					$currentMission = $missionIndex;
					break 2;
				}else if($key == 'quick_result' &&  !$content){
					$type = 2;
					$resultSpot = $aMission['quick_spot'];
					$currentMission = $missionIndex;
					break 2;
				}
			}
		}
		if($currentMission > $aJoin['max_mission_level']){
			$aJoin['max_mission_level'] = $currentMission;
		}
		if(!$type){
			alert('游戏已经结束啦', -1);
		}else{
			$expTime = $aJoin['mission_start_time'] + Takejewels::$aMissionTimeH5[$currentMission];
			if(time() >= $expTime){
				alert('时间到咯', -1);
			}
			$answer = post('user_answer');
			if($type == 1){
				if(!isset($answer['answer'])){
					alert('数据有误！', -1);
				}
				$oEs = m('Es');
				$aEsInfo = $oEs->getOfficialEsInfoById($esId);
				if(!$aEsInfo){
					alert('ID为 ' . $esId . ' 的题目不存在', -1);
				}
				$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
				$aResult = $oEsPlugin->getCorrectness($aEsInfo['content_json'], $answer['answer']);
				if($aResult['pass']){
					$aJoin['process'][$missionIndex][$esId] = 1;
					$oRaiders->setJoin($aJoin);
					alert('做题目下去吧骚年', 1, array('status' => 3));
				}else{
					$aJoin['process'] = array();
					$oRaiders->setJoin($aJoin);
					alert('哎唷！答错咯，再试试吧！', 1, array('status' => 2));
				}
			}elseif($type == 2){
				//最后一关时间到
				if($currentMission == 9){
					//alert('时间到咯', -1);
				}
				if($resultSpot == $answer){
					$aJoin['process'][$missionIndex]['quick_result'] = $answer;
					$oRaiders->setJoin($aJoin);
					if($currentMission == 4 || $currentMission == 6 || $currentMission == 9){
						if($currentMission == 4){
							$prizeLevel = 3;
						}elseif($currentMission == 6){
							$prizeLevel = 2;
						}elseif($currentMission == 9){
							$prizeLevel = 1;
						}
						$aPrizeList = $oRaiders->getPrizeList($prizeLevel, 1, 20, true);
						alert('选奖品吧哈哈', 1, array('status' => 1, 'prize' => $aPrizeList, 'level' => $prizeLevel));
					}else{
						alert('找茬下去吧骚年', 1, array('status' => 3));
					}
				}else{
					$aJoin['process'] = array();
					$oRaiders->setJoin($aJoin);
					alert('哎唷！找错咯，再试试吧！', 1, array('status' => 2));
				}
			}
		}
		
	}
	
	/**
	 * 抽奖
	 */
	public static function luckDraw(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$aUser = $aResult['data'];
		$oRaiders = m('Raiders');
		$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUser['id'], $aUser['user_type']);
		if(!$aJoin['luck_times']){
			alert('今天的抽奖机会已经用完啦', -1);
		}
		
		$today = date('Ymd', time());
		$aCodition = array(
			'id' => array(9),
			'start_time' => strtotime($today . ' 00:00:00'),
			'end_time' => strtotime($today . ' 23:59:59'),
		);
		$luckToday = $oRaiders->getOneAwardCount($aCodition);
		$aData = array(
			'id' => $aJoin['id'],
			'luck_times' => $aJoin['luck_times'] - 1,
		);
		$oRaiders->setJoin($aData);
		if($luckToday >= 10){
			alert('result', 1, 0);
		}else{
			$rand = rand(1, 100);
			if($rand == 1){
				$award = 9;
				$aAward = array(
					'user_type' => $aUser['user_type'],
					'user_id' => $aUser['id'],
					'prize_id' => $award,
					'create_time' => time(),
				);
				$oRaiders->addAward($aAward);
				$aPrize = array(
					'id' => $award,
					'surplus' => array('sub', 1),
				);
				$oRaiders->setPrize($aPrize);
				alert('result', 1, $award);
			}else{
				alert('result', 1, 0);
			}
		}
	}
	
	/**
	 * 选择奖品
	 */
	public static function choicePrize(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		
		$id = intval(post('id'));
		$oRaiders = m('Raiders');
		$aPrize = $oRaiders->getPrizeInfoById($id);
		if(!$aPrize){
			alert('奖品不存在', -1);
		}elseif(!$aPrize['surplus']){
			alert('OH NO!该奖品已经被领完了，选择其他奖品吧', -1);
		}
		
		$aUser = $aResult['data'];
		//记录所有领奖操作
		$selectPrizeRecordId = $oRaiders->addSelectPrizeRecord(array(
			'user_id' => $aUser['id'],
			'user_type' => $aUser['user_type'],
			'prize_id' => $id,
			'create_time' => time(),
		));
		
		$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUser['id'], $aUser['user_type']);
		if(!$aJoin){
			alert('您不是校讯通用户', -1);
		}
		if($aPrize['level'] == 1){
			$mission = 9;
		}elseif($aPrize['level'] == 2){
			$mission = 6;
		}elseif($aPrize['level'] == 3){
			$mission = 4;
		}else{
			alert('只能选择一二三等级', -1);
		}
		if($aJoin['process']){
			if($aJoin['process'][$mission]['quick_spot'] == $aJoin['process'][$mission]['quick_result']){
				$aJoin['award_time'] = time();
				$aJoin['process'] = array();
				$oRaiders->setJoin($aJoin);
				
				$aAward = array(
					'user_type' => $aUser['user_type'],
					'user_id' => $aUser['id'],
					'prize_id' => $id,
					'create_time' => time(),
				);
				$awardId = $oRaiders->addAward($aAward);
				
				$aPrize['surplus'] = array('sub', 1);
				$oRaiders->setPrize($aPrize);
				alert('填写地址', 1, array('award' => $awardId));
			}else{
				alert('您还拿到奖品呢', -1);
			}
		}else{
			alert('奖品就在眼前，加油吧', -1);
		}
	}
	
	/**
	 * 填写地址
	 */
	public static function fillInfo(){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		
		$id = intval(post('id'));
		$oRaiders = m('Raiders');
		$aAward = $oRaiders->getAwardInfoById($id);
		if(!$aAward){
			alert('奖品不存在喔', -1);
		}
		
		$aUser = $aResult['data'];
		if($aAward['user_id'] != $aUser['id'] || $aAward['user_type'] != $aUser['user_type']){
			alert('奖品不是你的喔', -1);
		}
		$name = post('name');
		$number = intval(post('number'));
		$addr = post('addr');
		if(!$name){
			alert('请填写名字', -1);
		}
		if(!is_numeric($number) || !$number){
			alert('请填写联系号码', -1);
		}
		if(!$addr){
			alert('请填写地址', -1);
		}
		$aAward['user_name'] = $name;
		$aAward['user_number'] = $number;
		$aAward['user_address'] = $addr;
		if($oRaiders->setAward($aAward)){
			$aPrize = $oRaiders->getPrizeInfoById($aAward['prize_id']);
			$content = '哇塞！太容易了！我参加争分夺宝活动获得 ' . $aPrize['name'] . '----优满分应用';
			//self::share($content, false);
		}else{
			alert('填写信息失败', -1);
		}
	}
	
	
	
	/**
	 * 分享一条微博
	 */
	public static function share($content, $check = true){
		$aResult = self::checkActive();
		if($aResult['status'] != 1){
			alert($aResult['msg'], -1);
		}
		$aUserInfo = $aResult['data'];
		if($aUserInfo['user_type'] == 2 && !$aUserInfo['xxt_id']){
			alert('您不是校讯通用户', -1);
		}
		
		$now = time();
		$oRaiders = m('Raiders');
		$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUserInfo['id'], $aUserInfo['user_type']);
		if(!$aJoin){
			alert('您不是校讯通用户', -1);
		}
		if(date('Ymd', $aJoin['share_time']) == date('Ymd', $now) && $check){
			//alert('您今天已经分享过啦', -1);
		}
		$updateJoinTime = true;
		if($check){
			$aJoin['share_time'] = $now;
			$aJoin['surplus_times'] = $aJoin['surplus_times'] + 1;
			$updateJoinTime = $oRaiders->setJoin($aJoin);
		}
		alert('记录分享成功', 1);
		alert('暂不支持分享到校圈', -1);
		//分享
		if($aUserInfo['user_type'] == 2 || $aUserInfo['user_type'] == 3){
			if(!isset($aUserInfo['xxt_data']) || !$aUserInfo['xxt_data']){
				halt('分享到校圈失败，获取用户信息出错' . PHP_EOL . '请您尝试重新登录再试一次，如果还失败请您耐心等待我们的修复。', true, $aUserInfo);
			}
			$city = $aUserInfo['xxt_data']['CityId'];
			$extendID = $aUserInfo['xxt_data']['UserId'];
			$schoolId = $aUserInfo['xxt_data']['SchoolId'];
		}else{
			$city = $aUserInfo['city_id'];
			$extendID = $aUserInfo['extend_code'];
			$schoolId = $aUserInfo['school_id'];
		}

		if(isComputer()){
			$clientType = 9;
		}else{
			$clientType = 10;
		}

		$aParams = array(
			'city_id'	=> $city,
			'user_id'	=> intval($extendID),
			'role_type'	=> $aUserInfo['user_type'],
			'school_id'	=> intval($schoolId),
			'class_id'	=> '',
			'content'	=> $content,
			'from_sys'	=> $clientType,
			'msg_type'	=> 1,
			'has_attachment' => 0
		);
		$aShare = Xxt::addWeibo($aParams);
		if($aShare){
			alert('分享到校圈成功', 1);
		}else{
			halt('分享到校圈失败', true, $aShare);
		}
	}
	
	
	/**
	 * 检查活动信息
	 */
	public static function checkActive(){
		$now = time();
		if($now >= self::END_TIME){
			return array('status' => 2, 'msg' => '活动已结束', 'data' => '');
		}
		
		$userType = intval(Cookie::get('userType'));
		if($userType){
			if($userType == 1){
				$aUser = isTeacherLogin();
			}elseif($userType == 2){
				$aUser = isLogin();
				if($aUser){
					$oUser = m('User');
					$aUserInfo = $oUser->getPersonalInfoByUserId($aUser['id']);
					$aUser['xxt_data'] = $aUserInfo['xxt_data'];
				}
			}elseif($userType == 3){
				$aUser = isParentLogin();
			}
		}else{
			$aUser = isTeacherLogin();
			if($aUser){
				$userType = 1;
			}else{
				$aUser = isLogin();
				if($aUser){
					$userType = 2;
					$oUser = m('User');
					$aUserInfo = $oUser->getPersonalInfoByUserId($aUser['id']);
					$aUser['xxt_data'] = $aUserInfo['xxt_data'];
				}else{
					$aUser = isParentLogin();
					if($aUser){
						$userType = 3;
					}
				}
			}
		}
		if($aUser){
			$aUser['user_type'] = $userType;
			if($userType == 1){
				if(!(isset($aUser['extend_type']) && $aUser['extend_type'] == 5)){
					return array('status' => 2, 'msg' => '抱歉！本活动只限广西用户参加', 'data' => $aUser);
				}
			}elseif($userType == 2){
				if($aUser['xxt_type'] != 5){
					return array('status' => 2, 'msg' => '抱歉！本活动只限广西用户参加', 'data' => $aUser);
				}
			}else{
				if($aUser['extend_type'] != 5){
					return array('status' => 2, 'msg' => '抱歉！本活动只限广西用户参加', 'data' => $aUser);
				}
			}
			return array('status' => 1, 'msg' => 'OK', 'data' => $aUser);
		}else{
			return array('status' => 3, 'msg' => '请登陆广西校迅通', 'data' => '');
		}
		
	}
	


}