<?php
class PersonalMessage{
	public static function filterEventList($aEventList){
		$aMethods = array(
			'1' => '_filterMyAtShuoShuoEvent',
			'100' => '_filterMyAtShuoShuoInCommentEvent',
			'2' => '_filterMyReshipmentShuoShuoEvent',
			'3' => '_filterMyReplyShuoShuoEvent',
			'4' => '_filterMyReplyShuoShuoEvent',
			'8' => '_filterMyMessageBoardEvent',
			'9' => '_filterMyMessageBoardEvent',
			'10' => '_filterFeedbackResultEvent',
			'20' => '_filterMyMatchFinishEvent',
			'30' => '_filterMyPkEvent',
			'31' => '_filterMyPkEvent',
			'32' => '_filterMyPkEvent',
			'33' => '_filterGivePropEvent',
		);

		$aFilterEventList = array();
		foreach($aEventList as $aTmpEvent){
			if(isset($aTmpEvent['data']) && !$aTmpEvent['data']){
				continue;
			}
			$aEvent = self::$aMethods[$aTmpEvent['type']]($aTmpEvent);
			$aEvent['id'] = $aTmpEvent['id'];
			$aFilterEventList[] = $aEvent;
		}
		return $aFilterEventList;
	}

	/**
	 * 过滤我的说说被他人转载的动态
	 * @param type $aEvent
	 */
	private static function _filterMyReshipmentShuoShuoEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'sender' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'shuoshuo_id' => $aEvent['data']['id'],
			'content' => $aEvent['data']['content'],
			'time' => $aEvent['data']['create_time'],
			'support' => $aEvent['data']['support'],	//赞的用户
			'comment' => self::_filterShuoShuoComment($aEvent['data']['comment']),
			'comment_count' => $aEvent['data']['comment_count'],
			'support_count' => $aEvent['data']['support_count'],
		);
		if($aEvent['data']['source_info']){
			$aSource = &$aEvent['data']['source_info'];
			$aResult['source'] = array(
				'id' => $aSource['id'],
				'user' => array(
					'id' => $aSource['user_info']['id'],
					'name' => $aEvent['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aSource['user_info']['profile'],
					'vip' => $aEvent['user_info']['vip'],
				),
				'content' => $aSource['content'],
				'images' => array(),	//图片
			);

			foreach($aSource['images'] as $images){
				$aResult['source']['images'][] = SYSTEM_RESOURCE_URL . $images;
			}
		}

		foreach($aResult['support'] as &$aSupportUser){
			$aSupportUser['profile'] = SYSTEM_RESOURCE_URL . $aSupportUser['profile'];
		}

		return $aResult;
	}

	/**
	 * 过滤我被他人在任意一条说说里@的动态
	 * @param type $aEvent
	 */
	private static function _filterMyAtShuoShuoEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'sender' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'shuoshuo_id' => $aEvent['data']['id'],
			'content' => $aEvent['data']['content'],
			'time' => $aEvent['data']['create_time'],
			'source' => array(),
			'images' => array(),
			'comment' => self::_filterShuoShuoComment($aEvent['data']['comment']),
			'comment_count' => $aEvent['data']['comment_count'],
			'user' => array(
				'id' => $aEvent['data']['user_info']['id'],
				'name' => $aEvent['data']['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['data']['user_info']['profile'],
				'vip' => $aEvent['data']['user_info']['vip'],
			),
		);

		foreach($aEvent['data']['images'] as $images){
			$aResult['images'][] = SYSTEM_RESOURCE_URL . $images;
		}

		$aResult['support'] = $aEvent['data']['support'];
		$aResult['support_count'] = $aEvent['data']['support_count'];

		//为赞的用户拼头像地址
		foreach($aResult['support'] as &$aSupportUser){
			$aSupportUser['profile'] = SYSTEM_RESOURCE_URL . $aSupportUser['profile'];
		}

		if($aEvent['data']['source_info']){
			//调整source的字段
			$aResult['source'] = array(
				'id' => $aEvent['data']['source_info']['id'],
				'user' => array(
					'id' => $aEvent['data']['source_info']['user_info']['id'],
					'name' => $aEvent['data']['source_info']['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aEvent['data']['source_info']['user_info']['profile'],
					'vip' => $aEvent['data']['source_info']['user_info']['vip'],
				),
				'content' => $aEvent['data']['source_info']['content'],
				'transmit_times' => $aEvent['data']['source_info']['transmit_times'],
				'time' => $aEvent['data']['source_info']['create_time'],
			);
		}
		return $aResult;
	}

	/**
	 * 过滤我被他人在任意一条说说里的评论或回复中(一二级评论)@的动态 type = 100
	 * @param type $aEvent
	 */
	private static function _filterMyAtShuoShuoInCommentEvent($aEvent){
		$aCommentList = self::_filterShuoShuoComment($aEvent['data']['comment'], $aEvent['data_id']);
		$commentTime = $aCommentList['comment_time'];
		unset($aCommentList['comment_time']);

		$aResult = array(
			'type' => $aEvent['type'],
			'sender' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'shuoshuo_id' => $aEvent['data']['id'],
			'content' => $aEvent['data']['content'],
			'source' => array(),
			'images' => array(),
			'time' => $commentTime,
			'comment' => $aCommentList,
			'comment_count' => $aEvent['data']['comment_count'],
		);

		foreach($aEvent['data']['images'] as $images){
			$aResult['images'][] = SYSTEM_RESOURCE_URL . $images;
		}

		if(isset($aEvent['data']['user_info'])){
			$aResult['user'] = $aEvent['data']['user_info'];
		}

		$aResult['support'] = $aEvent['data']['support'];
		$aResult['support_count'] = $aEvent['data']['support_count'];

		//为赞的用户拼头像地址
		foreach($aResult['support'] as &$aSupportUser){
			$aSupportUser['profile'] = SYSTEM_RESOURCE_URL . $aSupportUser['profile'];
		}

		if($aEvent['data']['source_info']){
			//调整source的字段
			$aResult['source'] = array(
				'id' => $aEvent['data']['source_info']['id'],
				'user' => array(
					'id' => $aEvent['data']['source_info']['user_info']['id'],
					'name' => $aEvent['data']['source_info']['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aEvent['data']['source_info']['user_info']['profile'],
					'vip' => $aEvent['data']['source_info']['user_info']['vip'],
				),
				'content' => $aEvent['data']['source_info']['content'],
				'transmit_times' => $aEvent['data']['source_info']['transmit_times'],
				'time' => $aEvent['data']['source_info']['create_time'],
			);
		}
		return $aResult;
	}

	/**
	 * 过滤我被他人在任意一条说说里回复我的评论(一级评论)或回复(二级评论)的动态 type=3,4
	 * @param type $aEvent
	 * @return type
	 */
	private static function _filterMyReplyShuoShuoEvent($aEvent){
		$aCommentList = self::_filterShuoShuoComment($aEvent['data']['comment'], $aEvent['data_id']);
		$commentTime = $aCommentList['comment_time'];
		unset($aCommentList['comment_time']);
		$aResult = array(
			'type' => $aEvent['type'],
			'sender' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'comment_id' => $aEvent['data_id'],
			'shuoshuo_id' => $aEvent['data']['id'],
			'content' => $aEvent['data']['content'],
			'source' => array(),
			'images' => array(),
			'comment' => &$aCommentList,
			'time' => $commentTime,
			'comment_count' => $aEvent['data']['comment_count'],
		);

		if(isset($aEvent['data']['images'])){
			foreach($aEvent['data']['images'] as $images){
				$aResult['images'][] = SYSTEM_RESOURCE_URL . $images;
			}
		}

		if($aEvent['type'] == 4){
			$aResult['user'] = array(
				'id' => $aEvent['data']['user_info']['id'],
				'name' => $aEvent['data']['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['data']['user_info']['profile'],
				'vip' => $aEvent['data']['user_info']['vip'],
			);
		}

		$aResult['support'] = $aEvent['data']['support'];
		$aResult['support_count'] = $aEvent['data']['support_count'];

		//为赞的用户拼头像地址
		foreach($aResult['support'] as &$aSupportUser){
			$aSupportUser['profile'] = SYSTEM_RESOURCE_URL . $aSupportUser['profile'];
		}

		if($aEvent['data']['source_info']){
			//调整source的字段
			$aResult['source'] = array(
				'id' => $aEvent['data']['source_info']['id'],
				'user' => array(
					'id' => $aEvent['data']['source_info']['user_info']['id'],
					'name' => $aEvent['data']['source_info']['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aEvent['data']['source_info']['user_info']['profile'],
					'vip' => $aEvent['data']['source_info']['user_info']['vip'],
				),
				'content' => $aEvent['data']['source_info']['content'],
				'transmit_times' => $aEvent['data']['source_info']['transmit_times'],
				'time' => $aEvent['data']['source_info']['create_time'],
			);
		}

		return $aResult;
	}

	/**
	 * 过滤他人在我的留言板发表留言和回复留言的动态 type=8,9
	 * @param type $aEvent
	 */
	private static function _filterMyMessageBoardEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'sender' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'message_id' => $aEvent['data']['id'],
			'content' => '',
			'time' => 0,
			'message_tree' => array(
				'time' => $aEvent['data']['create_time'],
				'content' => $aEvent['data']['content'],
				'reply_count' => $aEvent['data']['reply_count'],
				'user' => array(
					'id' => $aEvent['data']['sender_user_id'],
				),
				'reply' => array(),
			),
		);

		foreach($aEvent['data']['reply'] as $aReply){
			$aResult['message_tree']['reply'][] = array(
				'id' => $aReply['id'],
				'is_sender' => $aReply['sender_user_id'] == $aResult['sender']['id'] ? 1 : 0,
				'content' => $aReply['content'],
				'time' => $aReply['create_time'],
			);
			if($aReply['id'] == $aEvent['data_id']){
				$aResult['content'] = $aReply['content'];
				$aResult['time'] = $aReply['create_time'];
			}
		}

		return $aResult;
	}

	private static function _filterFeedbackResultEvent($aEvent){
		return array(
			'type' => $aEvent['type'],
			'time' => $aEvent['data']['create_time'],
			'is_pass' => $aEvent['data']['status'] == 2 ? 1 : 0,
			'reward' => $aEvent['data']['reward'],
			'reason' => $aEvent['data']['reason'],
			'reply' => $aEvent['data']['reply'],
			'es' => array(
				'id' => $aEvent['data']['es_id'],
				'type_id' => $aEvent['data']['es_type'],
				'es_content' => $aEvent['data']['es'],
			),
		);
	}

	/**
	 * 过滤我的赛事结束动态  type=20
	 * @param type $aEvent
	 */
	private static function _filterMyMatchFinishEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'match_id' => $aEvent['match_id'],
			'title' => $aEvent['match_name'],
			'description' => $aEvent['description'],
			'best_score' => $aEvent['best_score'],
			'champion_score' => $aEvent['champion_score'],
			'image' => SYSTEM_RESOURCE_URL . $aEvent['match_profile'],
			'member_count' => $aEvent['member_count'],
			'start_time' => $aEvent['match_start_time'],
			'end_time' => $aEvent['match_end_time'],
			'users' => array(),
			'time' => $aEvent['match_end_time'],
		);

		if($aEvent['win_info']){
			$aResult['win_info'] = array(
				'type' => $aEvent['win_info']['type'],
				'receive_time' => $aEvent['win_info']['receive_time'],
				'awards_info' => $aEvent['win_info']['awards_info'],
			);
			$aResult['ranking'] = $aEvent['win_info']['ranking'];
			if($aEvent['win_info']['awards_info']){
				$aResult['awards_info'] = $aEvent['win_info']['awards_info'];
			}
		}

		foreach($aEvent['users'] as $aTopUser){
			$aResult['users'][] = array(
				'id' => $aTopUser['user_info']['id'],
				'name' => $aTopUser['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aTopUser['user_info']['profile'],
				'vip' => $aTopUser['user_info']['vip'],
			);
		}

		return $aResult;
	}

	/**
	 * 过滤我的PK动态
	 * @param type $aEvent
	 */
	private static function _filterMyPkEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'pk_id' => $aEvent['data']['id'],
			'mission_id' => $aEvent['data']['mission_id'],
			'mission' => $aEvent['data']['mission_name'],
			'opposite_user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'es_count' => $aEvent['data']['es_counts'],
			'receiver_start_time' => $aEvent['data']['receiver_user_start_time'],
			'attachment_gold' => $aEvent['data']['attachment_gold'],
			'duration' => $aEvent['data']['duration'],
			'pk_send_time' => $aEvent['data']['create_time'],
			'pk_over_time' => $aEvent['data']['over_time'],
			'sender_score' => $aEvent['data']['sender_score'],
			'receiver_score' => $aEvent['data']['receiver_score'],
		);

		//生成被挑战者的用户信息
		$aUser = checkUserLogin();
		$imSender = $aUser['id'] == $aEvent['data']['sender_user_id'];
		if($imSender){
			//如果当前用户是发起者
			$aResult['opposite_user']['is_sender'] = 0; //则对方不是发起者
			$aResult['is_opposite_over_time'] = $aEvent['data']['receiver_user_start_time'] ? 1 : 0;	//对方是否超时
			$aResult['is_opposite_receive_attachment'] = $aEvent['data']['is_receive_attachment'] == 1 ? 1 : 0;
			$aResult['is_win'] = ($aUser['id'] == $aEvent['data']['winner_user_id']) ? 1 : 0;
		}else{
			$aResult['opposite_user']['is_sender'] = 1; //则对方就是发起者
			$aResult['is_opposite_over_time'] = $aEvent['data']['sender_user_start_time'] ? 1 : 0;
			$aResult['is_opposite_receive_attachment'] = 1;
			$aResult['is_win'] = $aEvent['data']['receiver_user_id'] == $aEvent['data']['winner_user_id'] ? 1 : 0;
		}

		if($aEvent['type'] == 30){
			//取发起PK时间
			$aResult['time'] = $aEvent['data']['create_time'];
		}elseif($aEvent['type'] == 31){
			//取拒绝赌注时间
			$aResult['time'] = $imSender ? $aEvent['data']['receiver_user_start_time'] : $aEvent['data']['sender_user_start_time'];
		}elseif($aEvent['type'] == 32){
			//取结束做题时间
			$aResult['time'] = max($aEvent['data']['sender_user_start_time'], $aEvent['data']['sender_user_end_time']);
		}

		return $aResult;
	}

	private static function _filterShuoShuoComment($aCommentList, $commentId = 0){
		if(!$aCommentList){
			return array();
		}
		$aUser = checkUserLogin();
		$userId = &$aUser['id'];
		$aResult = array();
		foreach($aCommentList as $aRootComment){
			$aFilterRootComment = array(
				'id' => $aRootComment['id'],
				'content' => $aRootComment['content'],
				'time' => $aRootComment['create_time'],
				'user' => array(
					'id' => $aRootComment['user_info']['id'],
					'name' => $aRootComment['user_info']['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aRootComment['user_info']['profile'],
					'vip' => $aRootComment['user_info']['vip'],
				),
				'reply_count' => $aRootComment['reply_count'],
				'reply' => array(),
			);

			if($commentId == $aRootComment['id']){
				$aResult['comment_time'] = $aRootComment['create_time'];
			}

			if(!isset($aRootComment['reply'])){
				continue;
			}

			foreach($aRootComment['reply'] as $aCommentReply){
				$aFilterRootComment['reply'][] = array(
					'id' => $aCommentReply['id'],
					'content' => $aCommentReply['content'],
					'time' => $aCommentReply['create_time'],
					'user' => array(
						'id' => $aCommentReply['user_info']['id'],
						'name' => $aCommentReply['user_info']['name'],
						'profile' => SYSTEM_RESOURCE_URL . $aCommentReply['user_info']['profile'],
						'vip' => $aCommentReply['user_info']['vip'],
					),
					'reply_user' => array(
						//被回复的用户
						'id' => $aCommentReply['reply_user_info']['id'],
						'name' => $aCommentReply['reply_user_info']['name'],
						'profile' => SYSTEM_RESOURCE_URL . $aCommentReply['reply_user_info']['profile'],
						'vip' => $aCommentReply['reply_user_info']['vip'],
					),
				);

				if($commentId == $aCommentReply['id']){
					$aResult['comment_time'] = $aCommentReply['create_time'];
				}
			}
			$aResult[] = $aFilterRootComment;
		}

		return $aResult;
	}

	public static function _filterGivePropEvent($aEvent){
		$aResult = array(
			'type' => $aEvent['type'],
			'user' => array(
				'id' => $aEvent['user_info']['id'],
				'name' => $aEvent['user_info']['name'],
				'profile' => SYSTEM_RESOURCE_URL . $aEvent['user_info']['profile'],
				'vip' => $aEvent['user_info']['vip'],
			),
			'time' => $aEvent['data']['create_time'],
			'message' => $aEvent['data']['message'],
			'prop' => array(
				'name' => $aEvent['data']['name'],
				'name' => $aEvent['data']['name'],
				'image' => SYSTEM_RESOURCE_URL . $aEvent['data']['ico'],
				'desc' => $aEvent['data']['description'],
				'price' => $aEvent['data']['price'],
			),
		);

		return $aResult;
	}

}

function addPersonalMessage($aData){
	$oPersonalMessage = m('PersonalMessage');
	return $oPersonalMessage->addPersonalMessage($aData);
}

function deletePersonalMessage($id = '', $userId = '', $type = '', $dataId = ''){
	$oPersonalMessage = m('PersonalMessage');
	return $oPersonalMessage->deletePersonalMessage($id, $userId, $type, $dataId);
}

function getPersonalMessageList($userId, $aType = array(), $dataId = 0, $page = 1, $pageSize = 20){

	$aEventList = m('PersonalMessage')->getPersonalMessageList($userId, $aType, $dataId, $page, $pageSize);

	return PersonalMessage::filterEventList($aEventList);
}

function getPersonalMessageById($personalMessageId){
	$oPersonalMessage = m('PersonalMessage');
	return $oPersonalMessage->getPersonalMessageById($personalMessageId);
}