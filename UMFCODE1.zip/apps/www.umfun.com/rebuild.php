<?php
require '../../rebuild/apps/home/web/index.php';