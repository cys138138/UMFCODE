<link  href="<?php echo $GLOBALS['RESOURCE']['style_home']; ?>" type="text/css" rel="stylesheet">
	<?php echo about\widgets\Header::widget(); ?>
    <!--头部 [-->
    <div class="header">
        <div class="column c">
            <h1 class="reg_logo">
                <a href="/">
                    <span class="hide">umFun-游戏你的学习</span>
                    <i class="reg_icon"></i>
                    <span class="reg_sublogo">找回密码</span>
                </a>
            </h1>
            <h2 class="reg_prompt">
                <span class="hide">中国最大中小学生在线游戏化学习平台</span>
                <i class="reg_icon icon_reg_prompt"></i>
            </h2>
        </div>
    </div>
    <!--头部 ]-->

    <!--主体 [-->
    <div class="main reg_main">
        <div class="column">
			<form method="post" id="forgotForm" class="forgotForm" >
				<div class="reg_forgetpass">
					<div class="hd">
						<i class="reg_icon icon_reg_point"></i>
						<h2>请输入要找回账户的邮箱地址或手机号码!</h2><br />
						通过邮箱找回，系统将发送 重置密码链接 邮件至您的邮箱，请与15分钟内点击该链接重置密码！<br />
						通过手机找回，系统将发送 手机校验码至您的注册手机，请与15分钟内输入手机校验码重置密码！<br />
					</div>
					<div class="item">
						<div class="name">邮箱或手机：</div>
						<div class="controls"><input class="text" type="text" name="email" id="email"/></div>
					</div>
					<div class="item" id="mobileCodeWraper" style="display:none;">
						<div class="name">手机校验码：</div>
						<div class="controls"><input class="text" type="text" name="mobileCode" id="mobileCode" /></div>
					</div>
					<div class="item" id="passwordWraper" style="display:none;">
						<div class="name">新密码：</div>
						<div class="controls"><input class="text" type="password" name="password" id="password" /></div>
					</div>
					<div class="item" id="surePasswordWraper" style="display:none;">
						<div class="name">重输密码：</div>
						<div class="controls"><input class="text" type="password" name="surePassword" id="surePassword" /></div>
					</div>
					<div class="item">
						<div class="name">验证码：</div>
						<div class="controls">
							<input class="text code" type="text" name="captcha" id="fgotCaptcha"/>
							<a href="##" onclick="return refreshCatcph();" class="code_active"><img src="<?php echo url('m=Captcha&a=display&name=fgotCaptcha'); ?>" id="verify_Img" width="100" height="40" alt=""/></a>
						</div>
					</div>
					<div class="item">
						<input id="action" type="hidden" value="" />
						<input class="reg_icon reg_btn_02" id="applyByEmail" type="button" value="申请重置密码" onclick="return checkForm();" style="display:none;" />
						<input class="reg_icon reg_btn_02" id="apply" type="button" value="申请重置密码" onclick="return checkForm();"/>
						<input class="reg_icon reg_btn_02" id="submitApply" type="button" value="申请重置密码" onclick="sureApplyByMobile();" style="display:none;" />
						<input class="reg_icon reg_btn_02" id="applyByMobile" type="button" value="申请重置密码" onclick="getMobileCode();" style="display:none;" />
						<input class="reg_icon reg_btn_02" id="goLogin" type="button" value="立刻前往登陆" onclick="gotoLogin();" style="display: none;">
						<!---<input class="reg_icon reg_btn_05" type="button" value="邮件已发送！"/>-->
					</div>
				</div>
			</form>

        </div>
    </div>
    <!--主体 ]-->

    <?php echo about\widgets\Footer::widget(); ?>

<script type="text/javascript">
<?php echo $validateJs; ?>

function refreshCatcph(){
	var fgotCaptcha = "<?php echo url('m=Captcha&a=display&name=fgotCaptcha'); ?>?" + Math.floor(Math.random() * 10000);
	$('#verify_Img').attr('src', fgotCaptcha);
	$('#fgotCaptcha').val('');
}

$(function(){
	$('#apply').attr("disabled", false);
});

//30秒倒计时
var inputCaptcha =0;
var sendEmail = 0
var forgotSwitch =0;
function sendAfter(){
	if(forgotSwitch== 1){
		if(inputCaptcha < 31){
			var captchaIndexTime = 30;
			var captchaIndexTimeInterval = setInterval(function(){
				if(captchaIndexTime > 0){
					captchaIndexTime--;
					$('#apply').val('处理中...' + captchaIndexTime + '秒内返回结果');
				}else{
					clearInterval(captchaIndexTimeInterval);
					sendAfter();
					$('#apply').attr('class','reg_icon reg_btn_02').val('申请重置密码');
					$('#apply').attr('onclick',"return checkForm();");
				}
			}, 1000);
		}else{
			inputCaptcha = 0;
			forgotSwitch=0;
		}
	}else{
		inputCaptcha = 0;
		forgotSwitch=0;
	}
}

function sendAfterAgin(){
	if(sendEmail < 31){
		setTimeout("sendEmail++;$('#apply').val('" + ( 30 - sendEmail ) + "秒后可重新发送');sendAfterAgin();", 1000);
	}else{
		$('#apply').attr("disabled", false).attr('class', 'reg_icon reg_btn_02').attr("onclick", 'return checkForm();').val('申请重置密码');
		sendEmail = 0;
	}
}


function  _after_checkForm(){
	$('#apply').attr("disabled", true).attr('class','reg_icon reg_btn_05').val('请等待处理...');
	$.ajax({
		type : 'post',
		url : '<?php echo url('m=Account&a=forgotPassword'); ?>',
		data : $('#forgotForm').serialize(),
		beforeSend:function(){
//			$('#apply').attr('class', 'reg_icon reg_btn_05').attr("onclick", '').val('处理中...30秒内返回结果');forgotSwitch=1;sendAfter();
		},
		complete:function(){
			forgotSwitch=0;
		},
		timeout:29000,
		success : function(result){
			if(result.status == 1){
				UBox.show('验证码己发送至新邮箱',1);
				sendAfterAgin();//成功后到计时30S
			}else{
				UBox.show(result.msg);
				refreshCatcph();
			}
		},
		error : function(){
			$('#apply').attr("disabled", false).attr('class', 'reg_icon reg_btn_02').attr("onclick", 'return checkForm();').val('申请重置密码');
			UBox.show('网络可能有点慢，请稍候再进行登陆!',-1);
		}
	});
	return false;
}

//60秒倒计时
var X = 0, T = 0;
function afterSendVerify(){
	if(X < 61){
		T = setTimeout("X++;$('#applyByMobile').val('"+(60-X)+"秒后可再次发送');afterSendVerify();", 1000);
	}else{
		X = 0;
		clearTimeout(T);
		$('#applyByMobile').val('再次发送校验码').attr("onclick", 'getMobileCode();');
		$('#applyByMobile').removeAttr('disabled');
		$('#applyByMobile').removeClass('reg_btn_05');
		$('#applyByMobile').addClass('reg_btn_02');
		$('#email').removeAttr('disabled');
	}
}

function gotoLogin(){
	window.location.href = '<?php echo url('m=index&a=index'); ?>';
}

function reSetPassword(){
	var password = $('#password').val(),
	surePassword = $('#surePassword').val(),
	action = $('#action').val(),
	fgotCaptcha = $('#fgotCaptcha').val(),
	oPassword = new Validater('password'),
	isPassword = oPassword.length(6, 16);

	if(isPassword != true){
		UBox.show('密码格式格式不正确！', -1);
		return;
	}
	if(password != surePassword){
		UBox.show('两次密码输入不一样！', -1);
		return;
	}
	$('#submitApply').attr("disabled", 'true');
	$('#submitApply').removeClass('reg_btn_02');
	$('#submitApply').addClass('reg_btn_05');
	ajax({
		url : '<?php echo url("m=Account&a=resetPasswordByMobile"); ?>',
		data : {password : password, surePassword : surePassword, captcha : fgotCaptcha, action : action},
		success : function(aResult){
			if(aResult.status == 1){
				UBox.show(aResult.msg, aResult.status);
				$('#goLogin').show();
			}else{
				$('#submitApply').removeAttr('disabled');
				$('#submitApply').removeClass('reg_btn_05');
				$('#submitApply').addClass('reg_btn_02');
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function sureApplyByMobile(){
	var mobile = $('#email').val(),
	mobileCode = $('#mobileCode').val(),
	fgotCaptcha = $('#fgotCaptcha').val(),
	oMobileCode = new Validater('mobileCode'),
	oFgotCaptcha = new Validater('captcha'),
	oMobile = new Validater('email'),
	isMobileCode = oMobileCode.isNumber(6);
	isMobile = oMobile.isPhone(),
	isFgotCaptcha = oFgotCaptcha.length(5, 5);
	if(isMobile != true){
		UBox.show('手机格式不正确！', -1);
		return;
	}
	if(isMobileCode != true){
		UBox.show('手机校验码格式不正确！', -1);
		return;
	}
	if(isFgotCaptcha != true){
		UBox.show('验证码格式不正确！', -1);
		return;
	}
	$('#submitApply').attr("disabled", 'true');
	$('#submitApply').removeClass('reg_btn_02');
	$('#submitApply').addClass('reg_btn_05');
	ajax({
		url : '<?php echo url("m=Account&a=verifyMobileMessage"); ?>',
		data : {mobile : mobile, mobileCode : mobileCode, captcha : fgotCaptcha},
		success : function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				$('#mobileCodeWraper').hide();
				$('#email').attr("disabled", 'true');
				$('#applyByMobile').hide();
				$('#passwordWraper').show();
				$('#surePasswordWraper').show();
				$('#action').val(aResult.data);
				$('#submitApply').attr("onclick", 'reSetPassword();');
				$('#submitApply').val('保存新密码');
				$('#submitApply').removeAttr('disabled');
				refreshCatcph();

			}else{
				$('#applyByMobile').val('再次发送校验码').attr("onclick", 'getMobileCode();');
				$('#applyByMobile').removeAttr('disabled');
				$('#email').removeAttr('disabled');
				$('#submitApply').removeAttr('disabled');
			}
			$('#submitApply').removeClass('reg_btn_05');
			$('#submitApply').addClass('reg_btn_02');
		}
	});
}

function getMobileCode(){
	var mobile = $('#email').val(),
	oMobile = new Validater('email'),
	isEmail = oMobile.isEmail(),
	fgotCaptcha = $('#fgotCaptcha').val(),
	oFgotCaptcha = new Validater('captcha'),
	isFgotCaptcha = oFgotCaptcha.length(5, 5),
	isMobile = oMobile.isPhone();
	$('#apply').hide();
	if(isFgotCaptcha != true){
		UBox.show('验证码格式不正确！', -1);
		return;
	}
	if(isEmail == true){
		$('#applyByEmail').show();
		$('#applyByMobile').hide();
		$('#mobileCodeWraper').hide();
		$('#submitApply').hide();
	}
	if(isMobile == true){
		$('#mobileCodeWraper').show();
		$('#applyByMobile').val('免费获取校验码');
		$('#applyByMobile').attr("disabled", 'true');
		$('#applyByMobile').show();
		$('#submitApply').show();
		$('#applyByEmail').hide();
		$('#email').attr("disabled", 'true');
		$('#applyByMobile').removeClass('reg_btn_02');
		$('#applyByMobile').addClass('reg_btn_05');
		ajax({
			url : '<?php echo url("m=Account&a=sendMobileMessage"); ?>',
			data : {mobile : mobile, captcha : fgotCaptcha},
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status == 1){
					afterSendVerify();
				}else{
					$('#applyByMobile').val('再次发送校验码').attr("onclick", 'getMobileCode();');
					$('#applyByMobile').removeAttr('disabled');
					$('#email').removeAttr('disabled');
				}
			}
		});
	}
}

$(function(){
		$('#email').change(function(){
			if(!this.value){
				return false;
			}
			var oEmailRegister = new Validater('email'),
			isEmail = oEmailRegister.isEmail(),
			isMobile = oEmailRegister.isPhone();
			if (isEmail !== true && isMobile !== true) {
				UBox.show('邮箱或手机格式错误', -1);
				return false;
			}
			if(isMobile == true){
				$('#mobileCodeWraper').show();
				$('#applyByMobile').show();
				$('#applyByMobile').val('免费获取校验码');
				$('#applyByEmail').hide();
			}
			if(isEmail == true){
				$('#applyByEmail').show();
				$('#applyByMobile').hide();
				$('#mobileCodeWraper').hide();
				$('#submitApply').hide();
			}
			$('#apply').hide();
		});
	});
</script>
</div>

<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>