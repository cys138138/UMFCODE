<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_center2']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_center2']; ?>"></script>

<div class="container center">
<?php 
	displayNav($userId);
 ?>
<!--主体 [-->
<div class="main">
	<div class="column c">

		<!--好友 [-->
		<div class="mod layout setup_mod">
			<div class="hd">
				<ul>
					<?php display('account/nav.html.php'); ?>
				</ul>
			</div>
			<div class="bd c">
				<div class="edit_gamenum">
					<form id="settingInformation">
						<div class="item c">
							<div class="name">每天接受PK次数：</div>
							<div class="controls">
								<select name="accept_pk_count" id="accept_pk_count">
									<?php 
									for($i = $acceptPkCount['min']; $i <= $acceptPkCount['max']; $i++){
											if($aUserInfo['accept_pk_count'] == $i){
												echo '<option selected="selected" value="' . $i . '">' . $i . '次</option>';
											}else{
												echo '<option value="' . $i . '">' . $i . '次</option>';	
											}
										}
									?>
								</select> 
								<span>(小提示：当设置为0时则关闭PK)</span>
							</div>
						</div>
						<div class="item">
							<button class="use_btn" type="button" onclick="checkForm();">保存</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!--好友 ]-->

	</div>
</div>
<!--主体 ]-->



<script type="text/javascript">
	<?php echo $validateJs; ?>
	function _after_checkForm(){
		ajax({
			url : '<?php echo url('m=Account&a=editGameSetting'); ?>',
			data : $('#settingInformation').serialize(),
			success : function(result){
				UBox.show(result.msg, result.status, result.data);
			}
		});
	}
</script>