<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>游戏化学习-优满分(UMFun)</title>
<meta name="keywords" content="游戏化学习，游戏化教育, 在线学习-优满分(UMFun) "/>
<meta name="description" content="中国最大中小学生在线游戏化学习平台，专注于向中小学生提供最有乐趣的游戏式学习体验，旨在通过游戏提高学习效能及学习成绩-优满分(UMFun)"/>
<style>
	body {margin:0;padding:0;}
	.mastery {text-align:center;}
	.mastery img {vertical-align:top;}
	.m1 {background-color:#343434;}
	.m2 {background-color:#1b77f4;}
	.m3 {background-color:#ffd602;}
	.m4 {background-color:#242527;}
	.m5 {background-color:#1b77f4;}
	.m6 {background-color:#ffd602;}
	.m7 {background-color:#343434;}
</style>
</head>
<body>

<div class="mastery">
	<?php for($i = 1; $i <= 7; $i++){ ?>
	<div class="m<?php echo $i; ?>"><img src="<?php echo SYSTEM_RESOURCE_URL . 'view2/images/account/mastery/m' . $i . '.jpg'; ?>" alt=""/></div>
	<?php } ?>
</div>

</body>
<?php echo SYSTEM_STATISTICS_CODE; ?>
</html>