<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_center2']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_center2']; ?>"></script>

<div class="container center">
<?php 
	displayNav($userId);
	$isBind = false;
	if($aUserInfo['mobile']){
		$isBind = true;
	}
 ?>
<!--主体 [-->
<div class="main">
    <div class="column c">

        <!--好友 [-->
        <div class="mod layout setup_mod">
            <div class="hd">
                <ul>
					<?php display('account/nav.html.php'); ?>
                </ul>
            </div>
            <div class="bd c">
                <div class="edit_mobile">
                    <form id="settingInformation">
                        <div class="item c">
                            <div class="name">绑定手机号码：</div>
                            <div class="controls"><input type="text" id="mobile" name="mobile" class="text" value="<?php echo $aUserInfo['mobile'] ? $aUserInfo['mobile'] : ''; ?>" /></div>
                        </div>
						<div class="item c">
                            <div class="name">手机校验码：</div>
                            <div class="controls"><input type="text" id="mobileCode" name="mobileCode" class="text" value="" /></div>
                        </div>
						<div class="item c">
                            <div class="name">验证码</div>
                            <div class="controls">
								<input class="text" style="width:132px;" type="text" placeholder="请输入验证码" id="captcha" name="captcha"/>
								<a style="margin-left:5px;" href="javascript:;" title="换一个验证码"><img width="85" height="40" id="verify_register_img" onclick="refreshRegiterCaptcha();"/>
								</a>
							</div>
                        </div>
                        <div class="item">
                            <input type="button" class="use_btn" id="sendMobileCode" value="免费获取校验码" onclick="getMobileCode();" />
                            <input type="button" class="use_btn" id="sureSetMobile" value="绑定手机" onclick="sureSetting();" style="margin-left:5px;" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--好友 ]-->

    </div>
</div>
<!--主体 ]-->



<script type="text/javascript">
	<?php echo $validateJs; ?>
	
	function refreshRegiterCaptcha(){
		$('#verify_register_img').attr('src', getCaptcha());
		$('#captcha').val('');
		$('#captcha').focus();
	}
	
	function getCaptcha(){
		return '<?php echo url('m=Captcha&a=display&name=fgotCaptcha'); ?>?' + Math.floor(Math.random() * 10000);
	}
	
	//60秒倒计时
	var X = 0, T = 0;
	function afterSendVerify(){
		if(X < 61){
			T = setTimeout("X++;$('#sendMobileCode').val('"+(60-X)+"秒后可再次发送');afterSendVerify();", 1000);
		}else{
			X = 0;
			clearTimeout(T);
			$('#sendMobileCode').val('再次发送校验码').attr("onclick", 'getMobileCode();').removeAttr('disabled').attr('style', 'background-color:#f30');
			$('#mobile').removeAttr('disabled');
		}
	}
	function getMobileCode(){
		if(!checkForm()){
			return false;
		}
		var mobile = $('#mobile').val(),
		captcha = $('#captcha').val(),
		oCaptcha = new Validater('captcha'),
		isCaptcha = oCaptcha.length(5, 5);
		if(captcha == ''){
			UBox.show('请输入验证码！', -1);
			return;
		}
		if(isCaptcha != true){
			UBox.show('验证码格式不正确！',-1);
			return ;
		}
		$('#mobile').attr('disabled', true);
		$('#sendMobileCode').attr('disabled', true).attr('style', 'background-color:#ccc');
		ajax({
			url : '<?php echo url("m=Account&a=sendMobileMessage"); ?>',
			data : {mobile : mobile, type : 1, captcha : captcha},
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status == 1){
					afterSendVerify();
					refreshRegiterCaptcha();
					$('#captcha').val('');
					$('#mobileCode').focus();
				}else{
					$('#sendMobileCode').val('再次发送校验码').bind("click", getMobileCode).attr('style', 'background-color:#f30').removeAttr('disabled');
					$('#mobile').removeAttr('disabled');
				}
			}
		});
	}
	
	function sureSetting(){
		if(!checkForm()){
			return false;
		}
		var oMobileCode = new Validater('mobileCode'),
		isMobileCode = oMobileCode.isNumber(6),
		captcha = $('#captcha').val(),
		oCaptcha = new Validater('captcha'),
		isCaptcha = oCaptcha.length(5, 5);
		if($('#mobileCode').val() == ''){
			UBox.show('请输入手机校验码！', -1);
			return;
		}
		if($('#captcha').val() == ''){
			UBox.show('请输入验证码！', -1);
			return;
		}
		if(isCaptcha != true){
			UBox.show('验证码格式不正确！',-1);
			return ;
		};
		if(isMobileCode != true){
			UBox.show('手机校验码格式不正确！', -1);
			return; 
		}
		$('#sureSetMobile').attr('disabled', true).attr('style', 'background-color:#ccc;margin-left:5px;');
		$.ajax({
			type : 'post',
			url : '<?php echo url('m=Account&a=settingMobileAccount'); ?>',
			data : {mobile : $('#mobile').val(), mobileCode : $('#mobileCode').val(), captcha : $('#captcha').val()},
			success : function(result){
				$('#sureSetMobile').removeAttr('disabled').attr('style', 'background-color:#f30;margin-left:5px;');
				if(result.status == 1){
					UBox.show(result.msg, result.status, '<?php echo url('m=Account&a=showMobileSetting'); ?>');
				}else{
					UBox.show(result.msg, result.status);
				}
			},
			error : function(){
				alert('网络可能有点慢，请稍候再进行登陆!');
			}
		});
	}
	$(function(){
		refreshRegiterCaptcha();
	});
</script>