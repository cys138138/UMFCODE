<!doctype html>
<html>
<head>
<meta charset="UTF-8" />
<title>游戏化学习-优满分(UMFun)</title>
<meta name="keywords" content="游戏化学习，游戏化教育, 在线学习-优满分(UMFun) "/>
<meta name="description" content="中国最大中小学生在线游戏化学习平台，专注于向中小学生提供最有乐趣的游戏式学习体验，旨在通过游戏提高学习效能及学习成绩-优满分(UMFun)"/>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_global2']; ?>"/>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_account2']; ?>"/>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_global2']; ?>"></script>
<!--[if lte IE 6]><script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['dd_belated_png2']; ?>"></script><![endif]-->
</head>
<body>
<div class="intro_wrap" id="intro_wrap">
    <div id="intro_layer" class="intro_layer">
        <div class="column">
            <h1 class="fl"><a href="/"><i class="acc_ico acc_ico_intro_logo"></i></a></h1>
            <h2 class="desc fl">
            <a href="<?php echo url('m=Index&a=index'); ?>">首页</a> |
                <a href="<?php echo url('m=Account&a=showParentIntroduce'); ?>">我是家长</a> |
                <a href="<?php echo url('m=Match&a=showNewCenter'); ?>">赛事中心</a> |
                <a href="<?php echo url('m=Exchange&a=index'); ?>">兑换商城</a>
            </h2>
            <span class="follow fr">
                <a id="loginbtn" href="<?php echo url('m=Login&a=showLogin', '', APP_LOGIN); ?>">登录</a> |
                <a id="regbtn" href="<?php echo url('m=Login&a=showLogin', '', APP_LOGIN); ?>">注册</a>
            </span>
        </div>
    </div>

    <div class="intro_mod">
        <div class="explain explain1">
            <div class="c column">
                <div class="tc info">
                    <h2>UMFun(优满分)—最具创新的游戏化学习网站</h2>
                    <p class="desc">互联网在线教育颠覆式开拓者<br/><span>五至九年级</span>现火爆开放中！让你上瘾的游戏，好玩，根本停不下来！</p>
                    <p class="btnbox">
                        <a href="javascript:;" id="btnJiathis" class="jiathis jiathis_txt jialike btn">立刻分享给其他小伙伴<i class="acc_ico acc_ico_share"></i></a>
						<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1398223093764561" charset="utf-8"></script>
                    </p>
                </div>
            </div>
        </div>
        <div class="explain explain2">
            <div class="c column">
                <div class="tc info">
                    <h2>游戏化学习</h2>
                    <p class="desc">
                        爱玩游戏的学生，学习能力一定很强！但学习能力强并不代表学习成绩就好，所以有很多同学很聪明、很会玩但学<br/>习成绩却并不理想，这个问题长期困扰着家长、老师和同学们。UMFun(优满分)正是为解决这一问题而生，通过游戏<br/>化学习的方法，将玩游戏和学习深度结合，能够在实现游戏目标的同时不知不觉的提升学习成绩！
                    </p>
                </div>
            </div>
        </div>
        <div class="explain explain3">
            <div class="c column">
                <div class="tl info">
                    <h2>修炼闯关</h2>
                    <p class="desc">1000多个教材同步关卡，每关都有不一样的挑战！<br/>修炼之路漫漫，三条命你能挑战过关吗？</p>
                    <p class="tips">不断闯关是升级（获得经验）最快的途径，<i class="acc_ico acc_ico_tips_left"></i><br/>也是玩家最基本的使命。</p>
                    <p class="sum">最近24小时内共有<em><?php echo $missionCount;?></em>人闯关！</p>
                </div>
            </div>
        </div>
        <div class="explain explain4">
            <div class="c bt column">
                <div class="tr info">
                    <h2>PK竞技</h2>
                    <p class="desc">这里有你认识的大部分同学，想跟他们一决高低吗？<br/>来场PK就知道了！</p>
                    <p class="tips"><i class="acc_ico acc_ico_tips_right"></i> PK是赚取金币最快的方式，<br/>金币可以购买更多好玩的道具或兑换喜欢的礼品。</p>
                    <p class="sum">最近24小时内共有<em><?php echo $pkCount;?></em>人发起PK！</p>
                </div>
            </div>
        </div>
        <div class="explain explain5">
            <div class="c bt column">
                <div class="tl info">
                    <h2>比赛争霸</h2>
                    <p class="desc">全国范围争霸赛，参赛无所畏惧，奖品志在必得！<br/>每场都有惊喜奖品发放！ </p>
                    <p class="tips">比赛奖品丰厚，有实物奖品也有经验和金币发放，冠、亚、季军均有奖励！<i class="acc_ico acc_ico_tips_left"></i></p>
                    <p class="sum">赛场当前共有<em><?php echo $matchCount;?></em>场比赛可参赛！</p>
                </div>
            </div>
        </div>
        <div class="explain explain6">
            <div class="c bt column">
                <div class="tr info">
                    <h2>兑换商城</h2>
                    <p class="desc">玩游戏也可以免费兑换你喜爱的礼品！<br/>为了喜爱的礼品，加油吧！</p>
                    <p class="tips"><i class="acc_ico acc_ico_tips_right"></i>等级和金币越多，可以兑换的礼品就越多、越贵重！</p>
                    <p class="sum">兑换商城当前共有<em><?php echo $exchangeCount;?></em> 款礼品可兑换！</p>
                </div>
                <div class="records">
                    <ul class="exc_list" id="excList">
                    </ul>
                </div>
            </div>
        </div>
        <div class="explain explain7">
            <div class="c bt column">
                <div class="tc info">
                    <h2>还有更多好玩的道具等你来领取！</h2>
                    <p class="btnbox">
                        <a class="btn" href="<?php echo url('m=Login&a=showLogin', '', APP_LOGIN); ?>">立刻体验游戏化学习<i class="acc_ico acc_ico_arrow"></i></a>
                    </p>
                </div>
            </div>
        </div>
        <div class="explain explain8">
            <div class="c bt column">
                <div class="tc info">
                    <h2>用户感受</h2>
                    <ul class="c list">
                        <li>优满分是我见过最棒的学习网站，但好像它又是一个游戏网站....</li>
                        <li>我在这里找到了几十个同学，原来大家都在玩....</li>
                        <li>感觉挺有效，好多人在闯关，排名不容易啊...</li>
                        <li>每天回家都会登录闯关，最近兑换了一个小机器人，真的有礼品哦！</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="explain explain9">
            <div class="c bt column">
                <div class="tc info">
                    <h2>加入优满分</h2>
                    <p class="desc">
                        玩游戏也是在学习，玩游戏也能提高学习成绩，同学们都在这，一起玩才是真的好玩！<br/>免费礼品兑换、超级大奖赛，奖品非你莫属！你的网络新空间，来这里才能证明你自己！<br/>加入优满分，爸爸妈妈再也不用担心你的学习！
                    </p>
                    <p class="btnbox">
                        <a class="btn" href="<?php echo url('m=Login&a=showLogin', '', APP_LOGIN); ?>">立刻加入优满分<i class="acc_ico acc_ico_arrow"></i></a>
                    </p>
                    <p class="copy">Copyright &copy; 优满分(UMFun.com) 2014</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
	function createTime(time){
		var nowTime = new Date();
		nowTime = parseInt(nowTime/1000);
		var cTime = nowTime - time;
		if(cTime < 60){
			return cTime + '秒前';
		}else if(cTime >= 60 && cTime < 3600){
			return parseInt(cTime/60) + '分钟前';
		}else if(cTime >= 3600 && cTime < 86400){
			return parseInt(cTime/3600) + '小时前';
		}else if(cTime >= 86400 && cTime < 604800){
			return parseInt(cTime/86400) + '天前';
		}else if(cTime >= 604800){
			return parseInt(cTime/604800) + '周前';
		}
	}
	
	$(function(){
		var aExchangeList = <?php echo json_encode($aExchangeList); ?>;
		var aExchangeListHtml = [];
		for(var i = 0; i < aExchangeList.length; i++){
			var aExchange = aExchangeList[i];
			aExchangeListHtml.push('<li>\
					<span class="ellipsis name">' + aExchange.user_info.name + '</span>\
				<span class="move">兑换了</span>\
				<span class="ellipsis thing">' + aExchange.good_info.name + '</span>\
				<span class="time">' + createTime(aExchange.create_time) + '</span>\
			</li>');
		}
		$('#excList').html(aExchangeListHtml);
		
		setTimeout(function(){
			document.getElementById('btnJiathis').onmouseover = undefined;
		}, 300);
		
		//滚动
		var intro = $('#intro_wrap');
        intro.find('.exc_list').marqueeMulti();
	});
	
	
	
</script>
</body>
<?php echo SYSTEM_STATISTICS_CODE; ?>
</html>