<div class="sidebar setting_sidebar">
	<style type="text/css">
		.addChengse{color:#FF3300;}
	</style>
	<dl class="setting_menu">
		<dt>
			<i class="icon icon_setting_user"></i>
			<strong>个人信息</strong>
		</dt>
		<dd><a href="<?php echo url('m=Account&a=showSettingInformation'); ?>"><em <?php if(get('a') == 'showSettingInformation'){ ?>class="addChengse" <?php } ?>>个人资料</em></a></dd>
		<dd><a href="<?php echo url('m=Account&a=showSettingPicture'); ?>"><em <?php if(get('a') == 'showSettingPicture'){ ?>class="addChengse" <?php } ?>>修改头像</em></a></dd>
		<!-- <dd><a href="<?php // echo url('m=Account&a=showSettingPicture'); ?>"><em <?php //if(get('a') == 'showSettingStyle'){ ?>class="addChengse" <?php // } ?>>风格设置</em></a></dd> -->
		<dt>
			<i class="icon icon_setting_school"></i>
			<strong>学校信息</strong>
		</dt>
		<dd><a href="<?php echo url('m=Account&a=showSchoolList'); ?>"><em <?php if(get('a') == 'showSchoolList'){ ?>class="addChengse" <?php } ?>>学校信息</em></a></dd>
		<dt>
			<i class="icon icon_setting_system"></i>
			<strong>系统设置</strong>
		</dt>
		<dd><a href="<?php echo url('m=Account&a=showSettingEmail'); ?>"><em <?php if(get('a') == 'showSettingEmail'){ ?>class="addChengse" <?php } ?>>修改邮箱账户</em></a></dd>
		<dd><a href="<?php echo url('m=Account&a=showSettingPassword'); ?>"><em <?php if(get('a') == 'showSettingPassword'){ ?>class="addChengse" <?php } ?>>修改账户密码</em></a></dd>
		<dd><a href="<?php echo url('m=Account&a=showGameSetting'); ?>"><em <?php if(get('a') == 'showGameSetting'){ ?>class="addChengse" <?php } ?>>修改游戏设置</em></a></dd>
	</dl>
</div>