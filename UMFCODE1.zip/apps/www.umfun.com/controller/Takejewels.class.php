<?php

/**
 * 争分夺宝 罗启军
 */

class TakejewelsController{
	
	/**
	 * 活动页面展示PC
	 */
	public function showActivity(){
		$agent = strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($agent,"netfront") || strpos($agent,"iphone") || strpos($agent,"midp-2.0") || strpos($agent,"opera mini") || strpos($agent,"ucweb") || strpos($agent,"android") || strpos($agent,"windows ce") || strpos($agent,"symbianos")){
			header('Location:' . url('m=Takejewels&a=showDoactivity', '', APP_XXT));
			return;
		}
		$aActive = Takejewels::checkActive();
		$aUserInfo = $aActive['data'];
		assign('aUserInfo', $aUserInfo);
		
		$oRaiders = m('Raiders');
		//一等奖
		$aOnePrize = $oRaiders->getPrizeList(1);
		$exchangeNums = 0;
		foreach($aOnePrize as $key => $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		$aOnePrize[0]['show_image'] = $GLOBALS['RESOURCE']['duo_1-1'];
		$aOnePrize[1]['show_image'] = $GLOBALS['RESOURCE']['duo_1-2'];
		$aOnePrize[2]['show_image'] = $GLOBALS['RESOURCE']['duo_1-3'];
		$aOnePrize[3]['show_image'] = $GLOBALS['RESOURCE']['duo_1-4'];
		assign('oneExchange', $exchangeNums);
		assign('aOnePrize', $aOnePrize);
		
		//二等奖
		$aTwoPrize = $oRaiders->getPrizeList(2);
		$exchangeNums = 0;
		foreach($aTwoPrize as $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		assign('twoExchange', $exchangeNums);
		assign('aTwoPrize', $aTwoPrize);
		
		//三等奖
		$aThreePrize = $oRaiders->getPrizeList(3, 1, 12);
		$exchangeNums = 0;
		foreach($aThreePrize as $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		assign('threeExchange', $exchangeNums);
		assign('aThreePrize', $aThreePrize);
		
		//幸运奖
		$aLuckPrize = $oRaiders->getPrizeList(4);
		$exchangeNums = 0;
		foreach($aLuckPrize as $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		assign('luckExchange', $exchangeNums);
		
		$aAwardList = $oRaiders->getAwardList(1, 24);
		assign('aAwardList', $aAwardList);
		assign('title', '争分夺宝之读万卷书行万里路');
		display('activity/nav.html.php');
		display('activity/spec_duobao.html.php');
	}
	
	/**
	 * 活动页面展示APP介绍
	 */
	public function showMactivity(){
		display('activity/spec_duobao_introduct.html.php');
	}
	
	/**
	 * 活动页面展示APP闯关
	 */
	public function showDoactivity(){
		$userType = intval(get('userType'));
		Cookie::set('userType', $userType);
		Takejewels::initUser();
		$aActive = Takejewels::checkActive();
		$aUserInfo = $aActive['data'];
		
		$aJoin = array();
		$oRaiders = m('Raiders');
		if(!$aUserInfo){
			$status = 4; //开始游戏
		}else{
			$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUserInfo['id'], $aUserInfo['user_type']);
			if(!$aJoin){
				$status = 4; //开始游戏
			}else{
				$now = time();
				if($aJoin['award_time'] + 86400 * 5 > $now){
					$status = 1; //等待游戏开始
				}else{
					$status = 4; //开始游戏
				}
				if(!$aJoin['surplus_times'] && date('Ymd', $aJoin['share_time']) < date('Ymd', $now)){
					$status = 2; //分享多一次
				}
				if(!$aJoin['surplus_times'] && date('Ymd', $aJoin['share_time']) == date('Ymd', $now)){
					$status = 3; //机会用完
				}
			}
		}
		assign('status', $status);
		assign('aJoin', $aJoin);
		assign('aUserInfo', $aUserInfo);
		
		
		//一等奖
		$aOnePrize = $oRaiders->getPrizeList(1);
		$exchangeNums = 0;
		foreach($aOnePrize as $key => $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		$aOnePrize[0]['show_image'] = $GLOBALS['RESOURCE']['duo_1-1'];
		$aOnePrize[1]['show_image'] = $GLOBALS['RESOURCE']['duo_1-2'];
		//$aOnePrize[2]['show_image'] = $GLOBALS['RESOURCE']['duo_1-3'];
		//$aOnePrize[3]['show_image'] = $GLOBALS['RESOURCE']['duo_1-4'];
		
		assign('oneExchange', $exchangeNums);
		assign('aOnePrize', $aOnePrize);
		
		//二等奖
		$aTwoPrize = $oRaiders->getPrizeList(2);
		$exchangeNums = 0;
		foreach($aTwoPrize as $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		assign('twoExchange', $exchangeNums);
		assign('aTwoPrize', $aTwoPrize);
		
		//三等奖
		$aThreePrize = $oRaiders->getPrizeList(3, 1, 12);
		$exchangeNums = 0;
		foreach($aThreePrize as $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		assign('threeExchange', $exchangeNums);
		assign('aThreePrize', $aThreePrize);
		
		//幸运奖
		$aLuckPrize = $oRaiders->getPrizeList(4);
		$exchangeNums = 0;
		foreach($aLuckPrize as $aPrize){
			$exchangeNums = $exchangeNums + $aPrize['total'] - $aPrize['surplus'];
		}
		assign('luckExchange', $exchangeNums);
		
		$aAwardList = $oRaiders->getAwardList(1, 20);	//获奖动态
		assign('aAwardList', $aAwardList);
		
		$aMyAwardList = array();
		if($aUserInfo){
			$aMyAwardList = $oRaiders->getAwardList(1, 8, array('user_id' => $aUserInfo['id'], 'user_type' => $aUserInfo['user_type']));	//获奖动态
		}
		
		assign('aMyAwardList', $aMyAwardList);
		display('activity/spec_duobao_app.html.php');
	}
	
	/**
	 * 开始游戏
	 */
	public function startGame(){
		Takejewels::startGame();
	}
	
	/**
	 * 获取剩余抽奖次数
	 */
	public function getLuckTimes(){
		$aActive = Takejewels::checkActive();
		$aUserInfo = $aActive['data'];
		if(!$aUserInfo){
			alert('luck', 1, 0);
		}else{
			$oRaiders = m('Raiders');
			$aJoin = $oRaiders->getJoinInfoByUserIdAndUserType($aUserInfo['id'], $aUserInfo['user_type']);
			if($aJoin){
				alert('luck', 1, $aJoin['luck_times']);
			}else{
				alert('luck', 1, 0);
			}
		}
	}
	
	/**
	 * 获取题目或找茬图片
	 */
	public function getNext(){
		Takejewels::getNext();
	}
	
	/**
	 * 答题处理或找茬处理
	 */
	public function answerQuestion(){
		Takejewels::answerQuestion();
	}
	
	
	/**
	 * 抽幸运奖
	 */
	public function luckDraw(){
		Takejewels::luckDraw();
	}
	
	/**
	 * 选择奖品
	 */
	public function choicePrize(){
		Takejewels::choicePrize();
	}
	
	/**
	 * 填写地址
	 */
	public function fillAwardInfo(){
		Takejewels::fillInfo();
	}

	/**
	 * 分享
	 */
	public function share(){
		$content = '争分夺宝之读万卷书行万里路。赢取秋冬缤纷欧洲剑桥游学之旅 ----优满分(www.umfun.com)，中国最大中小学生在线游戏化学习平台！';
		Takejewels::share($content);
	}
	
	/**
	 * APP版获奖名单
	 */
	public function getAwardList(){
		$oBbs = m('Bbs');
		$aArticle = $oBbs->getThreadInfoById(390);
		if($aArticle){
			assign('content', $aArticle['content']);
			display('activity/spec_duobao_award.html.php');
		}else{
			alert('获奖名单不存在');
		}
		
	}

}