<?php

/**
 * 团队赛控制器
 * 罗启军
 * 455538375@qq.com
 * 不要憎恨你的敌人 那会影响你的判断力
 */

class TeamController{
	private $_awardList = array(
		6 => array(
			0 => array(
				'name' => '我是高手',
				'first_total' => 210,
				'second_total' => 212,
				'user_info' => array(
					0 => array('name' => '杨藤飞'),
					1 => array('name' => '陈晓菲'),
					2 => array('name' => '林国龙'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			1 => array(
				'name' => 'SABER',
				'first_total' => 212,
				'second_total' => 219,
				'user_info' => array(
					0 => array('name' => '胡美仪'),
					1 => array('name' => '刘云玲'),
					2 => array('name' => '张扬东'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			2 => array(
				'name' => '海贼队',
				'first_total' => 230,
				'second_total' => 241,
				'user_info' => array(
					0 => array('name' => '南宫雨'),
					1 => array('name' => '习曼曼'),
					2 => array('name' => '梁士斌'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			3 => array(
				'name' => 'ABCD',
				'first_total' => 210,
				'second_total' => 200,
				'user_info' => array(
					0 => array('name' => '马志云'),
					1 => array('name' => '赵定贤'),
					2 => array('name' => '刘启隽'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			4 => array(
				'name' => '最强之队',
				'first_total' => 240,
				'second_total' => 233,
				'user_info' => array(
					0 => array('name' => '蒋国融'),
					1 => array('name' => '赵安晓'),
					2 => array('name' => '林凯翔'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			5 => array(
				'name' => '三相之力',
				'first_total' => 205,
				'second_total' => 201,
				'user_info' => array(
					0 => array('name' => '任广宁'),
					1 => array('name' => '欧沛文'),
					2 => array('name' => '赵勇'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			6 => array(
				'name' => '学霸队',
				'first_total' => 190,
				'second_total' => 245,
				'user_info' => array(
					0 => array('name' => '江权'),
					1 => array('name' => '陈华'),
					2 => array('name' => '黄英俊'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
			7 => array(
				'name' => '风暴英雄',
				'first_total' => 230,
				'second_total' => 225,
				'user_info' => array(
					0 => array('name' => '张志军'),
					1 => array('name' => '梁国栋'),
					2 => array('name' => '李泽文'),
				),
				'prize' => array(
					'rank' => array(
						'name' => '冬季动物暖手捂抱枕',
						'image' => 'data/team/14195837829676.png',
					),
				),
			),
		),
	);

	/**
	 * 活动页面展示PC
	 */
	public function showActivity(){
		$agent = strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($agent,"netfront") || strpos($agent,"iphone") || strpos($agent,"midp-2.0") || strpos($agent,"opera mini") || strpos($agent,"ucweb") || strpos($agent,"android") || strpos($agent,"windows ce") || strpos($agent,"symbianos")){
			header('Location:' . url('m=Team&a=showMactivity'));
			return;
		}
		display('team/intro_pc.html.php');
	}

	private function _insertSort($arr, $arrKey){
		for($i=1; $i < count($arr); $i++){
			$tmp = $arr[$i];
			$key = $i-1;
			while($key >= 0 && $tmp[$arrKey] > $arr[$key][$arrKey]){
				$arr[$key+1] = $arr[$key];
				$key--;
			}
			if(($key+1) != $i){
				$arr[$key+1] = $tmp;
			}
		}
		return $arr;
	}

	/**
	 * 活动获奖展示PC
	 */
	public function showAward(){
		$agent = strtolower($_SERVER['HTTP_USER_AGENT']);
		if(strpos($agent,"netfront") || strpos($agent,"iphone") || strpos($agent,"midp-2.0") || strpos($agent,"opera mini") || strpos($agent,"ucweb") || strpos($agent,"android") || strpos($agent,"windows ce") || strpos($agent,"symbianos")){
			header('Location:' . url('m=Team&a=showMactivity'));
			return;
		}

		$id = intval(get('id'));
		$oTeam = m('Team');
		if(!$id){
			$id = $oTeam->getNewestMatchId(0);
		}
		if(!$id){
			alert('巅峰队决活动还未开始呢', -1);
		}
		$aMatch = $oTeam->getMatchById($id);
		if(!$aMatch){
			alert('活动不存在', -1);
		}
		assign('aMatch', $aMatch);

		//晋级名单
		$aPassList = $oTeam->getPassTeamList($id);


		//获奖名单
		$get = '`id`,`name`,`member_one`,`member_two`,`member_three`,`match_id`,`prize_list`,(`second_one_score`+`second_two_score`+`second_three_score`)  AS `second_total`, `second_one_score`,`second_two_score`,`second_three_score`';
		$aAwardList = $oTeam->getJoinList($get, '`match_id`=' . $id . ' AND `second_one_score` > 0 AND `second_two_score` > 0 AND `second_three_score` > 0', 1, 10, '`second_total` DESC');
		$aAwardList = $oTeam->getAwardTeamList($id);

		$aAwardOur = $this->_awardList;
		if(isset($aAwardOur[$id])){
			foreach($aAwardOur[$id] as $aAward){
				array_push($aPassList['list'], $aAward);
				array_push($aAwardList['list'], $aAward);
			}
			$aPassList['list'] = $this->_insertSort($aPassList['list'], 'first_total');
			$aAwardList['list'] = $this->_insertSort($aAwardList['list'], 'second_total');
		}

		//赛事列表
		$aMatchList = $oTeam->getMathchList('`id` > 0', 1, 100, '`id` ASC');
		assign('aMatchList', $aMatchList);
		$aUserInfo = isLogin();
		assign('aPassList', $aPassList);
		assign('aAwardList', $aAwardList);
		assign('aUserInfo', $aUserInfo);
		display('team/award_pc.html.php');
	}

	/**
	 * 活动页面展示家长介绍
	 */
	public function showActivityP(){
		display('team/intro_p.html.php');
	}

	/**
	 * 活动页面展示家长介绍
	 */
	public function showAdv(){
		display('team/adv.html.php');
	}

	/**
	 * 活动页面展示APP介绍
	 */
	public function showMactivity(){
		display('team/intro_m.html.php');
	}

	public function showDoMactivity(){
		//file_put_contents('1.txt', 456456);
		header('Access-Control-Allow-Origin: http://' . APP_XXT);
		header('Access-Control-Allow-Credentials: true');

		$id = intval(get('id'));
		$oTeam = m('Team');
		if(!$id){
			$id = $oTeam->getNewestMatchId(0);
		}
		if(!$id){
			alert('巅峰队决活动还未开始呢', -1);
		}
		$aMatch = $oTeam->getMatchById($id);
		$aUser = isLogin();
		if(!$aUser){
			alert('请先登陆', -1);
		}

		$now = time();
		$aLuckyList = array();
		if($aMatch['second_match']['match_start_time'] < $now){
			$sequence = 'second';
			$alucky = $oTeam->getPrizeInfoById($aMatch['prizes']['second_lucky']);
			$aLuckyList[0] = array('id' => 1, 'name' => $alucky['name']);
			$aLuckyList[1] = array('id' => 2, 'name' => '5金币');
			$aLuckyList[2] = array('id' => 2, 'name' => '10金币');
			$aLuckyList[3] = array('id' => 2, 'name' => '20金币');
			$aLuckyList[4] = array('id' => 2, 'name' => '30金币');
		}else{
			$sequence = 'first';
			$alucky = $oTeam->getPrizeInfoById($aMatch['prizes']['second_lucky']);
			$aLuckyList[0] = array('id' => 1, 'name' => $alucky['name']);
			$aLuckyList[1] = array('id' => 2, 'name' => '2金币');
			$aLuckyList[2] = array('id' => 2, 'name' => '5金币');
			$aLuckyList[3] = array('id' => 2, 'name' => '10金币');
			$aLuckyList[4] = array('id' => 2, 'name' => '20金币');
		}

		$aJoin = $oTeam->getJoinByMatchIdUserId($aMatch['id'], $aUser['id']);
		if($aJoin){
			$checkJoin = $oTeam->checkJoin($aMatch['id'], $aUser['id']);
			$memberNums = 0;
			if($checkJoin){
				$memberNums++;
				if($checkJoin['member_two']){
					$memberNums++;
				}
				if($checkJoin['member_three']){
					$memberNums++;
				}
			}
			if($memberNums >= 2){
				$status = 3;	//不可以加入其他队伍
			}else{
				$status = 2;	//可以加入其他队伍
			}
		}else{
			$status = 1;	//没有队伍
		}

		$aAwardOur = $this->_awardList;
		//上期获奖名单
		//$lastId = $oTeam->getNewestMatchId(1);
		//if($lastId){
			$aJoinList = $oTeam->getAwardTeamList($id);

			if(isset($aAwardOur[$id])){
				foreach($aAwardOur[$id] as $aAward){
					array_push($aJoinList['list'], $aAward);
				}
				$aJoinList['list'] = $this->_insertSort($aJoinList['list'], 'second_total');
			}
			assign('aJoinList', $aJoinList);
	//	}

		//晋级名单
		$aPassList = $oTeam->getPassTeamList($id);
		if(isset($aAwardOur[$id])){
			foreach($aAwardOur[$id] as $aAward){
				array_push($aPassList['list'], $aAward);
			}
			$aPassList['list'] = $this->_insertSort($aPassList['list'], 'first_total');
		}


		assign('aPassList', $aPassList);

		assign('aLuckyList', $aLuckyList);
		assign('luckyScore', Team::THREE_AVERAGE);
		assign('sequence', $sequence);
		assign('status', $status);
		assign('aJoin', $aJoin);
		assign('aMatch', $aMatch);
		//赛事列表
		$aMatchList = $oTeam->getMathchList('`id` > 0', 1, 100, '`id` ASC');
		assign('aMatchList', $aMatchList);
		display('team/team_student.html.php');
	}

	public function createTeam(){
		Team::createTeam();
	}

	public function joinTeam(){
		Team::joinTeam();
	}

	public function luckDraw(){
		Team::luckDraw();
	}

	public function fillInfo(){
		Team::fillInfo();
	}

}