<?php
class MarkController {
	private $_userId = 0;

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	//签到按钮
	public function showMarkButton(){
		User::getMarkInfo();
	}

	//签到
	public function mark(){
		User::mark();
	}


	//签到排名列表
	public function showMarkList(){
		User::markRankingList();
	}




	//得到所有好友ID
	private function _getFriendIds(){
		$oSns = m('Sns');
		$aFriendIdsArray = array();

		$aFriendIdsArray = $oSns->getUserFriendIdList($this->_userId);
		if($aFriendIdsArray === false){
			return false;
		}
		array_push($aFriendIdsArray, $this->_userId);
		return array_filter($aFriendIdsArray);
	}


	//根据好友id取列表
	private function _getMarkList($aFriendIdIdsArray, $orderType = 1, $page = 1){

		if(!$aFriendIdIdsArray){
			return false;
		}

		if($orderType != 1 && $orderType != 2){
			return false;
		}


		$order = '`mark_total` desc';
		if($orderType == 2){
			$order = '`mark_continuous` desc';
		}


		$previousPage = 1;
		$nextPage = 2;

		$returnHtml = '';
		$aMarkList = array();
		$markCount = 0;
		$pageCount = 1;
		$pageSize = 10;
		if($page < 1){
			$page = 1;
		}


		$oUserBehavior = m('UserBehavior');
		$markCount = $oUserBehavior -> getMarkCountByUserIds($aFriendIdIdsArray);
		if( $markCount === false){
			return false;
		}


		if($markCount > 0){
			$pageCount = ceil($markCount/$pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aMarkList = $oUserBehavior->getMarkListByUserIds($aFriendIdIdsArray, $order, $page, $pageSize);
			if($aMarkList === false){
				return false;
			}

			if( 0 < $page && $page <= $pageCount){
				$previousPage = $page - 1;
				$nextPage = $page + 1;
			}

			if($aMarkList){
				$oUser = m('User');
				foreach($aMarkList as $key=>$aMarkInfo){
					$aMarkList[$key]['personInfo'] = array();
					$aPersonInfo = $oUser->getPersonalInfoByUserId($aMarkInfo['id']);
					if($aPersonInfo === false){
						return false;
					}
					if($aPersonInfo){
						$aMarkList[$key]['personInfo'] = $aPersonInfo;
					}
				}

			}
		}

		assign('userId', $this->_userId);
		assign('orderType', $orderType);
		assign('pageSize', $pageSize);
		assign('page', $page);
		assign('pageCount', $pageCount);
		assign('previousPage', $previousPage);
		assign('nextPage', $nextPage);
		assign('aMarkList', $aMarkList);
		$returnHtml = fetch('mark/list.html.php');
		return $returnHtml;
	}


	/*
	//加金币
	private function _setUserGold($markContinuous, $userId){

		$gold = 0;
		$oUserNumerical = m('UserNumerical');
		$aNumericalInfo = $oUserNumerical->getUserNumericalInfoById($userId);
		if($aNumericalInfo === false){
			return false;
		}
		//计算应得金币
		if(isset($GLOBALS['MARK'])){
			$aBaseArray =  array_keys(($GLOBALS['MARK']['base'] ));
			foreach ($aBaseArray as $value){
				if($markContinuous <= $value){
					$gold =  $GLOBALS['MARK']['base'][$value];
					break;
				}
			}

			if(isset($GLOBALS['MARK']['extra'][$markContinuous])){
				$gold += $GLOBALS['MARK']['extra'][$markContinuous];
			}
		}

		$aData = array(
			'id'	=> $userId,
			'gold'	=> $aNumericalInfo['gold'] + $gold
		);
		$result = $oUserNumerical->setUserNumerical($aData);
		if($result){
			return $aData['gold'];
		}else{
			return false;
		}
	}

	*/


}