<?php
class PropController{
	private $_userId = 0;
	private $_oProp = null;
	
	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
		$this->_oProp = propPlugin($this->_userId);
		if(!$this->_oProp){
			alert('道具出错，请刷新重试', 0);
		}
	}
	
	public function getPropList(){
		$type = intval(post('type', 1));
		$aPropList = $this->_getPropList($type);
		alert('列表', 1, $aPropList);
	}
	
	
	public function getCartInfo(){
		$oNum = m('UserNumerical');
		$aNumerical = $oNum->getUserNumericalInfoById($this->_userId);
		$aNum = array(
			'ub' => $aNumerical['ub'],
			'gold' => $aNumerical['gold'],
		);

		$aCartPropList = $this->_oProp->getCartPropList($this->_userId);
		$aPropList = $this->_getPropList(1);
		$cartCount = 0;
		foreach($aCartPropList as $aCart){
			$cartCount += $aCart['nums'];
		}
		$aResult = array(
			'num' => $aNum,
			'cart' => $aCartPropList,
			'list' => $aPropList,
			'cartCount' => $cartCount,
		);
		alert('道具商城', 1, $aResult);
	}
	
	public function getPropCartList(){
		$aPropCartList = post('prop_cart_list');
		
		$aResult = array(
			'cart_list' => array(),
			'total_gold' => 0
		);
		
		$aDifPropId = array();
		$aPropIdNum = array();
		if($aPropCartList){
			foreach($aPropCartList as $key => $aProp){
				array_push($aDifPropId, $aProp['id']);
				$aPropIdNum[$aProp['id']] = $aProp['nums'];
			}
			
			$oProp = m('Prop');
			$aPropList = $oProp->getPropListByPropIds($aDifPropId);
			$aResult['cart_list'] = $aPropList;
			$aResult['total_gold'] = $this->_countPropCartGold($aPropList, $aPropIdNum);
		}
		
		alert('道具购物车', 1, $aResult);
	}
	
	public function getNumerical(){
		$oNum = m('UserNumerical');
		$aNumerical = $oNum->getUserNumericalInfoById($this->_userId);
		$aNum = array(
			'ub' => $aNumerical['ub'],
			'gold' => $aNumerical['gold'],
		);
		alert('财富', 1, $aNum);
	}
	
	
	public function putCart(){
		$propId = intval(post('id'));
		$nums = intval(post('nums'));
		$result = $this->_oProp->putCart($this->_userId, $propId, $nums);
		if($result === true){
			alert('成功', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function cancelCart(){
		$aIds = post('ids');
		$result = $this->_oProp->cancelCart($this->_userId, $aIds);
		if($result === true){
			alert('成功', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function buyOneKind(){
		$propId = intval(post('id'));
		$nums = intval(post('nums'));
		$result = $this->_oProp->purchase($this->_userId, $propId, $nums);
		if($result === true){
			alert('购买成功，可以到我的道具查看喔', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function buyFromCart(){
		$aPropIds = post('ids');
		if(!is_array($aPropIds)){
			alert('参数错误，请刷新重试', 0);
		}
		$result = $this->_oProp->purchaseFromCart($this->_userId, $aPropIds);
		if($result === true){
			alert('购买成功，可以到我的道具查看喔', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function getPackageInfo(){
		$aResult = $this->_oProp->getMyPropList($this->_userId);
		alert('OK', 1, $aResult);
	}
	
	public function discardProp(){
		$propId = post('id');
		$result = $this->_oProp->useProp($this->_userId, $propId, 2);
		if($result === true){
			alert('道具已丢弃', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function sendProp(){
		$toUserId = intval(post('toUserId'));
		$propId = intval(post('propId'));
		$message = post('message');
		if(!$message){
			alert('给您的好友留个言吧', -1);
		}
		$aFriendIds = getUserFriendIds($this->_userId);
		if(!in_array($toUserId, $aFriendIds)){
			alert('好友不存在', -1);
		}
		$result = $this->_oProp->sendProp($this->_userId, $toUserId, $propId, $message);
		if($result === true){
			alert('道具赠送成功', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function getToolBar(){
		$type = intval(post('type'));
		if(!array_key_exists($type, $GLOBALS['PROP_TYPE_NAME'])){
			alert('道具类型不存在', -1);
		}
		$aPropList = $this->_oProp->getPropToolBar($this->_userId, $type);
		alert('道具栏', 1, $aPropList);
	}
	
	
	public function countCartGold(){
		$aPropIds = post('ids');
		if(!is_array($aPropIds)){
			alert('参数错误', -1);
		}
		foreach($aPropIds as $id){
			if(!is_numeric($id)){
				alert('参数错误', -1);
			}
		}
		$oProp = m('Prop');
		$aDifPropId = array_unique($aPropIds);
		$aPropList = $oProp->getPropListByPropIds($aDifPropId);
		
		$price = 0;
		$oNum = m('UserNumerical');
		$aNum = $oNum->getUserNumericalInfoById($this->_userId);
		$now = time();
		foreach($aPropList as $aProp){
			if($aProp['discount_start_time'] <= $now && $now <= $aProp['discount_end_time']){
				$aProp['price'] = floor($aProp['price'] * ($aProp['discount'] / 100));
			}
			if($aNum['vip'] && $aNum['vip_expiration_time'] > $now){
				$aProp['price'] = floor($aProp['price'] * ($GLOBALS['VIP'][$aNum['vip']]['prop_price'] / 10));
			}
			
			$kindNums = 0; //某种道具的数量
			foreach($aPropIds as $thisId){
				if($thisId == $aProp['id']){
					$kindNums++;
				}
			}
			$aProp['price'] = $aProp['price'] * $kindNums;
			$price += $aProp['price'];
		}
		alert('购物车总价', 1, $price);
	}
	
	public function getSendProp(){
		$type = intval(post('type'));
		if($type !=1 && $type != 2){
			$type = 1;
		}
		$aPropList = $this->_oProp->getSendProp($this->_userId, $type);
		alert('待领取道具列表', 1, $aPropList);
	}
	
	public function getProp(){
		$recordId = intval(post('id'));
		$type = intval(post('type'));
		if($type !=1 && $type != 2){
			$type = 1;
		}
		$result = $this->_oProp->getProp($this->_userId, $recordId, $type);
		if($result === true){
			alert('领取道具成功，可以到我的道具中查看', 1);
		}else{
			alert($result, -1);
		}
	}
	
	public function ignoreProp(){
		$recordId = intval(post('id'));
		$type = intval(post('type'));
		if($type !=1 && $type != 2){
			$type = 1;
		}
		$result = $this->_oProp->ignoreProp($this->_userId, $recordId, $type);
		if($result === true){
			alert('道具已忽略', 1);
		}else{
			alert($result, -1);
		}
	}
	
	
	public function useProp(){
		$propId = intval(post('id'));
		$oProp = m('Prop');
		$aProp = $oProp->getPropInfoById($propId);
		if(!$aProp){
			alert('道具不存在', -1);
		}
		
		$isFromMatch = $this->_checkIsMatchUseProp();	//检查是不是在比赛中使用道具
		if($isFromMatch){
			$this->_checkMatchUsePropLimit($isFromMatch);	//检查在比赛使用的道具次数
		}
		
		$functionName = $GLOBALS['PROP_FUNCTION_RELATION'][$aProp['prop_code']];
		if($aProp['prop_code'] == 'qnrs'){
			$missionId = intval(post('missionId'));
			$result = $this->_oProp->$functionName($this->_userId, $missionId, $propId);
		}elseif($aProp['prop_code'] == 'wnrs'){
			$missionId = intval(post('missionId'));
			$result = $this->_oProp->$functionName($this->_userId, $missionId, $propId);
		}elseif($aProp['prop_code'] == 'slyz'){
			$esId = Xxtea::decrypt(post('esId'));
			$result = $this->_oProp->$functionName($this->_userId, $esId, $propId);
		}elseif($aProp['prop_code'] == 'sjyz'){
			$esId = Xxtea::decrypt(post('esId'));
			$result = $this->_oProp->$functionName($this->_userId, $esId, $propId);
		}elseif($aProp['prop_code'] == 'slzy'){
			$esId = Xxtea::decrypt(post('esId'));
			$result = $this->_oProp->$functionName($this->_userId, $esId, $propId);
		}elseif($aProp['prop_code'] == 'sgnj'){
			$dataId = post('theId');
			$result = $this->_oProp->$functionName($this->_userId, $propId, $dataId);
		}elseif($aProp['prop_code'] == 'hhlf'){
			$missionId = intval(post('missionId'));
			$result = $this->_oProp->$functionName($this->_userId, $missionId, $propId);
		}elseif($aProp['prop_code'] == 'hhqjl'){
			$missionId = intval(post('missionId'));
			$result = $this->_oProp->$functionName($this->_userId, $missionId, $propId);
		}elseif($aProp['prop_code'] == 'scjd'){
			$missionId = intval(post('missionId'));
			$result = $this->_oProp->$functionName($this->_userId, $missionId, $propId);
			if($result === 1){
				alert('至对做完5题才能使用速成金丹喔', -1);
			}elseif($result === 2){
				alert('您已经通过该关的修炼阶段啦', -1);
			}
		}elseif($aProp['prop_code'] == 'tgys'){
			$missionId = intval(post('missionId'));
			$result = $this->_oProp->$functionName($this->_userId, $missionId, $propId);
			if($result === 1){
				alert('您已经通过挑战啦', -1);
			}
		}elseif($aProp['prop_code'] == 'mtgh'){
			$pkId = intval(post('pkId'));
			$esId = Xxtea::decrypt(post('esId'));
			$result = $this->_oProp->$functionName($this->_userId, $pkId, $esId, $propId);
		}elseif($aProp['prop_code'] == 'djbkr'){
			$result = $this->_oProp->$functionName($this->_userId, $propId);
			if($result){
				alert('您的道具包容量已增加10格', 1);
			}
		}elseif($aProp['prop_code'] == 'sbjf1' || $aProp['prop_code'] == 'sbjf3' || $aProp['prop_code'] == 'sbjf7'){
			$result = $this->_oProp->$functionName($this->_userId, $propId);
			if($result){
				$date = date('Y-m-d H:i:s', $result);
				alert('您在 ' . $date . ' 前的经验都会加倍喔', 1);
			}
		}
		if($result !== false){
			if($isFromMatch){
				$this->_addMatchUsePropCount($isFromMatch);	//更新比赛使用道具次数
			}
			alert('使用道具成功', 1, $result);
		}else{
			alert('使用道具失败', 0);
		}
		
	}
	
	private function _getPropList($type){
		$oProp = m('Prop');
		$aCondition = array(
			'money_type' => 1,
			'is_publish' => 1,
		);
		if($type == 1){
			$aCondition['type'] = array(1,9);
		}elseif($type == 2){
			$aCondition['type'] = array(2);
		}elseif($type == 3){
			$aCondition['type'] = array(3,4);
		}elseif($type == 4){
			$aCondition['type'] = array(5, 6);
		}elseif($type == 5){
			$aCondition['type'] = array(-1);
		}elseif($type == 6){
			$aCondition['type'] = array(7);
		}
		$aPropList = $oProp->getPropList($aCondition, 1, 30);
		$oNum = m('UserNumerical');
		$aNum = $oNum->getUserNumericalInfoById($this->_userId);
		$now = time();
		foreach($aPropList as $key => $aProp){
			if($aPropList[$key]['discount_start_time'] <= $now && $now <= $aPropList[$key]['discount_end_time']){
				$aPropList[$key]['price'] = floor($aPropList[$key]['price'] * ($aPropList[$key]['discount'] / 100));
			}
			$aPropList[$key]['vip_price'] = floor($aPropList[$key]['price'] * ($GLOBALS['VIP'][1]['prop_price'] / 10));
			$aDecript = explode('---', $aPropList[$key]['description']);
			$aPropList[$key]['range'] = $aDecript[0];
			$aPropList[$key]['effect'] = $aDecript[1];
		}
		return $aPropList;
	}
	
	private function _checkIsMatchUseProp(){
		$game = post('game');
		$matchId = post('match_id');
		if($game && $game == 'match' && $matchId){
			$oMatch = m('Match');
			$aMyMatch = $oMatch->getMatchUserRelationInfoById($matchId);
			if(!$aMyMatch){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			return $aMyMatch;
		}
		return array();
	}

	private function _checkMatchUsePropLimit($aMyMatch){
		if(isset($aMyMatch['prop_use_times']) && $aMyMatch['prop_use_times'] >= MATCH_PROP_USE_LIMIT){
			alert('抱歉，一场比赛只能使用' . MATCH_PROP_USE_LIMIT . '次道哦！', -1);
		}
	}

	private function _addMatchUsePropCount($aMyMatch){
		if(isset($aMyMatch['prop_use_times']) && $aMyMatch['prop_use_times'] < MATCH_PROP_USE_LIMIT){
			$oMatch = m('Match');
			$aData = array(
				'id' => $aMyMatch['id'],
				'prop_use_times' => array('add', 1)
			);
			$isSetSuccess = $oMatch->setMatchUserRelation($aData);
			if(!$isSetSuccess){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}
	}
	
	private function _countPropCartGold($aPropList, $aPropIdNum){
		$price = 0;
		$oNum = m('UserNumerical');
		$aNum = $oNum->getUserNumericalInfoById($this->_userId);
		$now = time();
		foreach($aPropList as $aProp){
			if($aProp['discount_start_time'] <= $now && $now <= $aProp['discount_end_time']){
				$aProp['price'] = floor($aProp['price'] * ($aProp['discount'] / 100));
			}
			if($aNum['vip'] && $aNum['vip_expiration_time'] > $now){
				$aProp['price'] = floor($aProp['price'] * ($GLOBALS['VIP'][$aNum['vip']]['prop_price'] / 10));
			}
			
			$aProp['price'] = $aProp['price'] * $aPropIdNum[$aProp['id']];
			$price += $aProp['price'];
		}
		
		return $price;
	}

}
