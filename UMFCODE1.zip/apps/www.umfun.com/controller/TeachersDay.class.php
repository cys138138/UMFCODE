<?php

class TeachersDayController{
	public function __construct(){}

	public function showActivity(){
		TeachersDay::showActivity(TeachersDay::CLIENT_PC);
	}

	//分享
	public function share(){
		TeachersDay::share();
	}


	//赠送
	public function giving(){
		TeachersDay::giving();
	}

	
	//Ajax获取教师列表
	public function getXxtTeacherList(){
		TeachersDay::getXxtTeacherList();
	}
}