<?php
/**
 * 默认控制器
 */
class IndexController{
	private $_userId = 0;
	private $_aUser = array();
	public function __construct(){
		$this->_aUser = checkUserLogin();
		$this->_userId = $this->_aUser['id'];
	}

	public function index(){
		$type = intval(get('type'));
		if(!$type || $type > 3){
			$type = 1;
		}
		assign('type', $type);
		$oNum = m('UserNumerical');
		$aFriendsId = getUserFriendIds($this->_userId);
		array_push($aFriendsId, $this->_userId);
		$aFriendRank = $oNum->getUserNumericalRankingList(1, 4, $aFriendsId);
		foreach($aFriendRank as $key => $aRank){
			$aFriendRank[$key]['level'] = Numerical::updateUserLevel($aRank['accumulate_points']);
		}
		$aWordRank = $oNum->getUserNumericalRankingList(1, 4, array());
		foreach($aWordRank as $key => $aRank){
			$aWordRank[$key]['level'] = Numerical::updateUserLevel($aRank['accumulate_points']);
		}
		assign('aFriendRank', $aFriendRank);
		assign('aWordRank', $aWordRank);

		$oExchange = m('Exchange');
		$aCondition = array(
			'recommand'	=> 1,
		);
		$aGoodsList = $oExchange->getExchangeGoodsList($aCondition, 1, 4);
		$aRecordList = $oExchange->getRandExchangeRecordsList(20);
		foreach($aRecordList as $key => $aExchanging){
			$aRecordList[$key]['user_info'] = getUserInfo($aExchanging['user_id'], array('personal'));
		}
		assign('aGoodsList', $aGoodsList);
		assign('aRecordList', $aRecordList);

		$oMatch = m('Match');
		$oPk = m('Pk');
		$aMatchStatis = $oMatch->getUserMatchStatisticsList($this->_userId);
		$aPKStatis = $oPk->getUserPkStatisticsList($this->_userId);
		assign('aMatchStatis', $aMatchStatis);
		assign('aPKStatis', $aPKStatis);
		//debug($aPKStatis);


		//新手引导
		$oUserInvitation = m('UserInvitation');
		$aTask = $oUserInvitation->getUserNewTaskStatusInfo($this->_userId);
		if(!$aTask){
			$aTask = array(
				'id' => $this->_userId,
				'invite_code' => 0,
				'direct_invite_nums' => 0,
				'indirect_invite_nums' => 0,
				'receive_ub' => 0,
				'new_task_process_status' => '0,0,0,0,0',
				'invite_prize_status' => 0
			);
			$oUserInvitation->addUserInvitaion($aTask);
		}elseif(!$aTask['new_task_process_status']){
			$aTask = array(
				'id' => $this->_userId,
				'new_task_process_status' => '0,0,0,0,0',
			);
			$oUserInvitation->setUserInvitation($aTask);
		}
		$aMyTask = explode(',', $aTask['new_task_process_status']);

		//错题统计
		$oEs = m('Es');
		$aStatis = $oEs->getUserSubjectWrongEsStatistic($this->_userId);
		$wrongCount = 0;
		$repairCount = 0;
		foreach($aStatis as $key => $aSubjectSta){
			$wrongCount += $aSubjectSta['wrong_es_times'] + $aSubjectSta['repair_es_count'];
			$repairCount += $aSubjectSta['repair_es_count'];
		}
		$wrongCount = \common\model\EsWrong::getWrongEsCount(['user_id' => $this->_userId]);
		$chineseCountWrongCount = \common\model\EsWrong::getWrongEsCount(['user_id' => $this->_userId, 'subject_id' => \common\model\Subject::SUBJECT_CHINESE_ID]);
		$mathCountWrongCount = \common\model\EsWrong::getWrongEsCount(['user_id' => $this->_userId, 'subject_id' => \common\model\Subject::SUBJECT_MATH_ID]);
		$englishCountWrongCount = \common\model\EsWrong::getWrongEsCount(['user_id' => $this->_userId, 'subject_id' => \common\model\Subject::SUBJECT_ENGLISH_ID]);
		if($wrongCount){
			$aStatis[1]['wrong_es_times'] = $chineseCountWrongCount;
			$aStatis[2]['wrong_es_times'] = $mathCountWrongCount;
			$aStatis[3]['wrong_es_times'] = $englishCountWrongCount;
			$aStatis[1]['wrong_percent'] = intval($chineseCountWrongCount / $wrongCount * 100);
			$aStatis[2]['wrong_percent'] = intval($mathCountWrongCount / $wrongCount * 100);
			$aStatis[3]['wrong_percent'] = intval($englishCountWrongCount / $wrongCount * 100);
		}else{
			$aStatis[1]['wrong_percent'] = 0;
			$aStatis[2]['wrong_percent'] = 0;
			$aStatis[3]['wrong_percent'] = 0;
		}

		if($repairCount){
			$aStatis[1]['repair_percent'] = intval($aStatis[1]['repair_es_count'] / $repairCount * 100);
			$aStatis[2]['repair_percent'] = intval($aStatis[2]['repair_es_count'] / $repairCount * 100);
			$aStatis[3]['repair_percent'] = intval($aStatis[3]['repair_es_count'] / $repairCount * 100);
		}else{
			$aStatis[1]['repair_percent'] = 0;
			$aStatis[2]['repair_percent'] = 0;
			$aStatis[3]['repair_percent'] = 0;
		}

		assign('aThreadRecommend', $this->_getThreadRecommend());

		assign('esCount', $this->_getEsCountByDate());
		assign('wrongCount', $wrongCount);
		assign('repairCount', $repairCount);
		assign('aStatis', $aStatis);

		$aUser = getUserInfo($this->_userId);
		assign('aUser', $aUser);
		displayHeader('学习中心');
		display('home.html.php');
		displayFooter();
	}

   /**
	* 获取每日任务
	*/
	public function getDailyTask(){
		$oUserBehavior = m('UserBehavior');
		$aTask = $oUserBehavior->getUserDailyBehaviorInfo($this->_userId);
		if(isset($aTask['task']) && is_array($aTask['task'])){
			foreach($aTask['task'] as $key => $myTask){
				foreach($GLOBALS['POINT']['daily_tasks'] as $taskId => $task){
					if($myTask['task_id'] == $taskId){
						$aTask['task'][$key]['task_info'] = $task;
					}
				}
			}
			alert('每日任务', 1, $aTask['task']);
		}else{
			alert('获取任务出错', -1);
		}
	}

   /**
	* 领取每日任务奖励
	*/
	public function getDailyTaskPrize(){
		$taskId = post('task_id');
		$oUserBehavior = m('UserBehavior');
		$aTask = $oUserBehavior->getUserDailyBehaviorInfo($this->_userId);
		$thisKey = -1;
		$aThisTask = array();
		foreach($aTask['task'] as $key => $task){
			if($task['task_id'] == $taskId){
				$aThisTask = $task;
				$thisKey = $key;
				break;
			}
		}
		if(!$aThisTask){
			alert('任务不存在', -1);
		}
		if($aThisTask['status'] != 2){
			alert('任务还没完成呢', -1);
		}
		$oNum = new Numerical();
		$oNum->addAccumulatePoints($this->_userId, 24, $aThisTask['task_id']);
		$oNum->addMoney($this->_userId, 14, $aThisTask['task_id']);
		$aTask['task'][$thisKey]['status'] = 3;
		$oUserBehavior->setUserDailyBehavior($aTask);

		//新版完成任务写事件
		$gold = $GLOBALS['POINT']['daily_tasks'][$aThisTask['task_id']]['gold'];
		if($gold){
			$aEventData = array(
				'user_id'	=>	$this->_userId,
				'type'		=> 33,
				'data_id'	=>	0,
				'data'		=>	array(
					'gold' => $gold,
					'task_id' => $aThisTask['task_id'],
					'create_time' => time()
				)
			);
			$oSnsEvent = m('SnsEvent');
			$oSnsEvent->addEvent($aEventData);
		}

		alert('奖励领取成功', 1);
	}


   /**
	* 根据月日制造题库新增多少题目数
	*/
	private function _getEsCountByDate(){
		$aMaxMonth = range(7, 12);
		$aMaxDay = range(16, 31);

		$monthMultiple = 20;
		$dayMultiple = 10;

		$month = (int)date('m');
		$day = (int)date('d');
		if(in_array($month, $aMaxMonth)){
			$monthMultiple = 10;
		}

		if(in_array($day, $aMaxDay)){
			$dayMultiple = 5;
		}

		return $month * $monthMultiple + $day * $dayMultiple;
	}

	/**
	 * 获取关卡比赛PK列表
	 */
	public function getGameList(){
		$oMission = m('Mission');
		$aCurrentMissionPage =  $oMission->getCurrentMissionPage($this->_userId, 1);
		$aChinese = $oMission->getUserMissionList($this->_userId, 1, $aCurrentMissionPage[1], 1, '`orders` ASC');
		$aMath = $oMission->getUserMissionList($this->_userId, 2, $aCurrentMissionPage[2], 1, '`orders` ASC');
		$aEnglish = $oMission->getUserMissionList($this->_userId, 3, $aCurrentMissionPage[3], 1, '`orders` ASC');
		$aResult = array(
			'chinese' => $aChinese,
			'math' => $aMath,
			'english' => $aEnglish,
			'chinesePage' => $aCurrentMissionPage[1],
			'mathPage' => $aCurrentMissionPage[2],
			'englishPage' => $aCurrentMissionPage[3],
		);

		$oMatch = m('Match');
		$aCondition = array(
			'status' => 6,
			'xxt_type' => $this->_aUser['xxt_type'],
			'is_activity_match' => 0,
		);
		$aResult['match'] = $oMatch->getMatchList($aCondition, 1, 2);

		$oPK = m('Pk');
		$aResult['pk'] = $oPK->getNearlyPkArenaPkList(6, $this->_userId);

		$aResult['pk_statistics'] = array(
			'wait_pk_count'	=>	0,
			'friend_send_pk'	=>	0,
			'have_gold_pk'		=>	0,
			'square_pk_count'	=> 0,
		);
		$aUserFriendIds = getUserFriendIds($this->_userId);
		$aResult['pk_statistics']['wait_pk_count'] = $oPK->getUserWaitPkCount($this->_userId);
		$aResult['pk_statistics']['friend_send_pk'] = $oPK->getPointUserSendPkArenaPkCount($aUserFriendIds);
		$aResult['pk_statistics']['have_gold_pk'] = $oPK->getPkArenaHaveGoldPkCount();
		$aResult['pk_statistics']['square_pk_count'] = $oPK->getPkArenaPkCount();
		alert('good', 1, $aResult);
	}

	/**
	 * 推荐好友
	 */
	public function recommandUserList(){
		$oSns = m('Sns');
		$aProbalyFriendList = $oSns->getUserProbalyFriendList($this->_userId, 0, 12);
		$oExchange = m('Exchange');
		$aGoodsList = $oExchange->getExchangeGoodsList(array('release' => 2), 1, 12, '`sales_volume` DESC');
		$aResult = array(
			'friend' => $aProbalyFriendList,
			'goods' => $aGoodsList,
		);
		alert('good', 1, $aResult);
	}

	/**
	 * 话题推荐的文章
	 */
	private function _getThreadRecommend(){
		$aIsRecommendOption = array(
			'category_id'	=> 0,
			'is_recommend'	=> 1,
			'is_top'		=> -1,
			'statu'			=> 2
		);
		$aIsRecommend = m('Bbs')->getThreadList(1, 5, $aIsRecommendOption, '`create_time` DESC');
		if($aIsRecommend === false){
			return false;
		}
		return $aIsRecommend;
	}

	/**
	 * 计算日期星座
	 * @param type $time 出生时间戳
	 * @return string 星座名称
	 */
	private function _getConstellation($time) {
		$month = date('n', $time);
		$day = date('j', $time);
		//检查时间有效性
		if ($month < 1 || $month > 12 || $day < 1 || $day > 31){
			return false;
		}

		//星座名称以及开始日期
		$aConstellation = array(
			array('20' => '宝瓶座'),
			array('19' => '双鱼座'),
			array('21' => '白羊座'),
			array('20' => '金牛座'),
			array('21' => '双子座'),
			array('22' => '巨蟹座'),
			array('23' => '狮子座'),
			array('23' => '处女座'),
			array('23' => '天秤座'),
			array('24' => '天蝎座'),
			array('22' => '射手座'),
			array('22' => '摩羯座')
		);
		list($signStart, $signName) = each($aConstellation[(int) $month - 1]);
		if($day < $signStart){
			list($signStart, $signName) = each($aConstellation[($month - 2 < 0) ? $month = 11 : $month -= 2]);
		}
		return $signName;
	}

	public function direct301(){
		$uri = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI']) : '';
		if(!$uri){
			alert('');
		}
		$uri = $uri['path'];
		if($uri == '/login/'){
			header('HTTP/1.1 301 Moved Permanently');
			header('Location:' . url('m=Login&a=showLogin', '', APP_LOGIN));
		}elseif($uri == '/exchange/'){
			header('HTTP/1.1 301 Moved Permanently');
			header('Location:' . url('m=Exchange&a=showList'));
		}
	}
}