<?php
/**
 * Description of ShuoShuo
 *
 * @author Administrator
 */
class ShuoShuoController{
	private $_userId = '';

	public function __construct(){
		alert('抱歉,本功能已停用!', 0);
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	public function showShuoshuo(){
		$myUserId = $this->_userId;
		$userId = intval(get('userId', $myUserId));
		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('页面不存在', 0);
		}

		$oSns = m('SnsEvent');
		$count = $oSns->getShuoshuoCountByUserId($userId);

		$oUser = m('User');
		$aUserInfo = $oUser->getPersonalInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		assign('userId', $userId);
		assign('count', $count);
		if(intval(get('userId'))){
			displayHeader('Ta的说说');
			display('shuoshuo/his_shuoshuo.html.php');
			displayFooter(true);
		}else{
			$todaySendShuoCount = $oSns->getShuoshuoCountByUserId($userId, 1);
			$oLimit = m('Limit');
			$remindAccumulateTime = $oLimit->getRemainedShuoshuoAccumulateTime($myUserId);
			assign('todaySendShuoCount', $todaySendShuoCount);
			assign('remindAccumulateTime', $remindAccumulateTime);
			displayHeader('我的说说');
			display('shuoshuo/my_shuoshuo.html.php');
			displayLeftNav($myUserId);
			displayFooter();
		}
	}

	public function getShuoShuoList(){
		$myUserId = $this->_userId;
		$userId = intval(post('userId', $myUserId));
		$type = intval(post('type', 0));
		$page = intval(post('page', 0));
		$pageSize = 10;

		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('无效用户id', 0);
		}
		$aFriendIds = array();

		$oSnsEvent = m('snsEvent');
		$aShuoShuoList = $oSnsEvent->getShuoshuoList($userId, $type, $page, $pageSize);
		if($aShuoShuoList === false){
			alert('程序执行错误，请稍后重试', 0);
		}

		foreach($aShuoShuoList as $key => $aShuoShuo){
			$aShuoShuoList[$key]['create_time'] = date('m月d日 H:i', $aShuoShuo['create_time']);
			if(isset($aShuoShuo['images'])){
				$aShuoShuoList[$key]['images'] = array();
				foreach($aShuoShuo['images'] as $index => $image){
					$aPathinfo = pathinfo($image);
					$aShuoShuoList[$key]['images'][$index]['image'] = $image;
					$aShuoShuoList[$key]['images'][$index]['thumb'] = $aPathinfo['dirname'] . '/' . SHUOSHUO_IMAGE_THUMB_PREFIX . $aPathinfo['basename'];
				}
			}
			if($aShuoShuo['source_type'] == 3){
				$aShuoShuoList[$key]['source_info']['match_start_time'] = date('m月d日 H:i', $aShuoShuo['source_info']['match_start_time']);
				$aShuoShuoList[$key]['source_info']['match_end_time'] = date('m月d日 H:i', $aShuoShuo['source_info']['match_end_time']);
				$aShuoShuoList[$key]['source_info']['match_url'] = url('m=Match&a=showDetail&match_id=' . $aShuoShuo['source_info']['id']);
				if($aShuoShuo['source_info']['users']){
					foreach($aShuoShuo['source_info']['users'] as $m => $aSupport){
						$aTempUser = getUserInfo($aSupport['user_id'], array('area', 'personal'));
						$aTempUser['age'] = date('Y') - date('Y', $aTempUser['birth_date']);
						$aShuoShuoList[$key]['source_info']['users'][$m]['user_info'] = array_merge($aSupport['user_info'], $aTempUser);
						unset($aTempUser);
					}
				}
			}

			if($aShuoShuo['source_type'] == 2){
				$aShuoShuoList[$key]['source_info']['create_time'] = date('m月d日 H:i', $aShuoShuo['source_info']['create_time']);
				$aShuoShuoList[$key]['source_info']['over_time'] = date('m月d日 H:i', $aShuoShuo['source_info']['over_time']);
				$aShuoShuoList[$key]['source_info']['pk_url'] = url('m=Pk&a=showDetail&pk_id=' . $aShuoShuo['source_info']['id']);
				$aShuoShuoList[$key]['source_info']['mission_url'] = url('m=Mission&a=showMissionChallenge&id=' . $aShuoShuo['source_info']['mission_id']);
			}

			//if($aShuoShuo['source_type'] == 0){
				if($aShuoShuo['support']){
					foreach($aShuoShuo['support'] as $n => $aSupport){
						$aTempUser = getUserInfo($aSupport['id'], array('area', 'personal'));
						$aTempUser['age'] = date('Y') - date('Y', $aTempUser['birth_date']);
						$aShuoShuoList[$key]['support'][$n] = array_merge($aSupport, $aTempUser);
						unset($aTempUser);
					}
				}
			//}else{
			//	if($aShuoShuo['source_info']['support']){
			//		foreach($aShuoShuo['source_info']['support'] as $n => $aSupport){
			//			$aTempUser = getUserInfo($aSupport['id'], array('area', 'personal'));
			//			$aTempUser['age'] = date('Y') - date('Y', $aTempUser['birth_date']);
			//			$aShuoShuoList[$key]['source_info']['support'][$n] = array_merge($aSupport, $aTempUser);
			//			unset($aTempUser);
			//		}
			//	}
			//}

			if($aShuoShuo['comment']){
				foreach($aShuoShuo['comment'] as $k => $aComment){
					$aShuoShuoList[$key]['comment'][$k]['create_time'] = date('m月d日 H:i', $aComment['create_time']);
					if($aComment['reply']){
						foreach($aComment['reply'] as $t => $aReply){
							$aShuoShuoList[$key]['comment'][$k]['reply'][$t]['create_time'] = date('m月d日 H:i', $aReply['create_time']);
						}
					}
				}
			}

		}
		alert('说说列表', 1, $aShuoShuoList);
	}

	public function getLastCommentUserList(){
		$userId = intval(post('user_id'));

		if(!$userId){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('无效用户id', 0);
		}
		$oPersonalMessage = m('personalMessage');
		$aLastCommentUserList = $oPersonalMessage->getCommentUserInfo($userId);
		if($aLastCommentUserList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		alert('最近评论用户列表', 1, $aLastCommentUserList);
	}

	public function getLastReplyList(){
		$userId = intval(post('user_id'));

		if(!$userId){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('无效用户id', 0);
		}
		$oPersonalMessage = m('SnsEvent');
		$aLastCommentReplyList = $oPersonalMessage->getUserCommentList($userId, 1, 20);
		if($aLastCommentReplyList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		foreach($aLastCommentReplyList as $key => $aLastCommentReply){
			$aLastCommentReplyList[$key]['create_time'] = date('m月d日 H:i', $aLastCommentReply['create_time']);
		}
		alert('最近回复列表', 1, $aLastCommentReplyList);
	}

	public function publish(){
		if(limitCheck('SNS')){
			limitAdd('SNS');
		}

		$atUserIds = (array)post('at_user_ids');	//@的用户列表,ID数组
		$content = (string)post('content');	//说说内容
		$sourceType = (int)post('source_type');	//转发数据源类型
		$sourceId = (int)post('source_id');	//转发数据源ID
		$isCommentSource = post('is_comment_source') ? true : false;	//是否同时评论
		$aImageList = (array)post('image_list');	//图片地址数组

		//验证内容
		$contentLength = ueGetLength($content);
		if($contentLength < 1 || $contentLength > 150){
			alert('说说内容为1到150个字符长度', 0);
		}
		$content = ueEncodeContent($content);	//说说内容

		$oSns = m('Sns');
		$oSnsEvent = m('snsEvent');

		//验证数据源
		if($sourceId){
			if(in_array($sourceType, array(1, 2, 3))){
				if($sourceType == 1){
					$aShuoShuo = $oSnsEvent->getShuoshuoDetailInfo($sourceId);
					if(!$aShuoShuo){
						alert('所转发的说说不存在', 0);
					}elseif($aShuoShuo['source_type'] > 0){
						alert('禁止转发该说说', 0);
					}/*elseif($aShuoShuo['user_id'] == $this->_userId){
						alert('禁止转发自己的说说', 0);
					}*/
				}
			}else{
				if($sourceType != 0){
					$sourceId = 0;
					alert('非法的转发操作!', 0);
				}
			}
		}else{
			$sourceType = 0;
		}

		if($aImageList){
			if(count($aImageList) > 4){
				alert('上传的图片数量不能超过4张图片', 0);
			}
			foreach($aImageList as &$imageUrl){
				if(!file_exists(SYSTEM_RESOURCE_PATH . $imageUrl)){
					alert('上传的图片不存在', 0);
				}else{
					$fileSuffix = basename(dirname($imageUrl)) . '/' . basename($imageUrl);
					$savePath = SYSTEM_RESOURCE_PATH . SHUOSHUO_IMAGE_PATH . $fileSuffix;
					rename(SYSTEM_RESOURCE_PATH . $imageUrl, $savePath);
					$imageUrl = SHUOSHUO_IMAGE_PATH . $fileSuffix;
					if(!$this->_buildThumbImage($savePath)){
						alert('图片处理出错', 0);
					}
				}
			}
		}

		$now = time();
		$shuoshuoId = $oSns->addSnsShuoshuo(array(
			'user_id' => $this->_userId,
			'content' => $content,
			'images' => $aImageList ? $aImageList : array(),
			'source_id' => $sourceId,
			'source_type' => $sourceType,
			'create_time' => $now,
			'current_date' => date('Ymd', $now)
		));
		if(!$shuoshuoId){
			alert('发表失败', 0);
		}
		if($isCommentSource && $sourceId){
			//同时评论
			$aParam = array(
				'shuoshuo_id' => $sourceId,
				'user_id' => $this->_userId,
				'parent_id' => 0,
				'replyed_user_id' => $aShuoShuo['user_id'],
				'content' => $content,
				'create_time' => time()
			);
			$isCommentSuccess = $oSns->commentShuoshuo($aParam);
			if(!$isCommentSuccess){
				alert('程序执行错误，请稍后重试', 0);
			}
		}

		//发at消息
		if($atUserIds){
			$atUserIds = array_unique($atUserIds);
			if($atUserIds){
				$oUser = m('User');
				foreach($atUserIds as $userId){
					$aUser = $oUser->getUserInfoByUserId($userId);
					if(!$aUser){
						continue;
					}
					$oPersonalMessage = m('personalMessage');
					$oPersonalMessage->addPersonalMessage(array(
						'user_id' => $userId,
						'type' => 1,
						'data_id' => $shuoshuoId,
					));
				}
			}
		}

		//限制与经验
		$limit = limitCheck('SHUOSHUO_ACCUMULATE');
		if($limit){
			limitAdd('SHUOSHUO_ACCUMULATE');
			$oGame = new Game();
			if(!$oGame->afterPublishShuo($this->_userId)){
				alert('程序执行错误，请稍后重试', 0);
			}
		}
		limitAdd('SNS');
		alert('发表成功', 1);
	}

	//赞
	public function support(){
		$id = intval(post('id'));
		$oSns = m('Sns');
		$aShuoShuoInfo = $oSns->getShuoshuoInfoById($id);

		$supportId = 0;
		if(!$aShuoShuoInfo){
			alert('说说不存在', 0);
		}elseif($aShuoShuoInfo['source_type'] == 1){
			//如果是转发的说说就赞源说说
			$aSourceShuoShuoInfo = $oSns->getShuoshuoInfoById($aShuoShuoInfo['source_id']);
			if(!$aSourceShuoShuoInfo){
				alert('原文已经不存在', 0);
			}
			$supportId = $aSourceShuoShuoInfo['id'];
		}else{
			$supportId = $aShuoShuoInfo['id'];
		}

		$result = $oSns->supportShuoshuo($this->_userId, $supportId);
		if($result == 1){
			alert('操作成功！');
		}elseif($result == -1){
			alert('您已经赞过了此说说', -1);
		}else{
			alert('程序执行错误，请稍后重试', 0);
		}
	}

	/**
	 * 获取某条说说的所有评论节点,但回复字点不是所有
	 */
	public function getAllComment(){
		$shuoshuoId = intval(post('id'));

		if(!$shuoshuoId){
			alert('程序执行错误，请稍后重试', 0);
		}

		$oSns = m('Sns');

		$aCommentList = $oSns->getAllShuoShuoComment($shuoshuoId);
		if($aCommentList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		foreach($aCommentList as $key => $aComment){
			$aCommentList[$key]['user_info'] = getUserInfo($aComment['user_id'], array('personal'));
			$aCommentList[$key]['create_time'] = $aComment['create_time'];
			if($aComment['reply']){
				foreach($aComment['reply'] as $k => $aRreply){
					$aCommentList[$key]['reply'][$k]['user_info'] = getUserInfo($aRreply['user_id'], array('personal'));
					$aCommentList[$key]['reply'][$k]['reply_user_info'] = getUserInfo($aRreply['replyed_user_id'], array('personal'));
					$aCommentList[$key]['reply'][$k]['create_time'] = $aRreply['create_time'];
				}
			}
		}
		alert('说说评论列表', 1, $aCommentList);
	}

	public function getAllCommentReply(){
		$commentId = intval(post('id'));

		if(!$commentId){
			alert('程序执行错误，请稍后重试', 0);
		}

		$oSns = m('Sns');

		$aCommentReplyList = $oSns->getAllShuoshuoCommentReply($commentId);
		if($aCommentReplyList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		foreach($aCommentReplyList as $key => $aCommentReply){
			$aCommentReplyList[$key]['user_info'] = getUserInfo($aCommentReply['user_id'], array('personal'));
			$aCommentReplyList[$key]['reply_user_info'] = getUserInfo($aCommentReply['replyed_user_id'], array('personal'));
			$aCommentReplyList[$key]['create_time'] = date('m月d日 H:i', $aCommentReply['create_time']);
		}
		alert('评论回复列表', 1, $aCommentReplyList);
	}

	public function comment(){
		if(limitCheck('SNS')){
			limitAdd('SNS');
		}

		$shuoshuoId = (int)post('shuoshuoId');
		$replyId = (int)post('reply_id');//改回复记录id
		$content = (string)post('content');
		$aAtUserIds = (array)post('atUserIds');

		$contentLength = ueGetLength($content);
		if($contentLength < 1 || $contentLength > 150){
			alert('回复内容为1到150个字符长度', 0);
		}
		$content = ueEncodeContent($content);

		$oSns = m('Sns');
		$aResult = array(
			'content' => $content,
			'user_id' => $this->_userId,
			'create_time' => time(),
		);
		$aShuoShuo = array();
		if($shuoshuoId){
			//如果评论说说
			$aShuoShuo = $oSns->getShuoshuoInfoById($shuoshuoId);
			if(!$aShuoShuo){
				alert('程序执行错误，请稍后重试', 0);
			}
			$aResult['shuoshuo_id'] = $shuoshuoId;
			$aResult['parent_id'] = 0;
			$aResult['replyed_user_id'] = $aShuoShuo['user_id'];
		}elseif($replyId){
			$aReply = $oSns->getShuoShuoCommentByCommentId($replyId);
			if(!$aReply){
				alert('程序执行错误，请稍后重试', 0);
			}
			$aShuoShuo = $oSns->getShuoshuoInfoById($aReply['shuoshuo_id']);
			if(!$aShuoShuo){
				alert('程序执行错误，请稍后重试', 0);
			}

			$aResult['shuoshuo_id'] = $aReply['shuoshuo_id'];
			$aResult['parent_id'] = $aReply['parent_id'] ? $aReply['parent_id'] : $aReply['id'];
			$aResult['replyed_user_id'] = $aReply['user_id'];
		}else{
			alert('错误的评论请求！', 0);
		}

		$commentId = $oSns->commentShuoshuo($aResult);
		if(!$commentId){
			alert('评论失败', 0);
		}
		$aResult['id'] = $commentId;

		//发送at消息
		if($aAtUserIds){
			$aUserIds = array_unique($aAtUserIds);
			$oUser = m('User');
			$oPersonalMessage = m('PersonalMessage');
			foreach($aUserIds as $userId){
				//验证用户ID
				if(!is_numeric($userId) || $userId == $aShuoShuo['user_id']){
					continue;
				}
				$aUser = $oUser->getUserInfoByUserId($userId);
				if($aUser === false){
					alert('抱歉,网络可能有点慢', 0);
				}elseif(!$aUser){
					alert('找不到所@的用户', 0);
				}

				//发送消息
				$isaddPersonalMessageSuccess = $oPersonalMessage->addPersonalMessage(array(
					'user_id' => $userId,
					'type' => 100,
					'data_id' => $commentId,
				));
				if(!$isaddPersonalMessageSuccess){
					alert('程序执行错误，请稍后重试', 0);
				}
			}
		}

		alert('评论成功', 1, $aResult);
	}

	public function delete(){
		$id = intval(post('id'));
		if(!$id){
			alert('程序执行错误，请稍后重试', 0);
		}

		$oSns = m('Sns');
		$aShuoShuo = $oSns->getShuoshuoInfoById($id);
		if($aShuoShuo === false){
			alert('程序执行错误，请稍后重试', 0);
		}elseif(!$aShuoShuo){
			alert('该说说已不存在', 0);
		}elseif($aShuoShuo['user_id'] != $this->_userId){
			alert('这条说说不是你的，不能删除哦', 0);
		}

		$result = $oSns->deleteShuoShuo($id);
		if($result){
			alert('删除说说成功', 1);
		}else{
			alert('删除说说失败', 0);
		}
	}

	/**
	 * 删除说说评论
	 */
	public function deleteComment(){
		$commentId = post('commentId');
		$oSns = m('Sns');
		//$aComment = $oSns->getShuoShuoCommentByCommentId();
		$oComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aComment = $oComment->get('*', 'id=' . $commentId);
		if(!$aComment){
			alert('找不到这条评论', 0);
		}
		$aComment = $aComment[0];

		$allowDelete = false;
		if($aComment['user_id'] != $this->_userId){
			$aShuoShuo = $oSns->getShuoshuoInfoById($aComment['shuoshuo_id']);
			if(!$aShuoShuo){
				alert('找不到这条说说', 0);
			}

			if($aShuoShuo['user_id'] == $this->_userId){
				$allowDelete = true;
			}
		}else{
			$allowDelete = true;
		}

		if($allowDelete){
			$row = $oSns->deleteShuoshuoComment($commentId);
			if(!$row){
				alert('删除失败', 0);
			}else{
				alert('删除成功', 1);
			}
		}
	}

	function showDetail(){
		$shuoId = intval(get('shuo_id'));

		$oSns = m('Sns');
		$aData = $oSns->getShuoshuoDetailInfo($shuoId);
		if($aData === false){
			alert('程序执行错误，请稍后重试', 0);
		}elseif(!$aData){
			alert('说说不存在', 0);
		}

		$aFriendList = $oSns->getUserFriendList($this->_userId);
		$aGroupList = $oSns->getUserGroupList($this->_userId);
		if($aFriendList === false || $aGroupList === false){
			alert('程序执行错误，请稍后重试', 0);
		}

		$count = $oSns->getShuoshuoCountByUserId($this->_userId);
		$aUserInfo = m('User')->getPersonalInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		assign('aUserInfo', $aUserInfo);
		assign('nowUserId', $this->_userId);
		assign('aData', $aData);
		assign('aFriendList', $aFriendList);
		assign('aGroupList', $aGroupList);
		assign('count', $count);
		assign('userId', $this->_userId);
		displayHeader();
		display('event/detail.html.php');
		displayFooter(true);
	}

	/**
	 * 图片上传
	 */
	public function uploadImage(){
		$twoNumberId = substr($this->_userId, -2) . '/';
		$filePrefix = md5(microtime() . $this->_userId . rand(0, 999));

		$oUploader = new UploadFile(UMEDITOR_UPLOAD_IMAGE_MAXSIZE, 'gif,jpg,jpeg,png,bmp', '', SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $twoNumberId, $filePrefix);
		$oUploader->uploadReplace = true;
		$uploadSuccess = $oUploader->upload();

		$aResult = array();
		if(!$uploadSuccess){
			$aResult = array(
				'msg' => $oUploader->getErrorMsg() == '上传文件大小超出限制！' ? '请上传小于' . intval(UMEDITOR_UPLOAD_IMAGE_MAXSIZE / (1024000)) . 'M的图片！' : $oUploader->getErrorMsg(),
				'data' => '',
				'status' => 0,
			);
		}else{
			$uploadFileInfo = current($oUploader->getUploadFileInfo());
			$filePath = USER_TMP_PATH . $twoNumberId . $uploadFileInfo['savename'];
			$srcImageUrl = SYSTEM_RESOURCE_URL . '/' . $filePath;	//返回给前端显示的图片地址
			if($this->_buildThumbImage(SYSTEM_RESOURCE_PATH . $filePath)){
				//如果生成缩略图成功则返回的图片地址改成缩略图地址
				$srcImageUrl = SYSTEM_RESOURCE_URL . '/' . USER_TMP_PATH . $twoNumberId . SHUOSHUO_IMAGE_THUMB_PREFIX . $uploadFileInfo['savename'];
			}
			$aResult = array(
				'msg' => '上传成功!',
				'status' => 1,
				'data' => array(
					'src' => $srcImageUrl,
					'path' => $filePath,
				)
			);
		}
		exit(json_encode($aResult));	//对iframe的异步用alert会在前端产生pre标签
	}

	/**
	 * 生成缩略图
	 * @param type $file
	 * @return string|boolean
	 */
	private function _buildThumbImage($file){
		$oImage = new Image();
		$oImage->setSoureImage($file);
		$oImage->setThumb(160, 130);
		$thumbName = dirname($file) . '/' . SHUOSHUO_IMAGE_THUMB_PREFIX . basename($file);
		if(is_array($oImage->save($thumbName))){
			return false;
		}
		return $thumbName;
    }

	public function getRecommendUserList(){
		$page = intval(post('page', 1));
		if($page < 1){
			$page = 1;
		}
		$aUserFriendIds = getUserFriendIds($this->_userId);
		$aUserFriendIds[] = $this->_userId;
		$oUser = m('user');
		$aRecommendUserIdList = $oUser->getHaveProfileUserIdList($page, 3, $aUserFriendIds);
		if($aRecommendUserIdList === false){
			alert('网络可能有点慢', -1);
		}
		$aRecommendUserList = getUserListByUserIds($aRecommendUserIdList, array('area', 'personal'));
		if($aRecommendUserList === false){
			alert('网络可能有点慢', -1);
		}
		$aRecommendUserList = $this->_getUserFriendCount($aRecommendUserList);
		alert('成功', 1, $aRecommendUserList);
	}

	/**
	 *可能认识的人
	 */
	public function getUserProbalyFriendList(){
		$oSns = m('Sns');
		$aShowId = post('show');
		if($aShowId){
			if(!is_array($aShowId)){
				alert('参数错误', -1);
			}
			foreach($aShowId as $id){
				if(!is_numeric($id)){
					alert('参数错误', -1);
				}
			}
		}else{
			$aShowId = array();
		}
		$oSns->cheakProbablyFriends($this->_userId);
		$aProbalyFriendList = $oSns->getUserRandProbablyList($this->_userId, 3, array('class', 'personal'), $aShowId);
		$aProbalyFriendList = $this->_getUserFriendCount($aProbalyFriendList);
		alert('SUCESS', 1, $aProbalyFriendList);
	}

	private function _getUserFriendCount($aUserList){
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aUserList as $key => $aUser){
			$aUserFriendList = getUserFriendIds($aUser['id']);
			$aUserList[$key]['friend_count'] = count($aUserFriendList);
		}
		return $aUserList;
	}
}
