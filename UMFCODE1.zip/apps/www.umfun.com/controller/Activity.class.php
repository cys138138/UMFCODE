<?php
class ActivityController{

	public function __construct(){}

	public function showActivity(){
		Activity::showActicity(Activity::CLIENT_PC);
	}
	
	public function showMission(){
		Activity::showMission();
	}
	
	public function getWeekRankingList(){
		Activity::getWeekRankingList();
	}
}
