<?php
class StyleController {
	private $_userId = 0;

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	public function showList(){
		$page = intval(post('page', 1));
		$categoryId = intval(post('category_id', 0));
		$isVip = intval(post('is_vip', 0));
		$order = post('order', '`id` desc');
		
		$aCondition = array('status' => 1);
		if($categoryId){
			$aCondition['category_id'] = $categoryId;
		}
		if($isVip){
			$aCondition['vip_limit'] = 1;
		}
		
		$oStyle = m('Style');
		$aStyleList = $oStyle->getStyleList($aCondition, $page, 0, $order);
		if(!$aStyleList){
			alert('系统出错，请稍后再试', 0);
		}else{
			foreach($aStyleList as &$aStyle){
				$aStyle['css_file'] = SYSTEM_RESOURCE_URL . SKIN_PATH . $aStyle['pack_name'] . '/style.css';
				$aStyle['image'] = SYSTEM_RESOURCE_URL . SKIN_PATH . $aStyle['pack_name'] . '/image.jpg';
				$aStyle['type_name'] = '';
				if(isset($GLOBALS['SKIN_CATEGORY'][$aStyle['category_id']])){
					$aStyle['type_name'] = $GLOBALS['SKIN_CATEGORY'][$aStyle['category_id']];
				}
			}
		}
		alert('风格列表', 1, $aStyleList);
	}

	public function setStyle(){
		$styleId = intval(post('style_id'));
		if(!$styleId){
			alert('参数错误', -1);
		}
		$oStyle = m('Style');
		$aStyleInfo = $oStyle->getStyleInfoById($styleId);
		if(!$aStyleInfo){
			alert('系统出错，请稍后再试', 0);
		}
		if($aStyleInfo['status'] != 1){
			alert('皮肤未开放哦！', -1);
		}
		
		$oUserNum = m('UserNumerical');
		$aUserInfo = $oUserNum->getUserNumericalInfoById($this->_userId);
		if($aStyleInfo['vip_limit']){
			if($aUserInfo['vip'] < $aStyleInfo['vip_limit'] || $aUserInfo['vip_expiration_time'] < time()){
				alert('至少要' . $GLOBALS['VIP'][$aStyleInfo['vip_limit']]['name'] . '才可以使用喔', -1);
			}
		}
		$oUser = m('User');
		$aData = array(
			'id' => $this->_userId,
			'style_id' => $styleId
		);
		$isSetSuccess = $oUser->setUserInfo($aData);
		if($isSetSuccess === false){
			alert('系统出错，请稍后再试', 0);
		}else{
			alert('皮肤设置成功！', 1);
		}
	}
	
	public function getUserVipStatus(){
		$oUser = m('UserNumerical');
		$aUserInfo = $oUser->getUserNumericalInfoById($this->_userId);
		if($aUserInfo === false){
			alert('系统错误，稍后重试' ,0);
		}else{
			alert('success' ,1 ,$aUserInfo);
		}
	}
}