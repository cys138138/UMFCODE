<?php
class EventController{

	private $_userId = '';
	private $_aEventRange = array(
		'personal_page' => 1,
		'friends_page' => 2,
		'group_page' => 3
	);

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	public function getPersonalMessageList(){
		$page = intval(post('page', 1));
		if($page < 1){
			$page = 1;
		}
		$aEventList = getPersonalMessageList($this->_userId, array(), 0, $page);
		alert('读取成功', 1, $aEventList);
	}

	public function getEventList(){
		$page = intval(post('page', 1));	//动态页码
		$aPublicUser= array();
		if($page < 1){
			$page = 1;
		}

		$rows = intval(post('rows'));	//动态条数
		if($rows < 1){
			$rows = 20;
		}

		$aEventTypes = post('types');	//动态类型
		if($aEventTypes){
			//验证类型
			foreach($aEventTypes as $type){
				if(!is_numeric($type)){
					alert('错误的动态类型请求！', 0);
				}
			}
		}else{
			$aEventTypes = array();	//没有指定则主空数组,等于全部
		}

		$aGetFriendIds = array();	//要获取动态的好友们的ID集
		$aFriendIds = getUserFriendIds($this->_userId);	//动态中涉及的其他人,如果存在这些好友用户则优先将这些好友显示出来
		array_unshift($aFriendIds, $this->_userId);	//把自己也加入优先显示队列最前面,并且在最优先

		$aUserIds = post('user_ids');	//前端指定了要读取的用户ID集
		if($aUserIds == 'all'){
			//全部
			$aGetFriendIds = array();
		}elseif(is_array($aUserIds)){
			//有指定要读取的ID集,验证每一个用户ID
			foreach($aUserIds as $userId){
				if(!getUserInfo(intval($userId))){
					alert('指定读取的用户不存在');
				}
				$aGetFriendIds[] = $userId;
			}
		}else{
			//其它情况,如果ID集剩下自己一个人的话就改成读全世界
			$aGetFriendIds = $aPiblicList = array_merge(
				$aFriendIds,
				$GLOBALS['PUBLIC_USER_IDS']
			);
		}
		$aEventList = getEventList($aGetFriendIds, $aFriendIds, $aEventTypes, $page, $rows);
		alert('读取成功', 1, $aEventList);
	}

	public function delete(){
		$id = intval(post('id'));
		if(!w('length(1, 11)', $id)){
			alert('程序执行错误，请稍后重试', 0);
		}

		$aPersonalMessage = getPersonalMessageById($id);
		if(!$aPersonalMessage){
			alert('找不到该动态', 0);
		}
		if($aPersonalMessage['user_id'] != $this->_userId){
			alert('禁止删除他人的动态', 0);
		}

		$result = deletePersonalMessage($id);
		if($result){
			alert('删除成功');
		}else{
			alert('删除失败', 0);
		}
	}

	public function getMoreUserList(){
		$type = intval(post('type'));	//1=说说的赞用户	2=比赛的报名用户	3=完成比赛的用户	4=再次报名比赛的用户	5=比赛得奖的用户
		$dataId = intval(post('dataId'));
		$aNoShowUserIds = post('aNoShowUserIds');
		$evenDataUserId = intval(post('evenDataUserId'));

		if(!w('_in(1,2,3,4,5)', $type)){
			alert('错误的请求类型！', 0);
		}
		if($dataId < 1){
			alert('数据错误！', 0);
		}
		if(!is_array($aNoShowUserIds)){
			$aNoShowUserIds = array();
		}
		if($evenDataUserId < 0){
			alert('数据错误！', 0);
		}


		$oSns = m('Sns');
		$oSnsEvent = m('SnsEvent');

		//如果是说说，查出源说说Id
		if($type == 1){
			$aShuoShuoInfo = $oSns->getShuoshuoInfoById($dataId);
			if($aShuoShuoInfo === false){
				alert('系统错误！', 0);
			}
			if(!$aShuoShuoInfo){
				alert('数据错误！', 0);
			}
			if($aShuoShuoInfo['source_type'] == 1){
				$dataId = $aShuoShuoInfo['source_id'];
			}
			unset($aShuoShuoInfo);
		}

		if($type == 2 && $evenDataUserId){
			array_push($aNoShowUserIds, $evenDataUserId);
		}


		//查询出当前用户所有好友Id
		$aFriendIds = getUserFriendIds($this->_userId);
		if($aFriendIds === false){
			alert('系统错误！', 0);
		}
		//查询出　"赞"　的前五十个用户
		$aUserList = $oSnsEvent->getMoreUserList($type, $dataId, $aNoShowUserIds);
		if($aUserList === false){
			alert('系统错误！', 0);
		}

		//判断用户是否可加好友
		foreach($aUserList as $key=> $aUserInfo){
			if(in_array($aUserInfo['id'], $aFriendIds) || $aUserInfo['id'] == $this->_userId){
				$aUserList[$key]['is_friend'] = 1;
			}else{
				$aUserList[$key]['is_friend'] = 0;
			}
		}
		alert('', 1, $aUserList);
	}

	/**
	 * 赛事和PK统计
	 */
	public function matchAndPKStatistics(){
		$oMatch = m('Match');
		$oPk = m('Pk');
		$aMatchStatis = $oMatch->getUserMatchStatisticsList($this->_userId);
		$aPKStatis = $oPk->getUserPkStatisticsList($this->_userId);
		foreach($aPKStatis as $key => $val){
			$aMatchStatis[$key] = $val;
		}
		alert('SUCCESS', 1, $aMatchStatis);
	}
}
