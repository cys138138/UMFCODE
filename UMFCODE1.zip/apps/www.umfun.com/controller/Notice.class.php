<?php
/**
 * 介个是消息中心么
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-9-4
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
class NoticeController{
	private $_userId = 0;

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}


	//返回当前用户的好友分组ID和好友ID
	private function _getUserFriendAndGroup(){
		//取所有好友及分组信息
		$aReturnArray = array();
		$aFriendGroup = array();
		$aFriendUser = array();
		$aFriendIdStr = '';
		$oSns = new SnsModel();
		$aFriendResult = $oSns->getUserFriendInfo($this->_userId);
		if($aFriendResult){
			if($aFriendResult['friends']){
				//取所有下标，即分组
				$aFriendGroup = array_keys($aFriendResult['friends']);
				foreach($aFriendResult['friends'] as $friendsInfo){
					if($friendsInfo != ''){
						$aFriendIdStr .= ',' . $friendsInfo;
					}
				}
				if($aFriendIdStr){
					$aFriendUser = array_filter(explode(',', trim($aFriendIdStr, ',')));
				}
			}
		}

		$aReturnArray['friendGroup'] = $aFriendGroup;
		$aReturnArray['friendUser'] = $aFriendUser;
		return $aReturnArray;
	}


	//通过申请，同意加为好友
	public function agree(){
		$userId = $this->_userId;
		$id = intval(post('id'));
		$groupId = intval(post('groupId', 0));

		if($id < 0){
			alert('数据错误', 0);
		}

		if($groupId < -1){
			alert('数据错误', 0);
		}

		$oSns = new SnsModel();

		//检查好友请求是否存在
		$aUserRelationInfo = $oSns->getUserRelationInfo('`id` = ' . $id);
		if(!$aUserRelationInfo){
			alert('该好友请求不存在', 0);
		}

		//取所有好友ID和分组ID　
		$aFriendAndGroupArray = $this->_getUserFriendAndGroup();
		if(!$aFriendAndGroupArray){
			alert('数据错误', 0);
		}

		if(in_array($aUserRelationInfo[0]['user_master_id'], $aFriendAndGroupArray['friendUser'])){
			alert('该用户已经是你的好友', 0);
		}

		//检查分组是否存在
		if($groupId){
			if(!in_array($groupId, $aFriendAndGroupArray['friendGroup'])){
				alert('该分组不存在', 0);
			}
		}else{
			$groupId = '-1';
		}
		$result = $oSns->acceptFriendsApply($userId, $aUserRelationInfo[0]['user_master_id'], $id, $groupId);
		if($result){
			alert('添加好友成功');
		}else{
			alert('添加好友失败，请重新操作', 0);
		}

	}


	//不同意申请，忽略      共用
	public function disagree(){
		$msgId = intval(post('msgId'));
		if($msgId < 0){
			alert('数据错误', 0);
		}

		$oSns = new SnsModel();
		$aMessageInfo = $oSns->getPersonalMessageById($msgId);
		if(!$aMessageInfo){
			alert('好友请求不存在', 0);
		}

		$aUserRelationInfo = $oSns->getUserRelationInfo('`id` = ' . $aMessageInfo['data_id']);
		if(!$aUserRelationInfo || $aUserRelationInfo[0]['user_slave_id'] != $this->_userId){
			alert('好友请求不存在', 0);
		}

		$result = $oSns->ignoreFriendApply($msgId);
		if($result){
			alert('已忽略');
		}else{
			alert('操作失败', 0);
		}
	}


	//好友确认 知道了
	public function deleteMyApply(){
		$msgId = intval(post('msgId'));
		if($msgId < 1){
			alert('数据错误', 0);
		}

		$oSns = new SnsModel();

		$aMessageInfo = $oSns->getPersonalMessageById($msgId);
		if(!$aMessageInfo){
			alert('数据错误', 0);
		}

		if($aMessageInfo['user_id'] != $this->_userId){
			alert('没有权限操作', 0);
		}


		$result = $oSns->deletePersonalMessageById($msgId);
		if($result){
			alert('success');
		}else{
			alert('删除失败，请重新操作', 0);
		}
	}

	public function send(){
		$aParam['receiver_user_id'] = intval(post('friendId'));
		if(!$aParam['receiver_user_id']){
			alert('程序执行错误，请稍后重试', 0);
		}
		$aParam['sender_user_id'] = $this->_userId;
		$aParam['content'] = post('content');
		$aParam['create_time'] = time();
		$aParam['is_read'] = 2;

		$oSns = m('Sns');
		$result = $oSns->addSnsPrivateMessage($aParam);
		if($result){
			alert('已发送');
		}else{
			alert('发送失败，请重新操作', 0);
		}
	}


	//好友解除消息忽略  共用
	public function deletePersonalMessage(){
		$msgId = intval(post('msgId'));
		if($msgId < 1){
			alert('数据错误', 0);
		}

		$oSns = new SnsModel();

		$aMessageInfo = $oSns->getPersonalMessageById($msgId);
		if(!$aMessageInfo){
			alert('数据错误', 0);
		}

		if($aMessageInfo['user_id'] != $this->_userId){
			alert('没有权限操作', 0);
		}

		$result = $oSns->deletePersonalMessageById($msgId);
		if($result){
			alert('success');
		}else{
			alert('删除失败，请重新操作', 0);
		}
	}


	public function deletePersonalMessageHeader(){
		$id = intval(get('id'));
		$oSns = m('Sns');
		$result = $oSns->deletePersonalMessageById($id);
		//Debug::showClass($oSns);
		if($result){
			$json = json_encode(array('status' => 1, 'msg' => '已忽略'));
		}else{
			$json = json_encode(array('status' => 0, 'msg' => '操作失败，请重新操作'));
		}
		echo $_GET['jsoncallback'].'('.$json.')';
		exit;
	}

	//不同意申请，忽略
	public function disagreeHeader(){
		$id = intval(get('id'));
		if(!$id){
			$json = json_encode(array('status' => 0, 'msg' => '程序执行错误，请稍后重试'));
		}
		$oSns = m('Sns');
		$aUserRelationInfo = $oSns->getUserRelationInfo('`id` = ' . $id);
		if(!$aUserRelationInfo || $aUserRelationInfo[0]['user_slave_id'] != $this->_userId){
			$json = json_encode(array('status' => 0, 'msg' => '好友请求不存在'));
		}
		$result = $oSns->ignoreFriendApply($id);

		if($result){
			$json = json_encode(array('status' => 1, 'msg' => '已忽略'));
		}else{
			$json = json_encode(array('status' => 0, 'msg' => '操作失败，请重新操作'));
		}
		echo $_GET['jsoncallback'].'('.$json.')';
		exit;
	}

}