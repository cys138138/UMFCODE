<?php
class EsCommentController{
	private $_userId = 0;
	private $_commentType = 1;	//评论类型
	private $_questionType = 2;	//问问类型
	private $_answerType = 3;	//回答类型
	
	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}
	
	public function index(){
		$esId = intval(Xxtea::decrypt(get('es_id')));
		$oEsComment = m('Wenwen');
		$esCommentCount = $oEsComment->getCommentCount($esId);
		$esQuestionCount = $oEsComment->getQuestionCount($esId);
		$oUser = m('User');
		$aUserInformation = $oUser->getUserDetailInfoByUserId($this->_userId);
		
		assign('esId', get('es_id'));
		assign('esCommentCount', $esCommentCount);
		assign('esQuestionCount', $esQuestionCount);
		assign('aUserInformation', $aUserInformation);
		display('es_comment/index.html.php');
	}

	public function showEsComment(){
		$esId = intval(Xxtea::decrypt(get('es_id')));
		$page = intval(get('page', 1));
		$typeId = intval(get('type', $this->_commentType));
		if(!$esId){
			alert('程序执行出错，请稍后重试', 0);
		}
		if(!($typeId >= 0 && $typeId <= 2)){
			alert('程序执行出错，请稍后重试', 0);
		}
		$oEsComment = m('Wenwen');
		$pageSize = 5;
		$page = $page > 0 ? $page : 1;
		if($typeId == $this->_commentType){
			$esCommentCount = $oEsComment->getCommentCount($esId);
			if($esCommentCount === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aEsCommentList = $oEsComment->getCommentListByEsId($esId, $page, $pageSize, '`create_time` desc');
			if($aEsCommentList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			
			assign('esCommentCount', $esCommentCount);
			assign('aEsCommentList', $aEsCommentList);
			assign('nextPage',$page + 1);
			display('es_comment/es_comment.html.php');
		}else if($typeId == $this->_questionType){
			$esQuestionCount = $oEsComment->getQuestionCount($esId);
			if($esQuestionCount === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aEsQuestionList = $oEsComment->getQuestionListByEsId($esId, $page, $pageSize, '`create_time` desc');
			if($aEsQuestionList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			
			assign('esQuestionCount', $esQuestionCount);
			assign('aEsQuestionList', $aEsQuestionList);
			assign('nextPage',$page + 1);
			display('es_comment/es_question.html.php');
		}else{
			alert('程序执行出错，请稍后重试', 0);
		}
	}
	
	public function addComment(){
		$esId = intval(Xxtea::decrypt(post('es_id')));
		$replyId = intval(post('id'));
		$typeId = intval(post('typeId'));
		$is_anonymous = intval(post('is_anonymous'));
		$content = ueEncodeContent(post('content'));
		$userId = $this->_userId;
		
		if(!$esId){
			alert('程序执行出错，请稍后重试', 0);
		}
		if(!$content){
			alert('发表内容为2到100个字符长度', 0);
		}
		$contentLength = ueGetLength(post('content'));
		if($contentLength < 2 || $contentLength > 100){
			alert('发表内容为2到100个字符长度', 0);
		}
		$oEsComment = m('Wenwen');
		if($typeId == $this->_commentType){
			$aEsComment = array(
				'es_id' => $esId,
				'user_id' => $userId,
				'parent_id' => $replyId,
				'is_anonymous' => $is_anonymous,
				'content' => $content,
				'create_time' => time(),
				'approved' => 0,
				'ip' => getClientIP()
			);
			$isAddCommentSucess = $oEsComment->addComment($aEsComment);
			if($isAddCommentSucess === false){
				alert('系统有误！请稍后重试！', 0);
			}elseif($isAddCommentSucess){
				$aEsComment['id'] = $isAddCommentSucess;
				alert('评论成功', 1, $aEsComment);
			}else{
				alert('评论失败，请稍后再试', 0);
			}
		}else if($typeId == $this->_questionType){
			$aEsQuestion = array(
				'es_id' => $esId,
				'user_id' => $userId,
				'is_anonymous' => $is_anonymous,
				'question' => $content,
				'create_time' => time(),
				'ip' => getClientIP()
			);
			$isAddQuestionSucess = $oEsComment->addQuestion($aEsQuestion);
			if($isAddQuestionSucess === false){
				alert('系统有误！请稍后重试！', 0);
			}elseif($isAddQuestionSucess){
				$aEsQuestion['id'] = $isAddQuestionSucess;
				alert('问问成功', 1, $aEsQuestion);
			}else{
				alert('问问失败，请稍后再试', 0);
			}
		}else if($typeId == $this->_answerType){
			$aEsQuestionAnswer = array(
				'question_id' => $replyId,
				'user_id' => $userId,
				'is_anonymous' => $is_anonymous,
				'answer' => $content,
				'supports' => 0,
				'create_time' => time(),
				'ip' => getClientIP()
			);
			$isAddAnswerSucess = $oEsComment->addAnswer($aEsQuestionAnswer);
			if($isAddAnswerSucess === false){
				alert('系统有误！请稍后重试！', 0);
			}elseif($isAddAnswerSucess){
				$aEsQuestionAnswer['id'] = $isAddAnswerSucess;
				alert('回答问问成功', 1, $aEsQuestionAnswer);
			}else{
				alert('回答问问失败，请稍后再试', 0);
			}
		}else{
			alert('程序执行出错，请稍后重试', 0);
		}
		
	}
	
}