<?php
/**
 * Description of Help
 *
 * @author Administrator
 */
class HelpController{
	private $_aSubjectConfig = array(
		array(
			'title' => '注册与登陆',
			'module' => 'user',
			'highlight' => 'register',
			'list' => array(
				'register' => '注册',
				'login' => '登陆',
			),
		),
		array(
			'title' => '账户设置',
			'module' => 'setting',
			'list' => array(
				'personal' => '个人资料',
				'headimg' => '修改头像',
				'school' => '学校资料',
				// 'emilmodify' => '修改邮箱账户',
				'bindmobile' => '绑定手机账号',
				'password' => '修改账户密码',
				// 'game' => '游戏设置',
				// 'parent' => '家长账户绑定',
				'skin' => '皮肤修改',
			),
		),
		array(
			'title' => '等级和经验',
			'module' => 'level',
			'list' => array(
				'introduced' => '等级和经验的介绍',
				'getway' => '经验的获得方式',
			),
		),
		/*array(
			'title' => '勋章',
			'module' => 'medal',
			'list' => array(
				'mintroduced' => '勋章的介绍',
				'mission' => '闯关勋章',
				'best' => '闯关奖章',
				'pk' => 'PK勋章',
			),
		),*/
		array(
			//'title' => 'U币与金币',$gXxtUserId
			'title' => '金币',
			'module' => 'money',
			'list' => array(
				//'uintroduced' => 'U币和金币的介绍',$gXxtUserId
				'uintroduced' => '金币的介绍',
				'signin' => '获取金币途径',
				//'uchong' => 'U币充值',$gXxtUserId
				//'vipchong' => '会员充值',$gXxtUserId
				//'utogold' => 'U币兑换金币',$gXxtUserId
			),
		),
		array(
			'title' => '比赛',
			'module' => 'match',
			'list' => array(
				'howin' => '如何进行比赛',
				'registration' => '报名条件',
				'process' => '比赛流程',
				'award' => '如何领奖',
			),
		),
		array(
			'title' => 'PK',
			'module' => 'pk',
			'list' => array(
				'rule' => 'PK规则',
				'send' => '如发起PK',
				'square' => 'PK场',
			),
		),
		array(
			'title' => '闯关挑战',
			'module' => 'dekaron',
			'list' => array(
				'dintroduced' => '闯关挑战的介绍',
				'start' => '起始关卡',
				'practice' => '修炼和挑战',
				'record' => '关卡战绩',
				'totalrecord ' => '总战绩',
				'errores' => '错题集',
			),
		),
		array(
			'title' => '道具',
			'module' => 'prop',
			'list' => array(
				'propintroduced' => '道具介绍',
			),
		),
		array(
			'title' => '消息',
			'module' => 'message',
			'list' => array(
				'warn' => '消息提醒'
			),
		),
	);

	public function showHome(){
		assign('aSubjectConfig', $this->_aSubjectConfig);
		display('help/home.html.php');
	}

	public function showSubject(){
		$module = get('module', 'user');
		$type = get('type', 'register');
		if($type){
			display('help/content/' . $module . '_' . $type . '.html.php');
		}
	}

	/**
	 * 检查是否需要指引
	 */
	public function checkIsNeedGuide(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$userCode = User::isReadIndexGuide($userId);
		if(!$userCode){
			$userUpdateTag = User::readIndexGuide($userId);
			if(!$userUpdateTag){
				halt('更新新手引导显示标记失败', 0);
			}
			alert('没有看过', 1, 0);
		}
		alert('有看过', 1, 1);
	}
}
