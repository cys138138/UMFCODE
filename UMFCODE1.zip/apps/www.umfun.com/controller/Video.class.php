<?php
class VideoController{
	private $_userId = '';

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}
	
	//视频首页
	public function showVideoHome(){
		$categoryId = intval(get('categoryId'));
		if($categoryId < 0){
			alert('数据错误', 0);
		}
		if($categoryId > 0){
			$oVideo = m('video');
			$aCagegoryInfo = $oVideo->getVideoCategoryInfoById($categoryId);
			if(!$aCagegoryInfo || $aCagegoryInfo['status'] != 1){
				alert('数据错误', 0);
			}
		}
		
		$aCategoryList = $this->_getCategoryList();
		if($aCategoryList === false){
			alert('系统错误', 0);
		}
		assign('aCategoryList', $aCategoryList);
		assign('userId', $this->_userId);
		assign('categoryId', $categoryId);
		Cookie::set('read_video' . $this->_userId, time(), time() + 86400 * 7);
		displayHeader('视频');
		displayLeftNav($this->_userId);
		display('video/index.html.php');
		displayFooter();
	}
	
	//根据条件取视频列表
	public function getVideoList(){
		$categoryId = intval(post('categoryId'));
		$page = intval(post('page'));		
		$pageSize = 20;
		$aCondition = array('statu' => 1);
		$aReturnData = array(
			'pageCount' => 0,
			'videoList' => array()
		);
		
		if($categoryId < 0 || $page < 1){
			alert('数据错误', 0);
		}
		if($categoryId == 0){
			if($page == 1){
				$pageSize = 26;	
			}else{
				$pageSize = 17;	
			}
			$aCondition['is_recommend'] = 1;
		}else{
			$aCondition['category_id'] = $categoryId;
		}
		
		$oVideo = m('video');
		$videoCount = $oVideo->getVideoCount($aCondition);
		if($videoCount === false){
			alert('系统错误', 0);
		}
		if($videoCount > 0){
			$aReturnData['pageCount'] = ceil($videoCount / $pageSize);
			$aReturnData['videoList'] = $oVideo->getVideoList($aCondition, $page, $pageSize);
			if($aReturnData['videoList'] === false){
				alert('系统错误', 0);
			}
		}
		alert('', 1, $aReturnData);
	}
	
	
	//视频播放页
	public function videoPlay(){
		$id = intval(get('id'));
		if($id < 1){
			alert('数据错误', 0);
		}
		//分类列表
		$aCategoryList = $this->_getCategoryList();
		if($aCategoryList === false){
			alert('系统错误', 0);
		}
		
		$oVideo = m('video');
		
		//视频信息
		$aVideoInfo = $oVideo->getVideoInfoById($id);
		if(!$aVideoInfo || $aVideoInfo['status'] != 1){
			alert('该视频不存在或暂时无法播放', 0);
		}
		$aVideoInfo['play_url'] = base64_encode($aVideoInfo['umelook_id']) . '__';
		if($aVideoInfo['is_trans'] == 1){
			$aVideoInfo['play_url'] .= base64_encode($aVideoInfo['umelook_id']) . '_0.xml';
		}
		$aVideoInfo['create_time_str'] = $this->_getTimeAgo($aVideoInfo['create_time']);
		
		
		//当前视频分类信息
		$aCategoryInfo = $oVideo->getVideoCategoryInfoById($aVideoInfo['category_id']);
		if(!$aCategoryInfo || $aCategoryInfo['status'] != 1){
			alert('该视频不存在或暂时无法播放', 0);
		}
		$categoryId = $aCategoryInfo['id'];
		unset($aCategoryInfo);
		
		//右侧列表
		$aRightVideoList = $oVideo->getFrontVideoList($aVideoInfo['id'], 6);
		if($aRightVideoList === false){
			alert('系统错误', 0);
		}
		
		//更新播放次数
		$aData = array(
			'id' => $aVideoInfo['id'],
			'views' => $aVideoInfo['views'] + 1
		);
		if(!$oVideo->setVideo($aData)){
			alert('系统错误', 0);
		}
		
		assign('aCategoryList', $aCategoryList);
		assign('userId', $this->_userId);
		assign('aVideoInfo', $aVideoInfo);
		assign('aRightVideoList', $aRightVideoList);
		assign('ategoryId', $categoryId);
		displayHeader('视频');
		displayLeftNav($this->_userId);
		display('video/play.html.php');
		displayFooter();
		
	}
	
	//返回所有可见视频分类  
	private function _getCategoryList($status = 1){
		$oVideo = m('video');
		$categoryCount = $oVideo->getVideoCategoryCount($status);
		if($categoryCount === false){
			return false;
		}
		$aCategoryList = $oVideo->getVideoCategoryList($status, 1, $categoryCount);
		if($aCategoryList === false){
			return false;
		}
		return $aCategoryList;	
	}
	
	
	//将时间戳转换成 xx天之前、y小时之前 的形式
	private function _getTimeAgo($time){
			$returnStr = '';
			$seconds = time() - $time;
			if($seconds <= 60){
				$returnStr .= '1分钟';				
			}elseif (60 < $seconds && $seconds < 60 * 60) {
				$returnStr = ceil($seconds / 60) . '分钟';
			}elseif (60*60 <= $seconds && $seconds < 60 * 60 * 24 ) {
				$returnStr = ceil($seconds / (60 * 60)) . '小时';
			}elseif(60 * 60 * 24 <= $seconds && $seconds < 60 * 60 * 24 * 30) {
				$returnStr = ceil($seconds / (60 * 60 * 24)) . '天';
			}elseif (60 * 60 * 24 * 30 <= $seconds && $seconds < 60 * 60 * 24 * 30 * 12 ) {
				$returnStr = ceil($seconds / (60 * 60 * 24 * 30)) . '月';
			}else{
				$returnStr = ceil($seconds / (60 * 60 * 24 * 30 * 12)) . '年';
			}
			return $returnStr . '前';
	}
	
	
	
	
}