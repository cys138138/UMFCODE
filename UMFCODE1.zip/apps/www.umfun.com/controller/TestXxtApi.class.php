<?php
class TestXxtApiController{
	private $_userId = '';

	public function __construct(){
		
	}
	
	public function index(){
		echo '测试校迅通Api首页！';
	}
	
	public function chkOauth(){
		$token = '60f1cce02b412335ddfd19790c6b3030';
		
		$aLoginInfo = Xxt::getLoginInfo($token);
		
		debug($aLoginInfo);
	}
	
	public function qryClassTeacher(){
		$teacherId = 3337445;
		
		$aClassTeacher = Xxt::getClassTeacher($teacherId);
		
		debug($aClassTeacher);
	}
	
	public function qryClassStudent(){
		$cityId = 'gz';
		$classId = 1411443;
		
		$aClassStudent = Xxt::getClassStudent($cityId, $classId);
		
		debug($aClassStudent);
	}
	
	public function qryParentInfo(){
		$cityId = 'gz';
		$userId = 4808484;
		
		$aParent = Xxt::getParentInfo($cityId, $userId);
		
		debug($aParent);
	}
	
	public function qryStudentInfo(){
		$cityId = 'gz';
		$userId = 5205971;
		
		$aStudent = Xxt::getStudentInfo($userId, $cityId);
		
		debug($aStudent);
	}
	
	public function qryTeacherInfo(){
		$cityId = 'gz';
		$userId = 3337445;
		
		$aTeacher = Xxt::getTeacherInfo($userId, $cityId);
		
		debug($aTeacher);
	}
	
	public function qryClass(){
		$classId = 1411443;
		
		$aClass = Xxt::getClassInfo($classId);
		
		debug($aClass);
	}
	
	public function qrySchool(){
		$schoolId = 169055;
		
		$aSchool = Xxt::getSchoolInfo($schoolId);
		
		debug($aSchool);
	}
	
	public function sendSysPublicMessage(){
		/*$aParams = [
			'CityId' => 'gz',
			'SchoolId' => 169055,
			'MessageType' => 1,	//消息类型(1 普通消息，2 推广消息，9 其他)
			'UserType' => 2,	//接收用户类型(1 教师，2 学生，3 家长)
			'MessageContent' => 2,	//接收内容
			'UserId' => 5205971,
			'MessageURL' => 'http://www.umfun.com/',	//消息对应连接地址
			'IsOauth' => 1,	//是否支持单点登录.0 不需要，1 需要
			'OthMsgId' => time(),	//第三方消息ID
			'ValidDate' => date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30)	//有效日期,日期格式yyyy-MM-dd hh:MM:ss
		];*/
		
		$aParams = [
			'City' => 'gz',
			'SchoolId' => 169055,
			'Type' => 1,	//消息类型(1 普通消息，2 推广消息，9 其他)
			'UserType' => 2,	//接收用户类型(1 教师，2 学生，3 家长)
			'Content' => 2,	//接收内容
			'UserId' => 5205971,
			'URL' => 'http://www.umfun.com/',	//消息对应连接地址
			'IsOauth' => 1,	//是否支持单点登录.0 不需要，1 需要
			'OthMsgId' => time(),	//第三方消息ID
			'ValidDate' => date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30)	//有效日期,日期格式yyyy-MM-dd hh:MM:ss
		];
		
		$aReturn = Xxt::postAppMessage($aParams['UserId'], $aParams);
		
		debug($aReturn);
	}
	
	public function addWeiboMsg(){
		/*$aParams = [
			'CityId' => 'gz',
			'UserId' => 5205971,
			'RoleType' => 2,	//(1 教师，2 学生，3 家长)
			'SchoolId' => 169055,
			'ClassId' => 1411443,
			'Content' => 'ContentContent',
			'FromSys' => 9,	//微博来源 9: 第三方Web；10：第三方APP
			'MsgType' => 2,	//微博类型 1 校圈，2 班圈，3 教师圈
			'HasAttachment' => 1,	//是否有附件1 是，0 否
			'WeiboMsgAttachmentList' => [
				'PathAndName' => 'http://s.umfun.com/view2/images/global/activity_team.jpg',
				'ThumbPath' => 'http://s.umfun.com/view2/images/global/activity_team.jpg'
			]
		];*/
		
		$aParams = [
			'City' => 'gz',
			'user_id' => 5205971,
			//'role_type' => 2,	//(1 教师，2 学生，3 家长)
			//'school_id' => 169055,
			//'class_id' => 1411443,
			'Content' => 'ContentContent',
			//'from_sys' => 9,	//微博来源 9: 第三方Web；10：第三方APP
			'MsgType' => 2,	//微博类型 1 校圈，2 班圈，3 教师圈
			'HasAttachment' => 1,	//是否有附件1 是，0 否
			'PathAndName' => 'http://s.umfun.com/view2/images/global/activity_team.jpg',
			'ThumbPath' => 'http://s.umfun.com/view2/images/global/activity_team.jpg'
		];
		
		$aReturn = Xxt::postAddWeibo($aParams['user_id'], $aParams);
		
		debug($aReturn);
	}
	
	public function shareWeiboMsg(){
		/*$aParams = [
			'CityId' => 'gz',
			'UserId' => 5205971,
			'RoleType' => 2,	//(1 教师，2 学生，3 家长)
			'SchoolId' => 169055,
			'ClassId' => 1411443,
			'Content' => 'ContentContent',
			'FromSys' => 9,	//微博来源 9: 第三方Web；10：第三方APP
			'LinkTitle' => '转发标题转发标题',	//转发标题
			'LinkUrl' => 'http://www.umfun.com/',	//转发链接
			'LinkDesc' => '转发描述转发描述',	//转发描述
			'ThumbPic' => 'http://s.umfun.com/view2/images/global/activity_team.jpg',	//缩略图片地址
		];*/
		
		$aParams = [
			'City' => 'gz',
			'UserId' => 5205971,
			'RoleType' => 2,	//(1 教师，2 学生，3 家长)
			'SchoolId' => 169055,
			'ClassId' => 1411443,
			'Content' => 'ContentContent',
			'FromSys' => 9,	//微博来源 9: 第三方Web；10：第三方APP
			'Title' => '转发标题转发标题',	//转发标题
			'Url' => 'http://www.umfun.com/',	//转发链接
			'Desc' => '转发描述转发描述',	//转发描述
			'ThumbPic' => 'http://s.umfun.com/view2/images/global/activity_team.jpg',	//缩略图片地址
		];
		
		$aReturn = Xxt::postShareWeibo($aParams['UserId'], $aParams);
		
		debug($aReturn);
	}
	
}