<?php

//战绩分析
class GradeController {


	private $_userId = 0;


	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}


	/**
	 *总战绩
	 */
	public function showGrade(){
		$userId = $this->_userId;
		$aUserInfo = getUserInfo($userId, array('numerical'));
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($userId);
		if($aUserNumerical === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aUserInfo = array_merge($aUserInfo, $aUserNumerical);
		$oMission = m('Mission');
		$aAllMissionStatistics = $oMission->getAllMissionStatisticsByUserId($userId);
		if(!$aAllMissionStatistics){
			$aAllMissionStatistics = array(
				'pass_mission_count' => 0,
				'es_count' => 0,
				'es_correct_count' => 0,
				'subject_count' => array(),
				'last_12_month_count' => array()
			);
			$aAllMissionStatistics['subject_count'][1] = array(
				'es_count' => 0,
				'es_correct_count' => 0,
				'pass_mission_count' => 0,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aAllMissionStatistics['subject_count'][2] = array(
				'es_count' => 0,
				'es_correct_count' => 0,
				'pass_mission_count' => 0,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aAllMissionStatistics['subject_count'][3] = array(
				'es_count' => 0,
				'es_correct_count' => 0,
				'pass_mission_count' => 0,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aAllMissionStatistics['subject_count'][4] = array(
				'es_count' => 1,
				'es_correct_count' => 0,
				'pass_mission_count' => 1,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aLast12MonthList = array();
			$thisYear = date('Y');
			$thisMonth = date('m');
			for($i = 11; $i >= 0; $i --){
				if($thisMonth - $i > 0){
					$year = $thisYear;
					$month = $thisMonth - $i;
				}else{
					$year = $thisYear - 1;
					$month = 12 - ($i - $thisMonth);
				}
				if($month < 10){
					$month = 0 . $month;
				}
				$monthStartTime = mktime(0, 0, 0, $month, 1, $year);
				if($month < 12){
					$monthEndTime = mktime(0, 0, 0, $month + 1, 1, $year) - 1;
				}else{
					$monthEndTime = mktime(0, 0, 0, 1, 1, $year + 1) - 1;
				}
				$aLast12MonthList[$year . $month] = array(
					'start_time' => $monthStartTime,
					'end_time' => $monthEndTime,
					'pass_mission_count' => 0,
					'es_count'	=> 0,
					'sum_score'	=> 0,
				);
			}
			$aAllMissionStatistics['last_12_month_count'] = $aLast12MonthList;
		}
		$aAllMissionStatistics['subject_count'][1]['percent'] = $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][1]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][2]['percent'] = $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][2]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][3]['percent'] = $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][3]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : '00.00';

		$aAllMissionStatistics['subject_count'][1]['mission_rate'] = $aAllMissionStatistics['pass_mission_count'] ? intval(($aAllMissionStatistics['subject_count'][1]['pass_mission_count'] / $aAllMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][2]['mission_rate'] = $aAllMissionStatistics['pass_mission_count'] ? intval(($aAllMissionStatistics['subject_count'][2]['pass_mission_count'] / $aAllMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][3]['mission_rate'] = $aAllMissionStatistics['pass_mission_count'] ? intval(($aAllMissionStatistics['subject_count'][3]['pass_mission_count'] / $aAllMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';

		$aEsMonthStats = array();
		$aMissionMonthStats = array();
		$aScoreMonthStats = array();
		$i = 0;
		foreach($aAllMissionStatistics['last_12_month_count'] as $key => $aStats){
			$aEsMonthStats[$i] = array();
			$aMissionMonthStats[$i] = array();
			$aScoreMonthStats[$i] = array();
			$aEsMonthStats[$i][0] = $key;
			$aEsMonthStats[$i][1] = $aStats['es_count'];
			$aMissionMonthStats[$i][0] = $key;
			$aMissionMonthStats[$i][1] = $aStats['pass_mission_count'];
			$aScoreMonthStats[$i][0] = $key;
			$aScoreMonthStats[$i][1] = $aStats['pass_mission_count'] ? intval((($aStats['sum_score'] / 100) / $aStats['pass_mission_count']) * 100) / 100 : 0;
			$i++;
		}
		$aMonthStats = array($aEsMonthStats, $aMissionMonthStats, $aScoreMonthStats);

		$oNumerical = m('UserNumerical');
		$aMedalList = $oNumerical->getMedalListByUserIds(array($userId));
		if($aMedalList === false){
			$aMedalList = array();
		}elseif($aMedalList){
			$aMedalList = $aMedalList[0]['medal_process'];
		}
		$oPk = m('Pk');
		$aUserPkStat = $oPk->getUserPkCountListByUserIds(array($userId));
		if($aUserPkStat === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMatch = m('Match');
		$matchCount = $oMatch->getUserRegisterMatchCount($userId);
		if($matchCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$matchWinPrizeCount = $oMatch->getUserWinPrizeCount($userId);
		if($matchWinPrizeCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oUser = m('User');
		$aMonthList = $oUser->getUserMonthList($userId);
		if(!$aMonthList){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		if($aUserInfo['vip'] >= 2 && $aUserInfo['vip_expiration_time'] > time()){
			assign('isVip', 1);
		}else{
			assign('isVip', 0);
		}

		assign('aMonthList', $aMonthList);
		assign('matchWinPrizeCount', $matchWinPrizeCount);
		assign('matchCount', $matchCount);
		assign('aUserPkStat', $aUserPkStat[0]);
		assign('aMedalList', $aMedalList);
		assign('aMonthStats', $aMonthStats);
		assign('aUserInfo', $aUserInfo);
		assign('aAllMissionStatistics', $aAllMissionStatistics);
		displayHeader('我的战绩');
		assign('isLink', 1);
		assign('userId', $userId);
		display('grade/index.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	public function getUserMonthGradeList(){
		$userId = intval(post('userId'));
		$year = intval(post('year'));
		$month = intval(post('month'));
		$aUser = getUserInfo($userId);
		if(!$aUser || $year > 2100 || $year < 2012 || $month > 12 || $month < 1){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMission = m('Mission');
		$aMonthMissionStatistics = $oMission->getUserMonthStatistics($userId, $year, $month);
		if(!$aMonthMissionStatistics){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['subject_count'][1]['percent'] = $aMonthMissionStatistics['es_count'] ? intval(($aMonthMissionStatistics['subject_count'][1]['es_count'] / $aMonthMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][2]['percent'] = $aMonthMissionStatistics['es_count'] ? intval(($aMonthMissionStatistics['subject_count'][2]['es_count'] / $aMonthMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][3]['percent'] = $aMonthMissionStatistics['es_count'] ? intval(($aMonthMissionStatistics['subject_count'][3]['es_count'] / $aMonthMissionStatistics['es_count']) * 10000) / 100 : '00.00';

		$aMonthMissionStatistics['subject_count'][1]['mission_rate'] = $aMonthMissionStatistics['pass_mission_count'] ? intval(($aMonthMissionStatistics['subject_count'][1]['pass_mission_count'] / $aMonthMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][2]['mission_rate'] = $aMonthMissionStatistics['pass_mission_count'] ? intval(($aMonthMissionStatistics['subject_count'][2]['pass_mission_count'] / $aMonthMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][3]['mission_rate'] = $aMonthMissionStatistics['pass_mission_count'] ? intval(($aMonthMissionStatistics['subject_count'][3]['pass_mission_count'] / $aMonthMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';

		if(!$aMonthMissionStatistics['pass_mission_count']){
			$aMonthMissionStatistics['subject_count'][4]['es_count'] = 1;
			$aMonthMissionStatistics['subject_count'][4]['pass_mission_count'] = 1;
		}
		$oPk = m('Pk');
		$startTime = $month < 10 ? strtotime($year . '-0' . $month) : strtotime($year . '-' . $month);
		if($month == 12){
			$endTime = strtotime(($year + 1) . '-01');
		}else{
			$endTime = ($month + 1) < 10 ? strtotime($year . '-0' . ($month + 1)) : strtotime($year . '-' . ($month + 1));
		}
		$aPkStats = $oPk->getUserPkCountListByUserIds(array($userId), $startTime, $endTime);
		if($aPkStats === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['aMonthPkStats'] = $aPkStats[0];
		$oMatch = m('Match');
		$matchCount = $oMatch->getUserRegisterMatchCount($userId, $startTime, $endTime);
		if($matchCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['matchCount'] = $matchCount;
		$winPrizeCount = $oMatch->getUserWinPrizeCount($userId, $startTime, $endTime);
		if($winPrizeCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['winPrizeCount'] = $winPrizeCount;
		for($i = 1; $i <= 3; $i++){
			if($aMonthMissionStatistics['subject_count'][$i]['pass_mission_list']){
				foreach($aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'] as $key => $value){
					$aTempStatics = $oPk->getUserMissionPkStatistics($userId, $value['mission_id']);
					$pkWinRate = $aTempStatics['pk_count'] ? intval(($aTempStatics['win_count'] / $aTempStatics['pk_count']) * 10000) / 100 : 0.00;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['pk_win_rate'] = $pkWinRate;
					$defeatPercent = $oMission->getDefeatedPercent($value['mission_id'], $value['score']);
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['defeat_percent'] = $defeatPercent;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['pk_count'] = $aTempStatics['pk_count'];
					$esCountCommentStr = '';
					$missionScoreCommentStr = '';
					$pkWinRateCommentStr = '';
					$esCount = $aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['es_count'];
					$score = $aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['score'] / 100;
					if($esCount > 40){
						$esCountCommentStr = '好勤奋哟！去和其他小伙 <a href="javascript:;" onclick="showSendPk();">PK</a> 吧！';
						if($score < 80){
							$missionScoreCommentStr = '<a href="' . url('m=Mission&a=showMissionChallenge&id=' . $value['mission_id'], '', APP_HOME) . '">去继续修炼此关卡 ！</a>';
						}else{
							if($pkWinRate < 60){
								$pkWinRateCommentStr = '<a href="' . url('m=Mission&a=showMissionChallenge&id=' . $value['mission_id'], '', APP_HOME) . '">去继续修炼此关卡 ！</a>';
							}
						}
					}else{
						$esCountCommentStr = '<a href="' . url('m=Mission&a=showMissionChallenge&id=' . $value['mission_id'], '', APP_HOME) . '">去继续修炼此关卡 ！</a>';
						if($score > 80){
							$missionScoreCommentStr = '去和其他小伙 <a href="javascript:;" onclick="showSendPk();">PK</a> 吧！';
						}else{
							if($pkWinRate >= 60 && $pkWinRate < 80){
								$pkWinRateCommentStr = '去和其他小伙 <a href="javascript:;" onclick="showSendPk();">PK</a> 吧！';
							}
						}
					}

					if($pkWinRate >= 80){
						$pkWinRateCommentStr = 'PK之王当之无愧！';
					}
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['esCountCommentStr'] = $esCountCommentStr;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['missionScoreCommentStr'] = $missionScoreCommentStr;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['pkWinRateCommentStr'] = $pkWinRateCommentStr;
				}
			}
		}

		alert('月战绩！', 1, $aMonthMissionStatistics);
	}


	/**
	 *历史关卡
	 */
	public function getHistoryMissionList(){
		$subjectId = intval(post('subjectId', 1));
		$page = intval(post('page', 1));
		$orderType = intval(post('orderType', 1));

		$orderBy = ' score DESC ';

		if(!isset($GLOBALS['SUBJECT'][$subjectId])){
			alert('数据错误', 0);
		}

		if($page <1 ){
			$page = 1;
		}

		if($orderType <1 ){
			$orderType = 1;
		}

		if($orderType > 2 ){
			$orderType = 2;
		}

		if($orderType  ==  2 ){
			$orderBy = ' id ';
		}

		$oMission = new MissionModel();
		$aMissionList = array();
		$aMissionCount = 0;
		$pageSize = 10;
		$pageCount = 1;


		$returnArray = array(
			'count' 	=> 0,
			'data' 		=> '',
			'pageHtml' 	=> '',
			'pageSize' 	=>	$pageSize
		);

		$aMissionCount = $oMission->getHistoryMissionCount($this->_userId, $subjectId);
		if($aMissionCount === false){
			alert('数据错误', 0);
		}

		$returnArray['count'] = $aMissionCount;

		if($aMissionCount > 0){
			$pageCount = ceil($aMissionCount / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}

			$aMissionList = $oMission->getHistoryMissionList($this->_userId, $subjectId, $page, $pageSize, $orderBy);
			if($aMissionList === false){
				alert('数据错误', 0);
			}else{
				$returnArray['data'] = $aMissionList;
			}

			$aPageInfo = array(
				'url' => url('m=Grade&a=getHistoryMissionList'),
				'onclick'	=>	"getHistoryMissionList(".$subjectId.",_PAGE_,".$orderType.")",
				'total' => $aMissionCount,
				'size' => $pageSize,
				'page' => $page,
			);
			$pageHtml = page($aPageInfo);
			if($pageHtml){
				$returnArray['pageHtml'] = $pageHtml;
			}
		}

		alert('', 1, $returnArray);

	}


	//好友排名
	private  function _getFriendList(){
		$aFriendIds = '';
		$aFriendIdArray = array();
		$aFriendList = array();

		$oMission = new MissionModel();
		$oSns = new SnsModel();
		$aFriendIds = $oSns->getUserFriendIds($this->_userId);

		if($aFriendIds === false){
			return false;
		}


		$aFriendIds .= ',' . $this->_userId;
		$aFriendIdArray = explode(',', $aFriendIds);

		$aFriendIdArray = array_filter($aFriendIdArray);
		$oUserNumberical = new UserNumericalModel();
		$aFriendList = $oUserNumberical -> getTopAccumulatePointsUserListByUserIds($aFriendIdArray);
		return $aFriendList;

	}



	/**
	 *根据个人战绩发表一条说说
	 */
	public function tellMyFriends(){

		$nextMissionShare =  Xxtea::xcrypt('nextMissionShare');
		//验证发送验证码时间超过一个小时没
		if(Cookie::isSetted($nextMissionShare)){
			$nextShareTime = Cookie::getDecrypt($nextMissionShare);
			if(time() < $nextShareTime){
				alert('请稍后再试', 0);
			}
		}

		$aParam = array();
		$aParam['user_id'] = $this->_userId;
		$aParam['content'] = trim(post('content'));

		$aParam['create_time'] = time();
		$aParam['current_date'] = date('Ymd', time());

		$aParam['content'] = str_replace('[[[a', '<a', $aParam['content']);
		$aParam['content'] = str_replace('[[[/a]]]', '</a>', $aParam['content']);
		$aParam['content'] = str_replace(']]]', '>', $aParam['content']);

		$oSns = m('Sns');
		$result = $oSns->addSnsShuoshuo($aParam);
		if($result){
			//下次发送时间　3600秒以后
			Cookie::setEncrypt($nextMissionShare , time()+3600);
			alert('分享成功', 1);
		}else{
			alert('分享失败', 0);
		}
	}

	/*
	 * 排行榜
	 */
	public function showRankingList(){
		$length = 10;
		//我的好友ID
		$aFriendUserIds = getUserFriendIds($this->_userId);

		$oUserNumerical = m('UserNumerical');
		//等级排行榜
		$aLevelRankingList = $oUserNumerical->getUserNumericalRankingList(1, $length, array(), $order = '`accumulate_points` desc');
		if($aLevelRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aLevelRankingList as $key => $aLevelRanking){
			$aLevelRankingList[$key]['level'] = Numerical::updateUserLevel($aLevelRanking['accumulate_points']);
			$aLevelRankingList[$key]['ranking'] = $key + 1;
			$aLevelRankingList[$key]['is_friend'] = 0;
			if(in_array($aLevelRanking['id'], $aFriendUserIds)){
				$aLevelRankingList[$key]['is_friend'] = 1;
			}
		}
		assign('aLevelRankingList', $aLevelRankingList);

		//金币排行榜
		$aGoldRankingList = $oUserNumerical->getUserNumericalRankingList(1, $length, array(), $order = '`gold` desc');
		if($aGoldRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aGoldRankingList as $key => $aGoldRanking){
			$aGoldRankingList[$key]['ranking'] = $key + 1;
			$aGoldRankingList[$key]['is_friend'] = 0;
			if(in_array($aGoldRanking['id'], $aFriendUserIds)){
				$aGoldRankingList[$key]['is_friend'] = 1;
			}
		}
		assign('aGoldRankingList', $aGoldRankingList);

		//签到榜
		$oUserBehavior = m('UserBehavior');
		$aMarkRankingList = $oUserBehavior->getMarkRankingList(1, $length);
		if($aMarkRankingList === false){
			alert('数据错误', 0);
		}
		$aUserIds = array();
		foreach($aMarkRankingList as $aMarkRanking){
			$aUserIds[] = $aMarkRanking['id'];
		}
		if($aUserIds){
			$aUserList = getUserListByUserIds($aUserIds);
			if($aUserList === false){
				alert('数据错误', 0);
			}
			foreach($aMarkRankingList as $key => $aMarkRanking){
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aMarkRanking['id']){
						$aMarkRankingList[$key]['name'] = $aUser['name'];
						$aMarkRankingList[$key]['profile'] = $aUser['profile'];
						break;
					}
				}
				$aMarkRankingList[$key]['ranking'] = $key + 1;
				$aMarkRankingList[$key]['is_friend'] = 0;
				if(in_array($aMarkRanking['id'], $aFriendUserIds)){
					$aMarkRankingList[$key]['is_friend'] = 1;
				}
			}
		}
		assign('aMarkRankingList', $aMarkRankingList);

		//本周闯关榜
		$oMission = m('Mission');
		$monDay = strtotime(date('Y-m-d', time() - ((date('w') == 0 ? 7 : date('w')) - 1) * 86400));
		$aPassMissionRankingList = $oMission->getPassMissionCountRankingList(1, $length, 0, $monDay, time());
		if($aPassMissionRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aPassMissionRankingList as $key => $aPassMissionRanking){
			$aPassMissionRankingList[$key]['ranking'] = $key + 1;
			$aPassMissionRankingList[$key]['is_friend'] = 0;
			if(in_array($aPassMissionRanking['id'], $aFriendUserIds)){
				$aPassMissionRankingList[$key]['is_friend'] = 1;
			}
		}
		assign('aPassMissionRankingList', $aPassMissionRankingList);

		//奖牌榜
		$aAllMedalRankingList = $oUserNumerical->getUserMedalRankingListForMatch(1, $length);
		if($aAllMedalRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aAllMedalRankingList as $key => $aAllMedalRanking){
			$aAllMedalRankingList[$key]['ranking'] = $key + 1;
			$aAllMedalRankingList[$key]['is_friend'] = 0;
			if(in_array($aAllMedalRanking['id'], $aFriendUserIds)){
				$aAllMedalRankingList[$key]['is_friend'] = 1;
			}
		}
		assign('aAllMedalRankingList', $aAllMedalRankingList);

		$oNum = new Numerical();
		//PK勋章榜
		$aPkMedalRankingList = $oUserNumerical->getMedalRankingList('pk_win_times', $GLOBALS['PK_WIN_MEDAL'][1]['nums'], 1, $length);
		if($aPkMedalRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aPkMedalRankingList as $key => $aPkMedalRanking){
			$aPkMedalRankingList[$key]['ranking'] = $key + 1;
			$aPkMedalRankingList[$key]['is_friend'] = 0;
			if(in_array($aPkMedalRanking['id'], $aFriendUserIds)){
				$aPkMedalRankingList[$key]['is_friend'] = 1;
			}
			$aPkMedalRankingList[$key]['level'] = $oNum->countLevel(6, $aPkMedalRanking['accumulate_points']);
			$aPkMedalRankingList[$key]['title'] = $GLOBALS['PK_WIN_MEDAL'][$aPkMedalRankingList[$key]['level']]['name'];
		}
		assign('aPkMedalRankingList', $aPkMedalRankingList);

		//闯关勋章榜
		$aPassMissionMedalRankingList = $oUserNumerical->getMedalRankingList('passed_missions', $GLOBALS['PASSED_MISSIONS_MEDAL'][1]['nums'], 1, $length);
		if($aPassMissionMedalRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aPassMissionMedalRankingList as $key => $aPassMissionMedalRanking){
			$aPassMissionMedalRankingList[$key]['ranking'] = $key + 1;
			$aPassMissionMedalRankingList[$key]['is_friend'] = 0;
			if(in_array($aPassMissionMedalRanking['id'], $aFriendUserIds)){
				$aPassMissionMedalRankingList[$key]['is_friend'] = 1;
			}
			$aPassMissionMedalRankingList[$key]['level'] = $oNum->countLevel(2, $aPassMissionMedalRanking['accumulate_points']);
		}
		assign('aPassMissionMedalRankingList', $aPassMissionMedalRankingList);


		//闯关奖章榜
		$aExcellentMissionMedalRankingList = $oUserNumerical->getMedalRankingList('excellent_missions', $GLOBALS['EXCELLENT_MISSIONS_MEDAL'][1]['nums'], 1, $length);
		if($aExcellentMissionMedalRankingList === false){
			alert('数据错误', 0);
		}
		foreach($aExcellentMissionMedalRankingList as $key => $aExcellentMissionMedalRanking){
			$aExcellentMissionMedalRankingList[$key]['ranking'] = $key + 1;
			$aExcellentMissionMedalRankingList[$key]['is_friend'] = 0;
			if(in_array($aExcellentMissionMedalRanking['id'], $aFriendUserIds)){
				$aExcellentMissionMedalRankingList[$key]['is_friend'] = 1;
			}
			$aExcellentMissionMedalRankingList[$key]['level'] = $oNum->countLevel(3, $aExcellentMissionMedalRanking['accumulate_points']);
		}
		assign('userId', $this->_userId);
		assign('aExcellentMissionMedalRankingList', $aExcellentMissionMedalRankingList);
		displayHeader('排行榜');
		display('grade/ranking.html.php');
		displayFooter();
	}
}