<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-8-12
 * Time: 下午3:22
 * To change this template use File | Settings | File Templates.
 */
class FriendController{
	private $_userId = '';

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	private $_STATU_TASK_FINISH = 1;		//完成新手任务了
	private $_DIRECT_INVITER_RECEIVED = 2;	//直接推荐人已领取，间接推荐人未领取
	private $_INDIRECT_INVITER_RECEIVED = 3;//直接推荐人未领取，间接推荐人已领取
	private $_ALL_INVITER_RECEIVED = 4;		//直接推荐、间接推荐人都已领取
	
	private $_NEW_TASE_PROCESS_COUNT = 5; 	//新手任务总共有多少步 
	
	
	//好友首页
	public function showFriend(){
		$frendId = intval(get('userId'));
		if($frendId > 0){
			$this->_showFriendListByFriendId($frendId);
		}else{
			alert('参数错误');
		}
	}
	
	/**
	 *查找好友
	 */
	public function showSearchFriend(){
		$searchName = post('searchName', '');
		$searchType = intval(post('type', 0));
		if($searchType == 1){
			if(!preg_match('/^[\x{4e00}-\x{9fa5}]{2,6}$/u', $searchName)){
				alert('姓名为两到六个中文字', 0);
			}
		}
		
		$oSns = m('Sns');
		$applyToMe = $oSns->getApplyFriendCount($this->_userId);
		$aUser = getUserInfo($this->_userId, array('personal'));
		if($applyToMe || $aUser['new_friend_flag']){
			$newFriend = true;
		}else{
			$newFriend = false;
		}
		assign('newFriend', $newFriend);
		displayHeader('查找好友');
		assign('userId', $this->_userId);
		assign('type',1);
		assign('searchType', $searchType);
		assign('searchName', $searchName);
		
		displayLeftNav($this->_userId);
		display('friend/search.html.php');
		displayFooter();
	}
	
	/**
	 *可能认识的人
	 */
	public function getProablyFriend(){
		$num = intval(post('num'));
		if(!$num){
			alert('参数错误', -1);
		}
		$oSns = m('Sns');
		$oSns->cheakProbablyFriends($this->_userId);
		$aProbalyFriendList = $oSns->getUserRandProbablyList($this->_userId, $num, array('personal', 'area'));
		if($aProbalyFriendList){
			$aProbalyFriendList = $this->_setFriendStatus($aProbalyFriendList);
		}
		alert('good', 1, $aProbalyFriendList);
	}
	
	/**
	 *分页查找可能认识的人
	 */
	public function getProablyFriendByPage(){
		$page = intval(post('page'));
		if(!$page){
			$page = 1;
		}
		
		$oSns = m('Sns');
		$offset = ($page - 1) * 15;
		$aProbalyFriendList = $oSns->getUserProbalyFriendList($this->_userId, $offset, 15);
		if($aProbalyFriendList){
			$aProbalyFriendList = $this->_setFriendStatus($aProbalyFriendList);
		}
		alert('good', 1, $aProbalyFriendList);
	}
	
	/*
	public static function displayNav($type, $newFriend){
		assign('type', $type);
		assign('newFriend', $newFriend);
		display('friend/nav.html.php');
	}
	*/

	/**
	 *查找好友
	 */
	public function searchFriend(){
		$type = intval(post('type'));
		if(!in_array($type, array(1, 2, 3))){
			alert('参数出错', -1);
		}
		
		$oUser = m('User');
		if($type == 1){
			$name = post('name');
			if(!preg_match('/^[\x{4e00}-\x{9fa5}]{2,6}$/u', $name)){
				alert('姓名为两到六个中文字', 0);
			}
			$aResult['list'] = $oUser->getUserListBySearchName($name, 1, 20);
			$aResult['count'] = $oUser->getUserCountBySearchName($name);
		}elseif($type == 2){
			$email = post('email');
			$isEmail = 1;
			if(!preg_match('/\w@\w*\.\w/', $email)){
				if(!preg_match('/^\d{8}$/', $email)){
					alert('输入完整的Email或8位数的UF帐号', -1);
				}
				$isEmail = 0;
			}
			$aUser = $oUser->getUserInfoBySearchAccount($email, $isEmail);
			
			if($aUser){
				$aResult = array(
					'list' => array($aUser),
					'count' => 1,
				);
			}else{
				$aResult = array();
				$aResult = array(
					'list' => array(),
					'count' => 0,
				);
			}
		}elseif($type == 3){
			$sex = intval(post('sex'));
			$age = intval(post('age'));
			$province = intval(post('province'));
			$city = intval(post('city'));
			$area = intval(post('area'));
			$school = intval(post('school'));
			$page = intval(post('page'));
			//alert($school, -1);
			if(!$page){
				$page = 1;
			}
			if($sex && $sex != 1 && $sex != 2){
				alert('请选择性别', -1);
			}
			if(!$age){
				$aAge = array();
			}elseif($age == 1){
				$aAge = array(0, 10);
			}elseif($age == 2){
				$aAge = array(10, 12);
			}elseif($age == 3){
				$aAge = array(12, 15);
			}elseif($age == 4){
				$aAge = array(15);
			}else{
				alert('请选择年龄范围', -1);
			}
			if($area){
				$areaId = $area;
			}elseif($city){
				$areaId = $city;
			}elseif($province){
				$areaId = $province;
			}else{
				$areaId = 0;
			}
			$aCondition = array(
				'gender' => $sex,
				'area'	=> $areaId,
				'school_id' => $school,
				'age' => $aAge,
			);
			$aResult['list'] = $oUser->getUserListBySearch($aCondition, $page, 15);
			$aResult['count'] = $oUser->getUserCountBySearch($aCondition);
		}
		if($aResult['list']){
			$aResult['list'] = $this->_setFriendStatus($aResult['list']);
		}
		alert('good', 1, $aResult);
	}
	
	
	
	private function _setFriendStatus($aData){
		//取当前所有好友ID
		$aMyFriendIds = getUserFriendIds($this->_userId);
		if($aMyFriendIds === false){
			return false;
		}
		$oSns = m('Sns');
		foreach($aData as $key=>$aUserInfo){
			$aData[$key]['is_friend'] = 0; //---可加好友
			if(in_array($aUserInfo['id'], $aMyFriendIds)){
				$aData[$key]['is_friend'] = 1;	//--己是好友
			}else if($aUserInfo['id'] == $this->_userId){
				$aData[$key]['is_friend'] = 3;	//--自己
			}else{
				//是否己经发送加好友请求
				$aMasterInfo = $oSns->getUserRelationInfo('`user_master_id` = ' . $this->_userId . ' AND `user_slave_id` = ' . $aUserInfo['id']);
				if($aMasterInfo === false){
					return false;
				}
				if($aMasterInfo){
					$aData[$key]['is_friend'] = 2;	//--已发送好友请求
				}
			}
		}
		return $aData;
	}
	
	
	/**
	 *可能认识的人页面
	 */
	public function showProablyFriend(){
		$oSns = m('Sns');
		$applyToMe = $oSns->getApplyFriendCount($this->_userId);
		$aUser = getUserInfo($this->_userId, array('personal'));
		if($applyToMe || $aUser['new_friend_flag']){
			$newFriend = true;
		}else{
			$newFriend = false;
		}
		assign('type',3);
		assign('newFriend', $newFriend);
		displayHeader('可能认识的人');
		assign('userId', $this->_userId);
		displayLeftNav($this->_userId);
		display('friend/probably.html.php');
		displayFooter();
	}
	
	/**
	 *好友推荐中心页面
	 */
	public function showRecommendFriend(){
		//我推荐的人-末领取奖励
		$aRecommendListAndCount = $this->_getRecommendList();
		//我推荐的人-己领取奖励
		$aHasRecommendListAndCount = $this->_getRecommendList(true);
		if($aRecommendListAndCount === false || $aHasRecommendListAndCount === false){
			alert('系统错误', 0);
		}
		
		$aRecommendList = array();
		$recommendPageHtml = '';
		
		$aHasRecommendList = array();
		$hasRecommendPageHtml = '';
		
		if($aRecommendListAndCount){
			$aRecommendList = $aRecommendListAndCount['data'];
			$recommendPageHtml = $aRecommendListAndCount['pageHtml'];
		}
		
		if($aHasRecommendListAndCount){
			$aHasRecommendList = $aHasRecommendListAndCount['data'];
			$hasRecommendPageHtml = $aHasRecommendListAndCount['pageHtml'];
		}
		
		//推荐好友排行
		$oInvitation = m('UserInvitation');
		$aRecommendFriendList = $oInvitation->getInvitationUserRankList();
		$aUserInvitationInfo = $oInvitation->getInvitationInfoByUserId($this->_userId);
		
		assign('aRecommendList', $aRecommendList);
		assign('recommendPageHtml', $recommendPageHtml);
		
		assign('aHasRecommendList', $aHasRecommendList);
		assign('hasRecommendPageHtml', $hasRecommendPageHtml);
		
		assign('aRecommendFriendList', $aRecommendFriendList);
		assign('aUserInvitationInfo', $aUserInvitationInfo);
		assign('userId', $this->_userId);
		$aUser = getUserInfo($this->_userId, array('personal', 'numerical'));
		assign('aUser', $aUser);
		assign('type',4);
		displayHeader('好友推荐中心');
		assign('userId', $this->_userId);
		displayLeftNav($this->_userId);
		display('friend/recommend.html.php');
		displayFooter();
	}
	
	
	/**
	 *好友请求页面
	 */
	public function showFriendApply(){
		$oSns = m('Sns');
		$applyToMe = $oSns->getApplyFriendCount($this->_userId);
		$aUser = getUserInfo($this->_userId, array('personal'));
		if($applyToMe || $aUser['new_friend_flag']){
			$newFriend = true;
		}else{
			$newFriend = false;
		}
		assign('type',5);
		assign('applyToMe', $applyToMe);
		assign('agreeMeFriend', $aUser['new_friend_flag']);
		assign('newFriend', $newFriend);
		displayHeader('好友管理');
		assign('userId', $this->_userId);
		displayLeftNav($this->_userId);
		display('friend/apply.html.php');
		displayFooter();
	}
	
	/**
	 *同意加好友
	 */
	public function agreeFriend(){
		$userId = intval(post('userId'));
		$groupId = intval(post('groupId'));
		$oSns = m('Sns');
		$aSlaveInfo = $oSns->getUserRelationInfo('`user_master_id` = ' . $userId . ' AND `user_slave_id` = ' . $this->_userId);
		if(!$aSlaveInfo){
			alert('好友请求不存在', -1);
		}
		//自己好友数组
		$aFriendId = getUserFriendIds($this->_userId);
		//被添加者好友
		$aUserSlave = getUserFriendIds($userId);
		//被添加者的好友数量
		if (count($aUserSlave) > USER_FRIENDS_LIMIT) {
			$oSns->ignoreFriendApply($aSlaveInfo[0]['id']);
			alert('抱歉，该用户的好友数已经达到上限，添加好友失败', -1);
		}
		//自己好友数量
		if (count($aFriendId) > USER_FRIENDS_LIMIT) {
			$oSns->ignoreFriendApply($aSlaveInfo[0]['id']);
			alert('抱歉，您的好友数已经达到上限，添加好友失败', -1);
		}
		$aGroupIds = $oSns->getUserGroupIds($this->_userId);
		if(!in_array($groupId, $aGroupIds)){
			alert('分组不存在', -1);
		}
		$result = $oSns->agreeFriendApply($this->_userId, $userId, $groupId);
		if($result){
			alert('添加好友成功，你又多一名小伙伴啦', 1);
		}else{
			alert('网络可能有点慢，请稍后再试', 0);
		}
	}
	
	/**
	 *忽略好友请求
	 */
	public function ignoreFriend(){
		$userId = intval(post('userId'));
		$oSns = m('Sns');
		$aSlaveInfo = $oSns->getUserRelationInfo('`user_master_id` = ' . $userId . ' AND `user_slave_id` = ' . $this->_userId);
		if(!$aSlaveInfo){
			alert('好友请求不存在', -1);
		}
		//过滤存在盲打漏洞
		$result = $oSns->ignoreFriendApply($aSlaveInfo[0]['id']);
		if($result){
			alert('good', 1);
		}else{
			alert('网络可能有点慢，请稍后再试', 0);
		}
	}
	
	/**
	 *获取好友请求
	 */
	public function getApplyToMeFriend(){
		$page = intval(post('page'));
		if(!$page){
			$page = 1;
		}
		$oSns = m('Sns');
		$aApplyFriendList = $oSns->getApplyFriendList($this->_userId, $page, 8);
		$aGroupList = $oSns->getUserGroupList($this->_userId);
		$aResult = array(
			'list' => $aApplyFriendList,
			'group' => $aGroupList
		);
		alert('hehe', 1, $aResult);
	}
	
	/**
	 *同意添加的好友
	 */
	public function getAgreeFriend(){
		$page = intval(post('page'));
		if(!$page){
			$page = 1;
		}
		$oSns = m('Sns');
		$aApplyFriendList = $oSns->getAgreeUserApplyFriendList($this->_userId, $page, 8);
		$aGroupList = $oSns->getUserGroupList($this->_userId);
		$aResult = array(
			'list' => $aApplyFriendList,
			'group' => $aGroupList
		);
		$oUser = m('User');
		$aData = array(
			'id' => $this->_userId,
			'new_friend_flag' => 0
		);
		$oUser->setUserInfo($aData);
		//debug($aResult, 11);
		alert('hehe', 1, $aResult);
	}


	//好友管理
	public function manage(){
		$oSns = m('Sns');
		$applyToMe = $oSns->getApplyFriendCount($this->_userId);
		$aUser = getUserInfo($this->_userId, array('personal'));
		if($applyToMe || $aUser['new_friend_flag']){
			$newFriend = true;
		}else{
			$newFriend = false;
		}
		assign('newFriend', $newFriend);
		$aGroupList = $oSns->getUserGroupList($this->_userId);
		$countFriends = 0;
		foreach($aGroupList as $key => $aGroup){
			$countFriends += $aGroup['nums'];
		}
		$aAllFriend = array(
			'id' => 0,
			'group_name' => '全部好友',
			'nums' => $countFriends,
		);
		assign('aAllFriend', $aAllFriend);
		assign('aGroupList', $aGroupList);
		assign('type',2);
		displayHeader('好友管理');
		assign('userId', $this->_userId);
		displayLeftNav($this->_userId);
		display('friend/manage.html.php');
		displayFooter();
	}
	
	/*
	 *加载好友列表
	 */
	public function loadFriendList(){
		$groupId = intval(post('groupId'));
		$page = intval(post('page'));
		if(!$page){
			$page = 1;
		}
		$oSns = m('Sns');
		$aFriendList = $oSns->getUserFriendList($this->_userId, $page, 10, $groupId);
		$aGroupList = $oSns->getUserGroupList($this->_userId);
		$aResult = array(
			'list' => $aFriendList,
			'group_list' => $aGroupList,
		);
		alert('good', 1, $aResult);
	}



	//删除好友
	public function delete(){
		if(limitCheck('DELETE_FRIEND')){
			limitAdd('DELETE_FRIEND');
		}
		$friendId = intval(post('friendId'));
		if(!$friendId){
			alert('参数错误', -1);
		}
		//取当前用户所有好友
		$aFriendId = getUserFriendIds($this->_userId);
		if(!in_array($friendId, $aFriendId)){
			alert('此用户不是你的好友哦', -1);
		}
		$oSns = m('Sns');
		$isDelete = $oSns->deleteFriend($this->_userId, $friendId);
		$aResult = array(
			'blongGrouId' => intval(post('blongGrouId')),
			'deleteId' => post('deleteId'),
		);
		if($isDelete){
			alert('好友已删除', 1, $aResult);
		}else{
			alert('删除失败，请重新操作', 0);
		}
	}


	//申请加为好友
	public function apply(){
		$verifyTextInfo = post('verify_text_info');
		$isLength = w('length(0, 50)', $verifyTextInfo);
		if(!$isLength){
			alert('验证信息不能超过50个字符', -1);
		}
		
		$userSlaveId = intval(post('user_id'));
		if(!$userSlaveId){
			alert('参数错误', -1);
		}
		if($this->_userId == $userSlaveId){
			alert('不能加自己为好友', -1);
		}
		
		//查询是否己经是好友关系
		$aFriendId = getUserFriendIds($this->_userId);
		//被添加者好友
		$aUserSlave = getUserFriendIds($userSlaveId);
		if (in_array($userSlaveId, $aFriendId)) {
			alert('该用户已经是你的好友', -1);
		}
		//被添加者的好友数量
		if (count($aUserSlave) > USER_FRIENDS_LIMIT) {
			alert('抱歉，该用户的好友数已经达到上限，添加好友失败', -1);
		}
		//自己好友数量
		if (count($aFriendId) > USER_FRIENDS_LIMIT) {
			alert('抱歉，您的好友数已经达到上限，添加好友失败', -1);
		}

		$oSns = m('Sns');
		//查询是否己经发送 "他加我" 请求
		$aSlaveInfo = $oSns->getUserRelationInfo('`user_master_id` = ' . $userSlaveId . ' AND `user_slave_id` = ' . $this->_userId);
		if($aSlaveInfo){
			//如果己经存在　"他加我" 记录，则互加为好友
			$result = $oSns->agreeFriendApply($this->_userId, $userSlaveId);
			if($result){
				alert('添加好友成功，你又多一名小伙伴啦', 2);
			}else{
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}else{
			limitCheck('APPLY_FRIEND');
			$aData = array(
				'user_master_id' => $this->_userId,
				'user_slave_id' => $userSlaveId,
				'create_time' => time(),
				'confirm_message' => $verifyTextInfo
			);
			$isApplySuccess = $oSns->applyFriend($aData);
			if($isApplySuccess){
				//限制与经验
				limitAdd('APPLY_FRIEND');
				$limit = limitCheck('FRIEND_ACCUMULATE');
				if($limit){
					$oGame = new Game();
					if(!$oGame->afterAddFriend($this->_userId)){
						alert('程序执行错误，请稍后重试', 0);
					}
					limitAdd('FRIEND_ACCUMULATE');
				}
				alert('好友申请信息已发送成功！', 1);
			}else{
				alert('申请好友失败，请重新操作', 0);
			}
		}
	}
	
	/*
	 *群加好友
	 **/
	public function batchApply(){
		$aFriendList = post('friendList');
		if(!is_array($aFriendList)){
			alert('参数错误', -1);
		}
		
		//查询是否己经是好友关系
		$aFriendId = getUserFriendIds($this->_userId);
		//自己好友数量
		if (count($aFriendId) > USER_FRIENDS_LIMIT) {
			alert('抱歉，您的好友数已经达到上限，添加好友失败', -1);
		}
		$now = time();
		$oSns = m('Sns');
		foreach($aFriendList as $id){
			//非法数据类型 添加自己 已经是好友continue
			if (!is_numeric($id) || ($id == $this->_userId) || in_array($id, $aFriendId)) {
				continue;
			}
			$aUserSlave = getUserFriendIds($id);
			//被添加者的好友数量超过限制数量则跳出不发申请
			if (count($aUserSlave) > USER_FRIENDS_LIMIT) {
				continue;
			}
			$aData = array(
				'user_master_id' => $this->_userId,
				'user_slave_id' => $id,
				'create_time' => $now,
				'confirm_message' => ''
			);
			$isApplySuccess = $oSns->applyFriend($aData);
			if(!$isApplySuccess){
				alert('申请好友失败，请重新操作', 0);
			}else{
				//限制与经验
				limitAdd('APPLY_FRIEND');
				$limit = limitCheck('FRIEND_ACCUMULATE');
				if($limit){
					$oGame = new Game();
					if(!$oGame->afterAddFriend($this->_userId)){
						alert('程序执行错误，请稍后重试', 0);
					}
					limitAdd('FRIEND_ACCUMULATE');
				}
			}
		}
		alert('好友请求发送成功', 1);
	}

	/*
	 *添加分组
	 **/
	public function addGroup(){
		if(limitCheck('SNS')){
			limitAdd('SNS');
		}
		$groupName = post('groupName');
		if(!$groupName){
			alert('分组名不能为空', -1);
		}
		if(!preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]+$/u', $groupName)){
			alert('分组名应该是中英文或数字', -1);
		}

		$groupNameLen = 0;
		for($i = 0; $i < strlen($groupName); $i++){
			if(ord(substr($groupName, $i, 1)) > 127){
				$i += 2;
				$groupNameLen += 2;
			}else{
				$groupNameLen ++;
			}
			if($groupNameLen > 12){
				alert('分组名应该在十二个字符长度内，一个中文为两个字符长度', -1);
			}
		}

		$oSns = m('Sns');
		$aGroupArray = $oSns->getUserGroupList($this->_userId);
		if($aGroupArray){
			if(count($aGroupArray) > 10){
				alert('你的分组己经够多了', -1);
			}
			foreach($aGroupArray as $aGroupInfo){
				if($aGroupInfo['group_name'] == $groupName){
					alert('这个分组己经存在了哦，换个分组名试试吧', -1);
				}
			}
		}
		$groupId = $oSns->addFriendGroup($this->_userId, $groupName);
		if($groupId){
			$aNewGroup = array(
				'id' => $groupId,
				'group_name' => $groupName,
				'nums' => 0,
			);
			alert('添加分组成功', 1, $aNewGroup);
		}else{
			alert('添加分组失败，请重新操作', 0);
		}
	}

	//编辑分组
	public function editGroup(){
		$groupId = intval(post('id'));
		$groupName = post('newGroupName');

		if(!$groupId || $groupId == 0 || $groupId == -1){
			alert('数据错误', -1);
		}

		if(!$groupName){
			alert('分组名不能为空', -1);
		}
		if(!preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]+$/u', $groupName)){
			alert('分组名应该是中英文或数字', 0);
		}

		$groupNameLen = 0;
		for($i = 0; $i < strlen($groupName); $i++){
			if(ord(substr($groupName, $i, 1)) > 127){
				$i += 2;
				$groupNameLen += 2;
			}else{
				$groupNameLen ++;
			}
			if($groupNameLen > 12){
				alert('分组名应该在十二个字符长度内，一个中文为两个字符长度', 0);
			}
		}

		$oSns = m('Sns');
		$aGroupArray = $oSns->getUserGroupList($this->_userId);
		if(!$aGroupArray){
			alert('数据错误', -1);
		}

		foreach($aGroupArray as $aGroupInfo){
			if($aGroupInfo['group_name'] == $groupName && $groupId != $aGroupInfo['id']){
				alert('这个分组己经存在了哦，换个分组名试试吧', -1);
			}
		}

		$result = $oSns->editUserGroup($groupId, $groupName);
		if($result || $result == 0){
			alert('编辑分组成功', 1, array('group_name' => $groupName));
		}else{
			alert('编辑分组失败，请重新操作', 0);
		}
	}


	/*
	 *删除分组
	 */
	public function deleteGroup(){
		$groupId = intval(post('id'));
		if(!$groupId){
			alert('数据错误', 0);
		}
		$oSns = m('Sns');

		//查询分组是不是属于当前用户
		$isGroup = false;
		$aGroupList = $oSns->getUserGroupList($this->_userId);
		if(!$aGroupList){
			alert('分组不属于您', -1);
		}

		foreach ($aGroupList as $aGroupInfo){
			if($aGroupInfo['id'] == $groupId){
				$isGroup = true;
			}
		}
		if(!$isGroup){
			alert('分组不属于您', -1);
		}

		$result = $oSns->deleteFriendGroup($this->_userId, $groupId);
		if($result){
			alert('删除分组成功', 1);
		}else{
			alert('删除分组失败，请重新操作', 0);
		}
	}

	
	/*
	 *将好友移动到另外一个分组
	 */
	public function moveUserToGroup(){
		$friendId = intval(post('friendId'));
		$to = intval(post('to'));
		if(!$friendId || !$to){
			alert('参数错误', -1);
		}

		$aFriendIdList = getUserFriendIds($this->_userId);
		if(!in_array($friendId, $aFriendIdList)){
			alert('该用户不是您的好友', -1);
		}
		
		$oSns = m('Sns');
		$aGroupIds = $oSns->getUserGroupIds($this->_userId);
		if(!in_array($to, $aGroupIds)){
			alert('分组不存在', -1);
		}
		$result = $oSns->moveUserToGroup($this->_userId, $friendId, $to);
		if($result || $result == 0){
			alert('移动好友成功', 1);
		}else{
			alert('移动好友失败，请重新操作', 0);
		}
	}

	public function schoolInfo(){
		$oUser = m('User');
		$areaId = post('areaId');

		$aSchoolList = $oUser->getSchoolListByAreaId($areaId);
		if($aSchoolList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		alert('获取成功', 1, $aSchoolList);
	}

	public function myFriend(){
		$groupId = intval(post('groupId', 0));
		$oSns = m('Sns');
		$aFriendList = $oSns->getUserFriendList($this->_userId, $groupId);
		if($aFriendList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		exit(json_encode($aFriendList));
	}


	
	public function recommend(){
		//我推荐的人-末领取奖励
		$aRecommendList = $this->_getRecommendList();
	
		//我推荐的人-己领取奖励
		$aHasRecommendList = $this->_getRecommendList(true);
		
		if($aRecommendList === false || $aHasRecommendList === false){
			alert('系统错误', 0);
		}
		
		
		//推荐好友排行
		$oInvitation = m('UserInvitation');
		$aRecommendFriendList = $oInvitation->getInvitationUserRankList();
		if($aRecommendFriendList === false){
			alert('系统错误', 0);
		}
		$aUserInvitationInfo = $oInvitation->getInvitationInfoByUserId($this->_userId);
		if($aUserInvitationInfo === false){
			alert('系统错误', 0);
		}
		
		assign('aRecommendList', $aRecommendList);
		assign('aHasRecommendList', $aHasRecommendList);
		assign('aRecommendFriendList', $aRecommendFriendList);
		assign('aUserInvitationInfo', $aUserInvitationInfo);
		
		
		assign('userId', $this->_userId);
		displayHeader();
		assign('userId', $this->_userId);
		display('friend/recommend.html.php');
		displayFooter(true);
	}

	//领取奖励
	public function getRecommendUb(){
		$id = intval(post('id'));
		if($id < 1){
			alert('数据错误', 0);
		}
		
		$oInvitation = m('UserInvitation');
		
		//取被推荐者信息
		$aInvitationInfo = $oInvitation->getUserInvitationById($id);
		if($aInvitationInfo === false){
			alert('系统错误', 0);
		}
		if(!$aInvitationInfo){
			alert('记录不存在哦', 0);
		}
		//<1
		if($aInvitationInfo['invite_prize_status'] < $this->_STATU_TASK_FINISH){
			alert('此奖励还不能领取哦', 0);
		}
		//4
		if($aInvitationInfo['invite_prize_status'] == $this->_ALL_INVITER_RECEIVED){
			alert('奖励己经领取过了哦', 0);
		}
		
		//取推荐者信息
		$aFatherInfo = $oInvitation->getUserInvitationById($aInvitationInfo['invite_code']);
		if($aFatherInfo === false){
			alert('系统错误', 0);
		}		
		
		$ub = 0;
		$aInvitationData = array('id'	=> $id);
		$aFatherData = array('id' => $aInvitationInfo['invite_code']);
		$aGrandData = array();

		//领取直接推荐奖励
		if($aInvitationInfo['invite_code'] == $this->_userId){
			
			//直接推荐人己领取--2
			if($aInvitationInfo['invite_prize_status'] == $this->_DIRECT_INVITER_RECEIVED){
				alert('奖励己经领取过了哦', 0);
				
			//直，间　都末领 --1
			}elseif($aInvitationInfo['invite_prize_status'] == $this->_STATU_TASK_FINISH){
				$aInvitationData['invite_prize_status'] = $this->_DIRECT_INVITER_RECEIVED;
			
			//间接己末领 -- 3
			}elseif($aInvitationInfo['invite_prize_status'] == $this->_INDIRECT_INVITER_RECEIVED){
				$aInvitationData['invite_prize_status'] = $this->_ALL_INVITER_RECEIVED;
			}
			
			//更新被推荐人状态
			$invitationResult = $oInvitation->setUserInvitation($aInvitationData);
			if(!$invitationResult){
				alert('操作失败', 0);
			}
			
			$ub = 25;
			
			//更新推荐者　推荐数量
			if(!$aFatherInfo){	
				$aFatherData['id']	= $this->_userId;
				$aFatherData['direct_invite_nums'] = 1;
				$aFatherData['receive_ub'] = $ub;
				$fatherResult = $oInvitation->addUserInvitaion($aFatherData);
			}else{
				if($aFatherInfo['invite_code'] > 1){
					$ub = 20;
				}
				$aFatherData['id']	= $aFatherInfo['id'];
				$aFatherData['direct_invite_nums'] = $aFatherInfo['direct_invite_nums'] + 1;
				$aFatherData['receive_ub'] = $aFatherInfo['receive_ub'] + $ub;
				$fatherResult = $oInvitation->setUserInvitation($aFatherData);
			}
			if(!$fatherResult){
				myLog('用户：' . $this->_userId . ' 领取直接推荐奖励时操作失败');
				alert('操作失败', 0);
			}
			
		//领取间接推荐奖励			
		}else{
			if(!$aFatherInfo || $aFatherInfo['invite_code'] != $this->_userId){
				alert('数据错误', 0);
			}
			
			//取更上一层推荐者信息 即当前用户在推荐表中的信息
			$aGrandInfo = $oInvitation->getUserInvitationById($aFatherInfo['invite_code']);
			if($aGrandInfo === false){
				alert('系统错误', 0);
			}
			
			//间接推荐人己领取--3
			if($aInvitationInfo['invite_prize_status'] == $this->_INDIRECT_INVITER_RECEIVED){
				alert('奖励己经领取过了哦', 0);
			
			//直，间　都末领 --1
			}elseif($aInvitationInfo['invite_prize_status'] == $this->_STATU_TASK_FINISH){
				$aInvitationData['invite_prize_status'] = $this->_INDIRECT_INVITER_RECEIVED;
					
			//直接己领间接末领 -- 2
			}elseif($aInvitationInfo['invite_prize_status'] == $this->_DIRECT_INVITER_RECEIVED){
				$aInvitationData['invite_prize_status'] = $this->_ALL_INVITER_RECEIVED;
			}
			
			//更新被推荐人状态
			$invitationResult = $oInvitation->setUserInvitation($aInvitationData);
			if(!$invitationResult){
				alert('操作失败', 0);
			}
			
			$ub = 5;
			
			if(!$aGrandInfo){
				$aGrandData['id']	= $this->_userId;
				$aGrandData['indirect_invite_nums'] = 1;
				$aGrandData['receive_ub'] = $ub;
				$grandResult = $oInvitation->addUserInvitaion($aGrandData);
			}else{
				$aGrandData['id']	= $aGrandInfo['id'];
				$aGrandData['indirect_invite_nums'] = $aGrandInfo['indirect_invite_nums'] + 1;
				$aGrandData['receive_ub'] = $aGrandInfo['receive_ub'] + $ub;
				$grandResult = $oInvitation->setUserInvitation($aGrandData);
			}
			if(!$grandResult){
				myLog('用户：' . $this->_userId . ' 领取间接推荐奖励时操作失败');
				alert('操作失败', 0);
			}
			
		}

		//更新领取者Ub
		$oUserNumerical = m('UserNumerical');
		$aUserNumericalInfo = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if(!$aUserNumericalInfo){
			myLog('用户：' . $this->_userId . ' 领取推荐奖励后更新UB操作失败');
			alert('系统错误a', 0);
		}
		
		$aNumericalData = array(
			'id' => $this->_userId,
			'ub' =>	$aUserNumericalInfo['ub'] + $ub						
		);
		$numericalResult = $oUserNumerical->setUserNumerical($aNumericalData);
		if(!$numericalResult){
			myLog('用户：' . $this->_userId . ' 领取推荐奖励后更新UB操作失败');
			alert('操作失败', 0);
		}
		alert('', 1);
	}
	
	//我推荐的好友 AJAX 请求分页
	public function getRecommendListByPage(){
		$type = intval(post('type', 1));
		$page = intval(post('page', 1));
		if($page < 1 || ($type != 1 && $type != 2)){
			alert('数据错误', 0);
		}
		$isReceiveAward = false;
		if($type == 2){
			$isReceiveAward = true;
		}
		
		$aRecommendListAndCount = $this->_getRecommendList($isReceiveAward, $page);
		if($aRecommendListAndCount === false){
			alert('系统错误', 0);
		}
		
		alert('', 1, $aRecommendListAndCount);
	}


	//个人中心@好友时的列表
	public function getFriendList(){
		$groupId = intval(post('groupId'));
		$page = intval(post('page'));
		if($page < 1){
			$page = 1;
		}

		$returnHtml = '';
		$pageHtml = '';
		$pageSize = 2;
		$oSns = m('Sns');
		$count = $oSns->getUserFriendCount($this->_userId, $groupId);
		if($count === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($count > 0){
			$pageCount = ceil($count / $pageSize);
			if($page > $pageCount){
				$page = $pageCount;
			}
			$aFriendList = $oSns->getUserFriendList($this->_userId, $groupId, ($page - 1) * $pageSize, $pageSize);
			if($aFriendList === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			if($aFriendList){
				$returnHtml = '<ul class="list c">';
				foreach($aFriendList as $aFriendInfo){
					$returnHtml .= '<li><a><span class="head"><img width="25" height="25" src="'. SYSTEM_RESOURCE_URL . $aFriendInfo['profile'] .'" /></span><span class="name">' . $aFriendInfo['name'] . '</span></a></li>';
				}
				$returnHtml .= '</ul>';
				$aPageInfo = array(
					'url' => url('m=Pay&a=showList&page=_PAGE_'),
					'total' => $count,
					'size' => $pageSize,
					'page' => $page,
					'onclick' => 'getFriendList('.$groupId.',_PAGE_)'
				);
				$pageHtml = page($aPageInfo);
			}
		}
		alert($returnHtml . $pageHtml, 1);
	}

	
	//发私信提醒
	public function sendRecommendMessage(){
		$id = intval(post('id'));
		$msg = post('msg');
		if($id < 1 || !$msg){
			alert('数据错误', 0);
		}
		$aCookie = array();
		$cookieName = 'recommandTime' . $this->_userId;
		if(Cookie::isSetted($cookieName)){
			$aCookie = explode(',', Cookie::get($cookieName));
		}
		$now = time();
		if(isset($aCookie[$id]) && $aCookie[$id] > $now){
			alert('亲：你今天己经提醒过了， 一天只能提醒一次哦', -1);
		}
		if($aCookie){
			foreach($aCookie as $sendCookie){
				if($sendCookie <= $now){
					unset($sendCookie);
				}
			}
		}
		
		$oInvitation = m('UserInvitation');
		$aInvitationInfo = $oInvitation->getUserInvitationById($id);
		if(!$aInvitationInfo || $aInvitationInfo['invite_prize_status'] >= $this->_STATU_TASK_FINISH){
			alert('操作失败', 0);
		}
		$aData = array(
			'sender_user_id'	=> $this->_userId,
			'receiver_user_id'	=> $id,
			'content'			=> $msg,
			'create_time'		=> time()
		);
		$oSns = m('Sns');
		$result = $oSns->addSnsPrivateMessage($aData);
		if(!$result){
			alert('操作失败', 0);
		}
		$aCookie[$id] = $now + 86400;
		Cookie::set($cookieName, implode(',', $aCookie), $now + 604800);
		alert('', 1);
	}

	//我推荐的好友
	private function _getRecommendList($isReceiveAward = false, $page = 1){
		$pageSize = 6;
		$oInvitation = m('UserInvitation');	
		$aRecommendListAndCount = $oInvitation->getUserInvitationDetailList($this->_userId, $isReceiveAward, $page, $pageSize);

		if($aRecommendListAndCount){
			foreach($aRecommendListAndCount['data'] as &$aRecommendInfo){
				
				if($aRecommendInfo['invite_prize_status'] < $this->_STATU_TASK_FINISH){
					$aTmp = explode(',', $aRecommendInfo['new_task_process_status']);
					$styleWidth = 0;
					$countTmp = count($aTmp);
					for($i = 0; $i <= $countTmp; $i++){
						if(isset($aTmp[$i]) && $aTmp[$i] == 1){
							$styleWidth ++;
						}
					}
					$aRecommendInfo['styleWidth'] = ceil(($styleWidth / $this->_NEW_TASE_PROCESS_COUNT) * 100);
					$aRecommendInfo['btnStatus'] = 1;//--私信催一下
				}else{
					$aRecommendInfo['styleWidth'] = 100;
						if($aRecommendInfo['invite_prize_status'] == $this->_STATU_TASK_FINISH || $aRecommendInfo['invite_prize_status'] == $this->_INDIRECT_INVITER_RECEIVED){
							$aRecommendInfo['btnStatus'] = 2;//--领取--
						}else{
							$aRecommendInfo['btnStatus'] = 3;//--己领取--
						}
				}
				if($aRecommendInfo['invite_list']){
					foreach($aRecommendInfo['invite_list'] as &$inviteInfo){
						if($inviteInfo['invite_prize_status'] < $this->_STATU_TASK_FINISH){
							$aTmp = explode(',', $inviteInfo['new_task_process_status']);
							$styleWidth = 0;
							$countTmp = count($aTmp);
							for($i = 0; $i <= $countTmp; $i++){
								if(isset($aTmp[$i]) && $aTmp[$i] == 1){
									$styleWidth ++;
								}
							}
							$inviteInfo['styleWidth'] = ceil(($styleWidth / $this->_NEW_TASE_PROCESS_COUNT) * 100);
							$inviteInfo['btnStatus'] = 1;//--私信催一下
						}else{
							$inviteInfo['styleWidth'] = 100;
							if($inviteInfo['invite_prize_status'] == $this->_STATU_TASK_FINISH || $inviteInfo['invite_prize_status'] == $this->_DIRECT_INVITER_RECEIVED){
								$inviteInfo['btnStatus'] = 2;//--领取--
							}else{
								$inviteInfo['btnStatus'] = 3;//--己领取--
							}
						}
					}
				}
			}
			
			$pageType = 1;
			if($isReceiveAward){
				$pageType = 2;
			}	
			$aPageData = array(
				'labels'=> array(
					'first'		=> '首页',
					'previous'	=> '上一页',
					'next'		=> '下一页',
					'last'		=> '尾页'
				),
				'page'=> $page,	
				'url' => ' ',
				'total'	=> $aRecommendListAndCount['count'],
				'size'	=> $pageSize,
				'onclick'=>"getRecommendNext(_PAGE_,$pageType)"
			);
			$p = new Pagination($aPageData);
			$aRecommendListAndCount['pageHtml'] = $p->fetch();
		}
		return $aRecommendListAndCount;
	}
	
	
	//他的　好友列表 更多
	public function showFriendListByFriendIdMore(){
		$friendId = intval(post('friendId'));
		$page = intval(post('page'));
	
		$aUserInfo = array();
		$aFriendCount = 0;
		$aFriendList = array();
		$returnHtml = '';
	
		if($friendId < 1 || $page < 2){
			alert('数据错误', 0);
		}
	
		$oUser = m('User');
		$oSns = m('Sns');
		$aUserInfo = $oUser->getUserInfoByUserId($friendId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if(!$aUserInfo){
			alert('会员不存在', 0);
		}
		$aFriendList = $this->_getHerFriendList($friendId, $page);
		if($aFriendList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		alert('', 1, $aFriendList);
	}
	
	//他的　好友列表
	private function _showFriendListByFriendId($friendId = 0){
		$aUserInfo = array();
		$aFriendCount = 0;
		$aFriendList = array();
		$pageCount = 1;
		$pageSize = 15;
	
		$commonFriendCount = 0;
		$aCommonFriendList = array();
	
		$probablyCount = 0;
		$aProbablyList = array();
	
		if($friendId < 1){
			alert('数据错误', 0);
		}
	
		$oUser = m('User');
		$oSns = m('Sns');
		$aUserInfo = $oUser->getUserInfoByUserId($friendId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if(!$aUserInfo){
			alert('此用户不存在', 0);
		}
	
		$aFriendCount = $oSns->getUserFriendCount($friendId);
		if($aFriendCount === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
	
		//当前登陆用户的好友ID集合
		$aUserFriendIdArray = getUserFriendIds($this->_userId);
		//当前用户的好友ID集合
		$aFriendIdArray = getUserFriendIds($friendId);
	
		//共同好友
		$aCommonIdArray = array_intersect($aUserFriendIdArray, $aFriendIdArray);
		if($aCommonIdArray){
			$aCommonFriendList = $oSns->getUserListByUserIds($aCommonIdArray, 0, count($aCommonIdArray), '');
			if($aCommonFriendList === false){
				alert('系统错误', 0);
			}
			$commonFriendCount = count($aCommonFriendList);
		}
	
		//可能认识的人
		$aProbablyList = $oSns->getUserFriendInMyProbably($this->_userId, $aFriendIdArray);
		if($aProbablyList === false){
			alert('系统错误', 0);
		}
	
		if($aFriendCount > 0){
			$pageCount = ceil($aFriendCount / $pageSize);
			$aFriendList = $this->_getHerFriendList($friendId);
			if($aFriendList === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}
	
		displayHeader();
		assign('friendId', $friendId);
		assign('pageCount', $pageCount);
		assign('aUserInfo', $aUserInfo);
		assign('aFriendCount', $aFriendCount);
		assign('aFriendList', $aFriendList);
		assign('commonFriendCount', $commonFriendCount);
		assign('aCommonFriendList', $aCommonFriendList);
		assign('aProbablyList', $aProbablyList);
	
		unset($aUserFriendIdArray);
		unset($aFriendIdArray);
		unset($aCommonIdArray);
	
		display('friend/user_friends.html.php');
		displayFooter(true);
	}
	
	//按条件取他的好友数据
	private function _getHerFriendList($herId, $page = 1){
		$pageSize = 15;
		$oSns = m('Sns');
		$aFriendList = $oSns->getUserFriendList($herId, $page, $pageSize);
		if($aFriendList === false){
			return false;
		}
		$aFriendIdArray = getUserFriendIds($this->_userId);
		if($aFriendList){
			foreach($aFriendList as $key=>$aFriendInfo){
				$aFriendList[$key]['isFriend'] = 0;
				if(in_array($aFriendInfo['id'], $aFriendIdArray)){
					$aFriendList[$key]['isFriend'] = 1;	//已加为好友
				}elseif($aFriendInfo['id'] == $this->_userId){
					$aFriendList[$key]['isFriend'] = 3;	//自己
				}else{
					//是否己经发送加好友请求
					$aMasterInfo = $oSns->getUserRelationInfo('`user_master_id` = ' . $this->_userId . ' AND `user_slave_id` = ' . $aFriendInfo['id']);
					if($aMasterInfo === false){
						return false;
					}
					if($aMasterInfo){
						$aFriendList[$key]['isFriend'] = 2;	//已发送好友请求
					}
				}
			}
		}
		return $aFriendList;
	}
	

	
	
}