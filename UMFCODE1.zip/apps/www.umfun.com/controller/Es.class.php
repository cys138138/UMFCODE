<?php
use common\model\Es;
class EsController {
	private $_userId = 0;

	private $_aEsCreateTimes = array(
		0 => '全部',
		1 => '最近1周',
		2 => '最近2周',
		3 => '最近1月',
		4 => '最近2月',
		5 => '最近3月'
	);

	private $_aEsOrderTypes = array(
		1 => '时间倒序',
		2 => '时间正序'
	);

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	//错题集
	public function showWrongEsList(){
		$missionId = intval(get('missionId', 0));
		if($missionId < 0){
			alert('数据错误');
		}
		$aDefaultMissionInfo = array(
			'subjectId' => 1,
			'page'		=> 1
		);

		$aEsListAndCount = $this->_getWongEsList($missionId);
		if($aEsListAndCount === false){
			alert('系统错误', 0);
		}
		$aEsList = $aEsListAndCount['aEsList'];
		$esCount = $aEsListAndCount['esCount'];
		unset($aEsListAndCount);

		if($missionId > 0){
			$oMission = m('Mission');
			$oEs = m('Es');
			$aMissionInfo = $oMission->getMissionInfoById($missionId);
			$aMissionPage = $oEs->getEsWrongMissionPage($this->_userId, $missionId, 10);
			if( $aMissionInfo === false || $aMissionPage === false){
				alert('系统错误', 0);
			}
			if($aMissionInfo){
				$aDefaultMissionInfo['subjectId'] = $aMissionInfo['subject_id'];
			}
			$aDefaultMissionInfo['page'] = $aMissionPage;
			unset($aMissionInfo);
			unset($aMissionPage);
		}

		assign('missionId', $missionId);
		assign('userId', $this->_userId);
		assign('esCount', $esCount);
		assign('aEsList', $aEsList);
		assign('aDefaultMissionInfo', $aDefaultMissionInfo);

		assign('aSubject', $GLOBALS['SUBJECT']);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aEsCreateTimes', $this->_aEsCreateTimes);
		assign('aEsOrderTypes', $this->_aEsOrderTypes);

		displayHeader('我的错题');
		displayLeftNav($this->_userId);
		display('es/es_list.html.php');
		displayFooter();
	}

	public function getWrongEsListByCondition(){
		$searchType = intval(post('searchType'));
		$page = intval(post('page'));
		$missionId = intval(post('missionId'));

		$esSubject = intval(post('esSubject'));
		$esType = intval(post('esType'));
		$esCreateTime = intval(post('esCreateTime'));
		$esOrderType = intval(post('esOrderType'));

		if($searchType != 1 && $searchType != 2 || $page < 1 || $missionId < 0){
			alert('数据错误', 0);
		}

		$aEsListAndCount = array();
		if($searchType == 1){
			$aEsListAndCount = $this->_getWongEsList($missionId, $page);
		}else{
			if($esSubject != 0 && !isset($GLOBALS['SUBJECT'][$esSubject])){
				alert('数据错误', 0);
			}
			if($esType != 0 && !isset($GLOBALS['ES_TYPE'][$esType])){
				alert('数据错误', 0);
			}
			if(!isset($this->_aEsCreateTimes[$esCreateTime])){
				alert('数据错误', 0);
			}
			if(!isset($this->_aEsOrderTypes[$esOrderType])){
				alert('数据错误', 0);
			}
			$aCreateTime = $this->_getCreateTime($esCreateTime);
			$startTime = $aCreateTime['startTime'];
			$endTime = $aCreateTime['endTime'];
			unset($aCreateTime);
			$order = '`create_time` desc';
			if($esOrderType == 2){
				$order = '`create_time` asc';
			}

			$aEsListAndCount = $this->_getWongEsList($missionId, $page, $esSubject, $esType, $startTime, $endTime, $order);
		}

		if($aEsListAndCount === false){
			alert('系统错误', 0);
		}
		alert('', 1, $aEsListAndCount);
	}


	//根据条件返回关卡列表
	public function getWongEsMissionList(){
		$page = intval(post('page'));
		$subjectId = intval(post('subjectId'));
		if($page < 1 || ($subjectId < 0 || $subjectId > 4)){
			alert('数据错误', 0);
		}

		$pageSize = 10;
		$pageCount = 0;
		$aMissionList = array();
		$aData = array();
		$oEs = m('Es');
		$missionCount = $oEs->getEsWrongMissionCount($this->_userId, $subjectId);
		if($missionCount === false){
			alert('系统错误', 0);
		}
		if($missionCount > 0){
			$pageCount = ceil($missionCount / $pageSize);
			$aMissionList = $oEs->getEsWrongMissionList($this->_userId, $page, $pageSize, $subjectId);
		}
		if($missionCount === false){
			alert('系统错误', 0);
		}
		$aData['pageCount'] = $pageCount;
		$aData['aMissionList'] = $aMissionList;
		alert('', 1, $aData);
	}

	//删除错题记录
	public function delWrongEs(){
		$esIds = post('esIds');
		if(!is_array($esIds) || !$esIds){
			alert('数据错误', 0);
		}
		$aUpdateIds = array();
		foreach($esIds as $id){
			if($id > 0){
				$aUpdateIds[] = $id;
			}elseif(is_string($id)){
				$aUpdateIds[] = Xxtea::decrypt($id);
			}
		}
		if(!$aUpdateIds){
			alert('数据错误', 0);
		}
		$oEs = m('Es');
		$result = $oEs->deleteBatchUserEsWrong($aUpdateIds);
		if($result === false){
			alert('系统错误', 0);
		}
		if($result){
			alert('删除错题成功', 1);
		}else{
			alert('操作失败', 0, $aUpdateIds);
		}
	}

	//通过题目ID删除错题记录
	public function delWrongEsByEsId(){
		$esId = post('es_id');
		$missionId = intval(post('mission_id'));
		if(!is_string($esId) || $missionId < 1){
			alert('参数错误', 0);
		}

		$esId = Xxtea::decrypt($esId);
		if(!m('Es')->deleteUserEsWrongByEsId($esId, $this->_userId, $missionId)){
			alert('操作失败', 0);
		}else{
			alert('删除错题成功');
		}
	}

	/**
	*	添加题目反馈
	*/
	public function addFeedback(){
		$esId = Xxtea::decrypt(post('es_id'));
		$missionId = intval(post('mission_id', 0));
		$reason = post('reason');
		$aUserAnswer = json_encode(post('user_answer'));
		$oEs = m('Es');
		$aEsInfo = $oEs->getOfficialEsInfoById($esId);
		if($aEsInfo === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif(!$aEsInfo){
			alert('题目数据有误，请联系管理员！', 0);
		}
		if(!w('length(10, 300)', $reason)){
			alert('抱歉，反馈信息字数限制为10到300字节', 0);
		}
		$oMission = m('Mission');
		if($missionId){
			$aMissionInfo = $oMission->getMissionInfoById($missionId);
			if($aMissionInfo === false){
				alert('系统有误，请稍后再试！', 0);
			}elseif(!$aMissionInfo){
				alert('关卡有误，请联系管理员！', 0);
			}
		}
		$aUserFeedbackInfo = $oEs->getEsFeedbackInfoByUserIdAndEsId($this->_userId, $esId);
		if($aUserFeedbackInfo === false){
			alert('系统有误，请稍后再试！', 0);
		}elseif($aUserFeedbackInfo && $aUserFeedbackInfo['status'] == 1){
			alert('您已经反馈过该题目，请耐心等待审核！', 0);
		}

		$feedbackId = $oEs->addEsFeedback(array(
			'user_id' => $this->_userId,
			'user_type' => 1,
			'es_id' => $esId,
			'subject_id' => $aEsInfo['subject_id'],
			'mission_id' => $missionId,
			'reason' => $reason,
			'user_answer' => $aUserAnswer,
			'status' => 1,
			'create_time' => time(),
		));
		if($feedbackId === false){
			alert('抱歉！系统有误，请稍后再试！', 0);
		}elseif($feedbackId){
			alert('反馈成功！');
		}else{
			alert('抱歉！反馈失败，请稍后再试！', 0);
		}
	}

	//根据条件反回错题列表
	private function _getWongEsList($missionId = 0, $page = 1, $subjectId = 0, $typeId = 0, $startTime = 0, $endTime = 0, $order = '`create_time` desc'){
		$filter = 2;
		if($missionId > 0){
			$filter = 1;
		}
		$oEs = m('Es');
		$aData = array(
			'esCount' 	=> 0,
			'aEsList'	=> array()
		);
		$pageSize = 10;
		$esCount = $oEs->getUserWrongEsCount($this->_userId, $subjectId, $typeId, $filter, $missionId, $startTime, $endTime);
		$aEsList = $oEs->getUserWrongEsList($this->_userId, $page, $pageSize, $subjectId, $typeId, $filter, $missionId, $startTime, $endTime, $order);

		if($esCount === false || $aEsList === false){
			return false;
		}
		if($aEsList){
			foreach($aEsList as $key => $aEsInfo){
				$mEs = Es::toModel($aEsInfo);
				$aEsList[$key]['es_answer'] = $mEs->getAnswer();
				$mEs->removeAnswer();
				$aEsList[$key]['es_content'] = $mEs->es_content;
				$aEsList[$key]['es_id'] = $mEs->id;
			}
		}
		$aData['esCount'] = $esCount;
		$aData['aEsList'] = $aEsList;
		unset($esCount);
		unset($aEsList);
		return $aData;
	}


	//根据查找类型返回起止时间
	private function _getCreateTime($type = 0){
		$aData = array(
			'startTime'	=> 0,
			'endTime'	=> 0
		);
		if($type == 1 || $type == 2){
			$aData['endTime'] = strtotime(date('Y-m-d'));
			$aData['startTime'] = strtotime(date('y-m-d',strtotime("-$type week")));
		}
		if($type == 3 || $type == 4 || $type == 5){
			$num = $type - 2;
			$aData['endTime'] = strtotime(date('Y-m-d'));
			$aData['startTime'] = strtotime(date('y-m-d',strtotime("-$num month")));
		}
		return $aData;
	}



//================================================================================================================

	//收藏夹
	public function showFavouriteEsList(){
		$missionId = intval(get('missionId', 0));
		if($missionId < 0){
			alert('数据错误', 0);
		}
		$esCount = 0;
		$aEsList = array();
		$aDefaultMissionInfo = array(
			'subjectId' => 1,
			'page'		=> 1
		);

		$aFavouriteEsListAndCount = $this->_getFavouriteEsList($missionId);
		if($aFavouriteEsListAndCount === false){
			alert('系统错误', 0);
		}
		$esCount = $aFavouriteEsListAndCount['esCount'];
		$aEsList = $aFavouriteEsListAndCount['aEsList'];
		unset($aFavouriteEsListAndCount);

		if($missionId > 0){
			$oMission = m('Mission');
			$oEs = m('Es');
			$aMissionInfo = $oMission->getMissionInfoById($missionId);
			$aMissionPage = $oEs->getEsFavouriteMissionPage($this->_userId, $missionId, 10);
			if( $aMissionInfo === false || $aMissionPage === false){
				alert('系统错误', 0);
			}
			if($aMissionInfo){
				$aDefaultMissionInfo['subjectId'] = $aMissionInfo['subject_id'];
			}
			$aDefaultMissionInfo['page'] = $aMissionPage;
			unset($aMissionInfo);
			unset($aMissionPage);
		}


		assign('missionId', $missionId);
		assign('userId', $this->_userId);
		assign('esCount', $esCount);
		assign('aEsList', $aEsList);
		assign('aDefaultMissionInfo', $aDefaultMissionInfo);

		assign('aSubject', $GLOBALS['SUBJECT']);
		assign('aEsType', $GLOBALS['ES_TYPE']);
		assign('aEsCreateTimes', $this->_aEsCreateTimes);
		assign('aEsOrderTypes', $this->_aEsOrderTypes);

		displayHeader('我的收藏');
		displayLeftNav($this->_userId);
		display('es/favourite_list.html.php');
		displayFooter();
	}


	//收藏夹AJAX条件查询请求
	public function getFavouriteEsListByCondition(){
		$searchType = intval(post('searchType'));
		$page = intval(post('page'));
		$missionId = intval(post('missionId'));

		$esSubject = intval(post('esSubject'));
		$esType = intval(post('esType'));
		$esCreateTime = intval(post('esCreateTime'));
		$esOrderType = intval(post('esOrderType'));

		if($searchType != 1 && $searchType != 2 || $page < 1 || $missionId < 0){
			alert('数据错误', 0);
		}

		$aEsListAndCount = array();
		if($searchType == 1){
			$aEsListAndCount = $this->_getFavouriteEsList($missionId, $page);
		}else{
			if($esSubject != 0 && !isset($GLOBALS['SUBJECT'][$esSubject])){
				alert('数据错误', 0);
			}
			if($esType != 0 && !isset($GLOBALS['ES_TYPE'][$esType])){
				alert('数据错误', 0);
			}
			if(!isset($this->_aEsCreateTimes[$esCreateTime])){
				alert('数据错误', 0);
			}
			if(!isset($this->_aEsOrderTypes[$esOrderType])){
				alert('数据错误', 0);
			}
			$aCreateTime = $this->_getCreateTime($esCreateTime);
			$startTime = $aCreateTime['startTime'];
			$endTime = $aCreateTime['endTime'];
			unset($aCreateTime);

			$order = '`create_time` desc';
			if($esOrderType == 2){
				$order = '`create_time` asc';
			}
			$aEsListAndCount = $this->_getFavouriteEsList($missionId, $page, $esSubject, $esType, $startTime, $endTime, $order);
		}

		if($aEsListAndCount === false){
			alert('系统错误', 0);
		}
		alert('', 1, $aEsListAndCount);
	}

	//收藏的关卡列表
	public function getFavouriteEsMissionList(){
		$page = intval(post('page'));
		$subjectId = intval(post('subjectId'));
		if($page < 1 || !$GLOBALS['SUBJECT'][$subjectId]){
			alert('数据错误', 0);
		}

		$pageSize = 10;
		$pageCount = 0;
		$missionCount = 0;
		$aMissionList = array();
		$aData = array();
		$oEs = m('Es');
		$missionCount = $oEs->getEsFavouriteMissionCount($this->_userId, $subjectId);
		if($missionCount === false){
			alert('系统错误', 0);
		}
		if($missionCount > 0){
			$pageCount = ceil($missionCount / $pageSize);
			$aMissionList = $oEs->getEsFavouriteMissionList($this->_userId, $page, $pageSize, $subjectId);
		}
		if($missionCount === false){
			alert('系统错误', 0);
		}
		$aData['pageCount'] = $pageCount;
		$aData['aMissionList'] = $aMissionList;
		alert('', 1, $aData);

	}

	//删除收藏
	public function delFavouriteEs(){
		$esIds = post('esIds');
		if(!is_array($esIds) || !$esIds){
			alert('数据错误', 0);
		}
		$esIdStr = '';
		foreach ($esIds as $id){
			if($id > 0){
				$esIdStr .= $id . ',';
			}
		}
		if(!$esIdStr){
			alert('数据错误', 0);
		}
		$oEs = m('Es');
		$result = $oEs->deleteBacthUserEsFavourite(rtrim($esIdStr, ','));
		if($result === false){
			alert('系统错误', 0);
		}
		if($result){
			alert($result, 1);
		}else{
			alert('操作失败', 0);
		}
	}


	//是否己被收藏
	private function _isFavouriteEs($userId, $esId){
		$aData = array(
			'msg'	=> '',
			'status'=> 0
		);
		$esId = Xxtea::decrypt($esId);
		if($esId < 1 || $userId < 1){
			$aData['msg'] = '数据错误';
			return $aData;
		}
		$oEs = m('Es');
		$isFavourite = $oEs->isUserFavouriteEs($userId, $esId);
		if($isFavourite === false){
			$aData['msg'] = '系统错误';
			return $aData;
		}
		$aData['msg'] = $isFavourite;
		$aData['status'] = 1;
		return $aData;
	}


	//返回题目收藏状态
	public function getEsFavouriteStatus(){
		$esId = post('esId');
		if(!$esId){
			alert('数据错误', 0);
		}
		$aResult = $this->_isFavouriteEs($this->_userId, $esId);
		alert($aResult['msg'], $aResult['status']);
	}


	public function showWrongStatis(){
		$oEs = m('Es');
		$aStatis = $oEs->getUserSubjectWrongEsStatistic($this->_userId);
		$aStatis[4] = array(
			'wrong_es_times' => 0,
			'repair_es_count' => 0,
			'wrong_es_count' => 0,
		);
		$wrongCount = 0;
		$repairCount = 0;
		$leftWrongCount = 0;
		foreach($aStatis as $aSubjectSta){
			$wrongCount += $aSubjectSta['wrong_es_times'];
			$repairCount += $aSubjectSta['repair_es_count'];
			$leftWrongCount += $aSubjectSta['wrong_es_count'];
		}
		if(!$wrongCount){
			$aStatis[4]['wrong_es_times'] = 1;
		}
		if(!$repairCount){
			$aStatis[4]['repair_es_count'] = 1;
		}
		if(!$leftWrongCount){
			$aStatis[4]['wrong_es_count'] = 1;
		}
		assign('wrongCount', $wrongCount);
		assign('repairCount', $repairCount);
		assign('leftWrongCount', $leftWrongCount);
		assign('aStatis', $aStatis);

		assign('userId', $this->_userId);
		displayHeader('错题统计');
		display('es/es_statis.html.php');
		displayFooter();
	}

	public function checkVip(){
		$oVip = new Vip($this->_userId);
		$aVip = $oVip->isVip();
		if($aVip['vip'] >= 1){
			$esId = intval(post('esId', 0));
			if($esId){
				alert('会员喔', 1, $esId);
			}
			$missionId = intval(post('missionId'));
			if($missionId){
				$url = url('m=Es&a=showRepairWrong&mission=' . $missionId);
			}else{
				$url = url('m=Es&a=showRepairWrong');
			}
			alert('会员喔', 1, $url);
		}else{
			alert('只有白金会员和钻石会员才可以使用修复错题功能喔', -1);
		}
	}

	public function showRepairWrong(){
		$oVip = new Vip($this->_userId);
		$aVip = $oVip->isVip();
		if($aVip['vip'] < 2){
			alert('优满分会员才能查看修复错题哦！立即开通，错题随心修复！', -1);
		}
		assign('allowRepairEs', $oVip->isAllowRepairWrongEs() ? true : false);	//是否允许修复题目


		$subjectId = intval(get('subject'));
		$missionId = intval(get('mission'));
		$orderMode = intval(get('order'));

		//这里面已经包括了参数验证,所以本方法不用对以上GET参数做验证
		$aEs = $this->_getNextFixEs(1, $subjectId, $missionId, $orderMode);
		if(!$aEs){
			header('Location: ' . url('m=Es&a=showWrongStatis'));
			exit;
		}
		$esId = 0;
		if(isset($aEs['es_id'])){
			$esId = $aEs['es_id'];
		}else{
			myLog('修复错题的时候获取题目ID失败,data:' . var_export($aEs, 1));
		}
		unset($aEs['es_id']);	//这里很重要,不能把数字的题目ID泄漏到前端,必须先unset
		assign('aEs', $aEs);

		//读取题目评论
		$oEsComment = m('Wenwen');
		$aEsCommentList = $oEsComment->getCommentListByEsId($esId, 1, 5, '`create_time` desc');
		if($aEsCommentList === false){
			$aEsCommentList = array();
		}
		assign('aCommentList', $aEsCommentList);

		$aMission = array(
			'id' => 0,
			'name' => '全部',
		);
		$filter = 2;
		if($missionId){
			$oMission = m('Mission');
			$aMission = $oMission->getMissionInfoById($missionId);
			if(!$aMission){
				alert('非法的查询关卡', 0);
			}
			$filter = 1;
		}

		assign('aSearchMission', array(
			'id' => $aMission['id'],
			'name' => $aMission['name'],
		));
		assign('searchSubjectId', $subjectId);
		assign('missionId', $missionId);
		assign('searchOrderMode', $orderMode);

		$oEs = m('Es');
		//错题的关卡列表
		$aMissionList = $oEs->getEsWrongMissionList($this->_userId, 1, 10, $subjectId);
		assign('aMissionList', $aMissionList);

		$aWrongEsStatisticList = $oEs->getUserSubjectWrongEsStatistic($this->_userId);
		$wrongEsCount = $fixedWrongEsCount = 0;
		foreach($aWrongEsStatisticList as $aWrongEsStatistic){
			$fixedWrongEsCount += $aWrongEsStatistic['repair_es_count'];
			$wrongEsCount += $aWrongEsStatistic['wrong_es_times'] + $aWrongEsStatistic['repair_es_count'];
		}
		assign('wrongEsCount', $wrongEsCount);
		assign('fixedWrongEsCount', $fixedWrongEsCount);

		$aSubjectList = $GLOBALS['SUBJECT'];
		array_unshift($aSubjectList, '全部');
		unset($aSubjectList[4]);
		assign('aSubjectList', $aSubjectList);
		assign('userId', $this->_userId);
		displayHeader();
		displayLeftNav($this->_userId);
		display('es/repair_es.html.php');
		displayFooter();
	}

	public function getWrongMissionList(){
		$oMission = m('Mission');
		$page = intval(post('page'));
		if(!$page){
			$page = 1;
		}
		$subject = post('subject');
		if(!array_key_exists($subject, $GLOBALS['SUBJECT'])){
			alert('科目不存在', -1);
		}
		$aMissionList = $oMission->getUserMissionEsStatisticList($this->_userId, $subject, $page, 5);
		//debug($aMissionList);
		alert('错题关卡列表', 1, $aMissionList);
	}

	/**
	 * 批阅修复做题并且返回下一题的题目和评论继续做
	 */
	public function markingFixEs(){
		$oVip = new Vip($this->_userId);
		$aVip = $oVip->isVip();
		if($aVip['vip'] < 2){
			alert('只有白金会员和钻石会员才可以使用修复错题功能喔', -1);
		}
		if(!$aVipPrivitege = $oVip->isAllowRepairWrongEs()){
			alert('今天的已经达到每天修复错题上限！', -1);
		}

		//验证参数
		$wrongId = intval(post('wrong_id'));
		$mAnswer = post('answer');

		$oEs = m('Es');
		$aUserWrongEs = $oEs->getUserEsWrongById($wrongId);
		if(!$aUserWrongEs){
			alert('非法的错题查询', 0);
		}

		$aFixEs = $oEs->getOfficialEsInfoById($aUserWrongEs['es_id']);
		if(!$aFixEs){
			alert('找不到该题目', 0);
		}

		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aFixEs['type_id']]);
		if(!$oEsPlugin->validateAnswer($mAnswer)){
			alert('无效的答案', 0);
		}

		//批阅题目
		$aAnswerResult = $oEsPlugin->getCorrectness($aFixEs['content_json'], $mAnswer);
		$isPass = $aAnswerResult['pass'];
		if($isPass && !m('Vip')->repairWrongEs($aUserWrongEs, $aVipPrivitege)){
			alert('抱歉，系统出错，修复题目失败！', 1);
		}

		//获取下一条题目
		$page = intval(post('page'));
		$subjectId = intval(post('subject'));
		$missionId = intval(post('mission'));
		$orderMode = intval(post('order'));
		$aNextEs = $this->_getNextFixEs($page, $subjectId, $missionId, $orderMode);
		$aEsCommentList = array();

		if($aNextEs){
			//读取题目评论
			$oEsComment = m('Wenwen');
			$aEsCommentList = $oEsComment->getCommentListByEsId($aNextEs['es_id'], 1, 5, '`create_time` desc');
			if($aEsCommentList === false){
				$aEsCommentList = array();
			}
			unset($aNextEs['es_id']);	//明文ID不能输出到前端
		}

		alert('批阅完毕', 1, array(
			'is_finish' => $aNextEs ? 0 : 1,
			'is_pass' => $isPass,
			'next_es_data' => $aNextEs,
			'next_es_comment' => $aEsCommentList,
		));
	}

	/**
	 * 重新搜索题目
	 */
	public function researchEs(){
		$subjectId = intval(post('subject'));
		$missionId = intval(post('mission'));
		$orderMode = intval(post('order'));
		$aEs = $this->_getNextFixEs(1, $subjectId, $missionId, $orderMode);
		if(!$aEs){
			alert('该条件下没有题目', 0);
		}
		$oEsComment = m('Wenwen');
		$aCommentList = $oEsComment->getCommentListByEsId(XxTea::decrypt($aEs['id']), 1, 5, '`create_time` desc');
		if($aCommentList === false){
			$aCommentList = array();
		}
		alert('', 1, array(
			'es' => $aEs,
			'comment' => $aCommentList,
		));
	}

	private function _getNextFixEs($page, $subjectId, $missionId, $orderMode){
		if($page < 1){
			$page = 1;
		}

		if($subjectId && $subjectId != 4 && !array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('非法的查询科目', 0);
		}

		$filter = 2;
		if($missionId){
			$oMission = m('Mission');
			$aMission = $oMission->getMissionInfoById($missionId);
			if(!$aMission){
				alert('非法的查询关卡', 0);
			}
			$filter = 1;
		}

		if($orderMode == 0){
			$order = 'RAND()';
		}elseif($orderMode == 1){
			$order = '`create_time` desc';
		}elseif($orderMode == 2){
			$order = '`create_time` asc';
		}else{
			alert('非法的查询排序', 0);
		}

		$oEs = m('Es');
		$aEs = $oEs->getUserWrongEsList($this->_userId, $page, 1, $subjectId, 0, $filter, $missionId, 0, 0, $order);
		if($aEs === false){
			alert('获取题目失败', 0);
		}elseif(!$aEs){
			return $aEs;
		}
		$aEs = $aEs[0];
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
		$aEs['wrong_id'] = $aEs['id'];
		$aEs['id'] = Xxtea::encrypt($aEs['es_id']);
		$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
		$aEs['es_content'] = $oEsPlugin->removeAnswer($aEs['es_content']);
		return $aEs;
	}


	//根据条件返回收藏题目列表
	private function _getFavouriteEsList($missionId = 0, $page = 1, $subjectId = 0, $typeId = 0, $startTime = 0, $endTime = 0, $order = '`create_time` desc'){
		$filter = 2;
		if($missionId > 0){
			$filter = 1;
		}
		$oEs = m('Es');
		$aData = array(
			'esCount' 	=> 0,
			'aEsList'	=> array()
		);
		$pageSize = 10;
		$esCount = $oEs->getUserFavouriteEsCount($this->_userId, $subjectId, $typeId, $filter, $missionId, $startTime, $endTime);
		$aEsList = $oEs->getUserEsFavouriteList($this->_userId, $page, $pageSize, $subjectId, $typeId, $filter, $missionId, $startTime, $endTime, $order);
		if($esCount === false || $aEsList === false){
			return false;
		}

		if($aEsList){
			foreach($aEsList as $key => $aEsInfo){
				$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
				$contentJson = json_encode($aEsInfo['content_json']);
				$aEsList[$key]['es_content'] = $oEsPlugin->resolve($contentJson);
				$aEsList[$key]['es_id'] = Xxtea::encrypt($aEsInfo['es_id']);
			}
		}
		$aData['esCount'] = $esCount;
		$aData['aEsList'] = $aEsList;
		unset($esCount);
		unset($aEsList);
		return $aData;
	}
}