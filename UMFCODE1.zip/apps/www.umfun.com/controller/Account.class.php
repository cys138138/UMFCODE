<?php
use common\model\Student;
use common\model\ClassRecord;

/**
 * 用户控制器
 * @author Administrator
 */
class AccountController{

	private $_personalInfoStatus = array(0, 1, 2, 3, 4);
	private $_startYear = 2000;
	private $_acceptPkCount = array(
		'min' => 0,
		'max' => 5
	);
	private $_oldTime = 0;

	public function __construct(){}

	public function rememberUserAgent(){
		Cookie::setEncrypt('_age', $_SERVER['HTTP_USER_AGENT'], time() + 60);
		alert(Cookie::getDecrypt('_age'));
	}
	/**
	 *登陆页面
	 */
	public function showLogin(){
		$token = get('token');
		if(!$token){
			$token = get('Token');
		}
		if($token){
			$_GET['token'] = $token;
			User::doXxtAccountLogin();
			exit;
		}
		$reference = isset($_GET['reference']) ? $_GET['reference'] : '';
		assign('validateLoginJs', j('password', 'checkLoginForm', 'showLoginTips'));
		assign('validateRegisterJs', j('password_register,repeatPassword_register,is_read_register,', 'checkRegisterForm', 'showRegisterTips'));

		//captcha_register
		assign('reference', $reference);
		assign('action', get('action'));
		assign('invitation', get('sf', isset($_COOKIE['sf']) ? $_COOKIE['sf'] : ''));	//注册邀请码
		assign('doNotCheckLoginCaptcha', limitCheck('LOGIN') ? 1 : 0);	//是否不要检查用户的登陆验证码
		display('index.html.php');
	}

	/**
	* 登出处理
	*/
	public function logout(){
		User::logout();
	}

	/**
	 * 用户登陆处理
	 * 表单参数: email(邮箱账号或手机或数字ID), password, rempass（可选）
	 */
	public function login(){
		alert('抱歉,这个登陆点已经停用,请到 ' . Yii::$app->urlManagerLogin->baseUrl . ' 上进行登陆', -1);
		User::login();
	}

	/**
	 * 获取登陆信息
	 */
	public function getLoginInformation(){
		$aUser = isLogin();
		if(!$aUser){
			alert('获取失败', 0);
		}

		//判断是否完成了资料
		if(!$aUser['name']){
			$aUser['url'] = url('m=Account&a=showPerfectUserInformation');
		}
		else{
			$aUser['url'] = url('m=Index&a=index');
		}

		if(!$aUser['profile'] || !file_exists(SYSTEM_RESOURCE_PATH . $aUser['profile'])){
			$aUser['profile'] = $GLOBALS['RESOURCE']['profile_male'];
		}else{
			$aUser['profile'] = SYSTEM_RESOURCE_URL . $aUser['profile'];
		}

		$aUser['logout'] = url('m=Account&a=logout');
		alert('获取成功', 1, $aUser);
	}

	/**
	 * 旧的注册页面输出方法,请于2014年2月28号之后删除该方法
	 */
	public function showRegister(){
		header('HTTP/1.1 301 Moved Permanently');
		header('Location: ' . url('m=Login&a=showLogin', '', APP_LOGIN));
	}

	/**
	 * 检查账号是否注册过
	 * 表单参数: email(邮箱账号或手机或数字ID)
	 */
	public function checkAccountExist(){
		User::checkAccountExist();
	}

	/**
	 * 显示QQ账号登陆界面
	 */
	public function showQQLogin(){
		include_once SYSTEM_BASE_PATH . 'library/QQConnect/qqConnectAPI.php';
		$qc = new QC();
		$qc->qq_login();
	}

	/**
	 * 使用QQ账号登陆回调
	 */
	public function qqAccountLogin(){
		$state = get('state');
		$code = get('code');
		if(!$state || !$code){
			alert('QQ登陆失败,可能是浏览器或网络问题！', 0);
		}
		include_once SYSTEM_BASE_PATH . 'library/QQConnect/qqConnectAPI.php';
		$qc = new QC();
		//QQ登录成功后的回调地址,主要保存access token
		$accessToken = $qc->qq_callback();
		//获取用户标示id
		$openId = $qc->get_openid();
		$qc = new QC($accessToken, $openId);

		if(!$openId){
			alert('QQ账号登陆出错！', 0);
		}

		if(!$openId){
			alert('QQ账号登陆出错！', 0);
		}

		$oUser = m('User');
		$aUser = $oUser->getUserInfoByQqOpenId($openId);
		if($aUser === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		$aQQAccount = $qc->get_user_info();

		if($aQQAccount['ret'] == 0){

			$code = Xxtea::encrypt($openId . ',' .$accessToken);
			//判断是否已注册过了
			if(!$aUser){
				assign('code', $code);
				assign('aQQAccount', $aQQAccount);
				display('account/qq_login.html.php');
			}else{
				header('location:' . url('m=Account&a=doQQAccountLogin&code=' . $code));
			}
		}
	}

	/**
	 * 使用QQ账号登陆、注册
	 */
	public function doQQAccountLogin(){
		User::doQQAccountLogin();
	}

	/**
	 * 绑定QQ账号
	 */
	public function bindQQaccount(){
		User::bindQQaccount();
	}

	/**
	 * 注册处理
	 * 表单参数：email_register, password_register, is_read_register, invitation_register, captcha_register
	 */
	public function register(){
		User::register();
	}

	/**
	 *导出txt文件2
	 */
	public function downLoadAccountInfo(){
		checkUserLogin(1);
		//处理中文文件名
		$filename = '优满分账号_' . post('readEmail') . '.txt';
		if(post('readEmail')){
			$filename = '优满分账号_' . post('readEmail') . '.txt';
		}elseif(post('readMobile')){
			$filename = '优满分账号_' . post('readMobile') . '.txt';
		}
	    $encoded_filename = urlencode($filename);
	    $encoded_filename = str_replace('+', '%20', $encoded_filename);    //urlencode会把空格替换成+，而这里需要替换成%20
    	// application/octet-stream为TXT类型文件(生成TXT文件)
    	header('Content-Type: application/octet-stream');
    	if (preg_match('/MSIE/', $_SERVER['HTTP_USER_AGENT']) ) {
       		header('Content-Disposition:  attachment; filename="' . $encoded_filename . '"');
    	}elseif (preg_match("/Firefox/", $_SERVER['HTTP_USER_AGENT'])) {
       		header('Content-Disposition: attachment; filename*="' .  $filename . '"');
    	}else{
      		header('Content-Disposition: attachment; filename="' .  $filename . '"');
   		}
		//在TXT里输出内容
		if(post('readEmail')){
			echo '邮箱账号： ' . post('readEmail') . "\r\n";
		}elseif(post('readMobile')){
			echo '手机账号： ' . post('readMobile') . "\r\n";
		}
       	echo '    UF号： ' . post('readNumber') . "\r\n";
       	echo '登陆密码： ' . post('readPassword') . "\r\n" . "\r\n";
		echo SMTP_FROM . ',中国最大中小学生在线游戏化学习平台' . "\r\n" .'更多精彩尽在 ' . 'http://' . APP_DOMAIN;
	}

	public function sendMobileMessage(){
		$mobile = post('mobile');
		$sendType = intval(post('type'));
		$captcha = post('captcha');
		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}

		$isCaptcha = w('length(5, 5)', $captcha);
		if(!$isCaptcha){
			alert('验证码格式不正确', -1);
		}
		if(!Verify::match('fgotCaptcha', $captcha)){
			alert('验证码错误！', -1);
		}

		//验证手机号是否存在
		$oUser = m('User');
		$isMobileExist = $oUser->isMobileExist($mobile);
		if($sendType != 1){
			if(!$isMobileExist){
				alert('抱歉，系统找不到此手机账号！', -1);
			}
		}else{
			if($isMobileExist){
				alert('抱歉，系统已绑定此手机账号！', -1);
			}
		}
		$nextVerify =  Xxtea::xcrypt('nextVerify');
		//验证发送验证码时间超过一分钟没
		if(Cookie::isSetted($nextVerify)){
			$nextTime = Cookie::getDecrypt($nextVerify);
			if(time() < $nextTime){
				alert('请稍后再试', 0);
			}
		}
		//取得6位数的手机验证码
		$time = str_replace('.', '', microtime(true));
		$start = rand(0, strlen($time)-6);
		$code = substr($time, $start, 6);

		if($sendType == 1){
			$msgText = urlencode('您好，您在优满分系统申请绑定手机，您的验证码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作 【优满分】');
		}else{
			$msgText = urlencode('您好，您在优满分系统通过手机找回密码，您的验证码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作 【优满分】');
		}
		$url = 'http://utf8.sms.webchinese.cn/?Uid=' . SEND_MESSAGE_USER . '&Key=' . SEND_MESSAGE_KEY . '&smsMob=' . $mobile . '&smsText=' . $msgText;
		$returnStatus = 0;
		if(function_exists('file_get_contents')){
			$returnStatus = file_get_contents($url);
		}else{
			$ch = curl_init();
			$timeout = 5;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$returnStatus = curl_exec($ch);
			curl_close($ch);
		}

		if($returnStatus > 0){
			//下次发送时间　60秒以后
			Cookie::setEncrypt($nextVerify , time()+60);

			$cookieName = Xxtea::xcrypt($mobile);
			$endTime = time()+600;
			Cookie::setEncrypt($cookieName, $code . '|' . $endTime);
		}
		alert('校验码已发送，请及时查看手机短信以便完成操作！', 1);
	}

	public function verifyMobileMessage(){
		$mobile = post('mobile');
		$mobileCode = post('mobileCode');
		$captcha = post('captcha');

		$isMobile = w('isPhone()', $mobile);
		if(!$isMobile){
			alert('手机号码格式不正确', -1);
		}
		$isMobileCode = w('isNumber(6)', $mobileCode);
		if(!$isMobileCode){
			alert('手机校验码格式不正确', -1);
		}
		$isCaptcha = w('length(5, 5)', $captcha);
		if(!$isCaptcha){
			alert('验证码格式不正确', -1);
		}
		if(!Verify::match('fgotCaptcha', $captcha)){
			alert('验证码错误！', -1);
		}

		//验证码不存在
		$cookieName = Xxtea::xcrypt($mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('手机校验码错误', -1);
		}

		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('手机校验码错误', -1);
		}

		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('手机校验码错误', -1);
		}

		if($mobileCode != $verifyArray[0]){
			alert('手机校验码错误', -1);
		}

		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}

		$nowTime = time();
		$endTime = $nowTime + 900;
		$encodeStr = Xxtea::encrypt($nowTime . $mobile . $endTime);

		alert('身份验证成功！', 1, $encodeStr);
	}

	public function resetPasswordByMobile(){
		$password = post('password');
		$surePassword = post('surePassword');
		$action = post('action');
		$captcha = post('captcha');

		$oUser = m('User');
		if($action){
			$decodeStr = Xxtea::decrypt($action);
			$startTime = substr($decodeStr, 0, 10);
			$mobile = substr($decodeStr, 10, 11);
			$endTime = substr($decodeStr, 21, 10);
			$isMobile = w('isPhone()', $mobile);
			if(!$isMobile || $endTime - $startTime != 900){
				alert('非法操作！', 0);
			}
			if($endTime < time()){
				alert('操作超时，请重新申请找回密码！', -1);
			}
			$isMobileExist = $oUser->isMobileExist($mobile);
			if(!$isMobileExist){
				alert('抱歉，系统找不到此手机账号！', -1);
			}
		}
		$vResult = v('password, captcha');
		if($vResult){
			alert($vResult, 0);
		}
		if($password != $surePassword){
			alert('两次密码不一至！', -1);
		}
		if(!Verify::match('fgotCaptcha', $captcha)){
			alert('验证码错误！', -1);
		}
		$isSetSuccess = $oUser->setUserIndexInfoByMobile(array('password' => md5($password)), $mobile);
		if($isSetSuccess === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		alert('设置设置成功！', 1);
	}

	/**
	 *用户填写信息页面2
	 */
	public function showPerfectUserInformation(){
		$from = get('from');
		$code = get('code');
		$aUser = checkUserLogin(2);
		$userId = $aUser['id'];

		if($from == 'qq'){
			assign('from', 1);
			assign('qqName', Xxtea::decrypt($code));
		}else{
			assign('from', 0);
			assign('qqName', '');
		}

		$aInvitation = m('UserInvitation')->getUserInvitationById($userId);
		$aUser['invite_code'] = '';
		if($aInvitation){
			$aUser['invite_code'] = $aInvitation['invite_code'];
		}
		assign('validateJs', j('trueName_register,provinceId_register,cityId_register,areaId_register,schoolId_register,gradeId_register','checkForm', 'errorCallBackFunction'));
		assign('aUser', $aUser);

		display('account/register_process_header.html.php');
		display('account/perfect_user_information.html.php');
		display('account/register_process_footer.html.php');
	}

	/**
	 *用户信息处理2
	 */
	public function perfectUserInformation(){
		$aUser = checkUserLogin(3);
		if(!$aUser){
			alert('请重新登陆', 0);
		}
		$userId = $aUser['id'];

		$vResult = v('trueName_register,provinceId_register,cityId_register,areaId_register,schoolId_register,gradeId_register,className_register');

		if($vResult){
			alert($vResult, 0);
		}
		$oUser = m('User');
		//验证有没有这个地区代码
		$areaId = post('areaId_register');
		$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
		if($aAreaInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aAreaInfo){
			alert('非法的地区', 0);
		}

		//先添加学校信息   createRegisterInfo
		$this->_schoolInfoHandle($userId);


		//计算默认的皮肤ID
		$oStyle = m('Style');
		$aStyle = $oStyle->getDefaultStyleInfo();
		if(!$aStyle){
			alert('初始化皮肤数据失败!', 0);
		}

		$row = $oUser->setUserInfo(array(
			'id' 		=> $userId,
			'name'		=> post('trueName_register'),
			'area_id'	=> $areaId,
			'accept_pk_count' => 0,
			'style_id' => $aStyle['id'],
		));
		if(!$row){
			alert('抱歉,更新用户资料失败', 0);
		}

		$this->_updateRegisterUserProbablyFriends($userId);//更新用户可能认识的好友
		//增加个人信息
		if($row){
			$aInvitation = m('UserInvitation')->getUserInvitationById($userId);
			if(!empty($aInvitation['invite_code'])){
				//添加邀请人为好友
				$oSns= m('sns');
				$aData = array(
					'user_master_id' => $userId,
					'user_slave_id' => $aInvitation['invite_code']
				);
				if($oSns->applyFriend($aData) === false){
					alert('网络可能有点慢，请稍后再试', 0);
				}
				if($oSns->agreeFriendApply($aInvitation['invite_code'], $userId) === false){
					alert('网络可能有点慢，请稍后再试', 0);
				}
				alert('填写成功!', 1, url('m=Account&a=rotate'));
			}else{
				alert('填写成功!', 1, url('m=Index&a=index'));
			}
		}else{
			alert('完善资料失败!', 0);
		}
	}

	/**
	 * 更新注册用户可能认识的朋友
	 */
	private function _updateRegisterUserProbablyFriends($userId){
		$oSns = m('Sns');
		$probablyFriends = $oSns->cheakProbablyFriends($userId);
		if($probablyFriends === false){
			alert('系统出错，请稍后再试', 0);
		}
	}

	/**
	 * 学校信息处理2
	 */
	private function _schoolInfoHandle($userId){
		//注意前端班级的value
		$provinceId = intval(post('provinceId_register'));
		$cityId = intval(post('cityId_register'));
		$areaId = intval(post('areaId_register'));
		$oUser = m('User');
		//验证地区
		$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
		if($aAreaInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aAreaInfo){
			alert('非法的地区', 0);
		}

		$aData = array(
			'user_id' => $userId,
			'school_id' => intval(post('schoolId_register')),
			'class' => post('className_register'),
			'grade' => post('gradeId_register'),
			'year' => date('Y', time()),
			'province_id' => $provinceId,
			'city_id' => $cityId,
			'area_id' => $areaId,
			'is_active' => 1,
		);

		if($aData['school_id'] != 0){
			$aSchoolInfo = $oUser->getSchoolInfoBySchoolId($aData['school_id']);
			if($aSchoolInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$aSchoolInfo){
				alert('非法的学校', 0);
			}
		}

		if($aData['class'] != 0){
			//验证班级是否存在
			$counts = $oUser->isClassExist($aData['year'], $aData['school_id'], $aData['grade'], $aData['class']);
			if($counts === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$counts){
				for($j = 1; $j < 21; $j++){
					$aClassList[] = $j;// . '班';
				}
				if(!in_array($aData['class'], $aClassList)){
					alert('无效的班级，暂时支持1-20', 0);
				}
			}
		}

		//如果学校id小于1，则为添加学校
		if($aData['school_id'] < 1){
			//判断用户要添加的学校是不是存在
			$schoolName = post('addSchoolName_register');
			if(!$schoolName){
				alert('请添加学校!', 0);
			}

			$aSchoolData = array(
				'area_id' => $areaId,
				'name' => $schoolName,
			);

			$aSchoolInfo = $oUser->getSchoolInfoByAreaIdAndSchoolName($aSchoolData['area_id'] ,$aSchoolData['name']);
			if($aSchoolInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if($aSchoolInfo){
				alert('该学校已经存在了!', 0);
			}
		}

		//如果班级id为0，则为添加班级
		if(!$aData['class']){
			//判断用户要添加的班级存不存在
			$addClassName = post('addClassName_register');
			if(!$addClassName){
				alert('请写入有效的班级!', 0);
			}
			//用户填写班级，前端默认填充班作显示。
			if(preg_match('/班$/', $addClassName) === 0){
				$addClassName = $addClassName . '班';
			}
			$aUserInfo = $oUser->isClassExist($aData['year'], $aData['school_id'], $aData['grade'], $addClassName);
			if($aUserInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if($aUserInfo){
				alert('该班级已经存在了', 0);
			}else{
				for($j = 1; $j < 21; $j++){
					$aClassList1[] = $j . '班';
				}
				if(in_array($addClassName, $aClassList1)){
					alert('抱歉，该班级已经存在了！', 0);
				}
				$aData['class'] = $addClassName;
			}
		}

		if(isset($aSchoolInfo) && !$aSchoolInfo){
			//如果数据库中不存在用户添加的学校就创建
			$aSchoolData['type'] = '';
			$aData['school_id'] = $oUser->addSchool($aSchoolData);
			if($aData['school_id'] === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}

		$mClass = ClassRecord::findOne([
			'user_id' => $userId,
			'is_active' => ClassRecord::ACTIVE_CLASS_FLAG,
		]);
		if($mClass){
			$mClass->set('school_id', $aData['school_id']);
			$mClass->set('class', $aData['class']);
			$mClass->set('grade', $aData['grade']);
			$mClass->set('year', $aData['year']);
			$mClass->set('province_id', $aData['province_id']);
			$mClass->set('city_id', $aData['city_id']);
			$mClass->set('area_id', $aData['area_id']);
			$mClass->save();
		}else{
			//添加班级
			$classId = $oUser->addClass($aData);
			if($classId === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$classId){
				alert('学校信息填写失败', 0);
			}
		}
	}

	/**
	 * 抽奖页面2
	 * 动作：获取用户最近获奖信息、展示抽奖页面
	 */
	public function rotate(){
		$aUser = checkUserLogin(4);
		$aRotateList = m('User')->getUserLotteryDrawList($aUser['id']);
		$level = array(2=>'特等奖', 3=>'安慰奖', 4=>'一等奖', 5=>'二等奖', 6=>'三等奖');
		foreach ($aRotateList as $k=>$v){
			$v['lottery_draw_status_name'] = $level[$v['lottery_draw_status']];
			$aRotateList[$k] = $v;
		}
		assign('aRotateList', $aRotateList);
		display('account/register_process_header.html.php');
		display('account/perfect_user_rotate.html.php');
		display('account/register_process_footer.html.php');
	}

	/**
	 * 获取抽奖奖品2
	 * 动作：随机奖品、插入奖品、输出奖品信息到页面
	 */
	public function getRotateParameter(){
		$aUserInfo = checkUserLogin(5);
		$userId = $aUserInfo['id'];

		//奖品信息配置
		$aData = $GLOBALS['REGISTER_PRIZE'];

		$aUser = m('User');
		$rotateCount = $aUser->countUserPrize();

		//规则
		if($rotateCount[2] >= 1){
			$aData[0]['chance'] = 0;
		}
		if($rotateCount[4] >= 2){
			$aData[2]['chance'] = 0;
		}
		if($rotateCount[5] >= 3){
			$aData[3]['chance'] = 0;
		}
		if($rotateCount[6] >= 4){
			$aData[4]['chance'] = 0;
		}



		$aTarget = array(5,50,95,140,185,230,275,320);
		$aPrizes = array($aData[0], $aData[1], $aData[4], $aData[1], $aData[3], $aData[1], $aData[2], $aData[1]);

		//随机数
		$aChance = array();
		foreach($aData as $key=>$aPrize){
			$aChance[$key] = $aPrize['chance'];
		}
		$range = $this->_randChance($aChance);

		$rotateValue = $aTarget[$range];
		$aUserInfo = $aUser->getUserInfoByNumberId($userId);

		if( $aUserInfo['lottery_draw_status'] == 0 ){
			$aData = array(
				'id' => $userId,
				'lottery_draw_status' => $aPrizes[$range]['dbLevel'],
				'lottery_draw_time' => time()
			);

			if($aUser->setUserIndexInfo($aData) === false){
				alert('系统出错', 0);
			}

			$oNum = new Numerical();
			//经验
			if(!empty($aPrizes[$range]['numberClassPoints'])){
				if(!$oNum->addAccumulatePoints($userId, $aPrizes[$range]['numberClassPoints'])){
				}
			}
			//金币
			if(!empty($aPrizes[$range]['numberClassMoney'])){
				if(!$oNum->addMoney($userId, $aPrizes[$range]['numberClassMoney'])){
				}
			}

			alert('获取数据成功', 1, array('rotate_total'=>1,'rotate'=>$rotateValue,'index'=>$range,'greetings'=>'恭喜你！你抽中' . $aPrizes[$range]['pageLevel'],'prizes_status'=>'已获得' . $aPrizes[$range]['prizes']));
		}else{
			alert('帐号没有获取抽奖机会', 3);
		}
	}

	/**
	 *用户上传头像显示页面
	 */
	public function showUploadProfile(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$this->_checkUserProfile($userId);
		$oUser = m('User');
		$aPersonalInfo = $oUser->getPersonalInfoByUserId($userId);
		if($aPersonalInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aPersonalInfo){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($aPersonalInfo['gender'] == 1){
			$profileUrl = SYSTEM_RESOURCE_URL . '/' . USER_DEFAULT_PATH . 'male_300.jpg';
			$profileDataPath = 'male_300.jpg';
		}else{
			$profileUrl = SYSTEM_RESOURCE_URL . '/' . USER_DEFAULT_PATH . 'female_300.jpg';
			$profileDataPath = 'female_300.jpg';
		}
		displayHeader('上传头像 - 优满分(UMFun) - 游戏你的学习！');

		assign('profileUrl', $profileUrl);
		assign('profileDataPath', $profileDataPath);
		display('account/upload_profile.html.php');
	}

	public function skipUploadProfile(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$this->_checkUserProfile($userId);
		$oUser = m('User');
		$aPersonalInfo = $oUser->getPersonalInfoByUserId($userId);
		if($aPersonalInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aPersonalInfo){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($aPersonalInfo['gender'] == 1){
			$aData['profile'] = USER_DEFAULT_PATH . 'male_100.jpg';
		}else{
			$aData['profile'] = USER_DEFAULT_PATH . 'female_100.jpg';
		}
		$aData['id'] = $userId;
		$result = $oUser->setUserInfo($aData);
		if($result === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}else if($result){
			alert('保存初始头像成功!', 1, url('m=Account&a=showSchoolInfo'));
		}else{
			alert('保存失败!', 0);
		}
	}

	/**
	 * 图片上传
	 */
	public function uploadImage(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$twoNumberId = substr($userId, -2) . '/';
		$result['msg'] ='';
		$result['error'] ='';
		$filePrefix = str_replace(array('0.', ' '), '', microtime()) . '_' . rand(10000, 99999);
		$filePrefix = $userId;
		$oUploader = new UploadFile(2097152, 'gif,jpg,jpeg,png,bmp', '', SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $twoNumberId, $filePrefix . '_approve');
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			$result['msg'] = $oUploader->getErrorMsg();
			$result['error'] = 'error';
		}else{
			$uploadFileInfo =  $oUploader->getUploadFileInfo();
			$uploadFileInfo = $uploadFileInfo[0];
			$result['src'] = SYSTEM_RESOURCE_URL . '/' . USER_TMP_PATH . $twoNumberId .$uploadFileInfo['savename'];
			$size = @getimagesize(SYSTEM_RESOURCE_PATH . '/' . USER_TMP_PATH . $twoNumberId .$uploadFileInfo['savename']);
			$result['image_width'] = $size[0];
			$result['image_height'] = $size[1];
			$result['path'] = USER_TMP_PATH . $twoNumberId .$uploadFileInfo['savename'];
			$result['msg'] = '上传成功!';
		}
		exit(json_encode($result));
	}

	/**
	 * 修改头像页面
	 */
	 public function showSettingPicture(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$profileUrl = SYSTEM_RESOURCE_URL . '/' . $aUser['profile'];
        $approveInfo = $oUser->getUserApproveInfo($userId);
		if($approveInfo === false){
            alert('系统错误', 0);
		}
		$approveProfilePassTime = null;
		if($approveInfo && isset($approveInfo['content']['profile'])){
			if($approveInfo['content']['profile']['pass_time'] == 0 || $approveInfo['content']['profile']['pass_time'] == 1){
				$profileUrl = SYSTEM_RESOURCE_URL . '/' . $approveInfo['content']['profile']['content'];
				$approveProfilePassTime = $approveInfo['content']['profile']['pass_time'];
			}
		}
		unset($approveInfo);
        assign('type', 2);
		assign('approveProfilePassTime', $approveProfilePassTime);
		assign('profileUrl', $profileUrl);
		displayHeader('修改头像');
		display('account/setting_picture.html.php');
		displayLeftNav($userId);
		displayFooter();
	 }

	/**
	 * 修改头像处理
	 * 表单参数：x, y, w, h, cssWidth, cssHeight, pic
	 */
	public function editProfile(){
		User::editProfile();
	}

	/**
	 *用户填写学校信息页面
	 */
	public function showSchoolInfo(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$this->_checkUserSchoolInfo($userId);
		$oUser = m('User');
		$aPersonalInfo = $oUser->getPersonalInfoByUserId($userId);
		if($aPersonalInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aPersonalInfo){
			alert('用户信息获取失败，请稍后再试', 0);
		}
		$areaId = $aPersonalInfo['area_id'];
		$aCityInfo = $oUser->getAreaInfoByAreaId($areaId);
		if($aCityInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$cityId = $aCityInfo['pid'];
		$aProvinceInfo = $oUser->getAreaInfoByAreaId($cityId);
		if($aProvinceInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$provinceId = $aProvinceInfo['pid'];
		displayHeader('学校选择 - 优满分(UMFun) - 游戏你的学习！');
		assign('areaId', $areaId);
		assign('cityId', $cityId);
		assign('provinceId', $provinceId);
		assign('validateJs', j('schoolId,gradeId,className'));
		display('account/school_info.html.php');
		displayFooter();
	}

	/**
	 *根据地区id获取学校信息
	 */
	public function schoolInfo(){
		User::getSchoolListByAreaId();
	}

	/**
	 *获取班级信息2
	 */
	public function getClassData(){
		User::getClassListBySchoolId();
	}

	/**
	 *选择起始关卡
	 */
	public function showSelectStartMission(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$this->_checkSelectStartMission($userId);
		$oMission = m('Mission');
		$aSubject = $GLOBALS['SUBJECT'];
		$aMissionList = array();
		foreach($aSubject as $key=>$value){
			$aMissionList[$key] = $oMission->getOriginalMissionList($key, null, null);
		}
		displayHeader('关卡选择 - 优满分(UMFun) - 游戏你的学习！');
		assign('aMissionList', $aMissionList);
		assign('validateJs', j('chineseStartMission,englishStartMission,mathStartMission'));
		display('account/select_start_mission.html.php');
	}

	/**
	 *设置起始关卡处理
	 */
	public function selectStartMission(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$this->_checkSelectStartMission($userId);
		$vResult = v('chineseStartMission,englishStartMission,mathStartMission');
		if($vResult){
			alert($vResult, 0);
		}
		$oMission = m('Mission');
		$chineseStartMissionId = post('chineseStartMission');
		$englishStartMissionId = post('englishStartMission');
		$mathStartMissionId =  post('mathStartMission');

		$aChineseMissionInfo = $oMission->getMissionInfoById($chineseStartMissionId);
		$aEnglishMissionInfo = $oMission->getMissionInfoById($englishStartMissionId);
		$aMathMissionInfo = $oMission->getMissionInfoById($mathStartMissionId);
		if($aChineseMissionInfo === false && $aEnglishMissionInfo === false && $aMathMissionInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		if(!$aChineseMissionInfo){
			alert('设置的语文关卡不存在', 0);
		}
		if(!$aEnglishMissionInfo){
			alert('设置的语数学卡不存在', 0);
		}
		if(!$aMathMissionInfo){
			alert('设置的英语关卡不存在', 0);
		}
		$aMissionIds = array(
			'chinese' => $chineseStartMissionId,
			'english' => $englishStartMissionId,
			'math' => $mathStartMissionId
		);

		$missionUserId = $oMission->initUserMission($aMissionIds, $userId);
		if($missionUserId === false){
			alert('系统出错,请稍后再试', 0);
		}elseif(!$missionUserId){
			alert('设置起始关卡失败', 0);
		}

		$oUserNumerical = m('UserNumerical');
		$aData = array();
		$aData['id'] = $userId;
		$aData['level'] = 1;
		$aData['gold'] = 0;
		$aData['accumulate_points'] = 0;
		$aData['vip'] = 0;
		$addResult = $oUserNumerical->addUserNumerical($aData);
		if($addResult === false){
			alert('系统出错，请稍后再试', 0);
		}elseif(!$addResult){
			alert('插入用户数值表失败', 0);
		}
		$oSns = m('Sns');
		$probablyFriends = $oSns->cheakProbablyFriends($userId);
		if($probablyFriends === false){
			alert('系统出错，请稍后再试', 0);
		}
		alert('关卡初始化成功!', 1, url('m=Index&a=index'));
	}

	/**
	 * 修改密码页面
	 */
	 public function showSettingPassword(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		displayHeader('重置密码 - 优满分(UMFun) - 游戏你的学习！');
		assign('aUserInfo', $aUser);
		assign('type', 5);
		assign('userId', $userId);
		assign('validateJs', j('newPassword'));
		display('account/setting_password.html.php');
		displayLeftNav($userId);
		displayFooter();

	 }

	/**
	 * 修改密码处理
	 */
	public function settingPassword(){
		checkUserLogin();
		$mStudent = Yii::$app->student->identity;
		if($mStudent->isXxtUser()){
			alert('抱歉，修改密码功能暂未开放', 0);
		}
		if(!$mStudent->password){
			$vResult = v('newPassword');
		}else{
			$vResult = v('oldPassword,newPassword');
		}
		if($vResult){
			alert($vResult, 0);
		}
		$oldPassword = post('oldPassword');
		$newPassword = post('newPassword');

		if($mStudent->password && !$mStudent->matchPassword($oldPassword)){
			//已经有密码才校验旧密码
			alert('原密码错误', 0);
		}

		if($oldPassword == $newPassword){
			alert('新密码与旧密码相同', 0);
		}

		$mStudent->set('password', $mStudent->encryptPassword($newPassword));
		//更新密码
		if(!$mStudent->save()){
			throw Yii::$app->buildError('更新用户密码失败');
		}

		$aLoginInfo = Yii::$app->student->getLoginInfo($mStudent->id);
		if(!Yii::$app->student->login($mStudent, $aLoginInfo['remember_login_time'], true)){
			Yii::error('修改密码后重新登陆失败');
		}
		alert('更改成功');
	}

	/**
	 * 修改个人资料页面
	 */
	public function showSettingInformation(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($userId);
		if($aUserInfo === false){
			alert('系统错误', 0);
		}

		if($aUserInfo['birth_day'] != '1970-01-01'){
			$aBirthDay = explode('-', $aUserInfo['birth_day']);
			$constellation = $this->getConstellation($aBirthDay[1], $aBirthDay[2]);
			$aUserInfo['constellation'] = $constellation;
		}else{
			$aUserInfo['constellation'] = '未知';
		}

		$approveInfo = $oUser->getUserApproveInfo($userId);
		if($approveInfo === false){
			alert('系统错误', 0);
		}
		if($approveInfo && isset($approveInfo['content']['name'])){
			$aUserInfo['approve_name'] = $approveInfo['content']['name']['content'];
			$aUserInfo['approve_name_pass_time'] = $approveInfo['content']['name']['pass_time'];
		}
		unset($approveInfo);
		assign('type',1);
		displayHeader('个人资料 - 优满分(UMFun) - 游戏你的学习！');
		assign('userId', $userId);
		displayLeftNav($userId);
		assign('aUserInfo', $aUserInfo);
		assign('validateJs', j('username'));
		display('account/setting_information.html.php');
		displayFooter();
	}

	/**
	 * 撤销姓名或头像修改
	 */
	public function unSettingNameOrProfile(){
		$aUser = isLogin();
		$userId = $aUser['id'];
		$type = intval(post('type'));	//１＝撤销姓名修改；２＝撤销头像修改
		if($type != 1 && $type != 2){
			alert('数据错误', 0);
		}

		$oUser = m('user');
		$aApproveInfo = $oUser->getUserApproveInfo($userId);
		$aPersonalInfo = $oUser->getPersonalInfoByUserId($userId);
		if(!$aApproveInfo || !$aPersonalInfo){
			alert('系统错误', 0);
		}
		$aApproveData = array(
			'id' => $userId,
			'content' => array(),
		);

		if($type == 1 ){
			if(isset($aApproveInfo['content']['name']) && $aApproveInfo['content']['name']['pass_time'] == -1){
				if(isset($aApproveInfo['content']['profile'])){
					$aApproveData['content']['profile'] = $aApproveInfo['content']['profile'];
				}
			}else{
				alert('数据错误', 0);
			}
		}else{
			if(isset($aApproveInfo['content']['profile']) && $aApproveInfo['content']['profile']['pass_time'] == -1){
				if(isset($aApproveInfo['content']['name'])){
					$aApproveData['content']['name'] = $aApproveInfo['content']['name'];
				}
			}else{
				alert('数据错误', 0);
			}
		}
		$revocationResult = 0;
		if($aApproveData['content']){
			$revocationResult = $oUser->setUserInfoApprove($aApproveData);
		}else{
			$revocationResult = $oUser->deleteUserInfoApprove($userId);
		}
		if($revocationResult){
			if($type == 2){
				@unlink(SYSTEM_RESOURCE_PATH . $aApproveInfo['content']['profile']['content']);
			}
			alert('操作成功', 1);
		}else{
			alert('操作失败', 0);
		}
	}

	/**
	 * 导航我操
	 */
	/* public static function displayNav($type){
		assign('type', $type);
		display('account/nav.html.php');
	} */

	/**
	 * 修改用户信息处理页面
	 * (可选)表单参数：username, mobile, signature, detailedPlace, areaId, gender, year, month, day
	 */
	public function editUserInformation(){
		User::editUserInformation();
	}

	/**
	 * 修改游戏设置页面
	 */
	public function showGameSetting(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		displayHeader('游戏设置 - 优满分(UMFun) - 游戏你的学习！');
		assign('type', 6);
		assign('userId', $userId);
		assign('acceptPkCount', $this->_acceptPkCount);
		assign('aUserInfo', $aUserInfo);
		assign('validateJs', j('accept_pk_count'));
		display('account/game_setting.html.php');
		displayLeftNav($userId);
		displayFooter();

	}

	/*
	 * 游戏设置处理页面
	 */
	public function editGameSetting(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$vResult = v('accept_pk_count');
		if($vResult){
			alert($vResult, 0);
		}

		$oUser = m('User');

		$aData = array();
		$aData['id'] = $userId;
		$aData['accept_pk_count'] = intval(post('accept_pk_count'));

		$row = $oUser->setUserInfo($aData);
		if($row === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}else if($row){
			alert('更改成功');
		}else{
			alert('信息没有修改!', 0);
		}
	}

	public function showMobileSetting(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByNumberId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		displayHeader('绑定手机账号 - 优满分(UMFun) - 游戏你的学习！');
		assign('type', 7);
		assign('userId', $userId);
		assign('aUserInfo', $aUserInfo);
		assign('validateJs', j('mobile, captcha'));
		display('account/mobile_setting.html.php');
		displayLeftNav($userId);
		displayFooter();
	}
	/*
	public function showUserSetting(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByNumberId($userId);
		$aUserInfo2 = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if(!$aUserInfo2){
			alert('无效的用户id', -1);
		}

		$aUser = $oUser->getPersonalInfoByUserId($userId);
		assign('emailActive', $aUser['is_email_active']);

		displayHeader('用户设置 - 优满分(UMFun) - 游戏你的学习！');
		assign('userId', $userId);
		assign('aUserInfo', $aUserInfo);
		assign('email', $aUserInfo2['email']);
		assign('validateJs', j('mobile, captcha'));
		assign('validateJs2', j('oldPassword,newPassword','checkForm2'));
		assign('validateJs3', j('email','checkForm3', 'errorCallBackFunction'));
		display('account/user_setting.html.php');
		displayLeftNav($userId);
		displayFooter();
	}*/

	public function settingMobileAccount(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		//禁止和教育用户绑定手机账号
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if(!$aUserInfo){
			alert('系统出错，请稍后再试', 0);
		}
		alert('非常抱歉，绑定手机账号功能未开放', -1);
		if($aUserInfo['xxt_id']){
			alert('非常抱歉，绑定手机账号功能未开放', -1);
		}
		$mobile = post('mobile');
		$mobileCode = post('mobileCode');

		$vResult = v('mobile');
		if($vResult){
			alert($vResult, -1);
		}
		$isMobileCode = w('isNumber(6)', $mobileCode);
		if($isMobileCode != true){
			alert('手机校验码格式不正确！', -1);
		}

		$fgotCaptcha = post('captcha');
		if(!Verify::match('fgotCaptcha', $fgotCaptcha)){
			alert('验证码错误！', -1);
		}

		//验证码不存在
		$cookieName = Xxtea::xcrypt($mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('手机校验码错误', -1);
		}

		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('手机校验码错误', -1);
		}

		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('手机校验码错误', -1);
		}

		if($mobileCode != $verifyArray[0]){
			alert('手机校验码错误', -1);
		}

		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}

		$oUser = m('User');
		$isSetSuccess = $oUser->setUserIndexInfo(array('id' => $userId, 'mobile' => $mobile));
		if($isSetSuccess === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}
		alert('绑定手机成功！', 1);
	}

	//家长账户绑定
	public function showParentMobileSetting(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$oParent = m('Parent');
		$aParent = $oParent->getParentInfoByUserId($userId);
		if($aParent === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$aUserInfo = $oUser->getUserInfoByNumberId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($aUserInfo){
			$aUserInfo['mobile'] = substr($aUserInfo['mobile'],0,3) . '****'. substr($aUserInfo['mobile'],7);
		}
		displayHeader('游戏设置 - 优满分(UMFun) - 游戏你的学习！');
		assign('type', 8);
		assign('userId', $userId);
		assign('aParentInfo', $aParent);
		assign('aUserInfo', $aUserInfo);
		assign('validateJs', j('mobile'));
		display('account/parent_mobile_setting.html.php');
		displayLeftNav($userId);
		displayFooter();
	}

	public function settingParentMobileAccount(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$mobile = post('mobile');
		$mobileCode = post('mobileCode');
		$type = post('type',0);//大于0为修改绑定，0为绑定

		$vResult = v('mobile');
		if($vResult){
			alert($vResult, -1);
		}

		$oParent = m('Parent');
		//判断当前用户有没有绑定过这个手机号码
		$isAdd = 1;
		$aParent = $oParent->getParentInfoByMobile($mobile);
		if($aParent === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($aParent){
			if(in_array($userId, $aParent['user_ids'])){
				alert('你已经绑定过此手机!', -1);
			}else{
				$isAdd = 0;
			}
		}
		if($type){
			$isAdd = 0;
		}
		$isMobileCode = w('isNumber(6)', $mobileCode);
		if($isMobileCode != true){
			alert('手机校验码格式不正确！', -1);
		}

		//校验码不存在
		$cookieName = Xxtea::xcrypt('Parent' . $mobile);
		if(!Cookie::isSetted($cookieName)){
			alert('手机校验码错误', -1);
		}

		$verifyCookie = Cookie::getDecrypt($cookieName);
		if(!$verifyCookie){
			alert('手机校验码错误', -1);
		}

		$verifyArray = explode('|', $verifyCookie);
		if(!$verifyArray){
			alert('手机校验码错误', -1);
		}

		if($mobileCode != $verifyArray[0]){
			alert('手机校验码错误', -1);
		}

		if(time() > $verifyArray[1]){
			alert('手机校验码超时', -1);
		}

		$password = rand(10000000,99999999);
		//绑定成功后发送一条信息通知家长
		if($isAdd){
			$msgText = urlencode('您好，您在优满分系统成功绑定了'. $mobile .'的手机，您可以用手机号作为登陆账号登陆：http://' . APP_PARENT . '，登陆密码是：' . $password . '为了您的账号安全，请尽快登陆修改您的密码！');
		}else{
			//修改绑定手机号
			if($type){
				$msgText = urlencode('您好，您在优满分系统成功修改了手机号码:' . $mobile .'，您可以登陆：http://' . APP_PARENT . '，登陆密码是您原来的登陆密码，若忘记密码可以找回密码！');

			//不同子女绑定同一父亲
			}else{
				$msgText = urlencode('您好，您在优满分系统成功绑定了号码为' . $mobile .'的手机，您可以登陆：http://' . APP_PARENT . '，登陆账号就是您的手机号码，登陆密码是您原来的登陆密码！');
			}
		}
		$sendResult = sendMobileMessage($mobile, $msgText);
		if(!$sendResult){
			alert('短信发送失败，请重新绑定！',-1);
		}

		if($isAdd){
			$aData['mobile'] = $mobile;
			$aData['password'] = $password;
			$aData['create_time'] = time();
			$aData['user_ids'] = $userId;
			$isSetSuccess = $oParent->addParentInfo($aData);
		}else{
			if($type){
				$aData['mobile'] = $mobile;
				$where = array('id'=>$type);
			}else{
				$aData['user_ids'] = implode(',', $aParent['user_ids']) . ',' . $userId;
				$where = array('id'=>$aParent['id']);
			}

			$isSetSuccess = $oParent->setParentInfo($aData, $where);
		}
		if($isSetSuccess === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}elseif(!$isSetSuccess){
			alert('绑定或修改绑定失败！', -1);
		}else{
			alert('绑定手机成功！', 1);
		}
	}

	public function sendParentMobileVerify(){
		$oldMobile = post('oldMobile',0);
		$oParent = m('Parent');
		$mobile = post('mobile');
		//如果是修改手机号则验证旧手机号码
		if($oldMobile){
			$isMobile = w('isPhone()', $oldMobile);
			if(!$isMobile){
				alert('手机号码格式不正确', -1);
			}
			if($oldMobile == $mobile){
				alert('旧手机号码与新手机号码一致！', -1);
			}
			$aParent = $oParent->getParentInfoByMobile($oldMobile);
			if($aParent === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}elseif(!$aParent){
				alert('旧绑定手机号码不存在!', -1);
			}
		}
		$mobile = post('mobile');
		$userId = post('userId');
		$isMobile2 = w('isPhone()', $mobile);
		if(!$isMobile2){
			alert('手机号码格式不正确', -1);
		}

		//判断当前用户有没有绑定过这个手机号码
		$aParent = $oParent->getParentInfoByMobile($mobile);
		if($aParent === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($aParent){
			if(in_array($userId, $aParent['user_ids'])){
				alert('你已经绑定过此手机!', -1);
			}
		}

		$nextVerify =  Xxtea::xcrypt('nextVerify2');
		//验证发送验证码时间超过一分钟没
		if(Cookie::isSetted($nextVerify)){
			$nextTime = Cookie::getDecrypt($nextVerify);
			if(time() < $nextTime){
				alert('请稍后再试', 0);
			}
		}

		//取得6位数的手机验证码
		$time = str_replace('.', '', microtime(true));
		$start = rand(0, strlen($time)-6);
		$code = substr($time, $start, 6);
		$msgText = urlencode('您好，您在优满分系统申请绑定手机，的校验码是 ' . $code . '此码在十五分钟内有效，请在十五分钟内完成操作');
		$returnStatus = sendMobileMessage($mobile, $msgText);
		if($returnStatus > 0){
			//下次发送时间　60秒以后
			Cookie::setEncrypt($nextVerify , time()+60);

			$cookieName = Xxtea::xcrypt('Parent'.$mobile);
			$endTime = time()+900;
			Cookie::setEncrypt($cookieName, $code . '|' . $endTime);
			alert('校验码已发送，请及时查看手机短信以便完成操作！', 1);
		}else{
			alert('校验码发送失败，请重新发送！', -1);
		}

	}

	public function showForgotPassword(){
		displayHeader('找回密码 - 优满分(UMFun) - 游戏你的学习！');
		assign('validateJs', j('email,captcha'));
		display('account/forgot_password.html.php');
	}

	public function forgotPassword(){
		$vResult = v('email,captcha');
		if($vResult){
			alert($vResult, 0);
		}
		$fgotCaptcha = post('captcha');
		if(!Verify::match('fgotCaptcha', $fgotCaptcha)){
			alert('验证码错误！', 0);
		}

		//检测两次COOKIE有没有间隔30S
		$nextForgotTime =  Xxtea::xcrypt('nextForgotTime');
		if(Cookie::isSetted($nextForgotTime)){
			$nextForgotTime = Cookie::getDecrypt($nextForgotTime);
			if(time() < $nextForgotTime){
				alert('请在30S后再次发送', 0);
			}
		}


		$oUser = m('User');
		$email = strtolower(post('email'));
		$num = $oUser->isEmailExist($email);
		if($num === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}elseif($num){
			$aUserInfo = $oUser->getUserInfoByEmail($email);
			if($aUserInfo === false){
				alert('网络可能有点慢，请稍后再试!', 0);
			}elseif($aUserInfo){
				$aPersonalInfo = $oUser->getPersonalInfoByUserId($aUserInfo['id']);
				if($aPersonalInfo === false){
					alert('网络可能有点慢，请稍后再试', 0);
				}

				$nowTime = time();
				$endTime = $nowTime + 60 * 15;
				$addTwoTime = null;
				for($i = 0; $i < strlen($nowTime); $i++){
					$addTwoTime .= substr($nowTime, $i, 1);
					$addTwoTime .= substr($endTime, strlen($endTime)-$i-1, 1);
				}
				$addTwoTime .= $aUserInfo['id'];
				$addTwoTime = urlencode(base64_encode($addTwoTime));
				$aOptions = array(
					'to' => $email,
					'subject' => 'UMFun找回密码',
					'name' => isset($aPersonalInfo['name']) ? $aPersonalInfo['name'] : $aUserInfo['email'],
					'content' => '这是一封你在UMFun(优满分' . APP_HOME .')请求找回密码的响应邮件! 请在15分钟内点击以下链接来重新设置新密码：：' . url('m=Account&a=showResetPassword', 'action=' . $addTwoTime)
 . ', 如果以上链接无法打开，请复制以上网址并粘贴至浏览器手动打开！密码重设后请妥善保管并牢记，祝您心情愉快，谢谢！'
				);
				if(email($aOptions)){
					Cookie::setEncrypt($nextForgotTime , time()+30);
					$distinguish = strpos($email, '@');
					$email = substr_replace($email, '******', 1, $distinguish-1);
					alert('申请成功', 1, array('email' => $email));
				}else{
					alert('申请失败', 0);
				}
			}
		}else{
			alert('该邮箱不存在!', 0);
		}

	}

	public function showResetPassword(){
		$action = get('action');

		$aData = $this->_getNumberByAction($action, '找回密码');
		$numberId = $aData['id'];

		//数字账号存在验证W方法==================================================================
		$isNumber = w('isNumber(8)', $numberId);
		if(!$isNumber){
			alert('无效的数字账号', 0);
		}
		$oUser = m('User');

		$isNumberIdExist = $oUser->isNumberIdExist($numberId);
		if($isNumberIdExist === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}elseif(!$isNumberIdExist){
			alert('数字账号不存在!', 0);
		}

		$aUserInfo = $oUser->getUserInfoByNumberId($numberId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}elseif($aUserInfo){
			$email = $aUserInfo['email'];
		}else{
			alert('数字账号不存在!', 0);
		}
		displayHeader('找回密码 - 优满分(UMFun) - 游戏你的学习！');
		assign('isSuccess', 1);
		assign('validateJs', j('captcha'));
		assign('email', $email);
		display('account/reset_password.html.php');

	}



	public function resetPassword(){
		$vResult = v('password,captcha');
		if($vResult){
			alert($vResult, 0);
		}
		$resetCaptcha = post('captcha');
		if(!Verify::match('reCaptcha', $resetCaptcha)){
			alert('验证码错误！', 0);
		}
		$password = post('password');
		$enPassword = post('enPassword');
		if($password == $enPassword){
			$action = post('action');
			$aData = $this->_getNumberByAction($action, '找回密码');
			$numberId = $aData['id'];
			$isNumber = w('isNumber(8)', $numberId);
			if(!$isNumber){
				alert('无效的数字账号', 0);
			}

			$oUser = m('User');
			$isNumberIdExist = $oUser->isNumberIdExist($numberId);
			if($isNumberIdExist === false){
				alert('网络可能有点慢，请稍后再试!', 0);
			}elseif($isNumberIdExist){
				$result = $oUser->setUserPasswordByNumberId($numberId, $password);
				if($result === false){
					alert('网络可能有点慢，请稍后再试!', 0);
				}else{
					alert('修改成功', 1);
				}
			}

		}else{
			alert('两次输入的密码不一样', 0);
		}
	}

	/*
	 * 修改学校信息页面
	 */
	public function showSchoolList(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$aSchoolList = $oUser->getClassListByUserId($userId);
		$aUserInfo = $oUser->getUserDetailInfoByUserId($userId);

		$nowYear = date('Y');
		for($startYear = $nowYear; $startYear >= $this->_startYear; $startYear --){
			$aYears[] = $startYear;
		}
		assign('type', 3);
		assign('areaId', $aUserInfo['area_id']);
		assign('cityId', $aUserInfo['city_id']);
		assign('provinceId', $aUserInfo['province_id']);
		assign('aSchoolList', $aSchoolList);
		assign('aYears', $aYears);
		assign('validateJs', j('schoolId,gradeId,className,saveAreaId'));
		displayHeader('学校信息 - 优满分(UMFun) - 游戏你的学习！');
		assign('userId', $userId);
		display('account/school_list.html.php');
		displayLeftNav($userId);
		displayFooter();
	}

	/*
	 * 修改学校处理
	 */
	public function schoolList(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$vResult = v('schoolId,gradeId,className,saveAreaId');
		if($vResult){
			alert($vResult, 0);
		}

		//验证地区
		$areaId = post('saveAreaId');
		$oUser = m('User');
		$aAreaInfo = $oUser->getAreaInfoByAreaId($areaId);
		if($aAreaInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aAreaInfo){
			alert('非法的地区', 0);
		}

		$aData = array();
		$aData['user_id'] = $userId;
		$aData['school_id'] = intval(post('schoolId'));
		$schoolId = $aData['school_id'];
		if($schoolId != 0){
			$aSchoolInfo = $oUser->getSchoolInfoBySchoolId($schoolId);
			if($aSchoolInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$aSchoolInfo){
				alert('非法的学校', 0);
			}
		}
		$className = post('className');
		$addClassText = intval(post('addClassText'));
		if($className == '0班' && $addClassText){
			$aData['class'] = $addClassText . '班';
		}else{
			$aData['class'] = post('className');
		}
		$aData['grade'] = post('gradeId');
		$aData['year'] = post('year');

		$nowYear = date('Y');
		for($startYear = $this->_startYear; $startYear < $nowYear + 1; $startYear ++){
			$aYears[] = $startYear;
		}
		if(!in_array($aData['year'], $aYears)){
			alert('无效的年份', 0);
		}

		if($aData['class'] != 0){
			//验证班级是否存在
			$counts = $oUser->isClassExist($aData['year'], $schoolId, $aData['grade'], $aData['class']);
			if($counts === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$counts){
				for($j = 1; $j < 101; $j++){
					$aClassList[] = $j . '班';
				}
				if(!in_array($aData['class'], $aClassList)){
					alert('无效的班级', 0);
				}
			}

			$nums = $oUser->isClassExist($aData['year'], $schoolId, $aData['grade'], $aData['class'], $userId);
			if($nums === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}elseif($nums){
				alert('该学样记录已经添加过了', 0);
			}
		}



		$aData['is_active'] = 2;

		$num = $oUser->getClassListByUserIdAndYear($userId, $aData['year']);
		if($num === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if(count($num) > 1){
			alert('同一年份最多只可以存在两个学校或班级,请勿添加多余的班级', 0);
		}

		//如果学校id为0，则为添加学校
		if($schoolId == 0){
			//判断用户要添加的学校是不是存在
			$schoolName = post('addSchoolName');
			if(!$schoolName){
				alert('请添加学校!', 0);
			}

			$aSchoolData = array(
				'area_id' => $areaId,
				'name' => $schoolName,
			);

			$aSchoolInfo = $oUser->getSchoolInfoByAreaIdAndSchoolName($aSchoolData['area_id'] ,$aSchoolData['name']);
			if($aSchoolInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if($aSchoolInfo){
				alert('该学校已经存在了!', 0);
			}
		}

		//如果班级id为0，则为添加班级
		if($aData['class'] == 0){
			//判断用户要添加的班级存不存在
			$addClassName = post('addClassName');
			if(!$addClassName){
				alert('请写入有效的班级!', 0);
			}
			$addClassName = $addClassName . '班';
			$aUserInfo = $oUser->isClassExist($aData['year'], $schoolId, $aData['grade'], $addClassName);
			if($aUserInfo === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if($aUserInfo){
				alert('该班级已经存在了', 0);
			}else{
				for($j = 1; $j < 21; $j++){
					$aOriginalClassList[] = $j . '班';
				}
				if(in_array($addClassName, $aOriginalClassList)){
					alert('该班级已经存在了', 0);
				}
				$aData['class'] = $addClassName;
			}
		}

		if(isset($aSchoolInfo) && !$aSchoolInfo){
			//如果数据库中不存在用户添加的学校就创建
			$aSchoolData['type'] = '';
			$aData['school_id'] = $oUser->addSchool($aSchoolData);
			if($aData['school_id'] === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}

		//添加班级
		$classId = $oUser->addClass($aData);
		if($classId === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if($classId){
			alert('添加学校成功');
		}else{
			alert('添加学校失败', 0);
		}

	}

	/*
	 *设置当前班级
	 */
	public function actionClass(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$classId = post('classId');
		$oUser = m('User');
		$aClassInfo = $oUser->getClassInfoByClassId($classId);
		if($aClassInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aClassInfo){
			alert('无效的班级id', 0);
		}
		$result = $oUser->setActiveClass($userId, $classId);
		if($result === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$result){
			alert('设置当前班级失败', 0);
		}else{
			alert('设置成功', 1);
		}
	}

	/*
	 *修改邮件发送邮箱页面
	 */
	public function showSettingEmail(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if(!$aUserInfo){
			alert('无效的用户id', -1);
		}

		$aUser = $oUser->getPersonalInfoByUserId($userId);
		assign('type', 4);
		assign('aUserInfo', $aUserInfo);
		assign('emailActive', $aUser['is_email_active']);
		displayHeader('修改邮箱 - 优满分(UMFun) - 游戏你的学习！');
		assign('userId', $userId);
		assign('validateJs', j('email','checkForm', 'errorCallBackFunction'));
		assign('email', $aUserInfo['email']);
		display('account/send_email.html.php');
		displayLeftNav($userId);
		displayFooter();
	}

	public function activEmail(){
		$aUser = checkUserLogin();
		$userId = $aUser['id'];

		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if(!$aUserInfo){
			alert('无效的用户id', -1);
		}
		$action = post('action', '');
		if($action){
			$this->_getNumberByAction($action, '验证邮箱');
			$aData = array(
				'id' => $userId,
				'is_email_active' => 1
			);
			$result = $oUser->setUserInfo($aData);
			if($result){
				$oNum = new Numerical();
				$oNum->addMoney($userId, 3);

				alert('邮箱验证成功', 1);
			}else{
				alert('系统出错', 0);
			}
		}else{
			alert('参数错误', -1);
		}
	}

	/**
	 * 激活邮箱的邮件
	 * 表单参数：email, limit_captcha
	 */
	public function sendActiveEmail(){
		User::sendActiveEmail();
	}

	/*
	 *发送邮箱处理
	 */
	public function sendEmail(){
		$captcha = post('captcha');
		if(!Verify::match('sendMailCaptcha', $captcha)){
			alert('验证码错误！', -1);
		}

		$aUser = checkUserLogin();
		$userId = $aUser['id'];
		if($aUser['password']){
			$vResult = v('oldPassword,email');
		}else{
			$vResult = v('email');
		}
		if($vResult){
			alert($vResult, 0);
		}
		$oldPassword = post('oldPassword');
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo){
			alert('无效的用户id', 0);
		}


		//检测两次COOKIE有没有间隔30S
		/*
		$nextSendTime =  Xxtea::xcrypt('nextSendTime');
		if(Cookie::isSetted($nextSendTime)){
			$nextTime = Cookie::getDecrypt($nextSendTime);
			if(time() < $nextTime){
				alert('请稍后再试', 0);
			}
		}
		*/

		$aPersonalInfo = $oUser->getPersonalInfoByUserId($userId);
		if($aPersonalInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($aUser['password']){
			$aUserInfo2 = $oUser->getUserInfoByEmailAndPassword($aUserInfo['email'], $oldPassword);
			if($aUserInfo2 === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$aUserInfo2){
				alert('当前密码错误，请重新填写！', 0);
			}
		}
		$email = post('email');
		$result1 = $oUser->isEmailExist($email);
		if($result1 === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($result1){
			alert('抱歉，该邮箱已经被人注册过了', 0);
		}
		$nowTime = time();
		$endTime = $nowTime + 60 * 15;
		$addTwoTime = null;
		for($i = 0; $i < strlen($nowTime); $i++){
			$addTwoTime .= substr($nowTime, $i, 1);
			$addTwoTime .= substr($endTime, strlen($endTime) - $i - 1, 1);
		}
		$addTwoTime .= $aUserInfo['id'] . $email;
		$addTwoTime = urlencode(base64_encode($addTwoTime));

		$options = array(
			'to' => $email,
			'subject' => 'UMFun修改邮箱验证码',
			'name' => isset($aPersonalInfo['name']) ? $aPersonalInfo['name'] : $aUserInfo['email'],
			'content' => '这是一封你在UMFun(优满分 ' . APP_HOME . ')修改账号邮箱的响应邮件! 请在15分钟内点击以下链接来重新设置新邮箱：' . url('m=Account&a=showSettingAccount', 'action=' . $addTwoTime)
 . ', 如果以上链接无法打开，请复制以上网址并粘贴至浏览器手动打开！邮箱重设后请妥善保管并牢记，祝您心情愉快，谢谢！'
		);
		if(email($options)){
			//下次发送时间　30秒以后
			//Cookie::setEncrypt($nextSendTime , time()+30);
			alert('发送邮件成功');
		}else{
			alert('发送邮件失败', 0);
		}
	}

	/*
	 *设置邮箱页面
	 */
	 public function showSettingAccount(){
	 	$action = get('action');
		$aData = $this->_getNumberByAction($action, '修改邮箱账户');
		$userId = $aData['id'];
		$newEmail = $aData['email'];

		//数字账号存在验证
		$isNumber = w('isNumber(8)', $userId);
		if(!$isNumber){
			alert('无效的数字账号', 0);
		}
		$oUser = m('User');
		$isNumberIdExist = $oUser->isNumberIdExist($userId);
		if($isNumberIdExist === false){
			alert('网络可能有点慢，请稍后再试!', 0);
		}elseif(!$isNumberIdExist){
			alert('用户账号不存在!', 0);
		}

		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo){
			alert('无效的用户id', 0);
		}
		//debug($aUserInfo, 11);
		displayHeader('修改邮箱 - 优满分(UMFun) - 游戏你的学习！');
		assign('validateJs', j('oldPassword','checkForm', 'errorCallBackFunction'));
		assign('email', $aUserInfo['email']);
		assign('newEmail', $newEmail);
		display('account/setting_account.html.php');
	 }

	/*
	 *设置邮箱处理
	 */
	 public function settingAccount(){
	 	$vResult = v('oldPassword');
		if($vResult){
			alert($vResult, 0);
		}
		$action = post('action');
		$aDataAccount = $this->_getNumberByAction($action, '修改邮箱账户');
		$userId = $aDataAccount['id'];
		$isEmail = w('isEmail()', $aDataAccount['email']);
		if(!$isEmail){
			alert('邮箱格式错误', 0);
		}
		$oldPassword = post('oldPassword');
		$oUser = m('User');

		$result1 = $oUser->isEmailExist($aDataAccount['email']);
		if($result1 === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($result1){
			alert('抱歉，该邮箱已经被人注册过了', 0);
		}


		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo){
			alert('无效的用户id', 0);
		}
		$aUserInfo2 = $oUser->getUserInfoByEmailAndPassword($aUserInfo['email'], $oldPassword);
		if($aUserInfo2 === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo2){
			alert('当前密码错误，请重新填写！', 0);
		}
		$aData = array();
		$aData['id'] = $userId;
		$aData['email'] = $aDataAccount['email'];
		$row = $oUser->setUserIndexInfo($aData);
		if($row === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$row){
			alert('邮箱没有修改', 0);
		}

		$aData = array(
			'id' => $userId,
			'is_email_active' => 1
		);
		$oUserInvitation = m('UserInvitation');
		$aTask = $oUserInvitation->getUserNewTaskStatusInfo($userId);
		$aTask['new_task_process_status'] = explode(',', $aTask['new_task_process_status']);
		if($aTask['new_task_process_status'][4] == 0){
			$aTask['new_task_process_status'][4] = 1;
			$aNewTask = array(
				'id' => $userId,
				'new_task_process_status' => implode(',',$aTask['new_task_process_status']),
			);
			$oUserInvitation->setUserInvitation($aNewTask);
		}
		$result = $oUser->setUserInfo($aData);
		alert('邮箱修改成功！');
	 }

	public function settingEmailAccount(){
		$aUser = checkUserLogin();
		//禁止和教育用户设置邮箱
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($aUser['id']);
		if(!$aUserInfo){
			alert('系统出错，请稍后再试', 0);
		}
		if($aUserInfo['xxt_id']){
			alert('非常抱歉，设置邮箱功能未开放', -1);
		}
		if($aUser['password']){
			$vResult = v('oldPassword');
			if($vResult){
				alert($vResult, 0);
			}
		}
		$email = post('email');
		$userId = $aUser['id'];
		$isEmail = w('isEmail()', $email);
		if(!$isEmail){
			alert('邮箱格式错误', 0);
		}
		$oldPassword = post('oldPassword');
		$oUser = m('User');

		$result1 = $oUser->isEmailExist($email);
		if($result1 === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif($result1){
			alert('抱歉，该邮箱已经被人注册过了', 0);
		}


		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$aUserInfo){
			alert('无效的用户id', 0);
		}
		if($aUser['password']){
			$aUserInfo2 = $oUser->getUserInfoByNumberIdAndPassword($userId, $oldPassword);
			if($aUserInfo2 === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}else if(!$aUserInfo2){
				alert('当前密码错误，请重新填写！', 0);
			}
		}
		$aData = array();
		$aData['id'] = $userId;
		$aData['email'] = $email;
		$row = $oUser->setUserIndexInfo($aData);
		if($row === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if(!$row){
			alert('邮箱没有修改', 0);
		}

		$aData = array(
			'id' => $userId,
			'is_email_active' => 0
		);
		$result = $oUser->setUserInfo($aData);
		alert('邮箱修改成功！');
	}

	public function recommendFriendRegister(){
		$emailStr = intval(post('qq_friend_id'));
		if(!$emailStr){
			alert('QQ不正确！', -1);
		}

		$reuslt = limitCheck('SEND_EMAIL', $emailStr);
		if($reuslt){
			$row = limitAdd('SEND_EMAIL', $emailStr);
			if(!$row){
				alert('网络可能有点慢，请稍后再试', 0);
			}
		}else{
			alert('该QQ用户已经推荐过了哦', -1);
		}

		$emailStr .= '@qq.com';

		$result = preg_match('/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/', $emailStr);
		if(!$result){
			alert('QQ邮箱格式不正确！', -1);
		}
		$oUser = m('User');
		$num = $oUser->isEmailExist($emailStr);
		if($num === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}else if($num){
			alert('该QQ用户已加入UMFun！');
		}

		$aUserInfo = checkUserLogin();
		$userId = $aUserInfo['id'];
		$aUser = getUserInfo($userId, array('class'));
		$emailContent = 'Hey，我是【' . $aUser['name'] . '】，我正在UMFun（优满分）玩修炼和挑战闯关，在这里找到好多同学，就差你了，现在邀请你赶快加入进来和我一起玩，通过下面的网址注册后我们将会自动成为好友，还有一次免费抽奖机会哦，Come on! ' . url('m=Account&a=showLogin&action=register') . '?sf=' . $aUser['id'];
		$aEmailOption = array(
			'to' => $emailStr,
			'name' => '亲',
			'subject' => $aUser['school_name'] . $aUser['grade'] . '年级' . $aUser['class'] . '的同学集合了！',
			'content' => $emailContent
		);
		email($aEmailOption);
		alert('邀请好友请求发送成功！', 1);
	}

	/**
	 * 获取用户信息
	 * 表单参数：userId（可选，默认为当前登陆用户）
	 */
	public function getUserInfo(){
		User::getUserInfo();
	}

	/**
	 * 获取当前登陆用户好友列表
	 * @auther lichaoyu
	 * @type ajax
	 */
	public function getFriendList(){
		$aUser = checkUserLogin();
		$oSns = m('Sns');
		$aGroupLists = $oSns->getUserGroupList($aUser['id']);
		foreach($aGroupLists as $v){
			$aGroupLists[ $v['id'] ] = $v['group_name'];
		}

		$aFriendGroupLists = array();
		$aFriendDatas = $oSns->getUserFriendList($aUser['id'], 0, 0, 0);
		foreach($aFriendDatas as $v){
			$aFriendGroupLists[$aGroupLists[$v['group_id']]][] = $v;
		}
		alert('成功', 1, $aFriendGroupLists);
	}

	/**
	 *处理过的两个时间戳和数字账号还原回去
	 */
	private function _getNumberByAction($action, $titleText=''){
		$action = base64_decode(urldecode($action));
		$nowTime = time();
		$addTwoTime = substr($action, 0, strlen($nowTime) * 2);
		$aData = array();
		$aData['id'] = substr($action, strlen($nowTime) * 2, 8);
		$aData['email'] = substr($action, strlen($nowTime) * 2 + 8);
		$startTime = null;
		$endTime = null;
		for($i = 0; $i < strlen($addTwoTime); $i += 2){
			$startTime .= substr($addTwoTime, $i, 1);
			$endTime .= substr($addTwoTime, strlen($addTwoTime)-$i-1, 1);
		}
		if(!($nowTime > $startTime) || !($nowTime < $endTime)){
			assign('titleText', $titleText);
			displayHeader('链接过期  - ');
			display('account/note.html.php');
			exit();
		}else{
			return $aData;
		}
	}

	/**
	 *检查用户是否填过了个人信息
	 */
	private function _checkUserInformation($userId){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aUserInfo){
			alert('获取用户信息失败', 0);
		}
	}

	/**
	 *检查用户是否设置头像
	 */
	private function _checkUserProfile($userId){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aUserInfo){
			alert('获取用户信息失败', 0);
		}
	}

	/**
	 *检查用户是否填过了学校信息
	 */
	private function _checkUserSchoolInfo($userId){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aUserInfo){
			alert('获取用户信息失败', 0);
		}
	}

	/**
	 *检查用户是否设置了起始关卡信息
	 */
	private function _checkSelectStartMission($userId){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aUserInfo){
			alert('获取用户信息失败', 0);
		}
	}

	/**
	 *获取指定日期对应星座
	 * @param integer $month 月份 1-12
	 * @param integer $day 日期 1-31
	 * @return boolean|string
	 */
	private function getConstellation($month, $day){
		$day   = intval($day);
		$month = intval($month);
		if ($month < 1 || $month > 12 || $day < 1 || $day > 31){
			return false;
		}
		$signs = array(
			array('20'=>'水瓶座'),
			array('19'=>'双鱼座'),
			array('21'=>'白羊座'),
			array('20'=>'金牛座'),
			array('21'=>'双子座'),
			array('22'=>'巨蟹座'),
			array('23'=>'狮子座'),
			array('23'=>'处女座'),
			array('23'=>'天秤座'),
			array('24'=>'天蝎座'),
			array('22'=>'射手座'),
			array('22'=>'摩羯座')
		);
		list($start, $name) = each($signs[$month-1]);
		if ($day < $start)
		list($start, $name) = each($signs[($month-2 < 0) ? 11 : $month-2]);
		return $name;
	}

	//浏览更多关于UMfun页面，闯关，pk随机数据专用
	/*
	*函数作用：每秒刷新后两位随机数会根据秒数后两位变化，
	*每小时刷新随机数第二位会根据秒数的倒数第四位变化
	*适用于大于四位数的随机数
	*/
	private function rnd($start,$end){
		$now = time();
		//根据尾数的位数，确认截取时间的位数
		$length = strlen($end);
		$times = intval(substr($now, -($length - 1)));
		$times2 = intval(substr($now,-2));
		if($times2 < 30){
			$times2 = 130;
		}

		$rnd = rand(-$times2,$times2);
		$times += $rnd;
		$center = $end - $times;

		//得到数据的前两位数
		$start = intval(substr($start,0,2));
		$end = intval(substr($end,0,2));
		$center = intval(substr($center,0,2));

		//比较边界大小
		if($center < $start){
			$center =  $start;
		}elseif($center > $end){
			$center =  $end;
		}

		$bit = intval(substr('100000000000000',0,$length - 1));
		$times2 = $center * $bit + substr($times,-($length - 2));
		return $times2;
	}


	//新手任务
	public function getTaskStatus(){
		$aUser = checkUserLogin();
		$oUserInvitation = m('UserInvitation');
		$aTask = $oUserInvitation->getUserNewTaskStatusInfo($aUser['id']);
		if($aTask === false){
			alert('网络可能有点慢，请稍后再试！', -1);
		}
		$aMyTaskStatus = explode(',', $aTask['new_task_process_status']);
		alert('',1,$aMyTaskStatus);
	}

	public function showMoreIntroduce(){
		$oMatch = m('Match');
		$aCondition['status'] = 6;
		$matchCount = $oMatch->getMatchCount($aCondition);
		$oExchange = m('Exchange');
		$aCondition = array('release'=>2);
		$exchangeCount = $oExchange->getExchangeGoodsCount($aCondition);
		$missionCount = $this->rnd(15000,20000);
		$pkCount = $this->rnd(1000,1500);

		$aExchangeList = $oExchange->getRandExchangeRecordsList(4);
		$nowTime = time();
		$sevenBeforeTime = $nowTime - 7 * 86400;
		foreach($aExchangeList as &$aExchange){
			$aExchange['user_info'] = getUserInfo($aExchange['user_id']);
			$aExchange['create_time'] = mt_rand($sevenBeforeTime, $nowTime);
		}

		//浏览更多Umfun相关数据
		assign('matchCount', $matchCount);
		assign('exchangeCount', $exchangeCount);
		assign('missionCount', $missionCount);
		assign('pkCount', $pkCount);
		assign('aExchangeList', $aExchangeList);

		display('account/more_introduce.html.php');
	}

	public function showParentIntroduce(){
		display('account/parent_introduce.html.php');
	}

	public function showMastery(){
		display('account/mastery.html.php');
	}

	/**
	  *增加反馈信息
	  */
	public function feedback(){
		$userType = intval(post('user_type'));
		if($userType == 3){
			$_COOKIE['id'] = post('userId');
			$_COOKIE['parentAutoLogin'] = post('autoLogin');
			$_SERVER['HTTP_USER_AGENT'] = post('user_agent');
			$aUser = isParentLogin();
		}elseif($userType == 1){
			$_COOKIE['teacherId'] = post('userId');
			$_COOKIE['teacherAutoLogin'] = post('autoLogin');
			$_SERVER['HTTP_USER_AGENT'] = post('user_agent');
			$aUser = isTeacherLogin();
		}else{
			$_COOKIE['userId'] = post('userId');
			$_COOKIE['autoLogin'] = post('autoLogin');
			$_COOKIE['loginToken'] = post('loginToken');
			$aUser = isLogin();
		}
		if(post('remote_ip')){
			$_SERVER['REMOTE_ADDR'] = post('remote_ip');
		}
		if(post('client_ip')){
			$_SERVER['HTTP_CLIENT_IP'] = post('client_ip');
		}
		if(post('for_ip')){
			$_SERVER['HTTP_X_FORWARDED_FOR'] = post('for_ip');
		}

		if(!$aUser){
			$aUser['id'] = 0;
		}
		$aFeedBack = array(
			'type' => post('type'),
			'descript' => post('descript'),
			'user_id' => $aUser['id'],
			'name' => post('name'),
			'contact' => post('contact'),
			'user_type' => 2,
			'handled_status' => 0,
			'create_time' => NOW_TIME,
		);
		$row = m('Service')->addFeedback($aFeedBack);
		if($row === false){
			alert('系统错误，请稍后重试', 0);
		}elseif(!$row){
			alert('反馈失败', -1);
		}else{
			if(substr(DOMAIN_EXTEND, -3) == 'com'){
				$name = isset($aUser['name']) ? $aUser['name'] : $aFeedBack['name'];
				$aOptions = array(
					'to' => USER_APPROVER_EMIAL,
					'subject' => 'UMFun 用户反馈提醒！',
					'name' => USER_APPROVER_EMIAL,
					'content' => '有用户' . $name . 'ID为' . $aUser['id'] . ' 提交了反馈信息！<br /><a href="http://' . APP_MANAGE .'/?m=Service&a=showFeedBack" style="color:#f00;">立即前往</a>为其审核!',
				);
				email($aOptions);
			}
			alert('感谢您的反馈^-^ 我们将会尽快处理你的问题,必要的时候会联系你的哦', intval(post('ajax')), $row);
		}
	}

	public function loginParent(){
		User::loginParent();
		header('location:' . url('m=Parents&a=showHome', '', APP_PARENT));
	}

	public function sendWeiboWhenConditionMeet(){
		$aUser = checkUserLogin();
		$aUser = getUserInfo($aUser['id'], array('personal'));
		User::sendWeiboWhenConditionMeet($aUser['xxt_data']);
	}

	public function shareSignToClass(){
		$aUser = checkUserLogin();

		$content = post('content');
		$contentLength = ueGetLength($content);
		if($contentLength < 1 || $contentLength > 150){
			alert('内容为1到150个字符长度', 0);
		}

		$aUser = getUserInfo($aUser['id'], array('personal'));
		if(!$aUser['xxt_data']){
			alert('抱歉，您不是和教育用户！', 0);
		}
		$aXxtUserInfo = array();
		try{
			$aXxtUserInfo = Xxt::getStudentInfo($aUser['xxt_data']['UserId'], $aUser['xxt_data']['CityId']);
		}catch(XxtException $e){
			$e->log();
			alert('获取和教育学生信息失败：' . $e->getMessage(), 0);
		}

		$contentStr = $content;
		$aWeiboParams = array();
		$aWeiboParams['city_id'] = $aUser['xxt_data']['CityId'];
		$aWeiboParams['user_id'] = $aUser['xxt_data']['UserId'];
		$aWeiboParams['role_type'] = 2;
		$aWeiboParams['school_id'] = $aXxtUserInfo['StudentEntity']['SchoolId'];
		$aWeiboParams['class_id'] = $aXxtUserInfo['StudentEntity']['ClassId'];
		$aWeiboParams['content'] = $contentStr;
		$aWeiboParams['from_sys'] = 9;
		$aWeiboParams['msg_type'] = 2;
		$aWeiboParams['has_attachment'] = 0;
		try{
			$result = Xxt::addWeibo($aWeiboParams);
		}catch(XxtException $e){
			$e->log();
		}

		alert('分享成功！', 1);
	}

	//随机概率算法--专用于抽奖
	private function _randChance($aChance){
		$sum = array_sum($aChance);
		foreach($aChance as $key => $chance){
			$rand = mt_rand(1, $sum);
			if($rand <= $chance){
				$result = $key;
				break;
			}else{
				$sum -= $chance;
			}
		}
		unset($aChance);
		return $result;
	}

	public function getVipPrivitege(){
		$aUser = checkUserLogin();
		$now = time();
		//VIP每日礼包
		$oVip = m('Vip');
		$aVip = $oVip->getVipPrivitegeInfo($aUser['id']);
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($aUser['id']);
		$aUser = array_merge($aUser, $aUserNumerical);
		if($aUser['vip_expiration_time'] > $now && date('Ymd', $aVip['gifts_receive_time']) < date('Ymd', $now)){
			alert('fail', 0);
		}else{
			alert('success', 1);
		}
	}

	/*
	public function xxtLogin(){
		$token = get('token');
		$userId = get('UserId');
		$roleType = get('RoleType');
		$cityId = get('CityId');

		$oSoap = new SoapServer('cmccSOAP.wsdl');
		$time = date('Y-m-d H:i:s');
		$msgSeq = 'XXT_REQUEST_' . time();
		$aResult = $oSoap->CHK_LOGIN(array(
			'Version' => '1.04',
			'MsgSeq' => $msgSeq,
			'MsgType' => 'CHK_LOGIN',
			'TimeStamp' => $time,
			'PerformCode' => XXT_PERFORM_CODE,
			'Skey' => md5(XXT_PERFORM_CODE . $time . $msgSeq . 'CHK_LOGIN' . XXT_PLATFORM_KEY),
			'Body' => array(
				'UserId' => $userId,
				'RoleType' => $roleType,
				'CityId' => $cityId,
				'Token' => $token,
			),
		));

		$aUser;
	}
	*/
}