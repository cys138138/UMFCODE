<?php
/**
 * 原来SNS默认控制器
 * @author Administrator
 */
class ZoneController{
	private $_userId = '';

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	/**
	 * 个人中心首页 好友动态
	 * 个人中心
	 */
	public function showHome(){
		//验证要查看的用户是否存在
		$showUserId = intval(get('userId', $this->_userId));
		header('Location:' . url('m=Zone&a=showHome&userId=' . $showUserId));
		exit;
		$aUser = getUserInfo($showUserId);
		if(!$aUser){
			alert('该用户不存在', 0);
		}
		$aCurrentLoginUser = isLogin();
		$oNumerical = m('UserNumerical');
		$aCurrentNum = $oNumerical->getUserNumericalInfoById($aCurrentLoginUser['id']);
		if($aCurrentNum['vip_expiration_time'] < time()){
			$aCurrentNum['vip'] = 0;
		}
		$aCurrentLoginUser = array_merge($aCurrentLoginUser, $aCurrentNum);

		//读取勋章列表数据
		
		$aMedal = $oNumerical->getMedalListByUserIds(array($aUser['id']));
		$aMedalList = array();
		if($aMedal){
			$aMedal = $aMedal[0];
			if($aMedal['passed_missions'] >= $GLOBALS['PASSED_MISSIONS_MEDAL'][1]['nums']){
				$aMedalList[0]['name'] = $GLOBALS['MEDAL_EVENT'][2];
				$aMedalList[0]['img'] = $GLOBALS['MEDAL_IMG'][2];
			}
			if($aMedal['excellent_missions'] >= $GLOBALS['EXCELLENT_MISSIONS_MEDAL'][1]['nums']){
				$aMedalList[1]['name'] = $GLOBALS['MEDAL_EVENT'][3];
				$aMedalList[1]['img'] = $GLOBALS['MEDAL_IMG'][3];
			}
			if($aMedal['pk_win_times'] >= $GLOBALS['PK_WIN_MEDAL'][1]['nums']){
				$aMedalList[2]['name'] = $GLOBALS['MEDAL_EVENT'][6];
				$aMedalList[2]['img'] = $GLOBALS['MEDAL_IMG'][6];
			}
		}
		assign('aMedalList', $aMedalList);

		//读取最近8位PK的用户列表
		$aFriendIds = getUserFriendIds($aUser['id']);
		$oPk = m('Pk');
		$aPkUserList = $oPk->getNearestPkUserList(0, 1, 8, $aFriendIds, 0);
		if($aPkUserList == false){
			$aPkUserList = array();
		}
		assign('aPkUserList', $aPkUserList);

		//读取最近参加过的3场比赛
		$oMatch = m('Match');
		$aMatchList = $oMatch->getUserLatestMatchList($aUser['id'], 3);
		if($aMatchList == false){
			$aMatchList = array();
		}
		assign('aMatchList', $aMatchList);

		//读取最近9位访客
		assign('aVisitorList', $this->_setUserVisitors($showUserId, $aCurrentLoginUser['id']));
		//读取他的动态
			//先读出事件中要优先显示头像的用户列表
		$aFriendIds = getUserFriendIds($aCurrentLoginUser['id']);
		array_unshift($aFriendIds, $aCurrentLoginUser['id']);
		if(!in_array($aUser['id'], $aFriendIds)){
			array_unshift($aFriendIds, $aUser['id']);
		}
			//读事件
		$aEventList = getEventList(array($aUser['id']), $aFriendIds, array(), 1);
		assign('aEventList', $aEventList);

		assign('aUser', $aUser);
		assign('aCurrentLoginUser', $aCurrentLoginUser);
		displayHeader($aUser['name'] . '的主页');
		display('zone/home.html.php');
		displayFooter(true);
	}

	private function _getVisitorsList($visitorsList){
		$aVisitorInfo = array();
		$returnArray = array(
			'today_count' => $visitorsList['today_count'],
			'all_count' => $visitorsList['all_count'],
			'visitors' => array()
		);
		//取最近9位访客的信息出来
		$visiCount = 0;
		foreach($visitorsList['visitors'] as $userId => $visiTime){
			if($visiCount < 9){
				$aVisitorInfo = getUserInfo($userId);
				if($aVisitorInfo){
					$returnArray['visitors'][] = $aVisitorInfo;
					$visiCount++;
				}
			}else{
				break;
			}
		}
		return $returnArray;
	}


	//最近访客相关处理
	private function _setUserVisitors($userId, $visitorId){
		$oUserVisitors = m('UserVisitor');
		$aUserVisitorsArray = array();
		$aUserVisitorsArray = $oUserVisitors->getUserVisitorsById($userId);
		if($aUserVisitorsArray === false){
			return false;
		}

		if($userId == $visitorId){
			if(!$aUserVisitorsArray){
				return $aUserVisitorsArray;
			}else{
				return $this->_getVisitorsList($aUserVisitorsArray);
			}
		}else{
			$aData = array('id' => $userId);
			if(!$aUserVisitorsArray){
				$aData['today_count'] = 1;
				$aData['all_count'] = 1;
				$aData['visitors'] = array($visitorId => time());
				$result = $oUserVisitors->addUserVisitors($aData);
				if($result === false){
					return false;
				}else{
					return $this->_getVisitorsList($aData);
				}
			}else{
				$aData['all_count'] = $aUserVisitorsArray['all_count'] + 1;
				$aData['today_count'] = 1;
				if(date('Y-m-d', reset($aUserVisitorsArray['visitors'])) == date('Y-m-d', time())){
					$aData['today_count'] = $aUserVisitorsArray['today_count'] + 1;
				}

				if(isset($aUserVisitorsArray['visitors'][$visitorId])){
					if(date('Y-m-d', $aUserVisitorsArray['visitors'][$visitorId]) == date('Y-m-d', time())){
						$aData['all_count'] = $aUserVisitorsArray['all_count'];
						$aData['today_count'] = $aUserVisitorsArray['today_count'];
					}
					unset($aUserVisitorsArray['visitors'][$visitorId]);
				}

				$aData['visitors'] = array($visitorId => time());
				$i = 1;
				foreach($aUserVisitorsArray['visitors'] as $key => $aVisitors){
					if($i < 9){
						$aData['visitors'][$key] = $aVisitors;
					}else{
						if(date('Y-m-d', $aVisitors) == date('Y-m-d',time())){
							$aData['visitors'][$key] = $aVisitors;
						}
					}
					$i++;
				}
				unset($aUserVisitorsArray);
				$result = $oUserVisitors->setUserVisitors($aData);
				if($result === false){
					return false;
				}else{
					return $this->_getVisitorsList($aData);
				}
			}
		}
	}
	
	private function _getMedalEvent($aMedalProcess){
		$aMedalEventList = array();
		foreach($aMedalProcess as $key => $aHistory){
			$aLevel = array_keys($aHistory);
			$newLevel = $aLevel[(count($aLevel)-1)];
			$key = str_replace('_medal', '', $key);
			if($key == 'passed_missions'){
				$aMedalEventList[$aHistory[$newLevel]]['name'] = $GLOBALS['MEDAL_EVENT'][2];
			}elseif($key == 'excellent_missions'){
				$aMedalEventList[$aHistory[$newLevel]]['name'] = $GLOBALS['MEDAL_EVENT'][3];
			}elseif($key == 'pk_win_times'){
				$aMedalEventList[$aHistory[$newLevel]]['name'] = $GLOBALS['MEDAL_EVENT'][6];
			}
			$aMedalEventList[$aHistory[$newLevel]]['level'] = $newLevel;
		}
		return $aMedalEventList;
	}

}