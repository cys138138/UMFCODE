<?PHP
/*
 * 个人中心模块
 */
class MissionController{
	private $_userId = 0;
	private $_personalInfoStatus = array(0, 1, 2, 3, 4);
	private $_taskType = 7;
	private $_challengeType = 6;

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	/**
	 *可能认识的人
	 */
	public function getUserProbalyFriendList(){
		$oSns = m('Sns');
		$aShowId = post('show');
		if($aShowId){
			if(!is_array($aShowId)){
				alert('参数错误', -1);
			}
			foreach($aShowId as $id){
				if(!is_numeric($id)){
					alert('参数错误', -1);
				}
			}
		}else{
			$aShowId = array();
		}
		$oSns->cheakProbablyFriends($this->_userId);
		$aProbalyFriendList = $oSns->getUserRandProbablyList($this->_userId, 8, array(), $aShowId);
		alert('SUCESS', 1, $aProbalyFriendList);
	}

	/**
	 *显示个人关卡
	 */
	public function showMissionList(){
		$aSubject = $GLOBALS['SUBJECT'];
		$subjectId = intval(get('subject_id'));

		if(!$subjectId){
			$subjectId = Cookie::get('mission_list_subject_id');
		}

		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			$subjectId = 1;
		}
		$oMission = m('Mission');
		$aCurrentMissionPage = $oMission->getCurrentMissionPage($this->_userId, 14);
		if($aCurrentMissionPage === false){
			alert('系统出错，请稍后再试', 0);
		}
		//用户的当前关卡页码
		$aCurrentMissionInfo = $oMission->getCurrentMission($this->_userId);
		if($aCurrentMissionInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		if(!isset($aCurrentMissionInfo[$subjectId])){
			if(isset($aCurrentMissionInfo[1])){
				$subjectId = 1;
			}elseif(isset($aCurrentMissionInfo[2])){
				$subjectId = 2;
			}elseif(isset($aCurrentMissionInfo[3])){
				$subjectId = 3;
			}
		}
		if(!$aCurrentMissionInfo){
			alert('去设置关卡welcome页面', 2, url('m=Mission&a=showSelectStartMissionWelcome'));
		}elseif(!isset($aCurrentMissionInfo[$subjectId])){
			alert('去设置关卡init页面', 2, url('m=Mission&a=initMission&subject_id=' . $subjectId));
		}

		$cookieSubjectId = Cookie::get('mission_list_subject_id');
		if($cookieSubjectId != $subjectId){
			Cookie::set('mission_list_subject_id', $subjectId);
		}
		$aFriendList = getUserFriendIds($this->_userId);

		//我的勋章
		$aMyMissionMedal = $this->_getPkMedal();
		if($aMyMissionMedal === false){
			alert('系统错误', 0);
		}

		//我的生肖卡数量
		$oUserExtend = m('UserExtend');
		$aZodiacList = $oUserExtend->getUserGoodsInfo($this->_userId);
		if($aZodiacList === false){
			alert('网络可能有点慢！', 0);
		}elseif(!$aZodiacList){
			$aZodiacList['cards'] = array();
		}

		assign('aUserZodiacList', $aZodiacList['cards']);
		assign('zodiacNumber', count($aZodiacList['cards']));
		assign('aMyMissionMedal', $aMyMissionMedal);
		assign('aFriendList', $aFriendList);
		assign('userId', $this->_userId);
		assign('aSubject', $aSubject);
		assign('subjectId', $subjectId);
		assign('aCurrentMissionPage', $aCurrentMissionPage);

		displayHeader('学习关卡');
		display('mission/mission_list.html.php');
		displayLeftNav($this->_userId);
		displayFooter();
	}

	//侧边栏-勋章
	private function _getPkMedal(){
		$aMissionMedal = array();
		$oUserNumerical = m('UserNumerical');
		$aUserMedal = $oUserNumerical->getMedalInfoById($this->_userId);
		if($aUserMedal === false){
			return false;
		}

		$oNum = new Numerical();
		if($aUserMedal['excellent_missions'] >= $GLOBALS['EXCELLENT_MISSIONS_MEDAL'][1]['nums']){
			$aMissionMedal[1]['is_have'] = 1;
			$aMissionMedal[1]['img'] = $GLOBALS['MEDAL_IMG'][3];
			$aMissionMedal[1]['level'] = $oNum->countLevel(3, $aUserMedal['excellent_missions']);
			$aMissionMedal[1]['name'] = $GLOBALS['MEDAL_EVENT'][3];
			$aMissionMedal[1]['times'] = $aUserMedal['excellent_missions'];
			$aMissionMedal[1]['top_level'] = count($GLOBALS['EXCELLENT_MISSIONS_MEDAL']);
			if($aMissionMedal[1]['level'] < $aMissionMedal[1]['top_level']){
				$nextLevel = intval($aMissionMedal[1]['level']) + 1;
				$aMissionMedal[1]['next_level'] = $nextLevel;
				$aMissionMedal[1]['next_left_point'] = $GLOBALS['EXCELLENT_MISSIONS_MEDAL'][$nextLevel]['nums'] - $aMissionMedal[1]['times'];
			}
		}else{
			$aMissionMedal[1]['is_have'] = 0;
			$aMissionMedal[1]['img'] = $GLOBALS['RESOURCE']['no_excellent_mission_medal'];
			$aMissionMedal[1]['name'] = $GLOBALS['MEDAL_EVENT'][3];
			$aMissionMedal[1]['next_left_point'] = $GLOBALS['EXCELLENT_MISSIONS_MEDAL'][1]['nums'] - $aUserMedal['excellent_missions'];
		}

		if($aUserMedal['passed_missions'] >= $GLOBALS['PASSED_MISSIONS_MEDAL'][1]['nums']){
			$aMissionMedal[2]['is_have'] = 1;
			$aMissionMedal[2]['img'] = $GLOBALS['MEDAL_IMG'][2];
			$aMissionMedal[2]['level'] = $oNum->countLevel(2, $aUserMedal['passed_missions']);
			$aMissionMedal[2]['name'] = $GLOBALS['MEDAL_EVENT'][2];
			$aMissionMedal[2]['times'] = $aUserMedal['passed_missions'];
			$aMissionMedal[2]['top_level'] = count($GLOBALS['PASSED_MISSIONS_MEDAL']);
			if($aMissionMedal[2]['level'] < $aMissionMedal[2]['top_level']){
				$nextLevel = intval($aMissionMedal[2]['level']) + 1;
				$aMissionMedal[2]['next_level'] = $nextLevel;
				$aMissionMedal[2]['next_left_point'] = $GLOBALS['PASSED_MISSIONS_MEDAL'][$nextLevel]['nums'] - $aMissionMedal[2]['times'];
			}
		}else{
			$aMissionMedal[2]['is_have'] = 0;
			$aMissionMedal[2]['img'] = $GLOBALS['RESOURCE']['no_passed_mission_medal'];
			$aMissionMedal[2]['name'] = $GLOBALS['MEDAL_EVENT'][2];
			$aMissionMedal[2]['next_left_point'] = $GLOBALS['EXCELLENT_MISSIONS_MEDAL'][1]['nums'] - $aUserMedal['passed_missions'];
		}
		unset($aUserMedal);
		return $aMissionMedal;
	}

	public function showSelectStartMissionWelcome(){
		//检查用户是否可设置关卡
		$oMission = m('Mission');
		$aCurrentMissionInfo = $oMission->getCurrentMission($this->_userId);
		if($aCurrentMissionInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		if(isset($aCurrentMissionInfo[1]) || isset($aCurrentMissionInfo[2]) || isset($aCurrentMissionInfo[3])){
			$this->_checkSetMission($aCurrentMissionInfo);
		}

		//获取关卡个数和题目个数
		$missionTotalCount = $oMission->getUserMissionCount();
		$oEs = m('Es');
		$esTotalCount = $oEs->getOfficialEsCount();

		assign('missionTotalCount', $missionTotalCount);
		assign('esTotalCount', $esTotalCount * 11);
		displayHeader('设置关卡欢迎页面');
		display('mission/select_start_mission_welcome.html.php');
	}

	public function initMission(){
		$subjectId = intval(get('subject_id', 1));
		$oMission = m('Mission');
		$aSubject = $GLOBALS['SUBJECT'];
		$aCurrentMissionInfo = $oMission->getCurrentMission($this->_userId);
		if($aCurrentMissionInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		if(isset($aCurrentMissionInfo[1]) && isset($aCurrentMissionInfo[2]) && isset($aCurrentMissionInfo[3])){
			alert('您已经设置过关卡了哦！', 0);
		}
		if(isset($aCurrentMissionInfo[$subjectId])){
			alert('您已经设置过此关卡了哦！', 0);
		}
		$aMissionList = Mission::getSubjectGradeMissionList();

		$aUser = getUserInfo($this->_userId, array('class'));

		assign('userGrade', $aUser['grade'] ? $aUser['grade'] : 5);
		assign('subjectId', $subjectId);
		assign('aCurrentMissionInfo', $aCurrentMissionInfo);
		assign('aMissionList', $aMissionList);
		displayHeader('设置关卡欢迎页面');
		display('mission/mission_init.html.php');
	}

	/**
	 * 用户初始化关卡
	 */
	public function setSelectStartMission(){
		Mission::setSelectStartMission($this->_userId);
	}

	public function getChallengeRankList(){
		$page = intval(post('page', 1));
		$days = intval(post('days', 0));
		$pageSize = 8;

		if($page < 0 || $days < 0){
			alert('所传参数有误！',-1);
		}

		$oMission = m('Mission');
		if($days == 7){
			$monDay = strtotime(date('Y-m-d', time() - ((date('w') == 0 ? 7 : date('w')) - 1) * 86400));
			$aRankingList = $oMission->getPassMissionCountRankingList($page, $pageSize, 0, $monDay, time());
		}else{
			$aRankingList = $oMission->getPassMissionCountRankingList($page, $pageSize, $days);
		}

		if($aRankingList === false){
			alert('系统出错，请稍后再试', 0);
		}

		if($page > 1 && !$aRankingList){
			alert('已经是最后一页了哦！',-1);
		}

		foreach($aRankingList as $key=>$aRanking){
			$aRankingList[$key]['rankNum'] = ($page - 1) * $pageSize + 1 + $key;
		}

		alert('', 1, $aRankingList);
	}

	public function getChallengeEventList(){

	}

	/**
	 *选择起始关卡
	 */
	public function showSelectStartMission(){
		$this->_checkSelectStartMission($this->_userId);
		$oMission = m('Mission');
		$aSubject = $GLOBALS['SUBJECT'];
		$aMissionList = array();
		foreach($aSubject as $key=>$value){
			$aMissionList[$key] = $oMission->getOriginalMissionList($key, null, null);
		}
		displayHeader('设置关卡');
		assign('aMissionList', $aMissionList);
		assign('validateJs', j('chineseStartMission,englishStartMission,mathStartMission'));
		display('mission/select_start_mission.html.php');
		displayFooter();
	}

	/**
	 *设置起始关卡处理
	 */
	public function selectStartMission(){
		$this->_checkSelectStartMission($this->_userId);
		$vResult = v('chineseStartMission,englishStartMission,mathStartMission');
		if($vResult){
			alert($vResult, 0);
		}
		$oMission = m('Mission');
		$chineseStartMissionId = post('chineseStartMission');
		$englishStartMissionId = post('englishStartMission');
		$mathStartMissionId =  post('mathStartMission');

		$aChineseMissionInfo = $oMission->getMissionInfoById($chineseStartMissionId);
		$aEnglishMissionInfo = $oMission->getMissionInfoById($englishStartMissionId);
		$aMathMissionInfo = $oMission->getMissionInfoById($mathStartMissionId);
		if($aChineseMissionInfo === false && $aEnglishMissionInfo === false && $aMathMissionInfo === false){
			alert('系统出错，请稍后再试', 0);
		}
		if(!$aChineseMissionInfo){
			alert('设置的语文关卡不存在', 0);
		}
		if(!$aEnglishMissionInfo){
			alert('设置的语数学卡不存在', 0);
		}
		if(!$aMathMissionInfo){
			alert('设置的英语关卡不存在', 0);
		}
		$aMissionIds = array(
			'chinese' => $chineseStartMissionId,
			'english' => $englishStartMissionId,
			'math' => $mathStartMissionId
		);

		$missionUserId = $oMission->initUserMission($aMissionIds, $this->_userId);
		if($missionUserId === false){
			alert('系统出错,请稍后再试', 0);
		}elseif(!$missionUserId){
			alert('设置起始关卡失败', 0);
		}

		alert('关卡初始化成功!', 1);
	}

	public function getMissionList(){
		$page = intval(get('page'));
		$subjectId = intval(get('subject_id'));
		if(!array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('非法的科目', 0);
		}
		$oMission = m('Mission');
		$aMissionList = $oMission->getUserMissionList($this->_userId, $subjectId, $page);
		if($page < 0){
			$aMissionList = array_reverse($aMissionList);
		}
		alert('', 1, array('mission_list' => $aMissionList));
	}

	/**
	 *显示关卡练习
	 */
	public function showExecuteMission(){
		$oMission = m('Mission');
		//读出关卡信息
		$missionId = intval(get('id'));
		//$missionId = 1;
		$aMission = $oMission->getMissionInfoById($missionId);
		if(!$aMission){
			wrong('关卡不存在');
		}
		assign('aMission', $aMission);
		$aMyMission = $oMission->getUserMissionInfo($missionId, $this->_userId);
		if(!$aMyMission){
			$lastestMissionOrder = $oMission->getLastDeblockingMissionOrders($this->_userId, $aMission['subject_id']);
			if($aMission['orders'] <= $lastestMissionOrder){
				$aNewUserMission = array();
				$aNewUserMission['user_id'] = $this->_userId;
				$aNewUserMission['mission_id'] = $missionId;
				$aNewUserMission['is_task_finish'] = 0;
				$aNewUserMission['task_finish_time'] = 0;
				$aNewUserMission['is_pass'] = 0;
				$aNewUserMission['es_count'] = 0;
				$aNewUserMission['es_correct_count'] = 0;
				$aNewUserMission['score'] = 0;
				$aNewUserMission['create_time'] = time();
				$aNewUserMission['pass_time'] = 0;
				$aNewUserMission['best_score_time'] = 0;
				$aNewUserMission['last_es_id'] = 0;
				$aNewUserMission['task_process'] = 0;
				$aNewUserMission['current_challenge_process'] = array();
				$aNewUserMission['challenge_history'] = array();
				if(!$oMission->addUserMission($aNewUserMission)){
					wrong('网络可能有点慢');
				}
				$aMyMission = $aNewUserMission;
			}else{
				wrong('您还不能进入该关卡喔');
			}
		}

		assign('aMyMission', $aMyMission);
		$doEsCount = $aMyMission['task_process'];	//当前对的题目数
		assign('doEsCount', $doEsCount);
		assign('esCount', $aMission['task_content']['correct_counts']);

		//题目数据
		$aEs = Mission::getNextEsInfo($missionId, 'exercise', array(0), $this->_userId);
		if($aEs == 5 || $aEs == 8){
			alert('抱歉,网络可能有点慢,请联系管理员', 0);
		}
		assign('aEs', $aEs);
		$aDefaultReason = $GLOBALS['ES_WRONG_REASON'][$aMission['subject_id']];
		assign('defaultReason', $aDefaultReason);
		assign('userId', $this->_userId);
		displayHeader();
		display('mission/mission_execute.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	/**
	 *	获取下一条题目信息
	 *	表单参数：mission_id, from, do_ids
	 */
	public function getNextEs(){
		Mission::getNextEs($this->_userId);
	}

	/**
	 *显示挑战
	 */
	public function showMissionChallenge(){
		$oMission = m('Mission');
		//读出关卡信息
		$missionId = intval(get('id'));
		//$missionId = 1;
		$aMission = $oMission->getMissionInfoById($missionId);
		if(!$aMission){
			alert('关卡不存在', 0);
		}
		/*$oUser = m('User');
		$aScoreList = array();
		foreach($aMission['recent_record'] as $key => $aRecord){
			$aScoreList[$key] = $aRecord['score'];
			$aUserInfo = $oUser->getPersonalInfoByUserId($aRecord['user_id']);
			if($aUserInfo){
				$aMission['recent_record'][$key]['name'] = $aUserInfo['name'];
				$aMission['recent_record'][$key]['avatar'] = $aUserInfo['profile'];
			}
		}
		//按照分数升序排列
		array_multisort($aScoreList, SORT_DESC, $aMission['recent_record']);
		debug($aMission['recent_record']);*/


		$aRankingList = $oMission->getTopScoreUserListByMissionId($missionId, 1, 10);
		if($aRankingList === false){
			alert('网络可能有点慢', 0);
		}
		$aScoreList = array();
		foreach($aRankingList as $aRanking){
			$aTemp = array();
			$aTemp['user_id'] = $aRanking['user_id'];
			$aTemp['pass_time'] = $aRanking['best_score_time'];
			$aTemp['score'] = $aRanking['score'];
			$aTemp['name'] = $aRanking['user_info']['name'];
			$aTemp['avatar'] = $aRanking['user_info']['profile'];
			$aScoreList[] = $aTemp;
		}
		unset($aRanking);
		unset($aRankingList);
		unset($aTemp);
		$aMission['recent_record'] = $aScoreList;
		unset($aScoreList);
		assign('aMission', $aMission);

		$aMyMission = $oMission->getUserMissionInfo($missionId, $this->_userId);

		if(!$aMyMission){
			alert('您还不能进入该关卡喔亲！', 0);
		}
		assign('aMyMission', $aMyMission);

		$aMissoinInfo = $oMission->getMissionInfoById($aMyMission['mission_id']);
		if(!$aMissoinInfo){
			alert('关卡不存在', 0);
		}
		$aNextMission = $oMission->getNextMissionInfo($aMissoinInfo['subject_id'], $aMissoinInfo['orders']);
		if($aNextMission){
			assign('nextMissionId', $aNextMission['id']);
		}else{
			assign('nextMissionId', 0);
		}

		$aEsList = $oMission->getRandomEsListForChallenge($aMission['category_ids'], $aMission['challenge_es_count']);
		if(!$aEsList){
			alert('该关卡下没有题目', 0);
		}
		assign('allEsCount', count($aEsList));

		$oWenwen = m('Wenwen');
		$aIdList = array();
		foreach($aEsList as $key => $aEs){
			$aIdList[] = $aEs['id'];
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
			$aEsList[$key]['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
			$aEsList[$key]['es_content'] = $oEsPlugin->removeAnswer($aEsList[$key]['es_content']);
			$aEsList[$key]['comment_count'] = $oWenwen->getCommentCount($aEs['id']);
			unset($aEsList[$key]['content_text']);
		}
		shuffle($aEsList);

		$aIds = array();
		foreach($aEsList as $aEs){
			$aIds[] = $aEs['id'];
		}

		$aEs = $aEsList[0];
		$now = time();
		$aEs['cs'] = Xxtea::encrypt($now);
		Cookie::set('ct', md5($now));
		$aEs['id'] = Xxtea::encrypt($aEs['id']);
		assign('aEs', $aEs);
		$aDefaultReason = $GLOBALS['ES_WRONG_REASON'][$aMission['subject_id']];
		assign('defaultReason', $aDefaultReason);
		assign('userId', $this->_userId);
		//本班排行
		$aFriendClassRanking = $this->_getClassRankByMissionId($aMyMission['mission_id']);
		assign('aClassRank', $aFriendClassRanking);
		$aUser = getUserInfo($this->_userId, array('personal', 'class'));
		assign('aUser', $aUser);
		
		displayHeader();

		if($aMyMission['is_task_finish']){
			$aMissionCount = array();
			$aMissionCount['id'] = $aMission['id'];
			$aMissionCount['challenge_count'] = $aMission['challenge_count'] + 1;
			if(!$oMission->setMission($aMissionCount)){
				wrong('网络可能有点慢');
			}

			$aUserMissionCount = array();
			$aUserMissionCount['id'] = $aMyMission['id'];
			if(!$aMyMission['create_time']){
				$aUserMissionCount['create_time'] = time();
			}
			$aChallengeProcess = array();
			$aChallengeProcess['life'] = $aMission['challenge_limit_blood'];
			$aChallengeProcess['time'] = 0;
			foreach($aEsList as $key => $aEs){
				$aChallengeProcess['es_list'][$aEs['id']] = $aEs;
			}
			$aChallengeProcess['rightEsCount'] = 0;
			$aUserMissionCount['current_challenge_process'] = $aChallengeProcess;
			if($oMission->setUserMission($aUserMissionCount) === false){
				alert('网络可能有点慢', 0);
			}
			display('mission/mission_challenge.html.php');
		}else{
			echo '<script type="text/javascript">UBox.show("对不起，您挑战之前必须完成练习");</script>';
			display('mission/mission_execute.html.php');
		}
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	/**
	 *显示关卡PK
	 */
	public function showPkMission(){
		$oMission = m('Mission');
		$missionId = intval(get('id'));
		$aMission = $oMission->getMissionInfoById($missionId);
		if(!$aMission){
			alert('关卡不存在', 0);
		}
		$aMyMission = $oMission->getUserMissionInfo($missionId, $this->_userId);
		if(!$aMyMission){
			alert('关卡不存在', 0);
		}
		if(!$aMyMission || $aMyMission['is_pass'] != 1){
			alert('您还不能PK些关卡哦!', -1);
		}

		$oPk = m('Pk');
		$aPkStat = $oPk->getUserMissionPkStatistics($this->_userId, $missionId);
		if($aPkStat === false){
			alert('程序执行错误，请稍后重试', 0);
		}

		$aPkRankList = $oPk->getPkRankingList(1, 8, array(), $missionId);
		if($aPkRankList === false){
			alert('程序执行错误，请稍后重试', 0);
		}

		$aPkEventList = $oPk->getPkEventListByMissionId($missionId, 1, 10);
		if($aPkEventList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		$aSendPkCountRankList = $oPk->getUserSendPkRankingList($missionId, 1, 8);
		if($aSendPkCountRankList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		assign('aPkEventList', $aPkEventList);
		assign('aSendPkCountRankList', $aSendPkCountRankList);
		assign('aPkStat', $aPkStat);
		assign('aPkRankList', $aPkRankList);
		assign('aMission', $aMission);
		assign('userId', $this->_userId);
		displayHeader();
		display('mission/mission_pk.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	/*
	* 生肖卡列表
	*/
	public function getZodiacList(){
		$oUserExtend = m('UserExtend');
		$aZodiacList = $oUserExtend->getUserGoodsInfo($this->_userId);
		if($aZodiacList === false){
			alert('网络可能有点慢！', 0);
		}

		if(!isset($aZodiacList['cards'])){
			$aUserGoods = array(
				'id' => $this->_userId,
				'cards' => array()
			);
			$result = $oUserExtend->addUserGoods($aUserGoods);
			if(!$result){
				alert('网络可能有点慢！请重新抽奖！', -1);
			}
			$aZodiacList = $oUserExtend->getUserGoodsInfo($this->_userId);
			if($aZodiacList === false){
				alert('网络可能有点慢！', 0);
			}
		}

		foreach($aZodiacList['cards'] as $key => $zodiac){
			$aZodiacContentList['content'][$zodiac - 1]['is_have'] = 1;
		}

		$aZodiacContentList = array(
			'content' => array(),
			'zodiac_count' => 12 - count($aZodiacList['cards']),
		);

		foreach(array(
			'mouse',
			'cow',
			'tiger',
			'rabbit',
			'long',
			'snake',
			'horse',
			'sheep',
			'monkey',
			'chicken',
			'dog',
			'pig',
		) as $i => $zodiacItem){
			$aZodiacContentList['content'][] = array(
				'name' => $zodiacItem,
				'is_have' => in_array($i + 1, $aZodiacList['cards']),
			);
		}

		alert('', 1, $aZodiacContentList);
	}

	/**
	 * 判断练习作答结果
	 * 表单参数：mission_id, user_answer[id], user_answer[type], user_answer[answer][], ts
	 */
	public function markingUserExerciseAnswer(){
		Mission::markingUserExerciseAnswer($this->_userId, $this->_taskType);
	}


	/*
	* 修炼完成--抽奖(生肖卡)
	*/
	public function lotteryDrawForZodiac(){
		Mission::lotteryDrawForZodiacPC($this->_userId);
	}

	/**
	 * 判断挑战作答结果
	 * 表单参数：mission_id, user_answer[id], user_answer[type], user_answer[answer][], cs
	 */
	public function markingUserChallengeAnswer(){
		Mission::markingUserChallengeAnswer($this->_userId, $this->_challengeType);
	}


	/*
	* 挑战完成抽奖(金币，经验，道具)
	*/
	public function lotteryDrawForNumerical(){
		//检测有没有抽奖的机会
		$missionId = intval(post('missionId',0));
		if(!$missionId){
			alert('非法参数！', -1);
		}

		$oMission = m('Mission');
		$aMissionInfo = $oMission->getUserMissionInfo($missionId, $this->_userId);
		if(!$aMissionInfo){
			alert('不存在此关卡哦！', -1);
		}

		if($aMissionInfo['is_pass'] != 1){
			alert('你还没有闯过这关卡哦！', -1);
		}

		if($aMissionInfo['lottery_draw_status'] > 1){
			alert('这一关你已经抽过奖了哦！', -1);
		}

		//奖品信息配置
		$aPrizeList = $GLOBALS['NUMERICAL_PRIZE'];

		//转盘位置配置
		$count = count($aPrizeList);
		$aTarget = array();
		$aTarget = array(
			3 => mt_rand(5, 40),
			6 => mt_rand(50, 85),
			1 => mt_rand(95, 130),
			2 => mt_rand(140, 175),
			4 => mt_rand(185, 220),
			6 => mt_rand(230, 265),
			2 => mt_rand(275, 310),
			5 => mt_rand(320, 355)
		);


		//随机数
		$aChance = array();
		foreach($aPrizeList as $aPrize){
			$aChance[$aPrize['rank']] = $aPrize['chance'];
		}
		$rand = $this->_randChance($aChance);

		//计算转盘位置
		$rotateValue = $aTarget[$rand];


		$oProp = m('Prop');
		$aGoods = array();
		//如果是抽到道具
		if($rand == 2){
			$aPropList = $oProp->getRandomPropInfo();
			if(!$aPropList){
				alert('抱歉！网络可能有点慢，请重新抽奖!', -1);
			}
			$aGoods['prop']['id'] = $aPropList['id'];
			$aGoods['prop']['name'] = $aPropList['name'];
			$aGoods['prop']['img'] = $aPropList['ico'];
		}else{
			//更新用户得奖信息
			$aGoods = $aPrizeList[$rand - 1]['prize'];
		}

		if($aGoods === false){
			alert('抱歉！网络可能有点慢，请重新抽奖!', -1);
		}

		if($aGoods){
			$aData = array('id' => $this->_userId);
			$oUserNumerical = m('UserNumerical');
			$existsNumerical = false;
			$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
			if(!$aUserNumerical){
				alert('抱歉！网络可能有点慢，请重新抽奖!', -1);
			}
			if(isset($aGoods['gold'])){
				$aData['gold'] = $aGoods['gold'] + $aUserNumerical['gold'];
				$GLOBALS['UPDATE']['numerical_data']['gold'] = $aData['gold'];
				$existsNumerical = true;
			}

			if(isset($aGoods['points'])){
				$aData['accumulate_points'] = $aGoods['points'] + $aUserNumerical['accumulate_points'];
				$GLOBALS['UPDATE']['numerical_data']['accumulate'] = $aData['accumulate_points'];
				$existsNumerical = true;
			}

			if($existsNumerical){
				$result = $oUserNumerical->setUserNumerical($aData);
				if(!$result){
					alert('抱歉！网络可能有点慢,请重新抽奖!', -1);
				}
			}

			if(isset($aGoods['prop'])){
				$aUserPropInfo = $oProp->getUserPropInfo($this->_userId);

				if($aUserPropInfo === false){
					alert('抱歉！网络可能有点慢,请重新抽奖!', -1);
				}elseif(!$aUserPropInfo){
					$aUserPropInfo = array(
						'id' => $this->_userId,
						'prop_package' => 15
					);
					$result = $oProp->addUserProp($aUserPropInfo);
					if(!$result){
						alert('抱歉！网络可能有点慢,请重新抽奖!', -1);
					}
				}

				$aUserPropInfo['props'][] = $aGoods['prop']['id'];
				$result = $oProp->setUserProp($aUserPropInfo);
				if(!$result){
					alert('抱歉！网络可能有点慢,请重新抽奖!', -1);
				}


			}
		}

		//更新领奖状态
		$oMission->setUserMission(array(
			'id'=>$aMissionInfo['id'],
			'lottery_draw_status' => 3
		));

		unset($aMissionInfo);
		alert('success', 1, array(
			'rotateValue' => $rotateValue,
			'rank' => $rand,
			'prize' => $aGoods
		));
	}


	/**
	 *本关战绩分析
	 */
	public function showMissionAnalysis(){
		$missionId = intval(get('id'));
		if(!$missionId){
			wrong('关卡ID错误');
		}

		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $this->_userId);
		if(!$aMyMission){
			wrong('关卡不存在');
		}
		if(!$aMyMission['is_pass']){
			wrong('该关卡还没通关');
		}
		$aMyMission['score'] = $aMyMission['score'] / 100;
		foreach($aMyMission['challenge_history'] as $key => $aHistory){
			$aMyMission['challenge_history'][$key]['score'] = $aMyMission['challenge_history'][$key]['score'] / 100;
		}
		assign('aMyMission', $aMyMission);

		$aMission = $oMission->getMissionInfoById($aMyMission['mission_id']);
		assign('aMission', $aMission);

		$oEs = m('Es');
		$aWrongEsList = $oEs->getUserWrongEsList($this->_userId, 1, 5, 0, 0, 0, $aMyMission['mission_id']);
		assign('aWrongEsList', $aWrongEsList);

		$oSns = m('Sns');
		$userIds = $oSns->getUserFriendIds($this->_userId);
		if($userIds){
			$userIds .= ',' . $this->_userId;
		}else{
			$userIds = $this->_userId;
		}
		$aFriendRanking = $oMission->getTopScoreUserListByMissionIdAndUserIds($aMyMission['mission_id'], explode(',', $userIds));
		foreach($aFriendRanking as $key => $aFriend){
			if($this->_userId == $aFriend['user_id']){
				$friendRanking = $key + 1;
				break;
			}
		}
		assign('friendRanking', $friendRanking);
		assign('aFriendRanking', $aFriendRanking);

		$aWorldRanking = $oMission->getTopScoreUserListByMissionId($missionId, 1, 10);
		assign('aWorldRanking', $aWorldRanking);
		$defeatPercent = $oMission->getDefeatedPercent($aMyMission['mission_id'], $aMyMission['score'] * 100);
		assign('defeatPercent', $defeatPercent);
		assign('myUserId', $this->_userId);
		//本班排行
		$aFriendClassRanking = $this->_getClassRankByMissionId($aMyMission['mission_id']);
		assign('aClassRank', $aFriendClassRanking);
		$aUser = getUserInfo($this->_userId, array('personal', 'class'));
		assign('aUser', $aUser);

		displayHeader();
		display('mission/mission_analysis.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}
	
	private function _getClassRankByMissionId($missionId){
		$oMission = m('Mission');
		$aUser = getUserInfo($this->_userId, array('personal', 'class'));
		$oUser = m('User');
		$aCondition = array(
			'year' => $aUser['year'],
			'school_id' => $aUser['school_id'],
			'grade' => $aUser['grade'],
			'class' => $aUser['class'],
			'is_active' => 1
		);
		$aClassList = $oUser->getClassListByCondition($aCondition);
		if($aClassList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$aClassUserIds = array();
		foreach($aClassList as $key => $value){
			array_push($aClassUserIds, $value['user_id']);
		}
		$aFriendClassRanking = $oMission->getTopScoreUserListByMissionIdAndUserIds($missionId, $aClassUserIds);
		if($aFriendClassRanking === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		
		return $aFriendClassRanking;
	}

	/**
	 * 根据科目id获取关卡列表
	 * 表单参数: subjectId, page, from_mission_list
	 */
	public function getUserMissionList(){
		Mission::getUserMissionList($this->_userId);
	}

	//得到用户的当前关卡--jose
	public function getUserCurrentMission(){
		$oMission = new MissionModel();//
		//当前关卡
		$pageSize = 10;
		$count = $oMission->getMissionCount(1);
		$pageCount = ceil($count / $pageSize);
		echo $pageCount;
		$b = $oMission->getCurrentMission($this->_userId);

		//$a = $oMission->getMissionList($this->_userId, 1, 1, 100);
		//$this->_userId, 1, 20, 10
		$userId = $this->_userId;
		$subjectId = 1;
		$page = 20;
		$pageSize = 10;
		$a = $oMission->getUserMissionList($this->_userId, $subjectId, $page, $pageSize);
		foreach($a as &$x){
			//if($x['can_enter'] == 2){echo $x['id'];}

		}
		//当前页关卡
		//if(isset($a[1])){echo 'xx';}
		var_dump($a);
	}

	/**
	 * 根据获取某关卡详细信息
	 * 表单参数: subjectId, mission_id
	 */
	public function getUserMissionDetail(){
		Mission::getUserMissionDetail($this->_userId);
	}

	/**
	 *检查作答格式
	 */
	private function _getStarByPoint($point){

		if($point < 5600){
			return 0;
		}
		for($i = 5; $i >= 1; $i--){
			$starPoin = 5600 + ($i - 1) * 1000;
			if($point >= $starPoin){
				return $i;
			}
		}
	}

	/**
	 *检查用户是否设置了起始关卡信息
	 */
	private function _checkSelectStartMission($userId){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserInfoByUserId($userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aUserInfo){
			alert('获取用户信息失败', 0);
		}
	}


	private function _checkSetMission($aCurrentMissionInfo){
		if(isset($aCurrentMissionInfo[1]) && isset($aCurrentMissionInfo[2]) && isset($aCurrentMissionInfo[3])){
			alert('您已经设置过关卡了哦！', 0);
		}elseif(!isset($aCurrentMissionInfo[1])){
			header('Location:' . url('m=Mission&a=initMission&subject_id=1', '', APP_HOME));
			return;
		}elseif(!isset($aCurrentMissionInfo[2])){
			header('Location:' . url('m=Mission&a=initMission&subject_id=2', '', APP_HOME));
			return;
		}elseif(!isset($aCurrentMissionInfo[3])){
			header('Location:' . url('m=Mission&a=initMission&subject_id=3', '', APP_HOME));
			return;
		}
	}

	//随机概率算法--专用于抽奖
	private function _randChance($aChance){
		$sum = array_sum($aChance);
		foreach($aChance as $key => $chance){
			$rand = mt_rand(1, $sum);
			if($rand <= $chance){
				$result = $key;
				break;
			}else{
				$sum -= $chance;
			}
		}
		unset($aChance);
		return $result;
	}

}
