<?php
/**留言板控制器
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-8-12
 * Time: 下午2:00
 * To change this template use File | Settings | File Templates.
 */
class GuestBookController{
	private $_userId = 0;

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}

	public function showGuestBook(){
		$myUserId = $this->_userId;
		$userId = intval(get('userId', $myUserId));
		$page = intval(get('page', 1));
		$pageSize = 10;

		$aUser = getUserInfo($userId, array('personal'));
		$aMyUser = getUserInfo($this->_userId, array('personal'));
		if(!$aUser){
			alert('页面不存在', 0);
		}
		if($page < 1){
			$page = 1;
		}

		$oSns = m('Sns');
		$count = $oSns->getSnsPublicMessageCount($userId);
		if($count === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		$pageUrl = url('m=GuestBook&a=showGuestBook&page=_PAGE_');
		$aPage = array(
			'url' => $pageUrl,
			'total' => $count,
			'page' => $page,
			'size' => 10,
			'subs' => 5,
			'onclick' => '',
			'overview' => '',
			'selector' => '',
			'labels' => array(
				'first'		=>	'首页',
				'previous'	=>	'上一页',
				'next'		=>	'下一页',
				'last'		=>	'尾页',
			),
		);
		$oPage = new Pagination($aPage);

		assign('page', $page);
		assign('total', $count);
		assign('userId', $userId);
		assign('myUserId', $myUserId);
		assign('aUser', $aUser);
		assign('aMyUser', $aMyUser);
		assign('pageBarHtml', $oPage->fetch());
		displayHeader();
		display('guestbook/message.html.php');
		displayFooter(true);
	}

	/**
	 * 读取留言列表
	 */
	public function getGuestBookList(){
		$userId = intval(post('user_id'));
		$page = intval(post('page'));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 10;

		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('无效用户id', 0);
		}
		$oSns = m('Sns');
		$count = $oSns->getSnsPublicMessageCount($userId);
		if($count === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		//取10条记录
		$aMessageList = $oSns->getSnsPublicMessageListByUserId($userId, $page, $pageSize);
		if($aMessageList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		//如果是自己的流言和接收者就允许回复
		foreach($aMessageList as $key => &$aMessage){
			if($this->_userId == $aMessage['sender_user_id'] || $this->_userId == $aMessage['user_id']){
				$aMessage['is_allow'] = true;
			}else{
				$aMessage['is_allow'] = false;
			}
			$aMessage['floor_num'] = ($page - 1) * $pageSize + ($key + 1);
			$aMessage['create_time'] = date('n月d日 H:i', strtotime($aMessage['create_time']));
			if($aMessage['child']){
				foreach($aMessage['child'] as $k => $aChild){
					$aMessage['child'][$k]['create_time'] = date('n月d日 H:i', strtotime($aChild['create_time']));
				}
			}
		}
		alert('留言列表', 1, $aMessageList);
	}

	/**
	 * 读取最近留言的用户列表
	 */
	public function getLastMessageUserList(){
		$userId = intval(post('user_id'));

		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('无效用户id', 0);
		}
		$aLastMessageUserList = m('Sns')->getLatestSendPublicMessgeUserList($userId);
		if($aLastMessageUserList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		alert('最近留言用户列表', 1, $aLastMessageUserList);
	}

	/**
	 * 读取最新回复的列表
	 */
	public function getLastMessageReplyList(){
		$userId = intval(post('user_id'));

		$aUser = getUserInfo($userId, array('area', 'class', 'personal'));
		if(!$aUser){
			alert('无效用户id', 0);
		}
		$aLastMessageReplyList = m('Sns')->getLatestPublicMessgeCommentList($userId);
		if($aLastMessageReplyList === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		foreach($aLastMessageReplyList as &$aLastMessageReply){
			$aLastMessageReply['create_time'] = date('n月d日 H:i', $aLastMessageReply['create_time']);
		}
		alert('最近留言列表', 1, $aLastMessageReplyList);
	}

	//回复
	public function reply(){
		if(limitCheck('SNS')){
			limitAdd('SNS');
		}
		$aParam = array(
			'parent_id' => intval(post('parent_id')) ? intval(post('parent_id')) : 0,
			'user_id' => intval(post('user_id')),
			'sender_user_id' => $this->_userId,
			'content' => ueEncodeContent(post('content')),
			'create_time' => time(),
		);

		if(!getUserInfo($aParam['user_id'])){
			alert('该用户不存在', 0);
		}
		if(!$aParam['content']){
			alert('留言不能为空', 0);
		}
		$contentLength = ueGetLength(post('content'));
		if($contentLength < 1 || $contentLength > 150){
			alert('留言内容为1到150个字符长度', 0);
		}

		$oSns = m('Sns');
		if($aParam['parent_id']){
			$aMessage = $oSns->getSnsPublicMessageInfoById($aParam['parent_id']);
			if(!$aMessage || $aMessage['parent_id'] || ($aMessage['sender_user_id'] != $this->_userId && $aMessage['user_id'] != $this->_userId)){
				alert('非法的回复请求', 0);
			}
		}

		$messageId = $oSns->addSnsPublicMessage($aParam);
		if($messageId === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($messageId){
			$aParam['id'] = $messageId;
			alert($aParam['parent_id'] ? '回复留言成功' : '发表留言成功', 1, $aParam);
		}else{
			$aParam['parent_id'] == 0 ? alert('发表留言失败，请重新提交你的留言', -1) : alert('回复留言失败，请重新提交你的留言', -1);
		}
	}

	public function delete(){
		$id = intval(post('id'));
		if(!$id){
			alert('数据不能为空', 0);
		}
		$oSns = m('Sns');
		$aMessage = $oSns->getSnsPublicMessageInfoById($id);
		if($aMessage === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}
		if($aMessage){
			if($aMessage['user_id'] != $this->_userId && $aMessage['sender_user_id'] != $this->_userId){
				alert('无权限删除', 0);
			}
			$type = 8;
			$isReply = 0;
			if($aMessage['parent_id'] != 0){
				$type = 9;
				$isReply = 1;
			}
			$result = $oSns->deleteSnsPublicMessage($id, $isReply);
			if($result === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}
			if($result){
				$oPersonalMessage = m('personalMessage');

				$delResult = $oPersonalMessage->deletePersonalMessage(0, $aMessage['user_id'], $type, $id);
				if($delResult === false){
					alert('网络可能有点慢，请稍后再试', 0);
				}
				alert('删除留言成功');
			}else{
				alert('删除留言失败，请重新操作', 0);
			}
		}else{
			alert('留言不存在', 0);
		}
	}

	public function getAllReply(){
		$messageId = intval(post('id'));
		$oSns = m('Sns');
		$aMessage = $oSns->getSnsPublicMessageInfoById($messageId);
		if(!$aMessage){
			alert('所请求的留言不存在', 0);
		}elseif($aMessage['parent_id']){
			//该留言不是一个根节点
			alert('抱歉,数据出错', 0);
		}
		$aReplyList = $oSns->getAllPublicMessage($messageId);
		if($aReplyList === false){
			alert('抱歉，网络可能有点慢', 0);
		}
		$aResult = array();
		foreach($aReplyList as $aReply){
			$aUser = getUserInfo($aReply['sender_user_id']);

			$aResult[] = array(
				'id' => $aReply['id'],
				'content' => $aReply['content'],
				'time' => $aReply['create_time'],
				'user' => array(
					'id' => $aUser['id'],
					'name' => $aUser['name'],
					'profile' => SYSTEM_RESOURCE_URL . $aUser['profile'],
				),
			);
		}
		alert('读取成功', 1, $aResult);
	}
}