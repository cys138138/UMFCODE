<?php
class ExchangeController{
	private $_userId = 0;
	const VIP_DISCOUNT1 = 0.95;	//普通会员折扣
	const VIP_DISCOUNT2 = 0.85;	//白金会员折扣
	const VIP_DISCOUNT3 = 0.82;	//钻石会员折扣
	const DAYS_DISCOUNT = 0.7;	//双蛋节折扣

	public function __construct(){
		if(get('a') != 'index' && get('a') != 'getGoodsList'){
			header('location:' . url('m=Exchange&a=showList'));
			myLog('居然还有人回来兑换商城!');
			exit;
			$aUser = checkUserLogin();
			$this->_userId = $aUser['id'];
		}
	}

	public function showList(){
		$showType = get('type', 'all');
		$goodsId = intval(get('goodsId'));

		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($goodsId);
		if($aGoods === false){
			alert('系统出错，请稍后再试!', 0);
		}
		if($aGoods){
			assign('initGoodsId', $goodsId);
		}

		$aRecommandList = $oExchange->getExchangeGoodsList(array('recommand' => 1, 'release' => 2), 1, 3, '`recommand_time` DESC');
		if($aRecommandList === false){
			alert('系统出错，请稍后再试!', 0);
		}

		$aExchangingList = $oExchange->getRandExchangeRecordsList(30);
		if($aExchangingList === false){
			alert('系统出错，请稍后再试!', 0);
		}
		foreach($aExchangingList as $key => $aExchanging){
			$aExchangingList[$key]['user_info'] = getUserInfo($aExchanging['user_id'], array('personal'));
		}

		$aExchangeRankingList = $oExchange->getExchangeGoodsList(array('release' => 2), 1, 10, '`sales_volume` DESC');
		if($aExchangeRankingList === false){
			alert('系统出错，请稍后再试!', 0);
		}

		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('系统出错，请稍后再试!', 0);
		}
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			alert('系统出错，请稍后再试!', 0);
		}
		$aUserInfo = array_merge($aUserInfo, $aUserNumerical);

		assign('aUserInfo', $aUserInfo);
		assign('aRecommandList', $aRecommandList);
		assign('aExchangeRankingList', $aExchangeRankingList);
		assign('aExchangingList', $aExchangingList);
		assign('userId', $this->_userId);
		assign('showType', $showType);
		displayHeader('兑换商城');
		display('exchange/list.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	public function index(){
		$title = '兑换商城 - ' . TITLE;
		$oExchange = m('Exchange');
		$aRecommandList = $oExchange->getExchangeGoodsList(array('recommand' => 1, 'release' => 2), 1, 3, '`recommand_time` DESC');
		if($aRecommandList === false){
			alert('系统出错，请稍后再试!', 0);
		}

		$aHotList = $oExchange->getExchangeGoodsList(array('release' => 2), 1, 3, 4);
		if($aHotList === false){
			alert('系统出错，请稍后再试!', 0);
		}
		assign('isLogin', isLogin() ? 1 : 0);
		assign('title', $title);
		assign('aRecommandList', $aRecommandList);
		assign('aHotList', $aHotList);
		display('exchange/index.html.php');
		displayFooter();
	}

	public function getGoodsList(){
		$page = intval(post('page', 1));
		$pageSize = 12;
		$order = intval(post('orders'));

		if($order == 1){
			$orderStr = '`orders` DESC';
		}elseif($order == 2){
			$orderStr = '`gold` ASC';
		}elseif($order == 3){
			$orderStr = '`level` ASC';
		}elseif($order == 4){
			$orderStr = '`sales_volume` DESC';
		}elseif($order == 5){
			$orderStr = '`support` DESC';
		}elseif($order == 6){
			$orderStr = '`create_time` DESC';
		}else{
			$orderStr = '`orders` DESC';
		}

		$aCondition = array('release' => 2);
		$oExchange = m('Exchange');
		$aGoodsList = $oExchange->getExchangeGoodsList($aCondition, $page, $pageSize, $orderStr);
		if($aGoodsList === false){
			alert('系统出错，请稍后再试!', 0);
		}
		$now = time();
		foreach($aGoodsList as $key => $aGoods){
			if(!$aGoods['rush_time'] || $now > $aGoods['rush_time'] + 3600){	//除了抢购商品外的打折商品
				$date = date('md');
				$day = date('d');
				if(($date >= 1223 && $date <= 1225) || ($date >= 101 && $date <= 103)){	//双蛋节7折
					$aGoodsList[$key]['original_gold'] = $aGoodsList[$key]['gold'];
					$aGoodsList[$key]['gold'] = intval($aGoodsList[$key]['gold'] * self::DAYS_DISCOUNT);
				}elseif($day == 20){	//每月20、30号开启折扣
					$aUser = isLogin();
					if($aUser){
						$oUserNumerical = m('UserNumerical');
						$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($aUser['id']);
						if($aUserNumerical && $aUserNumerical['vip_expiration_time'] > $now){
							if($aUserNumerical['vip'] == 1){
								$discount = self::VIP_DISCOUNT1;
							}elseif($aUserNumerical['vip'] == 2){
								$discount = self::VIP_DISCOUNT2;
							}elseif($aUserNumerical['vip'] == 3){
								$discount = self::VIP_DISCOUNT3;
							}else{
								alert('数据出错', 0);
							}
							$aGoodsList[$key]['original_gold'] = $aGoodsList[$key]['gold'];
							$aGoodsList[$key]['gold'] = intval($aGoodsList[$key]['gold'] * $discount);
						}
					}
				}
			}
		}
		alert('兑换物品列表', 1, $aGoodsList);
	}

	public function getGoodsDetail(){
		$goodsId = intval(get('goods_id'));

		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($goodsId);
		if($aGoods === false){
			alert('系统出错，请稍后再试!', 0);
		}
		if(!$aGoods){
			alert('兑换物品不存在!', -1);
		}else{
			/*$aUserIds = getUserFriendIds($this->_userId);
			if($aUserIds){
				$aGoods['exchange_friends_list'] = $oExchange->getUserListByGoodsId($goodsId, $aUserIds);
			}else{
				$aGoods['exchange_friends_list'] = array();
			}
			*/
			$aGoods['exchange_user_list'] = $oExchange->getUserListByGoodsId($goodsId, array(), 1, 9);
			if($aGoods['exchange_user_list'] === false){
				alert('系统出错，请稍后再试!', 0);
			}
		}

		$now = time();
		if(!$aGoods['rush_time'] || $now > $aGoods['rush_time'] + 3600){	//除了抢购商品外的打折商品
			$date = date('md');
			$day = date('d');
			if(($date >= 1223 && $date <= 1225) || ($date >= 101 && $date <= 103)){	//双蛋节7折
				$aGoods['original_gold'] = $aGoods['gold'];
				$aGoods['gold'] = intval($aGoods['gold'] * self::DAYS_DISCOUNT);
			}elseif($day == 20){	//每月20、30号开启折扣
				$oUserNumerical = m('UserNumerical');
				$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
				if($aUserNumerical && $aUserNumerical['vip_expiration_time'] > $now){
					if($aUserNumerical['vip'] == 1){
						$discount = self::VIP_DISCOUNT1;
					}elseif($aUserNumerical['vip'] == 2){
						$discount = self::VIP_DISCOUNT2;
					}elseif($aUserNumerical['vip'] == 3){
						$discount = self::VIP_DISCOUNT3;
					}else{
						alert('数据出错', 0);
					}
					$aGoods['original_gold'] =$aGoods['gold'];
					$aGoods['gold'] = intval($aGoods['gold'] * $discount);
				}
			}
		}

		$aCondition = array(
			'release' => 2,
			'recommand' => 1
		);
		$aRecommandGoodsList = $oExchange->getExchangeGoodsList($aCondition, 1, 5, '`create_time` DESC');
		if($aRecommandGoodsList === false){
			alert('系统出错，请稍后再试!', 0);
		}

		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('系统出错，请稍后再试!', 0);
		}
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			alert('系统出错，请稍后再试!', 0);
		}
		$aUserInfo = array_merge($aUserInfo, $aUserNumerical);
		assign('findImg', $GLOBALS['RESOURCE']['exchange_quick' . rand(1, 4)]);
		assign('aUserInfo', $aUserInfo);
		displayHeader('兑换商城--' . $aGoods['name']);
		assign('userId', $this->_userId);
		assign('aGoods', $aGoods);
		assign('aRecommandGoodsList', $aRecommandGoodsList);
		display('exchange/goods_detail.html.php');
		displayFooter();
	}

	public function quickSpot(){
		$goodsId = intval(post('goodsId'));
		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($goodsId);
		if(!$aGoods){
			alert('抱歉，系统找不到兑换的物品！', -1);
		}
		$spot = intval(post('spot'));
		Cookie::set($this->_userId . $goodsId, $spot);
		if($spot == $aGoods['quick_spot']){
			alert('找对了', 1);
		}else{
			alert('很遗憾找错了，继续找吧', -1);
		}

	}


	public function checkExchange(){
		$goodsId = intval(post('goodsId'));
		if(!$goodsId){
			alert('抱歉，系统兑换物品出错！', 0);
		}

		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($goodsId);
		if(!$aGoods){
			alert('抱歉，系统找不到兑换的物品！', 0);
		}

		if($aGoods['stock'] == 0){
			alert('抱歉，兑换的物品没有库存了哦！', -1);
		}

		$now = time();
		if($aGoods['rush_time']){	//抢购活动
			if($aGoods['rush_time'] > $now){
				alert('抢购还没开始呢', -1);
			}else{
				$endTime = $aGoods['rush_time'] + 129600;
				$startTime = $aGoods['rush_time'] - 129600;
				$aRecordList = $oExchange->checkExchangeRecord($this->_userId, $startTime, $endTime);
				if($aRecordList){
					foreach($aRecordList as $aRecord){
						if($aRecord['good_info']['rush_time']){
							alert('抱歉！抢兑活动的抢兑商品每人每次只能兑换一件', -1);
						}
					}
				}

				$quickSpot = intval(Cookie::get($this->_userId . $goodsId));
				if(!$quickSpot || $quickSpot != $aGoods['quick_spot']){
					if($aGoods['quick_spot'] % 10 > 0){
						$xCoordinate = 10 - ($aGoods['quick_spot'] % 10) + 1;
					}else{
						$xCoordinate = 1;
					}
					$yCoordinate = 10 - ceil($aGoods['quick_spot'] / 10) + 1;
					alert('先找茬吧', 2, array('x' => $xCoordinate, 'y' => $yCoordinate));	//开始找茬
				}

			}
		}


		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			alert('系统出错，请稍后再试!', 0);
		}

		if(!$aGoods['rush_time'] || $now > $aGoods['rush_time'] + 3600){	//除了抢购商品外的打折商品
			$date = date('md');
			$day = date('d');
			if(($date >= 1223 && $date <= 1225) || ($date >= 101 && $date <= 103)){	//双蛋节7折
				$aGoods['gold'] = intval($aGoods['gold'] * self::DAYS_DISCOUNT);
			}elseif($day == 20){	//每月20、30号开启折扣
				if($aUserNumerical['vip_expiration_time'] > $now){
					if($aUserNumerical['vip'] == 1){
						$discount = self::VIP_DISCOUNT1;
					}elseif($aUserNumerical['vip'] == 2){
						$discount = self::VIP_DISCOUNT2;
					}elseif($aUserNumerical['vip'] == 3){
						$discount = self::VIP_DISCOUNT3;
					}else{
						alert('数据出错', 0);
					}
					$aGoods['gold'] = intval($aGoods['gold'] * $discount);
				}
			}
		}

		if($aUserNumerical['gold'] < $aGoods['gold']){
			alert('抱歉，您还差' . ($aGoods['gold'] - $aUserNumerical['gold']) . '金币哦！', -2, $aGoods['gold'] - $aUserNumerical['gold']);
		}
		alert('可以购买', 1);
	}

	public function exchange(){
		$goodsId = intval(post('goodsId'));
		$mobile = post('mobile');
		$qq = post('qq');
		$receiver = post('receiver');
		$detailedPlace = post('detailedPlace');

		if(!$goodsId){
			alert('抱歉，系统兑换物品出错！', 0);
		}
		if(!$receiver){
			alert('请填写收货人姓名！', -1);
		}

		$vResult = v('mobile,detailedPlace');
		if($vResult){
			alert($vResult, -1);
		}

		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($goodsId);
		if(!$aGoods){
			alert('抱歉，系统找不到兑换的物品！', 0);
		}

		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			alert('系统出错，请稍后再试!', 0);
		}

		if($aGoods['stock'] == 0){
			alert('抱歉，兑换的物品没有库存了哦！', -1);
		}

		$now = time();
		if($aGoods['rush_time']){	//抢购活动
			if($aGoods['rush_time'] > $now){
				alert('抢购还没开始呢', -1);
			}else{
				$endTime = $aGoods['rush_time'] + 129600;
				$startTime = $aGoods['rush_time'] - 129600;
				$aRecordList = $oExchange->checkExchangeRecord($this->_userId, $startTime, $endTime);
				if($aRecordList){
					foreach($aRecordList as $aRecord){
						if($aRecord['good_info']['rush_time']){
							alert('抱歉！抢兑活动的抢兑商品每人每次只能兑换一件', -1);
						}
					}
				}

				$quickSpot = intval(Cookie::get($this->_userId . $goodsId));
				if($quickSpot != $aGoods['quick_spot']){
					alert('您找茬没找对呢', -1);
				}
			}
		}

		if(!$aGoods['rush_time'] || $now > $aGoods['rush_time'] + 3600){	//除了抢购商品外的打折商品
			$date = date('md');
			$day = date('d');
			if(($date >= 1223 && $date <= 1225) || ($date >= 101 && $date <= 103)){	//双蛋节7折
				$aGoods['gold'] = intval($aGoods['gold'] * self::DAYS_DISCOUNT);
			}elseif($day == 20){	//每月20、30号开启折扣
				if($aUserNumerical['vip_expiration_time'] > $now){
					if($aUserNumerical['vip'] == 1){
						$discount = self::VIP_DISCOUNT1;
					}elseif($aUserNumerical['vip'] == 2){
						$discount = self::VIP_DISCOUNT2;
					}elseif($aUserNumerical['vip'] == 3){
						$discount = self::VIP_DISCOUNT3;
					}else{
						alert('数据出错', 0);
					}
					$aGoods['gold'] = intval($aGoods['gold'] * $discount);
				}
			}
		}


		if($aUserNumerical['gold'] < $aGoods['gold']){
			alert('抱歉，您还差' . ($aGoods['gold'] - $aUserNumerical['gold']) . '金币哦！', -2, $aGoods['gold'] - $aUserNumerical['gold']);
		}
		if($aUserNumerical['level'] < $aGoods['level']){
			alert('抱歉，您的等级经验不够哦！', -1);
		}

		$aData = array(
			'id' => $aGoods['id'],
			'gold' => $aGoods['gold'],
			'receiver' => $receiver
		);
		$isExchangeSuccess = $oExchange->exchangeGoods($this->_userId, $aData, $detailedPlace, $mobile, $qq);
		if(!$isExchangeSuccess){
			alert('系统出错，请稍后再试!', 0);
		}else{
			if(substr(DOMAIN_EXTEND, -3) == 'com'){
				$aOptions = array(
					'to' => USER_APPROVER_EMIAL,
					'subject' => 'UMFun 用户兑换商品提醒！',
					'name' => USER_APPROVER_EMIAL,
					'content' => '用户ID为' . $this->_userId . '兑换了商品！<br /><a href="http://' . APP_MANAGE .'/?m=Exchange&a=showExchangeList" style="color:#f00;">立即前往</a>为其发货!',
				);
				email($aOptions);
			}
		}
		alert('恭喜您，兑换成功！', 1, $aGoods['gold']);
	}

	public function getMyExchangeList(){
		$userId = $this->_userId;
		$page = intval(post('page', 1));
		$pageSize = 10;

		$oExchange = m('Exchange');
		$aMyExchangeList = $oExchange->getExchangRecordsList($userId, 0, $page, $pageSize);
		if($aMyExchangeList === false){
			alert('系统出错，请稍后再试!', 0);
		}
		alert('兑换记录列表', 1, $aMyExchangeList);
	}

	public function supportGoods(){
		$goodsId = intval(post('goodsId'));
		$oExchange = m('Exchange');
		$aGoods = $oExchange->getExchangeGoodsInfoById($goodsId);
		if(!$aGoods){
			alert('抱歉，系统找不到兑换的物品！', 0);
		}

		$myCookie = $this->_userId . '_' . $goodsId;
		$cookieSupport = Cookie::get('sup_ex');
		if($cookieSupport){
			$aCookie = explode(',', $cookieSupport);
			if(in_array($myCookie, $aCookie)){
				alert('您已经赞过一次了哦！', -1);
			}
			$strCookie = implode(',', $aCookie) . ',' . $myCookie;
			Cookie::set('sup_ex', $strCookie, time() + 86400);
		}else{
			Cookie::set('sup_ex', $myCookie, time() + 86400);
		}
		$isSupportSuccess = $oExchange->setExchangeGoods(array('id' => $goodsId, 'support' => array('add', 1)));

		alert('喜欢物品成功！', 1);
	}
}