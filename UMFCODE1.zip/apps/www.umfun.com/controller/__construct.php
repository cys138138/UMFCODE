<?php
$aUrlPath = parse_url($_SERVER['REQUEST_URI']);
$referer = 'reference=' . base64_encode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
if($aUrlPath['path'] == '/login/'){
	$referer = '';
}
define('APP_LOGIN_URL', url('m=Site&a=index', $referer, APP_LOGIN));
define('TITLE', '优满分(UMFun) - 中国最大中小学生在线游戏化学习平台！');
header("Content-type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
$GLOBALS['VIEW'] = new View(APP_VIEW_PATH);


if($_SERVER['REMOTE_ADDR'] != '14.120.232.121' && 0){
	echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>停机公告</title>
	<link rel="stylesheet" href="http://s.umfun.dev//view2/style/style_global.css?v=20140106"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="停机公告" />
	<style>
		h3{padding: 5% 0;}
		p{padding: 1% 0;}
		blockquote{padding: 2% 0;}
	</style>
</head>
<body style="background-color:#FF6600;color:#fff;">
<div style="width:900px; margin: 150px auto;">
	<h3 style="font-size:16px;">服务器暂停公告</h3>
	<div>
		<p><strong style="font-size:30px;">由于服务器升级及系统版本更新，系统将于2014年1月23日</strong></p>
		<p><strong style="font-size:30px;">15:30-18:30 暂停服务，为您带来不便请多谅解！</strong></p>
	</div>
	<blockquote style="text-align: right;font-size:16px;"><b>UMFun团队 2014.01.23</b></blockquote>
<div>
</body>
</html>
';
	exit;
}

if(get('sf')){
	Cookie::set('sf', get('sf'), time() + 2592000);
}

//邮件来路
$aMreferer = get('mreferer');
if(!$aMreferer){
	$aMreferer = get('mReferer');
}
if($aMreferer){
	$aReferer = explode('.', $aMreferer);
	if($aReferer[0] && $aReferer[1]){
		$result = m('Notice')->addPushInfoSourceCount(array(
			'user_id' => $aReferer[0],
			'type' => $aReferer[1],
			'create_time' => time()
		));
		if($result === false){
			myLog('邮件返回时写入统计数据服务器出现错误');
		}elseif(!$result){
			myLog('不能写入邮件返回时的统计数据');
		}
	}
}

function displayHeader($title = ''){
	Yii::$app->request->csrfToken;
	$response = Yii::$app->getResponse();
	$request = Yii::$app->getRequest();
	if($response->getCookies()){
		if ($request->enableCookieValidation) {
			if ($request->cookieValidationKey == '') {
				throw new InvalidConfigException(get_class($request) . '::cookieValidationKey must be configured with a secret key.');
			}
			$validationKey = $request->cookieValidationKey;
		}
		foreach($response->getCookies() as $cookie){
			$value = $cookie->value;
			if ($cookie->expire != 1  && isset($validationKey)) {
				$value = Yii::$app->getSecurity()->hashData(serialize([$cookie->name, $value]), $validationKey);
			}
			setcookie($cookie->name, $value, $cookie->expire, $cookie->path, $cookie->domain, $cookie->secure, $cookie->httpOnly);  
		}
	}
	if($title){
		$title = $title . ' - ';
	}
	$title = $title . TITLE;
	echo getHeader($title);
}

function getHeader($title){
	$userId = get('userId');
	$aUser = array();
	$aCurrentUser = isLogin();
	$oNum = m('UserNumerical');
	if($aCurrentUser){
		$aCurrentNum = $oNum->getUserNumericalInfoById($aCurrentUser['id']);
		if($aCurrentNum['vip_expiration_time'] < time()){
			$aCurrentNum['vip'] = 0;
		}
		$aCurrentUser = array_merge($aCurrentUser, $aCurrentNum);

		$aCurrentUser['is_yh_user'] = 0;
		$oDb = new DBOI();
		if($oDb->table(T_TJ_USER)->where(['id' => $aCurrentUser['id']])->select()){
			$aCurrentUser['is_yh_user'] = 1;
		}
	}
	if($userId){
		$oUser = m('User');
		$aUser = $oUser->getLoginInfoByUserId($userId);
		if(!$aUser){
			$aUser = isLogin();
		}
		$aUser['css_file'] = '';
		if(isset($aUser['style_id']) && $aUser['style_id']){
			$aStyleInfo = m('Style')->getStyleInfoById($aUser['style_id']);
			$aUser['css_file'] = SKIN_PATH . $aStyleInfo['pack_name'] . '/style.css';
		}
	}else{
		$aUser = $aCurrentUser;
	}
	assign('title', $title);
	assign('aViewUser', $aUser);
	assign('aCurrentUser', $aCurrentUser);
	return fetch('header.html.php');
}

function displayFooter($isSNS = false){
	echo getFooter($isSNS);
}

function getFooter($isSNS = false){
	assign('isSNS', $isSNS);
	return fetch('footer.html.php');
}

function displayNav($userId, $isSNS = false){
	$aUser = checkUserLogin();
	$myUserId = $aUser['id'];
	$mobile = $aUser['mobile'];
	$approveStatus = $aUser['approve_status'];
	//我的个人信息
	$aUser = getUserInfo($myUserId, array('personal', 'class', 'area', 'numerical'));
	$oUserNumerical = m('UserNumerical');
	$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($myUserId);
	$aUser = array_merge($aUser, $aUserNumerical);
	$aUser['approve_status'] = $approveStatus;

	//公众号加载
	$isPublicUser = in_array($aUser['id'], $GLOBALS['PUBLIC_USER_IDS']) ? 1 : 0;
	assign('isPublicUser', $isPublicUser);
	$now = time();
	if($aUser['vip_expiration_time'] < $now){
		$aUser['vip'] = 0;
	}
	assign('aUser', $aUser);

	$oUser = m('User');
	$aMailInfo = $oUser->getPersonalInfoByUserId($myUserId);
	assign('emailActive', $aMailInfo['is_email_active']);
	assign('mobileActive', (bool)$mobile);


	//勋章
	$aMyMedal = array();
	$aUserMedal = $oUserNumerical->getMedalInfoById($myUserId);
	if(!$aUserMedal){
		$aUserMedal = array();
		$aUserMedal['id'] = $myUserId;
		$aUserMedal['passed_missions'] = 0;
		$aUserMedal['excellent_missions'] = 0;
		$aUserMedal['pk_win_times'] = 0;
		$aUserMedal['medal_process'] = array();
		if(!$oUserNumerical->addMedal($aUserMedal)){
			return false;
		}
	}
	foreach(Numerical::$aIdMedalRelation as $medalId => $aSysMedal){
		if($aUserMedal[$aSysMedal['db_field']] >= $GLOBALS[$aSysMedal['config_key']][1]['nums']){
			$aMyMedal[$aSysMedal['db_field']] = true;
		}
	}
	assign('aMyMedal', $aMyMedal);

	//收藏数 错误数
	$oEs = m('Es');
	$wrongEsCount = $oEs->getUserWrongEsCount($myUserId);
	assign('wrongEsCount', $wrongEsCount);
	assign('isSNS', $isSNS);

	$firstLoginToday = false;
	//每日任务
	$oUserBehavior = m('UserBehavior');
	$aTask = $oUserBehavior->getUserDailyBehaviorInfo($myUserId);
	if(!$aTask){
		$firstLoginToday = true;
		$aTask = $oUserBehavior->getInitDataForUserDailyBehavior($myUserId);
		$oUserBehavior->addUserDailyBehavior($aTask);
	}
	//debug($aTask);
	$lastUpdate = date('Ymd', $aTask['create_time']);
	$today = date('Ymd', $now);
	if(!$aTask['task'] || $today > $lastUpdate){
		$firstLoginToday = true;
		$aTask = $oUserBehavior->getInitDataForUserDailyBehavior($myUserId);
		$oUserBehavior->setUserDailyBehavior($aTask);
	}
	assign('firstLoginToday', $firstLoginToday);

	$finishTask = true;
	foreach($aTask['task'] as $task){
		if($task['status'] == 2){
			assign('isTaskGift', true);
		}
		if($finishTask && $task['status'] != 3){
			$finishTask = false;
		}
	}
	assign('finishTask', $finishTask);

	if($myUserId != $userId){
		$aFriendIds = getUserFriendIds($myUserId);
		assign('isFriend', in_array($userId, $aFriendIds));

		//被查看的用户信息
		$aVisitedInfo = getUserInfo($userId, array('personal', 'class', 'area', 'numerical'));
		if(!$aVisitedInfo){
			alert('用户不存在', 0);
		}
		$aVisitedNum = $oUserNumerical->getUserNumericalInfoById($userId);
		$aVisitedInfo = array_merge($aVisitedInfo, $aVisitedNum);
		assign('aVisitedInfo', $aVisitedInfo);
	}

	$aNewStyle = m('Style')->getNewStyle();
	$newSkinTime = $aNewStyle['create_time'];
	assign('newSkinTime', $newSkinTime);

	$oVideo = m('Video');
	$aVideoCondition = array(
		'status' => 1,
		'is_trans' => -1,
		'is_recommend' => -1,
		'category_id' => 0,
		'is_background' => 0,
	);
	$aNewVideo = $oVideo->getVideoList($aVideoCondition, 1, 1);
	if($aNewVideo){
		assign('newVideoTime', $aNewVideo[0]['create_time']);
	}else{
		assign('newVideoTime', 0);
	}
	assign('myUserId', $myUserId);

	//读取好友数量
	$oSns = m('Sns');
	$friendCount = $oSns->getUserFriendCount($myUserId);
	if(!$friendCount){
		$friendCount = 0;
	}
	assign('friendCount', $friendCount);

	//小纸条对话数
	$messageDialogCount = $oSns->getSnsPrivateMessageDialogCount($myUserId);
	if(!$messageDialogCount){
		$messageDialogCount = 0;
	}
	assign('messageDialogCount', $messageDialogCount);

	//获取说说数量
	$oSnsEvent = m('SnsEvent');
	$shuoshuoCount = $oSnsEvent->getShuoshuoCountByUserId($myUserId);
	if(!$shuoshuoCount){
		$shuoshuoCount = 0;
	}
	assign('shuoshuoCount', $shuoshuoCount);

	//获取道具数量
	$oProp = m('Prop');
	$aUserProp = $oProp->getUserPropInfo($myUserId);
	$propCount = 0;
	if($aUserProp){
		$propCount = count($aUserProp['props']);
	}
	assign('propCount', $propCount);
	$aPropList = $oProp->getPropSendRecordList(0, $myUserId, 1, 1, 50);
	assign('sendPropCount', count($aPropList));

	//兑换商城兑换日高亮
	$week = date('w');
	$date = date('md');
	$day = date('d');
	if($week == 6 || ($date >= 1223 && $date <= 1225) || ($date >= 101 && $date <= 103) || $day == 20 || $day == 30){
		$exchange = true;
	}else{
		$exchange = false;
	}
	assign('exchange', $exchange);

	$newPaper = $oSns->getUnreadPrivateMessageCount($myUserId);
	assign('newPaper', $newPaper);
	$homework = \common\model\TeacherHomeworkStudent::getStudentHomeworkCount(['student_id' => $myUserId, 'is_finish' => 0]);
	assign('homework', $homework);
	$applyToMe = $oSns->getApplyFriendCount($myUserId);
	if($applyToMe || $aUser['new_friend_flag']){
		$newFriend = true;
	}else{
		$newFriend = false;
	}
	assign('newFriend', $newFriend);
	assign('newMessage', $aUser['new_feed_flag']);

	assign('isLoginFromParent', User::isLoginFromParent($myUserId));
	assign('isLoginFromXxt', $aUser['xxt_id'] && User::isLoginFromXxt($myUserId));
	echo fetch('nav.html.php');
}

function displayLeftNav($userId, $isLandspace = false){
	return;
}

//临时文件输出调试函数
function fDebug($fileName, $aData){
	if(APP_HOME != 'www.umfun.dev'){
		return;
	}
	$traceInfo = '运行轨迹:' . PHP_EOL;
	$oException = new Exception();
	$aTraceList = $oException->getTrace();

	for($i = count($aTraceList) - 1; $i >= 0; $i--){
		$aTrace = $aTraceList[$i];
		if(!isset($aTrace['class'])){
			$aTrace['class'] = '----';
		}
		//组装回溯
		$traceInfo .= $aTrace['file'] . ' 第 ' . $aTrace['line'] . ' 行: ' . $aTrace['class'] . '->' . $aTrace['function'] . PHP_EOL;
	}

	file_put_contents(SYSTEM_LOG_PATH . APP_NAME . '/' . $fileName, '<?php' . PHP_EOL . var_export($aData, 1) . PHP_EOL . '回溯:' . $traceInfo);
}