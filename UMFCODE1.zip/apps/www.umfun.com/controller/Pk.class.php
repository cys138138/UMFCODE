<?php
class PkController{
	private $_userId = 0;
	private $_aUser = array();
	private $_aDurationConfig = array(3, 4, 5, 6, 7, 8);	//PK时长配置，单位（分钟）
	private $_aOverTimeConfig = array(3, 5, 7);	//PK超时时间配置，单位（天）
	private $_aPkEsCount = array(3, 4, 5, 6, 7, 8);	//PK题目数
	private $_acceptPkCount = array(
		'min' => 0,
		'max' => 5
	);
	private $_aPkStatus = array(
		0 => array(
			'description' => 'PK未知状态'
		),
		1 => array(
			'description' => '双方还没开始做题'
		),
		2 => array(
			'description' => '发起者正在做题，接受者还没开始做题'
		),
		3 => array(
			'description' => '接受者正在做题，发起者还没开始做题'
		),
		4 => array(
			'description' => '双方已开始做题，但还没完成'
		),
		5 => array(
			'description' => '发起者完成了PK，接受者还没开始做题'
		),
		6 => array(
			'description' => '发起者完成了PK，接受者正在做题'
		),
		7 => array(
			'description' => '接受者完成了PK，发起者还没开始做题'
		),
		8 => array(
			'description' => '接受者完成了PK，发起者正在做题'
		),
		9 => array(
			'description' => 'PK结束'
		)
	);

	private $_aAttachmentGold = array(
		'min' => 0,
		'max' => 10,
	);

	private $_userPkListCount = 5;//用户pk列表每页3条

	private $_aGrade = array(
		5 => '五年级',
		6 => '六年级',
		7 => '初一',
		8 => '初二',
		9 => '初三',
	);

	public function __construct(){
		if(get('a') != 'execOverTimePkJudgment'){
			$aUser = $this->_aUser = checkUserLogin();
			$this->_userId = $aUser['id'];
		}
	}


	/*------------pk场开始------------*/

	//每关卡下的发过PK的用户列表
	private function _getPkMissionUserList($missionId, $page = 1,$haveGold = 0, $aFriendIds = array()){
		$oPk = m('Pk');
		$aPkUserList = $oPk->getMissionPkArenaPkList($missionId, $page, $haveGold, $aFriendIds);
		return $aPkUserList;
	}

	//PK场
	public function showPkSquare(){
		$aSubjectAarray = $GLOBALS['SUBJECT'];

		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		//我的勋章
		$aMyPkMedal = $this->_getPkMedal();
		if($aMyPkMedal === false){
			alert('系统错误', 0);
		}

		$oUserNumerical = m('UserNumerical');
		$aWorldRankList = $oUserNumerical->getMedalRankingList('pk_win_times', 3, 1, 40);

		assign('aUserInfo', $aUserInfo);
		assign('aMyPkMedal', $aMyPkMedal);
		assign('aWorldRankList', $aWorldRankList);
		array_unshift($aSubjectAarray, '全部');
		assign('aSubjectAarray', $aSubjectAarray);
		assign('subject', 0);
		assign('userId', $this->_userId);
		assign('acceptPkCount', $this->_acceptPkCount);
		assign('aGrade', $this->_aGrade);
		displayHeader('PK场');
		display('pk/square.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}


	//ajax取pk场pk列表
	public function getPassMissionPkList(){
		$page = intval(post('page'));
		if($page < 1){
			alert('参数有误！',-1);
		}
		$subjectId = intval(post('subjectId'));
		$haveGold = intval(post('haveGold', 0));
		$isFriend = intval(post('isFriend'));
		$aMissionId = post('missionId', array()) ? array(intval(post('missionId'))) : array();

		$aSubject = array(
			0,
			1,
			2,
			3,
			4
		);
		if(!in_array($subjectId, $aSubject)){
			alert('选择科目的参数有误！',-1);
		}
		$aFriendIds = array();
		if($isFriend){
			$aFriendIds = getUserFriendIds($this->_userId);
			if($aFriendIds === false){
				alert('系统错误', 0);
			}
		}

		$pageSize = 6;
		$oPk = m('Pk');
		$aData = $oPk->getUserPassMissionListForPkArena($this->_userId, $page, $pageSize, $subjectId, '`orders` ASC', $haveGold, $aMissionId, $aFriendIds);
		if($aData === false){
			alert('系统错误', 0);
		}

		$aMissionList = $aData['mission_list'];
		foreach($aMissionList as &$aMissionInfo){
			$aUserPkList = array();
			$aUserPkList = $this->_getPkMissionUserList($aMissionInfo['id'], 1, $haveGold, $aFriendIds);

			if($aUserPkList === false){
				alert('系统错误', 0);
				break;
			}
			$aMissionInfo['pageCount'] = ceil($aMissionInfo['pk_count']/$this->_userPkListCount);
			$aMissionInfo['user_list'] = $aUserPkList;

		}
		$aData['mission_list'] = $aMissionList;
		$aData['page_count'] = ceil($aData['mission_count']/$pageSize);
		alert('获取成功!', 1, $aData);
	}


	//Pk场里的换一换
	public function getPkUserList(){
		$missionId = intval(post('missionId'));
		$page = intval(post('page'));
		$haveGold = intval(post('haveGold'),0);
		$isFriend = intval(post('isFriend'),0);
		$aFriendIds = array();
		if($isFriend){
			$aFriendIds = getUserFriendIds($this->_userId);
			if($aFriendIds === false){
				alert('系统错误', 0);
			}
		}
		$aUserList = $this->_getPkMissionUserList($missionId, $page, $haveGold, $aFriendIds);
		if($aUserList === false){
			alert('系统错误', 0);
		}

		alert('', 1, $aUserList);
	}

	//pk场里的应战
	public function atOncePk(){
		$pkId = intval(post('id'));
		$oPk = m('Pk');
		$aPk = $oPk->getDetailPkInfo($pkId);

		if($aPk === false){
			alert('网络可能有点慢！',0);
		}elseif(!$aPk){
			alert('不存在这场pk!',-1);
		}

		if($aPk['sender_user_id'] == $this->_userId){
			alert('这是您发起的pk您不能应战哦！',-1);
		}

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($aPk['mission_id']);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，PK内容不存在！', 0);
		}

		/* if($aMission['subject_id'] != 4){
			//判断是否都过了此关卡
			$isPassMission = $oMission->isPassMissionByUserIdList($aPk['mission_id'], array($this->_userId));
			if(!$isPassMission){
				alert('请先闯过  ' . $aMission['name'] . '  关', -1);
			}
		} */

		alert('',1);

	}

	/*------------pk场结束------------*/



	/*-----------我的PK开始--------------*/

	 /**
	 *	PK列表
	 */
	public function showList(){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		//我的勋章
		$aMyPkMedal = $this->_getPkMedal();
		if($aMyPkMedal === false){
			alert('系统错误', 0);
		}

		//推荐PK
		$length = 6;
		$aRecommendPkList = $this->_getRecommendPkList($length);
		if($aRecommendPkList === false){
			alert('系统错误', 0);
		}

		$oUserNumerical = m('UserNumerical');
		$aWorldRankList = $oUserNumerical->getMedalRankingList('pk_win_times', 3, 1, 40);

		assign('aUserInfo', $aUserInfo);
		assign('aWorldRankList', $aWorldRankList);
		assign('aRecommendPkList', $aRecommendPkList);
		assign('aMyPkMedal', $aMyPkMedal);
		assign('acceptPkCount', $this->_acceptPkCount);
		assign('userId',$this->_userId);
		displayHeader('我的PK');
		display('pk/my_pk.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	/**
	 *	加载更多PK列表
	 */
	public function morePkList(){
		$page = intval(post('page', 1));
		if($page < 1){
			alert('参数有误！',-1);
		}

		$winStatus = intval(post('is_win', 0));
		$order = intval(post('order', 0));
		$waitPk = intval(post('wait_pk', 0));
		$pageSize = 8;
		if(!$order){
			$order = '';
		}else{
			$order = '`create_time` DESC';
		}

		$oPk = m('Pk');

		$aPkList = $oPk->getNewUserPkList($this->_userId, $page, $pageSize, $order, $winStatus, $waitPk);
		if($aPkList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$pkCount = $oPk->getNewUserPkCount($this->_userId, $winStatus);
		if($pkCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aPkNewList['pk_list'] = &$aPkList;
		$aPkNewList['page_count'] = ceil($pkCount/$pageSize);
		foreach($aPkList as $key => $aPk){
			$aPkList[$key]['pk_status'] = $this->_getPkStatus($aPk);
			$aPkList[$key]['sender_score'] = $aPkList[$key]['sender_score'] / 100;
			$aPkList[$key]['receiver_score'] = $aPkList[$key]['receiver_score'] / 100;

			$end = 9;
			if($this->_userId == $aPkList[$key]['sender_user_id']){
				$aWait = array(5, 6);
				$aContinue = array(2, 4);
				$aJoin = array(1, 3, 7, 8);
			}elseif($this->_userId == $aPkList[$key]['receiver_user_id']){
				$aWait = array(7, 8);
				$aContinue = array(3, 4);
				$aJoin = array(1, 2, 5, 6);
			}

			//!!!!!临时部署,拦截BUG相关问题
			if(!isset($aContinue)){
				throw Yii::$app->buildError('查看更多PK出问题了', false, $aPkList[$key]);
			}

			if($aPkList[$key]['pk_status'] == $end){
				if(!$aPkList[$key]['is_receive_prize'] && $this->_userId == $aPkList[$key]['winner_user_id']){
					$aPkList[$key]['action'] = '立即领取';
					$aPkList[$key]['show_class'] = 'btn_green';
				}else{
					$aPkList[$key]['action'] = '查看详细';
					$aPkList[$key]['show_class'] = 'btn_gray';
				}
			}elseif(in_array($aPkList[$key]['pk_status'], $aContinue)){
				$aPkList[$key]['action'] = '继续PK';
				$aPkList[$key]['show_class'] = 'btn_orange';
			}elseif(in_array($aPkList[$key]['pk_status'], $aJoin)){
				$aPkList[$key]['action'] = '立即PK';
				$aPkList[$key]['show_class'] = 'btn_orange';
			}elseif(in_array($aPkList[$key]['pk_status'], $aWait)){
				$aPkList[$key]['action'] = '查看详细';
				$aPkList[$key]['show_class'] = 'btn_gray';
			}

			if($aPkList[$key]['receiver_user_id'] != 0){
				$aRceiverUserInfo = getUserInfo($aPkList[$key]['receiver_user_id']);
				if($aRceiverUserInfo === false){
					alert('网络可能有点慢！',0);
				}
				$aPkList[$key]['rceiver_user_info'] = $aRceiverUserInfo;
			}
		}
		unset($aPkList);
		alert('PK列表', 1, $aPkNewList);
	}

	//侧边栏-勋章
	private function _getPkMedal(){
		$aPkMedal = array();
		$oUserNumerical = m('UserNumerical');
		$aUserMedal = $oUserNumerical->getMedalInfoById($this->_userId);
		if($aUserMedal === false){
			return false;
		}

		$oNum = new Numerical();
		if($aUserMedal['pk_win_times'] >= $GLOBALS['PK_WIN_MEDAL'][1]['nums']){

			$aPkMedal[1]['img'] = $GLOBALS['MEDAL_IMG'][6];
			$aPkMedal[1]['level'] = $oNum->countLevel(6, $aUserMedal['pk_win_times']);
			$aPkMedal[1]['name'] = $GLOBALS['PK_WIN_MEDAL'][$aPkMedal[1]['level']]['name'];
			$aPkMedal[1]['times'] = $aUserMedal['pk_win_times'];
			$aPkMedal[1]['top_level'] = count($GLOBALS['PK_WIN_MEDAL']);
			if($aPkMedal[1]['level'] < $aPkMedal[1]['top_level']){
				$nextLevel = intval($aPkMedal[1]['level']) + 1;
				$aPkMedal[1]['next_level'] = $nextLevel;
				$aPkMedal[1]['next_left_point'] = $GLOBALS['PK_WIN_MEDAL'][$nextLevel]['nums'] - $aPkMedal[1]['times'];
			}

		}
		unset($aUserMedal);
		return $aPkMedal;
	}


	//一周PK排行榜
	public function _getPkRankingByWeek($pageSize = 7){
		$oPk = m('Pk');
		$page = 1;
		$endTime = time();
		$startTime = $endTime - 7*24*3600;
		$aPkList = $oPk->getPkRankingList($page, $pageSize, array(), 0, $startTime, $endTime);
		return $aPkList;
	}

	//推荐pK
	private function _getRecommendPkList($length){
		$userId = $this->_userId;
		$oPk = m('Pk');

		$aPkList = $oPk->getRecommendPkForUser($userId, $length);
		return $aPkList;
	}

	/*-----------我的PK结束--------------*/




	/*-----------PK排行榜开始------------*/
	public function showPkRanking(){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		//我的勋章
		$aMyPkMedal = $this->_getPkMedal();
		if($aMyPkMedal === false){
			alert('系统错误', 0);
		}

		//一周pk排行榜
		/*$aPkListByWeek = $this->_getPkRankingByWeek(40);
		if($aPkListByWeek === false){
			alert('系统错误', 0);
		}*/

		//推荐PK
		$length = 6;
		$aRecommendPkList = $this->_getRecommendPkList($length);
		if($aRecommendPkList === false){
			alert('系统错误', 0);
		}

		//我的Pk排行榜
		$oPk = m('Pk');
		$aMyPkList = $oPk->getUserPkCountListByUserIds(array($this->_userId));
		if($aMyPkList === false){
			alert('系统错误', 0);
		}
		$aUserFriendsIds = getUserFriendIds($this->_userId);
		if($aUserFriendsIds === false){
			alert('系统错误', 0);
		}

		$friendSendPkRank = $oPk->getUserSendPkRanking($this->_userId, $aUserFriendsIds);
		if($friendSendPkRank === false){
			alert('系统错误', 0);
		}
		$aMyPkList[0]['friend_send_pk_rank'] = $friendSendPkRank;

		$friendWinPkRank = $oPk->getUserWinPkRanking($this->_userId, $aUserFriendsIds);
		if($friendWinPkRank === false){
			alert('系统错误', 0);
		}
		$aMyPkList[0]['friend_win_pk_rank'] = $friendWinPkRank;

		$oUserNumerical = m('UserNumerical');
		$aWorldRankList = $oUserNumerical->getMedalRankingList('pk_win_times', 3, 1, 40);

		assign('aUserInfo', $aUserInfo);
		assign('aMyPkList', $aMyPkList[0]);
		assign('aWorldRankList', $aWorldRankList);
		assign('aRecommendPkList', $aRecommendPkList);
		assign('aMyPkMedal', $aMyPkMedal);
		assign('acceptPkCount', $this->_acceptPkCount);
		assign('userId', $this->_userId);
		displayHeader('PK排行榜');
		display('pk/pk_ranking.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	public function getPkRankingList(){
		$type = intval(post('type',1));
		$page = intval(post('page',1));

		if($page < 1){
			alert('参数有误！',-1);
		}

		if($type == 1 || $type == 3){
			$aPointUserIds = getUserFriendIds($this->_userId);
			$aPointUserIds[] = $this->_userId;
		}elseif($type == 2 || $type == 4){
			$aPointUserIds = array();
		}else{
			alert('参数有误！',-1);
		}

		$pageSize = 20;
		$oPk = m('Pk');

		if($type == 1 || $type == 2){
			$aPkList = $oPk->getPkRankingList($page, $pageSize, $aPointUserIds);
		}elseif($type == 3 || $type == 4){
			$aPkList = $oPk->getUserSendPkRankingList(0, $page, $pageSize, $aPointUserIds);
		}

		if($aPkList === false){
			alert('网络可能有点慢！',0);
		}
		alert('', 1, $aPkList);
	}

	/**
	 *	PK排行榜
	 */
	private function _time2Str($time){
		if(!$time){
			return null;
		}
		$str = '';
		$seconds = time() - $time;
		if($seconds <= 3600){
			$str = ceil($seconds / 60) . '分钟之前';
		}elseif($seconds > 3600 && $seconds <= 3600 * 24){
			$str = ceil($seconds / 3600) . '小时之前';
		}elseif($seconds > 3600 * 24 && $seconds <= 3600 * 24 * 30){
			$str = ceil($seconds / (3600 * 24)) . '天之前';
		}elseif($seconds > 3600 * 24 * 30){
			$str = date('Y-m-d', $time);
		}
		return $str;
	}

	/**
	 *	PK排行榜
	 */
	public function pkRankList(){
		$type = intval(post('type', 1));
		$page = intval(post('page', 1));
		$pageSize = 10;
		$oPk = m('Pk');
		if($type == 1){
			$aPkRankList = $oPk->getPkRankingList($page, $pageSize);
		}else{
			$oSns = m('Sns');
			$aFriendList = $oSns->getUserFriendsIdList($this->_userId);
			if($aFriendList === false){
				alert('程序执行错误，请稍后重试', 0);
			}
			$aPkRankList = $oPk->getPkRankingList($page, $pageSize, $aFriendList);
		}
		if($aPkRankList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		alert('PK排行榜', 1, $aPkRankList);
	}


	/**
	 *	最近好友PK用户列表
	 */
	public function nearlyFriendPkUserList(){
		$page = intval(post('page', 1));
		$pageSize = 10;

		$oPk = m('Pk');
		$aFriendPkList = $oPk->getNearestPkUserList($page, $pageSize);
		if($aFriendPkList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		alert('最近好友PK用户列表', 1, $aFriendPkList);
	}

	//创建PK模板
	public function showAdd(){
		$showType = intval(get('type', 1));
		if(!$showType){
			$showType = 1;
		}
		if($showType == 1){
			$targetUserId = intval(get('user_id'));
			if(!$targetUserId){
				$targetUserId = 0;
			}
			$aTargetUser = $this->_checkUserExist($targetUserId);
			if(!$aTargetUser){
				assign('targetUserId', 0);
			}else{
				assign('targetUserId', $targetUserId);
			}
		}elseif($showType == 2){
			$missionId = intval(get('mission_id'));
			if(!$missionId){
				$missionId = 0;
			}
			$oMission = m('Mission');
			$aTargetMission = $oMission->getUserMissionDetailInfo($missionId, $this->_userId);
			if(!$aTargetMission || !isset($aTargetMission['user_mission_info']['is_pass']) || $aTargetMission['user_mission_info']['is_pass'] != 1){
				assign('missionId', 0);
				assign('aTargetMission', array());
			}else{
				$aMissionInfo = $oMission->getMissionInfoById($missionId);
				if($aMissionInfo){
					$aTargetMission['subject_id'] = $aMissionInfo['subject_id'];
				}
				assign('missionId', $missionId);
				assign('aTargetMission', $aTargetMission);
			}
		}elseif($showType == 3){
			$parmStr = get('user_id');
			$aParm = explode('_', $parmStr);
			$targetUserId = intval($aParm[0]);
			$missionId = intval($aParm[1]);
			if(!$targetUserId){
				$targetUserId = 0;
			}
			$aTargetUser = $this->_checkUserExist($targetUserId);
			if(!$aTargetUser){
				assign('targetUserId', 0);
			}else{
				assign('targetUserId', $targetUserId);
			}

			if(!$missionId){
				$missionId = 0;
			}
			$oMission = m('Mission');
			$aTargetMission = $oMission->getUserMissionDetailInfo($missionId, $this->_userId);
			if(!$aTargetMission || !isset($aTargetMission['user_mission_info']['is_pass']) || $aTargetMission['user_mission_info']['is_pass'] != 1){
				assign('missionId', 0);
				assign('aTargetMission', array());
			}else{
				$aMissionInfo = $oMission->getMissionInfoById($missionId);
				if($aMissionInfo){
					$aTargetMission['subject_id'] = $aMissionInfo['subject_id'];
				}
				assign('missionId', $missionId);
				assign('aTargetMission', $aTargetMission);
			}
		}else{
			alert('程序执行错误，请稍后重试', 0);
		}
		assign('showType', $showType);
		displayHeader('发起PK');
		display('pk/addPk.html.php');
	}


	//按关卡添加关卡AJAX分页列表
	public function getMyMissionList(){
		$oMission = m('Mission');
		$aMissionList = array();
		$pageSize = 8;
		$subSize = 5;
		$aUserCurrentPageList = $oMission->getCurrentMissionPage($this->_userId, $pageSize);
		foreach($aUserCurrentPageList as $subject => $page){
			$aSubjectMissionList = $oMission->getOriginalMissionList($subject, $page, $pageSize);
			if($aSubjectMissionList === false){
				alert('程序执行错误，请稍后重试', 0);
			}
			$aMissionList[$subject]['missionList'] = $aSubjectMissionList;
			$missionCount = $oMission->getMissionCount($subject);
			if($missionCount === false){
				alert('程序执行错误，请稍后重试', 0);
			}

			//分页
			$pageUrl = url('m=Pk&a=getAjaxMyMissionList');
			$aData= array(
				'url' => $pageUrl,
				'total' => $missionCount,
				'page' => $page,
				'size' => $pageSize,
				'subs' => $subSize,
				'onclick' => 'getMissionListTurnPage(' . $subject . ',_PAGE_);',
				'labels' => array(
					'first'		=>	'',
					'previous'	=>	'<上一页',
					'next'		=>	'下一页>',
					'last'		=>	'',
				)
			);
			$opage = new Pagination($aData);
			$aMissionList[$subject]['pageHtml'] = $opage->fetch();
		}
		alert('用户可PK的关卡列表', 1, $aMissionList);
	}

	public function getSubjectGradeMissionList(){
		$aMissionList = Mission::getSubjectGradeMissionList();
		alert('用户可PK的关卡列表', 1, $aMissionList);
	}

	public function getMyMissionListByPage(){
		$page = post('page', 1) + 0;
		$subject = post('subject', 1) + 0;
		if($page <= 0 || $subject <= 0){
			alert('参数有误！', -1);
		}

		$oMission = m('Mission');
		$pageSize = 8;
		$subSize = 5;
		$aSubjectMissionList = $oMission->getOriginalMissionList($subject, $page, $pageSize);
		if($aSubjectMissionList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		$aMissionList[$subject]['missionList'] = $aSubjectMissionList;
		$missionCount = $oMission->getMissionCount($subject);
		if($missionCount === false){
			alert('程序执行错误，请稍后重试', 0);
		}

		//分页
		$pageUrl = url('m=Pk&a=getAjaxMyMissionList');
		$aData= array(
			'url' => $pageUrl,
			'total' => $missionCount,
			'page' => $page,
			'size' => $pageSize,
			'subs' => $subSize,
			'onclick' => 'getMissionListTurnPage(' . $subject . ',_PAGE_);',
			'labels' => array(
				'first'		=>	'',
				'previous'	=>	'<上一页',
				'next'		=>	'下一页>',
				'last'		=>	'',
			)
		);
		$opage = new Pagination($aData);
		$aMissionList[$subject]['pageHtml'] = $opage->fetch();
		alert('用户可PK的关卡列表', 1, $aMissionList);
	}

	//创建PK
	public function add(){
		alert('PK功能已禁用', -1);
		$receiverUserId = intval(post('pk_receiver_user_id', 0));
		$duration = intval(post('pk_duration', 30));
		$overTime = 7;
		$missionId = intval(post('pk_mission_id'));
		$esCounts = intval(post('pk_es_counts'));
		$attachmentGold = intval(post('pk_attachment_gold', 0));
		$type = intval(post('type'));
		//$vResult = v('pk_receiver_user_id,pk_mission_id,pk_duration,pk_es_counts,pk_over_time,pk_attachment_gold');
		$vResult = v('pk_mission_id,pk_duration,pk_es_counts,pk_over_time,pk_attachment_gold');
		if($vResult){
			alert($vResult, 0);
		}
		$oPk = m('Pk');
		$isNotPkPlatform = ($type != 4 && $type != 2 && $receiverUserId != 0);
		//用户在一个关卡只能发起一个pk到pk场
		if($type == 2 && $receiverUserId == 0){
			$arenaMissionPkCount = $oPk->getUserPkArenaMissionPkCount($this->_userId, $missionId);
			if($arenaMissionPkCount === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			if($arenaMissionPkCount != 0){
				alert('抱歉，您之前已发起过这一关卡到PK场了！', -1);
			}
		}
		if($isNotPkPlatform){
			$aReceiverUser = $this->_checkUserExist($receiverUserId);
			if(!$aReceiverUser){
				alert('抱歉，PK对象不存在！', 0);
			}
		}
		if(!in_array($duration, $this->_aDurationConfig)){
			alert('抱歉，PK时长值不正确！', 0);
		}

		if(!in_array($overTime, $this->_aOverTimeConfig)){
			alert('抱歉，PK超时值不正确！', 0);
		}

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($missionId);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，PK内容不存在！', 0);
		}

		if($this->_userId == $receiverUserId){
			alert('抱歉，不能和自己PK哦！', 0);
		}
		if($aMission['subject_id'] != 4 && $isNotPkPlatform){
			//判断是否都过了此关卡
			$isPassMission = $oMission->isPassMissionByUserIdList($missionId, array($this->_userId, $receiverUserId));
			if(!$isPassMission){
				alert('不能PK此关卡哦！', 0);
			}
		}
		if($attachmentGold){
			$oUser = m('User');
			$aUser = $oUser->getUserDetailInfoByUserId($this->_userId);
			if($aUser === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$oUserNumerical = m('UserNumerical');
			$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
			if($aUserNumerical === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}elseif($aUserNumerical['gold'] < $attachmentGold){
				alert('亲！您的金币数量不足哦', 0);
			}
		}

		//判断用户一天内发起的PK数是否超过限制

		if($isNotPkPlatform){
			$todayReceiverPkCount = $oPk->getUserTodayPkCount($receiverUserId, 2);
			if($todayReceiverPkCount === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			if($todayReceiverPkCount > $aReceiverUser['accept_pk_count']){
				alert('抱歉，您的对手今天好忙不能再PK了哦！', 0);
			}
			//判断PK选手在同一关卡是否有没有完成的PK记录
			$aLastPkRecord = $oPk->getLastPkRecord($this->_userId, $receiverUserId, $missionId);
			if($aLastPkRecord){
				$lastPkStatus = $this->_getPkStatus($aLastPkRecord);
				if($lastPkStatus != 9){
					alert('抱歉，您和PK对手在这关还没完成上一次的PK哦！', 0);
				}
			}
		}
		//分配题目
		$oEs = m('Es');
		$excludeType = 0;
		if($aMission['subject_id'] == 1 || $aMission['subject_id'] == 2){
			$excludeType = 4;	//语文和数学暂时排除填空题，题库正在删除拼音输入等
		}
		$aEsResult = $oEs->getEsIdsByCategoryId($aMission['category_ids'], $esCounts, $excludeType);
		if($aEsResult === false){
			alert('选题失败！', 0);
		}
		if(!$aEsResult){
			alert('选题失败！所选择关卡中题目数不够哦', 0);
		}
		$now = time();
		$aEsList = array();
		foreach($aEsResult as $esId){
			$aEsList[$esId] = 2;
		}
		$aContent = array(
			'sender_es_list'	=> $aEsList,
			'receiver_es_list'	=> $aEsList
		);
		$aNewData = array(
			'content'			=> $aContent,
			'sender_user_id' 	=> $this->_userId,
			'receiver_user_id'	=> $receiverUserId,
			'duration' 			=> $duration,
			'over_time' 		=> $now + $overTime * 86400,
			'mission_id' 		=> $missionId,
			'es_counts' 		=> $esCounts,
			'attachment_gold' 	=> $attachmentGold,
			'is_receive_attachment' => 2,
			'create_time' 		=> $now
		);
		$isAddSuccess = $oPk->addPk($aNewData);
		if($isAddSuccess === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		if($isNotPkPlatform){
			$isUpdateSuccess = $this->_updateNearlyChoosePkUserList($receiverUserId);
			if(!$isUpdateSuccess){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}
		//向接受者推关应用消息
		$this->_sendPkAppMessageToReceiver($this->_userId, $receiverUserId);

		//每日任务 发起PK
		//带金币的pk到任务大厅
		if($attachmentGold > 0 && $receiverUserId == 0){
			Task::refreshTask($this->_userId, 5);
		}

		if($type == 2 && $receiverUserId == 0){
			alert('发起PK到PK场成功！', 1, $isAddSuccess);
		}
		alert('发起PK成功！', 1, $isAddSuccess);
	}

	/**
	 * 	获取PK对象列表，并将PK对象分组
	 */
	public function getPkUserGroupList(){
		$type = intval(post('type'));
		if(!$type){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oPk = m('Pk');
		$aPkUserGroupList = array();
		if($type == 1){
			$targetPkUserId = post('targetPkUserId');
			$aPkUserGroupList['target'] = array();
			if($targetPkUserId && $targetPkUserId != $this->_userId){
				$aPkUserGroupList['target'] = $this->_updateNearlyChoosePkUserList($targetPkUserId);
			}
			if(!$aPkUserGroupList['target']){
				$aTargetRecord = $this->_getNearlyChoosePkUserList();
				if($aTargetRecord){
					$aPkUserGroupList['target'] = $aTargetRecord;
				}
			}
			$aNearlyPkUserList = $this->_getNearPkUserList();
			if($aNearlyPkUserList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aPkUserGroupList['nearly'] = $aNearlyPkUserList;
			$aFriendList = $this->_getPageFriends(1, 99999);
			if($aFriendList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aPkUserGroupList['friend'] = $aFriendList;
		}elseif($type == 2){
			$missionId = intval(post('missionId'));
			if(!$missionId){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$oMission = m('Mission');
			$aMission = $oMission->getMissionInfoById($missionId);
			if($aMission === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}elseif(!$aMission){
				alert('抱歉，关卡不存在！', -1);
			}
			/* if($aMission['subject_id'] != 4){
				//判断当前用户是否过了此关卡
				$isPassMission = $oMission->isPassMissionByUserIdList($missionId, array($this->_userId));
				if(!$isPassMission){
					alert('您此关卡还未过关，只能发起PK到PK场哦！', -1);
				}
			} */
			$aNearlyPkUserList = $this->_getNearPkUserList(1, $missionId);
			if($aNearlyPkUserList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aPkUserGroupList['nearly'] = $aNearlyPkUserList;

			$oSns = m('Sns');
			$aFiriendIds = $oSns->getUserFriendIdList($this->_userId);
			if($aFiriendIds === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aFriendList = $oPk->getUserListByPkMission($this->_userId, $missionId, 1, 99999, $aFiriendIds);
			if($aFriendList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			if($aMission['subject_id'] == 4 && $aFiriendIds){
				$aFriendList = getUserListByUserIds($aFiriendIds);
			}
			$aPkUserGroupList['friend'] = $aFriendList;

			$aAllPkUserList = $oPk->getUserListByPkMission($this->_userId, $missionId, 1, 99999);
			if($aAllPkUserList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			if($aMission['subject_id'] == 4){
				$aAllPkUserList = $oSns->getUserRandProbablyList($this->_userId, 20, array(), array());
			}
			$aStrangerList = array();
			foreach($aAllPkUserList as $key => $aPkUser){
				if(!in_array($aPkUser['id'], $aFiriendIds)){
					array_push($aStrangerList, $aPkUser);
				}
			}
			$aPkUserGroupList['stranger'] = $aStrangerList;
		}else{
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		alert('PK用户列表', 1, $aPkUserGroupList);
	}




	//根据关卡取全部通过的人、最近PK的人、及通过的好友
	public function getFriendListByMissionId(){
		$missionId = intval(post('missionId', 0));
		$type = intval(post('type', 1));
		$page = intval(post('page', 1));
		if($missionId < 1 || $type < 1 || $page < 1){
			alert('数据错误', 0);
		}
		$pageSize = 18;
		$aFriendList = array();
		$oPk = m('Pk');

		//全部
		if($type == 1){
			$aFriendList = $oPk->getUserListByPkMission($this->_userId, $missionId, $page, $pageSize);
		}elseif($type == 2){
			//最近PK的人
			$aFriendList = $this->_getNearPkUserList($page, $missionId);

		}elseif($type == 3){
			$oSns = m('Sns');
			$aFiriendIds = $oSns->getUserFriendIdList($this->_userId);
			if($aFiriendIds === false){
				alert('系统错误', 0);
			}
			if($aFiriendIds){
				$aFriendList = $oPk->getUserListByPkMission($this->_userId, $missionId, $page, $pageSize, $aFiriendIds);
			}
		}
		if($aFriendList === false){
			alert('系统错误', 0);
		}
		alert('', 1, $aFriendList);
	}

	public function getUserListByPassMissionId(){
		$missionId = intval(post('missionId', 0));
		$type = intval(post('type', 1));
		$page = intval(post('page', 1));
		$pageSize = 10;

		if($missionId < 1 || $type < 1 || $page < 1){
			alert('数据错误', 0);
		}

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($missionId);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，关卡不存在！', -1);
		}
		//判断当前用户是否过了此关卡
		if($aMission['subject_id'] != 4){
			$isPassMission = $oMission->isPassMissionByUserIdList($missionId, array($this->_userId));
			if(!$isPassMission){
				alert('不能PK此关卡哦！', -1);
			}
		}
		$oPk = m('Pk');
		$aPkUserList = array();

		if($type == 1){
			$aPkUserList = $oPk->getUserListByMissionId($this->_userId, $missionId, $page, $pageSize);
			if($aPkUserList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}elseif($type == 2){
			$oSns = m('Sns');
			$aFiriendIds = $oSns->getUserFriendIdList($this->_userId);
			if($aFiriendIds === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aPkUserList = $oPk->getUserListByMissionId($this->_userId, $missionId, $page, $pageSize, $aFiriendIds);
			if($aPkUserList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}elseif($type == 3){
			$oSns = m('Sns');
			$aFiriendIds = $oSns->getUserFriendIdList($this->_userId);
			if($aFiriendIds === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aPkUserList = $oPk->getUserListByMissionId($this->_userId, $missionId, $page, $pageSize, array(), $aFiriendIds);
			if($aPkUserList === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}else{
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		alert('关卡PK用户列表', 1, $aPkUserList);
	}

	public function getUserPkListByMissionId(){
		$page = intval(post('page', 1));
		$missionId = intval(post('missionId', 0));
		$pageSize = 3;
		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($missionId);
		if(!$aMission){
			alert('关卡不存在', 0);
		}
		$oPk = m('Pk');
		$aPkList = $oPk->getUserPkListByMissionId($this->_userId, $missionId, $page, $pageSize);
		if($aPkList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		foreach($aPkList as $key => $aPk){
			$pkStatus= $this->_getPkStatus($aPk);
			if($pkStatus == 1){
				//双方还没开始做题
				$aPkList[$key]['status_str'] = '马上PK';
			}elseif($pkStatus == 2){
				//发起者正在做题，接受者还没开始做题
				if($aPk['sender_user_id'] == $this->_userId){
					$aPkList[$key]['status_str'] = '继续PK';
				}else{
					$aPkList[$key]['status_str'] = '马上PK';
				}
			}elseif($pkStatus == 3){
				//接受者正在做题，发起者还没开始做题
				if($aPk['receiver_user_id'] == $this->_userId){
					$aPkList[$key]['status_str'] = '继续PK';
				}else{
					$aPkList[$key]['status_str'] = '马上PK';
				}
			}elseif($pkStatus == 4){
				//双方已开始做题，但还没完成
				$aPkList[$key]['status_str'] = '继续PK';
			}elseif($pkStatus == 5){
				//发起者完成了PK，接受者还没开始做题
				if($aPk['sender_user_id'] == $this->_userId){
					$aPkList[$key]['status_str'] = '等待结果';
				}else{
					$aPkList[$key]['status_str'] = '马上PK';
				}
			}elseif($pkStatus == 6){
				//发起者完成了PK，接受者正在做题
				if($aPk['sender_user_id'] == $this->_userId){
					$aPkList[$key]['status_str'] = '等待结果';
				}else{
					$aPkList[$key]['status_str'] = '继续PK';
				}
			}elseif($pkStatus == 7){
				//接受者完成了PK，发起者还没开始做题
				if($aPk['receiver_user_id'] == $this->_userId){
					$aPkList[$key]['status_str'] = '等待结果';
				}else{
					$aPkList[$key]['status_str'] = '马上PK';
				}
			}elseif($pkStatus == 8){
				//接受者完成了PK，发起者正在做题
				if($aPk['receiver_user_id'] == $this->_userId){
					$aPkList[$key]['status_str'] = '等待结果';
				}else{
					$aPkList[$key]['status_str'] = '继续PK';
				}
			}elseif($pkStatus == 9){
				//PK结束
				$aPkList[$key]['status_str'] = '已结束';
			}
			$aPkList[$key]['status'] = $pkStatus;
		}
		alert('关卡PK列表', 1, $aPkList);
	}


	//我的PK记录
	public function myPkList(){
		$page = intval(post('page', 1));
		$pageSize = 10;
		$oPk = m('Pk');
		$aMyPkList = array();
		$aMyPkList = $oPk->getUserPkRecord($this->_userId, $page, $pageSize);
		if($aMyPkList === false){
			alert('系统错误', 0);
		}
		if($aMyPkList){
			$myPkInfo = $oPk->getUserPkCountListByUserIds(array($this->_userId));
			if($myPkInfo === false){
				alert('系统错误', 0);
			}
			$aMyPkList['win_count'] = $myPkInfo[0]['win_count'];
			$aMyPkList['loss_count'] = $myPkInfo[0]['pk_count'] - $myPkInfo[0]['win_count'];
			$aMyPkList['page_count'] = ceil($aMyPkList['pk_user_count'] / $pageSize);
		}
		alert('', 1, $aMyPkList);
	}


	/**
	 *	删除PK
	 */
	public function delete(){
		$pkId = intval(post('pk_id'));
		if(!$pkId){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oPk = m('Pk');
		//查询当前用户是否有此pk记录
		$aPk = $oPk->getPkIndexInfoById($pkId);
		if(!$aPk){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		if($aPk['sender_user_id'] == $this->_userId || $aPk['receiver_user_id'] == $this->_userId){
			if($aPk['delete_user_id'] && $aPk['delete_user_id'] != $this->_userId){
				//直接删除
				$isDeleteSuccess = $oPk->deletePkById($pkId);
				if($isDeleteSuccess === false){
					alert('抱歉，系统出错，请稍后再试！', 0);
				}
			}else{
				//userId更新到delete_user_id字段
				$aNewData = array(
					'id' => $pkId,
					'delete_user_id' => $this->_userId
				);
				$isSetSuccess = $oPk->setPkData($aNewData);
				if($isSetSuccess === false){
					alert('抱歉，系统出错，请稍后再试！', 0);
				}
			}
			alert('删除成功！', 1);
		}else{
			alert('抱歉，无权操作！', 0);
		}
	}

	public function showDetail(){
		$pkPlatformStatus = 1;
		$pkId = intval(get('pk_id'));
		$from = intval(get('from'));
		if(!$pkId){
			alert('非法的PK参数', 0);
		}
		$oPk = m('Pk');
		$aPk = $oPk->getDetailPkInfo($pkId);
		if(!$aPk){
			alert('PK记录不存在', 0);
		}

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($aPk['mission_id']);
		if(!$aMission){
			alert('关卡不存在', 0);
		}
		$aPk['mission_name'] = $aMission['name'];
		$aPk['subject_id'] = $aMission['subject_id'];

		$oUser = m('User');
		$aSender = $oUser->getUserDetailInfoByUserId($aPk['sender_user_id']);
		$aReceiver = $oUser->getUserDetailInfoByUserId($aPk['receiver_user_id']);

		$remainEsNums = $aPk['es_counts'];

		$isThirdUser = false;
		if($this->_userId == $aPk['sender_user_id']){
			$role = 'sender';
		}elseif($this->_userId == $aPk['receiver_user_id']){
			$role = 'receiver';
		}else{
			#alert('PK不存在喔', 0);
            //缺少第三人视觉导致比赛不存在，暂时修正
            $role = 'receiver';
			$isThirdUser = true;	//是否第三方查看PK
		}
		if($aPk[$role. '_user_start_time'] == 0){
			$remainTime = $aPk['duration'] * 60;
		}else{
			$remainTime = time() - $aPk[$role. '_user_start_time'];
		}
		//$remainTime = $aPk[$role. '_user_start_time'] == 0 ? ($aPk['duration'] * 60) : (time() - $aPk[$role. '_user_start_time']);
		$aUserNumerical = m('UserNumerical')->getUserNumericalInfoById($this->_userId);

		//计算PK状态
		$pkStatus = $this->_getPkStatus($aPk);

		assign('pkStatus', $pkStatus);
		$aEs = array();
		$status = 0;	//第三人
		if(isset($role)){
			assign('role', $role);
			if($this->_userId == $aPk['delete_user_id']){
				alert('PK已经删除', 0);
			}
			if(($role == 'sender' && in_array($pkStatus, array(1, 2, 3, 4, 7, 8))) || ($role == 'receiver' && in_array($pkStatus, array(1, 2, 3, 4, 5, 6)))){
				$aEs = $this->_nextEs($aPk['content'][$role . '_es_list']);
				if(!$aEs && !$isThirdUser){
					alert('题目不存在', 0);
				}

			}

			if($aPk[$role . '_user_start_time']){
				$status = 2;	//继续PK
				if($aPk[$role . '_user_start_time'] + $aPk['duration'] * 60 <= time()){
					$status = 3;	//PK结束
				}
			}else{
				$status = 1;	//开始PK

			}

			if($aPk[$role . '_user_end_time'] || $aPk['winner_user_id']){
				$status = 3;	//PK结束
				$remainEsNums = 0;
			}

			if($status == 1 || $status == 2){
				$remainEsNums = $this->_countEsNum(array(2), $aPk['content'][$role . '_es_list']);
			}
		}
		$aPk['sender_score'] = $aPk['sender_score'] / 100;
		$aPk['receiver_score'] = $aPk['receiver_score'] / 100;

		$aNewEsList = array();
		foreach($aPk['content']['sender_es_list'] as $key => $value){
			$aNewEsList[Xxtea::encrypt($key)] = $value;
		}
		$aPk['content']['sender_es_list'] = $aNewEsList;
		foreach($aPk['content']['receiver_es_list'] as $key => $value){
			$aNewEsList[Xxtea::encrypt($key)] = $value;
		}
		$aPk['content']['receiver_es_list'] = $aNewEsList;

		if($from == 1){
			if($aUserNumerical['gold'] >= $aPk['attachment_gold']){
				$pkPlatformStatus = 2;
			}else{
				$pkPlatformStatus = 0;
			}
			if($aPk['sender_user_id'] != $this->_userId){
				$aReceiver = $oUser->getUserDetailInfoByUserId($this->_userId);
			}else{
				$aReceiver = array(
					'id' => 0,
					'email' => '0',
					'mobile' => '0',
					'name' => '--',
					'profile' => '',
				);
			}
		}

		assign('aSender', $aSender);
		assign('aReceiver', $aReceiver);
		assign('aEs', $aEs);
		assign('remainEsNums', $remainEsNums);
		assign('remainTime', $remainTime);
        assign('aUserNumerical',$aUserNumerical);
		assign('status', $pkStatus);
		assign('aPkInfo', $aPk);
		assign('pkPlatformStatus', $pkPlatformStatus);
		assign('userId', $this->_userId);
		displayHeader('PK详情');
		display('pk/pk_detail.html.php');
	}

	public function getPkDetail(){
		$pkId = intval(post('pk_id'));
		if(!$pkId){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oPk = m('Pk');
		$aPk = $oPk->getDetailPkInfo($pkId);
		if(!$aPk){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($aPk['mission_id']);
		if(!$aMission){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aPk['mission_name'] = $aMission['name'];
		$aPk['subject_id'] = $aMission['subject_id'];
		$aPk['sender_score'] = $aPk['sender_score'] / 100;
		$aPk['receiver_score'] = $aPk['receiver_score'] / 100;

		$aNewEsList = array();
		foreach($aPk['content']['sender_es_list'] as $key => $value){
			$aNewEsList[Xxtea::encrypt($key)] = $value;
		}
		$aPk['content']['sender_es_list'] = $aNewEsList;
		foreach($aPk['content']['receiver_es_list'] as $key => $value){
			$aNewEsList[Xxtea::encrypt($key)] = $value;
		}
		$aPk['content']['receiver_es_list'] = $aNewEsList;

		alert('PK详细信息', 1, $aPk);
	}

	/**
	 *	本关PK记录
	 */
	public function getMissionPkEventList(){
		$page = intval(post('page', 1));
		$missionId = intval(post('mission_id'));
		$pageSize = 10;

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($missionId);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，关卡不存在！', -1);
		}
		$oPk = m('Pk');
		$aPkEventList = $oPk->getMissionPkEventList($missionId, $page, $pageSize);
		if($aPkEventList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		alert('本关PK记录', 1, $aPkEventList);
	}

	/**
	 *	本关PK排名
	 */
	public function getMissionPkRanking(){
		$page = intval(post('page', 1));
		$missionId = intval(post('mission_id', 1));
		$pageSize = 10;

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($missionId);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，关卡不存在！', -1);
		}
		$oPk = m('Pk');
		$aPkRankList = $oPk->getPkRankingList($page, $pageSize, array(), $missionId);
		if($aPkRankList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		$oUser = m('User');
		foreach($aPkRankList as $key => $aPkRank){
			$aPkRankList[$key]['userInfo'] = $oUser->getUserDetailInfoByUserId($aPkRank['id']);
		}
		alert('本关PK排名', 1, $aPkRankList);
	}

	/**
	 *	根据关卡ID获取过关的用户列表
	 */
	public function getUserListByMissionId(){
		$missionId = intval(post('mission_id'));
		$page = intval(post('page', 1));
		$pageSize = 10;

		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($missionId);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，关卡不存在！', -1);
		}

		//判断当前用户是否过了此关卡
		if($aMission['subject_id'] != 4){
			$isPassMission = $this->isPassMissionByUserIdList($missionId, array($this->_userId));
			if(!$isPassMission){
				alert('不能PK此关卡哦！', -1);
			}
		}

		$oPk = m('Pk');
		$aUserList = $oPk->getUserListByPkMission($this->_userId, $missionId, $page, $pageSize);
		if($aUserList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		alert('用户列表', 1, $aUserList);
	}

	/**
	 *	根据用户ID获取共同关卡列表
	 */
	public function getCommonMissionList(){
		$receiverUserId = intval(post('pk_receiver_user_id'));
		$isReceiverUserExist = $this->_checkUserExist($receiverUserId);
		if(!$isReceiverUserExist){
			alert('抱歉，PK对象不存在！', 0);
		}

		$oPk = m('Pk');
		$aMissionList = $oPk->getMissionListByPkUser($this->_userId, $receiverUserId);
		if($aMissionList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		alert('共同过关的关卡列表', 1, $aMissionList);
	}


	/**
	 *开始PK
	 */
	public function startPk(){
		$id = intval(post('id'));
		$oPk = m('Pk');
		$aPkInfo = $oPk->getDetailPkInfo($id);
		if(!$aPkInfo){
			alert('PK不存在', 0);
		}

		if($aPkInfo['receiver_user_id'] == 0 && $aPkInfo['sender_user_id'] != $this->_userId){
			if($this->_userId == $aPkInfo['sender_user_id']){
				alert('不能自己和自己PK哦！', 0);
			}
			$oMission = m('Mission');
			$aMission = $oMission->getMissionInfoById($aPkInfo['mission_id']);
			if($aMission === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}elseif(!$aMission){
				alert('抱歉，关卡不存在！', -1);
			}

			/* //判断当前用户是否过了此关卡
			if($aMission['subject_id'] != 4){
				$isPassMission = $oMission->isPassMissionByUserIdList($aPkInfo['mission_id'], array($this->_userId));
				if(!$isPassMission){
					alert('您不能PK此关卡哦！', 0);
				}
			} */

			$aData = array();
			$aData['id'] = $id;
			$aData['receiver_user_id'] = $this->_userId;
			$result = $oPk->setPk($aData);
			if(!$result){
				alert('网络可能有点慢啦啦啦', 0);
			}
		}
		$aPkInfo = $oPk->getDetailPkInfo($id);
		if(!$aPkInfo){
			alert('PK不存在', 0);
		}
		//确定用户角色
		$statusCode = $this->_getPkStatus($aPkInfo);
		if($this->_userId == $aPkInfo['sender_user_id']){
			$role = 'sender';
			if(!in_array($statusCode, array(1, 3, 7))){
				alert($this->_aPkStatus[$statusCode]['description'], -1);
			}
		}elseif($this->_userId == $aPkInfo['receiver_user_id']){
			$role = 'receiver';
			if(!in_array($statusCode, array(1, 2, 5))){
				alert($this->_aPkStatus[$statusCode]['description'], -1);
			}
		}else{
			alert('这PK貌似不关你事喔，凑什么热闹呢！', 0);
		}

		if(isset($role)){
			if($this->_userId == $aPkInfo['delete_user_id']){
				alert('PK已经删除', -1);
			}
		}

		$aUpdatePk = array(
			'id' => $id,
			$role . '_user_start_time' => time(),
		);

		$isReceive = intval(post('isReceive'));
		if(!in_array($isReceive, array(0, 1))){
			alert('参数有错', 0);
		}

		if(!$oPk->setPk($aUpdatePk)){
			alert('网络可能有点慢啦啦啦', 0);
		}

		/*if($this->_userId == $aPkInfo['receiver_user_id']){
			$result = $this->_handleAttachmentGold($id, $isReceive);
			if(!$result){
				alert('网络可能有点慢啦啦啦', 0);
			}
		}*/
		alert('进入PK', 1);
	}

	public function acceptPkGold(){
		$id = intval(post('id'));
		$oPk = m('Pk');
		$aPkInfo = $oPk->getDetailPkInfo($id);
		if(!$aPkInfo){
			alert('PK不存在', 0);
		}
		$isReceive = intval(post('isReceive'));
		if(!in_array($isReceive, array(0, 1))){
			alert('参数有错', 0);
		}
		$statusCode = $this->_getPkStatus($aPkInfo);

		if($aPkInfo['receiver_user_id'] == 0){
			if($this->_userId == $aPkInfo['sender_user_id']){
				alert('不能自己和自己PK哦！', 0);
			}
			$oMission = m('Mission');
			$aMission = $oMission->getMissionInfoById($aPkInfo['mission_id']);
			if($aMission === false){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}elseif(!$aMission){
				alert('抱歉，关卡不存在！', -1);
			}

			/* //判断当前用户是否过了此关卡
			if($aMission['subject_id'] != 4){
				$isPassMission = $oMission->isPassMissionByUserIdList($aPkInfo['mission_id'], array($this->_userId));
				if(!$isPassMission){
					alert('您不能PK此关卡哦！', 0);
				}
			} */

			$aData = array();
			$aData['id'] = $id;
			$aData['receiver_user_id'] = $this->_userId;
			$result = $oPk->setPk($aData);
			if(!$result){
				alert('网络可能有点慢啦啦啦', 0);
			}
		}else{
			if($this->_userId != $aPkInfo['receiver_user_id']){
				alert('这PK貌似不关你事喔，凑什么热闹呢！', 0);
			}
		}
		if($aPkInfo['is_receive_attachment'] != 2){
			if($aPkInfo['is_receive_attachment'] == 1){
				alert('之前已经接受PK金币了哦', -1);
			}elseif($aPkInfo['is_receive_attachment'] == 0){
				alert('之前已经拒绝PK金币了哦', -1);
			}
		}
		$result = $this->_handleAttachmentGold($id, $isReceive);
		if(!$result){
			alert('网络可能有点慢啦啦啦', 0);
		}
		if($isReceive == 1){
			alert('接受PK金币成功！', 1);
		}else{
			alert('拒绝PK金币成功！', 1);
		}
	}

	/**
	 *PK作答处理
	 */
	public function markingPKAnswer(){
		$aPkAnswer = $_POST;
		if(!$this->_checkPk($aPkAnswer)){
			alert('作答格式有错', 0);
		}

		$oPk = m('Pk');
		$aPkInfo = $oPk->getDetailPkInfo($aPkAnswer['id']);
		if(!$aPkInfo){
			alert('PK不存在', 0);
		}

		//确定用户角色
		$statusCode = $this->_getPkStatus($aPkInfo);
		if($this->_userId == $aPkInfo['sender_user_id']){
			$role = 'sender';
			if(!in_array($statusCode, array(2, 4, 8))){
				alert($this->_aPkStatus[$statusCode]['description'], 0);
			}
			$anotherId = $aPkInfo['receiver_user_id'];
		}elseif($this->_userId == $aPkInfo['receiver_user_id']){
			$role = 'receiver';
			if(!in_array($statusCode, array(3, 4, 6))){
				alert($this->_aPkStatus[$statusCode]['description'], 0);
			}
			$anotherId = $aPkInfo['sender_user_id'];
		}else{
			alert('抱歉,你不是这场PK的参与者', 0);
		}

		if(isset($role)){
			if($this->_userId == $aPkInfo['delete_user_id']){
				alert('PK已经删除', 0);
			}
		}

		//批阅答案
		$aPkAnswer['user_answer']['id'] = Xxtea::decrypt($aPkAnswer['user_answer']['id']);


		if(!array_key_exists($aPkAnswer['user_answer']['id'], $aPkInfo['content'][$role . '_es_list'])){
			if($aResult['next_es'] = $this->_nextEs($aPkInfo['content'][$role . '_es_list'])){
				alert('下一题哈哈哈', 1, $aResult);
			}else{
				alert('读取下一题失败了', 0);
			}
			//alert('ID为 <b>' . $aPkAnswer['user_answer']['id'] . '</b> 不是该次分发给您的题目喔', 0);
		}

		$oEs = m('Es');
		$aEsInfo = $oEs->getOfficialEsInfoById($aPkAnswer['user_answer']['id']);
		if(!$aEsInfo){
			alert('ID为 ' . $aPkAnswer['answer']['id'] . ' 的题目不存在', 0);
		}

		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
		$aResult = $oEsPlugin->getCorrectness($aEsInfo['content_json'], $aPkAnswer['user_answer']['answer']);
		$isPass = $aResult['pass'];
		unset($aResult['pass']);
		unset($aResult['scale']);
		if($isPass){
			//和教育家长端学生数据收集
			Parents::statistics('esMode', array(
				'type' => 'pk',
				'subject' => $aEsInfo['subject_id'],
				'add_type' => 1
			));
		}else{
			Parents::statistics('esMode', array(
				'type' => 'pk',
				'subject' => $aEsInfo['subject_id'],
				'add_type' => 2
			));
		}

		//答完一道题目后
		$oGame = new Game();
		if(!$oGame->afterFinishEs($this->_userId, $aEsInfo, $aPkAnswer['get_time'], Cookie::get('pkt'), $isPass)){
			alert('抱歉，网络可能有点慢', 0);
		}

		//更新我的PK记录
		$aPkInfo['content'][$role . '_es_list'][$aPkAnswer['user_answer']['id']] = $isPass;
		$aUpdatePk = array(
			'id' => $aPkInfo['id'],
			'content' => $aPkInfo['content']
		);
		$remainEsNums = $this->_countEsNum(array(2), $aPkInfo['content'][$role . '_es_list']);
		if($remainEsNums == 0){
			//计算得分
			$aUpdatePk[$role . '_user_end_time'] = time();

			$oProp = propPlugin($this->_userId);
			//时光凝结道具
			if($oProp->checkSgnj($this->_userId, $aPkInfo['id'])){
				$aUpdatePk[$role . '_user_end_time'] = $aUpdatePk[$role . '_user_end_time'] - 30;
				if($aUpdatePk[$role . '_user_end_time'] < $aPkInfo[$role . '_user_start_time']){
					$aUpdatePk[$role . '_user_end_time'] = $aPkInfo[$role . '_user_start_time'];
				}
			}
			$aPkInfo[$role . '_user_end_time'] = $aUpdatePk[$role . '_user_end_time'];
			$rightEsNums = $this->_countEsNum(array(1), $aPkInfo['content'][$role . '_es_list']);

			if($rightEsNums){
				$totalTime = $aPkInfo['duration'] * 60;
				$score = intval(($totalTime - ($aUpdatePk[$role . '_user_end_time'] - $aPkInfo[$role . '_user_start_time'])) / $totalTime * 2000 + 8000 * $rightEsNums / $aPkInfo['es_counts']);
			}else{
				$score = 0;
			}

			//得到对方的角色
			if($role == 'sender'){
				$anotherRole = 'receiver';
				$duifangStatus = 8;

				$senderScore = $score / 100;
				$receiverScore = $aPkInfo['receiver_score'] / 100;
				$senderSpandTime = $aUpdatePk['sender_user_end_time'] - $aPkInfo['sender_user_start_time'];
				$ReceiverSpandTime = $aPkInfo['receiver_user_end_time'] - $aPkInfo['receiver_user_start_time'];
				if($aPkInfo['sender_user_end_time'] == 0){
					$senderSpandTime = 0;
				}
				if($aPkInfo['receiver_user_end_time'] == 0){
					$ReceiverSpandTime = 0;
				}
			}else{
				$anotherRole = 'sender';
				$duifangStatus = 6;

				$senderScore = $aPkInfo['sender_score'] / 100;
				$receiverScore = $score / 100;
				$senderSpandTime = $aPkInfo['sender_user_end_time'] - $aPkInfo['sender_user_start_time'];
				$ReceiverSpandTime = $aUpdatePk['receiver_user_end_time'] - $aPkInfo['receiver_user_start_time'];
				if($aPkInfo['receiver_user_end_time'] == 0){
					$ReceiverSpandTime = 0;
				}
				if($aPkInfo['sender_user_end_time'] == 0){
					$senderSpandTime = 0;
				}
			}

			if($statusCode == $duifangStatus){
				//结果事件
				$aData = array(
					'data_id' => $aPkInfo['id'],
					'user_id' => $aPkInfo['sender_user_id'],
					'type' => 32,
				);
				addPersonalMessage($aData);
				$aData['user_id'] = $aPkInfo['receiver_user_id'];
				addPersonalMessage($aData);

				//如果对方已经做完确定胜者
				if($score > $aPkInfo[$anotherRole . '_score']){
					$aUpdatePk['winner_user_id'] = $this->_userId;
				}elseif($score < $aPkInfo[$anotherRole . '_score']){
					$aUpdatePk['winner_user_id'] = $aPkInfo[$anotherRole . '_user_id'];
				}else{
					$myUserTime = $aUpdatePk[$role . '_user_end_time'] - $aPkInfo[$role . '_user_start_time'];
					$anotherUseTime = $aPkInfo[$anotherRole . '_user_end_time'] - $aPkInfo[$anotherRole . '_user_start_time'];
					if($myUserTime < $anotherUseTime){
						$score++;
						$aUpdatePk['winner_user_id'] = $this->_userId;
					}elseif($myUserTime > $anotherUseTime){
						$aPkInfo[$anotherRole . '_score']++;
						$aUpdatePk[$anotherRole . '_score'] = $aPkInfo[$anotherRole . '_score'];
						$aUpdatePk['winner_user_id'] = $anotherId;
					}else{
						$aUpdatePk[$role . '_user_end_time']--;
						$score++;
						$aUpdatePk['winner_user_id'] = $this->_userId;
					}
				}
				$oNum = new Numerical();
				$oNum->addMedal($aUpdatePk['winner_user_id'], 6);

				//每日任务 获胜1场PK
				Task::refreshTask($aUpdatePk['winner_user_id'], 6);

				$aThisResult = array();
				$oUser = m('User');
				$aSenderInfo = $oUser->getPersonalInfoByUserId($aPkInfo['sender_user_id'], 'name');
				$aReceiverInfo = $oUser->getPersonalInfoByUserId($aPkInfo['receiver_user_id'], 'name');
				$senderRightCount = $this->_countEsNum(array(1), $aPkInfo['content']['sender_es_list']);
				$ReceiverRightCount = $this->_countEsNum(array(1), $aPkInfo['content']['receiver_es_list']);
				$aThisResult['custom_data']['time'] = $aPkInfo['create_time'];
				$aThisResult['custom_data']['sender'] = $aSenderInfo['name'];
				$aThisResult['custom_data']['receiver'] = $aReceiverInfo['name'];
				$aThisResult['custom_data']['sender_finished_time'] = date('n月d日 H:i:s', $aPkInfo['sender_user_end_time']);
				$aThisResult['custom_data']['receiver_finished_time'] = date('n月d日 H:i:s', $aPkInfo['receiver_user_end_time']);
				$aThisResult['custom_data']['sender_score'] = $senderScore;
				$aThisResult['custom_data']['receiver_score'] = $receiverScore;
				$aThisResult['custom_data']['sender_correct_count'] = $senderRightCount;
				$aThisResult['custom_data']['receiver_correct_count'] = $ReceiverRightCount;
				$aThisResult['custom_data']['sender_spand_time'] = $senderSpandTime;
				$aThisResult['custom_data']['receiver_spand_time'] = $ReceiverSpandTime;
				if($aPkInfo['is_receive_attachment'] == 0){
					$aThisResult['custom_data']['gold'] = 0;
				}else{
					$aThisResult['custom_data']['gold'] = $aPkInfo['attachment_gold'];
				}
				if($this->_userId == $aUpdatePk['winner_user_id']){
					$aThisResult['show_type'] = 'PKWIN';
					$aThisResult['custom_data']['add_accumulate_points'] = $senderRightCount + $ReceiverRightCount;
				}else{
					$aThisResult['show_type'] = 'PKLOST';
				}
				$oGame->setResult($aThisResult);
			}
			$aUpdatePk[$role . '_score'] = $score;

		}
		if(!$oPk->setPk($aUpdatePk)){
			alert('出错啦啦啦', 0);
		}

		if($remainEsNums == 0){
			//PK完成或者下一题
			$aResult['result']['score'] = $score / 100;
			$aResult['result']['correct_rate'] = intval($rightEsNums / $aPkInfo['es_counts'] * 100);
			$aResult['result']['use_time'] = $aUpdatePk[$role . '_user_end_time'] - $aPkInfo[$role . '_user_start_time'];

			if(isset($aUpdatePk['winner_user_id'])){
				//pk胜者写动态
				$aEventData = array(
					'user_id'	=>	$aUpdatePk['winner_user_id'],
					'type'		=> ($aPkInfo['attachment_gold'] > 0 && $aPkInfo['is_receive_attachment'] == 1) ? 27 : 28,
					'data_id'	=>	$aPkAnswer['id'],
					'data'		=>	[
						'create_time' => time(),
						]
				);
				$oSnsEvent = m('SnsEvent');
				if(!$oSnsEvent->addEvent($aEventData)){
					alert('出错啦啦', 0);
				}
			}
			/*if(isset($aUpdatePk['winner_user_id'])){
				$aMessage = array(
					'user_id' => $aPkInfo[$role . '_user_id'],
					'type' => 15,
					'data_id' => $aPkAnswer['id']
				);
				$oSns = m('Sns');
				if($oSns->addPersonalMessage($aMessage) === false){
					alert('出错啦啦', 0);
				}

				$aMessage['user_id'] = $aPkInfo[$anotherRole . '_user_id'];
				if($oSns->addPersonalMessage($aMessage) === false){
					alert('出错啦啦', 0);
				}

				$aEvent = array(
					'user_id' => $aUpdatePk['winner_user_id'],
					'type' => 13,
					'data_id' => $aPkAnswer['id']
				);
				$oSns = m('Sns');
				if($oSns->addEvent($aEvent) === false){
					alert('出错撸', 0);
				}
			}*/
			alert('哇~~ 太牛了，对手都吓怕了', 200, $aResult);
		}else{
			$aEsInfos = $aResult['next_es'] = $this->_nextEs($aPkInfo['content'][$role . '_es_list']);
			if($aEsInfos){
				alert('下一题哈哈哈', 1, $aResult);
			}else{
				alert('读取下一题失败了', 0);
			}
		}
	}

	/**
	 *	PK事件列表
	 */
	public function pkEventList(){
		$page = intval(post('page', 1));
		$type = intval(post('type', 1));
		$pageSize = 10;
		$eventType = 13;

		$oSns = m('Sns');
		$aUserIdList = array();
		if($type == 2){
			$aUserIdList = $oSns->getUserFriendsIdList($this->_userId);
			if($aUserIdList === false){
				alert('程序执行错误，请稍后重试', 0);
			}
		}
		$aNearlyPkList = $oSns->getEventList($aUserIdList, $eventType, $page, $pageSize);
		if($aNearlyPkList === false){
			alert('程序执行错误，请稍后重试', 0);
		}
		alert('最近PK列表', 1, $aNearlyPkList);
	}

	/**
	 *	被挑战者处理PK赌注
	 */
	private function _handleAttachmentGold($pkId, $action){
		if(!$pkId){
			return false;
		}
		$oPk = m('Pk');
		$aPk = $oPk->getPkIndexInfoById($pkId);
		if(!$aPk){
			return false;
		}
		//判断当前用户是否为被挑战者
		if($aPk['receiver_user_id'] == $this->_userId){
			//判断金币是否足够
			if($aPk['attachment_gold']){
				$oUser = m('User');
				$aUser = $oUser->getUserDetailInfoByUserId($this->_userId);
				if($aUser === false){
					alert('抱歉，系统出错，请稍后再试！', 0);
				}
				$oUserNumerical = m('UserNumerical');
				$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
				if($aUserNumerical === false){
					alert('抱歉，系统出错，请稍后再试！', 0);
				}elseif($aUserNumerical['gold'] < $aPk['attachment_gold'] && $action == 1){
					alert('亲！您的金币数量不足, 不能接受Pk筹码哦', 0);
				}
			}
			$aPk['is_receive_attachment'] = $action;
			$isSetSuccess = $oPk->setIsReceiveAttachment($aPk);
			return $isSetSuccess;
		}else{
			return false;
		}
	}


	/**
	 *	PK领奖
	 */
	public function acceptPrize(){
		$pkId = intval(post('pk_id'));
		if(!$pkId){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oPk = m('Pk');
		$aPk = $oPk->getDetailPkInfo($pkId);
		if(!$aPk){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		//判断当前用户是否赢得此PK
		if($aPk['winner_user_id'] == $this->_userId){
			//领取奖励
			$oGame = new Game();
			if($aPk['is_receive_prize'] == 0){
				$isAcceptPrizeSuccess = $oPk->receivePrize($aPk);
				if($isAcceptPrizeSuccess){
					$points = $this->_countEsNum(array(1), $aPk['content']['sender_es_list']);
					$points += $this->_countEsNum(array(1), $aPk['content']['receiver_es_list']);
					if(!$oGame->acceptPKReword($this->_userId, $points, $aPk['is_receive_attachment'], $aPk['attachment_gold'] * 2)){
						alert('领奖失败', 0);
					}
				}else{
					alert('抱歉，系统出错，请稍后再试！', 0);
				}
			}else{
				alert('您已经领取奖励啦啦', -1);
			}
			//勋章
			if(!$oGame->afterPKEnd($aPk['sender_user_id'], $aPk['receiver_user_id'], $aPk['winner_user_id'])){
				alert('出错啦', 0);
			}
			alert('PK奖励领取成功！', 1, $points);
		}else{
			alert('抱歉，非法操作！', 0);
		}
	}

	/**
	 * 定时裁决超时PK
	 */
	public function execOverTimePkJudgment(){
		$pkId = intval(get('pk_id', 0));
		execOverTimePkJudgment($pkId);
	}


	//AJAX好友分页
	public function getFriendList(){
		$page = intval(post('page', 1));
		$type = intval(post('type', 0));
		if($page < 1 || $type < 1 || $type > 3){
			alert('数据错误', 0);
		}
		$aFriendList = array();
		if($type == 1){
			$aFriendList = $this->_getPageFriends($page);
		}elseif ($type == 2){
			$aFriendList = $this->_getNearPkUserList($page);
		}
		if($aFriendList === false){
			alert('数据错误', 0);
		}
		alert('', 1, $aFriendList);
	}

	/**
	 * 题目详细
	 */
	public function getEsDetail(){
		$id = intval(Xxtea::decrypt(post('id')));
		$pkId = intval(post('pk_id'));
		if(!$id){
			alert('参数出错', -1);
		}
		$oPk = m('Pk');
		$aPk = $oPk->getPkIndexInfoById($pkId);
		if(!$aPk){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMission = m('Mission');
		$aMission = $oMission->getMissionInfoById($aPk['mission_id']);
		if($aMission === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMission){
			alert('抱歉，PK内容不存在！', 0);
		}
		/* if($aMission['subject_id'] != 4){
			$isPassMission = $oMission->isPassMissionByUserIdList($aPk['mission_id'], array($this->_userId));
			if(!$isPassMission){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		} */
		$pkStatus = $this->_getPkStatus($aPk);
		if($this->_userId == $aPk['sender_user_id']){
			if(in_array($pkStatus, array(1, 2, 3, 4, 7, 8))){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}elseif($this->_userId == $aPk['receiver_user_id']){
			if(in_array($pkStatus, array(1, 2, 3, 4, 5, 6))){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
		}else{
			alert('抱歉，您无法查看该场PK！', -1);
		}

		$oEs = m('Es');
		$aEs = $oEs->getOfficialEsInfoById($id);
		if(!$aEs){
			alert('获取ID为 <b>' . $id . '</b> 的题目时出错啦', 0);
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
		$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
		$aEs['id'] = Xxtea::encrypt($aEs['id']);
		alert('题目详细', 1, $aEs);
	}

	//返回当前页好友
	private function _getPageFriends($page = 1, $pageSize = 18){
		$oSns = m('Sns');
		$aFiriendIdList = array();
		$aFriendList = array();
		$friendCount = 0;
		$friendCount = $oSns->getUserFriendCount($this->_userId);
		if($friendCount ===  false){
			return false;
		}
		if($friendCount < 1){
			return $aFriendList;
		}
		if($page < 1 || $page > ceil($friendCount / $pageSize)){
			return $aFriendList;
		}
		$aFiriendIdList = $oSns->getUserFriendIdList($this->_userId, $page, $pageSize);
		if($aFiriendIdList === false){
			return false;
		}elseif(!$aFiriendIdList){
			return $aFiriendIdList;
		}
		$oPk = m('Pk');
		$aFriendList = $oPk->getUserPkCountListByUserIds($aFiriendIdList);
		if($aFriendList === false){
			return $aFriendList;
		}
		return $aFriendList;
	}


	//最近PK的人
	private function _getNearPkUserList($page = 1, $missionId = 0, $pageSize = 18){
		$oPk = m('Pk');
		$aNearesPkUserList = array();
		//$aNearesPkUserList = $oPk->getNearestPkUserList($this->_userId, $page, $pageSize, array(), $missionId);
		$aNearesPkUserList = $oPk->getUserNearlyPkUserList($this->_userId, $page, $pageSize);
		if($aNearesPkUserList === false){
			return false;
		}
		return $aNearesPkUserList;
	}


	//得到当前用户通过的关卡列表
	private function _getUserMissionList($subjectId = 1, $page =  1, $pageSize = 6){
		if(!isset($GLOBALS['SUBJECT']) || $page < 1){
			return false;
		}
		$order = '`orders` ASC';
		$oMission = m('Mission');
		$aMissionList = array();
		$aMissionList = $oMission->getUserPassMissionList($this->_userId, $subjectId, $page, $pageSize);
		if($aMissionList === false){
			return false;
		}
		return $aMissionList;
	}


	/**
	 *检查作答格式
	 */
	private function _checkPk($aPkAnswer){
		if(!isset($aPkAnswer['id']) || !isset($aPkAnswer['user_answer']) || !isset($aPkAnswer['get_time'])){
			return false;
		}
		if(!is_numeric($aPkAnswer['id']) || !is_array($aPkAnswer['user_answer'])){
			return false;
		}
		if(!isset($aPkAnswer['user_answer']['id']) || !isset($aPkAnswer['user_answer']['answer'])){
			return false;
		}
		return true;
	}

	/**
	 *下一条题目
	 */
	private function _nextEs($aEsList){
		if(!is_array($aEsList)){
			alert('网络可能有点慢啦啦', 0);
		}

		$nextEsId = 0;
		foreach($aEsList as $esId => $esStatus){
			if($esStatus == 2){
				$nextEsId = $esId;
				break;
			}
		}
		if($nextEsId == 0){
			return false;
		}

		$oEs = m('Es');
		$aNextEs = $oEs->getOfficialEsInfoById($nextEsId);
		if(!$aNextEs){
			alert('获取ID为 <b>' . $nextEsId . '</b> 的下一题时出错啦啦啦', 0);
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aNextEs['type_id']]);
		$aNextEs['es_content'] = $oEsPlugin->resolve($aNextEs['content_json']);
		$aNextEs['es_content'] = $oEsPlugin->removeAnswer($aNextEs['es_content']);
		$aNextEs['id'] = Xxtea::encrypt($aNextEs['id']);
		$now = time();
		$aNextEs['get_time'] = Xxtea::encrypt($now);
		Cookie::set('pkt', md5($now));
		return $aNextEs;
	}

	/**
	 *统计题目数量
	 */
	private function _countEsNum($aStatus, $aEsList){
		$nums = 0;
		foreach($aEsList as $esStatus){
			if(in_array($esStatus, $aStatus)){
				$nums++;
			}
		}
		return $nums;
	}

	/**
	 *	计算PK的状态
	 */
	private function _getPkStatus($aPk){
		$pkStatus = 0;
		$nowTime = NOW_TIME;
		$overTime = $aPk['over_time'];
		$senderStartTime = $aPk['sender_user_start_time'];
		$senderEndTime = $aPk['sender_user_end_time'];
		$receiverStartTime = $aPk['receiver_user_start_time'];
		$receiverEndTime = $aPk['receiver_user_end_time'];
		$duration = $aPk['duration'] * 60;
		$senderOverTime = $senderStartTime + $duration;
		$receiverOverTime = $receiverStartTime + $duration;
		$isSenderOverTime = $nowTime > $senderOverTime;
		$isReceiverOverTime = $nowTime > $receiverOverTime;
		$isSenderEndPk = $isSenderOverTime || $senderEndTime;
		$isReceiverEndPk = $isReceiverOverTime || $receiverEndTime;

		if($overTime > $nowTime){
			if(!$senderStartTime && !$receiverStartTime){
				$pkStatus = 1;	//双方还没开始做题
			}elseif(($senderStartTime && !$senderEndTime && !$isSenderOverTime) && !$receiverStartTime){
				$pkStatus = 2;	//发起者正在做题，接受者还没开始做题
			}elseif(($receiverStartTime && !$receiverEndTime && !$isReceiverOverTime) && !$senderStartTime){
				$pkStatus = 3;	//接受者正在做题，发起者还没开始做题
			}elseif(($senderStartTime && !$senderEndTime && !$isSenderOverTime) && ($receiverStartTime && !$receiverEndTime && !$isReceiverOverTime)){
				$pkStatus = 4;	//双方已开始做题，但还没完成
			}elseif(($isSenderEndPk || $isSenderOverTime) && !$receiverStartTime){
				$pkStatus = 5;	//发起者完成了PK，接受者还没开始做题
			}elseif(($isSenderEndPk || $isSenderOverTime) && !$isReceiverEndPk){
				$pkStatus = 6;	//发起者完成了PK，接受者正在做题
			}elseif(($isReceiverEndPk || $isReceiverOverTime) && !$senderStartTime){
				$pkStatus = 7;	//接受者完成了PK，发起者还没开始做题
			}elseif(($isReceiverEndPk || $isReceiverOverTime) && !$isSenderEndPk){
				$pkStatus = 8;	//接受者完成了PK，发起者正在做题
			}elseif($isSenderEndPk && $isReceiverEndPk){
				$pkStatus = 9;	//PK结束
			}
		}else{
			$pkStatus = 9;		//PK结束
		}

		return $pkStatus;
	}

	/**
	 *	检查用户是否存在
	 */
	private function _checkUserExist($userId){
		$oUser = m('User');
		$aUser = $oUser->getUserDetailInfoByUserId($userId);
		if(!$aUser){
			return false;
		}else{
			return $aUser;
	}
		}

	//得到可发起PK的科目
	private function _getPkSubject(){
		$pkSubject = array();
		foreach($GLOBALS['SUBJECT'] as $key => $value){
			if($key < 4){
				$pkSubject[$key] = $value;
	}
		}
		return $pkSubject;
	}

	private function _updateNearlyChoosePkUserList($targetPkUserId){
		$oPk = m('Pk');
		$aTargetUser = getUserInfo($targetPkUserId, array('personal', 'class'));
		if($aTargetUser){
			$aData = $oPk->getUserPkCountListByUserIds(array($targetPkUserId));
			if(!$aData){
				alert('抱歉，系统出错，请稍后再试！', 0);
			}
			$aTempUser = array(
				'id' => $aTargetUser['id'],
				'name' => $aTargetUser['name'],
				'profile' => $aTargetUser['profile'],
				'grade' => $aTargetUser['grade'],
				'pk_count' => $aData[0]['pk_count'],
				'win_count' => $aData[0]['win_count'],
				'win_percent' => ($aData[0]['pk_count']) ? intval(($aData[0]['win_count'] / $aData[0]['pk_count']) * 100) : 0
			);
		}else{
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aTargetRecord = json_decode(Cookie::get('nearlyPkTarget_' . $this->_userId), true);
		$aNewTargetRecord = array();
		array_push($aNewTargetRecord, $aTempUser);
		if($aTargetRecord){
			foreach($aTargetRecord as $k => $aRecord){
				if($aTempUser['id'] != $aRecord['id'] && count($aNewTargetRecord) < 3){
					array_push($aNewTargetRecord, $aTargetRecord[$k]);
				}
			}
		}
		Cookie::set('nearlyPkTarget_' . $this->_userId, json_encode($aNewTargetRecord), time() + 31536000);
		return $aNewTargetRecord;
	}

	private function _getNearlyChoosePkUserList(){
		return json_decode(Cookie::get('nearlyPkTarget_' . $this->_userId), true);
	}

	/*Pk动态*/
	public function showPkTrends(){
		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		$oUserNumerical = m('UserNumerical');
		$aWorldRankList = $oUserNumerical->getMedalRankingList('pk_win_times', 3, 1, 40);

		//我的勋章
		$aMyPkMedal = $this->_getPkMedal();
		if($aMyPkMedal === false){
			alert('系统错误', 0);
		}

		//所有好友ID
		$oSns = m('Sns');
		$aFriendIdList = $oSns->getUserFriendsIdList($this->_userId);
		if($aFriendIdList === false){
			alert('系统错误', 0);
		}
		array_push($aFriendIdList, $this->_userId);

		assign('aWorldRankList', $aWorldRankList);
		assign('aUserInfo', $aUserInfo);
		assign('aMyPkMedal', $aMyPkMedal);
		assign('aFriendIdList', $aFriendIdList);
		assign('aUser', $this->_aUser);
		assign('userId', $this->_userId);
		assign('acceptPkCount', $this->_acceptPkCount);
		displayHeader('PK动态');
		display('pk/pk_event.html.php');
		displayLeftNav($this->_userId, true);
		displayFooter();
	}

	public function getUserMissionInfo(){
		$missionId = intval(post('missionId', 0));
		if(!$missionId){
			alert('', 1, array('es_count' => 0, 'es_correct_count' => 0, 'score' => 0));
		}
		$oMission = m('mission');
		$aUserMissionInfo = $oMission->getUserMissionInfo($missionId, $this->_userId);
		if(!$aUserMissionInfo || !$aUserMissionInfo['is_pass']){
			alert('', 1, array('es_count' => 0, 'es_correct_count' => 0, 'score' => 0));
		}
		alert('', 1, array('es_count' => $aUserMissionInfo['es_count'], 'es_correct_count' => $aUserMissionInfo['es_correct_count'], 'score' => $aUserMissionInfo['score']));
	}

	//向接受者推关应用消息
	private function _sendPkAppMessageToReceiver($senderId, $receiverId){
		$aUser = getUserInfo($receiverId, array('personal'));
		if(!empty($aUser['xxt_data'])){
			$aSenderIdUser = getUserInfo($senderId, array('personal'));
			$contentStr = $aSenderIdUser['name'] . '在优满分向您发出了一场PK，赶快去应战吧！';
			$wait7Time = strtotime('+7 Days');
			$aContent = array(
				'City' => $aUser['xxt_data']['CityId'],
				'UserType' => 2,
				'IsOauth' => 0,
				'OthMsgId' => time(),
				'ValidDate' => date('Y-m-d H:i:s', $wait7Time),
				'URL' => url('m=Pk&a=showList', '', APP_HOME),
				'Type' => 1,
				'SchoolId' => $aUser['xxt_data']['SchoolId'],
				'Content' => $contentStr
			);

			try{
				$result = Xxt::postAppMessage($aUser['xxt_data']['UserId'], $aContent);
			}catch(XxtException $e){
				$e->log();
			}
		}
	}

}