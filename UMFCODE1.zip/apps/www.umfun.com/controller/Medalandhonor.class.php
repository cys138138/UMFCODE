<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-10-30
 */
class MedalandhonorController{
	private $_userId = 0;
	private $_aUser = array();
	public static $aMedalExplain = array(
		//'challenge_times' => '勋章等级和完成的挑战次数有关，包括失败和成功。挑战次数越多等级越高',
		'passed_missions' => '勋章等级和<b>首次</b>成功挑战的关卡个数有关，个数越多等级越高',
		'excellent_missions' => '勋章等级和成功挑战且得分超过<b>90</b>的关卡个数有关，个数越多等级越高',
		//'perfect_missions' => '勋章等级和<b>首次</b>成功挑战且正确率<b>100%</b>的关卡个数有关，个数越多等级越高',
		//'pk_times' => '勋章等级和完成PK场数有关，场数越多等级越高',
		'pk_win_times' => '勋章等级和胜利的PK场数有关，场数越多等级越高',
		//'match_times' => '勋章等级和参加比赛的次数有关，次数越多等级越高',
		//'match_win_times' => '勋章等级和参加比赛获得<b>排名奖</b>个数有关，次数越多等级越高',
		//'comment_support_times' => '勋章等级和您的题目评论里面被支持的次数有关，被支持次数越多等级越高',
	);


	public function __construct(){
		$this->_aUser = checkUserLogin();
		$this->_userId = $this->_aUser['id'];
	}

	/**
	 *显示个人勋章详细页
	 */
	public function showMedal(){
		$userId = intval(get('userId'));
		if(!$userId){
			$userId = $this->_userId;
		}

		//获取勋章
		$aMedalResult = $this->_getMedal($userId);
		assign('medalCount', $aMedalResult['medalCount']);
		assign('aMedal', $aMedalResult['aMedal']);
		assign('aNgetMedal', $aMedalResult['aNgetMedal']);
		assign('userId', $userId);

		$role = 'TA的';
		$who = 'TA';
		assign('role', $role);
		assign('who', $who);

		$aMedalEventList = $this->_getMedalEvent($aMedalResult['medal_process']);
		assign('aMedalEventList', $aMedalEventList);

		displayHeader('TA的勋章');
		display('medal/medal.html.php');
		displayFooter(true);
	}

	/**
	 *显示个人勋章详细页
	 */
	public function showMyMedal(){
		//获取勋章
		$aMedalResult = $this->_getMedal($this->_userId);
		assign('medalCount', $aMedalResult['medalCount']);
		assign('aMedal', $aMedalResult['aMedal']);
		assign('aNgetMedal', $aMedalResult['aNgetMedal']);

		$aMedalEventList = $this->_getMedalEvent($aMedalResult['medal_process']);
		assign('aMedalEventList', $aMedalEventList);

		assign('userId', $this->_userId);
		assign('aUser', $this->_aUser);
		displayHeader('我的勋章');
		display('medal/my_medal.html.php');
		displayLeftNav($this->_userId);
		displayFooter();
	}

	/**
	 *勋章排名
	 */
	public function medalRanking(){
		$page = intval(post('page'));
		if(!$page){
			$page = 1;
		}
		$medalId = intval(post('medal'));
		if(!array_key_exists($medalId, $GLOBALS['MEDAL_EVENT'])){
			alert('勋章不存在', 0);
		}
		$role = post('role');
		if($role != 1 && $role != 2){
			alert('参数错误', 0);
		}
		$oMedal = m('UserNumerical');
		$medalField = Numerical::$aIdMedalRelation[$medalId]['db_field'];
		$medalPoint = $GLOBALS[Numerical::$aIdMedalRelation[$medalId]['config_key']][1]['nums'];
		if($role == 1){
			$aUserList = array();
		}elseif($role == 2){
			$oSns = m('Sns');
			$userIds = $oSns->getUserFriendIds($this->_userId);
			if($userIds){
				$userIds .= ',' . $this->_userId;
			}else{
				$userIds = $this->_userId;
			}
			$aUserList = explode(',', $userIds);
		}
		$oNum = new Numerical();
		$aMedalRanking = $oMedal->getMedalRankingList($medalField, $medalPoint, $page, 10, $aUserList);
		$aMyRanking = $oMedal->getUserRankingCount($this->_userId, $medalField, $aUserList);
		$aMyRanking['level'] = $oNum->countLevel($medalId, $aMyRanking['accumulate_points']);
		foreach($aMedalRanking as $key => $aRanking){
			$aMedalRanking[$key]['level'] = $oNum->countLevel($medalId, $aRanking['accumulate_points']);
		}
		alert('good', 1, array('list' => $aMedalRanking, 'my' => $aMyRanking));
	}


	private function _rankingFriendsByMedal($medalKey, $aList){
		$aNewList = array();
		foreach($aList as $key => $aFriend){
			$aNewList[$key]['id'] = $aList[$key]['id'];
			$aNewList[$key]['user_info'] = $aList[$key]['user_info'];
			$aNewList[$key][$medalKey] = $aList[$key][$medalKey];
		}
		return $aNewList;
	}

	private function _getMedal($userId){
		$oUserNumerical = m('UserNumerical');
		$aUserMedal = $oUserNumerical->getMedalInfoById($userId);
		if(!$aUserMedal){
			$aUserMedal = array();
			$aUserMedal['id'] = $userId;
			$aUserMedal['passed_missions'] = 0;
			$aUserMedal['excellent_missions'] = 0;
			$aUserMedal['pk_win_times'] = 0;
			$aUserMedal['gold_medal'] = 0;
			$aUserMedal['silver_medal'] = 0;
			$aUserMedal['cuprum_medal'] = 0;
			$aUserMedal['medal_process'] = array();
			if(!$oUserNumerical->addMedal($aUserMedal)){
				return false;
			}
		}

		$medalCount = 0;
		$aMedal = array();
		$aNgetMedal = array();
		$oNum = new Numerical();
		foreach(Numerical::$aIdMedalRelation as $medalId => $aSysMedal){
			if($aUserMedal[$aSysMedal['db_field']] >= $GLOBALS[$aSysMedal['config_key']][1]['nums']){
				$aMedal[$aSysMedal['db_field']] = array();
				$aMedal[$aSysMedal['db_field']]['name'] = $GLOBALS['MEDAL_EVENT'][$medalId];
				$aMedal[$aSysMedal['db_field']]['level'] = $oNum->countLevel($medalId, $aUserMedal[$aSysMedal['db_field']]);
				$aMedal[$aSysMedal['db_field']]['point'] = $aUserMedal[$aSysMedal['db_field']];
				$aMedal[$aSysMedal['db_field']]['top_level'] = count($GLOBALS[$aSysMedal['config_key']]);
				$aMedal[$aSysMedal['db_field']]['explain'] = self::$aMedalExplain[$aSysMedal['db_field']];
				if($aMedal[$aSysMedal['db_field']]['level'] < $aMedal[$aSysMedal['db_field']]['top_level']){
					$nextLevel = $aMedal[$aSysMedal['db_field']]['level'] + 1;
					$aMedal[$aSysMedal['db_field']]['next_left_point'] = $GLOBALS[$aSysMedal['config_key']][$nextLevel]['nums'] - $aMedal[$aSysMedal['db_field']]['point'];
				}
				$aMedal[$aSysMedal['db_field']]['img'] = $GLOBALS['MEDAL_IMG'][$medalId];
				$medalCount++;
			}else{
				$aNgetMedal[$aSysMedal['db_field']] = array();
				$aNgetMedal[$aSysMedal['db_field']]['name'] = $GLOBALS['MEDAL_EVENT'][$medalId];
				$aNgetMedal[$aSysMedal['db_field']]['explain'] = self::$aMedalExplain[$aSysMedal['db_field']];
				$aNgetMedal[$aSysMedal['db_field']]['img'] = $GLOBALS['MEDAL_IMG'][$medalId];
			}
		}
		return array(
			'medalCount' => $medalCount,
			'aMedal' => $aMedal,
			'aNgetMedal' => $aNgetMedal,
			'medal_process' => $aUserMedal['medal_process'],
		);
	}

	private function _getMedalEvent($aMedalProcess){
		$aMedalEventList = array();
		foreach($aMedalProcess as $key => $aHistory){
			$aLevel = array_keys($aHistory);
			$newLevel = $aLevel[(count($aLevel)-1)];
			$key = str_replace('_medal', '', $key);
			if($key == 'passed_missions'){
				$aMedalEventList[$aHistory[$newLevel]]['name'] = $GLOBALS['MEDAL_EVENT'][2];
			}elseif($key == 'excellent_missions'){
				$aMedalEventList[$aHistory[$newLevel]]['name'] = $GLOBALS['MEDAL_EVENT'][3];
			}elseif($key == 'pk_win_times'){
				$aMedalEventList[$aHistory[$newLevel]]['name'] = $GLOBALS['MEDAL_EVENT'][6];
			}
			$aMedalEventList[$aHistory[$newLevel]]['level'] = $newLevel;
		}
		return $aMedalEventList;
	}

	/**
	public function getFriendMedalEventList(){
		$page = intval(get('page'));
		if(!$page){
			$page = 1;
		}
		$oSns = m('Sns');
		$aUserIds = $oSns->getUserFriendIdList($this->_userId);
		array_push($aUserIds, $this->_userId);
		$aMedalEventList = $oSns->getEventList($aUserIds, 8, $page, 5);
		alert($aMedalEventList, 1);
	}*/
}