<?php
class MatchController{
	private $_userId = 0;
	private $_aUser = array();

	private $_aMatchStatus = array(
		'0' => array(
			'text' => '赛事未发布',
			'description' => '赛事未发布'
		),
		'1' => array(
			'text' => '马上报名',
			'description' => '报名时间未到（马上报名按钮不可用）'
		),
		'2' => array(
			'text' => '马上报名',
			'description' => '报名时间，用户未报名（马上报名）'
		),
		'3' => array(
			'text' => '准备参赛',
			'description' => '报名时间，用户已报名（准备参赛按钮不可用）'
		),
		'4' => array(
			'text' => '准备参赛',
			'description' => '未到开赛时间（准备参赛按钮不可用）'
		),
		'5' => array(
			'text' => '立即参赛',
			'description' => '比赛时间，用户可以进入赛事，但还没进入赛事（立即参赛）'
		),
		'6' => array(
			'text' => '继续未完赛事',
			'description' => '比赛时间，比赛进行中，还可进入本次比赛（继续未完赛事）'
		),
		'7' => array(
			'text' => '再次参赛',
			'description' => '比赛时间，比赛超时，本次比赛结束（再次参赛）'
		),
		'8' => array(
			'text' => '无参赛资格',
			'description' => '比赛时间，比赛进行中，但是用户未报名'
		),
		'9' => array(
			'text' => '比赛结束',
			'description' => '比赛结束'
		),
		'10' => array(
			'text' => '立即参赛',
			'description' => '比赛时间，用户可以进入赛事，但还没进入赛事（立即参赛）'
		),
		'11' => array(
			'text' => '已完成比赛',
			'description' => '没有参赛机会了（再次参赛按钮不可用）'
		),
		'12' => array(
			'text' => '无参赛资格',
			'description' => '比赛时间没到，用户没报名'
		)
	);


	//科目
	private function _getSubjectList(){
		$subjectArray = array();
		foreach($GLOBALS['SUBJECT'] as $key=> $subject){
			$subjectArray[$key] = $subject;
		}
		$subjectArray[99] = '综合';
		return $subjectArray;
	}

	//年级列表
	private $_gradeArray = array(
		/*
		1	=>	'一年级',
		2	=>	'二年级',
		3	=>	'三年级',
		4	=>	'四年级',
		 */
		5	=>	'五年级',
		6	=>	'六年级',
		7	=>	'初一',
		8	=>	'初二',
		9	=>	'初三',
		10	=>	'小升初',
		11	=>	'中考'
	);

	//奖项
	private $_awardsArray = array(
		1 => '冠 军',
		2 => '亚 军',
		3 => '季 军',
		4 => '第四名',
		5 => '第五名',
		6 => '第六名',
		7 => '第七名',
		8 => '第八名',
		9 => '第九名',
		10 => '第十名'
	);

	public function __construct(){
		if(get('a') != 'showNewCenter' && get('a') != 'moreMatchList'){
			header('Location:' . url('m=Match&a=showCenter'));
			exit;
			myLog('坑爹,怎么还回来!');
			exit('抱歉,本页已禁用');
			if(get('a') != 'showNewCenter' && get('a') != 'moreMatchList'){
				$this->_aUser = checkUserLogin();
				$this->_userId = $this->_aUser['id'];
			}
		}
	}

	//全部赛事
	public function showCenter(){

		//侧边栏好友动态
		$aMatchEventList = $this->_getMatchEventList();
		if($aMatchEventList === false){
			alert('网络可能有点慢请再次刷新页面！',0);
		}

		//侧边栏我的奖牌
		$aMedalList = $this->_myMedal();
		if($aMedalList === false){
			alert('网络可能有点慢请再次刷新页面！',0);
		}

		$showType = get('type', 'all');
		assign('aEventList', $aMatchEventList[1]);
		assign('eventTitle', $aMatchEventList[0]);
		assign('aMedalList', $aMedalList);
		assign('userId', $this->_userId);
		assign('showType', $showType);
		displayHeader('赛事中心');
		display('match/match_center.html.php');
		displayFooter();
	}

	//新版全部赛事
	public function showNewCenter(){
		$showType = get('type', 'all');
		assign('isLogin', isLogin() ? 1 : 0);
		assign('userId', $this->_userId);
		assign('showType', $showType);
		display('match/match_new_center.html.php');
		displayFooter();
	}

	//侧边栏动态
	private function _getMatchEventList(){
		$oSns = m('Sns');
		$aFriendIdList = $oSns->getUserFriendsIdList($this->_userId);
		array_push($aFriendIdList, $this->_userId);

		$eventType = array(9, 11, 12, 17);
		$eventPage = 1;
		$eventPageSize = 5;
		$eventTitle = '好友动态';
		$oEvent = m('SnsEvent');
		$aEventList = $oEvent->getEventListForMatch($aFriendIdList, $eventType, $eventPage, $eventPageSize);
		if($aEventList === false){
			return false;
		}


		if(!$aEventList){
			$eventTitle = '全部动态';
			$aEventList = $oEvent->getEventListForMatch(array(), $eventType, $eventPage, $eventPageSize);
		}
		if($aEventList === false){
			return false;
		}

		$aEventList2 = array($eventTitle, $aEventList);
		unset($aEventList);
		return $aEventList2;
	}

	//侧边栏我的奖牌
	private function _myMedal(){
		$oNumerical = m('UserNumerical');
		$aMedalList = $oNumerical->getMedalListByUserIds(array($this->_userId));
		if($aMedalList === false){
			return $aMedalList;
		}

		return $aMedalList[0];
	}

	//侧边栏奖牌榜
	public function getMedalRandkingList(){
		$page = intval(post('page', 1));
		if($page <= 0){
			alert('抱歉您传页码有误！', -1);
		}elseif($page > 10){
			alert('抱歉最多只能查看10页排行!', -1);
		}

		$order = post('order', 0);
		if($order == 0){
			$order = '';
		}elseif($order == 1){
			$order = 'gold_medal DESC';
		}elseif($order == 2){
			$order = 'silver_medal DESC';
		}elseif($order == 3){
			$order = 'cuprum_medal DESC';
		}else{
			alert('抱歉，您所传参数有误！', -1);
		}

		$pageSize = 8;
		$oNumerical = m('UserNumerical');
		$aMedalRandkingList = $oNumerical->getUserMedalRankingListForMatch($page, $pageSize, $order);
		if($aMedalRandkingList === false){
			alert('网络可能有点慢，请再次刷新页面！', -1);
		}
		foreach($aMedalRandkingList as $key=>$aMedalRandking){
			$aMedalRandkingList[$key]['randNum'] = ($page - 1) * $pageSize + $key + 1;
		}

		if($page > 1 && !$aMedalRandkingList){
			alert('最后一页了哦！', -1);
		}

		alert('', 1, $aMedalRandkingList);
	}



	//ajax取赛事分页列表
	public function moreMatchList(){
		$page = intval(post('page', 1));
		$type =  post('type', 'all');
		$oMatch = new Match();
		$aResult = $oMatch->moreMatchList($page, $type, 30);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}


	//我的赛事
	public function  showMyCenter(){
		//推荐的比赛
		$length = 6;
		$aRecommendMacthList = $this->_getRecommendMatchList($length);
		if($aRecommendMacthList === false){
			alert('系统错误', 0);
		}

		//好友动态 or 全部动态
		//所有好友ID
		$oSns = m('Sns');
		$aFriendIdList = $oSns->getUserFriendsIdList($this->_userId);
		array_push($aFriendIdList, $this->_userId);

		$eventType = array(9, 11, 12, 17);
		$eventPage = 1;
		$eventPageSize = 5;
		$eventTitle = '好友动态';
		$oEvent = m('SnsEvent');
		$aEventList = $oEvent->getEventListForMatch($aFriendIdList, $eventType, $eventPage, $eventPageSize);
		if($aEventList === false){
			alert('系统错误', 0);
		}

		if(!$aEventList){
			$eventTitle = '全部动态';
			$aEventList = $oEvent->getEventListForMatch(array(), $eventType, $eventPage, $eventPageSize);
		}
		if($aEventList === false){
			alert('系统错误', 0);
		}

		$oMatch = m('Match');
		//是否有获奖的赛事
		$winnersMatchCount = $oMatch -> getUserPrizeMatchCount($this->_userId);
		if($winnersMatchCount === false){
			alert('系统错误', 0);
		}
		//赛事总数
		$matchCount = $oMatch->getUserMatchCount($this->_userId);
		if($matchCount === false){
			alert('系统错误', 0);
		}

		$aGradeList = $this->_gradeArray;
		$aSubjectList = $this->_getSubjectList();

		//侧边栏我的奖牌
		$aMedalList = $this->_myMedal();
		if($aMedalList === false){
			alert('网络可能有点慢请再次刷新页面！',0);
		}

		assign('aMedalList', $aMedalList);
		assign('aRecommendMacthList', $aRecommendMacthList);
		assign('eventTitle', $eventTitle);
		assign('aEventList', $aEventList);
		assign('userId', $this->_userId);
		assign('aGradeList', $aGradeList);
		assign('aSubjectList', $aSubjectList);
		assign('winnersMatchCount', $winnersMatchCount);
		assign('matchCount', $matchCount);

		displayHeader('赛事中心');
		display('match/match_my_center.html.php');
		displayFooter();

	}


	//我的赛事列表
	public function getMatchListByUser(){
		$page = intval(post('page', 1));
		$type = intval(post('type', 1));
		$prizeFlag = intval(post('isPrize', 0));

		$oMatch = new Match();
		$aResult = $oMatch->getMatchListByUser($type, $page, 6, $prizeFlag, 0);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}




	//赛事动态
	public function showMatchEventList(){
		//推荐的比赛
		$length = 3;
		$aRecommendMacthList = $this->_getRecommendMatchList($length);
		if($aRecommendMacthList === false){
			alert('系统错误', 0);
		}

		//所有好友ID
		$oSns = m('Sns');
		$aFriendIdList = $oSns->getUserFriendsIdList($this->_userId);
		if($aFriendIdList === false){
			alert('系统错误', 0);
		}
		array_push($aFriendIdList, $this->_userId);

		//侧边栏我的奖牌
		$aMedalList = $this->_myMedal();
		if($aMedalList === false){
			alert('网络可能有点慢请再次刷新页面！', 0);
		}
		assign('aMedalList', $aMedalList);

		assign('aUser', $this->_aUser);
		assign('userId', $this->_userId);
		assign('aRecommendMacthList', $aRecommendMacthList);
		assign('aFriendIdList', $aFriendIdList);

		displayHeader('赛事中心');
		display('match/match_event.html.php');
		displayFooter();
	}



	//赛事详情
	public function showDetail(){
		$matchId = intval(get('match_id'));
		if($matchId < 1){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($matchId);
		if($aMatchInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		if(!$aMatchInfo){
			alert('赛事不存在！', 0);
		}

		//年级和科目
		$aSubjectList = $this->_getSubjectList();
		$aGradeList = $this->_gradeArray;
		$aMatchInfo['grade_name'] = '';
		$aMatchInfo['subject_name'] = '';
		if(isset($aGradeList[$aMatchInfo['grade_id']])){
			$aMatchInfo['grade_name'] = $aGradeList[$aMatchInfo['grade_id']];
		}
		if(isset($aSubjectList[$aMatchInfo['subject_id']])){
			$aMatchInfo['subject_name'] = $aSubjectList[$aMatchInfo['subject_id']];
		}
		$aMatchInfo['profile'] = SYSTEM_RESOURCE_URL .$aMatchInfo['profile'];
		$aMatchInfo['match_time_str'] = date('n月j日 H:i', $aMatchInfo['match_start_time']) . ' - ' . date('n月j日 H:i', $aMatchInfo['match_end_time']);

		$registrationCount = $oMatch->getRegistrationCountByMatchId($aMatchInfo['id']);
		if($registrationCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		//参赛人数
		$aMatchInfo['registration_count'] = $registrationCount;
		unset($registrationCount);

		//总题数
		$aMatchInfo['es_count'] = 0;
		foreach($aMatchInfo['es_rule'] as $rule){
			$aMatchInfo['es_count'] = $aMatchInfo['es_count'] + $rule['es_count'];
		}
		//本场目前最高得分
		$bestScore = '0';
		$myScore = '0';
		$myRank = 0;
		$aMatchRank = $oMatch->getMatchRankingList($matchId, 1, 1);
		if($aMatchRank === false){
			alert('系统错误', 0);
		}
		if($aMatchRank){
			$bestScore = $aMatchRank[0]['best_score'] / 100;
		}
		$aMyRelationInfo = $oMatch->getMatchUserRelationInfo($this->_userId, $matchId);
		if($aMyRelationInfo === false){
			alert('系统错误', 0);
		}
		$isJoin = 0;
		if($aMyRelationInfo){
			$isJoin = 1;
			$myScore = $aMyRelationInfo['best_score'] / 100;
			$myRank = $oMatch->getMatchRanking($matchId, $aMyRelationInfo['best_score']);
			if($myRank === false){
				alert('系统错误', 0);
			}
		}


		unset($aMatchRank);
		//unset($aMyRelationInfo);

		//倒计时处的处理
		$aBeginTime = array(
			'status'=> 1,		//进行中 立刻参赛
			'day'	=> '00',
			'hour'	=> '00',
			'minute'=> '00',
			'second'=> '00'
		);
		$secondStr = 0;
		$now = time();

		if($aMatchInfo['match_start_time'] > $now){
			$aBeginTime['status'] = 0; //未开始
		}elseif($aMatchInfo['match_end_time'] <= $now){
			$aBeginTime['status'] = 2; //己结束
		}

		//未开始 计算还有多久开始
		if($aBeginTime['status'] == 0){
			$secondStr = $aMatchInfo['match_start_time'] - $now;
		//进行中 计算还有多久结束
		}elseif($aBeginTime['status'] == 1){
			$secondStr = $aMatchInfo['match_end_time'] - $now;
		}

		//当前用户是否是第一次参加比赛
		$relationId = 0;
		$myHistory = array();
		if($aMyRelationInfo){
			if($aBeginTime['status'] == 1 ){
				$relationId = $aMyRelationInfo['id'];
				$aBeginTime['status'] = 3; //再次参赛

				if(($aMyRelationInfo['remainder_es_ids'] && $aMyRelationInfo['start_time'] == 0 && $aMyRelationInfo['end_time'] == 0) || ($aMyRelationInfo['remainder_es_ids'] && $aMyRelationInfo['start_time'] > 0 && ($now - $aMyRelationInfo['start_time'] < $aMatchInfo['duration'] * 60))){
					$aBeginTime['status'] = 4; //继续末完成比赛
				}
			}
			$myHistory = $aMyRelationInfo['match_history'];
			foreach ($myHistory as $key=>$history){
				$myHistory[$key]['date_str'] = '超时结束'; //超时
				if($history['end_time'] > 0){
					$myHistory[$key]['date_str'] = date('m-d H:i:s', $history['end_time']); //正常结束
				}elseif( $key+1 == count($myHistory) && $now - $aMyRelationInfo['start_time']  < $aMatchInfo['duration'] * 60 ){
					$myHistory[$key]['date_str'] = '<a href="javascript:void(0)" onclick="goToMatch()" title="点击继续">正在进行中...</a>'; //进行中...
				}

			}

		}

		if($secondStr > 0){
			$daySecond = 86400;
			$hourSecond = 3600;
			$minuteSecond = 60;
			if($secondStr / $daySecond > 1){
				$aBeginTime['day'] = floor($secondStr / $daySecond);
				if($aBeginTime['day'] < 10){
					$aBeginTime['day'] = '0' . $aBeginTime['day'];
				}
				$secondStr = $secondStr - ($aBeginTime['day'] * $daySecond);
			}

			if($secondStr > $hourSecond){
				$aBeginTime['hour'] = floor($secondStr / $hourSecond);
				if($aBeginTime['hour'] < 10){
					$aBeginTime['hour'] = '0' . $aBeginTime['hour'];
				}
				$secondStr = $secondStr - ($aBeginTime['hour'] * $hourSecond);
			}
			if($secondStr > $minuteSecond){
				$aBeginTime['minute'] = floor($secondStr / $minuteSecond);
				if($aBeginTime['minute'] < 10){
					$aBeginTime['minute'] = '0' . $aBeginTime['minute'];
				}
				$secondStr = $secondStr - ($aBeginTime['minute'] * $minuteSecond);
			}
			$aBeginTime['second'] = $secondStr;
			if($aBeginTime['second'] < 10){
				$aBeginTime['second'] =  '0' . $aBeginTime['second'];
			}
		}

		//经验计算
		$aPrizePoints = $oMatch->getPrizeAccumulatePoints($matchId);

		//获奖名单处理
		$aWinersTopUser = array();
		if(isset($aMatchInfo['winners']['top']) && $aMatchInfo['winners']['top']){
			foreach($aMatchInfo['winners']['top'] as $key => $aTop){
				if(isset($aTop['user_info']) && isset($this->_awardsArray[$key])){
					$_aTmpUser = array();
					$_aTmpUser['user_id'] = $aTop['user_id'];
					$_aTmpUser['user_name'] = $aTop['user_info']['name'];
					$_aTmpUser['user_profile'] = $aTop['user_info']['profile'];
					$_aTmpUser['receive_time'] = $aTop['receive_time'];
					$_aTmpUser['awards_name'] = $this->_awardsArray[$key];
					$_aTmpUser['awards_str'] = '';
					$_aTmpUser['best_score'] = 0;
					$_aTmpUser['awards_gold'] = 0;
					$_aTmpUser['awards_prize'] = '';
					$_aTmpUser['item_class'] = 'apex';
					if($key > 3){
						$_aTmpUser['item_class'] = 'item';
					}
					if(isset($aMatchInfo['awards']['top'][$key]['prize']) && $aMatchInfo['awards']['top'][$key]['prize']){
						$_aTmpUser['awards_prize'] = $aMatchInfo['awards']['top'][$key]['prize'];
						$_aTmpUser['awards_str'] .= '<em>' .$aMatchInfo['awards']['top'][$key]['prize'] . '</em> + ';
					}
					if($key < 4){
						$_aTmpUser['awards_str'] .= '<em>' . $aPrizePoints[$key] . '经验</em> + ';
					}else{
						$_aTmpUser['awards_str'] .= '<em>' . $aPrizePoints[4] . '经验</em> + ';
					}

					if(isset($aMatchInfo['awards']['top'][$key]['gold']) && $aMatchInfo['awards']['top'][$key]['gold']){
						$_aTmpUser['awards_gold'] = $aMatchInfo['awards']['top'][$key]['gold'];
						$_aTmpUser['awards_str'] .= '<em>' .$aMatchInfo['awards']['top'][$key]['gold'] . '金币</em>';
					}
					$aTopUserMatch = $oMatch->getMatchUserRelationInfo($aTop['user_id'], $aMatchInfo['id']);
					if($aTopUserMatch === false){
						alert('抱歉，系统出错，请稍后再试！', 0);
					}
					if(isset($aTopUserMatch['best_score']) && $aTopUserMatch['best_score'] > 0){
							$_aTmpUser['best_score'] = $aTopUserMatch['best_score'] / 100;
					}
					unset($aTopUserMatch);
					$aWinersTopUser[] = $_aTmpUser;
					unset($_aTmpUser);
				}
			}
		}

		$aWinersRandUser = array();
		if(isset($aMatchInfo['winners']['rand']) && $aMatchInfo['winners']['rand']){
			foreach($aMatchInfo['winners']['rand'] as $key => $aRand){
				if(isset($aRand['user_info'])){
					$_aTmpUser = array();
					$_aTmpUser['user_id'] = $aRand['user_id'];
					$_aTmpUser['user_name'] = $aRand['user_info']['name'];
					$_aTmpUser['user_profile'] = $aRand['user_info']['profile'];
					$_aTmpUser['receive_time'] = $aRand['receive_time'];
					$_aTmpUser['awards_gold'] = 0;
					$_aTmpUser['awards_prize'] = '';
					$_aTmpUser['awards_str'] = '';
					if(isset($aMatchInfo['awards']['rand']['prize']) && $aMatchInfo['awards']['rand']['prize']){
						$_aTmpUser['awards_prize'] = $aMatchInfo['awards']['rand']['prize'];
						$_aTmpUser['awards_str'] .= '<em>' .$aMatchInfo['awards']['rand']['prize'] . '</em> + ';
					}
					$_aTmpUser['awards_str'] .= '<em>' . $aPrizePoints[-1] . '经验</em> + ';
					if(isset($aMatchInfo['awards']['rand']['gold']) && $aMatchInfo['awards']['rand']['gold']){
						$_aTmpUser['awards_gold'] = $aMatchInfo['awards']['rand']['gold'];
						$_aTmpUser['awards_str'] .= '<em>' .$aMatchInfo['awards']['rand']['gold'] . '金币</em>';
					}
					$aWinersRandUser[] = $_aTmpUser;
					unset($_aTmpUser);
				}
			}

		}


		//用户参赛信息
		$oUser = m('User');
		$aUserInfo = $oUser->getUserDetailInfoByUserId($this->_userId);
		if($aUserInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aUserNumerical === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		$aUserInfo = array_merge($aUserInfo, $aUserNumerical);


		//推荐的比赛
		$length = 5;
		$aRecommendMacthList = $this->_getRecommendMatchList($length, $matchId);
		if($aRecommendMacthList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		//这场比赛的赛事动态
		$oSns = m('Sns');
		$aFriendIdList = $oSns->getUserFriendsIdList($this->_userId);
		array_push($aFriendIdList, $this->_userId);
		if($aFriendIdList === false){
			alert('系统错误', 0);
		}

		$eventType = array(9, 11, 12, 17);
		$eventPage = 1;
		$eventPageSize = 20;
		$oEvent = m('SnsEvent');
		$aEventList = getEventList($aFriendIdList, $aFriendIdList, $eventType, $eventPage, $eventPageSize, $matchId);
		if($aEventList === false){
			alert('系统错误', 0);
		}

		if(!$aEventList){
			$aEventList = getEventList(array(), $aFriendIdList, $eventType, $eventPage, $eventPageSize, $matchId);
		}
		if($aEventList === false){
			alert('系统错误', 0);
		}

		//计算我的获奖信息
		$aMyPrizeInfo = array();
		if($aWinersTopUser || $aWinersRandUser){
			$isTop = false;
			foreach($aWinersTopUser as $key => $aWinnersTop){
				if($aWinnersTop['user_id'] == $this->_userId){
					$aMyPrizeInfo = $aWinnersTop;
					if(($key + 1) < 4){
						$aMyPrizeInfo['points'] = $aPrizePoints[$key + 1];
					}else{
						$aMyPrizeInfo['points'] = $aPrizePoints[4];
					}
					$isTop = true;
					break;
				}
			}
			if(!$isTop){
				foreach($aWinersRandUser as $aWinersRand){
					if($aWinersRand['user_id'] == $this->_userId){
						$aMyPrizeInfo = $aWinersRand;
						$aMyPrizeInfo['points'] = $aPrizePoints[-1];
						break;
					}
				}
			}
		}

		$aChineseStr = array('一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五','十六','十七','十八','十九','二十');
		$validateJs = j('mobile,detailedPlace,areaId');
		$title = '比赛详情';
		assign('aPrizePoints', $aPrizePoints);
		assign('aChineseStr', $aChineseStr);
		assign('userId', $this->_userId);
		assign('aMatchInfo', $aMatchInfo);
		assign('aBeginTime', $aBeginTime);
		assign('aFriendIdList', $aFriendIdList);
		assign('bestScore', $bestScore);
		assign('isJoin', $isJoin);
		assign('myScore', $myScore);
		assign('myRank', $myRank);
		assign('aUserInfo', $aUserInfo);
		assign('relationId', $relationId);
		assign('myHistory', $myHistory);
		assign('aRecommendMacthList', $aRecommendMacthList);
		assign('aSubjectList', $aSubjectList);
		assign('aGradeList', $aGradeList);
		assign('aWinersTopUser', $aWinersTopUser);
		assign('aWinersRandUser', $aWinersRandUser);
		assign('aMyPrizeInfo', $aMyPrizeInfo);
		assign('validateJs', $validateJs);
		assign('aMatchEventList', $aEventList);
		displayHeader($title);

		display('match/match_detail.html.php');
		displayFooter();
	}


	/*
	 *比赛排行榜
	 */

	public function matchRankingList(){
		$page = intval(post('page', 1));
		$matchId = intval(post('id'));
		$pageSize = 10;
		$oMatch = new Match();
		$aResult = $oMatch->matchRankingList($page, $matchId, 10);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}

	/*
	* 比赛动态
	*/
	/* public function getMatchEvenList(){
		$page = intval(post('page', 1));
		$matchId = intval(post('match_id'));
		if($page < 1 || $matchId < 1){
			alert('数据错误', 0);
		}

		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($matchId);
		if($aMatchInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMatchInfo){
			alert('抱歉，不存在此场比赛！', -1);
		}

		$aUserIds = post('user_ids');
		if($aUserIds == 'all'){
			$aUserIds = array();
		}else{
			if(!is_array($aUserIds)){
				alert('数据错误', 0);
			}
		}

		$pageSize = 5;
		$eventType = array(9, 11, 12, 17);
		$oEvent = m('SnsEvent');
		$aEventList = $oEvent->getEventListForMatch($aUserIds, $eventType, $page, $pageSize, $matchId);
		if($aEventList === false){
			alert('系统错误', 0);
		}
		alert('', 1, $aEventList );

	} */

	public function getMatchEvenList(){
		$page = intval(post('page', 1));
		$matchId = intval(post('match_id'));

		if($page < 1 || $matchId < 1){
			alert('数据错误', 0);
		}

		$oMatch = m('Match');
		$aMatchInfo = $oMatch->getMatchInfoById($matchId);
		if($aMatchInfo === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}elseif(!$aMatchInfo){
			alert('抱歉，不存在此场比赛！', -1);
		}

		$oSns = m('Sns');
		$aFriendIdList = $oSns->getUserFriendsIdList($this->_userId);
		array_push($aFriendIdList, $this->_userId);
		if($aFriendIdList === false){
			alert('系统错误', 0);
		}

		$eventType = array(9, 11, 12, 17);
		$eventPageSize = 10;
		$oEvent = m('SnsEvent');
		$aEventList = getEventList(array(), $aFriendIdList, $eventType, $page, $eventPageSize, $matchId);
		if($aEventList === false){
			alert('系统错误', 0);
		}

		if(!$aEventList){
			$aEventList = getEventList($aFriendIdList, $aFriendIdList, $eventType, $page, $eventPageSize, $matchId);
			if($aEventList === false){
				alert('系统错误', 0);
			}
		}

		alert('', 1, $aEventList);
	}


	/*
	 *检查用户是否符合报名条件
	 */
	public function checkUserJoinStatus(){
		$oMatch = new Match();
		$aResult = $oMatch->checkUserJoinStatus(intval(post('match_id')));
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}


	public function join(){
		$matchId = intval(post('match_id'));
		$areaId = post('areaId');

		$aUserData = array();
		$aUserData['name'] = post('contact');
		$aUserData['call_phone'] = post('mobile');
		$aUserData['qq'] = post('qq');
		$aUserData['area_id'] = $areaId;
		$aUserData['province_id'] = post('provinceId');
		$aUserData['city_id'] = post('cityId');
		$aUserData['address'] = post('detailedPlace');

		$oMatch = new Match();
		$aResult = $oMatch->join($matchId, $areaId, $aUserData, 0);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);

	}

	/*
	 *再次参赛
	 */
	public function reJoin(){
		$matchId = intval(post('match_id'));
		if(!$matchId){
			alert('抱歉，您参加的比赛不存在！', -1);
		}

		$areaId = post('areaId');
		$aUserData = array();
		$aUserData['name'] = post('contact');
		$aUserData['call_phone'] = post('mobile');
		$aUserData['qq'] = post('qq');
		$aUserData['area_id'] = $areaId;
		$aUserData['province_id'] = post('provinceId');
		$aUserData['city_id'] = post('cityId');
		$aUserData['address'] = post('detailedPlace');

		$oMatch = new Match();
		$aResult = $oMatch->reJoin($matchId, $areaId, $aUserData, 0);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}

	public function getReJoinUserList(){
		$page = intval(post('page', 1));
		$matchId = intval(post('match_id'));
		$pageSize = 50;

		if(!$matchId){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		$oMatch = m('Match');
		$aMatch = $oMatch->getMatchInfoById($matchId);
		if($aMatch === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		if(!$aMatch){
			alert('赛事不存在！', 0);
		}
		$aReJoinUserList = array();
		if($aMatch['match_start_time'] < time()){
			$aReJoinUserList = $oMatch->getRejoinMatchUserList($matchId, $page, $pageSize);
			if($aReJoinUserList){
				foreach($aReJoinUserList as $key => $aRejoinUser){
					$aReJoinUserList[$key]['rejoin_time_str'] = getCreateTime($aReJoinUserList[$key]['last_rejoin_time']);
				}
			}
		}
		if($aReJoinUserList === false){
			alert('读取再次参赛数据失败！', -1, array());
		}else{
			alert('读取再次参赛数据成功！', 1, $aReJoinUserList);
		}
	}

	/*
	 *进入赛事
	 */
	public function showMatch(){
		$oMatch = m('Match');
		$myMatchId = intval(get('id'));
		$aMyMatch = $oMatch->getMatchUserRelationInfoById($myMatchId);
		if(!$aMyMatch){
			header('Location:' . url('m=Match&a=showDetail&match_id=' . $myMatchId));
			return;
			//alert('你没有参加该比赛', 0);
		}
		if($aMyMatch['user_id'] != $this->_userId){
			header('Location:' . url('m=Match&a=showDetail&match_id=' . $myMatchId));
			return;
			//alert('你没有参加该比赛', 0);
		}

		$aMatch = $oMatch->getMatchInfoById($aMyMatch['match_id']);
		if(!$aMatch){
			alert('赛事不存在', 0);
		}
		$now = time();
		if(!($now >= $aMatch['match_start_time'] && $now <= $aMatch['match_end_time'])){
			if($now > $aMatch['match_end_time']){
				alert('比赛已经结束了', 0);
			}
			alert('现在不是比赛时间喔', 0);
		}

		$isFirstJoin = false;
		if(!$aMyMatch['first_join_time']){
			$isFirstJoin = true;
			$aMyMatch['first_join_time'] = time();
		}

		$status = 1;	//开始比赛
		if(!$aMyMatch['remainder_es_ids']){
			$status = 2;	//比赛完成
		}else{
			if($aMyMatch['start_time']){
				$status = 3;	//继续比赛

				if((time() - $aMyMatch['start_time']) >= $aMatch['duration'] * 60){
					$status = 2;	//挑战完成，时间到
				}
			}
		}
		assign('status', $status);
		$rank = $oMatch->getMatchRanking($aMyMatch['match_id'], $aMyMatch['best_score'] );
		if($rank === false){
			alert('系统错误', 0);
		}
		$aMyMatch['best_score'] = $aMyMatch['best_score'] / 100;
		assign('aMatch', $aMatch);
		assign('aMyMatch', $aMyMatch);
		assign('rank', $rank);

		if($status == 1 || $status == 3){
			$aFirstEs = $this->_nextEs($aMyMatch['remainder_es_ids']);
			assign('aFirstEs', $aFirstEs);
		}

		$aMatchUserList = $oMatch->getMatchOnlineCustomers($aMyMatch['match_id'], 12);
		assign('aMatchUserList', $aMatchUserList);

		$aUser = getUserInfo($this->_userId, array('personal'));
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		$aUser = array_merge($aUser, $aUserNumerical);
		assign('aUser', $aUser);
		assign('userId', $this->_userId);
		displayHeader();
		display('match/match_doing.html.php');
		displayFooter();
	}

	/*
	 *比赛开始
	 */
	public function startMatch(){
		$oMatch = new Match();
		$aResult = $oMatch->startMatch(intval(post('id')));
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}


	/*
	 *比赛作答处理
	 */
	public function markingMatchAnswer(){
		$oMatch = new Match();
		$aResult = $oMatch->markingMatchAnswer($_POST);
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}

	/*
	 *时间到了自动完成比赛
	 */
	public function autoFinishMatch(){
		$oMatch = new Match();
		$aResult = $oMatch->autoFinishMatch(intval(post('id')));
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}

	/*
	 *领奖
	 */
	public function acceptPrize(){
		$oMatch = new Match();
		$aResult = $oMatch->acceptPrize(intval(post('id')));
		alert($aResult['msg'], $aResult['status'], $aResult['data']);
	}

	/**
	 *检查作答格式
	 */
	private function _checkMatch($aMatchAnswer){
		if(!isset($aMatchAnswer['match_id']) || !isset($aMatchAnswer['user_answer']) || !isset($aMatchAnswer['get_time'])){
			return false;
		}
		if(!is_numeric($aMatchAnswer['match_id']) || !is_array($aMatchAnswer['user_answer'])){
			return false;
		}
		if(!isset($aMatchAnswer['user_answer']['id']) || !isset($aMatchAnswer['user_answer']['answer'])){
			return false;
		}
		return true;
	}


	/**
	 *下一条题目
	 */
	private function _nextEs($aEsId){
		if(!is_array($aEsId)){
			alert('网络可能有点慢啦啦', 0);
		}
		if(!$aEsId){
			alert('哎唷没有下一题了啦', 0);
		}

		$oEs = m('Es');
		$nextEsId = current($aEsId);
		$aNextEs = $oEs->getOfficialEsInfoById($nextEsId);
		if(!$aNextEs){
			alert('获取ID为 <b>' . $nextEsId . '</b> 的下一题时出错啦啦啦', 0);
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aNextEs['type_id']]);
		$aNextEs['es_content'] = $oEsPlugin->resolve($aNextEs['content_json']);
		$aNextEs['es_content'] = $oEsPlugin->removeAnswer($aNextEs['es_content']);
		$aNextEs['id'] = Xxtea::encrypt($aNextEs['id']);
		$now = time();
		$aNextEs['get_time'] = Xxtea::encrypt($now);
		Cookie::set('meut', md5($now));
		return $aNextEs;
	}


	/**
	 *计算赛事的状态
	 */
	private function _getMatchStatus($aMatch){
		$matchStatus = 0;
		$nowTime = time();
		$aMyMatch = $aMatch['match_user_relation'];
		if($aMatch['registration_start_time'] > $nowTime){
			//未开始报名（马上报名按钮不可用）
			$matchStatus = 1;
		}elseif($aMatch['registration_end_time'] > $nowTime){
			//正在报名
			if($aMyMatch){
				if($aMatch['match_start_time'] > $nowTime){
					//用户已报名（准备参赛）
					$matchStatus = 3;
				}else{
					if(!$aMyMatch['start_time']){
						//开赛时间与报名时间重叠
						$matchStatus = 10;
						if(intval($aMyMatch['start_time']) + intval($aMatch['duration']) * 60 > $nowTime && $aMyMatch['remainder_es_ids']){
							$matchStatus = 6;
						}
					}else{
						//已经进入过比赛（再次参赛）
						//$matchStatus = 7;
						if($aMyMatch['start_time'] && intval($aMyMatch['start_time']) + intval($aMatch['duration']) * 60 > $nowTime && $aMyMatch['remainder_es_ids']){
							//还在比赛中（继续未完赛事）
							$matchStatus = 6;
						}else{
							//比赛超时，本次比赛结束（再次参赛）
							$matchStatus = 7;
						}
					}
				}
			}else{
				//用户未报名（马上报名）
				$matchStatus = 2;
			}
		}elseif($aMatch['match_start_time'] > $nowTime){
			//未开赛
			$matchStatus = 4;
			if(!$aMyMatch){
				$matchStatus = 12;
			}
		}elseif($aMatch['match_end_time'] > $nowTime){
			//比赛进行中
			if($aMyMatch){
				//用户已报名
				if($aMyMatch['start_time'] == 0){
					//用户可以进入赛事，但还没进入赛事（立即参赛）
					$matchStatus = 5;
				}else{
					//用户已经进入过赛事了
					if($aMyMatch['start_time'] && intval($aMyMatch['start_time']) + intval($aMatch['duration']) * 60 > $nowTime && $aMyMatch['remainder_es_ids']){
						//还在比赛中（继续未完赛事）
						$matchStatus = 6;
					}else{
						//比赛超时，本次比赛结束（再次参赛）
						$matchStatus = 7;
					}
				}
			}else{
				//用户未报名
				$matchStatus = 8;
			}
		}else{
			//比赛结束
			$matchStatus = 9;
			//查询是否得奖
		}
		return $matchStatus;
	}


	//返回倒计时的yy-mm-dd
	private function _getTimeGo($seconds){
		$aBeginTime = array(
			'day'	=> '00',
			'hour'	=> '00',
			'minute'=> '00',
			'second'=> '00'
		);

		$daySecond = 86400;
		$hourSecond = 3600;
		$minuteSecond = 60;

		if($seconds / $daySecond > 1){
			$aBeginTime['day'] = floor($seconds / $daySecond);
			if($aBeginTime['day'] < 10){
				$aBeginTime['day'] = '0' . $aBeginTime['day'];
			}
			$seconds = $seconds - ($aBeginTime['day'] * $daySecond);
		}

		if($seconds > $hourSecond){
			$aBeginTime['hour'] = floor($seconds / $hourSecond);
			if($aBeginTime['hour'] < 10){
				$aBeginTime['hour'] = '0' . $aBeginTime['hour'];
			}
			$seconds = $seconds - ($aBeginTime['hour'] * $hourSecond);
		}
		if($seconds > $minuteSecond){
			$aBeginTime['minute'] = floor($seconds / $minuteSecond);
			if($aBeginTime['minute'] < 10){
				$aBeginTime['minute'] = '0' . $aBeginTime['minute'];
			}
			$seconds = $seconds - ($aBeginTime['minute'] * $minuteSecond);
		}
		$aBeginTime['second'] = $seconds;
		if($aBeginTime['second'] < 10){
			$aBeginTime['second'] =  '0' . $aBeginTime['second'];
		}
		return $aBeginTime;
	}




	//根据条件取推荐比赛列表
	private function _getRecommendMatchList($length = 5, $matchId = 0){
		$oMatch = m('Match');
		$aRecommendMacthList = $oMatch->getRecommendMacthList($this->_userId, $length, $matchId);
		if($aRecommendMacthList === false){
			return false;
		}
		$aSubjectList = $this->_getSubjectList();
		$aGradeList = $this->_gradeArray;
		foreach ($aRecommendMacthList as &$aRecommendMacth){
			$aRecommendMacth['subject'] = '';
			$aRecommendMacth['grade'] = '';
			if(isset($aSubjectList[$aRecommendMacth['subject_id']])){
				$aRecommendMacth['subject'] = $aSubjectList[$aRecommendMacth['subject_id']];
			}
			if(isset($aGradeList[$aRecommendMacth['grade_id']])){
				$aRecommendMacth['grade'] = $aGradeList[$aRecommendMacth['grade_id']];
			}
		}
		return $aRecommendMacthList;
	}






}