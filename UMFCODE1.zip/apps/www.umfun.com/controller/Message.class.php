<?php
/**
 * Description of Message
 *
 * @author Administrator
 */
class MessageController {
	private $_userId = 0;

	public function __construct(){
		$aUser = checkUserLogin();
		$this->_userId = $aUser['id'];
	}
	
	//小纸条
	public function showMessage(){
		$oUser = m('User');
		$oSns = m('Sns');
		$friendId = 0;
		$offect = 0;
		$aMessageList = array();
		$aFriendInfo = array();
		
		//小纸条好友列表
		$aMessageFriendList = $oSns->getPrivateMessageFriendList($this->_userId);
		if($aMessageFriendList === false){
			alert('系统错误', 0);
		}
		
		if($aMessageFriendList){
			//默认好友
			$friendId = $aMessageFriendList[0]['id'];
			$offect = $aMessageFriendList[0]['unread_count'];
			$aMessageAndFriend = $this->_getMessageListByFriendId($friendId, 1, $offect);
			if($aMessageAndFriend === false){
				alert('系统错误', 0);
			}
			//与默认好友的小纸条内容第一页
			$aMessageList = $aMessageAndFriend['aMessageList'];
			//好友信息
			$aFriendInfo = $aMessageAndFriend['aFriendInfo'];
			
			$offect = $aMessageAndFriend['offect'];
		}
		
		//最新动态
		$aDynamicList = $oSns->getLatestReplyPrivateMessageList($this->_userId, 1, 10);
		if($aDynamicList === false){
			alert('系统错误', 0);
		}
		
		//当前用户信息
		$aPersionalInfo = $oUser ->getPersonalInfoByUserId($this->_userId);
		if($aPersionalInfo === false){
			alert('系统错误', 0);
		}
		if(!$aPersionalInfo ){
			alert('用户不存在', 0);
		}
		
		assign('aMessageFriendList', $aMessageFriendList);
		assign('aMessageList', $aMessageList);
		assign('offect', $offect);
		assign('aDynamicList', $aDynamicList);
		assign('aPersionalInfo', $aPersionalInfo);
		assign('aFriendInfo', $aFriendInfo);
		
		displayHeader();
		displayLeftNav($this->_userId);
		display('message/note.html.php');
		displayFooter();
	}

	//得到当前用户可发送小纸条的好友列表
	public function getUserFriendList(){
		$aRturnArray = array();
		$oSns = m('Sns');
		$aFriendList = array();
		$aGroupList = array();
		$aFriendList = $oSns->getUserFriendList($this->_userId, 0);
		$aGroupList = $aGroupAndFriend = $oSns->getUserGroupList($this->_userId);
		if($aFriendList === false || $aGroupList === false){
			alert('系统错误', 0);
		}
		$aRturnArray['groupList'] = $aGroupList;
		$aRturnArray['friendList'] = $aFriendList;
		alert('', 1, $aRturnArray);

	}
	
	//更多
	public function loadMore(){
		$friendId = intval(post('friendId'));
		$page = intval(post('page'));
		$offcet = intval(post('offcet'));
		if(!w('length(8)', $friendId)){
			alert('数据有误！', 0);
		}
		if($page < 1 || $offcet < 0){
			alert('数据错误！', 0);
		}
		$aMessageList = $this->_getMessageListByFriendId($friendId, $page, $offcet);
		if($aMessageList === false){
			alert('系统错误！', 0);
		}
		alert('', 1, $aMessageList);
	}

	//发送小纸条
	public function send(){
		if(limitCheck('SNS')){
			limitAdd('SNS');
		}
		
		$aData = array(
			'receiver_user_id'	=> intval(post('receiver_user_id')),
			'content'			=> ueEncodeContent(post('content')),	
			'sender_user_id'	=> $this->_userId,
			'is_read'			=> 2,
			'create_time'		=> time()
		);
		if(!w('length(8)', $aData['receiver_user_id'])){
			alert('抱歉，数据有误，请稍后再试！', 0);
		}
		
		$contentLength = ueGetLength(post('content'));
		if($contentLength < 1 || $contentLength > 150){
			alert('小纸条内容长度为1到150个字符长度', 0);
		}
		
		$oUser = m('User');
		$oSns = m('Sns');
		
		$aPersonalInfo = $oUser->getUserInfoByUserId($aData['receiver_user_id']);
		if($aPersonalInfo === false){
			alert('系统错误', 0);
		}
		if(!$aPersonalInfo){
			alert('抱歉！您所写的小纸条无人接收！', 0);
		}elseif($aPersonalInfo['is_forbidden'] == 1){
			alert('抱歉！该用户已被禁用！', 0);
		}
		
		$aUserFrienIds = getUserFriendIds($this->_userId);
		if($aUserFrienIds === false){
			alert('系统错误', 0);
		}
		
		
		//官方账号可以和任何用户互发私信
		if(!in_array($aData['receiver_user_id'], $GLOBALS['PUBLIC_USER_IDS']) && !in_array($this->_userId, $GLOBALS['PUBLIC_USER_IDS'])){
			if(!in_array($aData['receiver_user_id'], $aUserFrienIds)){
				alert('该用户还不是你的好友哦', 0);
			}
		}
		
		$result = $oSns->addSnsPrivateMessage($aData);
		if($result === false){
			alert('系统错误', 0);
		}
		if($result){
			alert('', 1);
		}else{
			alert('发送失败，请重新操作', 0);
		}
		
	}

	
	//发送小纸条后重载对话
	public function reloadMessage(){
		$oUser = m('User');
		$oSns = m('Sns');
		$friendId = 0;
		$offect = 0;
		$aData = array(
			'offect' 		=> 	0,
			'aMessageList'	=> 	array(),
			'aFriendInfo'	=> 	array()
		);
		
		//小纸条好友列表
		$aMessageFriendList = $oSns->getPrivateMessageFriendList($this->_userId);
		if($aMessageFriendList === false){
			alert('系统错误', 0);
		}
		$aData['aMessageFriendList'] = $aMessageFriendList;
		
		if($aMessageFriendList){
			//默认好友
			$friendId = $aMessageFriendList[0]['id'];
			$offect = $aMessageFriendList[0]['unread_count'];
			$aMessageAndFriend = $this->_getMessageListByFriendId($friendId, 1, $offect);
			if($aMessageAndFriend === false){
				alert('系统错误', 0);
			}
			$aData['offect'] = $aMessageAndFriend['offect'];
			$aData['aMessageList'] = $aMessageAndFriend['aMessageList'];
			$aData['aFriendInfo'] = $aMessageAndFriend['aFriendInfo'];
			unset($aMessageAndFriend);
		}
		alert('', 1, $aData);
	}
	
	//删除
	public function delMessage(){
		$type = intval(post('type'));
		$id = intval(post('id'));
		if($type !=1 && $type != 2){
			alert('数据错误', 0);
		}
		if($id < 1){
			alert('数据错误', 0);
		}
		$oSns = m('Sns');
		if($type == 1){
			$aMessageInfo = $oSns->getSnsPrivateMessageById($id);
			if($aMessageInfo === false){
				alert('系统错误', 0);
			}
			if(!$aMessageInfo){
				alert('记录不存在', 0);
			}
			$aDelResult = $this->_delMessageInfo($aMessageInfo);
			alert($aDelResult['msg'], $aDelResult['status']);
			
		}else{
			$aMessageList = array();
			$aMessageList = $oSns->getSnsPrivateMessagesByUserIds($id, $this->_userId);
			if($aMessageList === false){
				alert('系统错误', 0);
			}
			if(!$aMessageList){
				alert('记录不存在', 0);
			}
			foreach($aMessageList as $aMessageInfo){
				$aDelResult = $this->_delMessageInfo($aMessageInfo);
				if($aDelResult['status'] == 0){
					break;
				}
			}
			alert($aDelResult['msg'], $aDelResult['status']);
		}
	}

	//根据ID返回用户与我小纸条对话的具体内容
	private function _getMessageListByFriendId($friendId, $page = 1, $offect = 0){
		$oSns = m('Sns');
		$oUser = m('User');
		$pageSize = 10;
		
		$aFriendInfo = array();
		$aMessageList = array();
		$aNotReadMessageList = array();
		$notReadMessageCount = 0;
		
		$aReturnData = array(
			'offect'		=> $offect,	
			'aFriendInfo'	=> array(),
			'aMessageList'	=> array()	
		);

		//查当前好友信息
		$aFriendInfo = $oUser->getPersonalInfoByUserId($friendId);
		if($aFriendInfo === false || !$aFriendInfo){
			return false;
		}
		$aReturnData['aFriendInfo'] = $aFriendInfo;
		unset($aFriendInfo);
		
		if($offect > 0){
			if($page == 1){
				//将与当前用户所有末读的都查出来
				$aNotReadMessageList = $oSns->getUnreadPrivateMessageList($this->_userId, $friendId);
				if($aNotReadMessageList === false){
					return false;
				}
				//如果存在末读的，更新成己读状态
				if($aNotReadMessageList){
					$result = $oSns->editSnsPrivateMessage(array('is_read' => 1), '`sender_user_id` = ' . $friendId . ' AND `receiver_user_id` = ' . $this->_userId);
					if($result === false){
						return false;
					}
				}
				$notReadMessageCount = count($aNotReadMessageList);
				
				//如果末读数据条数小于第一页所需数据条数
				if($notReadMessageCount < $pageSize){
					$aOtherList = $oSns->getSnsPrivateMessagesByUserIds($friendId, $this->_userId, $notReadMessageCount, $pageSize- $notReadMessageCount);
					if($aOtherList === false){
						return false;
					}
					
					foreach($aOtherList as &$aOtherInfo){
						$aNotReadMessageList[count($aNotReadMessageList)] = $aOtherInfo;
					}
					unset($aOtherList);
				}
				$aMessageList = $aNotReadMessageList;
				$aReturnData['offect'] = count($aMessageList);
				unset($aNotReadMessageList);
			}else{
				if($offect > $pageSize){
					$start = $offect + ($page -2) * $pageSize;
				}else{
					$start = $pageSize * ($page -1);
				}
				$aMessageList = $oSns->getSnsPrivateMessagesByUserIds($friendId, $this->_userId, $start, $pageSize);
			}
		}else{
			$aMessageList = $oSns->getSnsPrivateMessagesByUserIds($friendId, $this->_userId, $pageSize * ($page -1), $pageSize);
		}	

		if($aMessageList === false){
			return false;
		}
		
		$aReturnData['aMessageList'] = $aMessageList;
		return $aReturnData;
	}
	
	
	//逐条删除
	private function _delMessageInfo($aMessageInfo){
		$aReturnData = array(
			'msg'	 => '',
			'status' => 0		
		);
		
		if($aMessageInfo['sender_user_id'] != $this->_userId && $aMessageInfo['receiver_user_id'] != $this->_userId){
			$aReturnData['msg']	= '没有权限删除此小纸条哦';
			return $aReturnData;
		}
		$result = false;
		$oSns = m('Sns');
		//如果是我发送的
		if($aMessageInfo['sender_user_id'] == $this->_userId){
			if($aMessageInfo['status'] == 0){
				$result = $oSns->editSnsPrivateMessage(array('status' => 1), array('id' => $aMessageInfo['id']));
			}elseif($aMessageInfo['status'] == 2){
				$result = $oSns->deleteSnsPrivateMessage($aMessageInfo['id']);
			}
		//如果是我接收的	
		}elseif($aMessageInfo['receiver_user_id'] == $this->_userId){
			if($aMessageInfo['status'] == 0){
				$result = $oSns->editSnsPrivateMessage(array('status' => 2), array('id' => $aMessageInfo['id']));
			}elseif($aMessageInfo['status'] == 1){
				$result = $oSns->deleteSnsPrivateMessage($aMessageInfo['id']);
			}
		}
		
		if(!$result){
			$aReturnData['msg']	= '操作失败';
		}else{
			$aReturnData['msg']	= '操作成功';
			$aReturnData['status']	= 1;
		}
		return $aReturnData;
	}
	

}
