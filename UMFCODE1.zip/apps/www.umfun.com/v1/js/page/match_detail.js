(function ($, win) {
	win.MatchDetail = {
		config: function (aOptions) {
			if (aOptions.url) {
				for (var key in _aUrl) {
					if (aOptions.url[key] != undefined) {
						_aUrl[key] = aOptions.url[key];
					}
				}
			}
			if (aOptions.defaultData) {
				for (var i in _defaultData) {
					if (aOptions.defaultData[i] != undefined) {
						_defaultData[i] = aOptions.defaultData[i];
					}
				}
			}
		},
		show: function () {
			//构建基本骨架
			_buildContainerHtml();
			_getInitData();
			_bindEvent();
			//倒计时
			_setTimerStatus();
		}
	};

	var _aUrl = {
		gotoEnterTopicUrl: '',
		myMatchUrl: '',
		getMyEntryRecordListUrl: '',
		getRecentEntryListUrl: '',
		getMatchRankingListUrl: '',
		getRelatedTopicListUrl: '',
		enterTopicDetail: '',
		getWinnerListUrl: '',
		startMatchUrl: '',
		//比赛开始跳转url
		matchUrl: '',
		starUrl: '',
		allMatchUrl: '',
		getLastAddressUrl: '',
		starPicUrl: '',
		drawGoldUrl: '',
		receiveUserPrizeUrl: ''
	};

	var _defaultData = {
		aMedal: '',
		aMatchDetail: ''
	};
	var _$matchDetail = $('.J-mainDiv'), _$matchConfirm = $('.J-confirmMatchDIv'), _aMatchRankList = [], _resourceUrl = App.getUrl('resource');

	/**
	 * 加载完骨架之后获取数据
	 */
	function _getInitData() {
		_getMatchIntro();
		_getMyEntryRecordList();
		//如果用户参加过本场比赛显示排行榜 否则显示 最近参赛的人
		if (!_defaultData.aMatchDetail.isFinishFirst) {
			_getRecentEntryList();
		} else {
			_getMatchRankingList();
		}
		_getPushTopicList();
	}

	/**
	 * 为页面绑定事件
	 */
	function _bindEvent() {
		//介绍和奖品切换
		_$matchDetail.find('.J-matchDetailTab a').click(function () {
			//比赛时间到未发奖提示
			if((_defaultData.aMatchDetail.winners.length == 0) && (_defaultData.aMatchDetail.match_status == 3)){
				UBox.show('正在等待工作人员抽奖！',-1);
				return;
			}
			if((_defaultData.aMatchDetail.winners.length == 0) && (_defaultData.aMatchDetail.match_status == 1)){
				UBox.show('比赛还没开始，敬请期待！',-1);
				return;
			}
			//比赛进行中
			if (_defaultData.aMatchDetail.winners.length == 0) {
				UBox.show('比赛进行中！等比赛结束再回来看看吧！',-1);
				return;
			}
			var $this = $(this);
			$this.addClass('active').siblings().removeClass('active');
			var cate = $this.data('cate');
			if (cate == 'intro') {
				_appendMatchIntroDetailHtml([]);
				return;
			}
			_getMatchAwardDetail();
		});

		/**
		 * 显示比赛参赛确认框
		 */
		function _showConfirmMatch(){
			//如果是活动比赛，跳过填写地址信息，直接报名参赛
			if(_defaultData.aMatchDetail.is_activity_match == 1){
				function _startFunc(){
					var oData = {
						match_id: _defaultData.aMatchDetail.id,
						user_name: '',
						phone: '',
						qq: '',
						province: '',
						city: '',
						area: '',
						address: ''
					};
					_startMatch(oData);
				}
				if(_defaultData.aMatchDetail.isFinishFirst == 1){
					UBox.confirm('再次参赛将扣除' + _defaultData.aMatchDetail.rejoin_fee + '金币，是否继续？', _startFunc);
				}else{
					_startFunc();
				}
				return;
			}
			if(_defaultData.aMatchDetail.isLimitJoin){
				UBox.show('你所在的年级不能参加这场比赛哦，去看看其他比赛吧！',-1);
				return;
			}

			if(App.oCurrentStudent.is_yh_user){
				if(_defaultData.aMatchDetail.isFinishFirst){
					UBox.show('抱歉,您无法再次参赛', -1);
					return;
				}

				location.href = _aUrl.matchUrl;
				return;
			}

			_$matchConfirm.html(_buildConfirmMatch());

			var aMatchUserInfo = _defaultData.aMatchDetail.user_info;

			var oAreaSelector = new AreaSelector({
				//下面是配置CAN_CONTINUE_MATCH
				$province: _$matchConfirm.find('.J-province'), //用JQ选择省份的select
				$city: _$matchConfirm.find('.J-city'), //城市的select
				$area: _$matchConfirm.find('.J-area'), //你懂的
				defaultArea: aMatchUserInfo.area_id //默认的区域ID,配这个时一定要配上defaultCity
			});
			//绑定事件
			$('.J-province,.J-city,.J-area').change(function(){
				var $self = $(this);
				$self.prev('.J-select').html($self.find(':selected').text());
			});
			oAreaSelector.init();
		}

		//点击弹出框参赛
		_$matchDetail.find('.J-confirmMatch').click(function () {
			if(App.oCurrentStudent.vip){
				_showConfirmMatch();
			}else{
				UBox.confirm('注意！非会员用户参赛无法获得实物奖励哦！立即开通会员，赢取海量奖品！', function(){
					_showConfirmMatch();
				});
			}
		});

		_$matchConfirm.on('click', '.J-matchConfirmClose', function () {
			_$matchConfirm.empty();
		});

		//确认参赛
		_$matchConfirm.on('click', '.J-startMatch', function () {
			var $this = $(this);
			if(!$this.data('status')){
				return;
			}
			_validataFormInput();
		});


		_$matchDetail.on('click', '.J-matchRankingPage a', function () {
			var $this = $(this);
			var option = $this.hasClass('J-MatchRankingPre');
			var page = $this.closest('.J-matchRankingPage').data('page');
			if (!$this.data('status')) {
				return;
			}
			//点击上一页
			if (option) {
				//第一页
				if (page == 1) {
					$this.removeClass('active').data('status', false);
					return;
				}
				page = (page - 1);
			} else {
				page = (page + 1);
			}
			_$matchDetail.find('.J-matchRankingPage a').addClass('active');
			if (page < 1) {
				page = 1;
			}
			//数据缓存
			if (_aMatchRankList[page] !== undefined) {
				_appendMatchRankingListHtml(_aMatchRankList[page], page);
				return;
			}
			_getMatchRankingList(page, $this);
		});

		_$matchDetail.on('click','.J-getGold',function(){
			_$matchConfirm.empty().append(_buildDialogHtml());
		});

		_$matchConfirm.on('click','.J-receiveGold',function(){
			var $this = $(this);
			ajax({
				beforeSend: function () {
					$this.addClass('disabled');
				},
				url: _aUrl.receiveUserPrizeUrl,
				data: {
					match_id: _defaultData.aMatchDetail.id
				},
				success: function (aReuslt) {
					_$matchConfirm.empty();
					if (aReuslt.status == 1) {
						_$matchConfirm.append(_buildDialog2Html(aReuslt.data));
					} else {
						UBox.show(aReuslt.msg, -1);
					}
				},
				complete : function () {
					$this.removeClass('disabled');
				}
			});

		});

		_$matchConfirm.on('click','.J-closeReceiveGold',function(){
			_$matchConfirm.empty();
			location.reload([true]);
		});

	}
	//user_award_info

	function _buildDialogHtml() {
		var aAwards = _defaultData.aMatchDetail.user_award_info;
		if(aAwards.length == 0){
			UBox.show('没有获奖信息', -1);
			return;
		}
		var prize =  '',gold = 0;
		if(aAwards.gold !== undefined){
			gold = aAwards.gold;
		}
		if(aAwards.prize !== undefined){
			prize = aAwards.prize;
		}
		return '<div class="modal  fade common-modal in" id="matchComplete" aria-hidden="false" style="display: block;">\
			<!-- success perfect fail -->\
			<div class="um-mcommon match-common match-complete">\
				<div class="hd">\
					领取奖励\
				</div>\
				<div class="bd">\
					<div class="prize">\
						<div class="fl">\
							<p>\
								<span style="width: 50px;">实物</span>\
								<span>' + prize + '</span>\
							</p>\
							<p>\
							<span style="width: 50px;">金币</span>\
							<span>' + gold + '金币</span>\
							</p>\
						</div>\
					</div>\
					<div class="gx">实物奖品将发送到您所填的收货地址</div>\
				</div>\
				<div class="ft">\
					<div class="opts">\
						<a href="javascript:void(0)" class="um-btn um-btn-success um-btn-xlg J-receiveGold">确定领取</a>\
					</div>\
				</div>\
			</div>\
		</div><div class="modal-backdrop fade in"></div>';
	}

	function _buildDialog2Html(aMatchAwardInfo) {
		var wardStr = aMatchAwardInfo.aAward.prize + '+' + aMatchAwardInfo.aAward.gold + '金币';
		return '<div class="modal  fade common-modal in" id="matchComplete" aria-hidden="false" style="display: block;">\
			<!-- success perfect fail -->\
			<div class="um-mcommon match-common match-complete">\
				<div class="hd">\
					比赛奖励\
				</div>\
				<div class="bd">\
					<div class="prize">\
						<div class="fl">\
							<p>\
								<span>赛事名称:</span>\
								<span style="width: 100%;">' + aMatchAwardInfo.match_name + '</span>\
							</p>\
							<p>\
							<span>参赛时间:</span>\
							<span>' + Ui1.date('Y年m月d日', aMatchAwardInfo.best_score_time) + '</span>\
							</p>\
							<p>\
							<span>排名:</span>\
							<span>' + aMatchAwardInfo.ranking + '</span>\
							</p>\
							<p>\
							<span>得分:</span>\
							<span>' + aMatchAwardInfo.best_score + '</span>\
							</p>\
						</div>\
					</div>\
					<div class="gx">' + wardStr + '</div>\
				</div>\
				<div class="ft">\
					<div class="opts">\
						<a href="javascript:void(0)" class="um-btn um-btn-success um-btn-xlg J-closeReceiveGold">关闭</a>\
					</div>\
				</div>\
			</div>\
		</div><div class="modal-backdrop fade in"></div>';
	}

	/**
	 * 获取详情介绍数据
	 */
	function _getMatchIntro() {
		_appendMatchIntroDetailHtml([]);
	}

	/**
	 * 填充比赛详情介绍数据
	 */
	function _appendMatchIntroDetailHtml(aMatchDetailIntro) {
		var matchDetailIntroHtml = _buildMatchIntroDetail(aMatchDetailIntro);
		_$matchDetail.find('.J-matchIntroAndAwardIntro').html(matchDetailIntroHtml);

	}

	function _getMatchAwardDetail() {
		ajax({
			url: _aUrl.getWinnerListUrl,
			data: {
				match_id: _defaultData.aMatchDetail.id,
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					_appendMatchAwardDetailHtml(aResult.data.aWinnerList, aResult.data.matchType);
				}
			}
		});

	}

	/**
	 * 填充比赛详情奖品数据
	 */
	function _appendMatchAwardDetailHtml(aMatchDetailAward, matchType) {
		var matchDetailAwardHtml = _buildMatchAwardIntro(aMatchDetailAward, matchType);
		_$matchDetail.find('.J-matchIntroAndAwardIntro').html(matchDetailAwardHtml);

	}

	/**
	 * 获取比赛排行
	 */
	function _getMatchRankingList(page, $this) {
		if (page == undefined) {
			page = 1;
		}
		ajax({
			beforeSend: function () {
				if ($this !== undefined) {
					$this.data('status', false);
				}
			},
			url: _aUrl.getMatchRankingListUrl,
			data: {
				page: page,
				match_id: _defaultData.aMatchDetail.id,
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMatchRanking = aResult.data.aMatchRanking;
					var ranking = aResult.data.ranking;
					if (ranking == 0) {
						_$matchDetail.find('.J-myRanking').hide();
					} else {
						_$matchDetail.find('.J-myRanking').show();
						_$matchDetail.find('.J-myRanking>em').html(ranking);
					}
					//第一页就没数据
					if (aMatchRanking.length == 0 && page == 1) {
						_$matchDetail.find('.J-matchRankingPage').hide();
						_$matchDetail.find('.J-recentEntryRecordList').html('<li class="nodata">暂无数据</li>');
						return;
					}
					//数据缓存
					_aMatchRankList[page] = aMatchRanking;
					_appendMatchRankingListHtml(aMatchRanking, page);
				}
			}
		});
	}

	/**
	 * 填充排行榜记录
	 */
	function _appendMatchRankingListHtml(aRecentEntryList, page) {

		//最后一页没数据
		if ((page > 1) && (aRecentEntryList.length == 0)) {
			_$matchDetail.find('.J-matchRankingPage a').data('status', true).addClass('active');
			_$matchDetail.find('.J-MatchRankingnext').removeClass('active').data('status', false);
			_$matchDetail.find('.J-recentEntryRecordList').html('<li class="nodata">没有数据啦</li>');
			_$matchDetail.find('.J-matchRankingPage').data('page', page);
			return;
			//处理非最后一页让按钮可点击
		} else {
			_$matchDetail.find('.J-matchRankingPage a').data('status', true);
		}
		if (page == 1) {
			_$matchDetail.find('.J-MatchRankingPre').removeClass('active').data('status', false);
		}
		_$matchDetail.find('.J-matchRankingPage').data('page', page);

		var listHtml = _buildMatchRankingList(aRecentEntryList);
		_$matchDetail.find('.J-recentEntryRecordList').html(listHtml);
	}


	/**
	 * 获取最近参数的人列表
	 */
	function _getRecentEntryList(page) {
		if (page == undefined) {
			page = 1;
		}
		ajax({
			url: _aUrl.getRecentEntryListUrl,
			data: {
				page: page,
				match_id: _defaultData.aMatchDetail.id,
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					var aNearestJoinMatchUserList = aResult.data.aNearestJoinMatchUserList;
					_appendRecentEntryListHtml(aNearestJoinMatchUserList);
				}
			}
		});
	}

	/**
	 * 填充最近参赛记录
	 */
	function _appendRecentEntryListHtml(aRecentEntryList) {
		var matchRecentEntryListHtml = _buildRecentEntryList(aRecentEntryList);
		_$matchDetail.find('.J-recentEntryRecordList').html(matchRecentEntryListHtml);
	}

	/**
	 * 填充相关话题列表
	 */
	function _appendRelatedTopicListHtml(aRelatedTopicList) {
		var matchRelatedTopicListHtml = _buildRelatedTopicList(aRelatedTopicList);
		_$matchDetail.find('.J-relatedTopicList').html(matchRelatedTopicListHtml);
	}

	function _buildContainerHtml() {
		var aContainerHtml = [];
		//主体html
		aContainerHtml.push('<div class="contain">\
		<div class="um-layout-1">');
		//左侧列表
		aContainerHtml.push(_buildMainHtml());

		//side 右侧
		aContainerHtml.push(_buildSideHtml());
		//结束html
		aContainerHtml.push('</div></div>');
		_$matchDetail.html(aContainerHtml.join(''));
	}

	function _buildMainHtml() {
		var aMainHtml = [];
		aMainHtml.push('<div class="main">\
			<div class="home-mods match-main">\
				<div class="match-nav">\
					<a href="' + _aUrl.allMatchUrl + '" class="active">全部比赛</a>\
					<a href="' + _aUrl.starUrl + '">比赛之星</a>\
					<a href="' + _aUrl.myMatchUrl + '">我的比赛</a>\
				</div>\
					<div class="bd">');

		//详细比赛介绍
		aMainHtml.push('<div class="match-detail">\
			<div class="J-matchDetail"></div>');
		aMainHtml.push(_buildMatchDetailHtml());
		aMainHtml.push('</div>');
		//详细比赛介绍结束

		aMainHtml.push('</div></div></div>');
		return aMainHtml.join('');
	}

	function _buildMatchDetailHtml() {
		var aMatchDetail = _defaultData.aMatchDetail;
		var matchStatus = _defaultData.aMatchDetail.match_status;
		var matchStatusStr = '';
		if (matchStatus == 1) {
			matchStatusStr = '<a href="javascript:void(0)" class="btnbox disabled" data-toggle="modal">未开始</a>';
		} else if (matchStatus == 4) {
			matchStatusStr = '<a href="javascript:void(0)" class="btnbox J-confirmMatch" data-toggle="modal">立即参赛</a>';
		} else if (matchStatus == 5) {
			matchStatusStr = '<a href="' + _aUrl.matchUrl + '" class="btnbox" data-toggle="modal">继续答题</a>';
		} else if (matchStatus == 6) {
			matchStatusStr = '<a href="javascript:void(0)" class="btnbox J-confirmMatch" data-toggle="modal">再次参赛</a>';
		} else if (matchStatus == 3) {
			matchStatusStr = '<a href="javascript:void(0)" class="btnbox disabled" data-toggle="modal">比赛结束</a>';
		//领取奖励
		} else if (matchStatus == 7) {
			matchStatusStr = '<a href="javascript:void(0)" class="btnbox J-getGold" data-toggle="modal">领取奖励</a>';
		}
		var gradName = aMatchDetail.grade_name != '' ? '【' + aMatchDetail.grade_name + '】' : '';
		if(aMatchDetail.is_big_match == 1){
			gradName = '';
		}
		return '<div class="match-title">' + gradName + aMatchDetail.name + '</div>\
	<div class="match-cont">\
		<div class="img">\
		' + Ui1.buildImage(_resourceUrl + aMatchDetail.profile, undefined, {width: 270, heigth: 300}) + '\
		</div>\
		<div class="info">\
			<div class="p1">\
				<span class="left">\
					<span class="text">首次参赛金币</span>\
					<em>' + aMatchDetail.join_fee + '</em>\
				</span>\
				<span>\
					<span class="text">再次参赛金币</span>\
					<em>' + aMatchDetail.rejoin_fee + '</em>\
				</span>\
			</div>\
			<div class="p2">\
				<p class="sum">比赛限时 <span>' + aMatchDetail.duration + '分钟</span> 比赛题数 <span>' + aMatchDetail.es_count + '题</span></p>\
				<p class="countdown J-timer">\
				</p>\
				<p class="time">' + Ui1.date('m月d日 H:i', aMatchDetail.match_start_time) + ' - ' + Ui1.date('m月d日 H:i', aMatchDetail.match_end_time) + '</p>\
				<p>'+ matchStatusStr +'</p>\
				<p class="J-overTime" style="display:none;">\
					<a href="javascript:void(0)" class="btnbox disabled" data-toggle="modal">比赛结束</a>\
				</p>\
				<p class="total"><em>' + aMatchDetail.join_match_count + '</em>人已参赛</p>\
			</div>\
		</div>\
	</div>\
	<div class="match-info">\
		<div class="match-info-menu J-matchDetailTab">\
			<a href="javascript:void(0)" class="active" data-cate="intro">详细介绍</a>\
			<a href="javascript:void(0)" data-cate="award">获奖名单</a>\
		</div>\
		<div class="J-matchIntroAndAwardIntro"></div>\
	</div>';
	}

	function _buildSideHtml() {
		var aSideHtml = [];
		aSideHtml.push('<div class="side">');
		//我的参赛记录
		aSideHtml.push(_buildMyEntryRecordHtml());
		if (!_defaultData.aMatchDetail.isFinishFirst) {
			aSideHtml.push(_buildRecentEntryListHtml());
		} else {
			aSideHtml.push(_buildMatchRankingHtml());
		}
		//aSideHtml.push(_buildSmallPicHtml());
		aSideHtml.push(_buildPushTopicHtml());
		aSideHtml.push('</div>');
		return aSideHtml.join('');
	}


	function _buildMatchIntroDetail() {
		var aMatchInfoIntroHtml = [];
		var aMatchDetail = _defaultData.aMatchDetail;
		var aAwardsTop = aMatchDetail.awards.top;
		var aAwardsRand = aMatchDetail.awards.rand;
		var aRank = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];

		aMatchInfoIntroHtml.push('<div class="match-info-intro">\
			<p><span class="notic">特别提醒：</span></br>1.每个用户只能用一个号参赛，不允许小号重复参赛，否则将取消比赛成绩；</br>\
			2.大赛获奖同学，需要在比赛结束后一周内向客服提供本人照片与获奖感言，否则将取消比赛成绩</br>&nbsp;&nbsp;奖品顺延至排位下一名的参赛者</br>\
			3.获奖的同学在收到奖品后，在晒奖专区按规则晒出自己的奖品，就可能获得30金币奖励\
			</p>\
			<h4>比赛奖品</h4>\
			<table class="table-list">\
				<thead>\
					<tr>\
						<td width="20%">奖项</td>\
						<td width="10%">数量</td>\
						<td width="20%">荣誉</td>\
						<td width="55%">奖励</td>\
					</tr>\
				</thead>\
			<tbody>');

		var aRankNames = ['冠军', '亚军', '季军'],
			aMedalHtmls = [
				'金牌一枚<i class="ico_brand ico_brand_gold_m"></i>',
				'银牌一枚<i class="ico_brand ico_brand_silver_m"></i>',
				'铜牌一枚<i class="ico_brand ico_brand_copper_m"></i>'
			];
		for (var i in aAwardsTop) {
			var aAwards = aAwardsTop[i],
				rankName = '第' + aRank[i] + '名',
				medalHtml = '--';
			if (i <= 3) {
				var aPrizeHtml = [];
				aAwards.prize && aPrizeHtml.push(aAwards.prize);
				aAwards.accumulate_points && aPrizeHtml.push(aAwards.accumulate_points + '经验');
				aAwards.gold && aPrizeHtml.push(aAwards.gold + '金币');
				rankName += '(' + aRankNames[i - 1] + ')';
				medalHtml = aMedalHtmls[i - 1];
			}

			aMatchInfoIntroHtml.push('<tr>\
				<td>' + rankName + '</td>\
				<td>1名</td>\
				<td>' + medalHtml + '</td>\
				<td>' + aPrizeHtml.join('+') + '</td>\
			</tr>');

		}

		var aRandPrizeHtml = [];
		if(aAwardsRand && aAwardsRand !== undefined){
			aAwardsRand.prize && aRandPrizeHtml.push(aAwardsRand.prize);
			aAwardsRand.accumulate_points && aRandPrizeHtml.push(aAwardsRand.accumulate_points + '经验');
			aAwardsRand.gold && aRandPrizeHtml.push(aAwardsRand.gold + '金币');
			aMatchInfoIntroHtml.push('\
			<tr>\
				<td>幸运奖</td>\
				<td>' + aAwardsRand.number + '名</td>\
				<td>--</td>\
				<td>' + aRandPrizeHtml.join('+') + '</td>\
			</tr>');
		}

		aMatchInfoIntroHtml.push('</tbody>\
			</table>');
		if (aMatchDetail.rule) {
			aMatchInfoIntroHtml.push('<!--<p><span class="notic">参赛就有机会获得幸运奖哦</span></p>-->\
			<h4>奖品展示</h4>\
			' + aMatchDetail.rule);
		}
		aMatchInfoIntroHtml.push('</div>');
		return aMatchInfoIntroHtml.join('');
	}

	function _buildMatchAwardIntro(aWinnerList, matchType) {
		if (matchType === undefined) {
			matchType = 0;
		}
		var aWinnerList = aWinnerList;
		var aTopUser = aWinnerList.top;
		var aRandUser = aWinnerList.rand;
		var aTopAward = _defaultData.aMatchDetail.awards.top;
		var aRandAward = _defaultData.aMatchDetail.awards.rand;
		var aWinnerListHtml = [];
		aWinnerListHtml.push('<div class="match-info-intro">\
			<div class="sl-wrap">\
				<div class="title"><em>实力奖名单</em></div>');
		//分大赛和日常比赛
		if (matchType == 1) {
			var aTop13 = (typeof (aTopUser[13]) == 'undefined') ? [] : aTopUser[13];
			var aTop46 = (typeof (aTopUser[13]) == 'undefined') ? [] : aTopUser[46];
			var aTop79 = (typeof (aTopUser[13]) == 'undefined') ? [] : aTopUser[79];
			aWinnerListHtml.push('<div class="title"><em style="color:#999">一到三年级</em></div>');
			aWinnerListHtml.push(_buildAawardTopUserListHtml(aTop13, aTopAward));
			aWinnerListHtml.push('<div class="title"><em style="color:#999">四到六年级</em></div>');
			aWinnerListHtml.push(_buildAawardTopUserListHtml(aTop46, aTopAward));
			aWinnerListHtml.push('<div class="title"><em style="color:#999">七到九年级</em></div>');
			aWinnerListHtml.push(_buildAawardTopUserListHtml(aTop79, aTopAward));
		} else {
			//日常比赛
			aWinnerListHtml.push(_buildAawardTopUserListHtml(aTopUser, aTopAward));
		}
		if (aRandUser.length != 0) {
			aWinnerListHtml.push('</div>\
			<div class="xy-wrap">\
				<div class="title"><em>幸运奖名单</em></div>\
				<div class="fl">\
					<ul class="list-unstyled">');
			for (var i in aRandUser) {
				if ((i % 2) != 0 || i == 0) {
					var goldStr = '';
					if(typeof(aRandAward.gold) != 'undefined' && parseInt(aRandAward.gold) > 0){
						if(aRandAward.prize != ''){
							goldStr += '+';
						}
						goldStr += aRandAward.gold + '金币';
					}
					aWinnerListHtml.push('<li>\
					' + Ui1.buildProfile(aRandUser[i].user_info) + '\
					' + Ui1.buildVipName(aRandUser[i].user_info) + '\
					<span class="text">奖励：' + aRandAward.prize + goldStr + '</span>\
				</li>');
				}
			}
			aWinnerListHtml.push('</ul>\
				</div>\
				<div class="vline"></div>\
				<div class="fl">\
					<ul class="list-unstyled">');
			for (var i in aRandUser) {
				if ((i % 2) == 0 && i > 0) {
					var goldStr = '';
					if(typeof(aRandAward.gold) != 'undefined' && parseInt(aRandAward.gold) > 0){
						if(aRandAward.prize != ''){
							goldStr += '+';
						}
						goldStr += aRandAward.gold + '金币';
					}
					aWinnerListHtml.push('<li>\
					' + Ui1.buildProfile(aRandUser[i].user_info) + '\
					' + Ui1.buildVipName(aRandUser[i].user_info) + '\
					<span class="text">奖励：' + aRandAward.prize + goldStr + '</span>\
				</li>');
				}

			}
			aWinnerListHtml.push('</ul>\
				</div>\
			</div>\
		</div>');
		}
		return aWinnerListHtml.join('');
	}

	/**
	 * 小数保留两位包括0
	 * @param {int} x
	 */
	function _changeTwoDecimal(x) {
		var f_x = parseFloat(x);
		if (isNaN(f_x)) {
			return '0.00';
		}
		var f_x = Math.round(x * 100) / 100;
		var s_x = f_x.toString();
		var pos_decimal = s_x.indexOf('.');
		if (pos_decimal < 0) {
			pos_decimal = s_x.length;
			s_x += '.';
		}
		while (s_x.length <= pos_decimal + 2) {
			s_x += '0';
		}
		return s_x;
	}

	function _buildAawardTopUserListHtml(aTopUser, aTopAward) {
		var aWinnerListHtml = [];
		aWinnerListHtml.push('<ul class="list-unstyled">');
		if(aTopUser.length == 0){
			aWinnerListHtml.push('<li class="nodata">暂无数据..</li>');
			aWinnerListHtml.push('</ul>');
			return aWinnerListHtml.join('');
		}
		//日常比赛
		for (var i in aTopUser) {
			if (i == 1) {
				var goldStr = '';
				if(typeof(aTopAward[1].gold) != 'undefined' && parseInt(aTopAward[1].gold) > 0){
					if(aTopAward[1].prize != ''){
						goldStr += '+';
					}
					goldStr += aTopAward[1].gold + '金币';
				}
				aWinnerListHtml.push('<li>\
							' + Ui1.buildProfile(aTopUser[i].user_info) + '\
							' + Ui1.buildVipName(aTopUser[i].user_info) + '\
							<span class="text"><em>冠军</em><span>' + _changeTwoDecimal(aTopUser[i].best_score) + '</span>奖励：' + aTopAward[1].prize + goldStr + '</span>\
						</li>');
			}
			if (i == 2) {
				var goldStr = '';
				if(typeof(aTopAward[2].gold) != 'undefined' && parseInt(aTopAward[2].gold) > 0){
					if(aTopAward[2].prize != ''){
						goldStr += '+';
					}
					goldStr += aTopAward[2].gold + '金币';
				}
				aWinnerListHtml.push('<li>\
							' + Ui1.buildProfile(aTopUser[i].user_info) + '\
							' + Ui1.buildVipName(aTopUser[i].user_info) + '\
							<span class="text"><em>亚军</em><span>' + _changeTwoDecimal(aTopUser[i].best_score) + '</span>奖励：' + aTopAward[2].prize + goldStr + '</span>\
						</li>');
			}
			if (i == 3) {
				var goldStr = '';
				if(typeof(aTopAward[3].gold) != 'undefined' && parseInt(aTopAward[3].gold) > 0){
					if(aTopAward[3].prize != ''){
						goldStr += '+';
					}
					goldStr += aTopAward[3].gold + '金币';
				}
				aWinnerListHtml.push('<li>\
							' + Ui1.buildProfile(aTopUser[i].user_info) + '\
							' + Ui1.buildVipName(aTopUser[i].user_info) + '\
							<span class="text"><em>季军</em><span>' + _changeTwoDecimal(aTopUser[i].best_score) + '</span>奖励：' + aTopAward[3].prize + goldStr + '</span>\
						</li>');
			}
		}
		aWinnerListHtml.push('</ul>');
		return aWinnerListHtml.join('');
	}

	function _getMyEntryRecordList() {
		ajax({
			url: _aUrl.getMyEntryRecordListUrl,
			data: {
				match_id: _defaultData.aMatchDetail.id,
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMyEntryRecordList = aResult.data.aMyEntryRecordList;
					var bestScore = aResult.data.bestScore;
					if(bestScore == 0){
						_$matchDetail.find('.J-myRecord').hide();
					}else{
						_$matchDetail.find('.J-myRecord').show().find('.J-bestScore').html('<span>' + bestScore + '</span>');
					}
					_appendMyEntryRecordListHtml(aMyEntryRecordList);
				}
			}
		});
	}

	function _appendMyEntryRecordListHtml(aMyEntryRecordList) {
		_$matchDetail.find('.J-myEntryRecordList').html(_buildMyEntryRecordList(aMyEntryRecordList));
	}

	function _buildMyEntryRecordList(aMyEntryRecordList) {
		var aMyEntryRecordListHtml = [];
		if (aMyEntryRecordList.length == 0) {
			return '<ul class="list-unstyled"><li class="nodata">\
					还没有参赛记录\
				</li></ul>';
		}
		var matchStatus = _defaultData.aMatchDetail.match_status;
		if(matchStatus == 6){
			_$matchDetail.find('.J-againJoin').show();
		}
		for (var i in aMyEntryRecordList) {
			aMyEntryRecordListHtml.push('<p style="line-height: 17px;"><span class="record-1">第' + (parseInt(i) + 1) + '次参赛</span><span class="record-2" style="color:#726969;font-size:11px; line-height:21px;">' + Ui1.date('m-d H:i', aMyEntryRecordList[i].start_time) + '</span><span class="record-3">' + (aMyEntryRecordList[i].score / 100) + '</span></p>');
		}
		return aMyEntryRecordListHtml.join('');
	}

	//我的参数记录
	function _buildMyEntryRecordHtml() {
		return '<div class="home-mods um-matchrecord">\
			<div class="hd">\
				<h2 class="title">我的参赛记录</h2>\
				<span class="sp J-myRecord" style="display:none;">最高分:<span class="J-bestScore" style="color:#f60"></span></span>\
			 </div>\
			 <div class="bd">\
				<div class="record-list J-myEntryRecordList">\
				</div>\
				<div class="palyagain J-againJoin" style="display:none;">\
					对自己成绩不满意？<br>\
					再次参赛试试\
				</div>\
			 </div>\
		 </div>';
	}

	function _buildMatchRankingHtml() {
		return '<div class="home-mods um-matchrank open">\
			<div class="hd">\
				<h2 class="title">本场比赛排行</h2>\
				<span class="sp J-myRanking" style="display:none;">我的排名:<em>0</em></span>\
			 </div>\
			 <div class="bd">\
				<div class="rank-list">\
					<ul class="list-unstyled J-recentEntryRecordList" >\
						<li class="nodata">\
							正在加载...\
						</li>\
					</ul>\
				</div>\
			 </div>\
			 <div class="ft">\
				<div class="opts J-matchRankingPage" data-page="1">\
					<a href="javascript:void(0)" class="J-prev-dan-btn um-btn-ghost um-btn-default um-btn-xs J-MatchRankingPre" >上一页</a>\
					<a href="javascript:void(0)" class="J-next-dan-btn um-btn-ghost um-btn-default um-btn-xs active J-MatchRankingnext" data-status="true" >\下一页</a>\
				</div>\
			 </div>\
		 </div>';
	}

	/**
	 * 获取最近参赛的人
	 * @returns {String}
	 */
	function _buildRecentEntryListHtml() {
		return '<div class="home-mods um-matchrank">\
			<div class="hd">\
				<h2 class="title">最近参赛的人</h2>\
			 </div>\
			 <div class="bd">\
				<div class="rank-list">\
					<ul class="list-unstyled J-recentEntryRecordList">\
						<li class="nodata">\
							正在加载...\
						</li>\
					</ul>\
				</div>\
			 </div>\
		 </div>';
	}

	//最近参赛记录列表
	function _buildRecentEntryList(aRecentEntryList) {
		var aDataList = aRecentEntryList;
		var aLiListHtml = [];
		if (aDataList.length == 0) {
			return '<li class="nodata">\
				还没有人参加呢...\
			</li>';
		}
		for (var i in aDataList) {
			var status = 'active';
			if (i > 3) {
				status = '';
			}
			if (i == aDataList.length) {
				status = 'last';
			}
			aLiListHtml.push('<li class="' + status + '">\
						' + Ui1.buildProfile(aDataList[i].user_info) + '\
						' + Ui1.buildVipName(aDataList[i].user_info) + '\
					<span class="score">\
						<em>' + aDataList[i].best_score + '</em>\
					</span>\
				</li>');

		}
		return aLiListHtml.join('');
	}

	//比赛排行榜
	function _buildMatchRankingList(aMatchRankingList) {
		var aDataList = aMatchRankingList;
		if (aDataList.length == 0) {
			return '<li class="nodata">\
					暂无数据...\
				</li>';
		}
		var aLiListHtml = [];
		for (var i in aDataList) {
			var status = 'active';
			if (aDataList[i].ranking > 3) {
				status = '';
			}
			if (i == aDataList.length) {
				status = 'last';
			}
			aLiListHtml.push('<li class="' + status + '">\
					<span class="num">' + aDataList[i].ranking + '</span>' + Ui1.buildProfile(aDataList[i].user_info) + '' + Ui1.buildVipName(aDataList[i].user_info) + '\
					<span class="score">\
						<em>' + aDataList[i].best_score + '</em>\
					</span>\
				</li>');

		}
		return aLiListHtml.join('');
	}

	//图片
	function _buildSmallPicHtml() {
		return '<div class="home-mods">' + Ui1.buildImage(_resourceUrl + _aUrl.starPicUrl) + '</div>';
	}

	function _buildPushTopicHtml() {
		return '<div class="home-mods um-mtopic">\
				<div class="hd">\
					 <h2 class="title">相关话题</h2>\
						<a href="' + _aUrl.gotoEnterTopicUrl + '" target="_blank" class="sp" title="进入话题">进入话题</a>\
				 </div>\
				 <div class="bd">\
					<ul class="J-relatedTopicList">\
						<li class="nodata">\
							正在加载...\
						</li>\
					</ul>\
				 </div>\
			 </div>';
	}

	/**
	 * 获取推荐(相关)话题列表数据
	 */
	function _getPushTopicList() {
		ajax({
			url: _aUrl.getRelatedTopicListUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					_appendRelatedTopicListHtml(aResult.data.aRelatedTopicList);
				}
			}
		});
	}

	/**
	 * 填充推荐(相关)话题数据
	 */
	function _appendRelatedTopicListHtml(aRelatedTopicList) {
		var relatedTopicList = _buildRelatedTopicList(aRelatedTopicList);
		_$matchDetail.find('.J-relatedTopicList').html(relatedTopicList);
	}


	/**
	 * 构建推荐话题列表html
	 */
	function _buildRelatedTopicList(aRelatedTopicList) {
		var aDataList = aRelatedTopicList;
		if (aDataList.length == 0) {
			return '<li class="nodata">\
					暂无数据\
				</li>';
		}
		var aLiListHtml = [];
		for (var i in aDataList) {
			aLiListHtml.push('<li><a href="' + _aUrl.enterTopicDetail.replace('_topicId', aDataList[i].id) + '" target="_blank"><span class="disc">' + aDataList[i].read_times + '</span>' + aDataList[i].title + '</a></li>');
		}
		return aLiListHtml.join('');
	}

	/**
	 * 确认参赛弹窗
	 */
	function _buildConfirmMatch() {
		var aMatchUserInfo = _defaultData.aMatchDetail.user_info;
		var isNodata = false;
		if (aMatchUserInfo.length == 0) {
			isNodata = true;
		}
		var gold = 0;
		//参加过了
		if (_defaultData.aMatchDetail.match_status == 6) {
			gold = _defaultData.aMatchDetail.rejoin_fee;
		} else {
			gold = _defaultData.aMatchDetail.join_fee;
		}
		var qq = (typeof(aMatchUserInfo.qq) == 'undefined') ? '' : aMatchUserInfo.qq;
		var name = (typeof(aMatchUserInfo.name) == 'undefined') ? '' : aMatchUserInfo.name;
		var address = (typeof(aMatchUserInfo.address) == 'undefined') ? '' : aMatchUserInfo.address;
		return '<div class="modal hide fade common-modal in J-confirmModal" id="matchConfirm" aria-hidden="false" style="display: block;">\
			<!-- success perfect fail -->\
			<div class="um-mcommon match-confirm">\
				<div class="hd">\
					确认参赛\
				</div>\
				<div class="bd">\
					<div class="point">请填写正确的收奖地址，否则我们将视为放弃奖品</div>\
					<form action="">\
						<p>\
							<label for="name">联 系 人：</label>\
							<input class="J-matchName" type="text" id="name" placeholder="请输入名字" value="' + name + '" >\
						</p>\
						<p>\
							<label for="phone">联系电话：</label>\
							<input class="J-matchPhone" type="text" id="phone" placeholder="请输入联系电话" value="' + (!isNodata ? aMatchUserInfo.call_phone : '') + '">\
						</p>\
						<p>\
							<label for="qq">Q Q号码：</label>\
							<input class="J-matchQq" type="text" id="qq" placeholder="请输入QQ号码" value="' + qq + '">\
						</p>\
						<p>\
							<label for="address">收货地址：</label>\
							<span class="ov">\
								<a class="btn-select">\
									<span class="J-select cur-select">请选择<i class="triangle-down"></i></span>\
									<select class="J-province"></select>\
								</a>\
								<a class="btn-select">\
									<span class="J-select cur-select">请选择<i class="triangle-down"></i></span>\
									<select class="J-city"></select>\
								</a>\
								<a class="btn-select">\
									<span class="J-select cur-select">请选择<i class="triangle-down"></i></span>\
									<select class="J-area"></select>\
								</a>\
								</span></p><div style="text-align:right;width: 89%;">\
									<input type="text" id="address"  class="address-detail J-matchAddress" placeholder="请输入详细地址" value="' + address + '">\
								</div>\
							\
						<p></p>\
					</form>\
					<div class="tip">系统将扣除你' + gold + '金币，是否继续？</div>\
				</div>\
				<div class="ft">\
					<div class="opts">\
						<a href="javascript:void(0)" class="um-btn um-btn-error um-btn-xlg J-startMatch" data-status="true">确认参赛</a>\
					</div>\
				</div>\
			</div>\
			<a href="javascript:void(0)" class="close J-matchConfirmClose" data-dismiss="modal">×</a>\
		</div>	';
	}

	function _startMatch(oData) {
		ajax({
			beforeSend:function(){
				$('.J-startMatch').data('status', false).html('数据提交中..');
			},
			url: _aUrl.startMatchUrl,
			data: oData,
			success: function (aResult) {
				if (aResult.status == 1) {
					var matchId = aResult.data.matchId;
					location.href = _aUrl.matchUrl;
				}else{
					$('.J-startMatch').data('status', true).html('确认参赛');
					UBox.show(aResult.msg, -1);
				}
			},
			error:function(){
				UBox.show('网络出错了,请重试..', -1);
				$('.J-startMatch').data('status', true).html('确认参赛');
			}
		});
	}

	function _validataFormInput() {
		var $userName = _$matchConfirm.find('.J-matchName');
		//获取任务信息
		var userName = $userName.val();
		var $phone = _$matchConfirm.find('.J-matchPhone');
		var phone = $phone.val();
		var $qq = _$matchConfirm.find('.J-matchQq');
		var qq = $qq.val();
		var $address = _$matchConfirm.find('.J-matchAddress');
		var address = $address.val();
		//省
		var province = _$matchConfirm.find('.J-province').val();
		//市
		var city = _$matchConfirm.find('.J-city').val();
		//区
		var area = _$matchConfirm.find('.J-area').val();

		if (userName == '') {
			UBox.show('名字不正确', -1);
			$userName.focus();
			return;
		}
		if (phone == '' || !/^1\d{10}$/.test(phone)) {
			UBox.show('手机号码不正确', -1);
			$phone.focus();
			return;
		}
		if (qq == '' || !/^\d+$/.test(qq)) {
			UBox.show('qq号码不正确', -1);
			$qq.focus();
			return;
		}
		if (address == '') {
			UBox.show('地址不能为空', -1);
			$address.focus();
			return;
		}
		if (province == 0 || city == 0 || area == 0) {
			UBox.show('请选择所在地', -1);
			return;
		}
		var oData = {
			match_id: _defaultData.aMatchDetail.id,
			user_name: userName,
			phone: phone,
			qq: qq,
			province: province,
			city: city,
			area: area,
			address: address
		};
		_startMatch(oData);
	}

	function _setTimerStatus() {
		var nowTime = parseInt($.now() / 1000);

		var startTime = _defaultData.aMatchDetail.match_start_time;
		var endTime = _defaultData.aMatchDetail.match_end_time;
		//距离开始时间
		if (startTime > nowTime && startTime < endTime) {
			_timer((startTime - nowTime), -1, 1);
		} else if (nowTime < endTime && startTime < nowTime) {
			//距离结束时间
			_timer((endTime - nowTime), -1);
		} else {
			//已结束
			//_$matchDetail.find('.J-overTime').show();
			_$matchDetail.find('.J-timer').remove();
			//_$matchDetail.find('.J-confirmMatch').css({'background': '#ccc'}).html('比赛结束').removeClass('J-confirmMatch').unbind('click');
		}

	}

	function _timer(intDiff, step,startOrEnd) {
		if(startOrEnd == undefined){
			startOrEnd = 0;
		}
		window.setInterval(function () {
			var day = 0,
					hour = 0,
					minute = 0,
					second = 0;
			if (intDiff > 0) {
				day = Math.floor(intDiff / (60 * 60 * 24));
				hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
				minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
				second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
			}
			if (day <= 9)
				day = '0' + day;
			if (hour <= 9)
				hour = '0' + hour;
			if (minute <= 9)
				minute = '0' + minute;
			if (second <= 9)
				second = '0' + second;
			if (startOrEnd > 0) {
				_$matchDetail.find('.J-timer').html('<i class="ico-match ico-countdown"></i>距开始：<span>' + day + '</span>天<span>' + hour + '</span>小时<span>' + minute + '</span>分<span>' + second + '</span>秒');
			} else {
				_$matchDetail.find('.J-timer').html('<i class="ico-match ico-countdown"></i>距结束：<span>' + day + '</span>天<span>' + hour + '</span>小时<span>' + minute + '</span>分<span>' + second + '</span>秒');
			}
			intDiff = intDiff + step;
		}, 1000);
	}
})(jQuery, window);
