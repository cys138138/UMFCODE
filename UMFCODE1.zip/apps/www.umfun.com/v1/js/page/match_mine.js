(function ($, win) {
	win.MatchMyMatch = {
		config: function (aOptions) {
			if (aOptions.url) {
				for (var key in _aUrl) {
					if (aOptions.url[key] != undefined) {
						_aUrl[key] = aOptions.url[key];
					}
				}
			}
			if (aOptions.defaultData) {
				for (var i in _defaultData) {
					if (aOptions.defaultData[i] != undefined) {
						_defaultData[i] = aOptions.defaultData[i];
					}
				}
			}
		},
		bannerHtml : '',
		show: function () {
			//构建基本骨架
			_buildContainerHtml();
			_getInitData();
			_bindEvent();
		}
	};
	var _aUrl = {
		matchIndexUrl: '',
		getMyMatchListUrl: '',
		oneMatchUrl: '',
		getMedalRankListUrl: '',
		starUrl: '',
		starPicUrl: '',
		gotoMatchMoreDetails: '',
		wrongMissionListUrl: '',
		practiceUrl: ''
	};

	var _defaultData = {
		aMedal: ''
	};
	var _$myMatch = $('.J-mainDiv'), _isOnlyAward = 0, _order = 0, _aMyMatchList = [], _aMedalRankList = [], _medalRandkOrder = 0, _resourceUrl = App.getUrl('resource');

	/**
	 * 加载完骨架之后获取数据
	 */
	function _getInitData() {
		_getMyMatchList();
		_getMedalRandList();

	}

	/**
	 * 为页面绑定事件
	 */
	function _bindEvent() {
		_$myMatch.find('.J-onlyAwardList').click(function () {
			_isOnlyAward = ($(this)[0].checked ? 1 : 0);
			_setLoadMoreStatus();
			_getMyMatchList();
		});
		_$myMatch.find('.J-MatchOrder a').click(function () {
			var order = $(this).data('order');
			_setLoadMoreStatus();
			$(this).addClass('active').siblings().removeClass('active');
			_order = order;
			_getMyMatchList();
		});
		_$myMatch.find('.J-loadMore').click(function () {
			$this = $(this);
			var page = $this.data('page');
			page = page + 1;
			if (_aMyMatchList[page + '_' + _order + '_' + _isOnlyAward] !== undefined) {
				_$myMatch.find('.J-loadMore').data('page', page);
				_appendMyMatchListHtml(_aMyMatchList[page + '_' + _order + '_' + _isOnlyAward], 1);
				return;
			}
			_getMyMatchList(page);
		});
		//奖牌排行分页
		_$myMatch.on('click', '.J-MedalPagination a', function () {
			var $this = $(this);
			var option = $this.hasClass('J-MedalRankPre');
			var page = $this.closest('.J-MedalPagination').data('page');
			if (!$this.data('status')) {
				return;
			}
			//点击上一页
			if (option) {
				//第一页
				if (page == 1) {
					$this.removeClass('active').data('status', false);
					return;
				}
				page = (page - 1);
			} else {
				page = (page + 1);
			}
			_$myMatch.find('.J-MedalPagination a').addClass('active');
			if (page < 1 || page > 10) {
				page = 1;
			}
			//数据缓存
			if (_aMedalRankList[page + '_' + _aMedalRankList] !== undefined) {
				_appendMedalRandListHtml(_aMedalRankList[page + '_' + _aMedalRankList], page);
				return;
			}
			_getMedalRandList(page, $this);

		});

	}

	function _setLoadMoreStatus() {
		_$myMatch.find('.J-loadMore').show().data('page', 1);
		_$myMatch.find('.J-loadMoreNodata').hide();
	}

	/**
	 * 获取我的比赛列表数据
	 */
	function _getMyMatchList(page) {
		var isLoadMore = true;
		if (page == undefined) {
			isLoadMore = false;
			page = 1;
		}
		ajax({
			url: _aUrl.getMyMatchListUrl,
			data: {
				page: page,
				page_size: 10,
				prize_flag: _isOnlyAward,
				order: _order,
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMatchList = aResult.data.aMyMatchList;
					_aMyMatchList[page + '_' + _order + '_' + _isOnlyAward] = aMatchList;
					if (isLoadMore) {
						_$myMatch.find('.J-loadMore').data('page', page);
						_appendMyMatchListHtml(aMatchList, 1);
						return;
					}
					_appendMyMatchListHtml(aMatchList);
				}
			}
		});
	}

	function _appendMyMatchListHtml(aMyMatchList, type) {
		if (type === undefined) {
			var myMatchList = _buildMyMatchList(aMyMatchList);
			_$myMatch.find('.J-myMatchList').html(myMatchList);
		} else {

			if (aMyMatchList.length == 0) {
				_$myMatch.find('.J-loadMore').hide();
				_$myMatch.find('.J-loadMoreNodata').show();
				return;
			}
			var myMatchList = _buildMyMatchList(aMyMatchList);
			_$myMatch.find('.J-myMatchList').append(myMatchList);
		}

		//强化修炼建议
		_$myMatch.find('.J-recommend').click(function(){
			var $self = $(this);
			var matchId = $self.data('id');
			//增加关卡推荐=>20150723
			ajax({
				url: _aUrl.wrongMissionListUrl,
				data: {match_id: matchId},
				success: function(data){
					var aData = data['data'];
					var len = aData.length;
					if(len == 0){return;}

					var itemNum = 3, outerWidth = 420, outerHeight = 140;
					var pageNum = Math.ceil(len / itemNum);    //页数
					var itemHtml = '', $match = '', $page = '';
					var $module = Ui1.buildScrollPageModule();
					$module.addClass('scroll-module');
					$module.css('width', outerWidth + 'px');
					$module.css('height', outerHeight + 'px');
					var $container = $module.getContainer();	//获取内部容器
					for(var i=0; i<len; ++i){
						itemHtml = '<a class="mission-item"><div><div>' + aData[i]['subject_name'] + '</div><div>' + aData[i]['grade_name'] + '</div><div>' + aData[i]['name'] + '</div></div><div><span>去修炼</span></div></a>';
						$match = $(itemHtml);
						$match.attr('href', _aUrl.practiceUrl.replace('id', aData[i]['id']));

						if(i % itemNum == 0){     //每3个分成一页
						    $page = $('<div class="mission-item-page"></div>');
						    $page.css('width', outerWidth + 'px');
						    $container.append($page);
						}
						$page.append($match);
					}
					$container.css('width',  pageNum * outerWidth + 'px');
					var $extend = $('<div class="J-mask um-common-mask">\
										<div class=" container">\
											<div class="J-recommend um-recommend-mission">\
												<div class="J-close-button close-button"></div>\
												<div class="title">强化修炼</div>\
												<div class="desc">根据你本场比赛的答题情况，推荐去以下关卡进行修炼</div>\
												<hr/>\
											</div>\
										</div>\
									</div');
					$extend.find('.J-recommend').append($module);
					_$myMatch.append($extend);
					$module.updateNum();		//更新页面标识（容器添加子节点之后）

					//关闭按钮事件
					$extend.find('.J-close-button').click(function(){
						_$myMatch.find('.J-mask').remove();
					});
					//切换页面按钮特殊修改
					var $handle = $extend.find('.J-module-scroll-page-handle')
					$handle.css('border-color', 'rgba(0, 0, 0, 0)');
					$handle.eq(0).css('margin-left', '-50px');
					$handle.eq(1).css('margin-right', '-50px');
					$extend.find('.J-module-scroll-page-handle > .J-arrow').css('border-color', 'black');
				}
			});
		});
	}

	/**
	 * 获取奖牌排行列表数据
	 */
	function _getMedalRandList(page, $this) {
		if (page === undefined) {
			page = 1;
		}
		ajax({
			beforeSend: function () {
				if ($this !== undefined) {
					$this.data('status', false);
				}
			},
			data: {
				page: page,
				order: _medalRandkOrder,
			},
			url: _aUrl.getMedalRankListUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMedalRankList = aResult.data.aMedalRankList;
					//第一页就没数据
					if (aMedalRankList.length == 0 && page == 1) {
						_$myMatch.find('.J-MedalPagination').hide();
						_$myMatch.find('.J-medalRanklist').html('<li class="nodata">暂无数据</li>');
						return;
					}
					//数据缓存
					_aMedalRankList[page + '_' + _aMedalRankList] = aMedalRankList;
					_appendMedalRandListHtml(aMedalRankList, page);
				}
			}
		});
	}

	function _buildContainerHtml() {
		var aContainerHtml = [];
		//主体html
		aContainerHtml.push('<div class="contain">\
		<div class="um-layout-1">');
		//我的赛事列表
		aContainerHtml.push(_buildMainHtml());

		//side 右侧
		aContainerHtml.push(_buildSideHtml());
		//结束html
		aContainerHtml.push('</div></div>');
		_$myMatch.html(aContainerHtml.join(''));
	}

	function _buildMainHtml() {
		var aMainHtml = [];
		aMainHtml.push('<div class="main">\
			<div class="home-mods match-main">\
				<div class="match-nav">\
					<a href="' + _aUrl.matchIndexUrl + '">全部比赛</a>\
					<a href="' + _aUrl.starUrl + '">比赛之星</a>\
					<a href="javascript:;" class="active">我的比赛</a>\
				</div>\
					<div class="bd">');
		aMainHtml.push(_buildMyMatchtMainHtml());
		aMainHtml.push('</div></div></div>');
		return aMainHtml.join('');
	}

	function _buildMyMatchtMainHtml() {
		return '<div class="match-sort-wrap">\
			<div class="match-sort">\
				<div class="fl J-MatchOrder">\
					<span class="sort-h">排序：</span>\
					<a href="javascript:void(0)" data-order="0" class="active">按参赛时间</a>\
					<a href="javascript:void(0)" data-order="2">按最高得分</a>\
					<a href="javascript:void(0)" data-order="3">按最好排名</a>\
				</div>\
				<div class="fr">\
					<div class="sort-h">\
						<input type="checkbox" class="J-onlyAwardList">仅查看获奖赛事\
					</div>\
				</div>\
			</div>\
			<div class="match-main-list match-sort-list">\
				<div class="bd">\
					<ul class="list-unstyled J-myMatchList"><li class="nodata">加载中</li></ul>\
				</div>\
				<div class="ft">\
					<a href="javascript:void(0)" class="J-loadMore" data-page="1" style="display:none;">加载更多</a>\
					<a href="javascript:void(0)" class="J-loadMoreNodata" style="color:#ccc; display:none">没有数据了</a>\
				</div>\
			</div>\
		</div>';
	}

	function _buildMyMatchList(aMyMatchList) {
		var aDataList = aMyMatchList;
		if(aDataList.length == 0){
			return '<li class="nodata">暂无数据..</li>';
		}
		_$myMatch.find('.J-loadMore').show();
		var aLiListHtml = [];
		for (var i in aDataList) {
			var bgColor = '';
			var oTemp = aDataList[i];
			var matchStatus = 'over',
			matchStatusStr = '查看比赛';
			if(oTemp.status == 3){
				matchStatusStr = '查看比赛';
			}else if(oTemp.status == 2){
				matchStatus = 'ing';
				matchStatusStr = '再次参赛';
			}else if(oTemp.status == 1){
				matchStatusStr = '查看比赛';
			}else if(oTemp.status == 4){
				matchStatus = 'ing';
				matchStatusStr = '立即比赛';
			}else if(oTemp.status == 5){
				matchStatus = 'cur';
				matchStatusStr = '继续比赛';
			}else if(oTemp.status == 6){
				matchStatus = 'ing';
				matchStatusStr = '再次参赛';
			}else if(oTemp.status == 7){
				matchStatus = 'over';
				bgColor = 'background-color: #093;';
				matchStatusStr = '领取奖励';
			}
			var gradName = aDataList[i].grade_name != '' ? '【' + aDataList[i].grade_name + '】' : '';
			if (aDataList[i].is_big_match == 1 || aDataList[i].grade_id == 0) {
				gradName = '';
			}

			var recommendMatch = '';
			if(aDataList[i]['match_user_relation'] && aDataList[i]['match_user_relation']['have_wrong_es'] != 0){
				recommendMatch = '&nbsp;&nbsp;&nbsp;&nbsp;<a class="J-recommend" data-id="' + aDataList[i]['id'] + '">强化修炼建议</a>';
			}
			aLiListHtml.push('<li class="' + matchStatus + '">\
				<a href="javascript:void(0)">\
					<div class="match-wrap">\
						<div class="match-img">\
							' + Ui1.buildImage(_resourceUrl + aDataList[i].profile, undefined, {width: 92, height: 92}) + '\
						</div>\
						<i class="ico-match"></i>\
					</div>\
				</a>\
				<div class="match-sort-info">\
					<div class="title">' + gradName + aDataList[i].name + '</div>\
					<div class="prize">' + aDataList[i].description + '</div>\
					<div class="num">\
						<em>' + aDataList[i].join_match_count + '</em>人参加' + recommendMatch + '</div>\
				</div>\
				<div class="match-sort-otps">');
			if (aDataList[i].status == 7) {
				aLiListHtml.push('<a href="' + _aUrl.oneMatchUrl.replace('_matchId', aDataList[i].id) + '" class="match-list-btn" style="' + bgColor + '">领取奖励</a>');
			} else {
				aLiListHtml.push('<a href="' + _aUrl.oneMatchUrl.replace('_matchId', aDataList[i].id) + '" class="match-list-btn" style="' + bgColor + '">' + matchStatusStr + '</a>');
			}
			aLiListHtml.push('<div class="match-list-text">\
						<div class="text">我的最高分<em>' + aDataList[i].match_user_relation.best_score + '</em></div>\
						<div class="text">我的排名<em>' + aDataList[i].match_user_relation.ranking + '</em></div>\
					</div>\
				</div>\
			</li>');
		}
		return aLiListHtml.join('');
	}

	function _buildSideHtml() {
		var aSideHtml = [];
		aSideHtml.push('<div class="side">');
		aSideHtml.push(_buildMyMedalHtml());

		aSideHtml.push(self.bannerHtml);
		aSideHtml.push(_buildMedalrankHtml());
		aSideHtml.push('</div>');
		return aSideHtml.join('');
	}

	//我的奖牌
	function _buildMyMedalHtml() {
		return '<div class="home-mods um-mmymedal">\
				<div class="hd">\
					 <h2 class="title">我的奖牌</h2>\
				 </div>\
				<div class="bd">\
					<div class="my-medallist">\
						<div class="brand">\
							<i class="ico_brand ico_brand_gold_b"></i>\
							<span class="text">' + _defaultData.aMedal.gold_medal + '</span>\
						</div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_silver_b"></i>\
							<span class="text">' + _defaultData.aMedal.silver_medal + '</span>\
						</div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_copper_b"></i>\
							<span class="text">' + _defaultData.aMedal.cuprum_medal + '</span>\
						</div>\
					</div>\
				 </div>\
				<div class="hd">\
					 <h2 class="title">比赛须知</h2>\
					 <a href="' + _aUrl.gotoMatchMoreDetails + '" target="_blank" class="sp">\
						更多详情\
					 </a>\
				 </div>\
				 <div class="bd">\
					<div class="match-notic">\
						<ul class="J-matchNoticeList">\n\
							<li>大赛每个组别的前三名用户会获得相应的实物奖励，并没有10名幸运奖。奖品会于比赛结束后发出。</li>\
							<li>日常比赛前三名用户会在比赛结束后获得相应的金币奖励。</li>\
						</ul>\
					</div>\
				 </div></div>';
	}

	/**
	 * 获取奖牌排行列表数据
	 */
	function _getMedalRandList(page, $this) {
		if (page === undefined) {
			page = 1;
		}
		ajax({
			beforeSend: function () {
				if ($this !== undefined) {
					$this.data('status', false);
				}
			},
			data: {
				page: page,
				order: _medalRandkOrder,
			},
			url: _aUrl.getMedalRankListUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMedalRankList = aResult.data.aMedalRankList;
					//第一页就没数据
					if (aMedalRankList.length == 0 && page == 1) {
						_$myMatch.find('.J-MedalPagination').hide();
						_$myMatch.find('.J-medalRanklist').html('<li class="nodata">暂无数据</li>');
						return;
					}
					//数据缓存
					_aMedalRankList[page + '_' + _aMedalRankList] = aMedalRankList;
					_appendMedalRandListHtml(aMedalRankList, page);
				}
			}
		});
	}

	/**
	 * 填充奖牌排行列表数据
	 */
	function _appendMedalRandListHtml(aMedalRankList, page) {
		//最后一页
		if ((page > 1) && (aMedalRankList.length == 0)) {
			_$myMatch.find('.J-MedalRankNext').removeClass('active').data('status', false);
			_$myMatch.find('.J-MedalPagination').data('page', page);
			_$myMatch.find('.J-medalRanklist').html('<li class="nodata">没有数据啦</li>');
			return;
			//处理非最后一页让按钮可点击
		} else {
			_$myMatch.find('.J-MedalPagination a').data('status', true);
		}
		if (page == 1) {
			_$myMatch.find('.J-MedalRankPre').removeClass('active').data('status', false);
		}
		_$myMatch.find('.J-MedalPagination').data('page', page);
		var medalRankList = _buildMedalRankList(aMedalRankList);
		_$myMatch.find('.J-medalRanklist').html(medalRankList);
	}

	/**
	 * 构建奖牌列表html
	 */
	function _buildMedalrankHtml() {
		return '<div class="home-mods um-mmadalrank">\
				<div class="hd">\
					 <h2 class="title">奖牌排行榜</h2>\
				 </div>\
				 <div class="bd">\
					<div class="madalrank-list">\
						<div class="caption">\
							<span class="td rank">排名</span>\
							<span class="td">金牌</span>\
							<span class="td">银牌</span>\
							<span class="td">铜牌</span>\
							<span class="td">总数</span>\
						</div>\
						<div class="tbody">\
							<ul class="list-unstyled J-medalRanklist"><li class="nodata">加载中</li></ul>\
						</div>\
					</div>\
				 </div>\
				 <div class="ft">\
					<div class="opts J-MedalPagination" data-page="1">\
						<a href="javascript:void(0)" class="J-prev-dan-btn um-btn-ghost um-btn-default um-btn-xs J-MedalRankPre" data-status="true">上一页</a>\
						<a href="javascript:void(0)" class="J-next-dan-btn um-btn-ghost um-btn-default um-btn-xs active J-MedalRankNext" data-status="true">下一页</a>\
					</div>\
				 </div>\
			 </div>';
	}

	/**
	 * 构建
	 */
	function _buildMedalRankList(aMedalRankList) {
		var aDataList = aMedalRankList;
		var aLiListHtml = [];
		for (var i in aDataList) {
			aLiListHtml.push('<li class="' + ((aDataList[i].rank > 3) ? '' : 'active') + '">\
				<span class="td rank">\
					<span class="num">' + aDataList[i].rank + '</span>\
						' + Ui1.buildProfile(aDataList[i].user_info) + '\
				</span>\
				<span class="td">' + aDataList[i].gold_medal + '</span>\
				<span class="td">' + aDataList[i].silver_medal + '</span>\
				<span class="td">' + aDataList[i].cuprum_medal + '</span>\
				<span class="td">' + aDataList[i].all_medal + '</span>\
			</li>');
		}
		return aLiListHtml.join('');
	}

	var self = win.MatchMyMatch;
})(jQuery, window);
