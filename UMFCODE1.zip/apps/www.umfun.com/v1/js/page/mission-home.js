(function($, win){
	win.MissionHome = {
		aMissionListCache : {},
		aDanRankListCache : {},
		isGetDanAjaxIng : false,
		isGetMissionListAjaxIng : false,
		// 闯关列表切换
		tabListStyle : function(o, type){
			//	<a href="###"><i class="v3-cdi"></i></a>
			//	<span class="text">95.5</span>
			//	<i class="v3-good-green"></i>
			if(_checkIsGettingMissionList()){
				return ;
			}
			if(type == 1){
				$('#missionListStyle').removeClass('thumb-style');
				$('#missionListStyle').addClass('list-style');
			}else{
				$('#missionListStyle').removeClass('list-style');
				$('#missionListStyle').addClass('thumb-style');
			}
			$(o).parent().children().removeClass('active');
			$(o).addClass('active');
			this._updateMissionListStatusCookieByType(1, type);
			this.listStyle = type;
			this._getMissionList(this.gradeId, this.subjectId);
		},

		// 卡牌选择
		cardSelect : function(){
			var prevData;
			var $info = $('#cardModal .ft>.info');
			var imgSrc;
			var cardName;
			var cardIntro;

			prevData = $info.html();
			var $li =$('#cardSlide .slide li');

			$li.each(function(){
				if($(this).hasClass('disabled')){
					$(this).find('img').attr('src',$(this).find('img').attr('src'));
				}else{
					$li.click(function(e) {
						e.preventDefault();
						e.stopPropagation();
						imgSrc = $(this).find('img').attr('src');
						cardName = $(this).attr('data-cardname');
						cardIntro = $(this).attr('data-cardintro');

						if($(this).hasClass('disabled')){
							return false;
						}
						if($(this).hasClass('active')){
							return;
						}else{
							$(this).addClass('active').siblings().removeClass('active');
							$('#cardModal .ft')
								.addClass('active')
								.find('#introImg')
								.attr('src',imgSrc);
							$info.find('.title').html(cardName);
							$info.find('.description').html(cardIntro);
						}
					})
				}
			});

			$(document).on('click', '#cardBack', function(){
				$('#cardSlide .slide li, #cardModal .ft').removeClass('active');
				$info.html(prevData);
				_tooltip();
			});
			$('#cardSlide .slide li, #cardModal .ft').removeClass('active');
			$info.html(prevData);
		},

		showGrade : function (){
			var aHtml = [],
			gradeText = '',
			active = '';
			for(var value in this.aGrade){
				if(this.gradeId == value){
					active = 'class="active"';
					gradeText = this.aGrade[value];
				}else{
					active = '';
				}
				aHtml.push('<li><a href="javascript:;" ' + active + ' data-role="' + value + '" onclick="MissionHome.selectGrade(this, ' + value + ');">' + this.aGrade[value] + '</a></li>');
			}

			$('.J-mission-list-grade').html(aHtml.join(''));
			$('.J-grade-text').html(gradeText + '<i class="triangle-down"></i>');
			this.showSubject();
		},

		showSubject : function (){
			if(_checkIsGettingMissionList()){
				return ;
			}
			var aHtml = [],
			active = '';
			for(var value in this.aSubjectList[this.gradeId]){
				if(this.subjectId == value){
					active = 'class="active"';
				}else{
					active = '';
				}
				aHtml.push('<li ' + active + ' ><a href="javascript:;" data-toggle="tab" data-role="' + value + '" onclick="MissionHome.selectSubject(this, ' + value + ');">' + this.aSubjectList[this.gradeId][value] + '</a></li>');
			}

			$('.J-mission-list-subject').html(aHtml.join(''));
			_checkMissionListParams(this.gradeId, this.subjectId);
			this._getMissionList(this.gradeId, this.subjectId);
		},

		selectGrade : function(o, id){
			this.gradeId = id;
			$(o).parent().parent().find('li a').removeClass('active');
			$(o).addClass('active');
			$('.J-grade-text').html($(o).text() + '<i class="triangle-down"></i>');
			this._updateMissionListStatusCookieByType(2, id);
			this.showSubject();
		},

		selectSubject : function(o, id){
			this.subjectId = id;
			$(o).parent().parent().find('li').removeClass('active');
			$(o).parent().addClass('active');
			this._updateMissionListStatusCookieByType(3, id);
			_checkMissionListParams(this.gradeId, this.subjectId);
			this._getMissionList(this.gradeId, this.subjectId);
		},

		_getMissionList : function(gradeId, subjectId){
			if(_checkIsGettingMissionList()){
				return ;
			}
			$('.J-mission-list-loading').show();
			$('.J-mission-list-pane').hide();
			$('.J-mission-list-caption').hide();
			var keyStr = 'key_' + gradeId + '_' + subjectId;
			var oMission = this;
			if(typeof(oMission.aMissionListCache[keyStr]) != 'undefined'){
				oMission._appendMissionList(oMission.aMissionListCache[keyStr]);
				$('.J-mission-list-loading').hide();
				return;
			}
			oMission.isGetMissionListAjaxIng = true;
			//ajax
			ajax({
				url : oMission.missionListUrl,
				data : {
					grade_id : gradeId,
					subject_id : subjectId
				},
				success : function(aResult){
					oMission.isGetMissionListAjaxIng = false;
					if(aResult.status == 1){
						oMission.aMissionListCache[keyStr] = aResult.data;
						oMission._appendMissionList(aResult.data);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
					$('.J-mission-list-loading').hide();
				},
				error : function(){
					oMission.isGetMissionListAjaxIng = false;
					UBox.show('抱歉，系统错误！', 0);
				}
			});
			//设置cookie
		},

		_appendMissionList : function(aData){
			var aHtml = [],
			hasCurrentMission = false,
			lastMissionId = _getLastMissionId();
			for(var index in aData){
				var oTempItem = aData[index],
				practicBtnText = '',
				liClassStr = '',
				challengeBtnText = '';
				if(this.listStyle == 0){
					liClassStr = ' J-mission-list-item-li';
				}
				if(lastMissionId == oTempItem.id){
					hasCurrentMission = true;
				}
				if(oTempItem.task_process == 0){
					aHtml.push('<li class="lock' + liClassStr + '">');
					practicBtnText = '修炼';
				}else if(oTempItem.task_process == 1){
					aHtml.push('<li class="continue' + liClassStr + '">');
					practicBtnText = '继续修炼';
				}else if(oTempItem.task_process == 2 && oTempItem.chanllge_process == 0){
					aHtml.push('<li class="continue' + liClassStr + '">');
					practicBtnText = '修炼';
					challengeBtnText = '立刻挑战';
				}else if(oTempItem.task_process == 2){
					aHtml.push('<li class="success' + liClassStr + '">');
					practicBtnText = '修炼';
					challengeBtnText = '立刻挑战';
				}
				if(oTempItem.chanllge_process == 1){
					challengeBtnText = '再次挑战';
				}
				aHtml.push('<div class="J-mission-list-item-' + oTempItem.id + ' item-hd" title="' + oTempItem.name + '">');
				aHtml.push(oTempItem.name);
				aHtml.push('</div>');
				aHtml.push('<div class="item-bd">');
				if(this.listStyle == 1 && oTempItem.chanllge_process == 1){
					if(oTempItem.cd_time == 1){
						aHtml.push('<a data-toggle="tooltip" data-original-title="卡牌冷却完成"><i class="v3-cdc"></i></a>');
					}else if(oTempItem.cd_time != 0){
						aHtml.push('<a data-toggle="tooltip" data-original-title="卡牌冷却中,剩余' + oTempItem.cd_time + '"><i class="v3-cdi"></i></a>');
					}
				}
				if(oTempItem.score != 0){
					aHtml.push('<span class="text">' + oTempItem.score + '</span> ');
				}else{
					if(this.listStyle == 1){
						aHtml.push('<span class="text">-</span> ');
					}
				}
				if(oTempItem.chanllge_process == 1 && oTempItem.is_good == 1){
					if(this.listStyle == 0){
						aHtml.push('<i class="v3-good-white"></i>');
					}else{
						aHtml.push('<i class="v3-good-green"></i>');
					}
				}
				
				if(this.listStyle == 0 && typeof(oTempItem.best_score_user_info.id) != 'undefined'){
					oTempItem.best_score_user_info.profile = App.getUrl('resource') + oTempItem.best_score_user_info.profile;
					aHtml.push('<a href="' + _getAnalysisUrlUrl(oTempItem.id) + '">' + Ui1.buildImage(oTempItem.best_score_user_info.profile, Ui1.defaultProfile, {width: 40, height: 40}) + '</a>');
				}
				aHtml.push('</div>');
				aHtml.push('<div class="item-ft">');
				if(oTempItem.chanllge_process == 1 && oTempItem.cd_time != 0){
					if(oTempItem.cd_time == 1){
						aHtml.push('<div class="cooldown">卡牌冷却完成</div>');
					}else{
						aHtml.push('<div class="cooldown">卡牌冷却中,剩余' + oTempItem.cd_time + '</div>');
					}
				}
				aHtml.push('<div class="opts">');
				if(challengeBtnText != ''){
					aHtml.push('<a href="' + _getChallengeUrl(oTempItem.id) + '">' + challengeBtnText + '</a>');
				}
				if(practicBtnText != ''){
					aHtml.push('<a href="' + _getPracticeUrl(oTempItem.id) + '">' + practicBtnText + '</a>');
				}
				aHtml.push('</div>');
				aHtml.push('</div>');
				aHtml.push('</li>');
			}
			$('.J-mission-list-pane ul').html(aHtml.join(''));
			$('.J-mission-list-pane').show();
			if(this.listStyle == 1){
				$('.J-mission-list-caption').show();
			}else{
				$('.J-mission-list-item-li .item-bd a img').attr('title', '本关之星');
			}
			// 工具提示
			_tooltip();
			$('.J-mission-list-pane').jScrollPane();
			if(hasCurrentMission){
				this.locationCurrentMission(lastMissionId);
			}else{
				$('.J-mission-list-pane').jScrollPane().data('jsp').scrollToY(0);
			}
		},

		_getMissionListStatusCookie : function(){
			var missionListStatus = $.cookie('mission_list_status');
			var aMissionListStatus = [];
			if(missionListStatus){
				aMissionListStatus = missionListStatus.split(',');
			}

			if(aMissionListStatus.length > 0){
				return aMissionListStatus;
			}else{
				return false;
			}
		},

		_updateMissionListStatusCookieByType : function(type, value){
			var aMissionListStatus = this._getMissionListStatusCookie();
			if(!aMissionListStatus){
				return ;
			}
			aMissionListStatus[type] = value;
			if(typeof(aMissionListStatus[4]) == 'undefined'){
				aMissionListStatus[4] = 0;
			}
			this._setMissionListStatusCookie(aMissionListStatus[0], aMissionListStatus[1], aMissionListStatus[2], aMissionListStatus[3], aMissionListStatus[4]);
		},

		_setMissionListStatusCookie : function(studentId, listStyle, gradeId, subjectId, lastMissionId){
			$.cookie('mission_list_status', studentId + ',' + listStyle + ',' + gradeId + ',' + subjectId + ',' + lastMissionId, {path: '/'});
		},

		initMissionListStatusCookie : function(){
			var aMissionListStatus = this._getMissionListStatusCookie(),
			subjectId = this.subjectId,
			gradeId = this.gradeId,
			aGrade = this.aGrade,
			aSubjectList = this.aSubjectList,
			userId = App.oCurrentStudent.id;
			if(aMissionListStatus == false){
				if(typeof(aGrade[gradeId]) == 'undefined'){
					gradeId = this.studentGrade;
					if(typeof(aSubjectList[gradeId][subjectId]) == 'undefined'){
						for(var value in aSubjectList[gradeId]){
							subjectId = value;
							break;
						}
					}
				}

				this._setMissionListStatusCookie(userId, 0, gradeId, subjectId, 0);
				this.gradeId = gradeId;
				this.subjectId = subjectId;
				this.listStyle = 0;
			}else{
				if(typeof(aGrade[gradeId]) != 'undefined'){
					if(typeof(aMissionListStatus[4]) == 'undefined'){
						aMissionListStatus[4] = 0;
					}
					this._setMissionListStatusCookie(userId, aMissionListStatus[1], this.gradeId, this.subjectId, aMissionListStatus[4]);
				}else{
					this.gradeId = aMissionListStatus[2];
					this.subjectId = aMissionListStatus[3];
				}
				this.listStyle = aMissionListStatus[1];
			}

			if(this.listStyle == 1){
				$('.v3-thumb-style').removeClass('active');
				$('.v3-list-style').addClass('active');
				$('#missionListStyle').removeClass('thumb-style');
				$('#missionListStyle').addClass('list-style');
			}else{
				$('.v3-list-style').removeClass('active');
				$('.v3-thumb-style').addClass('active');
				$('#missionListStyle').removeClass('list-style');
				$('#missionListStyle').addClass('thumb-style');
			}
		},

		showDan : function(aDan){
			var aHtml = [],
			danRank = 0,
			danRankText = '--',
			p1 = '',
			p3 = '',
			hasDan = false;
			avgScore = 0.00;

			if(!$.isArray(aDan)){
				danRank = 3;
				p1 = '闯关平均分';
				p3 = '距' + aDan.next_dan_name + '还差'  + aDan.next_dan_short_score+ '分';
				avgScore = aDan.mission_avg_score;
				danRankText = aDan.name;
				if(aDan.next_dan_id == 0){
					p3 = '';
				}
				hasDan = true;
			}else{
				p1 = '暂时无段位';
				p3 = '闯完20关后再统计段位';
			}
			aHtml.push('<div class="hd">');
			aHtml.push('<span class="title">我的段位</span>');
			aHtml.push('<a href="javascript:;" class="ep" data-toggle="tooltip" data-original-title="' + this.whatIsDan + '">段位是什么？</a>');
			aHtml.push('</div>');
			aHtml.push('<div class="bd">');
			aHtml.push('<div class="l">');
			aHtml.push('<div class="rank' + danRank + ' rank-icon">');
			if(!hasDan){
				aHtml.push('<i class="icon"></i>');
			}else{
				aHtml.push('<img src ="' + aDan.image + '" />');
			}
			aHtml.push('</div>');
			aHtml.push('<div class="rank' + danRank + ' text">' + danRankText + '</div>');
			aHtml.push('</div>');
			aHtml.push('<div class="r">');
			aHtml.push('<div class="p1">' + p1 + '</div>');
			aHtml.push('<div class="p2">' + avgScore + '</div>');
			aHtml.push('<div class="p3">' + p3 + '</div>');
			aHtml.push('</div>');
			aHtml.push('</div>');
			aHtml.push('<div class="ft"></div>');
			$('.J-dan-info').html(aHtml.join(''));
			if(aDan.length == 0){
				$('.J-dan-info').addClass('nodata');
			}
		},

		showDanRankList : function(type){
			if(_checkIsGettingDanList()){
				return ;
			}
			var oMission = this;

			$('.J-dan-list-ul li').removeClass('active');
			if(type == 1){
				$('.J-friend-rank').addClass('active');
			}else{
				$('.J-world-rank').addClass('active');
			}

			if(type != oMission.danRankType){
				oMission.danRankPage = 1;
				oMission.danRankType = type;
			}
			var keyStr = 'key_' + type + '_' + oMission.danRankPage;
			if(typeof(oMission.aDanRankListCache[keyStr]) != 'undefined'){
				_afterGettingDanRankList(oMission.aDanRankListCache[keyStr]);
				return;
			}
			oMission.isGetDanAjaxIng = true;
			ajax({
				url : oMission.danRankListUrl,
				data : {page : oMission.danRankPage, type : type},
				success : function(aResult){
					oMission.isGetDanAjaxIng = false;
					if(aResult.status == 2){
						oMission.danRankPage -= 1;
						return;
					}
					oMission.aDanRankListCache[keyStr] = aResult.data;
					if(aResult.status == 1){
						_afterGettingDanRankList(aResult.data);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(){
					oMission.isGetDanAjaxIng = false;
					UBox.show('抱歉，系统错误！', 0);
				}
			});
		},

		nextDanRankPage : function(){
			if(_checkIsGettingDanList()){
				return ;
			}
			this.danRankPage = this.danRankPage + 1;
			this.showDanRankList(this.danRankType);
		},

		prevDanRankPage : function(){
			if(_checkIsGettingDanList()){
				return ;
			}
			if(this.danRankPage != 1){
				this.danRankPage = this.danRankPage - 1;
				this.showDanRankList(this.danRankType);
			}
		},

		showCardsList : function(aData){
			var aHtml = [];
			for(var index in aData){
				var oTemp = aData[index];
				aHtml.push('<li>');
				aHtml.push('<a href="#cardModal" data-toggle="modal" onclick="MissionHome.showCardsDetail(' + oTemp.id + ');">');
				aHtml.push('<img src="' + oTemp.profile + '">');
				aHtml.push('</a>');
				aHtml.push('<span class="J-card-cound-summary-' + oTemp.id + ' card-text" userCount="' + oTemp.user_cards_count + '" totalCount="' + oTemp.cards_count + '">' + oTemp.user_cards_count + '/' + oTemp.cards_count + '</span>');
				aHtml.push('</li>');
			}
			$('.J-card-list').html(aHtml.join(''));
			// 卡牌宽度控制
			ulWidth('#slideCard');

		},

		showCardsDetail : function(id){
			_getCardsDetail(id);
		},

		comfirmExchangeCard : function(o, id){
			$('.J-exchange-tips').show();
			$(o).text('确定兑换');
			$(o).attr('onclick', 'MissionHome.exchangeCard(this, ' + id + ');');
		},

		exchangeCard : function(o, id){
			$(o).addClass('disabled');
			$(o).removeAttr('onclick');
			$(o).text('正在兑换...');
			ajax({
				url : this.exchangeCardsUrl,
				data : {id : id},
				success : function(aResult){
					if(aResult.status == 1){
						//$('.J-exchange-tips').text('恭喜您，兑换成功并获得' + $('.J-exchange-tips').attr('exchange_gold') + '金币');
						$('.J-exchange-tips').text('恭喜您，兑换成功并获得' + aResult.data.gold + '金币');
						$(o).text('立刻兑换');
						var oSummary = $('.J-card-cound-summary-' + id);
						oSummary.text('0/' + oSummary.attr('totalCount'));
						App.oCurrentStudent.updateInfo();
					}else{
						$(o).removeClass('disabled');
						$(o).attr('onclick', 'MissionHome.exchangeCard(this, ' + id + ');');
						$(o).text('确定兑换');
					}
				},
				error : function(){
					UBox.show('抱歉，系统错误！', 0);
				}
			});
		},

		locationCurrentMission : function(id){
			var index = $('.J-mission-list-item-' + id).parent().index();
			var value = 0;
			if(self.listStyle == 0){
				value = parseInt(index / 3) * 120;
			}else{
				value = parseInt(index / 1) * 40;
			}
			$('.J-mission-list-pane').jScrollPane().data('jsp').scrollToY(value);
		}
	};

	function _checkMissionListParams(gradeId, subjectId){
		if(typeof(self.aSubjectList[gradeId][subjectId]) == 'undefined'){
			for(var value in self.aSubjectList[gradeId]){
				self.subjectId = value;
				break;
			}
		}
	}

	function _getChallengeUrl(id){
		return self.challengeUrl.replace('_missionId', id);
	}

	function _getPracticeUrl(id){
		return self.practiceUrl.replace('_missionId', id);
	}

	function _getAnalysisUrlUrl(id){
		return self.analysisUrl.replace('_missionId', id);
	}

	function _appendDanRankList(aList){
		var aHtml = [];
		if(self.danRankPage == 1 && self.danRankPageSize < aList.length){
			self.danRankPageSize = aList.length;
		}
		for(var index in aList){
			var oTemp = aList[index];
			aHtml.push('<li>');
			oTemp.rank = ((self.danRankPage - 1) * self.danRankPageSize) + parseInt(index) + 1;
			if(oTemp.rank <= 3){
				aHtml.push('<span class="num"><i class="v3-no' + oTemp.rank + '"></i></span>');
			}else{
				aHtml.push('<span class="num">' + oTemp.rank + '</span>');
			}
			aHtml.push('<span class="info">');
			aHtml.push(Ui1.buildProfile({id : oTemp.id, profile: oTemp.profile}, true, {addClass : 'circle'}));
			aHtml.push('&nbsp;' + Ui1.buildVipName(oTemp, true));
			aHtml.push('</span>');
			var rankIconHtml = '';
			if(oTemp.avg_score_status == 1){
				rankIconHtml = '<i class="rankc v3-up"></i>';
			}else if(oTemp.avg_score_status == 2){
				rankIconHtml = '<i class="rankc v3-down"></i>';
			}
			aHtml.push('<span class="rank" title="' + oTemp.dan_name + '(' + oTemp.mission_avg_score + ')">' + oTemp.dan_name + '(' + oTemp.mission_avg_score + rankIconHtml + ')</span>');
			aHtml.push('</li>');
		}

		$('.dan-rank-list-pane ul').html(aHtml.join(''));
	}

	function _getCardsDetail(id){
		ajax({
			url : self.cardsDetailUrl,
			data : {id : id},
			success : function(aResult){
				if(aResult.status == 1){
					_appendCardsDetail(aResult.data);
					// 左右滑动
					jQuery("#cardSlide").slide({mainCell:".J-card-info-item", effect:"left", delayTime:500,vis:6,scroll:1,pnLoop:false, trigger:"click",easing:"easeOutCubic" ,titOnClassName:"active"});
					// jQuery("#cardSlide").slide({ mainCell:".J-card-info-item", effect:"left", delayTime:800,vis:6,scroll:5,pnLoop:false,trigger:"click",easing:"easeOutCubic" ,titOnClassName:"active"});
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error : function(){
				UBox.show('抱歉，系统错误！', 0);
			}
		});
	}

	function _appendCardsDetail(aData){
		var aHtml = [];

		for(var index in aData.card_list){
			var oTemp = aData.card_list[index];
			var liClass = '';
			if(oTemp.status == 0){
				aHtml.push('<li class="disabled" data-cardname="' + oTemp.name + '" data-cardintro="' + oTemp.introduction + '">');
			}else if(oTemp.status == 1){
				aHtml.push('<li data-cardname="' + oTemp.name + '" data-cardintro="' + oTemp.introduction + '">');
			}else if(oTemp.status == 2){
				aHtml.push('<li class="J-gray" data-cardname="' + oTemp.name + '" data-cardintro="' + oTemp.introduction + '">');
			}

			aHtml.push('<a href="javascript:;">');
			/*if(oTemp.status == 2){
				//aHtml.push('<img src="' + oTemp.image_gray + '" >');
				aHtml.push('<img src="' + oTemp.profile + '" >');
			}else{
				aHtml.push('<img src="' + oTemp.profile + '" >');
			}*/
			aHtml.push('<img src="' + oTemp.profile + '" >');
			aHtml.push('<i class="triangle-up"></i>');
			aHtml.push('</a>');
			aHtml.push('</li>');
		}

		$('.J-card-info-title').html(aData.title + '<a href="javascript:;" class="close v3-card-close" data-dismiss="modal" aria-hidden="true"></a>');
		$('.J-card-info-item').html(aHtml.join(''));
		var exchangeValue = parseInt(parseInt(aData.value) * parseFloat(aData.exchange_rate));
		var exchangeGoldTip = '';
		if(aData.has_dan == 1){
			exchangeGoldTip = '<span style="display:inline-block;background:#ff6600;-moz-border-radius: 5px;-webkit-border-radius: 5px;border-radius: 5px;font-size:16px;color:#ffffff;padding: 0 4px;line-height:29px;">' + aData.current_dan_name + '段位可兑换 ' + exchangeValue + '金币</span>';
		}
		aHtml = [];
		aHtml.push('<div class="img">');
		aHtml.push('<img src="' + aData.profile + '" id="introImg">');
		aHtml.push('</div>');
		aHtml.push('<div class="info">');
		aHtml.push('<div class="title">' + aData.title + '介绍<b class="text" style="color:#665734;">兑换价值' + aData.value + '金币</b>' + exchangeGoldTip + '<a class="tip" data-toggle="tooltip" data-original-title="' + aData.exchange_description + '">段位加成说明</a></div>');
		aHtml.push('<p class="description">' + aData.description + '</p>');
		aHtml.push('<div class="opts">');
		//aHtml.push('<div class="intro">' + aData.introduction + '</div>');
		if(aData.is_exchangable == 1){
			aHtml.push('<div class="J-exchange-tips info success active" style="display:none;" gold="' + aData.value + '" exchange_gold="' + exchangeValue + '">兑换本套卡牌您将获得' + exchangeValue + '金币收入，同时本套卡牌也将被回收，是否确定兑换？</div>');
			aHtml.push('<a href="javascript:;" class="dh v3-card-btn" onclick="MissionHome.comfirmExchangeCard(this, ' + aData.id + ');">立刻兑换</a>');
		}else{
			aHtml.push('<a href="javascript:;" class="dh v3-card-btn disabled">立刻兑换</a>');
			aHtml.push('<b class="text">已集齐' + aData.user_card_count + '张，再集齐剩余' + (parseInt(aData.card_count) - parseInt(aData.user_card_count)) + '张即可兑换！</b>');
		}

		aHtml.push('</div>');
		aHtml.push('<a href="javascript:;" class="back" id="cardBack">返回</a>');
		aHtml.push('</div>');
		$('.J-card-info-description').html(aHtml.join(''));
		$('.J-card-info-item').css({left:0});
		self.cardSelect();

		_modalVerticalCenter("#cardSlide");

		_tooltip();


	}

	function _checkIsGettingMissionList(){
		if(self.isGetMissionListAjaxIng){
			UBox.show('操作过于频繁，请稍后再试！', -1);
			return true;
		}

		return false;
	}

	function _checkIsGettingDanList(){
		if(self.isGetDanAjaxIng){
			UBox.show('操作过于频繁，请稍后再试！', -1);
			return true;
		}

		return false;
	}

	function _afterGettingDanRankList(aData){
		if(aData.length > 0){
			_appendDanRankList(aData);
			if(self.danRankPage != 1){
				$('.J-prev-dan-btn').addClass('active');
			}else{
				$('.J-prev-dan-btn').removeClass('active');
			}
			$('.J-next-dan-btn').addClass('active');
		}else{
			if(self.danRankPage != 1){
				self.danRankPage -= 1;
			}else{
				$('.dan-rank-list-pane ul').html('<div class="emptydata" id="emptydata">你还没有好友参与段位排行！</div>');
			}
			if(self.danRankType == 0){
				self.danWorldMaxPage = self.danRankPage;
			}else{
				self.danFriendMaxPage = self.danRankPage;
			}
			if(self.danRankPage != 1){
				$('.J-prev-dan-btn').addClass('active');
			}else{
				$('.J-prev-dan-btn').removeClass('active');
			}
			$('.J-next-dan-btn').removeClass('active');
		}
		if(self.danRankType == 0){
			$('.J-world-rank a').removeAttr('onclick');
			$('.J-friend-rank a').attr('onclick', 'MissionHome.showDanRankList(1);');
		}else{
			$('.J-friend-rank a').removeAttr('onclick');
			$('.J-world-rank a').attr('onclick', 'MissionHome.showDanRankList(0);');
		}
	}

	function _getLastMissionId(){
		var aMissionListStatus = self._getMissionListStatusCookie();
		if(!aMissionListStatus){
			return 0;
		}

		return aMissionListStatus[4];
	}



	//MissionHome.gradeSelect();
	//MissionHome.cardSelect();

	// global.js
	var self = win.MissionHome;
	$(function(){
		$('#slideCard').jScrollPane();
	})



})(jQuery, window);
