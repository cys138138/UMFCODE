(function ($, win) {
	win.MatchPractic = {
		EVENT_ON_TIME_OVER : 1,
		config: function (aOptions) {
			if (aOptions.url) {
				for (var key in _aUrl) {
					if (aOptions.url[key] != undefined) {
						_aUrl[key] = aOptions.url[key];
					}
				}
			}
			if (aOptions.defaultData) {
				for (var i in _defaultData) {
					if (aOptions.defaultData[i] != undefined) {
						_defaultData[i] = aOptions.defaultData[i];
					}
				}
			}
		},
		show: function () {
			//构建基本骨架
			_buildContainerHtml();
			_getInitData();
			_bindEvent();
			//比赛时长
			_remainSeconds = _defaultData.aMatchInfo.duration;
			_setRemainingProcessEsCount(_defaultData.aMatchInfo.remainder_es_nums);
		},

		showResult : function(aData){
			aData = $.extend({
				score : 75,
				use_time : '200秒',
				correct_percent : 70,
				best_score : 84,
				rank : 3,
				best_rank : 13
			}, aData);

			_setRemainingProcessEsCount(0);
			_$matchPractic.find('.J-practic').addClass('disabled').html('比赛完成').data('status', false);
			_timeReducePause();
			App.oCurrentStudent.updateInfo();
			_$completeMatchDailog.empty().append(_buildDialogHtml(aData));

			//增加关卡推荐=>20150723
			ajax({
				url: _aUrl.wrongMissionListUrl,
				data: {match_id: _defaultData.aMatchInfo.id},
				success: function(data){
					var aData = data['data'];
					var len = aData.length;
					if(len == 0){return;}

					var itemNum = 3, outerWidth = 420, outerHeight = 140;
					var pageNum = Math.ceil(len / itemNum);    //页数
					var itemHtml = '', $match = '', $page = '';
					var $module = Ui1.buildScrollPageModule();
					$module.addClass('scroll-module');
					$module.css('width', outerWidth + 'px');
					$module.css('height', outerHeight + 'px');
					var $container = $module.getContainer();	//获取内部容器
					for(var i=0; i<len; ++i){
						itemHtml = '<a class="mission-item"><div><div>' + aData[i]['subject_name'] + '</div><div>' + aData[i]['grade_name'] + '</div><div>' + aData[i]['name'] + '</div></div><div><span>去修炼</span></div></a>';
						$match = $(itemHtml);
						$match.attr('href', _aUrl.practiceUrl.replace('id', aData[i]['id']));

						if(i % itemNum == 0){     //每8个分成一页
						    $page = $('<div class="mission-item-page"></div>');
						    $page.css('width', outerWidth + 'px');
						    $container.append($page);
						}
						$page.append($match);
					}
					$container.css('width',  pageNum * outerWidth + 'px');
					var $extend = $('<div class="um-recommend-mission"><hr/><div class="title">强化修炼</div><div class="desc">根据你本场比赛的答题情况，推荐去以下关卡进行修炼</div></div>');
					$extend.append($module);
					_$completeMatchDailog.find('#matchComplete').append($extend);
					$module.updateNum();		//更新页面标识（容器添加子节点之后）

					//切换页面按钮特殊修改
					var $handle = $extend.find('.J-module-scroll-page-handle');
					$handle.css('border-color', 'rgba(0, 0, 0, 0)');
					$handle.eq(0).css('margin-left', '-50px');
					$handle.eq(1).css('margin-right', '-50px');
					$extend.find('.J-module-scroll-page-handle > .J-arrow').css('border-color', 'black');
				}
			});
		}
	};

	var self = win.MatchPractic;
	$.extend(self, new Component());

	var _aUrl = {
		getEsContentUrl: '',
		commitAnswerUrl: '',
		getRecentEntryListUrl: '',
		getMatchRankingListUrl: '',
		drawGoldUrl: '',
		matchIndexUrl: '',
		continueMatchUrl: '',
		matchDetailUrl: '',
		autoSubmitUrl: '',
		wrongMissionListUrl: '',
		practiceUrl: ''
	};

	var _defaultData = {
		ts: 0,
		aMatchInfo: '',
		aEsTypeList : ''
	};
	var _$matchPractic = $('.J-mainDiv'), _$completeMatchDailog = $('.J-completeMatchDailog'), _$es = null, _remainSeconds = 0, _timeReduceTimer = null, _aMatchRankList = [],_isUsingSgnj = false;

	//开始比赛
	function _startMatch(){
		_timeReduceStart();
		_getEsData();
		_bindPropEvent();
	}

	function _bindPropEvent() {
		if(!App.oCurrentStudent.is_yh_user){
			//生成道具条
			Prop.getPropBar(Prop.SCENE_MATCH_PLAYING, function ($propBar) {
				_$matchPractic.find('.J-propBar').empty().append($propBar);
			}, _defaultData.aMatchInfo.id);
		}else{
			_$matchPractic.find('.J-propBar').remove();
		}
		_bindSGNJEvent();
	}

	/**
	 * 时光凝结事件使用的事件绑定处理
	 */
	function _bindSGNJEvent() {
		//时光凝结使用条件检查
		Prop.bindEvent(Prop.EVENT_BEFORE_USE_SGNJ, function (oEvent) {
			var isOk = true;
			if (_remainSeconds < 1) {
				UBox.show('已经没时间啦', -1);
				isOk = false;
			}
			oEvent.xListenerData.isOk = isOk;
		});
		//实现使用时光凝结
		Prop.bindEvent(Prop.EVENT_USE_SGNJ, function (oEvent) {
			if (_isUsingSgnj) {
				UBox.show('你已经正在使用时光凝结了，不要重复使用哦！', -1);
				return;
			}
			_isUsingSgnj = true;
			//暂停
			_timeReducePause();
			UBox.show('时间已经停止，加紧做题哦！', 1);
		});

		//实现使用时光凝结
		Prop.bindEvent(Prop.EVENT_SGNJ_TIME_OVER, function (oEvent) {
			_isUsingSgnj = false;
			_timeReduceStart();
			UBox.show('时光凝结已经失效，加紧做题哦！', 1);
		});
	}

	/**
	 * 加载完骨架之后获取数据
	 */
	function _getInitData() {
		if (_defaultData.aMatchInfo.isFinishFirst) {
			_getMatchRankingList();
		} else {
			_getRecentEntryList();
		}
	}

	function _getEsData() {
		ajax({
			url: _aUrl.getEsContentUrl,
			data: {match_id: _defaultData.aMatchInfo.id},
			success: function (aResult) {
				_showQuestion(aResult.data.aEsContent);
				_$matchPractic.find('.J-practic').show();
			}
		});
	}

	/**
	 * 获取最近参数的人列表
	 */
	function _getRecentEntryList(page) {
		if (page == undefined) {
			page = 1;
		}
		ajax({
			url: _aUrl.getRecentEntryListUrl,
			data: {
				page_size: 9,
				page: page,
				match_id: _defaultData.aMatchInfo.id
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					var aNearestJoinMatchUserList = aResult.data.aNearestJoinMatchUserList;
					_appendRecentEntryListHtml(aNearestJoinMatchUserList);
				}
			}
		});
	}

	/**
	 * 填充最近参赛记录
	 */
	function _appendRecentEntryListHtml(aRecentEntryList) {
		var matchRecentEntryListHtml = _buildRecentEntryList(aRecentEntryList);
		_$matchPractic.find('.J-recentEntryRecordList').html(matchRecentEntryListHtml);
	}



	/**
	 * 时间剩余和时间进度
	 * @param {type} strTime 剩余时间
	 */
	function _setRemainingProcess(strTime) {
		var totalTime = _defaultData.aMatchInfo.duration;
		var proce = (_remainSeconds / totalTime) * 100;
		_$matchPractic.find('.J-processTime').css({'width': '' + proce + '%'});
		_$matchPractic.find('.J-RemaininTime').html(strTime);
	}

	function _setRemainingProcessEsCount(remainEscount) {
		var totalEsCount = _defaultData.aMatchInfo.remainder_es_nums;
		var proce = (((totalEsCount - remainEscount) / totalEsCount) * 100);
		_$matchPractic.find('.J-processEsCount').css({'width': '' + proce + '%'});
		_$matchPractic.find('.J-RemaininNums').html(remainEscount);
	}

	function _setfirstData(){
		_$matchPractic.find('.J-RemaininTime').html(Ui1.date('i:s', _defaultData.aMatchInfo.duration));
		_$matchPractic.find('.J-processTime').css({'width': '100%'});
		_$matchPractic.find('.J-espPlug').empty().append('<p><h3 style="text-align: center; padding-top:100px;">你准备好了吗?</h3></p>');
	}

	/**
	 * 为页面绑定事件
	 */
	function _bindEvent() {
		//判断是否显示准备战斗
		if(_defaultData.aMatchInfo.isShowStartPage){
			_setfirstData();
		}else{
			_$matchPractic.find('.J-startPractic').remove();
			_$matchPractic.find('.J-espPlug').empty().append('<p>数据加载中..</p>');
			_startMatch();
		}

		_$matchPractic.find('.J-startPractic').click(function(){
			$(this).remove();
			_$matchPractic.find('.J-espPlug').empty().append('<p>数据加载中..</p>');
			_startMatch();
			_$matchPractic.find('.J-practic').show();
		});
		_$matchPractic.find('.J-practic').click(function () {
			var $this = $(this);
			if (!$this.data('status')) {
				return;
			}
			var xAnswer = _$es.buildAnswer();
			if (_$es.isEmptyAnswer(xAnswer)) {
				UBox.show('请先作答', -1);
				return;
			}
			var aPostData = {
				match_id: _defaultData.aMatchInfo.id,
				ts: _defaultData.ts,
				user_answer: {
					answer: xAnswer
				}
			};
			ajax({
				url: _aUrl.commitAnswerUrl,
				data: aPostData,
				beforeSend: function () {
					_$matchPractic.find('.J-practic').addClass('disabled').html('正在出招..').data('status', false);
				},
				success: function (aResult) {
					if (aResult.status == 1) {
						_defaultData.ts = aResult.data.ts;
						_showQuestion(aResult.data);
						var $reEsCount = _$matchPractic.find('.J-RemaininNums');
						//设置比赛剩余提示状态
						_setRemainingProcessEsCount(parseInt($reEsCount.html()) - 1);
						_$matchPractic.find('.J-practic').removeClass('disabled').html('出招').data('status', true);

					} else if (aResult.status == 2) {
						self.showResult(aResult.data);
						/*
						_setRemainingProcessEsCount(0);
						_$matchPractic.find('.J-practic').addClass('disabled').html('比赛完成').data('status', false);
						_timeReducePause();
						App.oCurrentStudent.updateInfo();
						_$completeMatchDailog.empty().append(_buildDialogHtml(aResult.data));
						*/
					}
					scroll(0, 0);
				},
				error: function () {
					_$matchPractic.find('.J-practic').removeClass('disabled').html('出招').data('status', true);
					_$matchPractic.find('.J-commitFail').show();
				}
			});
		});

		_$matchPractic.on('click', '.J-matchRankingPage a', function () {
			var $this = $(this);
			var option = $this.hasClass('J-MatchRankingPre');
			var page = $this.closest('.J-matchRankingPage').data('page');
			if (!$this.data('status')) {
				return;
			}
			//点击上一页
			if (option) {
				//第一页
				if (page == 1) {
					$this.removeClass('active').data('status', false);
					return;
				}
				page = (page - 1);
			} else {
				page = (page + 1);
			}
			_$matchPractic.find('.J-matchRankingPage a').addClass('active');
			if (page < 1) {
				page = 1;
			}
			//数据缓存
			if (_aMatchRankList[page] !== undefined) {
				_appendMatchRankingListHtml(_aMatchRankList[page], page);
				return;
			}
			_getMatchRankingList(page, $this);
		});

		_$completeMatchDailog.on('click', '.J-receiveGold', function () {
			var $this = $(this);
			ajax({
				url: _aUrl.drawGoldUrl,
				data: {
					match_id: _defaultData.aMatchInfo.id
				},
				success: function (aResult) {
					if (aResult.status == 1) {
						$this.remove();
						if(aResult.data == 0){
							_$completeMatchDailog.find('.J-tipsGoldMsg').show().html('很遗憾没有抽到金币');
						}else{
							_$completeMatchDailog.find('.J-tipsGoldMsg').show().html('恭喜得到<em>' + aResult.data + '</em>金币');
						}
						_$completeMatchDailog.find('.J-againDiv').show();
						_$completeMatchDailog.find('.J-drawTips').hide();
					} else {
						_$completeMatchDailog.find('.J-tipsGoldMsg').show().html(aResult.msg);
					}
				}
			});
		});

		self.bindEvent(self.EVENT_ON_TIME_OVER, function(){
			_$completeMatchDailog.empty().append(_buildDialogGameOverHtml());
			_timeReducePause();
			if(App.oCurrentStudent.is_yh_user){
				ajax({
					url : _aUrl.autoSubmitUrl,
					data : {
						id : _defaultData.aMatchInfo.id
					},
					success : function(aResult){
						if(aResult.status == 1){
							self.showResult(aResult.data);
						}
					}
				});
			}
		});
	}

	function _showQuestion(aEs) {
		_$es = Esp.buildQuestion(aEs);
		var esInfo = '<div class="tag-warp">\
			<span class="tag" style="border: 1px solid #019934;">' + _defaultData.aEsTypeList[aEs.type_id] + '</span>\
		</div>';
		_$matchPractic.find('.J-esInfo').html(esInfo);
		_$matchPractic.find('.J-espPlug').empty().append(_$es);
	}

	/**
	 * 获取详情介绍数据
	 */
	function _getMatchRecordRankList() {
		_appendMatchRecordRankListHtml([]);
	}

	/**
	 * 填充比赛详情介绍数据
	 */
	function _appendMatchRecordRankListHtml(aMatchRecordRankList) {
		var matchRecordRankListHtml = _buildRecordRankList(aMatchRecordRankList);
		_$matchPractic.find('.J-recordRank').html(matchRecordRankListHtml);

	}

	function _buildContainerHtml() {
		var aContainerHtml = [];
		//主体html
		aContainerHtml.push('<div class="um-container">\
		<div class="contain">\
			<div class="um-layout-2">');
		//内容
		aContainerHtml.push(_buildEsTitleHtml());
		aContainerHtml.push(_buildEsMainHtml());
		aContainerHtml.push(_buildSideHtml());
		aContainerHtml.push('</div>\
		</div></div>');
		_$matchPractic.html(aContainerHtml.join(''));
	}

	function _buildEsTitleHtml() {
		return '<div class="title-bar match" style="height:60px;">\
			<!-- module -->\
			<div class="um-manswer-header" style="padding-top:10px;">\
				<div class="title">\
					<span title="">' + _defaultData.aMatchInfo.title + '</span>\
				</div>\
				<div class="nav">\
					<ul class="list-unstyled">\
						<li class="back"><a href="' + _aUrl.matchIndexUrl + '">返回比赛</a></li>\
					</ul>\
				</div>\
			</div>\
			<!-- end module -->\
		</div>';
	}

	function _buildEsMainHtml() {
		return '<div class="main">\
				<div class="modm um-manswer-tag J-esInfo">\
				</div>\
				<!-- module -->\
				<div class="modm um-esplug J-espPlug">\
					加载中\
				</div>\
				<!-- end module -->\
				<!-- module -->\
				<!-- 道具条 -->\
				<div class="modm um-mpropbar J-propBar">\
				</div>\
				<!-- end module -->\
				<!-- module -->\
				<!-- 出招模块 -->\
				<div class="modm um-manswer-feedback">\
					<div class="submit">\
						<a href="javascript:void(0)" class="um-btn um-btn-success  um-btn-xlg J-practic" data-status="true" style="display:none;">出招</a>\
						<a href="javascript:void(0)" class="um-btn um-btn-success  um-btn-xlg J-startPractic" data-status="true">开始战斗</a>\
					</div>\
					<span class="tip J-commitFail" style="display:none;">出招失败，请重新尝试!</span>\
				</div>\
				<!-- end module -->\
			</div>';
	}

	function _buildDialogHtml(aData) {
		var aBtnHtml = '<a href="javascript:void(0)" class="um-btn um-btn-success um-btn-xlg J-receiveGold">领取金币</a>',
			congratulationHtml = '<p class="J-drawTips">恭喜完成比赛，可以领取金币哦！</p>';

		if(!_defaultData.aMatchInfo.isFinishCanDraw || App.oCurrentStudent.is_yh_user){
			aBtnHtml = '<a href="' + _aUrl.matchDetailUrl + '" class="um-btn um-btn-success um-btn-xlg">查看比赛排名</a>';
			congratulationHtml = '';
		}

		return '<div class="modal  fade common-modal in" id="matchComplete" aria-hidden="false" style="display: block;">\
			<!-- success perfect fail -->\
			<div class="um-mcommon match-common match-complete">\
				<div class="hd">\
					完成比赛\
				</div>\
				<div class="bd">\
					<div class="prize">\
						<div class="fl" style="width:200px;">\
							<p>\
								<span>比赛得分</span>\
								<span><em style="font-size:2.8em;">' + aData.score + '</em></span>\
							</p>\
							<p>\
								<span>正 确 率</span>\
								<span><em>' + aData.correct_percent + '%</em></span>\
							</p>\
							<p>\
								<span>使用时间</span>\
								<span><em>' + aData.use_time + '</em></span>\
							</p>\
							<p>\
								<span>最佳记录</span>\
								<span><em>' + aData.best_score + '</em></span>\
							</p>\
							<!--<p>\
								<span>本次排名</span>\
								<span><em>' + aData.rank + '</em></span>\
							</p>-->\
						</div>\
						<div class="fl">\
							<!--<p>\
								<span>最佳记录</span>\
								<span><em>' + aData.best_score + '</em></span>\
							</p>-->\
							<!--<p>\
								<span>最佳排名</span>\
								<span><em>' + aData.best_rank + '</em></span>\
							</p>-->\
						</div>\
					</div>\
					' + congratulationHtml + '\
					<div class="gx J-tipsGoldMsg" style="display:none;"></div>\
				</div>\
				<div class="ft">\
					<div class="opts">\
						' + aBtnHtml + '\
					</div>\
					<div class="opts J-againDiv" style="display:none;">\
						<!--<a href="' + _aUrl.matchDetailUrl + '" class="um-btn um-btn-success um-btn-xlg">再次参赛</a>\
						<a href="' + _aUrl.matchIndexUrl + '" class="um-btn um-btn-success um-btn-xlg">全部比赛</a>-->\
						<a href="' + _aUrl.matchDetailUrl + '" class="um-btn um-btn-success um-btn-xlg">查看比赛排名</a>\
					</div>\
				</div>\
			</div>\
		</div><div class="modal-backdrop fade in"></div>';
	}

	/**
	 * 左侧
	 */
	function _buildSideHtml() {
		var aSideHtml = [];
		aSideHtml.push('<div class="side">');
		aSideHtml.push(_buildStatusHtml());
		aSideHtml.push(_buildMyRecordHtml());
		if (_defaultData.aMatchInfo.isFinishFirst) {
			aSideHtml.push(_buildRecordRankHtml());
		} else {
			aSideHtml.push(_buildRecordRankListHtml());
		}

		aSideHtml.push('</div>');
		return aSideHtml.join('');
	}

	function _buildStatusHtml() {
		return '<div class="mods um-mchallenge-process match">\
			<div class="hd">倒数时间</div>\
			<div class="bd">\
				<div class="process-bar">\
					<div class="process J-processTime"></div>\
					<div class="percent J-RemaininTime">00:00</div>\
				</div>\
			</div>\
			<div class="hd">题目数量</div>\
			<div class="bd">\
				<div class="process-bar">\
					<div class="process J-processEsCount"></div>\
					<div class="percent">剩余<span class="J-RemaininNums">0</span>题</div>\
				</div>\
			</div>\
		</div>';
	}

	/**
	 * 我的战绩
	 */
	function _buildMyRecordHtml() {
		var ranking = '<span class="num">' + _defaultData.aMatchInfo.ranking + '</span>';
		var core =  _defaultData.aMatchInfo.bestScore;
		//是否有完成过
		if(!_defaultData.aMatchInfo.isFinishFirst){
			ranking = '';
			core = '比赛中..';
		}
		return '<div class="mods um-matchrank match open">\
			<div class="hd">\
				<h2 class="title">我的战绩</h2>\
			 </div>\
			 <div class="bd">\
				<div class="rank-list">\
					<ul class="list-unstyled">\
						<li class="active">\
							' + ranking + Ui1.buildProfile(_defaultData.aMatchInfo.user_info) + '\
							' + Ui1.buildVipName(_defaultData.aMatchInfo.user_info) + '\
							<span class="score">\
								成绩:<em>' + core + '</em>\
							</span>\
						</li>\
					</ul>\
				</div>\
			 </div>\
		 </div>';
	}


	//最近参赛记录列表
	function _buildRecentEntryList(aRecentEntryList) {
		var aDataList = aRecentEntryList;
		var aLiListHtml = [];
		if (aDataList.length == 0) {
			return '<li class="nodata">\
				还没有人参加呢...\
			</li>';
		}
		for (var i in aDataList) {
			aLiListHtml.push('<li class="active">\
					' + Ui1.buildProfile(aDataList[i].user_info) + '\
					' + Ui1.buildVipName(aDataList[i].user_info) + '\
				<span class="score">\
					<em>' + aDataList[i].best_score + '</em>\
				</span>\
			</li>');
		}
		return aLiListHtml.join('');
	}

	/**
	 * 战绩榜
	 */
	function _buildRecordRankHtml() {
		return '<div class="mods um-matchrank open">\
					<div class="hd">\
						<h2 class="title">战绩榜</h2>\
					 </div>\
					 <div class="bd">\
						<div class="rank-list">\
							<ul class="list-unstyled J-recentEntryRecordList" >\
							<li class="nodata">\
								正在加载...\
							</li>\
						</ul>\
						</div>\
					</div>\
					<div class="ft">\
					<div class="opts J-matchRankingPage" data-page="1">\
						<a href="javascript:void(0)" class="J-prev-dan-btn um-btn-ghost um-btn-default um-btn-xs J-MatchRankingPre" >上一页</a>\
						<a href="javascript:void(0)" class="J-next-dan-btn um-btn-ghost um-btn-default um-btn-xs active J-MatchRankingnext" data-status="true" >\下一页</a>\
					</div>\
			 </div>\
				</div>';
	}

	/**
	 * 最近参赛记录
	 */
	function _buildRecordRankListHtml() {
		return '<div class="mods um-matchrank">\
				<div class="hd">\
					<h2 class="title">最近参赛的人</h2>\
				 </div>\
				 <div class="bd">\
					<div class="rank-list">\
						<ul class="list-unstyled J-recentEntryRecordList"><li class="nodata">\
						正在加载...\
					</li>\</ul>\
					</div>\
				</div>\
			</div>';
	}

	/**
	 * 获取战绩榜
	 */
	function _getMatchRankingList(page, $this) {
		if (page == undefined) {
			page = 1;
		}
		ajax({
			beforeSend: function () {
				if ($this !== undefined) {
					$this.data('status', false);
				}
			},
			url: _aUrl.getMatchRankingListUrl,
			data: {
				page: page,
				match_id: _defaultData.aMatchInfo.id,
			},
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMatchRanking = aResult.data.aMatchRanking;
					var ranking = aResult.data.ranking;
					if (ranking == 0) {
						_$matchPractic.find('.J-myRanking').hide();
					} else {
						_$matchPractic.find('.J-myRanking').show();
						_$matchPractic.find('.J-myRanking>em').html(ranking);
					}
					//第一页就没数据
					if (aMatchRanking.length == 0 && page == 1) {
						_$matchPractic.find('.J-matchRankingPage').hide();
						_$matchPractic.find('.J-recentEntryRecordList').html('<li class="nodata">暂无数据..</li>');
						return;
					}
					//数据缓存
					_aMatchRankList[page] = aMatchRanking;
					_appendMatchRankingListHtml(aMatchRanking, page);
				}
			}
		});
	}

	/**
	 * 填充排行榜记录
	 */
	function _appendMatchRankingListHtml(aRecentEntryList, page) {

		//最后一页没数据
		if ((page > 1) && (aRecentEntryList.length == 0)) {
			_$matchPractic.find('.J-matchRankingPage a').data('status', true).addClass('active');
			_$matchPractic.find('.J-MatchRankingnext').removeClass('active').data('status', false);
			_$matchPractic.find('.J-recentEntryRecordList').html('<li class="nodata">没有数据啦</li>');
			_$matchPractic.find('.J-matchRankingPage').data('page', page);
			return;
			//处理非最后一页让按钮可点击
		} else {
			_$matchPractic.find('.J-matchRankingPage a').data('status', true);
		}
		if (page == 1) {
			_$matchPractic.find('.J-MatchRankingPre').removeClass('active').data('status', false);
		}
		_$matchPractic.find('.J-matchRankingPage').data('page', page);

		var listHtml = _buildMatchRankingList(aRecentEntryList);
		_$matchPractic.find('.J-recentEntryRecordList').html(listHtml);
	}

	//比赛排行榜
	function _buildMatchRankingList(aMatchRankingList) {
		var aDataList = aMatchRankingList;
		if (aDataList.length == 0) {
			return '<li class="nodata">暂无数据..</li>';
		}
		var aLiListHtml = [];
		for (var i in aDataList) {
			var status = 'active';
			if (aDataList[i].ranking > 3) {
				status = '';
			}
			if (i == aDataList.length) {
				status = 'last';
			}
			aLiListHtml.push('<li class="' + status + '" title="第' + aDataList[i].ranking + '名">\
					<span class="num">' + aDataList[i].ranking + '</span>' + Ui1.buildProfile(aDataList[i].user_info) + '' + Ui1.buildVipName(aDataList[i].user_info) + '\
					<span class="score" style="width:85px;">成绩:\
						<em>' + aDataList[i].best_score + '</em>\
					</span>\
				</li>');

		}
		return aLiListHtml.join('');
	}


	/**
	 * 开始倒计时
	 */
	function _timeReduceStart() {
		_timeReduceTimer = setInterval(function () {
			_remainSeconds--;
			var timeStr = Ui1.date('i:s', _remainSeconds);
			if (timeStr.indexOf('NaN') != -1) {
				window.oLog && oLog.add([_remainSeconds, timeStr], '时间解析出错');
				$.error('时间解析出错');
			}
			_setRemainingProcess(timeStr);
			//时间耗尽
			if (_remainSeconds == 0) {
				self.triggerEvent(self.EVENT_ON_TIME_OVER);
			}
		}, 1000);
	}

	/**
	 * 暂停倒计时
	 */
	function _timeReducePause() {
		//取消获得句柄
		_timeReduceTimer = clearInterval(_timeReduceTimer);
	}

	function _buildDialogGameOverHtml() {
		var rejoinHtml = '<div class="ft">\
			<div class="opts">\
				<a href="javascript:;" class="um-btn um-btn-success um-btn-xlg">正在交卷...</a>\
			</div>\
		</div>';

		if(!App.oCurrentStudent.is_yh_user){
			rejoinHtml = '<div class="ft">\
				<div class="opts">\
					<a href="' + _aUrl.matchDetailUrl + '" class="um-btn um-btn-success um-btn-xlg">再次参赛</a>\
				</div>\
			</div>';
		}
		return '<div class="modal  fade common-modal in" id="matchComplete" aria-hidden="false" style="display: block;">\
			<!-- success perfect fail -->\
			<div class="um-mcommon match-common match-complete">\
				<div class="hd">\
					比赛结束\
				</div>\
				<div class="bd">\
					<div class="prize">\
						<div class="fl">\
						</div>\
					</div>\
					<div class="gx">比赛时间用尽，比赛结束。</div>\
				</div>\
				' + rejoinHtml + '\
			</div>\
		</div><div class="modal-backdrop fade in"></div>';
	}

})(jQuery, window);
