(function ($, win) {
	win.PageMatchStar = {
		$wrapper : null,
		matchList : '',
		starInfo : '',
		menuLobby : '',
		menuMine : '',
		oneToThreeGroupId : '',
		fourToSixGroupId : '',
		sevenToNineGroupId : '',

		show: function () {
			_buildContainerHtml();	//构建基本骨架
			_getMatchCategoryList();	//读取比赛列表
			_bindEvent();	//初始化事件
		},

		loadStarInfo : function(matchId){
			var $match = self.$wrapper.find('.J-match[itemid="' + matchId + '"]');
			var aStarInfo = $match.data('star_info');	//缓存
			if(aStarInfo){
				_renderStarInfo(aStarInfo);
				return;
			}

			ajax({
				url : self.starInfo,
				data : {
					id : matchId
				},
				success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					$match.data('star_info', aResult.data.aStarInfo);
					_renderStarInfo(aResult.data.aStarInfo);
				}
			});
		}
	};

	/**
	 * 为页面绑定事件
	 */
	function _bindEvent() {
		// self.$wrapper.find(".J-txtScroll-left").slide({titCell: ".hd ul", mainCell: ".bd ul", autoPage: true, effect: "left", scroll: 1, vis: 3, trigger: "click"});
		// 切换
		self.$wrapper.find('.slideTxtBox').slide({titOnClassName: "active"});

		self.$wrapper.on('click', '.J-match', function(){
			//点击比赛加载得奖者信息
			self.loadStarInfo($(this).attr('itemid'));
		});

		self.$wrapper.on('mouseover', '.J-winnerProfile', function(){
			//头像划过
			var $item = $(this).closest('.J-winner');
			$item.addClass('active').siblings().removeClass('active');
			self.$wrapper.find('.J-winnerTestimonials[itemid="' + $item.attr('itemid') + '"]').show().siblings().hide();
		});
	}

	/**
	 * 获取详情介绍数据
	 */
	function _getMatchCategoryList() {
		ajax({
			url : self.matchList,
			success : function(aResult){
				if(aResult.status != 1){
					UBox.show(aResult.msg, aResult.status);
					return;
				}
				_appendMatchCategoryListHtml(aResult.data.aBigMatchList);
				self.$wrapper.find('.J-match:first').click();
			}
		});
	}

	/**
	 * 填充比赛详情介绍数据
	 */
	function _appendMatchCategoryListHtml(aMatchList) {
		var matchCategoryListHtml = _buildStarCateHtml(aMatchList);
		self.$wrapper.find('.J-matchCateList').css('width', aMatchList.length * 273 + 'px').html(matchCategoryListHtml);
		self.$wrapper.find(".J-txtScroll-left").slide({titCell: ".hd ul", mainCell: ".bd ul", autoPage: true, effect: "left", scroll: 1, vis: 3, trigger: "click"});
	}

	/**
	 * 填充一到三年级明星排行
	 */
	function _appendMatchStarOneToThreeListHtml(aMatchStarOneToThreeList) {
		var matchStarOneToThreeListHtml = '<div class="hd">\
			<ul class="list-unstyled">' + _buildWinnersList(aMatchStarOneToThreeList) + '</ul>\
		</div>\
		<div class="bd">' + _buildWinnersSayList(aMatchStarOneToThreeList) + '</div>';
		self.$wrapper.find('.J-starOneToThree').html(matchStarOneToThreeListHtml);
		self.$wrapper.find('.J-starOneToThree .J-order1').trigger('mouseover');
	}

	/**
	 * 填充4到6年级明星排行
	 */
	function _appendMatchStarFourToSixListHtml(aMatchStarFourToSixList) {
		var matchStarFourToSixListHtml = '<div class="hd">\
			<ul class="list-unstyled">' + _buildWinnersList(aMatchStarFourToSixList) + '</ul>\
		</div>\
		<div class="bd">' + _buildWinnersSayList(aMatchStarFourToSixList) + '</div>';
		self.$wrapper.find('.J-starFourToSix').html(matchStarFourToSixListHtml);
		self.$wrapper.find('.J-starFourToSix .J-order1').trigger('mouseover');
	}

	/**
	 * 填充7到9年级明星排行
	 */
	function _appendMatchStarSevenToNineListHtml(aMatchStarSevenToNineList) {
		var matchStarSevenToNineListHtml = '<div class="hd">\
			<ul class="list-unstyled">' + _buildWinnersList(aMatchStarSevenToNineList) + '</ul>\
		</div>\
		<div class="bd">' + _buildWinnersSayList(aMatchStarSevenToNineList) + '</div>';
		self.$wrapper.find('.J-starSevenToNine').html(matchStarSevenToNineListHtml);
		self.$wrapper.find('.J-starSevenToNine .J-order1').trigger('mouseover');
	}

	function _buildContainerHtml() {
		var aContainerHtml = [];
		//主体html
		aContainerHtml.push('<div class="um-layout-full">\
			<div class="main">\
				<div class="home-mods match-main">\
					<div class="contain">\
						<div class="match-nav">\
							<a href="' + self.menuLobby + '">全部比赛</a>\
							<a href="javascript:;" class="active">比赛之星</a>\
							<a href="' + self.menuMine + '">我的比赛</a>\
						</div>\
					</div>\
				</div>\
			</div>\
		</div>');
		aContainerHtml.push('<div class="contain">\
		<div class="match-star-cont">');
		//分类
		aContainerHtml.push(_buildMatchCategoryHtml());
		aContainerHtml.push(_buildOneToThreeHtml());
		aContainerHtml.push(_buildFourToSixHtml());
		aContainerHtml.push(_buildSevenToNineHtml());
		aContainerHtml.push('</div></div>');

		self.$wrapper.html(aContainerHtml.join(''));
	}

	function _buildMatchCategoryHtml() {
		return '<div class="match-star-nav">\
			<div class="txtScroll-left J-txtScroll-left">\
				<div class="hd">\
					<a class="prev"></a>\
					<a class="next"></a>\
				</div>\
				<div class="bd">\
					<div class="wrap">\
						<div class="tempWrap" style="overflow:hidden; position:relative; width:819px">\
							<ul class="list-unstyled infoList J-matchCateList" style="width: 1638px; left: 0px; position: relative; overflow: hidden; padding: 0px; margin: 0px;"></ul>\
						</div>\
					</div>\
					\
				</div>\
			</div>\
		</div>';
	}

	function _buildStarCateHtml(aMatchList) {
		var aLiListHtml = [];
		for (var i in aMatchList) {
			var aMatch = aMatchList[i];
			aLiListHtml.push('<li style="float: left; width: 243px;"><a href="javascript:;" class="J-match" itemid="' + aMatch.id + '">' + aMatch.name + '</a></li>');
		}
		return aLiListHtml.join('');
	}

	function _buildOneToThreeHtml() {
		return '<div class="match-star-p match-star-1">\
			<div class="slideTxtBox J-starOneToThree">\
			</div>\
		</div>';
	}

	function _buildFourToSixHtml() {
		return '<div class="match-star-p match-star-2">\
				<div class="slideTxtBox J-starFourToSix"></div>\
			</div>';
	}

	function _buildSevenToNineHtml() {
		return '<div class="match-star-p match-star-3">\
			<div class="slideTxtBox J-starSevenToNine"></div>\
		</div>';
	}

	function _renderStarInfo(aStarInfo){
		_appendMatchStarOneToThreeListHtml(aStarInfo[self.oneToThreeGroupId]);
		_appendMatchStarFourToSixListHtml(aStarInfo[self.fourToSixGroupId]);
		_appendMatchStarSevenToNineListHtml(aStarInfo[self.sevenToNineGroupId]);
	}

	function _buildWinnersList(aWinners){
		var aShowWinners = JsTools.clone(aWinners);
		var aTmpWinner = JsTools.clone(aShowWinners[0]);
		aShowWinners[0] = aShowWinners[1];
		aShowWinners[1] = aTmpWinner;

		var aClassGroupList = {
			aLi : ['left', 'center', 'right'],
			aOrders : [2, 1, 3]
		};
		var aWinnerHtml = [];
		for(var i in aShowWinners){
			var aWinner = aShowWinners[i];
			aWinnerHtml.push('<li class="J-winner ' + aClassGroupList.aLi[i] + '" itemid="' + aShowWinners[i].id + '">\
				<div class="name">' + aWinner.name + '</div>\
				<div class="img J-winnerProfile J-order' + aClassGroupList.aOrders[i] + '">\
					' + Ui1.buildProfile(aWinner, true, {
						addClass : 'circle'
					}) + '\
					<i class="ico-match-star num-' + aClassGroupList.aOrders[i] + '"></i>\
				</div>\
				<div class="score"><em>' + aWinner.score + '</em>分</div>\
				<div class="gift">' + aWinner.award + '</div>\
				<div class="triangle-up"></div>\
			</li>');
		}
		return aWinnerHtml.join('');
	}

	function _buildWinnersSayList(aWinners){
		var aResult = [];
		for(var i in aWinners){
			aResult.push('<ul class="list-unstyled J-winnerTestimonials" itemid="' + aWinners[i].id + '" style="display:none;">\
				<li>\
					<div class="title">' + aWinners[i].location + '</div>\
					<div class="cont">' + aWinners[i].testimonials  + '</div>\
				</li>\
			</ul>');
		}
		return aResult.join('');
	}

	var self = win.PageMatchStar;
})(jQuery, window);
