(function ($, win) {
	win.MatchIndex = {
		config: function (aOptions) {
			if (aOptions.url) {
				for (var key in _aUrl) {
					if (aOptions.url[key] != undefined) {
						_aUrl[key] = aOptions.url[key];
					}
				}
			}
			if (aOptions.defaultData) {
				for (var i in _defaultData) {
					if (aOptions.defaultData[i] != undefined) {
						_defaultData[i] = aOptions.defaultData[i];
					}
				}
			}
		},
		bannerHtml : '',
		show: function () {
			//构建基本骨架
			_buildContainerHtml();
			_getInitData();
			_bindEvent();
		}
	};
	var _aUrl = {
		gotoMatchMoreDetails: '',
		gotoEnterTopicUrl: '',
		myMatchUrl: '',
		getBigMatchUrl: '',
		getDailyMatchUrl: '',
		getMyMatchListUrl: '',
		getRelatedTopicListUrl: '',
		getMedalRankListUrl: '',
		enterTopicDetail: '',
		oneMatchUrl: '',
		MyMatchUrl: '',
		enterStartMatchUrl: '',
		starUrl: ''
	};

	var _defaultData = {
		aMedal: '',
		isSxXxtUser: false
	};
	var _$matchIndex = $('.J-mainDiv'), _aMedalRankList = [], _medalRandkOrder = 0 ,_resourceUrl = App.getUrl('resource');

	/**
	 * 加载完骨架之后获取数据
	 */
	function _getInitData() {
		if(!_defaultData.isSxXxtUser){
			_getBigMatchList();
		}
		_getDailyMatchList();
		_getMyMatchList();
		_getPushTopicList();
		_getMedalRandList();

	}

	/**
	 * 为页面绑定事件
	 */
	function _bindEvent() {
		_$matchIndex.on('mouseenter', '.J-oneDailyMatch', function () {
			$(this).find('.J-dailyStatus').show();
		});
		_$matchIndex.on('mouseleave', '.J-oneDailyMatch', function () {
			$(this).find('.J-dailyStatus').hide();
		});

		//奖牌排行分页
		_$matchIndex.on('click', '.J-MedalPagination a', function () {
			var $this = $(this);
			var option = $this.hasClass('J-MedalRankPre');
			var page = $this.closest('.J-MedalPagination').data('page');
			if (!$this.data('status')) {
				return;
			}
			//点击上一页
			if (option) {
				//第一页
				if (page == 1) {
					$this.removeClass('active').data('status', false);
					return;
				}
				page = (page - 1);
			} else {
				page = (page + 1);
			}
			_$matchIndex.find('.J-MedalPagination a').addClass('active');
			if (page < 1 || page > 10) {
				page = 1;
			}
			//数据缓存
			if (_aMedalRankList[page + '_' + _aMedalRankList] !== undefined) {
				_appendMedalRandListHtml(_aMedalRankList[page + '_' + _aMedalRankList], page);
				return;
			}
			_getMedalRandList(page, $this);

		});
		_$matchIndex.on('click','.J-bigMatchUrl',function(){
			var url = $(this).data('url');
			if(url == ''){
				return;
			}
			location.href = url;
		});
	}

	/**
	 * 获取大赛列表数据
	 * @returns {undefined}
	 */
	function _getBigMatchList() {
		ajax({
			url: _aUrl.getBigMatchUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					_appendBigMatchHtml(aResult.data.aBigMatchList);
				}
			}
		});
	}

	/*
	 * 将数据填充大赛界面
	 * @param {type} aBigMatchListData
	 */
	function _appendBigMatchHtml(aBigMatchListData) {
		var bigMatchList = _buildMatchspHtml(aBigMatchListData);
		_$matchIndex.find('.J-bigMatchList').html(bigMatchList);
	}

	/**
	 * 获取日常大赛列表数据
	 */
	function _getDailyMatchList() {
		ajax({
			url: _aUrl.getDailyMatchUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					_appendDailyMatchHtml(aResult.data.aDailyMatchList);
				}
			}
		});
	}

	/*
	 * 将数据填充日常大赛界面
	 * @param {type} aBigMatchListData
	 */
	function _appendDailyMatchHtml(aDailyMatchListData) {
		var dailyMatchList = _buildDailyMatchHtml(aDailyMatchListData);
		_$matchIndex.find('.J-dailyMatchList').html(dailyMatchList);
	}

	/**
	 * 获取我的比赛列表数据
	 */
	function _getMyMatchList() {
		ajax({
			url: _aUrl.getMyMatchListUrl,
			data:{position: 1},
			success: function (aResult) {
				if (aResult.status == 1) {
					_appendMyMatchListHtml(aResult.data.aMyMatchList);
				}
			}
		});
	}

	/**
	 * 填充我的比赛列表数据
	 */
	function _appendMyMatchListHtml(aMyMatchList) {
		var myMatchList = _buildMyMatchList(aMyMatchList);
		_$matchIndex.find('.J-myMatchList').html(myMatchList);
	}


	/**
	 * 获取推荐(相关)话题列表数据
	 */
	function _getPushTopicList() {
		ajax({
			url: _aUrl.getRelatedTopicListUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					_appendRelatedTopicListHtml(aResult.data.aRelatedTopicList);
				}
			}
		});
	}

	/**
	 * 填充推荐(相关)话题数据
	 */
	function _appendRelatedTopicListHtml(aRelatedTopicList) {
		var relatedTopicList = _buildRelatedTopicList(aRelatedTopicList);
		_$matchIndex.find('.J-relatedTopicList').html(relatedTopicList);
	}

	/**
	 * 获取奖牌排行列表数据
	 */
	function _getMedalRandList(page, $this) {
		if (page === undefined) {
			page = 1;
		}
		ajax({
			beforeSend: function () {
				if ($this !== undefined) {
					$this.data('status', false);
				}
			},
			data: {
				page: page,
				order: _medalRandkOrder,
			},
			url: _aUrl.getMedalRankListUrl,
			success: function (aResult) {
				if (aResult.status == 1) {
					var aMedalRankList = aResult.data.aMedalRankList;
					//第一页就没数据
					if (aMedalRankList.length == 0 && page == 1) {
						_$matchIndex.find('.J-MedalPagination').hide();
						_$matchIndex.find('.J-medalRanklist').html('<li class="nodata">暂无数据..</li>');
						return;
					}
					//数据缓存
					_aMedalRankList[page + '_' + _aMedalRankList] = aMedalRankList;
					_appendMedalRandListHtml(aMedalRankList, page);
				}
			}
		});
	}

	/**
	 * 填充奖牌排行列表数据
	 */
	function _appendMedalRandListHtml(aMedalRankList, page) {
		//最后一页
		if ((page > 1) && (aMedalRankList.length == 0)) {
			_$matchIndex.find('.J-MedalRankNext').removeClass('active').data('status', false);
			_$matchIndex.find('.J-MedalPagination').data('page', page);
			_$matchIndex.find('.J-medalRanklist').html('<li class="nodata">没有数据啦</li>');
			return;
			//处理非最后一页让按钮可点击
		} else {
			_$matchIndex.find('.J-MedalPagination a').data('status', true);
		}
		if (page == 1) {
			_$matchIndex.find('.J-MedalRankPre').removeClass('active').data('status', false);
		}
		_$matchIndex.find('.J-MedalPagination').data('page', page);
		var medalRankList = _buildMedalRankList(aMedalRankList);
		_$matchIndex.find('.J-medalRanklist').html(medalRankList);
	}

	/**
	 * 构建主体宽肩
	 */
	function _buildContainerHtml() {
		var aContainerHtml = [];
		//主体html
		aContainerHtml.push('<div class="contain">\
		<div class="um-layout-1">');
		//大赛日常大赛左侧列表
		aContainerHtml.push(_buildMainHtml());

		//side 右侧
		aContainerHtml.push(_buildSideHtml());
		//结束html
		aContainerHtml.push('</div></div>');
		_$matchIndex.html(aContainerHtml.join(''));
	}

	/**
	 * 构建比赛列表主体html
	 */
	function _buildMainHtml() {
		var aMainHtml = [];
		aMainHtml.push('<div class="main">\
			<div class="home-mods match-main lobby">\
				<div class="match-nav">\
					<a href="javascript:;" class="active">全部比赛</a>\
					<a href="' + _aUrl.starUrl + '">比赛之星</a>\
					<a href="' + _aUrl.myMatchUrl + '">我的比赛</a>\
				</div>\
					<div class="bd">');
		//banner
		aMainHtml.push(self.bannerHtml);
		//banner end
		if(!_defaultData.isSxXxtUser){					//大赛
			aMainHtml.push('<div class="match-main-list matchsp">\
				<div class="hd">大赛</div>\
					<div class="bd J-bigMatchList">\n\
						<ul class="list-unstyled"><li class="nodata">数据加载中..</li></ul>\n\
					</div>\n\
				</div>');
		//大赛结束
		}
		
		//日常大赛
		aMainHtml.push('<div class="match-main-list matchdate">\
			<div class="hd">日常比赛</div>\
				<div class="bd J-dailyMatchList">\n\
					<ul class="list-unstyled"><li class="nodata">数据加载中..</li></ul>\n\
				</div>\n\
			</div>\n\
		</div>');

		aMainHtml.push('</div></div>');
		return aMainHtml.join('');
	}

	/**
	 * 构建banner骨架
	 * @returns {String}
	 */
	function _buildBannerHtml() {
		var aBannerHtml = [];
		aBannerHtml.push('');
		aBannerHtml.push(_buildSlideNav(1));
		aBannerHtml.push('</ul>');
		return aBannerHtml.join('');
	}

	/**
	 * 构建slide数量
	 * @param {type} nums
	 * @returns {String}
	 */
	function _buildSlideNav(nums) {
		var aSlideNav = [];
		for (var i = 1; i <= nums; i++) {
			if (i == 1) {
				aSlideNav.push('<li class="active">•</li>');
			} else {
				aSlideNav.push('<li>•</li>');
			}
		}
		return aSlideNav.join('');
	}

	function _buildMatchspHtml(aBigMatchListData) {
		var aMatchspHtml = [];
		var aBigMatchList = aBigMatchListData;
		aMatchspHtml.push('<ul class="list-unstyled">');
		if (aBigMatchListData.length == 0) {
			return '<li class="nodata">暂无数据..</li>';
		}
		for (var i in aBigMatchList) {
			var limitTitle = '无年级限制';
			var alimitGradeList = aBigMatchList[i].limit_grade_list;
			if (alimitGradeList !== undefined && alimitGradeList.length > 0) {
				limitTitle = '仅限' + alimitGradeList.join(',');
			}
			aMatchspHtml.push('<li>\
					<a class="J-bigMatchUrl" data-url="' + _aUrl.oneMatchUrl.replace('_matchId', aBigMatchList[i].id) + '" data-id="' + aBigMatchList[i].id + '" title="' + limitTitle + '">\
					<div class="match-wrap">\
						<div class="match-img">\
							' + Ui1.buildImage(_resourceUrl + aBigMatchList[i].big_match_profile, undefined, {width: 340, height: 235, style: 'height:235px;'}) + '\
						</div>\
						<div class="info">\
							<div class="p1">');
			aMatchspHtml.push('<em>'+ limitTitle + '</em>');
			aMatchspHtml.push(Ui1.date('m/d H:i', aBigMatchList[i].match_start_time) + ' - ' + Ui1.date('m/d H:i', aBigMatchList[i].match_end_time) + '</div>\
							<div class="p2">' + aBigMatchList[i].duration + '分钟答题' + aBigMatchList[i].es_count + '题</div>\
						</div>\
						<div class="join">\
							<i class="ico-match ico-match1"></i>\
							<div class="text">');
							if(aBigMatchList[i].status == 1){
								aMatchspHtml.push('<span>敬请</span>\
									<span>期待</span>');
							}else{
								aMatchspHtml.push('<span>' + aBigMatchList[i].join_match_count + '人</span>\
									<span>参赛</span>');
							}
						aMatchspHtml.push('</div>\
						</div>\
					</div>\
					<div class="match-text">' + aBigMatchList[i].name + '\
					</div>\
					</a>\
				</li>');
		}
		aMatchspHtml.push('</ul>');
		return aMatchspHtml.join('');
	}

	function _buildDailyMatchHtml(aDailyMatchListData) {
		var aMatchdateHtml = [];
		var aDailyMatchList = aDailyMatchListData;
		aMatchdateHtml.push('<ul class="list-unstyled">');

		if (aDailyMatchList.length == 0) {
			return '<li class="nodata">暂无数据..</li>';
		}

		for (var i in aDailyMatchList) {
			//1 未开始 2 进行中 3 结束
			var matchStatus = aDailyMatchList[i].status;
			var status = 'cur';
			if (matchStatus == 3) {
				status = 'over';
			}
			if (matchStatus == 1) {
				status = 'ing';
			}
			var limitTitle = '无年级限制';
			var alimitGradeList = aDailyMatchList[i].limit_grade_list;
			if (alimitGradeList !== undefined && alimitGradeList.length > 0) {
				limitTitle = '仅限' + alimitGradeList.join(',');
			}
			aMatchdateHtml.push('<li class="' + status + ' J-oneDailyMatch">\
					<a href="' + _aUrl.oneMatchUrl.replace('_matchId', aDailyMatchList[i].id) + '" title="' + limitTitle + '">\
					<div class="match-wrap">\
						<div class="match-img">\
							' + Ui1.buildImage(_resourceUrl + aDailyMatchList[i].profile, undefined, {width: 202, height: 222}) + '\
						</div>\
						<div class="info J-dailyStatus" style="display:none;">\
							<div class="p1">' + Ui1.date('m/d H:i', aDailyMatchList[i].match_start_time) + ' - ' + Ui1.date('m/d H:i', aDailyMatchList[i].match_end_time) + '</div>\
							<div class="p2">');
			aMatchdateHtml.push('<em>'+ limitTitle + '</em>');
			aMatchdateHtml.push('</div>\
							<div class="p3">' + aDailyMatchList[i].duration + '分钟答题' + aDailyMatchList[i].es_count + '题</div>\
						</div>\
						<i class="ico-match"></i>\
					</div>\
					<div class="match-text">【' + aDailyMatchList[i].grade_name + '】' + aDailyMatchList[i].name + '\
					</div>\
					<div class="match-text">\
							<em>' + aDailyMatchList[i].join_match_count + '</em>人参赛\
					</div>\
					</a>\
				</li>');
		}
		aMatchdateHtml.push('</ul>');
		return aMatchdateHtml.join('');
	}

	function _buildSideHtml() {
		var aSideHtml = [];
		aSideHtml.push('<div class="side">');
		aSideHtml.push(_buildMyMedalHtml());
		aSideHtml.push(self.bannerRightHtml);

		aSideHtml.push(_buildMyMatchHtml());
		aSideHtml.push(_buildPushTopicHtml());
		aSideHtml.push(_buildMedalrankHtml());
		aSideHtml.push('</div>');
		return aSideHtml.join('');
	}

	//我的奖牌
	function _buildMyMedalHtml() {
		return '<div class="home-mods um-mmymedal">\
				<div class="hd">\
					 <h2 class="title">我的奖牌</h2>\
				 </div>\
				<div class="bd">\
					<div class="my-medallist">\
						<div class="brand">\
							<i class="ico_brand ico_brand_gold_b"></i>\
							<span class="text">' + _defaultData.aMedal.gold_medal + '</span>\
						</div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_silver_b"></i>\
							<span class="text">' + _defaultData.aMedal.silver_medal + '</span>\
						</div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_copper_b"></i>\
							<span class="text">' + _defaultData.aMedal.cuprum_medal + '</span>\
						</div>\
					</div>\
				 </div>\
				<div class="hd">\
					 <h2 class="title">比赛须知</h2>\
					 <a href="' + _aUrl.gotoMatchMoreDetails + '" target="_blank" class="sp">\
						更多详情\
					 </a>\
				 </div>\
				 <div class="bd">\
					<div class="match-notic">\
						<ul class="J-matchNoticeList">\
							<li>大赛每个组别的前三名用户会获得相应的实物奖励，并设有10名幸运奖。奖品会于比赛结束后发出。</li>\
							<li>日常比赛前三名用户会在比赛结束后获得相应的金币奖励。</li>\
						</ul>\
					</div>\
				 </div></div>';
	}

	function _buildMyMatchHtml() {
		return '<div class="home-mods um-mmymatch">\
				<div class="hd">\
					 <h2 class="title">我的比赛</h2>\
					 <!-- <a href="javascript:;" class="sp">\
						<i class="ico ico_refresh"></i>\
					 </a> -->\
				 </div>\
				 <div class="bd">\
					<div class="match-list">\
						<ul class="list-unstyled J-myMatchList"></ul>\
					</div>\
				 </div>\
			 </div>';
	}

	function _buildMyMatchList(aMyMatchList) {
		var aLiListHtml = [];
		if (aMyMatchList.length == 0) {
			return '<li class="nodata">	还没有参赛数据..</li>';
		}
		var status = 'over last';
		for (var i in aMyMatchList) {
			var aData = aMyMatchList[i],
				status = aData.status;
			var matchDetailUrl = _aUrl.enterStartMatchUrl.replace('_matchId', aData.id);
			var statusClass = 'over last';

			if (JsTools.inArray(aData.status, [5, 6])) {
				statusClass = 'cur';
			}
			aLiListHtml.push('<li class="' + statusClass + '">\
				<div class="img">\
					<a href="" class="avatar">\
					' + Ui1.buildImage(_resourceUrl + aData.profile, undefined, {width: 100, height: 100}) + '\
					</a>\
					<i class="ico-match"></i>\
				</div>\
				<div class="info">\
					<div class="title">' + aData.name + '</div>');

			if (status == 5) {
				aLiListHtml.push('<a href="' + matchDetailUrl + '" class="match-btn">继续答题</a>');
			}else if(status == 6){
				aLiListHtml.push('<a href="' + matchDetailUrl + '" class="match-btn">再次参赛</a>');
			} else if(status == 3){
				aLiListHtml.push('<a href="' + matchDetailUrl + '" class="match-btn">比赛结束</a>');
			} else if(status == 7){
				//!!!!!志远少弄了已结束但文字高亮的样式
				aLiListHtml.push('<a href="' + matchDetailUrl + '" class="match-btn" style="background:#093;">领取奖励</a>');
			} else {
				aLiListHtml.push('<a href="' + matchDetailUrl + '" class="match-btn">查看比赛</a>');
			}

			aLiListHtml.push('</div></li>');
		}
		return aLiListHtml.join('');
	}

	function _buildPushTopicHtml() {
		return '<div class="home-mods um-mtopic">\
				<div class="hd">\
					 <h2 class="title">相关话题</h2>\
						<a href="' + _aUrl.gotoEnterTopicUrl + '" target="_blank" class="sp" title="进入话题">进入话题</a>\
				 </div>\
				 <div class="bd">\
					<ul class="J-relatedTopicList"></ul>\
				 </div>\
			 </div>';
	}

	/**
	 * 构建推荐话题列表html
	 */
	function _buildRelatedTopicList(aRelatedTopicList) {
		var aDataList = aRelatedTopicList;
		if (aDataList.length == 0) {
			return '<li class="nodata">暂无数据..</li>';
		}
		var aLiListHtml = [];
		for (var i in aDataList) {
			aLiListHtml.push('<li><a href="' + _aUrl.enterTopicDetail.replace('_topicId', aDataList[i].id) + '" target="_blank"><span class="disc">' + aDataList[i].read_times + '</span>' + aDataList[i].title + '</a></li>');
		}
		return aLiListHtml.join('');
	}

	/**
	 * 构建奖牌列表html
	 */
	function _buildMedalrankHtml() {
		return '<div class="home-mods um-mmadalrank">\
				<div class="hd">\
					 <h2 class="title">奖牌排行榜</h2>\
				 </div>\
				 <div class="bd">\
					<div class="madalrank-list">\
						<div class="caption">\
							<span class="td rank">排名</span>\
							<span class="td">金牌</span>\
							<span class="td">银牌</span>\
							<span class="td">铜牌</span>\
							<span class="td">总数</span>\
						</div>\
						<div class="tbody">\
							<ul class="list-unstyled J-medalRanklist"></ul>\
						</div>\
					</div>\
				 </div>\
				 <div class="ft">\
					<div class="opts J-MedalPagination" data-page="1">\
						<a href="javascript:;" class="J-prev-dan-btn um-btn-ghost um-btn-default um-btn-xs J-MedalRankPre" data-status="true">上一页</a>\
						<a href="javascript:;" class="J-next-dan-btn um-btn-ghost um-btn-default um-btn-xs active J-MedalRankNext" data-status="true">下一页</a>\
					</div>\
				 </div>\
			 </div>';
	}

	/**
	 * 构建
	 */
	function _buildMedalRankList(aMedalRankList) {
		var aDataList = aMedalRankList;
		var aLiListHtml = [];
		for (var i in aDataList) {
			aLiListHtml.push('<li class="' + ((aDataList[i].rank > 3) ? '' : 'active') + '">\
				<span class="td rank">\
					<span class="num">' + aDataList[i].rank + '</span>\
						' + Ui1.buildProfile(aDataList[i].user_info) + '\
				</span>\
				<span class="td">' + aDataList[i].gold_medal + '</span>\
				<span class="td">' + aDataList[i].silver_medal + '</span>\
				<span class="td">' + aDataList[i].cuprum_medal + '</span>\
				<span class="td">' + aDataList[i].all_medal + '<i class="rankc v3-up" style="display:none;"></i></span>\
			</li>');
		}
		return aLiListHtml.join('');
	}

	var self = win.MatchIndex;
})(jQuery, window);
