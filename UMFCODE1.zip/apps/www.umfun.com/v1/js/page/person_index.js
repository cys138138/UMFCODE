(function ($, win) {
	win.PersonIndex = {
		config: function (aOptions) {
			if (aOptions.url) {
				for (var key in _aUrl) {
					if (aOptions.url[key] != undefined) {
						_aUrl[key] = aOptions.url[key];
					}
				}
			}
			if (aOptions.defaultData) {
				for (var i in _defaultData) {
					if (aOptions.defaultData[i] != undefined) {
						_defaultData[i] = aOptions.defaultData[i];
					}
				}
			}
		},
		show: function () {
			_buildMianHtml();
			_bindEvent();
			_getInitData();
		}
	};
	var _aUrl = {
		praiseUrl: '',
		getPushFriendDataUrl: '',
		getHotTopicDataUrl: '',
		getRecentVisitorsDataUrl: '',
		gotoShowProablyUrl: '',
		gotoTopicUrl: '',
		gotoNoTopicUrl: '',
		userInfoUrl: '',
		addFriendUrl: '',
		sendMessageUrl: '',
		//EventPage用到的url
		evenListUrl: '',
		matchDetailUrl: '',
		exchangeGoodDetailUrl: '',
		threadDetailUrl: '',
		openVipUrl: '',
		bindEmailUrl: '',
		missionPracticUrl: '',
		gotoHotTopicListUrl: ''
	};

	var _defaultData = {
		isMySelf: false,
		userId: '',
		isNewUser: false,
		topIsEmpty : ''
	};
	var $personIndex = $('body'), _PushFriendDataList = [];

	function _buildMianHtml() {
		//左侧主体
		_buildLeftMain();
		//右侧主体
		_buildRightMain();
	}

	/**
	 * 绑定各事件并构建左侧html
	 */
	function _bindEvent() {
		_buildToplist();
		_buildTopListEvent();
		_clickAddFriend();
		//绑定点赞事件
		_praise();
		//绑定发小纸条事件
		_sendMessge();
	}

	function _getInitData() {
		//获取推荐的人
		_getPushFriendData();
		//话题
		_getHotTopicData();
		//访客
		_getRecentVisitors();
	}

	/**
	 * 构建左侧主体html
	 */
	function _buildRightMain() {
		var tipic = '话题';
		var saidFriend = '好友';
		if (_defaultData.isNewUser == 1) {
			tipic = '热门话题';
			saidFriend = '推荐用户';
			var userHtml = '<a href="' + _aUrl.gotoShowProablyUrl + '" target="_blank" class="sp">查看全部</a>';
			var gotoTopic = _aUrl.gotoNoTopicUrl;
		} else {
			//好友
			var userHtml = '<a href="javascript:;" class="sp"><i class="ico ico_refresh J-userFriendLoadMore" data-page="1" data-status="true"></i></a>';
			var gotoTopic = _aUrl.gotoTopicUrl;
		}
		var topDivHtml = '';
		if(_defaultData.topIsEmpty != 1){
			topDivHtml = '<!--热门话题-->\
	   <div class="p3">\
		   <div class="hd">' + tipic + '<a href="' + gotoTopic + '" target="_bank" class="sp"  style="display:none;">查看更多</a>\
		   </div>\
		   <div class="bd">\
			   <ul class="list-unstyled topic-list J-hotTopic">\
			   </ul>\
		   </div>\
	   </div>\
	   <!--热门话题 end-->';
			
		}
		var rightMainHtml = '<!--推荐的人-->\
	   <div class="p2">\
		   <div class="hd">' + saidFriend + '' + userHtml + '\
		   </div>\
		   <div class="bd">\
			   <div class="p2-list">\
				   <ul class="list-unstyled p-list J-pushFriend">\
				   </ul>\
			   </div>\
		   </div>\
	   </div>\
	   <!--推荐的人 end-->'+ topDivHtml +'\
	   <!--最近访客-->\
	   <div class="p4">\
		   <div class="hd">\
			   最近访客\
		   </div>\
		   <div class="bd">\
			   <div class="p2-list">\
				   <ul class="list-unstyled p-list J-recentVisitors">\
				   </ul>\
			   </div>\
		   </div>\
	   </div>\
	   <!--最近访客 end-->';
		$personIndex.find('.J-rightMain').html(rightMainHtml);
	}

	function _buildLeftMain() {
		var leftmainHtml = '<!--分类导航-->\
		   <div class="profile-nav">\
			   <ul class="list-unstyled">\
				   <li class="active J-topCategory" data-type="all">\
					   <a href="javascript:;">\
						   <span class="nav-text"><i class="ico ico_p_all"></i>全部</span>\
					   </a>\
				   </li>\
				   <li class="J-topCategory" data-type="mission">\
					   <a href="javascript:;">\
						   <span class="nav-text"><i class="ico ico_p_mission"></i>闯关</span>\
					   </a>\
				   </li>\
				   <li class="J-topCategory" data-type="match">\
					   <a href="javascript:;">\
						   <span class="nav-text"><i class="ico ico_p_match"></i>比赛</span>\
					   </a>\
				   </li>\
				   <!--<li class="J-topCategory" data-type="activity">\
					   <a href="javascript:;">\
						   <span class="nav-text"><i class="ico ico_p_activity"></i>活动</span>\
					   </a>\
				   </li>-->\
				   <li class="J-topCategory" data-type="pk">\
					   <a href="javascript:;">\
						   <span class="nav-text"><i class="ico ico_p_pk"></i>PK</span>\
					   </a>\
				   </li>\
			   </ul>\
		   </div>\
			   <div class="profile-list J-topListParent J-event-list">\
			   </div>\
		   <!--分类导航end-->';
		$personIndex.find('.J-leftMain').html(leftmainHtml);
	}

	function _buildTopListEvent() {
		//默认全部
		$personIndex.find('.J-topCategory:first').click();
		_bindLoadMore();
	}

	function _buildToplist() {
		$personIndex.on('click', '.J-topCategory', function () {
			var eventType = $(this).data('type');
			$(this).siblings().removeClass('active').end().addClass('active');
			_getTipicByType('target_user', eventType, 1);
		})
	}

	function _bindLoadMore() {
		$personIndex.find('.J-topListParent').on('click', '.J-loadMore', function () {
			$this = $(this);
			var type = $this.data('type');
			var page = $this.data('page');
			$this.closest('p').remove();
			var oldData = $('.J-event-list').html();
			_getTipicByType('target_user', type, (page + 1), oldData);
		});
	}


	/**
	 * 绑定加好友事件
	 */
	function _clickAddFriend() {
		$personIndex.on('click', '.J-addFriend', function () {
			$this = $(this);
			_sendRequest($this.data('id'), 1);
		});
	}

	/**
	 * 点赞操作
	 */
	function _praise() {
		$personIndex.find('.J-praise').click(function () {
			var $this = $(this);
			if (!$this.data('status')) {
				return;
			}
			ajax({
				beforeSend: function () {
					$this.data('status', false);
				},
				url: _aUrl.praiseUrl,
				data: {
					user_id: $this.data('id')
				},
				success: function (aResult) {
					if (aResult.status !== 1) {
						UBox.show(aResult.msg, -1);
						return;
					}
					_setPraise(aResult.data.praise);
					UBox.show(aResult.msg, 1);
				},
				error: function () {
					UBox.show('网络出错了请重试..', -1);
					$this.data('status', true);
				}
			});
		});
	}

	/**
	 *设置点赞数量和状态 
	 */
	function _setPraise(praise) {
		var praiseHtml = '<span class="zan">赞<i class="ico ico_p_love_red"></i></span>\
		   <span class="zan-text">收集的赞：<em>' + praise + '</em></span>';
		$personIndex.find('.J-praise').closest('div').html(praiseHtml).addClass('active');
	}

	/**
	 * 获取推荐的人数据并构建
	 */
	function _getPushFriendData() {
		ajax({
			url: _aUrl.getPushFriendDataUrl,
			data: {
				page: 1,
				user_id: _defaultData.userId
			},
			success: function (result) {
				if (result.status == 1) {
					var aPushFriendList = result.data.aPushFriendList;
					//保存第一页获取的数据方便循环读取数据
					_PushFriendDataList[1] = aPushFriendList;
					_buildPushFriend(aPushFriendList);
				}
			}
		});
		_userFriendLoadMore();
	}

	function _userFriendLoadMore() {
		$personIndex.find('.J-userFriendLoadMore').click(function () {
			var $this = $(this);
			var page = $this.data('page');
			if(_PushFriendDataList[(page + 1)] !== undefined){
				_buildPushFriend(_PushFriendDataList[(page + 1)]);
				$this.data('page', (page + 1));
				return;
			}
			ajax({
				url: _aUrl.getPushFriendDataUrl,
				data: {
					page: (page + 1),
					user_id: _defaultData.userId
				},
				success: function (result) {
					if (result.status == 1) {
						var aPushFriendList = result.data.aPushFriendList;
						$this.data('page', (page + 1));
						if(page > 1 && aPushFriendList.length == 0){
							$this.data('page',1);
							if(_PushFriendDataList[1] !== undefined){
								_buildPushFriend(_PushFriendDataList[1]);
								return;
							}
						}
						_PushFriendDataList[(page + 1)] = aPushFriendList;
						_buildPushFriend(aPushFriendList);
					}
				}
			});
		});
	}

	/**
	 *构建推荐的人列表 
	 */
	function _buildPushFriend(aPushFriendLists) {
		var aPushFriendList = aPushFriendLists;
		var aPushListHtml = [];
		if (aPushFriendList.length == 0) {
			$personIndex.find('.J-pushFriend').html('<li class="nodata">暂时没有可能认识的人喔</li>');
			return;
		}
		for (var i in aPushFriendList) {
			aPushListHtml.push('<li>\
		   <div class="head">' + Ui1.buildProfile({id: aPushFriendList[i].id, profile: aPushFriendList[i].profile}) + '\
		   </div>\
		   <div class="name">\
			   <a href="javascript:;">' + Ui1.buildVipName(aPushFriendList[i]) + '</a>\
		   </div>');
			if(aPushFriendList[i].is_my_friend == 0){
				aPushListHtml.push('<div class="fribtn"><a href="javascript:void(0)" data-id="' + aPushFriendList[i].id + '" class="J-addFriend"><i>+</i>好友</a></div>');
			}
			aPushListHtml.push('</li>');
		}
		$personIndex.find('.J-pushFriend').html(aPushListHtml.join(''));
	}

	/**
	 * 获取热门话题并构建
	 */
	function _getHotTopicData() {
		ajax({
			url: _aUrl.getHotTopicDataUrl,
			data: {
				user_id: _defaultData.userId
			},
			success: function (result) {
				if (result.status == 1) {
					var aHotTopicList = result.data.aHotTopicList;
					_buildHotTopic(aHotTopicList);
				}
			}
		});
	}

	/**
	 *构建热门话题列表 
	 */
	function _buildHotTopic(aHotTopicList) {
		var aHotTopicHtml = [];
		if (aHotTopicList.length == 0) {
			$personIndex.find('.J-hotTopic').html('<li class="nodata">暂时没有可能认识的人喔</li>');
			return;
		}
		for (var i in aHotTopicList) {
			aHotTopicHtml.push('<li>\
		   <a href="' + aHotTopicList[i].url + '" target="_blank" title="' + aHotTopicList[i].title + '">· ' + aHotTopicList[i].title + '</a>\
		   <span class="date">' + Ui1.timeToAgo(aHotTopicList[i].create_time) + '</span>\
	   </li>');
		}
		$personIndex.find('.J-hotTopic').html(aHotTopicHtml.join(''));
	}

	/**
	 * 获取最近访客数据并构建
	 */
	function _getRecentVisitors() {
		ajax({
			url: _aUrl.getRecentVisitorsDataUrl,
			data: {
				user_id: _defaultData.userId
			},
			success: function (result) {
				if (result.status == 1) {
					var aRecentVisitors = result.data.aRecentVisitors;
					_buildRecentVisitors(aRecentVisitors);
				}
			}
		});
	}

	/**
	 * 构建访客列表
	 */
	function _buildRecentVisitors(aRecentVisitors) {
		var aRecentVisitorsHtml = [];
		if (aRecentVisitors.length == 0) {
			$personIndex.find('.J-recentVisitors').html('<li class="nodata">暂时没有可能认识的人喔</li>');
			return;
		}
		for (var i in aRecentVisitors) {
			aRecentVisitorsHtml.push('<li>\
		   <div class="head">' + Ui1.buildProfile({id: aRecentVisitors[i].id, profile: aRecentVisitors[i].profile}) + '\
		   </div>\
		   <div class="name">\
			   <a href="javascript:;">' + Ui1.buildVipName(aRecentVisitors[i]) + '</a>\
		   </div>');
		if(aRecentVisitors[i].is_my_friend == 0){
			aRecentVisitorsHtml.push('<div class="fribtn">\
				<a href="javascript:;" class="J-addFriend" data-id="' + aRecentVisitors[i].id + '"><i>+</i>好友</a>\
			</div>');
		}		   
	   aRecentVisitorsHtml.push('</li>');
		}
		$personIndex.find('.J-recentVisitors').html(aRecentVisitorsHtml.join(''));
	}

	/**
	 * 发小纸条
	 */
	function _sendMessge() {
		$personIndex.find('.J-sendMessge').click(function () {
			_sendRequest($(this).data('id'), 2);
		});
	}

	/**
	 * 根据type 弹出相应的框
	 */
	function _sendRequest(userId, type) {
		var dialogType = UMDialogs.TYPE_ADD_FRIEND;
		if (type == 2) {
			var dialogType = UMDialogs.TYPE_SEND_MESSAGE;
		}
		var dialog = UMDialogs.build(dialogType, {
			user_target_id: userId,
			user_info_url: _aUrl.userInfoUrl,
			add_friend_url: _aUrl.addFriendUrl,
			send_message_url: _aUrl.sendMessageUrl
		});
		dialog.show();
	}

	function _getTipicByType(type, eventType, page, oldData) {
		EventPage.page = page;
		EventPage.type = type;
		EventPage.target_user_id = _defaultData.userId;
		EventPage.event_type = eventType;
		EventPage.oWrapDom = $personIndex.find('.J-event-list');
		EventPage.evenListUrl = _aUrl.evenListUrl;
		EventPage.matchDetailUrl = _aUrl.matchDetailUrl;
		EventPage.exchangeGoodDetailUrl = _aUrl.exchangeGoodDetailUrl;
		EventPage.threadDetailUrl = _aUrl.threadDetailUrl;
		EventPage.openVipUrl = _aUrl.openVipUrl;
		EventPage.bindEmailUrl = _aUrl.bindEmailUrl;
		EventPage.missionPracticUrl = _aUrl.missionPracticUrl;
		EventPage.userInfoUrl = _aUrl.userInfoUrl;
		EventPage.showEventList(EventPage.page, EventPage.type, EventPage.event_type, function (data) {
			if (data.list.length == 0) {
				var who = '他';
				if (_defaultData.isMySelf == 1) {
					who = '你';
				}
				if (oldData !== undefined) {
					$personIndex.find('.J-event-list').html(oldData + '<p><a href="javascript:;" style="background-color: #eee; color:#ccc; display: block;width: 200px;height: 40px;line-height: 40px;text-align: center;margin: 50px auto;">没有数据了...</a></p>');
					return;
				}
				$personIndex.find('.J-event-list').html('<div class="nodata">' + who + '暂时还没有自己的动态，<a href="' + _aUrl.gotoHotTopicListUrl + '" target="_blank">查看热门动态</a></div>');
			} else {
				var $topicList = $personIndex.find('.J-event-list');
				var topicListHtml = $topicList.html();
				if (oldData !== undefined) {
					topicListHtml = oldData + topicListHtml;
				}
				$topicList.html(topicListHtml + '<p><a href="javascript:;" class="loadmore J-loadMore" data-page="' + data.page + '" data-type="' + eventType + '">加载更多...</a></p>');
				UMDialogs.listenToShowStudentInfo($topicList.find('.J-event-list-wraper img'), {
					user_info_url: _aUrl.userInfoUrl,
					add_friend_url: _aUrl.addFriendUrl,
					send_message_url: _aUrl.sendMessageUrl,
				});
			}
		});
	}

})(jQuery, window);
