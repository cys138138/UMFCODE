(function ($, win) {
    win.PageSide = {
        $oPageSide: {},
        markRankpage: 1,
        exchangeGoodDetailUrl: '',
        threadDetailUrl: '',
        markInfoUrl: '',
        markRankListUrl: '',
        markUrl: '',
        signHelpUrl: '',
        recommandTopicUrl: '',
        topicDetailUrl: '',
        probablyFriendUrl: '',
        bbsHomeUrl: '',
        exchangeHomeUrl: '',
        recentExchangegRecordUrl: '',
        exchangeGoodsDetailUrl: '',
        goldRankingUrl: '',
        userInfoUrl: '',
        applyFriendUrl: '',
        sendMessageUrl: '',
        pmUrl: null,
        pmUserInfo: null,

        showGoldRanking: function (type) {
            var oThis = this;
            ajax({
                url: oThis.goldRankingUrl,
                data: {type: type},
                success: function (aResult) {
                    if (aResult.status == 1) {
                        _appendGoldRankingList(type, aResult.data);
                    } else {
                        UBox.show(aResult.msg, aResult.status);
                    }
                }
            });
        },
        showRecommendTopic: function () {
            var oThis = this;
            ajax({
                url: oThis.recommandTopicUrl,
                data: {},
                success: function (aResult) {
                    if (aResult.status == 1) {
                        _appendRecommendTopic(aResult.data);
                    } else {
                        UBox.show(aResult.msg, aResult.status);
                    }
                }
            });
        },
        showExchangeRecord: function () {
            ajax({
                url: self.recentExchangegRecordUrl,
                data: {},
                success: function (aResult) {
                    if (aResult.status == 1) {
                        _appendRecentExchangegRecord(aResult.data);
                    } else {
                        UBox.show(aResult.msg, aResult.status);
                    }
                }
            });
        },
        showProbably: function () {
            var oThis = this;
            ajax({
                url: oThis.probablyFriendUrl,
                data: {},
                success: function (aResult) {
                    if (aResult.status == 1) {
                        _appendProbablyFriendList(aResult.data);
                    } else {
                        UBox.show(aResult.msg, aResult.status);
                    }
                }
            });
        },
        showMark: function () {
            var oThis = this;
            var htmlStr = '';
            ajax({
                url: oThis.markInfoUrl,
                success: function (aResult) {
                    if (aResult.status == 1) {
                        var oData = aResult.data.aMarkInfo;
                        var markStatus = '';
                        if (oData.is_marked == 0) {
                            markStatus = '<a class="J-mark-btn btn" href="javascript:;">签到</a>';
                        } else {
                            markStatus = '<a class="J-mark-btn btn disabled" href="javascript:;">已签到</a>';
                        }
                        htmlStr += '\
							<div class="bd">\
								<div class="time">\
									<div class="week">' + oData.week_str + '</div>\
									<div class="date">' + oData.today_date + '</div>\
								</div>\
								<div class="btnbox">\
									' + markStatus + '\
								</div>\
								<div class="follow">\
									<div class="total">' + oData.mark_total_day + '</div>\
									<span>Days</span>\
								</div>\
							</div>\
							<div class="ft">\
								<span class="sum">\
									<span class="row">已连续签到' + oData.continue_mark_day + '日，今日' + oData.today_gold + '金币</span>\
								</span>\
								<!--<a href="javascript:void(0);" onclick="showHelpWindow(\'签到说明\', \'' + oThis.signHelpUrl + '\');">\
									<i class="ico ico_checkin_tips"></i>\
								</a>-->\
								<span class="dropdown">\
									<a id="checkin_act" class="J-mark-rank checkin_act" href="javascript:;" data-status="0">\
										<span class="row">签到榜</span>\
										<i class="arrow"></i>\
									</a>\
								</span>\
							</div>\
							<div class="J-mark-rank-block checkin-rank">\
								<div class="profile">\
									' + Ui1.buildProfile(App.oCurrentStudent, true, {addClass: 'circle'}) + '\
									好友签到总天数排名<b>No.' + oData.friend_mark_rank + '</b>.\
								</div>\
								<div class="optionbox">\
									<div class="box box-first">筛选：</div>\
									<div class="box">\
										<a href="javascript:;" class="J-mark-man-select J-mark-option-select box-display" data-type="0"><span class="currentText">全部人</span><i class="arrow"></i></a>\
										<div class="J-mark-option-item box-select">\
											<a href="javascript:;" data-type="1">好友</a>\
										</div>\
									</div>\
									<div class="box active">\
										<a href="javascript:;" class="J-mark-date-select J-mark-option-select box-display" data-type="mark_continuous"><span class="currentText">连续天数</span><i class="arrow"></i></a>\
										<div class="J-mark-option-item box-select" style="display:none;">\
											<a href="javascript:;" data-type="mark_total">总天数</a>\
										</div>\
									</div>\
								</div>\
								<div class="checkin-list">\
									<table>\
										<thead>\
											<tr>\
												<td class="user">我的好友</td>\
												<td class="days">连续天数</td>\
												<td class="gather">总天数</td>\
											</tr>\
										</thead>\
										<tbody class="J-mark-rank-list-wraper"></tbody>\
									</table>\
								</div>\
								<div class="operate">\
									<a href="javascript:;" class="J-prev-mark-rank-list prev">上一页</a>\
									<a href="javascript:;" class="J-next-mark-rank-list next">下一页</a>\
									<a class="close J-close" href="javascript:;" title="关闭">×</a>\
								</div>\
							</div>\
						';

                        oThis.$oPageSide.find('.J-mark-block').html(htmlStr);
                        oThis.$oPageSide.find('.J-mark-block').show();
                        oThis.$oPageSide.find('.J-mark-rank').unbind();
                        oThis.$oPageSide.find('.J-mark-rank').on('click', function () {
                            if ($(this).attr('data-status') == 0) {
                                oThis.$oPageSide.find('.J-mark-rank-block').show();
                                $(this).attr('data-status', 1);
                            } else {
                                oThis.$oPageSide.find('.J-mark-rank-block').hide();
                                $(this).attr('data-status', 0);
                            }
                            _showMarkRankList(1);
                        });
                        oThis.$oPageSide.find('.J-mark-block').find('.J-close').unbind();
                        oThis.$oPageSide.find('.J-mark-block').find('.J-close').on('click', function () {
                            $('.J-mark-rank-block').hide();
                            $('.J-mark-rank').attr('data-status', 0);
                        });
                        oThis.$oPageSide.find('.J-mark-btn').unbind();
                        oThis.$oPageSide.find('.J-mark-btn').on('click', function () {
                            _mark($(this));
                        });
                        oThis.$oPageSide.find('.J-mark-option-select').unbind();
                        oThis.$oPageSide.find('.J-mark-option-select').on('click', function () {
                            $(this).next().show();
                        });
                        oThis.$oPageSide.find('.J-mark-option-item a').unbind();
                        oThis.$oPageSide.find('.J-mark-option-item a').on('click', function () {
                            $(this).parent().hide();
                            var type = $(this).attr('data-type'),
                                currentType = $(this).parent().prev().attr('data-type'),
                                currentTypeStr = $(this).parent().prev().find('.currentText').html(),
                                typeStr = $(this).html();
                            $(this).parent().prev().attr('data-type', type);
                            $(this).parent().prev().find('.currentText').html(typeStr);
                            $(this).attr('data-type', currentType);
                            $(this).html(currentTypeStr);
                            _showMarkRankList(1);
                        });
                        oThis.$oPageSide.find('.J-prev-mark-rank-list').unbind();
                        oThis.$oPageSide.find('.J-prev-mark-rank-list').on('click', function () {
                            if (oThis.markRankpage != 1) {
                                _showMarkRankList(--oThis.markRankpage);
                            }
                        });
                        oThis.$oPageSide.find('.J-next-mark-rank-list').unbind();
                        oThis.$oPageSide.find('.J-next-mark-rank-list').on('click', function () {
                            _showMarkRankList(++oThis.markRankpage);
                        });
                    } else {
                        UBox.show(aResult.msg, aResult.status);
                    }
                }
            });
        },

        //"个人主页"，点赞
        showPmZan: function () {
            var oThis = this;
            var userInfo = this.pmUserInfo;
            var main = this.$oPageSide.find('.J-pmZan-block');
            var htmlStr = '\
				<div class="zan">\
                    <div class="J-zan-btn zan-btn">\
                       <span>赞</span>\
					   <div class="J-zan-ico ico_personal ico_personal_zan"></div>\
                    </div>\
                    <span class="msg">收到的赞:</span>\
					<span class="J-zan-text text"></span>\
				</div>\
				<div class="medal">\
                    <div class="rank">\
                        <img class="J-rank-img"/>\
                        <div class="J-rank-text text"></div>\
                    </div>\
                    <div class="brand">\
                        <i class="ico_brand ico_brand_gold_m"/>\
                        <div class="J-gold text"></div>\
                    </div>\
                    <div class="brand">\
                        <i class="ico_brand ico_brand_silver_m"/>\
                        <div class="J-silver text"></div>\
                    </div>\
                    <div class="brand">\
                        <i class="ico_brand ico_brand_copper_m"/>\
                        <div class="J-copper text"></div>\
                    </div>\
				</div>';
            main.html(htmlStr);
            var zanBtn = main.find(".J-zan-btn");
            if (!userInfo['is_praise']) {
                zanBtn.data({"id": userInfo['id'], 'status': true}).on("click", function () {
                    var $this = $(this);
                    if (!$this.data('status')) {
                        return;
                    }
                    ajax({
                        beforeSend: function () {
                            $this.data('status', false);
                        },
                        url: oThis.pmUrl.praiseUrl,
                        data: {
                            user_id: $this.data('id')
                        },
                        success: function (aResult) {
                            if (aResult.status !== 1) {
                                UBox.show(aResult.msg, -1);
                                return;
                            }
                            $this.find(".J-zan-ico").addClass("ico_personal_zan_ed");
                            main.find(".J-zan-text").html(aResult.data.praise);
                            UBox.show(aResult.msg, 1);
                        },
                        error: function () {
                            UBox.show('网络出错了请重试..', -1);
                            $this.data('status', true);
                        }
                    });
                });
            }
            else {
                zanBtn.find(".J-zan-ico").addClass("ico_personal_zan_ed");
            }
            main.find(".J-zan-text").html(userInfo['visitor_info']['praise_count']);
            main.find(".J-rank-img").attr("src", userInfo['dan_info']['image']);
            main.find(".J-rank-text").html(userInfo['dan_info']['name']);
            main.find(".J-gold").html(userInfo['medal_info']['gold_medal'] > 99 ? "99+" : userInfo['medal_info']['gold_medal']);
            main.find(".J-silver").html(userInfo['medal_info']['silver_medal'] > 99 ? "99+" : userInfo['medal_info']['silver_medal']);
            main.find(".J-copper").html(userInfo['medal_info']['cuprum_medal'] > 99 ? "99+" : userInfo['medal_info']['cuprum_medal']);

        },
        //"个人主页"，好友
        showPmFriend: function () {
            var userInfo = this.pmUserInfo;
            var oThis = this;
            var htmlStr = '\
                <div class="um-pmTitle">\
                    <span class="title-name">好友</span>\
                    <div class="J-ref-btn ico_personal ico_personal_ref_friend"></div>\
                </div>\
                <div class="J-content um-pmContent"> \
                </div>';
            var main = this.$oPageSide.find('.J-pmFriend-block');
            main.html(htmlStr);
            var btnPage = main.find(".J-ref-btn").on("click", function () {
                showContent($(this).data("page"));
            });
            var content = main.find(".J-content");
            var showContent = function (pageN) {
                var htmlLabel = '';
                ajax({
                    url: oThis.pmUrl.getPushFriendDataUrl,
                    data: {
                        page: pageN,
                        user_id: userInfo.id
                    },
                    success: function (res) {
                        var data = res.data.aPushFriendList;
                        if (data.length == 0) {
                            if (pageN != 1) {
                                showContent(1);
                            } else {
                                content.html('<div class="noData">暂时没有可能认识的人喔</div>');
                                btnPage.off("click");
                            }
                            return;
                        }
                        for (var i = 0, n = data.length; i < n; i++) {
                            var dataItem = data[i];
                            var addFriendHtml = dataItem.is_my_friend == 0 ? '<div class="J-addFriend addFriend" data-id="' + dataItem.id + '"><i>+</i>好友</div>' : '';
                            htmlLabel += '<div class="J-user-item user-item">\
                                ' + Ui1.buildProfile(dataItem, true, {addClass: 'circle'}) + '\
                                <div class="name">' + Ui1.buildVipName(dataItem) + '</div>\
                                ' + addFriendHtml + '\
                            </div>';
                        }
                        content.html(htmlLabel);
                        content.find('.J-addFriend').on('click', function () {
                            $this = $(this);
                            _sendRequest($this.data('id'), 1);
                        });
                        btnPage.data("page", pageN + 1);
                    }
                });
            };
            var _sendRequest = function (userId, type) {
                var dialogType = UMDialogs.TYPE_ADD_FRIEND;
                if (type == 2) {
                    dialogType = UMDialogs.TYPE_SEND_MESSAGE;
                }
                var dialog = UMDialogs.build(dialogType, {
                    user_target_id: userId,
                    user_info_url: oThis.pmUrl.userInfoUrl,
                    add_friend_url: oThis.pmUrl.addFriendUrl,
                    send_message_url: oThis.pmUrl.sendMessageUrl
                });
                dialog.show();
            };
            showContent(1);
        },
        //"个人主页"，最近访客
        showPmVisitor: function () {
            var oThis = this;
            var userInfo = this.pmUserInfo;
            var htmlStr = '\
                <div class="um-pmTitle">\
                    <span class="title-name">最近访客</span>\
                </div>\
                <div class="J-content um-pmContent">\
                \
                </div>';
            var main = this.$oPageSide.find('.J-pmVisitor-block');
            main.html(htmlStr);
            var content = main.find(".J-content");
            var showContent = function () {
                var htmlLabel = '';
                ajax({
                    url: oThis.pmUrl.getRecentVisitorsDataUrl,
                    data: {
                        user_id: userInfo.id
                    },
                    success: function (res) {
                        var data = res.data.aRecentVisitors;
                        if (data.length == 0) {
                            content.html('<div class="noData">暂时没有可能认识的人喔</div>');
                            return;
                        }
                        for (var i = 0, n = data.length; i < n; i++) {
                            var dataItem = data[i];
                            var addFriendHtml = dataItem.is_my_friend == 0 ? '<div class="J-addFriend addFriend" data-id="' + dataItem.id + '"><i>+</i>好友</div>' : '';
                            htmlLabel += '<div class="J-user-item user-item">\
                                ' + Ui1.buildProfile(dataItem, true, {addClass: 'circle'}) + '\
                                <div class="name">' + Ui1.buildVipName(dataItem) + '</div>\
                                ' + addFriendHtml + '\
                            </div>';
                        }
                        content.html(htmlLabel);
                        content.find('.J-addFriend').on('click', function () {
                            $this = $(this);
                            _sendRequest($this.data('id'), 1);
                        });
                    }
                });
            };
            var _sendRequest = function (userId, type) {
                var dialogType = UMDialogs.TYPE_ADD_FRIEND;
                if (type == 2) {
                    dialogType = UMDialogs.TYPE_SEND_MESSAGE;
                }
                var dialog = UMDialogs.build(dialogType, {
                    user_target_id: userId,
                    user_info_url: oThis.pmUrl.userInfoUrl,
                    add_friend_url: oThis.pmUrl.addFriendUrl,
                    send_message_url: oThis.pmUrl.sendMessageUrl
                });
                dialog.show();
            };
            showContent();
        },
        //"个人主页"，话题
        showPmTopic: function () {
            var oThis = this;
            var userInfo = this.pmUserInfo;
            var htmlStr = '\
                <div class="um-pmTitle">\
                    <span class="title-name">话题</span>\
                </div>\
                <div class="J-content um-pmContent">\
                \
                </div>';
            var main = this.$oPageSide.find('.J-pmTopic-block');
            main.html(htmlStr);
            var content = main.find(".J-content");
            ajax({
                url: oThis.pmUrl.getHotTopicDataUrl,
                data: {
                    user_id: userInfo.id
                },
                success: function (res) {
                    var data = res.data.aHotTopicList;
                    if (data.length == 0) {
                        content.html('<div class="noData">暂时没有可能认识的人喔</div>');
                        return;
                    }
                    var htmlLabel = '<ul>';
                    for (var i = 0, n = data.length; i < n; i++) {
                        var dataItem = data[i];
                        htmlLabel += '<li>\
		                <a href="' + dataItem.url + '" target="_blank" title="' + dataItem.title + '">' + dataItem.title + '</a>\
		                <span class="date">' + Ui1.timeToAgo(dataItem.create_time) + '</span>\
	                    </li>';
                    }
                    htmlLabel += '</ul>';
                    content.html(htmlLabel);
                }
            });

        }
    };

    function _showMarkRankList(page) {
        self.markRankpage = page;
        ajax({
            url: self.markRankListUrl,
            data: {
                page: page,
                group_type: $('.J-mark-man-select').attr('data-type'),
                order_type: $('.J-mark-date-select').attr('data-type')
            },
            success: function (aResult) {
                if (aResult.status == 1) {
                    _appendMarkRankList(aResult.data.aMarkRangkList);
                    if (self.markRankpage != 1 && aResult.data.aMarkRangkList.length == 0) {
                        --self.markRankpage;
                    }
                } else {
                    UBox.show(aResult.msg, aResult.status);
                }
            }
        });
    }

    function _appendMarkRankList(aData) {
        var htmlStr = '';
        if (aData.length == 0) {
            if (self.markRankpage == 1) {
                $('.J-mark-rank-list-wraper').html('<tr><td colspan="3"><center>暂无数据</center></td></tr>');
            } else {
                UBox.show('没有下一页了', -1);
            }
            return;
        }
        for (var i in aData) {
            var oTemp = aData[i];
            var classStr = '';
            if (parseInt(oTemp.rankNumber) <= 3) {
                classStr = 'active';
            }
            htmlStr += '\
				<tr class="' + classStr + '">\
					<td class="user">\
						<span class="num">' + oTemp.rankNumber + '</span>\
						' + Ui1.buildProfile(oTemp.user_info, true, {addClass: 'circle'}) + '\
						' + Ui1.buildVipName(oTemp.user_info, true) + '\
					</td>\
					<td class="days">' + oTemp.mark_continuous + '</td>\
					<td class="gather">' + oTemp.mark_total + '</td>\
				</tr>\
			';
        }
        self.$oPageSide.find('.J-mark-rank-list-wraper').html(htmlStr);
        _bindShowUserCard($('.J-mark-rank-list-wraper img'));
    }

    function _mark(o) {
        if (o.hasClass('disabled')) {
            return;
        }
        ajax({
            url: self.markUrl,
            data: {},
            success: function (aResult) {
                if (aResult.status == 1) {
                    self.showMark();
                } else {
                    UBox.show(aResult.msg, aResult.status);
                }
            }
        });
    }

    function _appendRecommendTopic(aData) {
        var htmlStr = '';
        for (var i in aData) {
            var oTemp = aData[i];
            var url = self.topicDetailUrl.replace('_topicId', oTemp.id);
            htmlStr += '\
				<li>\
					<a href="' + url + '"><span class="disc">' + oTemp.read_times + '</span>' + oTemp.title + '</a>\
				</li>\
			';
        }
        htmlStr = '\
			<div class="hd">\
				<h2 class="title">推荐话题</h2>\
					<a href="' + self.bbsHomeUrl + '" class="sp" title="进入话题">进入话题</a>\
			</div>\
			<div class="bd">\
				<ul>' + htmlStr + '</ul>\
			</div>\
		';

        self.$oPageSide.find('.J-topic-block').html(htmlStr);
        self.$oPageSide.find('.J-topic-block').show();
    }

    function _appendProbablyFriendList(aData) {
        var htmlStr = '';
        for (var i in aData) {
            var oTemp = aData[i];
            htmlStr += '\
				<li>\
					<div class="head">\
						' + Ui1.buildProfile(oTemp, true, {addClass: 'circle'}) + '\
					</div>\
					<div class="name">\
						' + Ui1.buildVipName(oTemp, true) + '\
					</div>\
					<div class="fribtn">\
						<a href="#fricheck" data-toggle="modal" class="J-add-probably-friend" data-id="' + oTemp.id + '"><i>+</i>好友</a>\
					</div>\
				</li>\
			';
        }
        htmlStr = '\
			<div class="hd">\
				<h2 class="title">可能认识的人</h2>\
				<a href="javascript:;" class="J-refresh-probably-friend sp">\
					<i class="ico ico_refresh"></i>\
				</a>\
			</div>\
			<div class="bd">\
				<ul class="J-probably-friend-list-wraper list-unstyled p-list">\
					<!-- <li class="nodata">\
						暂时没有可能认识的人喔\
					</li> -->\
					' + htmlStr + '\
				</ul>\
			</div>\
		';

        self.$oPageSide.find('.J-problely-block').html(htmlStr);
        self.$oPageSide.find('.J-problely-block').show();
        self.$oPageSide.find('.J-refresh-probably-friend').unbind();
        self.$oPageSide.find('.J-refresh-probably-friend').on('click', function () {
            self.showProbably();
        });
        self.$oPageSide.find('.J-add-probably-friend').unbind();
        self.$oPageSide.find('.J-add-probably-friend').on('click', function () {
            _bindAddFriendDialog($(this).attr('data-id'));
        });
        _bindShowUserCard(self.$oPageSide.find('.J-probably-friend-list-wraper img'));
    }

    function _appendRecentExchangegRecord(aData) {
        var htmlStr = '',
            recommandHtmlStr = '',
            recentRecordHtmlStr = '';
        for (var i in aData.aRecommandList) {
            var oTemp = aData.aRecommandList[i];
            var url = self.exchangeGoodsDetailUrl.replace('_goodsId', oTemp.id);
            recommandHtmlStr += '\
				<li>\
					<a href="' + url + '">\
						' + Ui1.buildImage(App.getUrl('resource') + oTemp.recommand_image) + '\
					</a>\
					<div class="desc">\
						<span class="price">兑换价格：<b>' + oTemp.gold + '</b>金币</span>\
						<a href="' + url + '" target="_blank" class="btn">去兑换</a>\
					</div>\
				</li>\
			';
        }
        for (var i in aData.aRecentRecord) {
            var oTemp = aData.aRecentRecord[i];
            var url = self.exchangeGoodsDetailUrl.replace('_goodsId', oTemp.id);
            recentRecordHtmlStr += '\
				<li>\
					<a href="javascript:;" class="img">\
						' + Ui1.buildImage(App.getUrl('resource') + oTemp.goods_info.profile) + '\
					</a>\
					' + Ui1.buildVipName(oTemp.user_info, true) + '\
					兑换了\
					<a href="' + url + '" class="text">' + oTemp.goods_info.name + '</a>\
				</li>\
			';
        }

        htmlStr = '\
			<div class="hd">\
				<h2 class="title">兑换商城</h2>\
				<a href="' + self.exchangeHomeUrl + '" class="sp" title="进入兑换商城">进入兑换商城</a>\
			</div>\
			<div class="bd">\
				<div class="exchange-slide" id="exchangeSlide">\
					<ul class="list-unstyled slide-main">' + recommandHtmlStr + '</ul>\
					<ul class="list-unstyled slide-nav">\
						<li class="active">•</li>\
						<li>•</li>\
						<li>•</li>\
					</ul>\
				</div>\
				<div class="exchange-list">\
					<ul class="list-unstyled infoList">' + recentRecordHtmlStr + '</ul>\
				</div>\
			</div>\
		';
        self.$oPageSide.find('.J-exchange-block').html(htmlStr);
        self.$oPageSide.find('.J-exchange-block').show();
        // 兑换商城上

        setTimeout(function () {
            jQuery(".exchange-slide").slide({
                titCell: ".slide-nav li",
                mainCell: ".slide-main",
                effect: "left",
                delayTime: 300,
                titOnClassName: "active",
                autoPlay: true
            });
        }, 1000);
        // 兑换商城下
        jQuery(".exchange-list").slide({
            mainCell: ".infoList",
            autoPlay: true,
            effect: "topMarquee",
            vis: 4,
            interTime: 50
        });
    }

    function _appendGoldRankingList(type, aData) {
        var htmlStr = '',
            tabAllClassStr = '',
            tabFriendClassStr = '';
        if (type == 'all') {
            tabAllClassStr = 'on';
        } else {
            tabFriendClassStr = 'on';
        }
        for (var i in aData) {
            var oTemp = aData[i],
                activeClass = '',
                rank = parseInt(i) + 1;

            if (rank <= 3) {
                activeClass = 'active';
            }
            htmlStr += '\
				<li class="' + activeClass + '">\
					<div class="user">\
						<span class="num">' + rank + '</span>\
						' + Ui1.buildProfile(oTemp.user_info, true, {addClass: 'circle'}) + '\
						' + Ui1.buildVipName(oTemp.user_info, true) + '\
					</div>\
					<div class="level">LV' + oTemp.level + '</div>\
					<div class="gold"><em>' + oTemp.gold + '</em>金币</div>\
				</li>\
			';
        }
        htmlStr = '\
			<div class="hd">\
				<ul class="list-unstyled tab-nav">\
				  <li class="' + tabFriendClassStr + '"><a href="javascript:;" class="J-gold-rank-tab" data-type="friend">好友排行</a>|</li>\
				  <li class="' + tabAllClassStr + '"><a href="javascript:;" class="J-gold-rank-tab" data-type="all">世界排行</a></li>\
				</ul>\
				<!--<a href="javascript:;" class="sp" title="更多排行">更多排行</a>-->\
			</div>\
			<div class="bd">\
				<div class="tab-pal">\
					<ul class="J-gold-rank-list-wraper list-unstyled">' + htmlStr + '</ul>\
				</div>\
			</div>\
		';
        self.$oPageSide.find('.J-rank-block').html(htmlStr);
        self.$oPageSide.find('.J-rank-block').show();
        self.$oPageSide.find('.J-gold-rank-tab').unbind();
        self.$oPageSide.find('.J-gold-rank-tab').on('click', function () {
            self.showGoldRanking($(this).attr('data-type'));
        });
        _bindShowUserCard(self.$oPageSide.find('.J-gold-rank-list-wraper img'));
    }

    function _bindAddFriendDialog(userId) {
        var oDialog = UMDialogs.build(UMDialogs.TYPE_ADD_FRIEND, {
            user_target_id: userId,
            user_info_url: self.userInfoUrl,
            add_friend_url: self.applyFriendUrl,
            send_message_url: self.sendMessageUrl
        });
        oDialog.show();
    }

    function _bindShowUserCard(oDom) {
        UMDialogs.listenToShowStudentInfo(oDom, {
            user_info_url: self.userInfoUrl,
            add_friend_url: self.applyFriendUrl,
            send_message_url: self.sendMessageUrl
        });
    }

    var self = win.PageSide;

})(jQuery, window);
