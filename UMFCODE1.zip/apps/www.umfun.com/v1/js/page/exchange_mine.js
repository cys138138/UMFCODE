(function($,win){
	win.ExchangeMinePage = {
		homeUrl : '',
		mineUrl : '',
		topGoodsListUrl : '',
		goodsDetailUrl:'',
		aGoodsList : [],
		goodsPageStr : '',
		$container : null,
		show : function(){
			var _content = '<div class="main">\
					<div class="home-mods exchange-main">\
						<div class="exchange-nav">\
							<a href="' + this.homeUrl + '">兑换首页</a>\
							<a href="' + this.mineUrl + '" class="active">我的兑换</a>\
						</div>\
						<div class="bd">' + _createGoodsListHtml(this.aGoodsList) + '<div class="mtopic-pagination">' + this.goodsPageStr + '</div>\
						</div>\
					</div>\
				</div>\
				<div class="side">' + _createTopGoodsHtml() + '</div>';
			
			this.$container.append(_content);
			_$container = this.$container;
			
			//初始化界面
			_initInterface();
		}
	};
	/**
	 * 初始化界面
	 */
	function _initInterface(){
		//加载top10
		ajax({
			url : _self.topGoodsListUrl,
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillTopGoodsHtml(aResult.data);
				}
			}
		});
	}
		
	/**
	 * 构建Top兑换
	 */
	function _createTopGoodsHtml(){
		var _body = '<div class="home-mods um-mexchangtop">\
			<div class="hd">\
				<h2 class="title">兑换TOP&nbsp;<em>10</em></h2>	\
			</div>\
			<div class="bd">\
				<div class="exchang-list">\
					<ul class="list-unstyled J-top">\
					</ul>\
				</div>\
			</div>\n\
		</div>';
		return _body;
	}
	
	/**
	 * 填充Top兑换数据 
	 * @param {Array} aTopGoodsList Top商品列表
	 */
	function _fillTopGoodsHtml(aTopGoodsList){
		var _count = 0;
		for(var i in aTopGoodsList){
			var _goods = aTopGoodsList[i];
			_count++;
			if(_count<=3){
				_$container.find('.J-top').append('\
					<li class="top">\
							<div class="num">' + _count + '</div>\
							<div class="img">\
								<a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '" class="avatar">' + Ui1.buildImage(_resourceUrl + _goods.profile, undefined, {width : 100, heigth : 100}) + '\
								</a>\
							</div>\
							<div class="info">\
								<p class="title"><a title="' + _goods.name + '" title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '">' + _goods.name + '</a></p>\
								<p>兑换<em>' + _goods.sales_volume + '</em>件</p>\
								<p><em>' + _goods.gold + '</em>金币</p>\
								<p><em>' + _goods.level + '</em>等级以上</p>\
							</div>\
						</li>\
				');
			}else{							
				_$container.find('.J-top').append('\
					<li>\
							<div class="num">' + _count + '</div>\
							<div class="img">\
								<a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '" class="avatar">' + Ui1.buildImage(_resourceUrl + _goods.profile, undefined, {width : 100, heigth : 100}) + '\
								</a>\
							</div>\
							<div class="info">\
								<p class="title"><a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '">' + _goods.name + '</a></p>\
							</div>\
						</li>\
				');
			}	
		}
		_$container.find('.J-top li:last').addClass('last');
	}
	
	/**
	 * 构建商品列表页面
	 * @param {Array} aGoodsList 兑换商品列表
	 * @returns {String}
	 */
	function _createGoodsListHtml(aGoodsList){
		var _head = '<div class="exchange-my-list">';
		var _tail = '</div>';
		var _body = '';
		if(aGoodsList.length == 0){
			_body = '<div class="nodata">\
						还没有<strong>兑换记录</strong>哦<br>\
						赶快去兑换你喜欢的礼品吧！\
					</div>';
		}else{
			var _head = '<div class="exchange-my-list"><ul class="list-unstyled">';
			var _tail = '</ul></div>';
			for(var i in aGoodsList){
				var _aGoods = aGoodsList[i];
				if(!_aGoods.goods_info){
					continue;
				}
				var _statusStr = '待发货';
				var _express_company = _aGoods.express_company;
				var _express_number = _aGoods.express_number;
				if(_aGoods.status == 2){
					_statusStr = '已发货';
				}
				if($.trim(_express_company) === ''){
					_express_company = '--';
				}
				if($.trim(_express_number) === ''){
					_express_number = '--';
				}
				var _payResult ='';
				switch(parseInt(_aGoods.pay_type)){
					case 1:
						_payResult ='<em>' + _aGoods.gold + '</em>金币';
						break;
					case 2:
						_payResult += '<em>' + _aGoods.gold_ub_ub + '</em>U币';
						_payResult += _aGoods.gold_ub_gold != 0? '<br><em>' + _aGoods.gold_ub_gold + '</em>金币' : '';
						break;
				}
				_body += '<li>\
							<div class="item-1">\
								<div class="item-img">\
									<a target="_blank" title="' + _aGoods.goods_info.name + '" href="' + _self.goodsDetailUrl.replace('_goodsId', _aGoods.goods_info.id) + '">' + Ui1.buildImage(_resourceUrl + _aGoods.goods_info.profile, undefined, {width : 100, heigth : 100}) + '</a>\
								</div>\
								<div class="item-info">\
									<div class="item-title">\
										<a target="_blank" href="' +  _self.goodsDetailUrl.replace('_goodsId', _aGoods.goods_info.id) + '">'+ _aGoods.goods_info.name + '</a>\
									</div>\
									<div class="item-time">' + Ui1.date('Y/m/d H:i', _aGoods.create_time) + '</div>\
								</div>\
							</div>\
							<div class="item-2">\
								<div class="item-price">'+ _payResult +'</div>\
							</div>\
							<div class="item-3">\
								<div class="item-status">' + _statusStr + '</div>\
							</div>\
							<div class="item-4">\
								<div class="item-company">物流公司：' + _express_company + '</div>\
								<div class="item-id">单号：' + _express_number + '</div>\
							</div>\
							<div class="item-5">\
								<div class="item-school">\
									<p>' + _aGoods.address + '</p>\
								</div>\
								<div class="vh"></div>\
							</div>\
						</li>';
			}
		}
		return _head + _body + _tail;
	}

	var _resourceUrl = App.getUrl('resource');
	var _self = win.ExchangeMinePage;
	var _$container = null;
})(jQuery,window);

	