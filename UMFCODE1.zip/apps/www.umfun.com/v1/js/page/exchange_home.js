(function($,win){
	win.ExchangeHomePage = {
		homeUrl : '',
		goodsDetailUrl:'',
		threadDetailUrl:'',
		mineUrl : '',
		onlyMine : 0,
		categoryId : 0,
		sortBy : 0,
		aGoodsList : [],
		goodsPageStr : '',
		aExchangeCategoryList : [],
		aRecommendList : [],
		topGoodsListUrl : '',
		exchangedListUrl : '',
		goodsSupportUrl : '',
		threadListUrl : '',
		threadPage : 1,
		forumUrl : '',
		THREAD_MAX_PAGES : 1,
		$container : null,
		show : function(){
			var _content = '<div class="main">\
							<div class="home-mods exchange-main">\
								<div class="exchange-nav">\
									<a href="' + this.homeUrl + '" class="active">兑换首页</a>\
									<a href="' + this.mineUrl + '">我的兑换</a>\
								</div>\
								<div class="bd">' + _createCommendGoodsHtml(this.aRecommendList) + _createGoodsFilterMenuHtml(this.aExchangeCategoryList, this.onlyMine) + _createGoodsListHtml(this.aGoodsList) + '<div class="mtopic-pagination">' + this.goodsPageStr + '</div>\
								</div>\
							</div>\
						</div>\
						<div class="side">\
							<!-- module -->' + _createExchangedHtml() + '<!-- end module -->\
							<!-- module -->' + this.bannerRightHtml + '<!-- end module -->\n\
							<!-- module -->' + _createThreadHtml() + '<!-- end module -->\n\
							<!-- module -->' + _createTopGoodsHtml() + '<!-- end module -->\
						</div>';
			this.$container.append(_content);
			_$container = this.$container;

			//初始化界面
			_initInterface();
			//绑定事件
			_bindEvent();
		}
	};

	/**
	 * 构建商品列表页面
	 * @param {Array} aGoodsList 兑换商品列表
	 * @returns {String}
	 */
	function _createGoodsListHtml(aGoodsList){
		var _head = '<div class="product-list">\
					<ul class="list-unstyled">';
		var _tail = '</ul></div>';
		var _body = '';
		for(var i in aGoodsList){
			var _aGoods = aGoodsList[i];
			var _supportStr = '<i class="ico-exchange-like-ghost"></i>';
			if(_aGoods.is_supported == 1){
				_supportStr = '<i class="ico-exchange-like"></i>';
			}
			
			var _activityStr = '', _goldStr = '';

			//打折判断
			if(_aGoods['discount_statu'] == 2){	//即将打折
				_goldStr = '<em>' + _aGoods.gold + '</em>金币';
				_activityStr = '<div class="activity-content"><span class="discount">？折</span><br/><span class="date">' + Ui1.date('n月j日', _aGoods['discount_start_time']) + '<br/>开始</span></div>';
			}else if(_aGoods['discount_statu'] == 3){	//打折中
				_activityStr = '<div class="activity-content"><span class="discount">' + _aGoods['discount']/10 + '折</span><br/><span class="date">' + Ui1.date('n月j日', _aGoods['discount_end_time']) + '<br/>结束</span></div>';
				_goldStr = '<em>' + _aGoods['after_discount_gold'] + '</em>金币<span class="origin-price">' + _aGoods.gold + '金币</span>'
			}else{
				var flag1 = _aGoods.gold !=0 ? 1:0;
				var flag2 = _aGoods.gold_ub_gold - _aGoods.gold_ub_ub !=0? 2:0;
				var flag = flag1+flag2;
				switch(flag){
					case 1:
						_goldStr = '<em>' + _aGoods.gold + '</em>金币';
						_goldStr += '<div class="gold-footer"></div>'
						break;
					case 2:
						_goldStr = _aGoods.gold_ub_ub !=0 ?'<em>' + _aGoods.gold_ub_ub + '</em>U币' :'';
						_goldStr += _aGoods.gold_ub_gold !=0 ?'+<em>' + _aGoods.gold_ub_gold + '</em>金币':'';
						_goldStr += '<div class="gold-footer"></div>'
						break;
					case 3:
						_goldStr = '<em>' + _aGoods.gold + '</em>金币';
						_goldStr += '<span style="margin: 0 5px;color:black">或</span>';
						var UbString = _aGoods.gold_ub_ub !=0 ?'<em>' + _aGoods.gold_ub_ub + '</em>U币' :'';
						var GoldString = _aGoods.gold_ub_gold !=0 ?'+<em>' + _aGoods.gold_ub_gold + '</em>金币':'';
						_goldStr += '<div class="gold-footer">'+UbString + GoldString+'</div>';
						break;
				}
			}

			_body += '<li>\
					<a title="' + _aGoods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId',_aGoods.id) + '">\
						<div class="product-img">\
						' + Ui1.buildImage(_resourceUrl + _aGoods.profile, undefined, {width : 214, heigth : 214}) + _activityStr + '\
						</div>\
					</a>\
					<div class="product-info">\
						<a target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _aGoods.id) + '" data-toggle="modal">\
							<div class="title" title="' + _aGoods.name + '">' + _aGoods.name + '</div>\
						</a>\
						<div class="p1">\
							<span class="gold">' + _goldStr + '</span>\
						</div>\
						<div class="p2 J-like" data-id="' + _aGoods.id + '">\
							<a href="javascript:;">\
								<span class="J-support">' + _aGoods.support + '</span>&nbsp; 人喜欢&nbsp;' + _supportStr + '\
								<span class="gone">已兑换<em>' + _aGoods.sales_volume + '</em></span>\
							</a>\
						</div>\
					</div>\
				</li>';
		}
		return _head + _body + _tail;
	}

	/**
	 * 构建商品筛选页面
	 * @param {Array} aExchangeCategoryList 兑换商品分类列表
	 * @param {Number} onlyMine 是否只显示我能兑换的商品 0 不是 1 是
	 * @returns {String}
	 */
	function _createGoodsFilterMenuHtml(aExchangeCategoryList, onlyMine){
		var _head = '<div class="product-nav">\
					<table cellspacing="0" border="0" style="width:709px;" rules=rows>\
						<tr>\
							<td class="text">分类</td>\n\
							<td><a href="javascript:;" class="J-category" data-id="0">全部</a></td>';
		var _body = '';
		var _count = 0;
		for(var i in aExchangeCategoryList){
			_count++;
			var aCategory = aExchangeCategoryList[i];
			if(_count === aExchangeCategoryList.length ){
				_body += '<td style="border-right:1px solid #e8e8e8"><a  class="J-category" href="javascript:;" data-id="' + aCategory.id + '">' + aCategory.name + '</a></td>';
			}else{
				_body += '<td><a  class="J-category" href="javascript:;" data-id="' + aCategory.id + '">' + aCategory.name + '</a></td>';
			}
		}
		var _tail = '</tr>\
						<tr>\
							<td class="text">排序</td>\
							<td><a href="javascript:;" class="J-sort" data-id="0">默认</a></td>\
							<td><a href="javascript:;" class="J-sort" data-id="1">金币</a></td>\
							<td><a href="javascript:;" class="J-sort" data-id="2">等级</a></td>\
							<td><a href="javascript:;" class="J-sort" data-id="3">兑换</a></td>\
							<td><a href="javascript:;" class="J-sort" data-id="4">人气</a></td>\
							<td><a href="javascript:;" class="J-sort" data-id="5">上架时间</a></td>\
							<td class="opts" colspan="4">\
								<input type="checkbox" class="J-only-mine" name="enabledExchange" id="enabledExchange">\
								<label for="enabledExchange">仅显示我能兑换的</label>\
							</td>\
						</tr>\
					</table>\
				</div>';
		return _head + _body + _tail;
	}

	/**
	 * 构建推荐商品页面
	 * @param {Array} aRecommendList 推荐商品列表
	 * @returns {String}
	 */
	function _createCommendGoodsHtml(aRecommendList){
		var _head = '<div class="product-group">';
		var _body = '';
		for(var i in aRecommendList){
			var recommend = aRecommendList[i];

			var _width = 0;
			var _height = 0;
			if(recommend.position == 1){
				_width = 530;
				_height = 300;
			}else if(recommend.position == 2){
				_width = 177;
				_height = 288;
			}else{
				_width = 236;
				_height = 170;
			}

			_body += '<a title="' + recommend.goods_info.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', recommend.goods_info.id) + '" class="product-' + recommend.position + '">' + Ui1.buildImage(_resourceUrl + recommend.profile, undefined, {width : _width, heigth : _height}) + '</a>';
		}
		var _tail = '</div>';
		return _head + _body + _tail;
	}

	/**
	 * 构建Top兑换
	 */
	function _createTopGoodsHtml(){
		var _body = '<div class="home-mods um-mexchangtop">\
			<div class="hd">\
				<h2 class="title">兑换TOP&nbsp;<em>10</em></h2>	\
			</div>\
			<div class="bd">\
				<div class="exchang-list">\
					<ul class="list-unstyled J-top">\
					</ul>\
				</div>\
			</div>\n\
		</div>';
		return _body;
	}

	/**
	 * 填充Top兑换数据
	 * @param {Array} aTopGoodsList Top商品列表
	 */
	function _fillTopGoodsHtml(aTopGoodsList){
		var _count = 0;
		for(var i in aTopGoodsList){
			var _goods = aTopGoodsList[i];
			_count++;
			if(_count<=3){
				var goodsMsg = "";
				if(_goods.gold_ub_gold - _goods.gold_ub_ub == 0){
					goodsMsg = '<p><em>' + _goods.level + '</em>等级以上</p>';
				}else{
					var ubMsg = _goods.gold_ub_ub != 0? ('<em>'+_goods.gold_ub_ub +'</em>U币'):'';
					var goldMsg = _goods.gold_ub_gold != 0? ('<em>'+_goods.gold_ub_gold +'</em>金币'):'';
					goodsMsg = '<p>'+goldMsg+ubMsg+'</p>';
				}
				_$container.find('.J-top').append('\
					<li class="top">\
							<div class="num">' + _count + '</div>\
							<div class="img">\
								<a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '" class="avatar">' + Ui1.buildImage(_resourceUrl + _goods.profile, undefined, {width : 100, heigth : 100}) + '\
								</a>\
							</div>\
							<div class="info">\
								<p class="title" title="' + _goods.name + '"><a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '">' + _goods.name + '</a></p>\
								<p>兑换<em>' + _goods.sales_volume + '</em>件</p>\
								<p><em>' + _goods.gold + '</em>金币</p>\
								'+goodsMsg+'\
							</div>\
						</li>\
				');
			}else{
				_$container.find('.J-top').append('\
					<li>\
							<div class="num">' + _count + '</div>\
							<div class="img">\
								<a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '" class="avatar">' + Ui1.buildImage(_resourceUrl + _goods.profile, undefined, {width : 100, heigth : 100}) + '\
								</a>\
							</div>\
							<div class="info">\
								<p class="title"><a title="' + _goods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _goods.id) + '">' + _goods.name + '</a></p>\
							</div>\
						</li>\
				');
			}
		}
	}

	/**
	 * 构建推荐话题
	 */
	function _createThreadHtml(){
		var body = '<div class="home-mods um-mtopic">\
			<div class="hd">\
				<h2 class="title">相关话题</h2>\
				<a target="_blank" href="' + _self.forumUrl + '" class="sp" title="进入话题">进入话题</a>\
			</div>\
			<div class="bd">\
				<ul class="J-thread">\
				</ul>\
			</div>\
			<div class="ft">\
				<div class="opts J-dataPage" data-page="1">\
					<a href="javascript:;" class="J-thread-prev um-btn-ghost um-btn-default um-btn-xs">上一页</a>\
					<a href="javascript:;" class="J-thread-next um-btn-ghost um-btn-default um-btn-xs active">下一页</a>\
				</div>\
			</div>\
		</div>';
		return body;
	}

	/**
	 * 填充推荐话题
	 * @param {Array} aThreadList 推荐话题列表
	 */
	function _fillThreadHtml(aThreadList){
		_$container.find('.J-thread li').detach();

		if(aThreadList.length<1){
			_$container.find('.J-thread').append('<li class="nodata">没有推荐话题</li>');
			return ;
		}
		var offset = (_self.threadPage - 1) * 5;
		for(var i in aThreadList){
			var thread = aThreadList[i];
			offset++;
			_$container.find('.J-thread').append('\
					<li>\
						<a target="_blank" href="' + _self.threadDetailUrl.replace('_topicId',thread.id) + '"><span class="disc">' + offset + '</span>' + thread.title + '</a>\
					</li>');
		}

		//更新按钮显示
		if(_self.threadPage <=1){
			_$container.find('.J-thread-prev').removeClass('active');
		}else{
			_$container.find('.J-thread-prev').addClass('active');
		}

		if(aThreadList.length < 5){
			_$container.find('.J-thread-next').removeClass('active');
		}else{
			_$container.find('.J-thread-next').addClass('active');
		}

		//最大页判断
		if(_$container.find('.J-dataPage').data('page') >= _self.THREAD_MAX_PAGES){
			_$container.find('.J-thread-next').removeClass('active');
		}
	}

	/**
	 * 构建正在兑换
	 */
	function _createExchangedHtml(){
		var body = '<div class="home-mods um-mexchanging">\
			<div class="hd">\
				<h2 class="title">正在兑换</h2>	\
			</div>\
			<div class="bd">\
				<div class="exchang-list">\
					<ul class="list-unstyled J-exchanged">\
					</ul>\
				</div>\
			</div>\
		</div>';
		return body;
	}

	/**
	 * 填充正在兑换
	 * @param {Array} aExchangedRecordList 正在兑换商品列表
	 */
	function _fillExchangedHtml(aExchangedRecordList){
		_$container.find('.J-exchanged li').detach();
		for(var i in aExchangedRecordList){

			var exchangedRecord = aExchangedRecordList[i];
			_$container.find('.J-exchanged').append('\
			<li>\
				<div class="img">\
					<a title="' + exchangedRecord.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', exchangedRecord.goods_id) + '" class="avatar">' + Ui1.buildImage(_resourceUrl + exchangedRecord.profile, undefined, {width : 100, heigth : 100}) +'\
					</a>\
				</div>\
				<div class="info">' + Ui1.buildVipName(exchangedRecord.user_info) + '<p>兑换了<a target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', exchangedRecord.goods_id) + '">' +  exchangedRecord.name + '</a></p>\
				</div>\
			</li>');
		}
	}

	/**
	 * 更新推荐话题
	 * @param {Number} currentPage 当前页码
	 */
	function _updateThreadHtml(currentPage){
		ajax({
			url : _self.threadListUrl,
			data : {
				page : currentPage
			},
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillThreadHtml(aResult.data);
				}
			}
		});
	}

	/**
	 * 初始化界面
	 */
	function _initInterface(){
		_$container.find('.J-category').each(function(i, n){
			if(_self.categoryId == $(this).data('id')){
				$(this).addClass('active');
			}
		});

		_$container.find('.J-sort').each(function(i, n){
			if(_self.sortBy == $(this).data('id')){
				$(this).addClass('active');
			}
		});

		if(_self.onlyMine == 1){
			_$container.find('.J-only-mine').attr('checked','checked');
		}

		//加载正在兑换
		ajax({
			url : _self.exchangedListUrl,
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillExchangedHtml(aResult.data);
				}
			}
		});

		//加载推荐话题
		ajax({
			url : _self.threadListUrl,
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillThreadHtml(aResult.data);
				}
			}
		});

		//加载top10
		ajax({
			url : _self.topGoodsListUrl,
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillTopGoodsHtml(aResult.data);
				}
			}
		});

		//推荐话题 上一页
		$('.J-thread-prev').on('click', function(){
			if(! $(this).hasClass('active')){
				return;
			}
			if(_self.threadPage > 1){
				_self.threadPage--;
				_$container.find('.J-dataPage').data('page', _self.threadPage);
				_updateThreadHtml(_self.threadPage);
			}
		});

		//推荐话题 下一页
		_$container.find('.J-thread-next').on('click', function(){
			if(! $(this).hasClass('active')){
				return;
			}
			_self.threadPage++;
			_$container.find('.J-dataPage').data('page', _self.threadPage);
			_updateThreadHtml(_self.threadPage);
		});
	}

	/**
	 * 绑定事件
	 */
	function _bindEvent(){
		//分类
		_$container.on('click', '.J-category', function(){
			_$container.find('.J-category.active').removeClass('active');
			$(this).addClass('active');
			_filterGoodsList();
		});

		//排序
		_$container.on('click', '.J-sort', function(){
			_$container.find('.J-sort.active').removeClass('active');
			$(this).addClass('active');
			_filterGoodsList();
		});

		//仅显示我能兑换的
		_$container.on('click', '.J-only-mine', function(){
			_filterGoodsList();
		});

		//点击喜欢
		_$container.on('click', '.J-like', function(){
			if($(this).find('.ico-exchange-like').size()>0){
				UBox.show('您已经喜欢过了哦！', -1);
				return;
			}
			_support($(this), $(this).data('id'));
		});
	}

	/**
	 * 点击喜欢商品
	 * @param {Number} id 商品ID
	 */
	function _support($this, goodsId){
		ajax({
			url : _self.goodsSupportUrl,
			data : {
				id : goodsId
			},
			success : function (aResult) {
				if (aResult.status == 1) {
					var num = parseInt($this.find('.J-support').text());
					$this.find('.J-support').text(num + 1);
					$this.find('.ico-exchange-like-ghost').attr('class', 'ico-exchange-like');
				}else if(aResult.status == 0){
					UBox.show('你已经赞过一次了哦！', -1);
				}
			}
		});
	}

	/**
	 * 获取符合筛选兑换商品的数据
	 */
	function _filterGoodsList(){
		var _categoryId = _$container.find('.J-category.active').data('id');
		var _sortBy = _$container.find('.J-sort.active').data('id');
		var _onlyMine = Number(_$container.find('.J-only-mine')[0].checked);
		var _urlParams = '?category_id=' + _categoryId + '&sort_by=' + _sortBy + '&only_mine=' + _onlyMine;
		window.location.href = _self.homeUrl + _urlParams;
	}

	var _resourceUrl = App.getUrl('resource');
	var _self = win.ExchangeHomePage;
	var _$container = null;
})(jQuery,window);
