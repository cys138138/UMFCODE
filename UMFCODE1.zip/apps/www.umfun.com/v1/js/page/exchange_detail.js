(function($,win){
	win.ExchangeDetailPage = {
		homeUrl : '',
		mineUrl : '',
		otherUsersListUrl : '',
		detailRecommendListUrl : '',
		goodsDetailUrl : '',
		studentInfoUrl : '',
		goodsSupportUrl : '',
		lastReciveInfoUrl : '',
		exchangeUrl : '',
		payExchangeUrl : '',
		ubExchangeUrl:'',
		exchangeGoods : null,
		$container : null,
		show : function(){
			var _likeCss = 'ico-exchange-like-ghost';
			if(this.exchangeGoods.is_supported == 1){
				_likeCss = 'ico-exchange-like';
			}
			//打折判断
			
			var _activityStr = '', _goldStr = '';
			if(this.exchangeGoods['discount_statu'] == 2){	//即将打折
				_goldStr = '<strong>' + this.exchangeGoods.gold + '</strong>金币';
				_activityStr = '<div class="activity-content"><span class="discount">？折</span><br/><span class="date">' + Ui1.date('n月j日', this.exchangeGoods['discount_start_time']) + '<br/>开始</span></div>';
			}else if(this.exchangeGoods['discount_statu'] == 3){	//打折中
				_activityStr = '<div class="activity-content"><span class="discount">' + this.exchangeGoods['discount']/10 + '折</span><br/><span class="date">' + Ui1.date('n月j日', this.exchangeGoods['discount_end_time']) + '<br/>结束</span></div>';
				_goldStr = '<strong>' + this.exchangeGoods['after_discount_gold'] + '</strong><span class="gold-label">金币</span><span class="origin-price">' + this.exchangeGoods.gold + '金币</span>';
			}else {
				var falg1 = this.exchangeGoods.gold !=0 ? 1 :0;
				var flag2 = this.exchangeGoods.gold_ub_gold - this.exchangeGoods.gold_ub_ub !=0 ? 2 :0;
				var flag = falg1+flag2;
				switch(flag){
					case 1:
						_goldStr = '<strong>' + this.exchangeGoods.gold + '</strong>金币';
						_payType=1;
						break;
					case 2:
						_goldStr += this.exchangeGoods.gold_ub_ub !=0?'<strong>'+this.exchangeGoods.gold_ub_ub + '</strong>U币</span>':'';
						_goldStr += this.exchangeGoods.gold_ub_gold !=0 ?'+<strong>' + this.exchangeGoods.gold_ub_gold + '</strong>金币':'';
						_payType=2;
						break;
					case 3:
						_goldStr += '<span data-type="1" class="J-pay-type pay-type"><strong>' + this.exchangeGoods.gold + '</strong>金币</span>';
						_goldStr += '<span data-type="2" class="J-pay-type pay-type">';
						_goldStr += this.exchangeGoods.gold_ub_ub !=0?'<strong>'+this.exchangeGoods.gold_ub_ub + '</strong>U币':'';
						_goldStr += this.exchangeGoods.gold_ub_gold !=0 ?'+<strong>' + this.exchangeGoods.gold_ub_gold + '</strong>金币':'';
						_goldStr += '</span>';
						_payType=-1;
						break;
				}

			}
				
			var _content = '<div class="main">\
				<div class="home-mods exchange-main">\
					<div class="exchange-nav">\
						<a href="' + this.homeUrl + '">兑换首页</a>\
						<a href="' + this.mineUrl + '">我的兑换</a>\
					</div>\
					<div class="bd">\
						<div class="exchange-detail-hd">\
							<div class="product-img">' + Ui1.buildImage(_resourceUrl + this.exchangeGoods.profile, undefined, {width : 350, heigth : 350, title : this.exchangeGoods.name}) + _activityStr +  '</div>\
							<div class="product-info">\
								<h1>' + this.exchangeGoods.name + '</h1>\
								<div class="product-price">\
									' + _goldStr + '\
									<a href="javascript:;" class="like J-like" data-id="' + this.exchangeGoods.id + '"><em>' + this.exchangeGoods.support + '</em>人喜欢\
										<i class="' + _likeCss + '"></i>\
									</a>\
								</div>\
								<div class="product-amount">\
									<ul class="list-unstyled">\
										<li>\
											<span class="light_des">兑换量</span>\
											<span class="exchange_num J-exchange_num">' + this.exchangeGoods.sales_volume + '</span>\
										</li>\
										<li>\
											<span class="light_des">存库量</span>\
											<span class="storage_num J-storage_num">' + this.exchangeGoods.stock + '</span>\
										</li>\
										<li>\
											<span class="light_des">等级限制</span>\
											<span class="level_limit">' + this.exchangeGoods.level + '</span>\
										</li>\
									</ul>\
								</div>\
								<div class="opts">\
									<a  data-toggle="modal" class="um-btn um-btn-error um-btn-xlg J-exchangeNow">立刻兑换</a>\
								</div>\
							</div>\
						</div>\
						<div class="exchange-detail-bd">\
							<div class="exchange-detail-bd-cont">\
								<div class="hd">\
									<h2 class="title">商品详情</h2>	\
								</div>\
								<div class="bd">\
									<div class="exchange-editor">' + this.exchangeGoods.description + '</div>\
									<div class="exchange-notic">\
										<div class="hd">\
											<h2 class="title">【兑换须知】</h2>	\
										</div>\
										<div class="exchange-notic-cont">\
											<p>全国包邮，除港澳台外</p>\
											<p>兑换用户请填写正确完整的收货地址。如因用户地址填写不正确或者不完整导致兑换商品无法送达，则视为用户主动放弃商品并不予任何形式进行补偿。</p>\
											<p>兑换后商品将于三个工作日内发送，节假日或遇到其他突发原因会稍微延迟发送。用户可于“我的兑换”中查看兑换状态和物流信息。</p>\
											<p>商品发货（超过10个工作日未发货），物流信息未更新等问题统一咨询优满分客服，联系QQ：2025928896</p>\
										</div>\
									</div>\
								</div>\
							</div>\
							<div class="exchange-detail-bd-side">\
								<!-- module -->' + _createCommendHtml() + '<!-- end module -->\
								 <!-- module -->' + _createOtherUsersHtml() + '<!-- end module -->\
							</div>\
						</div>\
					</div>\
				</div>\
			</div>';

			this.$container.append(_content);
			_$container = this.$container;
			//初始化界面
			_initInterface();
			//绑定事件
			_bindEvent();
		}
	};

	/**
	 * 初始化界面
	 */
	function _initInterface(){
		$.cookie('exchange_submit', null);
		//构建窗口代码
		_$exchangeDialog = $(_createExchangeDialogHtml());
		_$container.after(_$exchangeDialog);

		_$notEnoughGoldDialog = $(_createNotEnoughGoldDialog());
		_$notEnoughUbDialog = $(_createNotEnoughUbDialog());
		_$container.after(_$notEnoughGoldDialog);
		_$container.after(_$notEnoughUbDialog);

		_$exchangeSuccessDialog = $(_createExchangeSuccessDialog());
		_$container.after(_$exchangeSuccessDialog);

		//加载其它人
		ajax({
			url : _self.otherUsersListUrl,
			data : {
				id : _self.exchangeGoods.id
			},
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillOtherUsersHtml(aResult.data);
				}
			}
		});

		//加载兑换推荐
		ajax({
			url : _self.detailRecommendListUrl,
			data : {
				id : _self.exchangeGoods.id
			},
			success : function (aResult) {
				if (aResult.status == 1) {
					_fillCommendHtml(aResult.data);
				}
			}
		});
	}

	/**
	 * 绑定事件
	 */

	function _bindEvent(){
		//加好友
		_$container.on('click',' .J-addFriend', function(){
			var _oDialog = UMDialogs.build(UMDialogs.TYPE_ADD_FRIEND, {
				user_target_id : $(this).data('id'),
				user_info_url : _self.friendInfoUrl,
				add_friend_url : _self.friendApplyUrl
			});
			_oDialog.show();	//显示弹框
		});

		//支付类型
		_$container.on('click','.J-pay-type', function(){
			var self = $(this);
			_$container.find('.J-pay-type').removeClass('focus');
			_payType = $(this).addClass('focus').data("type");
		});

		//点击喜欢
		_$container.on('click',' .J-like', function(){
			_support($(this), $(this).data('id'));
		});

		//点击立即兑换
		_$container.on('click',' .J-exchangeNow', function(){
			var time = new Date().getTime(), sTime = new Date('2016-1-22').getTime(), eTime = new Date('2016-2-19').getTime();
			if(sTime <= time && time <= eTime){
				UBox.show('由于各地快递公司开始放年假，所以从1月22号到2月18号暂停兑换功能的使用！', -1);
				return;
			}else if(_payType <0){
				UBox.show('请选择兑换方式', -1);
				return;
			}
			// U币/金币是否足够
			if(_payType==1){
				var _diffGold = _haveEnoughGold();
				if(_diffGold  > 0){
					_fillNotEnoughGoldDialog(_diffGold);
					_showDialog(_$notEnoughGoldDialog);
					return ;
				}
			}else{
				var _diffGold = _self.exchangeGoods.gold_ub_gold-App.oCurrentStudent.gold;
				var _diffUb = _self.exchangeGoods.gold_ub_ub-App.oCurrentStudent.ub;
				if(_diffGold  > 0){
					_fillNotEnoughGoldDialog(_diffGold);
					_showDialog(_$notEnoughGoldDialog);
					return ;
				}
				if(_diffUb  > 0){
					_fillNotEnoughUbDialog(_diffUb);
					_showDialog(_$notEnoughUbDialog);
					return ;
				}
			}


			var _diffLevel = _haveEnoughLevel();
			if(_diffLevel > 0){
				UBox.show('您的等级不够，不能兑换该商品', -1);
				return ;
			}

			var _storageNum = $.trim($('.J-storage_num').text());
			if(_storageNum == 0){
				UBox.show('商品库存为空，不能兑换该商品', -1);
				return ;
			}

			_fillExchangeDialogHtml();
			_showDialog(_$exchangeDialog);
		});

		//点击确认兑换
		_$exchangeDialog.on('click', '.J-confirm', function(){
			if(_isCommiting){
				UBox.show('不能重复提交表单', -1);
				return ;
			}
			var _aExchangeData = _getFormData();

			if(!$.isEmptyObject(_aExchangeData)){
				_exchange(_aExchangeData);
			}
		});

		//点击兑换窗口关闭按钮
		_$exchangeDialog.on('click', '.J-close', function(){
			_closeDialog(_$exchangeDialog);
		});

		//点击兑换成功窗口关闭按钮
		_$exchangeSuccessDialog.on('click', '.J-close', function(){
			_closeDialog(_$exchangeSuccessDialog);
		});

		//点击金币不足窗口关闭按钮
		_$notEnoughGoldDialog.on('click', '.J-close', function(){
			_closeDialog(_$notEnoughGoldDialog);
		});
		//点击U币不足窗口关闭按钮
		_$notEnoughUbDialog.on('click', '.J-close', function(){
			_closeDialog(_$notEnoughUbDialog);
		});
	}

	/**
	 * 兑换商品
	 * @param {Array} aExchangeData 要提交的表单数据
	 */
	function _exchange(aExchangeData){
		_isCommiting = true;
		ajax({
			url : _self.exchangeUrl,
			data : aExchangeData,
			success : function (aResult) {
				_isCommiting = false;
				if (aResult.status == 1) {
					//兑换了和库存量变化
					var _exchange_num = Number(_$container.find('.J-exchange_num').text());
					_$container.find('.J-exchange_num').text(++_exchange_num);
					var _exchange_num = Number(_$container.find('.J-storage_num').text());
					_$container.find('.J-storage_num').text(--_exchange_num);
					//显示兑换成功窗口
					_showDialog(_$exchangeSuccessDialog);
				}else if(aResult.status == 0){
					//疑问
					_closeDialog(_$exchangeDialog);
					UBox.show(aResult.msg, -1);
				}
			},
			error : function(aResult){
				_isCommiting = false;
			}
		});
	}


	/**
	 * 验证用户是否有足够的等级兑换商品
	 */
	function _haveEnoughLevel(){
		var _studentLevel = Number(App.oCurrentStudent.level);
		var _goodLevel = Number(_self.exchangeGoods.level);
		return _goodLevel - _studentLevel;
	}

	/**
	 * 验证用户是否有足够的金币兑换商品
	 * @return {Number} 商品金币和用户金币的差值
	 */
	function _haveEnoughGold(){
		var _studentGold = Number(App.oCurrentStudent.gold);
		var _goodGold = Number(_self.exchangeGoods['after_discount_gold'] || _self.exchangeGoods.gold);
		return _goodGold - _studentGold;
	}

	/**
	 * 显示对话窗口
	 * @param {jQuery} $dialog 要显示的窗口对象
	 */
	function _showDialog($dialog){
		_closeDialog(_$exchangeDialog);
		_closeDialog(_$exchangeSuccessDialog);
		_closeDialog(_$notEnoughGoldDialog);
		_closeDialog(_$notEnoughUbDialog);
		_locateMiddle($dialog);
		var goods = _self.exchangeGoods,tip = '';
		if(_payType == 1){
 			tip = '系统将扣除你' + (goods['after_discount_gold'] || goods.gold) + '金币，是否继续？'
		}else{
			tip = '系统将扣除你' + 
			(goods.gold_ub_gold!=0?goods.gold_ub_gold+'金币':'') + 
			(goods.gold_ub_ub!=0?goods.gold_ub_ub+'U币':'') + 
			'，是否继续？'
		}
		$dialog.css({'display' : 'block'}).find(".J-tip").html(tip);
	}

	/**
	 * 居中显示
	 */
	function _locateMiddle($Dom){

	}

	/**
	 * 关闭对话窗口
	 * @param {jQuery} dialogType 要关闭的窗口对象
	 */
	function _closeDialog($dialog){
		$dialog.css({'display' : 'none'});
	}

	/**
	 * 构建兑换推荐
	 */
	function _createCommendHtml(){
		var _body = '<!-- 兑换推荐 -->\
					<div class="home-mods um-mexchangtop">\
						<div class="hd">\
							 <h2 class="title">兑换推荐</h2>	\
						 </div>\
						 <div class="bd">\
							<div class="exchang-list">\
								<ul class="list-unstyled J-commend">\
								</ul>\
							</div>\
						 </div>\
					 </div>';
		return _body;
	}

	/**
	 * 填充兑换推荐
	 * @param {Array} aCommendList 推荐商品列表
	 */
	function _fillCommendHtml(aCommendList){
		if(aCommendList.length < 1){
			_$container.find('.J-commend').append('<li class="nodata">\
												暂时没有商品推荐喔\
											</li>');
			return ;
		}

		for(var i in aCommendList){
			var _commendGoods = aCommendList[i];
			_$container.find('.J-commend').append('<li class="top">\
													<div class="img">\
														<a title="' + _commendGoods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _commendGoods.id)+ '" class="avatar">' + Ui1.buildImage(_resourceUrl + _commendGoods.profile, undefined, {width : 100, heigth : 100}) + '</a>\
													</div>\
													<div class="info">\
														<p class="title"><a title="' + _commendGoods.name + '" target="_blank" href="' + _self.goodsDetailUrl.replace('_goodsId', _commendGoods.id) + '">' + _commendGoods.name + '</a></p>\
														<p><em>' + _commendGoods.gold + '金币(' + _commendGoods.level + '级以上)</em></p>\
														<p>已有' + _commendGoods.sales_volume + '人兑换</p>\
													</div>\
												</li>');
		}
	}

	/**
	 * 构建他们也兑换了
	 */
	function _createOtherUsersHtml(){
		var _body = '<div class="home-mods um-mmayknow">\
									<div class="hd">\
										 <h2 class="title">他们也兑换了</h2>\
									 </div>\
									 <div class="bd">\
										<ul class="list-unstyled p-list J-otherUsers">\
										</ul>\
									 </div>\
								 </div>';
		return _body;
	}

	/**
	 * 填充他们也兑换了
	 * @param {Array} aOtherUsersList 其它兑换人列表
	 */
	function _fillOtherUsersHtml(aOtherUsersList){
		if(aOtherUsersList.length < 1){
			_$container.find('.J-others').append('<li class="nodata">\
												暂时没有可能认识的人喔\
											</li>');
			return ;
		}

		for(var i in aOtherUsersList){
			var _otherUser = aOtherUsersList[i];
			_$container.find('.J-otherUsers').append('<li data-id="' + _otherUser.user_id + '">\
												<div class="head">' + Ui1.buildProfile(_otherUser.user_info, true) + '<span class="mask">' + Ui1.timeToAgo(_otherUser.create_time) + '</span>\
												</div>\
												<div class="name">\
													<a  href="' + Ui1.buildZoneUrl(_otherUser.user_info.id) + '">' + Ui1.buildVipName(_otherUser.user_info, true) + '</a>\
												</div>\
												<div class="fribtn J-addFriend" data-id="' + _otherUser.user_id + '">\
													<a href="javascript:;"><i>+</i>好友</a>\
												</div>\
											</li>');
		}

		//绑定个人信息对话窗口
		UMDialogs.listenToShowStudentInfo(_$container.find('.J-otherUsers').find('img'), {user_info_url : _self.friendInfoUrl});
	}

	/**
	 * 点击喜欢商品
	 * @param {Number} id 商品ID
	 */
	function _support($this, goodsId){
		ajax({
			url : _self.goodsSupportUrl,
			data : {
				id : goodsId
			},
			success : function (aResult) {
				if (aResult.status == 1) {
					var _num = Number($this.find('em').text());
					$this.find('em').text(_num + 1);
					$this.find('.ico-exchange-like-ghost').attr('class', 'ico-exchange-like');
				}else if(aResult.status == 0){
					UBox.show('您已经喜欢过了哦', -1);
				}
			}
		});
	}

	/**
	 * 构建确认兑换弹出窗口
	 */
	function _createExchangeDialogHtml(){
		var _body = '<!-- 确认兑换 -->\
						<!-- 通用弹出框 -->\
						<div class="modal hide fade in common-modal" aria-hidden="false" id="exchangeConfirm">\
							<!-- success perfect fail -->\
							<div class="um-mcommon exchange exchange-confirm">\
								<div class="hd">\
									确认兑换\
								</div>\
								<div class="bd">\
									<div class="point">请填写正确的收货地址，否则我们将视为放弃兑换商品</div>\
									<form action="">\
										<p>\
											<label for="name">联&ensp;系&ensp;人：</label>\
											<input class="J-name" type="text" id="name" value="' + _self.receiver + '" placeholder="请输入名字">\
										</p>\
										<p>\
											<label for="phone">联系电话：</label>\
											<input class="J-phone" type="text" id="phone" value="' + _self.mobile + '" placeholder="请输入联系电话">\
										</p>\
										<p>\
											<label for="qq">Q Q号码：</label>\
											<input class="J-qq" type="text" id="qq" value="' + _self.qq + '" placeholder="请输入QQ号码">\
										</p>\
										<p>\
											<label for="address">收货地址：</label>\
											<span class="ov">\
												<span class="btn-select">\
													<span class="J-select cur-select">请选择<i class="triangle-down"></i></span>\
													<select  name="province" id="province" class="J-province">\
													</select>\
												</span>\
												<span class="btn-select">\
													<span class="J-select cur-select">请选择<i class="triangle-down"></i></span>\
													<select name="province" id="province" class="J-city">\
													</select>\
												</span>\
												<span class="btn-select">\
													<span class="J-select cur-select">请选择<i class="triangle-down"></i></span>\
													<select name="province" id="province" class="J-area">\
													</select>\
												</span>\
												</span></p><div style="text-align:right;width: 89%;">\
													<input type="text" id="address"  class="address-detail J-address" placeholder="请输入详细地址"  value="' + _self.address + '">\
												</div>\
										</p>\
									</form>\
									<div class="J-tip tip">系统将扣除你' + (_self.exchangeGoods['after_discount_gold'] || _self.exchangeGoods.gold) + '金币，是否继续？</div>\
								</div>\
								<div class="ft">\
									<div class="opts">\
										<a href="###" class="um-btn um-btn-error um-btn-xlg J-confirm">确认兑换</a>\
									</div>\
								</div>\
							</div>\
							<a href="###" class="close J-close" data-dismiss="modal" >&times;</a>\
						</div>';
		return _body;
	}

	/**
	 * 填充确认兑换窗口
	 */
	function _fillExchangeDialogHtml(){
		//获取最后一次记录
		if(_self.oAreaSelector == null){
			//加载兑换推荐
			_self.oAreaSelector = new AreaSelector({
				//下面是配置
				$province : $('.J-province'),	//用JQ选择省份的select
				$city : $('.J-city'),	//城市的select
				$area : $('.J-area'),	//你懂的
				//以下配置可选
				defaultArea : _self.areaId,	//默认的区域ID,配这个时一定要配上defaultCity
			});
			//绑定事件
			$('.J-province,.J-city,.J-area').change(function(){
				var $self = $(this);
				$self.prev('.J-select').html($self.find(':selected').text());
			});
			_self.oAreaSelector.init();
		}
	}

	/**
	 * 构建金币不足弹出窗口
	 */
	function _createNotEnoughGoldDialog(){

		var _body = '<!-- 金币不足 -->\
					<!-- 通用弹出框 -->\
					<div class="modal hide fade in common-modal" aria-hidden="false" >\
						<!-- success perfect fail -->\
						<div class="um-mcommon exchange exchange-fail">\
							<div class="hd">\
								金币不足\
							</div>\
							<div class="bd J-diffGold">\
								<p>抱歉，金币不足，您还差<em>0</em>金币。您可以去<br>\
									<a class="J-exchangeInDiffGold" target="_blank" href="' + _self.payExchangeUrl + '">兑换金币</a></p>\
							</div>\
						</div>\
						<a href="###" class="close J-close" data-dismiss="modal" >&times;</a>\
					</div>';
		return _body;
	}

	/**
	 * 构建金币不足弹出窗口
	 */

	 function _createNotEnoughUbDialog(){
		var _body = '<!-- U币不足 -->\
					<!-- 通用弹出框 -->\
					<div class="modal hide fade in common-modal" aria-hidden="false" >\
						<!-- success perfect fail -->\
						<div class="um-mcommon exchange exchange-fail">\
							<div class="hd">\
								U币不足\
							</div>\
							<div class="bd J-diffUb">\
								<p>抱歉，U币不足，您还差<em>0</em>U币。您可以去<br>\
									<a class="J-exchangeInDiffUb" target="_blank" href="' + _self.ubExchangeUrl + '">兑换U币</a></p>\
							</div>\
						</div>\
						<a href="###" class="close J-close" data-dismiss="modal" >&times;</a>\
					</div>';
		return _body;
	}

	/**
	 * 填充金币不足弹出窗口
	 * @param {Number} gold 差的金币数
	 */
	function _fillNotEnoughGoldDialog(gold){
		_$notEnoughGoldDialog.find('.J-diffGold').find('em').text(gold);
	}
	/**
	 * 填充金币不足弹出窗口
	 * @param {Number} Ub 差的U币数
	 */
	 function _fillNotEnoughUbDialog(ub){
		_$notEnoughUbDialog.find('.J-diffUb').find('em').text(ub);
	}

	/**
	 * 构建兑换成功窗口
	 */
	function _createExchangeSuccessDialog(){
		var _body = '<!-- 兑换成功 -->\
					<!-- 通用弹出框 -->\
					<div class="modal hide fade in common-modal" aria-hidden="false" id="exchangeSuccess">\
						<!-- success perfect fail -->\
						<div class="um-mcommon exchange exchange-success">\
							<div class="hd">\
								兑换成功\
							</div>\
							<div class="bd">\
								<div class="point">恭喜您，兑换成功</div>\
								<p>我们将在3个工作日发货，请注意查收！</p>\
							</div>\
							<div class="ft">\
								<div class="opts">\
									<a target="_blank" href="' + _self.mineUrl + '" class="um-btn um-btn-error um-btn-xlg J-record">查看兑换记录</a>\
								</div>\
							</div>\
						</div>\
						<a href="###" class="close J-close" data-dismiss="modal" >&times;</a>\
					</div>';
		return _body;
	}

	/**
	 * 验证表单
	 * @return {Array} 返回过滤验证后的表单数据
	 */
	function _getFormData() {
		var _goodsId = _self.exchangeGoods.id;
		var _$userName = _$exchangeDialog.find('.J-name');
		//获取任务信息
		var _userName = $.trim(_$userName.val());
		var _$phone = _$exchangeDialog.find('.J-phone');

		var _phone = $.trim(_$phone.val());
		var _$qq = _$exchangeDialog.find('.J-qq');
		var _qq = $.trim(_$qq.val());
		var _$address = _$exchangeDialog.find('.J-address');
		var _address = $.trim(_$address.val());
		//省
		var _province = _$exchangeDialog.find('.J-province').val();
		//市
		var _city = _$exchangeDialog.find('.J-city').val();
		//区
		var _area = _$exchangeDialog.find('.J-area').val();

		if (_userName == '') {
			UBox.show('名字不正确', -1);
			_$userName.focus();
			return;
		}

		if (_phone == '' || !/^((\+86)|(86))?(1[3|4|5|8]{1}\d{9})$/.test(_phone)) {
			if(!/^\d{3}-\d{8}|\d{4}-\d{7}$/.test(_phone)){
				UBox.show('联系电话填写有误', -1);
				_$phone.focus();
				return;
			}
		}

		if (_qq == '' || !/^[1-9][0-9]{4,15}$/.test(_qq)) {
			UBox.show('qq号码不正确', -1);
			_$qq.focus();
			return;
		}
		if (_address == '') {
			UBox.show('地址不能为空', -1);
			_$address.focus();
			return;
		}
		if (_province == 0 || _city == 0 || _area == 0) {
			UBox.show('请选择所在地', -1);
			return;
		}
		var _aData = {
			receiver : _userName,
			mobile : _phone,
			qq : _qq,
			areaId : _area,
			address : _address,
			goodsId : _goodsId,

			payType:_payType
		};

		return _aData;
	}

	var _resourceUrl = App.getUrl('resource');
	var _self = win.ExchangeDetailPage;
	var _$container = null;
	var _$exchangeDialog = null;
	var _$notEnoughGoldDialog = null;
	var _$notEnoughUbDialog = null;
	var _$exchangeSuccessDialog = null;
	var _isCommiting = false;
	var _payType = 1 ;//充值类型：1是金币兑换，2是ub+金币兑换; 默认为1
})(jQuery,window);
