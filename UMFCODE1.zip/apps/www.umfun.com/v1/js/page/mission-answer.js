/*
 * 闯关信息插件
 * 2014-12-12 14:00:00
 */
(function($, window){
	window.MissionAnswer = {
		PAGE_PRACTIC : 'page_practic',
		PAGE_CHALLENGE: 'page_challenge',
		PAGE_ANALYSIS : 'page_analysis',
		EVENT_START_PRACTICE : 'event_start_practice',	//开始修炼
		EVENT_START_CHALLENGE : 'event_start_challenge',	//开始挑战
		EVENT_AFTER_ANSWER : 'after_answer',	//答对以后

		STATUS_ANSWERWING_ES : '正在做题',
		STATUS_SUBMITTING_ANSWER : '正在提交答案',
		STATUS_SHOWWING_ES_RESULT : '显示做题结果',
		STATUS_GETTING_NEXT_ES : '正在获取下一题',
		STATUS_PASS_AL : '完成了AL',
		STATUS_PASS_PRACTICE : '通过了修炼',
		STATUS_PASS_CHALLENGE : '通过了挑战',
		status : '',

		$propBar : null,	//道具栏DOM
		$esContent : null,	//题目显示框

		aConfig : {
			oHeadDom : null,	//标题栏
			oAnswerDom : null,	//答题内容块
			aMission : [],	//本关信息
			aUserMission : [],	//用户的关卡记录信息
			oSideDom : null,
			hasCharInputer : 0,
			isMathCharInputer : 0,
			getNextEsUrl : '',	//下一题取题地址
			postAnswerUrl : '',	//作答地址
			publishSolutionUrl : '',	//提交钥匙思路的地址
			analysisUrl : '',	//战绩地址
			practicUrl : '',	//修炼地址
			challengeUrl : '',	//挑战地址
			missionListUrl : '',	//闯关列表地址
			missionUrl : '',	//闯关地址
			getCardUrl : '',	//获取魔术卡
			useMagicUrl : '',	//使用魔术卡
			magicImgSrc : '',	//魔术卡地址
			cardImgSrc : '',	//卡组背面
			aSuccessTips : '', //成功提示信息
			esFeedBackUrl : '',	//反馈地址
			feedbackAddtionalUrl : '',	//反馈附加信息地址
			analysisBbsUrl : '',	
			aFailedTips : '', //失败提示信息
			aDataBoxPlan : {
				esNumber : 0
			},
			page : '',
			aEsTypeList : ''
		},
		challenge_limit_blood : 0,
		isLost : false,

		config : function(aConfig){
			for(var key in self.aConfig){
				if(aConfig[key] === undefined){
					continue;
				}
				self.aConfig[key] = aConfig[key];
			}
			self.challenge_limit_blood = self.aConfig.aMission.challenge_limit_blood;

			_remainSeconds = self.aConfig.aMission.challenge_limit_duration * 60;	//初始化挑战剩余时间

			if(self.aConfig.page == self.PAGE_PRACTIC){
				self.bindEvent(self.EVENT_START_PRACTICE, function(){
					//开始答题的时候取题
					_showNextEs();
					_bindEvent();
					_initProp(Prop.SCENE_MISSION_PRACTICE);
				});
			}else{
				self.bindEvent(self.EVENT_START_CHALLENGE, function(){
					//开始答题的时候取题
					_showNextEs();
					_bindEvent();
					_initProp(Prop.SCENE_MISSION_CHALLENGE);
				});
			}
			if(self.aConfig.hasCharInputer == 1){
				CharInputer.init({subject : self.aConfig.aMission.subject_id});
			}
		},

		/**
		 * 显示侧边栏
		 */
		showSideBar : function(){
			self.aConfig.oSideDom.html(_buildSildBar());
			_updateSideBoxPlan();
			_sideMonitorInputMinFont300();
		},

		/**
		 * 显示关卡标题和游戏进度
		 */
		showTitleBar : function(){
			self.aConfig.oHeadDom.html(_buildHeadHtml());
		},

		/**
		 * 开始倒计时
		 */
		timeReduceStart : function(){
			if(_isUsingSgnj || _timeReduceTimer != undefined || (!self.isLost && self.status != self.STATUS_ANSWERWING_ES)){
				//如果时光凝结的效果还没消失或者倒计时句柄还存在又或者页面状态不是做题中就不做处理
				return;
			}else if(_remainSeconds == 0){
				//没时间了就更加不用跑了
				self.timeReducePause();
				return;
			}
//			_remainSeconds = 5;
			_timeFlickerTimer = clearInterval(_timeFlickerTimer);
			var $time = self.aConfig.oSideDom.find('.J-thisCorrectCounts');
			$time.css('visibility', 'visible');
			_timeReduceTimer = setInterval(function(){
				_remainSeconds--;

				var timeStr = Ui1.timeToFormatStr(_remainSeconds).replace(/^\d+\:/, '');
				if(timeStr.indexOf('NaN') != -1){
					window.oLog && oLog.add([_remainSeconds, timeStr], '时间解析出错');
					$.error('时间解析出错');
				}

				$time.text(timeStr);
				if(_remainSeconds == 0){
					self.isLost = true;

					_showChallenge({
						remain_time : _remainSeconds,
						is_correct : 0
					});
					 _$resultDialog.modal({backdrop : 'static', 'show' : true});
					self.timeReducePause();
					return;
				}
			}, 1000);
		},

		/**
		 * 暂停倒计时
		 */
		timeReducePause : function(){
			_timeReduceTimer = clearInterval(_timeReduceTimer);
			if(_timeFlickerTimer == undefined && !self.isLost){
				var $time = self.aConfig.oSideDom.find('.J-thisCorrectCounts');
				_timeFlickerTimer = setInterval(function () {
					var displayValue = $time.css('visibility') == 'visible' ? 'hidden' : 'visible';
					$time.css('visibility', displayValue);
				}, 600);
			}
		},

		commentResult : function(missionRelationId, score){
			ajax({
				 url : '/mission_x/aftermissionsuccess.json',
				 data : {
					 mission_relation_id : missionRelationId,
					 score : score
				 },
				 success : $.noop,
				 error : $.noop
			});
		},

		/**
		 * 显示修炼内容
		 * @returns {undefined}
		 */
		showPracticeContent : function(){
			self.aConfig.oAnswerDom.html('<div class="modm um-manswer-tag J-esInfo"><!-- 题目难度和题型 --></div>\
			<div class="modm um-esplug J-esContent"><!-- 题目内容 --></div>\
			<div class="J-propBar"></div>\
			<div class="modm um-manswer-feedback J-wrapDoEs">\
				<div class="submit J-submit">\
					<a href="javascript:void(0);" class="um-btn um-btn-default um-btn-xlg disabled J-btnAnswer">初始化中</a>\
					<span class="tip J-btnAnswerTip"></span>\
				</div>\
			</div>\
			<div class="modal hide fade common-modal" tabindex="-1" role="dialog" id="mCommon">\
				<div class="J-dialogBox"></div>\
			</div>\
			<div class="modal hide fade common-modal" tabindex="-1" role="dialog" id="feedBackDialog">\
				' + _feedBack() + '\
			</div>');

			// 垂直居中代码
			_modalVerticalCenter('#feedBackDialog');
			$(window).resize(function(){
				_modalVerticalCenter('#feedBackDialog');
				_modalVerticalCenter('#mCommon');
			});

			self.$propBar = self.aConfig.oAnswerDom.find('.J-propBar');	//设置道具条实例
			self.$esContent = self.aConfig.oAnswerDom.find('.J-esContent');	//设置题目框实例

			self.triggerEvent(self.EVENT_START_PRACTICE);	//触发开始修炼事件
			_$resultDialog = $('#mCommon');
		},

		showChallengeContent : function () {
			self.aConfig.oAnswerDom.html('<div class="modm um-manswer-tag J-esInfo"><!-- 题目难度和题型 --></div>\
			<div class="modm um-esplug J-esContent"><!-- 题目内容 --></div>\
			<div class="J-propBar"><!-- 道具条 --></div>\
			<div class="modm um-manswer-feedback J-wrapDoEs">\
			<div class="submit J-submit"><!-- 出招模块 -->\
				<a href="javascript:void(0);" class="um-btn um-btn-default um-btn-xlg disabled J-btnAnswer">初始化中</a>\
				<span class="tip J-btnAnswerTip"></span>\
			</div>\
			</div>\
			<div class="modal hide fade common-modal" tabindex="-1" role="dialog" id="mCommon">\
				<div class="J-dialogBox"></div>\
			</div>\
			<div class="modal hide fade common-modal" tabindex="-1" role="dialog" id="feedBackDialog">\
				' + _feedBack() + '\
			</div>');
			self.$propBar = self.aConfig.oAnswerDom.find('.J-propBar');	//设置道具条实例
			self.$esContent = self.aConfig.oAnswerDom.find('.J-esContent');	//设置题目框实例
			self.triggerEvent(self.EVENT_START_CHALLENGE);	//触发开始挑战事件
			_$resultDialog = $('#mCommon');
			// 垂直居中代码
			_modalVerticalCenter('#feedBackDialog');
			$(window).resize(function(){
				_modalVerticalCenter('#feedBackDialog');
				_modalVerticalCenter('#mCommon');
			});
		},
		setBtnAnswer : function(opts){
			var $btn = self.aConfig.oAnswerDom.find('.J-btnAnswer');
			if(opts == 0){
				$btn.addClass('disabled');
			}else if(opts == 1){
				$btn.removeClass('disabled');
			}
		},

		updateMissionListStatusCookieByType : function(type, value){
			var aMissionListStatus = this._getMissionListStatusCookie();
			if(!aMissionListStatus){
				return ;
			}
			aMissionListStatus[type] = value;
			if(typeof(aMissionListStatus[4]) == 'undefined'){
				aMissionListStatus[4] = 0;
			}
			this._setMissionListStatusCookie(aMissionListStatus[0], aMissionListStatus[1], aMissionListStatus[2], aMissionListStatus[3], aMissionListStatus[4]);
		},

		_getMissionListStatusCookie : function(){
			var missionListStatus = $.cookie('mission_list_status');
			var aMissionListStatus = [];
			if(missionListStatus){
				aMissionListStatus = missionListStatus.split(',');
			}

			if(aMissionListStatus.length > 0){
				return aMissionListStatus;
			}else{
				return false;
			}
		},

		_setMissionListStatusCookie : function(studentId, listStyle, gradeId, subjectId, lastMissionId){
			$.cookie('mission_list_status', studentId + ',' + listStyle + ',' + gradeId + ',' + subjectId + ',' + lastMissionId, {path: '/'});
		},

		checkToolUser : function(url, getCardUrl, useMagicUrl){
			ajax({
				url : url,
				data : {},
				success : function(aResult){
					if(aResult.status == 1){
						self.aConfig.getCardUrl = getCardUrl;
						self.aConfig.useMagicUrl = useMagicUrl;
						$('body').append('<button class="J-draw-Unlimited-btn" style="position:absolute;top:80px;left:100px;height:50px;background:#ff0000;">无限抽卡牌</button>');
						$('.J-draw-Unlimited-btn').on('click', function(){
							var k = {
								"is_correct": 1,
								"chanllge_status": 1,
								"accumulate_points": 98,
								"hit_accumulate_points": 5,
								"score": 9828,
								"remain_time": 2,
								"remian_es_count": 0,
								"remain_blood": "2",
								"answer_text": "3",
								"es_analysis": false,
								"hit_word": "yes",
								"chanllge_continuous_correct_count": 10,
								"is_show_cards": 1
							};
							_showChallenge(k);
							_$resultDialog.modal('show');
							return;
						});
					}
				}
			});
		},
		showPracticeResult: function (aEs) {
			if (aEs === undefined) {
				var aEs = {
					accumulate_points: 0.0001,
				};
			}
			_showSuccesOverMission(aEs);
			_$resultDialog.modal({backdrop : 'static', 'show' : true});
		},
		showChallengeResult: function(type, aEs){
			if(self.aConfig.page != self.PAGE_CHALLENGE){
				UBox.show('请到挑战去,使用该功能!', -1);return;
			}
			if (aEs === undefined) {
				var aEs = null;
				switch (type) {
					//成功
					case 1:
						aEs = {
							accumulate_points: 0,
							answer_text: 0,
							chanllge_continuous_correct_count: 20,
							chanllge_status: 1,
							es_analysis: false,
							hit_accumulate_points: 8,
							hit_word: "Perfect",
							is_correct: 1,
							is_show_cards: false,
							next_mission_id: "78",
							next_mission_practic_is_finish: true,
							remain_blood: "3",
							remain_time: 882,
							remian_es_count: 0,
							score: 9960
						}
						break;
						//失败
					case 2:
						aEs = {
							is_correct: 0,
							remain_time: 1
						};
						//显示道具条
						self.challenge_limit_blood = 0;
						self.isLost = true;
						break;
						//时间到或没生命值了
					case 3:
						//没时间
						aEs = {
							is_correct: 0,
							remain_time: 0
						};
						self.isLost = true;
						break;
					default:
						aEs = {
							accumulate_points: 0,
							answer_text: 0,
							chanllge_continuous_correct_count: 20,
							chanllge_status: 1,
							es_analysis: false,
							hit_accumulate_points: 8,
							hit_word: "Perfect",
							is_correct: 1,
							is_show_cards: false,
							next_mission_id: "78",
							next_mission_practic_is_finish: true,
							remain_blood: "3",
							remain_time: 882,
							remian_es_count: 0,
							score: 9960
						}
						break;
				}
			}

			_showChallenge(aEs);
			_$resultDialog.modal({backdrop : 'static', 'show' : true});
		}
	};

	//头部构建
	function _buildHeadHtml(){
		//以下变量的计算方式可以自行优化
		var aMission = self.aConfig.aMission,
			aUserMission = self.aConfig.aUserMission,
			practicUrl = '',
			challengeUrl = '',
			analysisUrl = '',
			practicClass = '',
			challengeClass = '',
			analysisClass = '';

		if(self.aConfig.page == self.PAGE_PRACTIC){
			practicUrl = 'javascript:;';
			practicClass = ' class="active J-practicUrl"';
		}else{
			practicUrl = self.aConfig.practicUrl;
		}

		if(self.aConfig.page == self.PAGE_CHALLENGE){
			challengeUrl = 'javascript:;';
			challengeClass = ' class="active"';
		}else{
			challengeUrl = aUserMission.is_task_finish == 1 ? self.aConfig.challengeUrl : 'javascript:;';
			challengeClass = aUserMission.is_task_finish != 1 ? ' class="disabled J-challengeUrl"' : '';
		}

		/*if(self.aConfig.page == self.PAGE_ANALYSIS){
			analysisUrl = 'javascript:;';
			analysisClass = ' class="active"';
		}else{
			analysisUrl = aUserMission.pass_time == 0 ? 'javascript:;' : self.aConfig.analysisUrl;
			analysisClass = aUserMission.pass_time == 0 ? ' class="disabled"' : '';
		}*/
		analysisClass = '';
		analysisUrl = self.aConfig.analysisUrl;
		//战绩的图标状态...

		return '<div class="um-manswer-header">\
			<div class="title">\
				<a href="' + self.aConfig.missionUrl + '">闯关</a><b>&gt;</b><a href="' + self.aConfig.missionListUrl + '">' + aMission.grade_name + ' · ' + aMission.subject_name + '</a><b>&gt;</b><span title="' + aMission.name + '">' + aMission.name + '</span>\
			</div>\
			<div class="nav">\
				<ul class="list-unstyled">\
					<li' + practicClass + '><a href="' + practicUrl + '">修炼</a></li>\
					<li' + challengeClass + '><a href="' + challengeUrl + '">挑战</a></li>\
					<li' + analysisClass + '><a href="' + analysisUrl + '" >战绩</a></li>\
					<li class="back"><a href="' + self.aConfig.missionListUrl + '">返回列表</a></li>\
				</ul>\
			</div>\
		</div>';
	}


	//题目难度与类型
	function _buildEsInfoLittle(esInfo){
		var aHardLLevel = {
			1 : '难度容易',
			2 : '难度中等',
			3 : '难度较大'
		};

		$('.J-esInfo').html('<!-- 头部标签 -->\
			<div class="tag-warp">\
				<span class="tag">' + aHardLLevel[esInfo.hard_level] + '</span>\
				<span class="tag">' + self.aConfig.aEsTypeList[esInfo.type_id] + '</span>\
			</div>\
		<a href="javascript:void(0);" class="ep um-fr J-feedBack">反馈该题有误</a>');
		$('.J-feedBack').click(function(){
			$('#feedBackDialog').modal('show');
		});
		$('.J-btnFeedBack').unbind();
		$('.J-btnFeedBack').click(function(){
			_pubilshFeedBack();
		});
	}

	//侧栏构建部署
	function _buildSildBar(){
		var challengeORanswerClass = self.aConfig.page == self.PAGE_PRACTIC ? 'um-mpractic-process' : 'um-mchallenge-process',
			PlnTextType = {
				'page_practic' : {
					titile : '修炼进度',
					left : '答对题数',
					centent : '正确率',
					right : '总答题数'

				},
				'page_challenge' : {
					titile : '挑战进度',
					left : '剩余时间',
					centent : '剩余生命',
					right : '剩余题目'
				}
			};
		var sideBarHtml = '<div class="mods ' + challengeORanswerClass + '">\
			<div class="hd">' + PlnTextType[self.aConfig.page].titile + '</div>\
			<div class="bd">\
				<div class="process-bar">\
					<div class="process J-thisProcessWidth"></div>\
					<div class="percent J-thisProcessBarText">0%</div>\
				</div>\
			</div>\
			<div class="ft">\
				<div class="databox">\
					<ul class="list-unstyled">\
						<li class="left">\
							<div class="data blue J-thisCorrectCounts">0</div>\
							<div class="text">' + PlnTextType[self.aConfig.page].left + '</div>\
						</li>\
						<div class="vline"></div>\
						<li class="center">\
							<div class="data blue J-thisProcessText">0%</div>\
							<div class="text">' + PlnTextType[self.aConfig.page].centent + '</div>\
						</li>\
						<div class="vline"></div>\
						<li class="right">\
							<div class="data blue J-thisAnswerCounts">0</div>\
							<div class="text">' + PlnTextType[self.aConfig.page].right + '</div>\
						</li>\
					</ul>\
				</div>\
			</div>\
		</div>\
		<div class="mods um-mhistory-data" id="mHistoryData">\
			<div class="hd">本题历史数据</div>\
			<div class="bd">\
			</div>\
			<div class="ft">\
				<div class="databox">\
					<ul class="list-unstyled">\
						<li class="left">\
							<div class="data green J-correctCounts">0</div>\
							<div class="text">总答题数</div>\
						</li>\
						<div class="vline"></div>\
						<li class="center">\
							<div class="data green J-processText">0%</div>\
							<div class="text">正确率</div>\
						</li>\
						<div class="vline"></div>\
						<li class="right">\
							<div class="data green J-answerCounts">0</div>\
							<div class="text">平均耗时(秒)</div>\
						</li>\
					</ul>\
				</div>\
			</div>\
		</div>\
		<div class="mods um-mquestion-answer">\
			<div class="hd">本题参考答案</div>\
			<div class="bd">\
				<div class="answer hidedata J-esAnswer">作答后将自动显示参考答案</div>\
			</div>\
			<div class="ft"></div>\
		</div>\
		\
		<div class="mods um-mquestion-analysis J-analysis">\
			<div class="hd">本题解题思路<a href="' + self.aConfig.analysisBbsUrl + '" style="float:right;color:#ff0000;font-size:14px;"><span style="display:inline-block;vertical-align:middle;margin-top:-3px;width:27px;height:25px;background-position: -68px -26px;background-image: url(http://i.umfun.com/v1/css/sprite/tp-sprite.png);"></span>写解析抢金币</a></div>\
			<div class="bd J-analysisTipsBox">\
				<div class="analysis hidedata J-analysisTipsContent">作答后将自动显示解题思路</div>\
			</div>\
			<div class="ft hide J-analysisEdit">\
				<div class="textarea">\
					<a href="javascript:;" class="J-char-input">' + (self.aConfig.isMathCharInputer == 1 ? '数学符号输入器' : '拼音符号输入器') + '</a>\
					<textarea class="J-solutionContent">我来提供正确的解题思路!</textarea>\
				</div>\
				<div class="opts">\
					<a class="um-btn um-btn-xs um-btn-default J-btnPublishSolution">发表</a>\
					<span class="tip J-analysisOptionTips"><!---成功！---></span>\
					<span class="limit" style="float: right;margin-right: 20px;"><b class="J-analysisfont">0</b>/300</span>\
				</div>\
			</div>\
			<div class="ft hide J-perfect-analysis-wrap">\
				<div class="opts">\
					<a class="um-btn um-btn-xs um-btn-default J-perfect-analysis">我要完善</a>\
				</div>\
			</div>\
		</div>';

		return sideBarHtml;
	}

	//反馈界面
	function _feedBack(){
		return '<!-- 通用弹出框 -->\
		<div class="um-mcommon um-mfeedback">\
			<div class="hd" style="text-align:left;">\
				你认为该题哪里有错误？\
			</div>\
			<div class="bd">\
				<div class="select">\
					<select>\
						<option value="2">题干有问题</option>\
						<option value="0">解析有问题</option>\
						<option value="1">答案有问题</option>\
						<option value="3">选项有问题</option>\
					</select>\
				</div>\
				<div class="textarea">\
					<textarea class="J-feedBackConters"></textarea>\
				</div>\
			</div>\
			<div class="ft">\
				<div class="opts">\
					<a class="um-btn um-btn-sm um-btn-default J-btnCloseFeedback" data-dismiss="modal">取消</a>\
					<a class="um-btn um-btn-sm um-btn-default J-btnFeedBack">发表</a>\
					<span class="tip J-feedBackTip"></span>\
				</div>\
			</div>\
		</div>';
	}

	//绑定出招按钮时间
	function _bindEvent(){
		self.aConfig.oAnswerDom.on('click', '.J-btnAnswer', _postAnswer);
		self.aConfig.oSideDom.on('click', '.J-btnPublishSolution', _publishThinking);
	}

//////////////////////////////////////////////
	/**
	 * 提交作答
	 * @returns {Boolean}
	 */
	function _postAnswer(){
		if(self.status == self.STATUS_SUBMITTING_ANSWER){
			UBox.show('正在提交答案中', -1);
			return false;
		}else if(self.isLost){
			UBox.show('您已经输了', -1);
			return;
		}else if(self.status == self.STATUS_SHOWWING_ES_RESULT){
			//显示下一题
			_showNextEs();
			return;
		}else if(self.status == self.STATUS_GETTING_NEXT_ES){
			UBox.show('操作过于频繁，请稍后再试！', -1);
			return false;
		}

		var xAnswer = _$es.buildAnswer();
		if(_$es.isEmptyAnswer(xAnswer)){
			UBox.show('请先作答', -1);
			return false;
		}
		self.status = self.STATUS_SUBMITTING_ANSWER;

		var aEs = _$es.data('es');
		var $btnObj = $('.J-btnAnswer');
		var $btnAnswerTip = $('.J-btnAnswerTip');

		var aPostData = {};
		if(self.aConfig.page == self.PAGE_PRACTIC){
			aPostData = {
				user_mission_relation_id : self.aConfig.aUserMission.id,
				es_id : aEs.id,
				answer : xAnswer,
				ts : aEs.ts
			};
		}else{
			aPostData = {
				user_mission_relation_id : self.aConfig.aUserMission.id,
				answer : xAnswer,
				ts : aEs.ts
			};
		}


		ajax({
			url : self.aConfig.postAnswerUrl,
			data : aPostData,
			beforeSend:function(){

				$btnObj.text('出招中...').addClass('disabled');
				//删除点击事件
				self.aConfig.oAnswerDom.off('click','.J-btnAnswer',_postAnswer);
			},
			complete : function () {
				//恢复事件
				self.aConfig.oAnswerDom.on('click', '.J-btnAnswer', _postAnswer);
			},
			timeout: 15000,
			success : function(aResult){
				if(aResult.status != 1){
					UBox.show(aResult.msg, aResult.status);
					return;
				}

				_aAnswerHistory.push({
					commit : aPostData,
					result : aResult.data
				});

				self.aConfig.aDataBoxPlan.esNumber++;

				if(aResult.data.is_show_task_finish || (aResult.data.correct_es_count == 20 && aResult.data.is_show_task_finish == 1 )){
					//self.status = self.STATUS_PASS_PRACTICE;	//更新状态为 通过修炼
					if((self.aConfig.aUserMission.task_process == self.aConfig.aMission.task_content.correct_counts) ||
						(aResult.data.task_continuous_correct_count === 15) || (aResult.data.correct_es_count === 20)){
						self.showPracticeResult(aResult.data);
					}
				}
				self.status = self.STATUS_SHOWWING_ES_RESULT;	//更新状态为 显示题目结果

				//显示作答结果等等...
				$('.J-submit').prepend(_buildAnswerResult(aResult.data));

				var oEvent = new UmFunEvent();
				oEvent.oEs = _$es.clone(true);
				oEvent.aResult = aResult.data;
				self.triggerEvent(self.EVENT_AFTER_ANSWER, oEvent);

				self.aConfig.oAnswerDom.find('.J-btnAnswer').text('下一题');

				if(self.isLost || self.aConfig.aMission.challenge_es_count == 0){
					self.aConfig.oAnswerDom.find('.J-btnAnswer').addClass('disabled');
				}else{
					self.aConfig.oAnswerDom.find('.J-btnAnswer').removeClass('disabled');
				}

				//挑战反馈
				if(self.aConfig.page == self.PAGE_CHALLENGE){
					self.timeReducePause();
					if(aResult.data.remain_time < 1){
						//后端时间失败
						self.isLost = true;
						_showChallenge(aResult.data);
						 _$resultDialog.modal({backdrop : 'static', 'show' : true});
						return false;
					}
					//挑战所有成功状态
					if(aResult.data.chanllge_status == 1){
						_showChallenge(aResult.data);
						_$resultDialog.modal({backdrop : 'static', 'show' : true});

						//!!!!!tptptptptptptptptptptpt
						self.commentResult(self.aConfig.aUserMission.id, aResult.data.score);
						return;
					}
				}

				if(aResult.data.is_correct){
					App.oCurrentStudent.updateInfo();
				}
			},
			afterError : function(oXhr){
				$btnAnswerTip.text('出招失败，请点击"出招"重试!');
				setTimeout(function(){
					$btnAnswerTip.hide(200).text('');
				}, 3500);
				self.status = self.STATUS_ANSWERWING_ES;
				$btnObj.text('出招').removeClass('disabled');
				return;
			}
		});
	}

	//下一题
	function _showNextEs(){
		$('.J-result-warp').remove();

		self.aConfig.oSideDom.find('.J-analysisTipsContent').text('作答后将自动显示解题思路').addClass('hidedata');
		self.aConfig.oSideDom.find('.J-solutionContent').val('我来提供正确的解题思路!');
		self.aConfig.oSideDom.find('.J-analysisfont').text(0);
		self.aConfig.oSideDom.find('.J-analysisOptionTips').text('');
		self.aConfig.oSideDom.find('.J-esAnswer').text('作答后将自动显示参考答案').addClass('hidedata');
		self.aConfig.oSideDom.find('.J-analysisEdit').hide();
		self.aConfig.oSideDom.find('.J-perfect-analysis').hide();
		self.aConfig.oSideDom.find('.J-perfect-analysis-wrap').hide();

		if(self.aConfig.aMission.challenge_es_count == 0){
			return false;
		}else if(self.status == self.STATUS_GETTING_NEXT_ES){
			UBox.show('正在取题中', -1);
			return false;
		}

		self.status = self.STATUS_GETTING_NEXT_ES;
		var $btnAnswerTip = $('.J-btnAnswerTip');

		ajax({
			url : self.aConfig.getNextEsUrl,
			data : {
				user_mission_relation_id : self.aConfig.aUserMission.id
			},
			success : function(aResult){
				_retryGetEsTimes = 3;
				if(aResult.status != 1){
					UBox.show(aResult.msg, aResult.status);
					return;
				}

				var aNextEs = JsTools.clone(aResult.data);
				delete aNextEs.es_content;
				_aAnswerHistory.push({next_es : JsTools.clone(aNextEs)});

				_buildEsInfoLittle(aResult.data);
				_$es = Esp.buildQuestion(aResult.data);
				_$es.appendTo(self.$esContent.empty());
				_updateSideBar(aResult.data);

				$('.J-propBar').css('visibility', '');
				self.aConfig.oAnswerDom.find('.J-btnAnswer').text('出招').removeClass('disabled');

				self.status = self.STATUS_ANSWERWING_ES;

				if(self.aConfig.page == self.PAGE_CHALLENGE){
					self.timeReduceStart();
				}
			},
			timeout: 15000,
			afterError : function(oXhr){
				$btnAnswerTip.text('网络超时， 正在给你重新出题中!');
				self.status = '';
				if(_retryGetEsTimes > 0){
					_retryGetEsTimes--;
					setTimeout(function(){
						$btnAnswerTip.hide(200).text('');
						_showNextEs();
					}, 4000);
				}
			},
			delayTime : 800,
			afterDelay : function (aResult) {
				if(aResult.status == 1){
					$btnAnswerTip.text('');
				}
			}
		});
	}

	//作答结果提示
	function _buildAnswerResult(xAnswer){
		var aData = xAnswer,
			adativingLearningHtml = '',
			adativingLearningClass = '',
			experience = '',
			answerClass = '',
			$sideDom = self.aConfig.oSideDom,
			answerJudgeText = '',
			aBoxPlan = self.aConfig.aUserMission,
			answerJudge = 0;

		$('.J-esAnswer').hide(200).html(_$es.buildAnswerText(aData.answer_text)).show(300).removeClass('hidedata');

		var $analysisTipsContent = $sideDom.find('.J-analysisTipsContent');
		if(aData.es_analysis === false){
			$analysisTipsContent.text('暂无解题思路！分享一下你的解题思路吧！');
			$sideDom.find('.J-analysisOptionTips').text('');
			$sideDom.find('.J-analysisEdit').show(300);

		}else{
			$analysisTipsContent.text(aData.es_analysis.analysis).removeClass('nodata');
			Esp.drawMathExpression($analysisTipsContent);
			if(aData.es_analysis.user_type == 1){
				$analysisTipsContent.append('<br /><br /><p style="text-align:right;">' + aData.es_analysis.user_info.name + ' ' + Ui1.date('Y.n.j', aData.es_analysis.create_time) + '</p>');
			}
			self.aConfig.oSideDom.find('.J-perfect-analysis').show();
			self.aConfig.oSideDom.find('.J-perfect-analysis-wrap').show();
			var canFillPerfectAnalysis = false;
			if(aData.is_can_fill_analysis_perfection == 1){
				canFillPerfectAnalysis = true;
			}
			$sideDom.find('.J-perfect-analysis').unbind();
			$sideDom.find('.J-perfect-analysis').on('click', function(){
				if(!canFillPerfectAnalysis && aData.is_can_fill_analysis_new == 0){
					UBox.show('已经有人提交了完善，请稍后', -1);
				}else{
					$sideDom.find('.J-solutionContent').val(aData.es_analysis.analysis);
					$sideDom.find('.J-solutionContent').focus();
					$analysisTipsContent.text('').addClass('hidedata');
					$sideDom.find('.J-analysisOptionTips').text('');
					$sideDom.find('.J-analysisEdit').show(300);
					self.aConfig.oSideDom.find('.J-perfect-analysis-wrap').hide();
				}
			});
		}
		$sideDom.find('.J-analysisEdit').delegate('textarea,:text', 'click', function(){
			lastActiveObject = this;
		});
		if(self.aConfig.hasCharInputer == 1){
			$sideDom.find('.J-char-input').unbind();
			$sideDom.find('.J-char-input').on('click', function(){
				CharInputer.show();
			});
		}else{
			$sideDom.find('.J-char-input').hide();
		}
		
		if(self.aConfig.page == self.PAGE_PRACTIC){
			if(aData.adaptive_learning_text.length > 0){
				adativingLearningHtml += '<div class="title" id="adativingLearningText">' + aData.adaptive_learning_text + '</div>';
				adativingLearningClass = ' al';
			}else{
				adativingLearningClass = '';
			}
		}

		if(aData.is_correct == 1){
			answerJudge = aData.task_continuous_correct_count === undefined ? aData.chanllge_continuous_correct_count : aData.task_continuous_correct_count;
			answerJudgeText = '本关' + (self.aConfig.page == self.PAGE_PRACTIC ? '修炼' : '挑战') + '已连续答对 ' + answerJudge + ' 题！';
			experience = '<span class="point">经验+' + aData.hit_accumulate_points + '</span>';
			++aBoxPlan.es_correct_count;
			++aBoxPlan.es_count;
			--self.aConfig.aMission.challenge_es_count;

			if(aData.task_continuous_correct_count >= 15){
				answerClass = 'perfect';
			}else{
				answerClass = 'success';
			}
		}else if(aData.is_correct == 0){
			answerJudgeText = '请再接再厉！';
			experience = '';
			++aBoxPlan.es_count;
			--self.aConfig.aMission.challenge_es_count;
			--self.challenge_limit_blood;

			answerClass = 'fail';
		}

		_updateSideBoxPlan();
		$('.J-propBar').css('visibility', 'hidden');

		return '<div class="result-warp ' + adativingLearningClass + ' J-result-warp">\
				<div class="title-warp">\
					' + adativingLearningHtml + '\
				</div>\
				<div class="result">\
					<div class="description ' + answerClass + '">\
						<div class="stauts">\
							<i class="icon"></i>\
						</div>\
						<div class="info">\
							<span class="mark">' + aData.hit_word + '</span>\
							' + experience + '\
							<span class="continue">' + answerJudgeText + '</span>\
						</div>\
					</div>\
				</div>\
			<span class="triangle-down"></span>\
		</div>';
	}

	//更新右侧第一个进度框数据
	function _updateSideBoxPlan(){
		var aBoxPlan = self.aConfig.aUserMission,
			aData = self.aConfig.aMission,
			$sideDom = self.aConfig.oSideDom,
			rightEsAccuracy = '',
			process = 0,
			PlnTextType = {};

		if(self.aConfig.page == self.PAGE_CHALLENGE){
			process = self.aConfig.aDataBoxPlan.esNumber * 10;
			process = process > 100 ? 100 : process;
			rightEsAccuracy = Math.round(process) >= 100 ? '<a href="' + self.aConfig.analysisUrl + '" class="complete">挑战成功，点击查看战绩</a>' : process + '%';
		}else{
			process = ((aBoxPlan.is_task_finish != 0) || (aBoxPlan.es_correct_count >= 20)) ? 100 : (aBoxPlan.es_correct_count / self.aConfig.aMission.task_content.correct_counts * 100).toFixed(2);
			process = process > 100 ? 100 : process;
			rightEsAccuracy = Math.round(process) >= 100 ? '<a href="' + self.aConfig.challengeUrl + '" class="complete">修炼完成，点击立即进入挑战</a>' : process + '%';
		}

		PlnTextType = {
			'page_practic' : {
				left : parseInt(aBoxPlan.es_correct_count) < 10 ? '0' + aBoxPlan.es_correct_count : aBoxPlan.es_correct_count,
				centent : (aBoxPlan.es_count == 0 ? 0 : Math.round(aBoxPlan.es_correct_count / aBoxPlan.es_count * 100)) + '%',
				right :  parseInt(aBoxPlan.es_count) < 10 ? '0' + aBoxPlan.es_count : aBoxPlan.es_count

			},
			'page_challenge' : {
				left : '00:00',
				centent : parseInt(self.challenge_limit_blood) < 10 ? '0' + self.challenge_limit_blood : self.challenge_limit_blood,
				right : parseInt(aData.challenge_es_count) < 10 ? '0' + aData.challenge_es_count : aData.challenge_es_count
			}
		};

		self.aConfig.oSideDom.find('.J-thisProcessWidth').css('width', process + '%');
		self.aConfig.oSideDom.find('.J-thisProcessBarText').html(rightEsAccuracy);
		$sideDom.find('.J-thisProcessText').text(PlnTextType[self.aConfig.page].centent);
		$sideDom.find('.J-thisAnswerCounts').text(PlnTextType[self.aConfig.page].right);

		if(self.aConfig.page == self.PAGE_PRACTIC){
			$sideDom.find('.J-thisCorrectCounts').text(PlnTextType[self.aConfig.page].left);
		}

		if(self.challenge_limit_blood == 0){
			self.isLost = true;
			_showChallenge({is_correct : 0, remain_time : 1});
			_$resultDialog.modal({backdrop : 'static', 'show' : true});
			return false;
		}
	}

	/**
	 * 发表解题思路
	 * @returns {undefined}
	 */
	function _publishThinking(){
		var $content = self.aConfig.oSideDom.find('.J-solutionContent');
		var content = $.trim($content.val());

		var $tipsText = $('.J-analysisOptionTips');
		if(content.length < 5){
			$tipsText.text('最小5个字符！');
			return;
		}
		if(content.length > 300){
			$tipsText.text('最大300个字符！');
			return;
		}
		if(content == '我来提供正确的解题思路!'){
			$tipsText.text('内容不能为空');
			return;
		}

		ajax({
			url : self.aConfig.publishSolutionUrl,
			data : {
				es_id : _$es.data('es').id
				,content : content
			},
			beforeSend:function(){
				$('.J-btnPublishSolution').text('发表中..').addClass('disabled');
			},
			timeout: 15000,
			success : function(aResult){
				$('.J-btnPublishSolution').text('发表').removeClass('disabled');
				if(aResult.status == 0){
					$tipsText.text('发表失败!');
					return;
				}else if(aResult.status == -1){
					UBox.show(aResult.msg, aResult.status);
					$tipsText.text('已有解题在审核中');
					 setTimeout(function(){
						  $tipsText.text('');
					 }, 2000);
					return;
				}else if(aResult.status == 1){
					$('.J-analysisTipsContent').html(content).removeClass('hidedata');
					$('.J-analysisEdit').hide();
					$tipsText.text('发表成功!');
					UBox.show(aResult.msg, aResult.status);
				}
				$content.val('');
			},
			afterError : function(oXhr){
				$tipsText.text('网络超时!');
				return;
			}
		});
	}

	/**
	 * 提交题目反馈
	 * @returns {undefined}
	 */
	function _pubilshFeedBack(){
		var oBtn = $('.J-btnFeedBack'),
			$feedbackTip = self.aConfig.oAnswerDom.find('.J-feedBackTip'),
			$feedbackContent = self.aConfig.oAnswerDom.find('.J-feedBackConters');
		oBtn.text('发表中...').addClass('disabled');
		var xAnswer = _$es.buildAnswer();
		if(xAnswer === undefined){
			xAnswer = '';
		}

		var reason = $.trim($feedbackContent.val());
		if(!reason){
			UBox.show('请输入反馈原因');
			return;
		}

		ajax({
			url : self.aConfig.esFeedBackUrl,
			data : {
				es_id : _$es.data('es').id,
				mission_id : self.aConfig.aMission.id,
				reason : reason,
				user_answer : xAnswer
			},
			timeout: 15000,
			complete : function(){
				oBtn.text('发表').removeClass('disabled');
			},
			success : function(aResult){
				if(aResult.status != 1){
					$feedbackTip.text(aResult.msg);
					return;
				}

				$feedbackTip.text('发表成功!');
				$feedbackContent.val('');

				_aAnswerHistory.length > 1 && ajax({
					url : self.aConfig.feedbackAddtionalUrl,
					data : {
						reason : self.aConfig.page + '页面\n' + reason,
						additionalInformation : _aAnswerHistory
					},
					success : $.noop
				});
			},
			afterError : function(oXhr){
				$feedbackTip.text('网络超时，请重试!');
				return;
			},
			delayTime : 3000,
			afterDelay : function (aResult) {
				if(aResult.status == 1){
					self.aConfig.oAnswerDom.find('.J-btnCloseFeedback').trigger('click');
					$feedbackTip.text('');
				}
			}
		});
	}

	//挑战提示状况
	function _showChallenge(aEs){
		var returnHtml = '',
			cardHtml = '',
			aEsRight = {},
			cardListHtml = '',
			pointHtml = '';

		for(var i = 0; i < 5; i++){
			cardListHtml += '<li class="J-cardItem">\
				<a href="javascript:void(0);">\
					<img src="' + self.aConfig.cardImgSrc + '" data-index="' + i + '" class="bg J-cardList' + i + '">\
				</a>\
			</li>';
		}

		cardHtml += ' <div class="card">\
			<ul class="list-unstyled">\
				' + cardListHtml + '\
			</ul>\
		</div>';

		if(aEs.is_correct === 0 && self.challenge_limit_blood > 0 && self.isLost === false){
			aEs.is_correct = 1;
		}

		if(aEs.accumulate_points != 0){
			pointHtml = '<div class="point">本关挑战获得奖励：' + aEs.accumulate_points + '经验' + (aEs.is_show_cards ? ' + 抽卡一次' : '') + '</div>';
		}else{
			pointHtml = aEs.is_show_cards ? '<div class="point">本关挑战获得奖励： 抽卡一次 </div>' : '';
		}

		aEsRight = {
			0 : {
				boxClass : 'fail',
				title : (parseInt(aEs.remain_time) > 0) ? '抱歉，由于生命值耗尽，挑战失败！' : '抱歉，由于时间耗尽，本次挑战失败',
				pointHtml : (parseInt(aEs.remain_time) > 0) ? '<div class="point J-propFail" style="color:#666;">您还可以选择使用复活道具进行复活</div>' : '',
				guideHtml : '<div class="guide">接下来你可以选择 回去修炼 或 再挑战一次</div>',
				cardHtml : '<div class="card J-card"></div>',
				optsHtml : '<a href="' + self.aConfig.practicUrl + '" class="um-btn um-btn-error um-btn-xlg">回去修炼</a>\
							<a href="' + self.aConfig.challengeUrl + '" class="um-btn um-btn-error um-btn-xlg">再次挑战</a>',
				footHtml : '<div class="ft"><div class="tip">温馨提示：' + self.aConfig.aFailedTips + '</div></div>'
			},
			1 : {
				boxClass : 'perfect',
				title : '恭喜，本次挑战成功！得分' + (aEs.score / 100),
				pointHtml : pointHtml,
				guideHtml : '<div class="guide J-guide">' + (aEs.is_show_cards ? '请点击抽选一张卡牌' : '接下来你可以选择 再次挑战 或 查看战绩') + '</div>',
				cardHtml  : aEs.is_show_cards ? cardHtml : '',
				optsHtml  : '<a href="' + self.aConfig.challengeUrl + '" class="um-btn um-btn-default um-btn-xlg">再挑战一次</a>\
							<a href="' + self.aConfig.analysisUrl + '" class="um-btn um-btn-default um-btn-xlg">去查看战绩</a>',
				footHtml : '<div class="ft"><div class="tip">温馨提示：' + self.aConfig.aSuccessTips + '</div></div>'
			}
		};

		returnHtml += '<!-- success perfect fail -->\
			<div class="um-mcommon um-mcard perfect ' + aEsRight[aEs.is_correct].boxClass + ' J-mcard">\
				<div class="hd">\
					' + aEsRight[aEs.is_correct].title + '\
				</div>\
				<div class="bd">\
						'+ aEsRight[aEs.is_correct].pointHtml +'\
						'+ aEsRight[aEs.is_correct].cardHtml +'\
						'+ aEsRight[aEs.is_correct].guideHtml +'\
						<div class="opts J-opts"> <!-- um-btn-error -->'+ aEsRight[aEs.is_correct].optsHtml +'</div>\
				</div>\
				<div class="tip J-tip">'+ aEsRight[aEs.is_correct].footHtml +'</div>\
		</div>';

		$('.J-dialogBox').html(returnHtml);
		if(aEs.is_show_cards){
			$('.J-opts, .J-tip').addClass('hide');
		}

		if(aEs.is_correct == 0){
			self.timeReducePause();
			self.isLost = true;
		}
		Prop.sceneData.isGameOver = true;
		_drawCard();
		//生命结束并且当前答题数不是最后一题的时候
		if((self.challenge_limit_blood < 1) && self.aConfig.aMission.challenge_es_count > 0){
			$('.J-card').css('height', '150px');
			Prop.getPropBar(2, function($propBar){
				var $propWrap = $('<div class="J-dialogPropBar"></div>');
				$propWrap.append($propBar);
				 _$resultDialog.css('width', '650px').append($propWrap);
			}, self.aConfig.aMission.id);
			$('#mCommon .J-prorpBarParent').css({
				'position':'absolute',
				'top' : '140px',
				'width' : '95%'
			});
		}
		_modalVerticalCenter('#mCommon');
		return;
	}

	// 抽卡
	function _drawCard(){
		$('.J-mcard').find('.bg').each(function(){
			$(this).on('click', function(){
				var $this = $(this);
				var index = $this.data('index');

				ajax({
					url : self.aConfig.getCardUrl,
					data : {
						mission_user_relation_id : self.aConfig.aUserMission.id,
						index : 2
					},
					success : function(aResult){
						if(aResult.status != 1){
							UBox.show(aResult.msg, aResult.status);
							return;
						}

						var aData = aResult.data;
						if(aData.type == 1){
							$('.J-cardList' + index).after('<img src="' + aData.card_info.profile + '"/>');
							$('.J-guide').html('您抽中了 "' + aData.card_info.name + '" 卡' + (aData.card_info.is_new_card ? '' : '，您的卡牌中已有此卡。'));
						}else if(aData.type == 2){
							$('.J-cardList' + index).after('<img src="' + self.aConfig.magicImgSrc + '" class="J-wzMagic"/>');
							 _isMagic($this, aData.card_info.magic_key);
						}
						$this.animate({
							'opacity': 0,
							'top': '-25%'
						},500);

						$('.um-mcard').find('.bg').off('click');
						$('.J-opts, .J-tip').removeClass('hide');
						_modalVerticalCenter('#mCommon');

					}
				});
			});
		});
	}
	//抽魔法卡
	function _isMagic(obj , magicKey){
		$('.J-guide').html('恭喜抽中了<b style="color:#09F;">魔力卡</b>,\
		是否释放魔力？<a class="J-useMagic" style="color:#09F;">释放</a>，\
		<a class="J-discard" style="color:#09F;">丢掉</a>？');
		$('.J-discard').click(function(){
			$('.J-guide').html('很遗憾，魔力卡已经丢掉！');
			$('.J-opts, .J-tip').removeClass('hide');
		});
		$('.J-useMagic').click(function(){
			ajax({
				url : self.aConfig.useMagicUrl,
				data : {
					magic_key : magicKey
				},
				success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					var aData = aResult.data;
					var index = obj.data('index');
					var magicCardPosition = _$resultDialog.find('.J-wzMagic').closest('.J-cardItem').index();
					if(aData.type == 1){
						var cardItemNums = _$resultDialog.find('.J-cardItem').length;
						var aTemp = [magicCardPosition];
							for (var v in aData.card_list) {
								var n = 0;
								do {
									n = Math.floor(Math.random() * cardItemNums + 1) - 1;
								} while ($.inArray(n, aTemp) > -1);
								$('.J-cardList' + n).attr('src', aData.card_list[v].profile);
								aTemp.push(n);
							}

						$('.J-guide').html('魔力卡的正面魔力发挥了巨大作用带来了两张卡！');
					}else if(aData.type == 2){
						if(aData.card_list.length < 1){
							$('.J-guide').html('您什么也没得到！');
							return;
						}
						$('.J-wzMagic').attr('src', aData.card_list.profile);
						$('.J-guide').html('很遗憾，魔力卡的毁灭力量毁灭了您现有的一张卡！');
					}
					$('.J-opts, .J-tip').removeClass('hide');
					_modalVerticalCenter('#mCommon');

				}
			});
		});
	}

	//闯关成功反馈
	function _showSuccesOverMission(aEs){
		var point = aEs.accumulate_points > 0 ? '<div class="point">本关修炼获得奖励：' + aEs.accumulate_points + '经验</div>' : '';
		$('.J-dialogBox').html('<!-- success perfect fail -->\
		<div class="um-mcommon um-mcard perfect J-mcard">\
			<div class="hd">\
				恭喜，你已经完成了本关修炼任务！\
			</div>\
			<div class="bd">\
				' + point + '\
				<div class="guide">接下来你可以选择 继续修炼 或 立刻挑战</div>\
				<div class="opts">\
					<!-- um-btn-error -->\
					<a href="javascript:void(0);" class="um-btn um-btn-default um-btn-xlg" data-dismiss="modal">继续修炼</a>\
					<a href="' + self.aConfig.challengeUrl + '" class="um-btn um-btn-default um-btn-xlg">立刻挑战</a>\
				</div>\
			</div>\
			<div class="ft">\
				<div class="tip">' + self.aConfig.aSuccessTips + '</div>\
			</div>\
		</div>');
		_modalVerticalCenter('#mCommon');

		$('.J-challengeUrl').removeClass('disabled').find('a').attr('href', self.aConfig.challengeUrl);
		self.aConfig.oSideDom.find('.J-thisProcessWidth').css('width', '100%').removeClass('J-thisProcessWidth');
		self.aConfig.oSideDom.find('.J-thisProcessBarText').html('<a href="' + self.aConfig.challengeUrl + '" class="complete">修炼完成，点击立即进入挑战</a>').removeClass('J-thisProcessBarText');
		return;
	}

	//监听解题思路输入状态
	function _sideMonitorInputMinFont300(){
		var $this = self.aConfig.oSideDom.find('.J-solutionContent');
		$this.focus(function(){
			if($this.val() == '我来提供正确的解题思路!'){
				$this.val('');
			}
		}).blur(function(){
			if($this.val().length < 1){
				$this.val('我来提供正确的解题思路!');
			}
		});

		$this.on('input propertychange', function() {
			var $oFontHtml = self.aConfig.oSideDom.find('.J-analysisfont'),
				$this = $(this),
				fontCount = $this.val().length;
			if(fontCount > 300){
				$oFontHtml.html('不能再写了');
				$this.val($this.val().substr(0, 300));
				return false;
			}
			$oFontHtml.text(fontCount);
		});
	}

	//更新侧栏历史数据
	function _updateSideBar(aEs){
		self.aConfig.oSideDom.find('.J-processWidth').css('width', aEs.correct_percent + '%');
		self.aConfig.oSideDom.find('.J-processText').html(aEs.correct_percent + '%');
		self.aConfig.oSideDom.find('.J-correctCounts').text((parseInt(aEs.answer_counts) < 10 ? '0' + aEs.answer_counts : aEs.answer_counts));
		var answerTimeTotal = aEs.answer_time_total == 0 ? '00' : (aEs.answer_time_total / aEs.answer_counts).toFixed(1);
		self.aConfig.oSideDom.find('.J-answerCounts').text(answerTimeTotal);
	}

	/**
	 * 初始化道具相关的东西
	 * @param {type} scene
	 * @returns {undefined}
	 */
	function _initProp(scene) {
		Prop.getPropBar(scene, function($propBar){
			$propBar.appendTo(self.$propBar);
		}, self.aConfig.aMission.id);
		Prop.sceneData.missionId = self.aConfig.aMission.id;

		if(self.aConfig.page == self.PAGE_CHALLENGE){
			//时光凝结使用条件检查
			Prop.bindEvent(Prop.EVENT_BEFORE_USE_SGNJ, function (oEvent) {
				var isOk = true;
				if(self.isLost){
					UBox.show('已经输啦', -1);
					isOk = false;
				}else if(_remainSeconds < 1){
					UBox.show('已经没时间啦', -1);
					isOk = false;
				}

				oEvent.xListenerData.isOk = isOk;
			});

			//实现使用时光凝结
			Prop.bindEvent(Prop.EVENT_USE_SGNJ, function (oEvent) {
				if(_isUsingSgnj){
					UBox.show('你已经正在使用时光凝结了，不要重复使用哦！', -1);
					return;
				}
				_isUsingSgnj = true;
				self.timeReducePause();
				UBox.show('时间已经停止，加紧做题哦！', 1);
			});

			//实现使用时光凝结
			Prop.bindEvent(Prop.EVENT_SGNJ_TIME_OVER, function (oEvent) {
				_isUsingSgnj = false;
				self.timeReduceStart();
				UBox.show('时光凝结已经失效，加紧做题哦！', 1);
			});

			//千年人参使用条件检查
			Prop.bindEvent(Prop.EVENT_BEFORE_USE_QNRS, function (oEvent) {
				var isOk = true;
				if(_remainSeconds < 1){
					UBox.show('挑战的限制时间已经结束了哦！', -1);
					isOk = false;
				}else if(self.challenge_limit_blood < 1){
					UBox.show('你已经输了,无法加血', -1);
					isOk = false;
				}else if(self.challenge_limit_blood == self.aConfig.aMission.challenge_limit_blood){
					UBox.show('你已经是满血状态了', -1);
					isOk = false;
				}

				oEvent.xListenerData.isOk = isOk;
			});

			//实现使用千年人参
			Prop.bindEvent(Prop.EVENT_USE_QNRS, function (oEvent) {
				self.challenge_limit_blood += oEvent.xSenderData.add_life_nums;
				_updateSideBoxPlan();
				UBox.show('好！恢复了' + oEvent.xSenderData.add_life_nums + '点生命值，继续加油！', 1);
			});


			//万年人参使用条件检查
			Prop.bindEvent(Prop.EVENT_BEFORE_USE_WNRS, function (oEvent) {
				var isOk = true;
				if(_remainSeconds < 1){
					UBox.show('挑战的限制时间已经结束了哦！', -1);
					isOk = false;
				}else if(self.challenge_limit_blood == 0){
					UBox.show('你已经挑战失败，只能通过复活功能道具进行恢复了', -1);
					isOk = false;
				}else if(self.challenge_limit_blood == self.aConfig.aMission.challenge_limit_blood){
					UBox.show('你已经是满血状态了', -1);
					isOk = false;
				}
				oEvent.xListenerData.isOk = isOk;
			});

			//实现使用万年人参
			Prop.bindEvent(Prop.EVENT_USE_WNRS, function (oEvent) {
				self.challenge_limit_blood = self.aConfig.aMission.challenge_limit_blood;
				_updateSideBoxPlan();
				UBox.show('好！生命值完全恢复，继续加油！', 1);
			});


			//还魂灵符使用条件检查
			Prop.bindEvent(Prop.EVENT_BEFORE_USE_HHLF, function (oEvent) {
				var isOk = true;
				if(_remainSeconds < 1){
					UBox.show('挑战的限制时间已经结束了哦！', -1);
					isOk = false;
				}else if(self.challenge_limit_blood > 0){
					UBox.show('你还有生命值，无须使用', -1);
					isOk = false;
				}

				oEvent.xListenerData.isOk = isOk;
			});

			//实现使用还魂灵符
			Prop.bindEvent(Prop.EVENT_USE_HHLF, function (oEvent) {
				self.challenge_limit_blood = 1;
				_updateSideBoxPlan();
				UBox.show('好！再错就会失败了，小心出招哦！', 1);
				self.setBtnAnswer(1);
				self.timeReduceStart();
				_$resultDialog.modal('hide');
				_$resultDialog.find('.J-dialogPropBar').remove();
				 Prop.sceneData.isGameOver = false;
				self.isLost = false;
			});


			//还魂琼浆露使用条件检查
			Prop.bindEvent(Prop.EVENT_BEFORE_USE_HHQJL, function (oEvent) {
				var isOk = true;
				if(_remainSeconds < 1){
					UBox.show('挑战的限制时间已经结束了哦！', -1);
					isOk = false;
				}else if(self.challenge_limit_blood > 0){
					UBox.show('你还有生命值，无须使用', -1);
					isOk = false;
				}

				oEvent.xListenerData.isOk = isOk;
			});

			//实现使用还魂琼浆露
			Prop.bindEvent(Prop.EVENT_USE_HHQJL, function (oEvent) {
				self.challenge_limit_blood = self.aConfig.aMission.challenge_limit_blood;
				_updateSideBoxPlan();
				self.timeReduceStart();
				UBox.show('好！生命值完全恢复，继续加油！', 1);
				self.setBtnAnswer(1);
				self.timeReduceStart();
				 _$resultDialog.modal('hide');
				_$resultDialog.find('.J-dialogPropBar').remove();
				 Prop.sceneData.isGameOver = false;
				self.isLost = false;
			});
		}
	}

	MissionAnswer = $.extend(MissionAnswer, new Component());

	var self = MissionAnswer;

	var  _$resultDialog = null;

	var _$es = null,	//当前题目插件对象
	_remainSeconds = 0,
	_isUsingSgnj = false,	//是否正在使用时光凝结
	_timeReduceTimer = undefined,
	_retryGetEsTimes = 1,
	_timeFlickerTimer = undefined,
	_aAnswerHistory = [];
})(jQuery, window);
var lastActiveObject = null;