(function($,win){
	win.MissionAnalysis = {
		aMissionRankListCache : {},
		missionId : 0,
		isPassMission : 0,
		isCanEnterChallenge : 0,
		missionRankingListPage : 1,
		missionRankingListType : 0,
		missionRankingListPageSize : 0,
		isAjaxGettingMissionRanking : false,

		showUmManswerHeader : function(missionHomeUrl, missionListUrl, practicUrl, challengeUrl, gradeStr, subjectStr, missionName){
			var htmlStr = '';
			var liClass = '';
			if(this.isCanEnterChallenge == 0){
				liClass = 'class="disabled"';
				challengeUrl = 'javascript:;';
			}
			htmlStr += '\
				<div class="um-manswer-header">\
					<div class="title">\
						<a href="' + missionHomeUrl + '">闯关</a><b>></b><a href="' + missionListUrl + '">' + gradeStr + ' &middot; ' + subjectStr + '</a><b>></b>' + missionName + '\
					</div>\
					<div class="nav">\
						<ul class="list-unstyled">\
							<li ><a href="' + practicUrl + '">修炼</a></li>\
							<li ' + liClass + '><a href="' + challengeUrl + '">挑战</a></li>\
							<li class="active"><a href="javascript:;" >战绩</a></li>\
							<li class="back"><a href="' + missionHomeUrl + '">返回列表</a></li>\
						</ul>\
					</div>\
				</div>\
			';
			$('.J-um-manswer-header').html(htmlStr);
		},

		showMgradeStatistic : function(challengeUrl, challengeCount, esCount, esCorrectCount, correctPercent, wrongEsCount, selectEsCount, fillEsCount, judgeEsCount, score, defeatPercent){
			var htmlStr = '';

			htmlStr = '\
				<div class="hd">\
					<span class="title"><i class="v3-goldstar"></i><b>本关战绩统计</b><i class="v3-goldstar"></i></span>\
				</div>\
				<div class="bd">\
					<div class="l">\
						<ul class="list-unstyled">\
							<li>\
								<a>\
									<span class="num">' + challengeCount + '</span>\
									<span class="text">挑战次数</span>\
								</a>\
							</li>\
							<li>\
								<a>\
									<span class="num">' + esCount + '</span>\
									<span class="text">答题总数</span>\
								</a>\
							</li>\
							<li>\
								<a>\
									<span class="num">' + esCorrectCount + '</span>\
									<span class="text">答对题数</span>\
								</a>\
							</li>\
							<li>\
								<a>\
									<span class="num">' + correctPercent + '%</span>\
									<span class="text">总正确率</span>\
								</a>\
							</li>\
						</ul>\
					</div>\
					<div class="r">\
						<ul class="list-unstyled">\
							<li>\
								<a>\
									<span class="num">' + wrongEsCount + '</span>\
									<span class="text">错题总数</span>\
								</a>\
							</li>\
							<li>\
								<a>\
									<span class="num">' + selectEsCount + '</span>\
									<span class="text">选择题数</span>\
								</a>\
							</li>\
							<li>\
								<a>\
									<span class="num">' + fillEsCount + '</span>\
									<span class="text">填空题数</span>\
								</a>\
							</li>\
							<li>\
								<a>\
									<span class="num">' + judgeEsCount + '</span>\
									<span class="text">判断题数</span>\
								</a>\
							</li>\
						</ul>\
					</div>\
					<div class="total-grade">\
						<div class="score">' + score + '</div>\
						<div class="discription">超越了' + defeatPercent + '%挑战者</div>\
					</div>\
				</div>\
				<div class="ft">\
					<div class="opts">\
						<a href="' + challengeUrl + '" class="um-btn um-btn-xlg um-btn-gold">再次挑战</a>\
					</div>\
				</div>\
			';

			$('.J-mgrade-analysis').html(htmlStr);
		},

		showMgradeRanklist : function(score, rank){
			var htmlStr = '';

			htmlStr = '\
				<div class="hd">\
					<span class="title"><i class="v3-goldstar"></i><b>本关战绩排行</b><i class="v3-goldstar"></i></span>\
				</div>\
				<div class="bd">\
					<div class="caption">\
						<span class="J-mission-start topstar"></span>\
						<span class="tab-nav">\
							<a href="javascript:;" class="J-select-friend-mission-ranking" onclick="MissionAnalysis.selectRankingType(this, 1);">\
								好友排行\
							</a>\
							<a href="javascript:;" class="J-select-world-mission-ranking active" onclick="MissionAnalysis.selectRankingType(this, 0);">\
								全部排行\
							</a>\
						</span>\
						<span class="info">\
							' + ((this.isPassMission == 1) ? ('我的最高得分' + score + '，好友排行' + rank + '') : '') + '\
						</span>\
					</div>\
					<div class="J-mission-ranking-list list-warp"></div>\
				</div>\
				<div class="ft">\
					<div class="opts">\
						<a href="javascript:;" class="J-prev-rank-btn um-btn-ghost um-btn-default um-btn-xs" onclick="MissionAnalysis.prevPageMissionRankingList();">上一页</a>\
						<a href="javascript:;" class="J-next-rank-btn um-btn-ghost um-btn-default um-btn-xs" onclick="MissionAnalysis.nextPageMissionRankingList();">下一页</a>\
					</div>\
				</div>\
			';

			$('.J-mgrade-ranklist').html(htmlStr);
		},

		showPage : function(){
			var htmlStr = '';
			htmlStr = '\
				<div class="contain">\
					<div class="J-um-manswer-header title-bar"></div>\
					<div class="J-statisitcs um-layout-full">\
						<div class="main">\
							<div class="J-mgrade-analysis um-mgrade-analysis"></div>\
							<div class="J-mgrade-ranklist um-mgrade-ranklist"></div>\
						</div>\
					</div>\
				</div>\
			';

			$('.J-analysis-page').html(htmlStr);
		},

		showMissionRankingList : function(page, type){
			if(_chkIsAjaxGettingMissionRanking()){
				return ;
			}
			var oAnalysis = this;
			var keyStr = 'key_' + type + '_' + page;
			if(typeof(oAnalysis.aMissionRankListCache[keyStr]) != 'undefined'){
				_afterGettingMissionRankList(oAnalysis.aMissionRankListCache[keyStr], page, type);
				return;
			}
			oAnalysis.isAjaxGettingMissionRanking = true;
			ajax({
				url : self.missionRankingListUrl,
				data : {
					page : page,
					type : type,
					mission_id : oAnalysis.missionId
				},
				success : function(aResult){
					oAnalysis.isAjaxGettingMissionRanking = false;
					oAnalysis.aMissionRankListCache[keyStr] = aResult.data;
					if(aResult.status == 1){
						_afterGettingMissionRankList(aResult.data, page, type);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(){
					oAnalysis.isAjaxGettingMissionRanking = false;
					UBox.show('抱歉，系统错误！', 0);
				}
			});
		},

		nextPageMissionRankingList : function(){
			if(_chkIsAjaxGettingMissionRanking()){
				return ;
			}
			this.showMissionRankingList(++this.missionRankingListPage, this.missionRankingListType);
		},

		prevPageMissionRankingList : function(){
			if(_chkIsAjaxGettingMissionRanking()){
				return ;
			}
			if(this.missionRankingListPage == 1){
				$('.J-prev-rank-btn').removeClass('active');
				return;
			}
			this.showMissionRankingList(--this.missionRankingListPage, this.missionRankingListType);
		},

		selectRankingType : function(o, type){
			if(this.missionRankingListType == type){
				return;
			}
			$(o).parent().children().removeClass('active');
			$(o).addClass('active');
			this.missionRankingListPage = 1;
			this.showMissionRankingList(1, type);
		},

		showMissionStar : function(aData){
			var htmlStr = '';
			htmlStr = '\
				本关之星:\
				' + Ui1.buildProfile({id : aData.id, profile: aData.profile}, true, {addClass : 'circle'}) + '\
				' + Ui1.buildVipName(aData, true) + '\
				' + (parseInt(aData.score) / 100) + '\
			';

			$('.J-mission-start').html(htmlStr);
		}
	};

	function _appendMissionRankingList(aData){
		var aHtml = [];
		if(self.missionRankingListPage == 1 && self.missionRankingListPageSize < aData.length){
			self.missionRankingListPageSize = aData.length;
		}
		for(var index in aData){
			if(index == 0 || index == 10 || index == 20 || index == 30){
				if(index == 30){
					aHtml.push('<div class="list-box noline">');
				}else{
					aHtml.push('<div class="list-box">');
				}
				aHtml.push('<ul class="list-unstyled">');
			}
			var oTemp = aData[index];
			var rank = ((self.missionRankingListPage - 1) * self.missionRankingListPageSize) + parseInt(index) + 1;
			aHtml.push('<li>');
			if(rank <= 3){
				aHtml.push('<span class="num" id="rankNum' + rank + '"><i class="v3-no' + rank + '"></i></span>');
			}else{
				aHtml.push('<span class="num" id="rankNum' + rank + '">' + rank + '</span>');
			}
			aHtml.push('<span class="info">');
			aHtml.push(Ui1.buildProfile({id : oTemp.user_info.id, profile: oTemp.user_info.profile}, true, {addClass : 'circle'}));
			aHtml.push('&nbsp;' + Ui1.buildVipName(oTemp.user_info, true));
			aHtml.push('</span>');
			aHtml.push('<span class="rank">' + oTemp.score + '</span>');
			aHtml.push('</li>');
			if(index == 9 || index == 19 || index == 29 || index == 39){
				aHtml.push('</ul>');
				aHtml.push('</div>');
			}
		}
		if(!(aData.length == 10 || aData.length == 20 || aData.length == 30 || aData.length == 40)){
			aHtml.push('</ul>');
			aHtml.push('</div>');
		}

		$('.J-mission-ranking-list').html(aHtml.join(''));
	}

	function _chkIsAjaxGettingMissionRanking(){
		if(self.isAjaxGettingMissionRanking){
			UBox.show('操作过于频繁，请稍后再试！', -1);
			return true;
		}

		return false;
	}

	function _afterGettingMissionRankList(aData, page, type){
		if(aData.length > 0){
			_appendMissionRankingList(aData);
			self.missionRankingListPage = page;
			self.missionRankingListType = type;
			if(self.missionRankingListPage != 1){
				$('.J-prev-rank-btn').addClass('active');
			}else{
				$('.J-prev-rank-btn').removeClass('active');
			}
			$('.J-next-rank-btn').addClass('active');
		}else{
			if(self.missionRankingListPage != 1){
				--self.missionRankingListPage;
			}else{
				$('.J-mission-ranking-list').html('<div class="emptydata" id="emptydata">你还没有好友参与本关战线排行！</div>');
			}
			if(self.missionRankingListPage != 1){
				$('.J-prev-rank-btn').addClass('active');
			}else{
				$('.J-prev-rank-btn').removeClass('active');
			}
			$('.J-next-rank-btn').removeClass('active');
		}
		if(self.missionRankingListType == 0){
			$('.J-select-world-mission-ranking').removeAttr('onclick');
			$('.J-select-friend-mission-ranking').attr('onclick', 'MissionAnalysis.selectRankingType(this, 1);');
		}else{
			$('.J-select-friend-mission-ranking').removeAttr('onclick');
			$('.J-select-world-mission-ranking').attr('onclick', 'MissionAnalysis.selectRankingType(this, 0);');
		}
		if(self.missionRankingListPage == 5){
			$('.J-next-rank-btn').removeClass('active');
		}
		if(self.missionRankingListPage == 1){
			if(aData.length < 40){
				$('.J-next-rank-btn').removeClass('active');
			}
		}
	}

	var self = win.MissionAnalysis;
})(jQuery,window);
