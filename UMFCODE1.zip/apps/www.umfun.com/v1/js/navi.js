/*
 * 优满分全局顶部导航条插件.
 * 2014-12-11 22:22:22
 */

(function($, window){
	window.Navi = {
		MENU_HOME : 'home',
		MENU_MISSION : 'mission',
		MENU_MATCH : 'match',
		MENU_PK : 'pk',
		MENU_EXCHANGE : 'exchange',
		MENU_TOPIC : 'topic',
		MENU_TASK : 'task',
		EVENT_ON_CLICK_PROP_MALL : 'porp_01',
		EVENT_ON_CLICK_GUIDE : 'guide_01',
		EVENT_ON_TASK : 'task',
		EVENT_ON_CLICK_SHOW_SKIN_SHOP : 'show_skin_shop',

		aConfig : {
			naviDom : null,
			userProfile : '',
			userNumericalUrl : '',

			homeUrl : '',
			missionUrl : '',
			matchUrl : '',
			pkUrl : '',
			exchangeUrl : '',
			topicUrl : '',

			esWrongListUrl : '',
			recordUrl : '',
			updatePassWord : '',
			userInfoUrl : '',
			updatePictureUrl : '',
			settingMobileUrl : '',

			eventNoticeUrl : '',
			friendNoticeUrl : '',
			ownPropertyUrl : '',
			newMessageUrl : '',

			vipUrl : '',
			payUrl : '',
			guildUrl : '',
			logoutUrl : '',
			friendUrl : '',
			isEmailActive: '',
			bindEmailUrl: '',
			isPhoneActive: '',
			bindPhoneUrl: '',
			homeworkUrl:'',
			bindQrCord:'',
			accountUrl: '',

			guideUrl: '',
			feedbackUrl: '',

			getClassListUrl: '',
			getClassInfoUrl: '',
			joinClassUrl: '',
			exitClassUrl: '',
			
			skinResult: ''
		},
		cache : '',
		setCurrentMenu : function(menuKey){
			self.aConfig.naviDom.find('.J-menu-' + menuKey).addClass('active');
		},
		getUserInfo : function(obj, isUpdate){
			var html = '';
			if(!isUpdate && self.cache){
				$(obj).html(self.cache);
				return;
			}

			ajax({
				url : self.aConfig.userNumericalUrl,
				type : 'GET',
				// error : function(){
				// 	$.error('请求头部用户信息失败');
				// 	return false;
				// },
				success : function(aResult){
					if(aResult.status != 1){
						alert(aResult.msg);
						return false;
					}
					var aUserInfo = App.oCurrentStudent,
						aOtherInfo = aResult.data;
					//var emailActiveIco = self.aConfig.isEmailActive ? 'v3-acc-active' : 'v3-acc';
					var phoneActiveIco = self.aConfig.isPhoneActive ? 'v3-acc-active' : 'v3-acc';
					html = '<!-- module -->\
					<div class="um-msubaccount">\
						<div class="um-opts-subaccount-hd">\
							' + Ui1.buildVipName(aUserInfo) + '\
							' + Ui1.buildVipIcon(aUserInfo.vip) + '\
							<a class="info" href="' + self.aConfig.bindPhoneUrl + '"><i class="' + phoneActiveIco + '"></i></a>\
							<a onclick="Navi.getUserInfo(\'#subAccount\', true);">\
								<i class="v3-reflash um-fr"></i>\
							</a>\
						</div>\
							\
						<div class="um-opts-subaccount-bd">\
							<div class="p1">\
								<ul class="list-unstyled">\
									<li>等级<em class="J-level">' + aUserInfo.level + '</em></li>\
									<li>经验<em class="J-points">' + aUserInfo.accumulate_points + '</em></li>\
									<li>金币<em class="J-gold">' + aUserInfo.gold + '</em></li>\
									<li>U币<em class="J-userUb">' + aUserInfo.ub + '</em></li>\
									<a class="subbtn" onclick="location.href=\'' + self.aConfig.accountUrl + '\'">U币换金币</a>\
								</ul>\
							</div>\
							<div class="p2">\
								<p class="">\
									<span>错题<em>' + aOtherInfo.es_wrong + '</em></span>\
									<a class="subbtn" onclick="location.href=\'' + self.aConfig.esWrongListUrl + '\'">立刻修复</a>\
								</p>\
								<p class="">\
									<span class="fl">道具<em>' + aOtherInfo.prop + '</em></span>\
									<a class="J-btn_showPropMall subbtn">查看道具</a>\
								</p>\
							</div>\
							<div class="p3">\
								<ul class="list-unstyled">\
									<li><a href="' + self.aConfig.friendUrl + '">好友<em>' + aOtherInfo.friend + '</em></a></li>\
									<li><a id="showClassBtn">我的班级</a></li>\
								</ul>\
							</div>\
						</div>\
						<div class="um-opts-subaccount-ft">\
							<span class="um-fl"><a href="' + self.aConfig.recordUrl + '">战绩</a></span>\
							<span class="um-fr"><a href="' + Ui1.buildZoneUrl(aUserInfo.id) + '">我的主页</a></span>\
						</div>\
					</div>\
					<!--end module-->';
					if(!self.cache || isUpdate){
						self.cache = html;
					}
					$(obj).html(html);
					$(obj).find('#showClassBtn').click(function(){
						ajax({
							url: self.aConfig.getClassListUrl,
							success: function(data){
								_showClass(data);
							}
						});
					});
					App.oCurrentStudent.updateInfo();
				}
			});
		},

		buildUserNumericalHtml : function(){
			var aUserInfo = App.oCurrentStudent,
			obj = $('#subAccount');
			obj.find('.J-level').html('LV' + aUserInfo.level).attr('title', 'LV' + aUserInfo.level);
			obj.find('.J-points').html(aUserInfo.accumulate_points).attr('title', aUserInfo.accumulate_points);
			obj.find('.J-gold').html(aUserInfo.gold).attr('title', aUserInfo.gold);
			obj.find('.J-userUb').html(aUserInfo.ub).attr('title', aUserInfo.ub);
			return;
		},

		config : function(aConfig){
			for(var key in self.aConfig){
				if(aConfig[key] == undefined){
					continue;
				}
				self.aConfig[key] = aConfig[key];
			}
			App.oCurrentStudent.bindEvent(App.oCurrentStudent.EVENT_AFTER_UPDATE_INFO, function(){
				self.buildUserNumericalHtml();
			});
		},

		show : function(){
			var hasFriendNotice = _buildTipDot('friend'),
				hasNewMessage = _buildTipDot('message'),
				hasEventNotice = _buildTipDot('event'),
				hasHomework = _buildTipDot('homework'),
				Navhtml = '',
				isTipDot = _buildTipDot(),
				userProfile = _buildProfile(),
				isVipGift = '',
				vipAndPayHtml = '';

			vipAndPayHtml += '<a href="' + self.aConfig.vipUrl + '" target="_blank">会员中心</a>\
							  <a href="' + self.aConfig.payUrl + '" target="_blank">充值中心</a>';
			Navhtml = '<div class="side-tool-container">\
					<div class="side_tool" id="sideTool">\
						<a style="display:none;" onclick="showHelpWindow(\'游戏指引\', \'' + self.aConfig.guideUrl + '\');",  title="指引">\
							<div class="tool-icon"><i class="ico_side_tool ico_side_tool_guide"></i></div>\
							<div class="title">指引</div>\
						</a>\
						\
						<a title="声明" onclick="Ui1.buildLegalNotices('+ '\'safety.html\''+',\'#header\');">\
							<div class="tool-icon"><i class="ico_side_tool2 ico_side_tool2_low"></i></div>\
							<div class="title">声明</div>\
						</a>\
						<a target="_blank" href="' + self.aConfig.feedbackUrl + '" title="反馈">\
							<div class="tool-icon"><i class="ico_side_tool ico_side_tool_feedback"></i></div>\
							<div class="title">反馈</div>\
						</a>\
						<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=2025928896&site=qq&menu=yes" title="客服">\
							<div class="tool-icon"><i class="ico_side_tool ico_side_tool_contact"></i></div>\
							<div class="title">客服</div>\
						</a>\
						<a title="APP" class="qr_code_label">\
							<div class="J-show_qr_code qr_code_show">\
								<div>扫一扫</div>\
								<div id="qr_code_content" class="qr_code_content">\
									<img src="'+ self.aConfig.bindQrCord+'">\
									<div class="loading_img">加载中</div>\
								</div>\
								<div>下载优满分APP</div>\
							</div>\
							<div class="tool-icon"><i class="ico_side_tool_app"></i></div>\
							<div class="title">APP</div>\
						</a>\
					</div>\
					</div>\
					<!-- module -->\
					<div class="um-mheader">\
						<div class="um-logo">\
						<a href="' + self.aConfig.homeUrl + '" class="item"><i class="v3-logo"></i></a>\
						</div>\
							\
						<!-- 导航栏 -->\
						<div class="um-nav J-nav">\
							<ul class="list-unstyled">\
								<li data-text="首页" class="J-menu-' + self.MENU_HOME + '">\
									<span class="um-nav-bgc h-home"></span>\
									<a href="' + self.aConfig.homeUrl + '" class="item">\
										<i class="v3-home"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
								<li data-text="闯关" class="J-menu-' + self.MENU_MISSION + '">\
									<span class="um-nav-bgc h-mission J-um-nav-bgc"></span>\
									<a href="' + self.aConfig.missionUrl + '" class="item">\
										<i class="v3-mission"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
								<li data-text="比赛" class="J-menu-' + self.MENU_MATCH + '">\
									<span class="um-nav-bgc h-match J-um-nav-bgc"></span>\
									<a href="' + self.aConfig.matchUrl + '" class="item">\
										<i class="v3-match"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
								<li data-text="PK" class="J-menu-' + self.MENU_PK + '">\
									<span class="um-nav-bgc h-pk J-um-nav-bgc"></span>\
									<a href="' + self.aConfig.pkUrl + '" class="item">\
										<i class="v3-pk"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
								<li data-text="兑换" class="J-menu-' + self.MENU_EXCHANGE + '">\
									<span class="um-nav-bgc h-exchange"></span>\
									<a href="' + self.aConfig.exchangeUrl + '" class="item">\
										<i class="v3-exchange"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
								<li data-text="话题" class="J-menu-' + self.MENU_TOPIC + '">\
									<span class="um-nav-bgc h-topic"></span>\
									<a href="' + self.aConfig.topicUrl + '" class="item">\
										<i class="v3-topic"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
								<li data-text="今日任务" class="J-menu-' + self.MENU_TASK + '">\
									<span class="um-nav-bgc h-task"></span>\
									<a href="javascript:void(0);" class="item J-btn_showTask">\
										<i class="v3-task"></i>\
										<span class="text"></span>\
									</a>\
								</li>\
							</ul>\
						</div>\
						\
						<!-- 账户操作 -->\
						<div class="um-opts">\
							<ul class="list-unstyled">\
								<li class="um-opts-account">\
									<span class="J-opts-account">' + userProfile +'</span>\
									<!-- 个人账户弹出框 -->\
									<div class="um-opts-subaccount dropdown-menu" id="subAccount">\
									</div>\
								</li>\
								\
								<li class="um-opts-news">\
									<a class="item J-is-tip-dot"><i class="v3-news"></i><span class="J-dot">' + isTipDot + '</span></a>\
									<div class="um-opts-subnews dropdown-menu" id="subnews">\
										<!-- module -->\
										<div class="um-msubnews">\
											<div class="um-opts-subnews-hd"></div>\
											<div class="um-opts-subnews-bd J-is-tip-dot">\
												<div class="ul1">\
													<a href="' + self.aConfig.eventNoticeUrl + '">好友动态</a>\
													<a href="' + self.aConfig.friendNoticeUrl + '">好友请求<span class="J-friend-dot">' + hasFriendNotice + '</span></a>\
													' + isVipGift + '\
													<a href="' + self.aConfig.homeworkUrl + '">测验情况<span class="J-homework-dot">' + hasHomework + '</span></a>\
												</div>\
												<div class="ul2">\
													<a href="' + self.aConfig.ownPropertyUrl + '">与我相关<span class="J-event-dot">' + hasEventNotice + '</span></a>\
													<a href="' + self.aConfig.newMessageUrl + '">小纸条<span class="J-message-dot">' + hasNewMessage + '</span></a>\
												</div>\
											</div>\
										</div>\
									</div>\
								</li>\
								\
								<li class="um-opts-set">\
									<a class="item dropdown-toggle" data-toggle="dropdown"><i class="v3-options"></i></a>\
									\
									<!-- 设置弹出框 -->\
									<div class="um-opts-subset dropdown-menu" id="subSet">\
										<!-- module -->\
										<div class="um-msubset">\
											<div class="um-opts-subset-hd"></div>\
											<div class="um-opts-subset-bd">\
												<div class="ul1">\
													<a href="' + self.aConfig.userInfoUrl + '">个人资料</a>\
													<a href="' + self.aConfig.updatePictureUrl + '">修改头像</a>\
													<a href="' + self.aConfig.settingMobileUrl + '">账户绑定</a>\
													<a href="' + self.aConfig.updatePassWord + '">修改密码</a>\
												</div>\
												\
												<div class="ul2">\
													<a href="javascript:;" class="J-btn_showSkinShop">皮肤设置</a>\
													<a href="javascript:;" class="J-btn_showPropMall">道具商店</a>\
													' + vipAndPayHtml + '\
													<!---a href="javascript:;" xid="btn_showGuide">新版指引</a--->\
												</div>\
												\
											</div>\
											<div class="um-opts-subset-ft">\
												<a href="' + self.aConfig.logoutUrl + '">安全退出</a>\
											</div>\
											\
										</div>\
										<!-- end module -->\
									</div>\
									\
								</li>\
							</ul>\
						</div>\
					</div>\
			<!-- end module -->';
			self.aConfig.naviDom.append(Navhtml);
			self.getUserInfo('#subAccount', false);

			self.aConfig.naviDom.delegate('.J-btn_showPropMall', 'click',  function(){
				self.triggerEvent(self.EVENT_ON_CLICK_PROP_MALL);
			});

			self.aConfig.naviDom.delegate('.J-btn_showGuide', 'click',  function(){
				self.triggerEvent(self.EVENT_ON_CLICK_GUIDE);
			});

			self.aConfig.naviDom.delegate('.J-btn_showTask', 'click',  function(){
				self.triggerEvent(self.EVENT_ON_TASK);
			});

			self.aConfig.naviDom.on('click', '.J-btn_showSkinShop', function () {
				window.oPopupSkin.show();
			});
			_navHover();
			_optsHover();

			//监听个人信息变化，更新个人头像
			App.oCurrentStudent.bindEvent(App.oCurrentStudent.EVENT_AFTER_UPDATE_INFO, function(){
				self.aConfig.naviDom.find('.J-opts-account').html(_buildProfile());
				self.aConfig.naviDom.find('.J-is-tip-dot > .J-dot').html(_buildTipDot());
				self.aConfig.naviDom.find('.J-is-tip-dot .J-message-dot').html(_buildTipDot('message'));
				self.aConfig.naviDom.find('.J-is-tip-dot .J-event-dot').html(_buildTipDot('event'));
				self.aConfig.naviDom.find('.J-is-tip-dot .J-friend-dot').html(_buildTipDot('friend'));
				self.aConfig.naviDom.find('.J-is-tip-dot .J-homework-dot').html(_buildTipDot('homework'));
			});

			//高亮当前选项，替代setCurrentMenu方法
			self.aConfig.naviDom.find('.J-nav a').each(function(){
				var $self = $(this);
				var pathname = window.location.pathname;
				if($self.attr('href').search(pathname) != -1){
					$self.parents('li').addClass('active');
				}
			});
		}
	};

	//构建头像
	function _buildProfile(){
		return Ui1.buildProfile({
			id : App.oCurrentStudent.id,
			profile : App.oCurrentStudent.profile
		}, false, {addClass : 'item'})
	}

	//构建统一提醒
	function _buildTipDot(type){
		var hasNotice, dotHtml = '<span class="dot">&bull;</span>',
			aKeys = ['message', 'event', 'friend', 'homework'],
			aNotices = [
			 	App.oCurrentStudent.hasNewMessage(),
				App.oCurrentStudent.hasEventNotice(),
				App.oCurrentStudent.hasFriendNotice(), 
				App.oCurrentStudent.hasHomework()
			];
		 	
		for(var i=0; i<aKeys.length; ++i){
			if(type == aKeys[i]){	//有对应type消息
				return aNotices[i] ? dotHtml : '';
			}else if(aNotices[i]){	//有消息
				hasNotice = aNotices[i];
			}
		}
		return hasNotice ? dotHtml : '';
	}
	// 头部hover
	function _navHover(){
		$('#header').find('.J-nav li').each(function(){
			if($(this).hasClass('active')){
				$(this).find('.um-nav-bgc').css({
					height: '5px'
				});
			}
			$(this).hover(function(){
				$(this).find('.um-nav-bgc').stop(true,true).animate({
					height: '75px'
				},100);
				var text = $(this).attr('data-text');
				$(this).find('.text').text(text);
			},function(){
				if($(this).hasClass('active')){
					$(this).find('.um-nav-bgc').stop(true,true).animate({
						height: '5px'
					},100);
				}else{
					$(this).find('.um-nav-bgc').stop(true,true).animate({
						height: '0'
					},100);
				}

				var text = $(this).attr('data-text');
				$(this).find('.text').text('');
			});
		});
	}

	// 设置hover
	function _optsHover(){
		$('.um-opts li').each(function(){
			$(this).hover(function(){
				$(this).find('.item').css('backgroundColor', '#223133');
				$(this).siblings().find('.item').css('backgroundColor', 'transparent');
			},function(){
				$(this).find('.item').css('backgroundColor', 'transparent');
			});
		});
	}

	// 显示班级
	function _showClass(data){
		var aClassList = data['data'];
		var classHtml = '', operateHtml = _buildOperate(aClassList.length);
		for(var i=0; i<aClassList.length; ++i){
			classHtml += _buildClass(aClassList[i]);
		}
		var html = '<div class="um-common-mask">\
						<div class="um-class-container container">\
							<div class="J-close-button close-button"></div>\
							<div class="title">我的班级</div>\
							<div class="J-class-list class-list">' + classHtml +  '</div>\
							<hr><div class="J-class-operate operate-container">' + operateHtml + '</div><div class="J-result class-list"></div>\
						</div>\
					</div>';
		var $root = $(html);
		//添加事件
		$root.find('.J-close-button').click(function(){
			$root.remove();
		});
		$root.find('.J-class-id').bind('keydown', function(evt){
			if(evt.keyCode == 13){  //Enter
			    _searchClass($root);
			}
		});

		$root.delegate('.J-search-class-btn', 'click', function(){
			_searchClass($root);
		});
		$root.delegate('.J-join', 'click', function(){
			var $self = $(this);
			var $list = $root.find('.J-class-list');
			var $result = $root.find('.J-result');
			classId = $self.data('id');
			ajax({
				url: self.aConfig.joinClassUrl,
				data: {classId: classId},
				success: function(data){
					if(data['status'] == 1){
						var $item = $self.parents('.J-class-item');
						var classNum = $root.find('.J-class-list > .J-class-item').length;
						var operateHtml = _buildOperate(classNum + 1);
						$root.find('.J-class-operate').html(operateHtml);
						$self.removeClass('J-join').addClass('J-exit').text('退出班级');
						$result.html('');
						$item.appendTo($list);
					}
					UBox.show(data['msg'], data['status']);
				}
			});
		});
		$root.delegate('.J-exit', 'click', function(){
			var $self = $(this);
			classId = $self.data('id');
			ajax({
				url: self.aConfig.exitClassUrl,
				data: {classId: classId},
				success: function(data){
					if(data['status'] == 1){
						var classNum = $root.find('.J-class-list > .J-class-item').length;
						var operateHtml = _buildOperate(classNum - 1);
						$root.find('.J-class-operate').html(operateHtml);
						$self.parents('.J-class-item').remove();
					}
					UBox.show(data['msg'], data['status']);
				}
			});
		});
		Navi.aConfig.naviDom.append($root);			
	}

	//查找班级方法
	function _searchClass($root){
		var classId = $root.find('.J-class-id').val();
		ajax({
			url: self.aConfig.getClassInfoUrl,
			data: {classId: classId},
			success: function(data){
				if(data['status'] != 1 || data['data'].length == 0){
					UBox.show('班级ID不正确');
					return;
				}
				var aClassInfo = data['data'];
				$root.find('.J-result').html('<hr><div class="J-class-item class-item"><span>' + aClassInfo['name'] + '</span><span>' + aClassInfo['subject_name'] + '</span><span>' + aClassInfo['teacher_name'] + '老师</span><span><a class="J-join" data-id="' + aClassInfo['id'] + '">加入班级</a></span></div>');
			}
		});
	}

	//构建班级dom
	function _buildClass(data){
		return '<div class="J-class-item class-item">\
					<span>' + data['class_name'] + '</span>\
					<span>' + data['subject_name'] + '</span>\
					<span>' + data['teacher_name'] + '</span>\
					<span><a class="J-exit" data-id="' + data['class_id'] + '">退出班级</a></span>\
				</div>';
	}

	//构建班级操作dom
	function _buildOperate(classNum){
		if(classNum == 3){
			return '<div class="notice">你已经加入了三个班级，如需加入新的班级，请先退出原来的班级</div>';
		}
		return '<div>班级ID<input type="text" class="J-class-id" /><a class="J-search-class-btn">查找</a></div><div class="remark">班级ID由教师使用优满分教师版创建班级生成，学生可向教师索取</div>';
	}

	$.extend(Navi, new Component());
	var self = Navi;
	var _vipPrivitege = false;
})(jQuery, window);

//今日任务
(function($, win){
	win.DailyTask = {
		aConfig : {
			getDailyTaskUrl : '',
			pkUrl : '',
			matchUrl : '',
			recommendFriendUrl : '',
			missionListUrl : '',
			missionListSubject1Url : '',
			missionListSubject2Url : '',
			missionListSubject3Url : '',
			getDailyTaskPrizeUrl : ''
		},
		config : function(aConfig){
			for(var key in self.aConfig){
				if(aConfig[key] == undefined){
					continue;
				}
				self.aConfig[key] = aConfig[key];
			}
		},
		show : function(){
			ajax({
				url : self.aConfig.getDailyTaskUrl,
				success : function(aResult){
					var aTaskList = aResult.data;
					var html = '<div class="modal hide fade common-modal task-modal" tabindex="-1" role="dialog" id="taskModal">\
							<!-- 今日任务 -->\
							<div class="um-mcommon um-mtask">\
								<div class="hd">\
									今日任务\
								</div>\
								<div class="bd">\
									<div class="point">优满分现完全免费 做任务送金币</div>\
									<div class="task">\
										<ul class="list-unstyled">';

					var statusStr = '';
					var statusClass = '';
					var url = '';
					var onclick = '';
					for(var i = 0; i < aTaskList.length; i++){
						var index = parseInt(aTaskList[i].task_id) + 1;
						var gold = '';
						if(aTaskList[i].task_info.gold > 0){
							gold = '+' + aTaskList[i].task_info.gold + '金币';
						}
						if(aTaskList[i].status == 1){
							statusStr = '去完成';
							statusClass = 'um-btn-default';

							if(aTaskList[i].task_id == 0){
								url = self.aConfig.recommendFriendUrl;
							}else if(aTaskList[i].task_id == 1){
								url = self.aConfig.missionListUrl;
							}else if(aTaskList[i].task_id == 2){
								url = self.aConfig.missionListSubject1Url;
							}else if(aTaskList[i].task_id == 3){
								url = self.aConfig.missionListSubject2Url;
							}else if(aTaskList[i].task_id == 4){
								url = self.aConfig.missionListSubject3Url;
							}else if(aTaskList[i].task_id == 5){
								url = self.aConfig.pkUrl;
							}else if(aTaskList[i].task_id == 6){
								url = self.aConfig.pkUrl;
							}else if(aTaskList[i].task_id == 7){
								url = self.aConfig.matchUrl;
							}else if(aTaskList[i].task_id == 8){
								url = self.aConfig.matchUrl;
							}
							onclick = '';
						}else if(aTaskList[i].status == 2){
							statusStr = '领取奖励';
							statusClass = 'um-btn-success';
							url = 'javascript:void(0);';
							onclick = 'onclick="DailyTask.getPrize(' + aTaskList[i].task_id + ', this);"';
						}else if(aTaskList[i].status == 3){
							statusStr = '已完成';
							statusClass = 'um-btn-default disabled';
							url = 'javascript:void(0);';
							onclick = '';
						}

						html += '<li>\
								<div class="icon">\
									<i class="v3-task-' + index + '"></i>\
								</div>\
								<div class="dist">' + aTaskList[i].task_info.name + '<em>(' + aTaskList[i].finish_times + '/' + aTaskList[i].task_info.times + ')</em></div>\
								<div class="reward">' + aTaskList[i].task_info.point + '经验' + gold + '</div>\
								<a href="' + url + '" ' + onclick + ' class="um-btn um-btn-sm ' + statusClass + '">' + statusStr + '</a>\
							</li>';
					}
					html += '</ul>\
								</div>\
							</div>\
						</div>\
						<a href="###" class="common-close-button" data-dismiss="modal" ></a>\
					</div>';
					Navi.aConfig.naviDom.append(html);
					_modalVerticalCenter('#taskModal');
					$('#taskModal').modal({backdrop : 'static', 'show' : true});
				}
			});

			$(window).resize(function(){
				_modalVerticalCenter('#taskModal');
			});
		},
		getPrize : function(id, obj){
			var $this = $(obj);
			ajax({
				url : self.aConfig.getDailyTaskPrizeUrl,
				data : {taskId : id},
				success : function(aResult){
					if(aResult.status == 1){
						$this.removeClass('um-btn-success');
						$this.addClass('um-btn-default disabled');
						$this.text('已完成');
						$this.attr('href', 'javascript:void(0);');
						$this.attr('onclick', '');
						App.oCurrentStudent.updateInfo();
					}
					UBox.show(aResult.msg, aResult.status);
				}
			});
		}
	};
	var self = window.DailyTask;
})(jQuery, window);