/**
 * 道具插件
 */
(function ($, window, App) {
	window.Prop = {
		CHANNEL_MALL: 0,
		CHANNEL_MYPROP: 1,
		CHANNEL_RECIVCE: 2,
		EVENT_AFTER_PROP_UPDATE: 'prop_bar_update', //更新事件

		SCENE_MISSION_PRACTICE: 1, //修炼场景
		SCENE_MISSION_CHALLENGE: 2, //挑战
		SCENE_MATCH_PLAYING: 4, //比赛

		SCENE_PK: 3, //PK道具
		SCENE_PROP_TYPE_GROOMING: 6, //扩容道具
		SCENE_PROP_TYPE_POINTS: 5, //积分道具
		SCENE_PROP_TYPE_GENERAL: 2, //通用道具


		_isChangeMyProp: false, //记录是否用户改变购买道具

		//千年人参触发检查
		EVENT_BEFORE_USE_QNRS: 'before_use_qnrs',
		//千年人参使用
		EVENT_USE_QNRS: 'use_qnrs',
		//万年人参
		EVENT_BEFORE_USE_WNRS: 'before_use_wnrs',
		EVENT_USE_WNRS: 'use_wnrs',
		//还魂琼浆露
		EVENT_BEFORE_USE_HHQJL: 'before_use_hhqjl',
		EVENT_USE_HHQJL: 'use_hhqjl',
		//还魂灵符
		EVENT_BEFORE_USE_HHLF: 'before_use_hhlf',
		EVENT_USE_HHLF: 'use_hhlf',
		//速成金丹
		EVENT_BEFORE_USE_SCJD: 'before_use_scjd',
		EVENT_USE_SCJD: 'use_scjd',
		//时光凝结
		EVENT_BEFORE_USE_SGNJ: 'before_use_sgnj',
		EVENT_SGNJ_TIME_OVER: 'after_sgnj_time_over',
		EVENT_USE_SGNJ: 'use_sgnj',

		//金蝉脱壳
		EVENT_BEFORE_USE_TGYS: 'before_use_tgys',
		EVENT_USE_TGYS: 'use_tgys',
		//场景数据装载
		sceneData: {
			//场景id如果是比赛则表示比赛id如果是pk则表示pk id
			scencId: '',
			//当前的关卡
			missionId: '',
			//是否允许开启时间减少
			allowStartTimeReduce: true,
			//生命值
			isGameOver : false
		},
		config: function (aOptions) {
			/*if(!aOptions.$dom){
			 $.error('缺少容器参数');
			 }
			 _$dom = aOptions.$dom;*/

			if (aOptions.url) {
				for (var key in _aUrl) {
					if (aOptions.url[key] != undefined) {
						_aUrl[key] = aOptions.url[key];
					}
				}
			}

			App.oCurrentStudent.bindEvent(App.oCurrentStudent.EVENT_AFTER_UPDATE_INFO, function () {
				//u币金币
				$('.J-myUb').text(App.oCurrentStudent.ub);
				$('.J-myGold').text(App.oCurrentStudent.gold);
			});
		},
		showMall: function (defaultChannel) {
			if ($_mall) {
				_showMall();
				return;
			}

			if (!defaultChannel) {
				defaultChannel = 1;
			}

			ajax({
				url: _aUrl.urlGetProp,
				data:{
					type: 1
				},
				success: function (aResult) {
					_aPropCategorySellList[1] = aResult.data;
					$_mask = $('<div class="mask" style="display: block;"></div>');
					$_mall = $(_buildBodyHtml(defaultChannel));
					_$dom.append([$_mask, $_mall]);
					_bindEvent();
					//获取购物车信息
					_updateCartList();
				}
			});
		},
		getPropBar: function (scene, callback, scencId) {
			if (scene === undefined || scencId === undefined) {
				UBox.show('缺失道具参数', 0);
				return;
			}
			self.sceneData.scencId = scencId;
			//判断是否已经调用过
			if (_$propBar) {
				_$cloneBarProp.push(_$propBar.clone(true));
				var $cloneBarProp = _$cloneBarProp[_$cloneBarProp.length - 1];
				//防止事件冲突
				$cloneBarProp.find('.prev').unbind('click');
				$cloneBarProp.find('.next').unbind('click');
				//滑动
				$cloneBarProp.find("#propBar").slide({mainCell:".J-barPropSlide ul", effect:"left", delayTime:500,vis:8,scroll:1,pnLoop:false, trigger:"click",easing:"easeOutCubic" ,titOnClassName:"active"});
				if(callback !== undefined){
					callback($cloneBarProp);
				}
				return;

			}
			ajax({
				url: _aUrl.urlGetToolBar,
				data: {scene : scene},
				success: function (aResult) {
					if (aResult.status != 1) {
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					_$propBar = $(_buildPropBarHtml(aResult.data));
					_$propBar.scenc = scene;
					//给$propBar绑定事件
					_getBarBindEvent(_$propBar);
					//第一次显示默认第一个道具的详细
					_$propBar.find('.J-barProp:first').click();

					//返回对象回调函数接受
					callback(_$propBar);
					//滑动
					jQuery("#propBar").slide({mainCell:".J-barPropSlide ul", effect:"left", delayTime:500,vis:8,scroll:1,pnLoop:false, trigger:"click",easing:"easeOutCubic" ,titOnClassName:"active"});
				}
			});


		},
		//判断道具是否存在
		isExitPropById: function (id) {
			if (1) {
				return true;
			}
			return false;
		},
		useProp: function (ids, func) {
			var functionName = func;
			var id = ids;
			//双倍经验的使用方法
			var aSbjf = ['useSbjf1', 'useSbjf3', 'useSbjf7'];
			//挑战中使用的方法
			var aChallengeProp = ['useQnrs', 'useWnrs', 'useSgnj', 'useHhlf', 'useHhqjl', 'useTgys'];
			//闯关道具的使用方法
			var aPractice = ['useScjd'];
			//比赛使用的道具
			var aMatchProp = ['useSgnj'];
			//双倍经验使用
			if (JsTools.inArray(func, aSbjf)) {
				_PropRunner.doublePoins(id);
				return;
			}

			//判断场景是否是挑战
			if (JsTools.inArray(functionName, aChallengeProp)) {
				if (self.SCENE_MISSION_CHALLENGE == _$propBar.scenc) {
					//处理挑战道具的使用
					for (var i in aChallengeProp) {
						if (aChallengeProp[i] == functionName) {
							_PropRunner[functionName](id);
						}
					}
					return;
				}
			}

			//比赛用的道具
			if (JsTools.inArray(functionName, aMatchProp)) {
				if (self.SCENE_MATCH_PLAYING == _$propBar.scenc) {
					//处理挑战道具的使用
					for (var i in aMatchProp) {
						if (aMatchProp[i] == functionName) {
							_PropRunner[functionName](id);
						}
					}
					return;
				}
			}

			//判断场景是否是修炼
			if (JsTools.inArray(functionName, aPractice)) {
				if (self.SCENE_MISSION_PRACTICE == _$propBar.scenc) {
					//处理在修炼中使用道具的使用方法
					for (var j in aPractice) {
						if (aPractice[j] == functionName) {
							_PropRunner[functionName](id);
						}
					}
					return;
				}
			}
			if(self.sceneData.isGameOver){
				UBox.show('生命值已耗尽不能使用该道具', -1);
				return;
			}
			//通用道具的使用方法
			switch (functionName)
			{
				//神龙眼罩
				case 'useSlyz':
					_PropRunner.useSlyz(id);
					break;
					//神剑眼罩
				case 'useSjyz':
					_PropRunner.useSjyz(id);
					break;
					//
				case 'useSlzy':
					_PropRunner.useSlzy(id);
					break;
					//背包容量
				case 'useDjbkr':
					_PropRunner.useDjbkr(id);
					break;
				default:
					UBox.show('该道具不适合在该页面使用喔', -1);
			}

		}

	};
	var _PropRunner = {
		triggerUsePropEvent: function (id) {
			//通知工具条减少数量
			var oEvent = new UmFunEvent({
				//action 0 表示删除了道具操作 1表示购买或者新加了道具
				xSenderData: {propId: id, num: 1, action: 0}
			});
			self.triggerEvent(self.EVENT_AFTER_PROP_UPDATE, oEvent);
		},
		//神龙眼罩
		useSlyz: function (id) {
			var aEs = Esp.oLastQuestion.data('es');
			var esType = aEs.type_id;
			if (esType != 1 && esType != 2) {
				UBox.show('该道具只适用于选择题', -1);
				return;
			}
			var esId = aEs.id;
			if (_$propBar.data('last_es_id') == esId) {
				UBox.show('一道题目只可以排除错误答案一次喔', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				data: _PropRunner.buildEsParms(id, esId),
				success: function (aResult) {
					if (aResult.status == 1) {
						var oQuestion = Esp.oLastQuestion;
						oQuestion.removeOption(aEs.options_relation[aResult.data]);
						_PropRunner.triggerUsePropEvent(id);
						_$propBar.data('last_es_id', esId);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//神剑眼罩
		useSjyz: function (id) {
			var aEs = Esp.oLastQuestion.data('es');
			var esType = aEs.type_id;
			if (esType != 1 && esType != 2) {
				UBox.show('该道具只适用于选择题', -1);
				return;
			}
			var esId = aEs.id;
			if (_$propBar.data('last_es_id') == esId) {
				UBox.show('一道题目只可以排除错误答案一次喔', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				data: _PropRunner.buildEsParms(id, esId),
				success: function (aResult) {
					if (aResult.status == 1) {
						_PropRunner.triggerUsePropEvent(id);
						_$propBar.data('last_es_id', esId);
						var oQuestion = Esp.oLastQuestion;
						for (var i = 0; i < aResult.data.length; i++) {
							oQuestion.removeOption(aEs.options_relation[aResult.data[i]]);
						}
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//神灵之眼
		useSlzy: function (id) {
			var aEs = Esp.oLastQuestion.data('es');
			var esId = aEs.id;
			if (_$propBar.data('last_es_id') == esId && _$propBar.data('last_prop_id') == id) {
				UBox.show('答案已经出来啦', -1);
				return;
			}
			_$propBar.data('last_es_id', esId);
			ajax({
				url: _aUrl.urlUseProp,
				data: _PropRunner.buildEsParms(id, esId),
				success: function (aResult) {
					if (aResult.status == 1) {
						var aAnswer = aResult.data;
						var oQuestion = Esp.oLastQuestion;
						oQuestion.writeAnswer(aAnswer);
						_PropRunner.triggerUsePropEvent(id);
						_$propBar.data('last_prop_id', id);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//背包扩容
		useDjbkr: function (id) {
			ajax({
				url: _aUrl.urlUseProp,
				data: {id: id, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					UBox.show(aResult.msg, aResult.status);
					if (aResult.status == 1) {
						_PropRunner.triggerUsePropEvent(id);
					}
				}
			});
		},
		//经验
		doublePoins: function (id) {
			ajax({
				url: _aUrl.urlUseProp,
				data: {id: id, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					UBox.show(aResult.msg, aResult.status);
					if (aResult.status == 1) {
						_PropRunner.triggerUsePropEvent(id);
					}
				}
			});
			return false;
		},
		///挑战道具的使用方法列表
		//还魂琼浆露
		useHhqjl: function (id) {
			if (!self.hasEvent(self.EVENT_BEFORE_USE_HHQJL)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_HHQJL, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_HHQJL)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				dataType: 'JSON',
				data: {id: id, missionId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						//通知
						self.triggerEvent(self.EVENT_USE_HHQJL);
						//通知减少
						_PropRunner.triggerUsePropEvent(id);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//还魂灵符
		useHhlf: function (id) {
			if (!self.hasEvent(self.EVENT_BEFORE_USE_HHLF)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_HHLF, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_HHLF)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				dataType: 'JSON',
				data: {id: id, missionId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						//通知效果(闯关---复活并加一滴血)
						self.triggerEvent(self.EVENT_USE_HHLF);
						//通知减少数量
						_PropRunner.triggerUsePropEvent(id);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//万年人参
		useWnrs: function (id) {
			//万年人参
			if (!self.hasEvent(self.EVENT_BEFORE_USE_WNRS)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_WNRS, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_WNRS)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				dataType: 'JSON',
				data: {id: id, missionId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						//通知
						self.triggerEvent(self.EVENT_USE_WNRS);

						_PropRunner.triggerUsePropEvent(id);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//千年人参
		useQnrs: function (id) {
			if (!self.hasEvent(self.EVENT_BEFORE_USE_QNRS)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_QNRS, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_QNRS)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				dataType: 'JSON',
				data: {id: id, missionId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						var oEvent = new UmFunEvent({
							xSenderData: {
								add_life_nums: 1
							}
						});
						//通知
						self.triggerEvent(self.EVENT_USE_QNRS, oEvent);
						_PropRunner.triggerUsePropEvent(id);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//时光凝结
		useSgnj: function (id) {
			if (!self.hasEvent(self.EVENT_BEFORE_USE_SGNJ)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_SGNJ, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_SGNJ)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}

			if (!self.hasEvent(self.EVENT_SGNJ_TIME_OVER)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				data: {id: id, theId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						self.triggerEvent(self.EVENT_USE_SGNJ);
						self.sceneData.allowStartTimeReduce = false;
						_PropRunner.triggerUsePropEvent(id);
						setTimeout(function () {
							self.triggerEvent(self.EVENT_SGNJ_TIME_OVER);
							self.sceneData.allowStartTimeReduce = true;

						}, 30000);

						//把时间设置为暂停
						self.sceneData.isEsStopTime = true;
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//修炼道具使用方法列表
		//速成金丹(只能在修炼中使用)
		useScjd: function (id) {
			UBox.show('抱歉,该道具已下架,无法使用', -1);
			return;
			if (!self.hasEvent(self.EVENT_BEFORE_USE_SCJD)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_SCJD, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_SCJD)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				dataType: 'JSON',
				data: {id: id, missionId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						//处理页面的效果......
						self.triggerEvent(self.EVENT_USE_SCJD);
						//通知
						_PropRunner.triggerUsePropEvent(id);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		//金蝉脱壳
		useTgys: function (id) {
			UBox.show('抱歉,该道具已下架,无法使用', -1);
			return;
			if (!self.hasEvent(self.EVENT_BEFORE_USE_TGYS)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			var oEvent = new UmFunEvent();
			self.triggerEvent(self.EVENT_BEFORE_USE_TGYS, oEvent);
			if (!oEvent.xListenerData.isOk) {
				return;
			}
			if (!self.hasEvent(self.EVENT_USE_TGYS)) {
				UBox.show('当前页面不支持使用该道具', -1);
				return;
			}
			ajax({
				url: _aUrl.urlUseProp,
				data: {id: id, missionId: self.sceneData.missionId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId},
				success: function (aResult) {
					if (aResult.status == 1) {
						_PropRunner.triggerUsePropEvent(id);
						self.triggerEvent(self.EVENT_USE_TGYS);
					} else {
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},

		//绑定做题的参数
		buildEsParms: function (id, esId) {
			if (!id) {
				$.error('使用道具时缺少道具ID');
				return;
			}
			var aData = {};
			if (typeof (matchIdUsePropFlag) != 'undefined') {
				aData = {id: id, esId: esId, game: 'match', match_id: matchIdUsePropFlag,scenario: _$propBar.scenc, scencId: self.sceneData.scencId};
			} else {
				aData = {id: id, esId: esId, scenario: _$propBar.scenc, scencId: self.sceneData.scencId};
			}
			return aData;
		}
	};

	$.extend(Prop, new Component());

	function _buildHeaderTab(defaultChannel) {
		var aTabs = ['', '', ''];
		aTabs[--defaultChannel] = ' cur';
		var headTab = '<div class="hd J-wrapTabs">\
			<a class="J-tab J-channelMall' + aTabs[0] + '" href="javascript:;"> <i class="ico_props ico_props_mall"></i>\
				道具商城\
			</a>\
			<a class="J-tab J-channelMyProp' + aTabs[1] + '"  href="javascript:;"> <i class="ico_props ico_props_mine"></i>\
				我的道具\
			</a>\
			<a class="J-tab J-channelRecieve' + aTabs[2] + '"  href="javascript:;">\
				<i class="ico_props ico_props_receive"></i>\
				领取道具\
			</a>\
		</div>';
		return headTab;
	}
	/**
	 * 构建道具商城左侧列表
	 * @param {type} aCategoryList
	 * @param {type} selectCategory
	 * @returns {String}
	 */
	function _buildCategoryHtml(aCategoryList, selectCategory) {
		if (!selectCategory) {
			selectCategory = 1;
		}
		var aTabs = ['', '', '', '', '', ''];
		aTabs[--selectCategory] = ' cur';
		return '<div class="menu">\
			<a class="J-categoryTab J-categoryMission ' + aTabs[0] + '" href="javascript:;" data-category="' + _aCategoryList[1] + '"><i class="ico_props ico_props_points"></i>闯关道具</a>\
			<a   class="J-categoryTab J-categoryPropsUniversal ' + aTabs[1] + '" href="javascript:;" data-category="' + _aCategoryList[2] + '"><i class="ico_props ico_props_universal"></i>通用答题道具</a>\
			<a   class="J-categoryTab J-categoryPk ' + aTabs[2] + '" href="javascript:;" data-category="' + _aCategoryList[3] + '"><i class="ico_props ico_props_match"></i>PK和比赛道具</a>\
			<a   class="J-categoryTab J-categoryPropsExpansion ' + aTabs[3] + '" href="javascript:;" data-category="' + _aCategoryList[4] + '"><i class="ico_props ico_props_expansion"></i>经验和扩容道具</a>\
			<a   class="J-categoryTab J-categoryPropsHot ' + aTabs[4] + '" href="javascript:;" data-category="' + _aCategoryList[5] + '"><i class="ico_props ico_props_hot"></i>热门打折道具</a>\
			<a   class="J-categoryTab J-categoryPropsDress ' + aTabs[5] + '" href="javascript:;" data-category="' + _aCategoryList[6] + '"><i class="ico_props ico_props_dress"></i>装扮类道具</a>\
		</div>';
	}
	/**
	 * 构建道具商城左侧分类html
	 * @param {array} aPropList
	 * @returns {dom html} html结构代码
	 */
	function _buildPropsSellListHtml(aPropList) {
		var html = '', listContentHtml = '';

		var aPropListHtml = [];
		for (var i in aPropList) {
			var aProp = aPropList[i];
			aPropListHtml.push('<li>\
				<p class="part">\
					<span class="img"><a href="javascript:void(0)" onclick="return false;"><img src="' + _aUrl.urlResource + aProp.ico + '" width="66" height="66" alt=""/></a></span>\
					<span class="ellipsis name">' + aProp.name + '</span>\
				</p>\
				<p class="price">\
					价&nbsp;&nbsp;&nbsp;&nbsp;格：' + aProp.price + '<br/>\
				</p>\
				<p class="num">\
					<span>数量</span>\
					<a class="add J-minusPropNums"  href="javascript:;"><i class="arrow"></i></a>\
					<input class="text J-propNums" type="text" value="1"/>\
					<a class="min J-addPropNums" href="javascript:;"><i class="arrow"></i></a>\
				</p>\
				<p class="btnbox J-btnbox">\
					<!---a onclick="Prop2.buyOneKind(' + aProp.id + ', this)" class="buy" href="javascript:void(0);">购买</a--->\
					<a data-id="' + aProp.id + '" class="fav J-putCart" href="javascript:void(0);">加入购物车</a>\
				</p>\
				<p class="overlay">\
					功效：' + aProp.effect + '<br/>\
					使用范围：' + aProp.range + '<br/>\
					已卖出：<em class="sum">' + aProp.purchase_total + '</em>\
				</p>\
			</li>');
		}

		listContentHtml = aPropList.length <= 0 ? '<p class="air"">该分类暂时没有道具！</p></div>' : '<ul>' + aPropListHtml.join('') + '</ul>';
		html = listContentHtml;
		return html;
	}

	function _buildCardHtml(aCardList) {
		return '<div class="cart">\
			<div class="title">\
				<a id="deleteProp" style="display:none" class="del J-deleteCart" href="javascript:;">删除道具</a>\
				<i class="ico_props ico_props_cart"></i>\
				购物车商品总数\
				<span id="propSum" class="sum J-propSum">' + aCardList.length + '</span>\
			</div>\
			<div class="info">\
				<a id="prev" class="prev">\
					<i class="arrow"></i>\
				</a>\
				<div class="list">\
					<ul id="cartList" class="J-cartList">\
						<li class="J-empty"></li>\
					</ul>\
				</div>\
				<a id="next" class="next">\
					<i class="arrow"></i>\
				</a>\
			</div>\
		</div>';
	}

	function _buildNumericalHtml() {
		return '<div class="wealth">\
			<ul>\
				<li class="name">\
					<i class="ico_props ico_props_wealth"></i>\
					我的财富\
				</li>\
				<!--li>U  币</li-->\
				<li>金  币</li>\
				<li></li>\
				<li class="prompt">\
					<!--span>\
					会员价指的是\
					<br/>\
					白金会员价哦！\
					</span-->\
				</li>\
				<!--li id="myUb" class="num J-myUb">0</li-->\
				<li id="myGold" class="num J-myGold">0</li>\
				<li></li>\
			</ul>\
		</div>';
	}

	function _buildBodyHtml(defaultChannel) {
		var headTab = _buildHeaderTab(defaultChannel);
		return '<div class="umfun-props"><div class="props">\
			' + headTab + '\
			<a class="close J-btnCloseMall" href="javascript:;" title="关闭">&times;</a>\
			<div class="bd J-body" mark="J-channelMall">\
				' + _buildMallHtml(_aPropCategorySellList[1]) + '\
			</div>\
		</div></div>';
	}

	function _buildMallHtml(aPropSellList) {
		var categoryHtml = _buildCategoryHtml();
		var aCardList = [];
		var proptsHtml = _buildPropsSellListHtml(aPropSellList);
		var cardHtml = _buildCardHtml(aCardList);
		var numericalHtml = _buildNumericalHtml();
		return '<div class="props_mall">\
			<div class="props_cate">\
				' + categoryHtml + '\
				<div class="list J-propList">' + proptsHtml + '</div>\
			</div>\
			<div class="props_total">\
				' + cardHtml + '\
				' + numericalHtml + '\
			</div>\
		</div>\
		<div class="ft">\
			<!--商城用 [-->\
			<p class="count fl">\
				共计： <em id="cartGoldCount" class="row J-cartGoldCount">0</em>\
				金币\
			</p>\
		<p class="btnbox_buy fr">\
			<a  class="btn btn_orange J-buyFromCart" href="javascript:;">购  买</a>\
		</p>\
		<!--商城用 ]-->\
		</div>';
	}
	//我的道具页面构建
	function _buildMyPropHtml(aMyPropList) {
		if (aMyPropList.prop_list.length == 0) {
			return _buildMyPropNodataHtml();
		}
		var html = _buildMyPropBodyHtml(aMyPropList.prop_list) + _buildMyPropSendFriendHtml(aMyPropList) + _buildMyPropFooterHtml();
		return html;
	}
	/**
	 * 自己没有道具的显示html构建
	 * @returns {String}
	 */
	function _buildMyPropNodataHtml() {
		return '<div id="myPropList" class="props_mine">\
		<div class="cont">\
			<div class="list">\
				<ul id="propList">\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
					<li></li>\
				</ul>\
			</div>\
		</div>\
		<div id="propIntroduce" class="side">\
			<div class="notfound">\
				<p>\
					您还没有道具哦，\
					<br>\
					赶快到\
					<a class="act J-showMall" href="javascript:void()">道具商城</a>\
					购买吧~~\
				</p>\
			</div>\
		</div>\
	</div>\
	<!--我的道具 ]-->\
	<!--赠送 ]-->\
	<div class="ft">\
		<!--我的道具用 [-->\
		<p xid="propBottom" class="count fl">\
			共有道具总数 <em id="myPropSum">0</em>\
		</p>\
		<p xid="propBottom" class="prompt fl">\
			道具包容量不够？\
			<a class="act J-showMall" href="javascript:void(0)">点我马上扩容！</a>\
		</p>\
		<!--我的道具用 ]-->\
	</div>';
	}
	//我的道具道具列表构建
	function _buildMyPropBodyHtml(aMyPropList) {
		var aPropListHtml = [];
		var aPropList = aMyPropList;
		var aMyPropDetail = [];
		_myPropCountNums = 0;
		//总道具数量
		aPropListHtml.push('<div id="myPropList" class="props_mine J-myPropList" "="">\
	<div class="cont">\
		<div class="list">\
			<ul id="propList">');
		//道具列表构建
		for (var i in aPropList) {
			//循环取出种类道具的数量构建html
			for (var j = 0; j < aPropList[i].nums; j++) {
				aPropListHtml.push('<li class="J-myProp" data-have_list=\'' + _buildPropHaveList(aPropList[i].have_list) + '\' data-detail=\'' + _buildPropDetail(aPropList[i]) + '\' data-my_prop_id= ' + aPropList[i].id + '>\
				<a href="javascript:void(0)" onclick="return false;">\
					<span class="img"><img src="' + _aUrl.urlResource + aPropList[i].ico + '" width="66" height="66" alt=""></span>\
					<span class="ellipsis name" title="' + aPropList[i].name + '">' + aPropList[i].name + '</span>\
				</a>\
			</li>');
				//获取所有详细信息
				aMyPropDetail.push(_buildPropDetail(aPropList[i]));
				_myPropCountNums++;
			}

		}
		aPropListHtml.push('</ul></div></div>');
		//共同好友列表,详细容器
		aPropListHtml.push('<div id="propIntroduce" class="side">');
		//详细容器
		aPropListHtml.push('<div class="intro J-myPropDetail">');
		//第一个道具详细介绍
		//aPropListHtml.push(_buildPropDetail(aPropList[0]));
		aPropListHtml.push('</div>');

		//共同好友
		aPropListHtml.push('<div class="member">\
					<p>他们也有这个道具</p>\
					<ul class="list J-memberHaveList">');
		//aPropListHtml.push(_buildPropHaveList(aPropList[0].have_list));
		//结束dom结构
		aPropListHtml.push('</ul></div></div></div>');
		return aPropListHtml.join('');
	}


	function _buildPropDetail(aMyProp) {
		return '<h3 class="title">道具介绍</h3>\
			<p class="img">\
				<img src="' + _aUrl.urlResource + aMyProp.ico + '" width="66" height="66" alt="">\
			</p>\
			<p class="desc">\
				名称：' + aMyProp.name + '<br/>\
				功效：' + aMyProp.effect + '<br/>\
				使用范围：' + aMyProp.range + '<br/>\
			</p>';
	}
	//构建道具共同好友列表html
	function _buildPropHaveList(aPropList) {
		var aPropListHaveList = aPropList;
		var aHaveListHtml = [];
		for (var k = 0; k < aPropListHaveList.length; k++) {
			aHaveListHtml.push('<li title="' + aPropListHaveList[k].name + '">' + Ui1.buildProfile({id: aPropListHaveList[k].id, profile: aPropListHaveList[k].profile}) + '</li>');
		}

		return aHaveListHtml.join('');


	}
	//赠送好友界面构建
	function _buildMyPropSendFriendHtml(aMyPropFriend) {
		var aGroupList = aMyPropFriend.group_list;
		var aFriendLists = aMyPropFriend.friend_list;
		var friendGroupListHtml = _buildGroupHtml(aGroupList, aFriendLists),
				friendListHtml = _buidMyFriendHtml(aFriendLists);
		return '<div class="props_handsel J-sendProp" style="display:none;">\
			<div class="side">\
				<div class="menu">\
					<h3>请选择好友</h3>\
					<ul id="groupList" class="group">\
						<li  class="cur J-groupSwitch">\
							<a href="javascript:void(0)"> <b>全部</b>\
							</a>\
						</li>\
						' + friendGroupListHtml + '\
					</ul>\
				</div>\
			</div>\
			<div class="cont">\
				<p class="say">\
					<input id="sendMessage" maxlength="30" class="text" type="text" placeholder="说点什么吧（30字内）"></p>\
				<div class="friends">\
					<ul id="friendList" class="list J-friendList">' + friendListHtml + '</ul>\
				</div>\
			</div>\
		</div>';
	}

	function _buildGroupHtml(aGroupList, aFriendLists) {
		var aGroup = [];
		for (var i = 0; i < aGroupList.length; i++) {
			var aFriendList = [];
			for (var j = 0; j < aFriendLists.length; j++) {
				if (aFriendLists[j].group_id == aGroupList[i].id) {
					aFriendList.push(aFriendLists[j]);
				}
			}
			aGroup.push('<li  class="J-groupSwitch" data-this_group_friend=\'' + _buidMyFriendHtml(aFriendList) + '\'><a href="javascript:void(0)"><b>' + aGroupList[i].group_name + '</b></a></li>');
		}
		return aGroup.join('');
	}
	function _buidMyFriendHtml(aFriendLists) {
		var aFriendList = aFriendLists;
		var aFriendHtml = [];
		//好友列表
		for (var i = 0; i < aFriendList.length; i++) {
			var userProfile = Ui1.buildProfile({
					id : aFriendList[i].id,
					profile : aFriendList[i].profile
				}, false, {addClass : 'item'});
				var userName = Ui1.buildVipName(aFriendList[i],false);
			aFriendHtml.push('<li class="J-friendSelect" data-id="' + aFriendList[i].id + '">\
									' + userProfile + '\
									<span class="ellipsis name J-friendName">' + userName + '</span>\
							</li>');
		}
		return aFriendHtml.join('');
	}
	//我的道具底部
	function _buildMyPropFooterHtml() {
		var html = '<div class="ft">\
	<!--我的道具用 [-->\
	<p class="count fl J-propBottom">\
		共有道具总数 <em id="myPropSum">0</em>\
	</p>\
	<p  class="prompt fl J-propBottom">\
		道具包容量不够？\
		<a class="act J-showMall" href="javascript:void(0)">点我马上扩容！</a>\
	</p>\
	<p  class="btnbox fr J-btnSendPropParent">\
		<a  class="btn btn_orange J-btnSendProp" href="javascript:;" data-how="0">赠  送</a>\
		<a  class="btn btn_gray J-btnDiscardProp" href="javascript:;">丢  弃</a>\
	</p>\
	<!--我的道具用 ]-->\
	<!--赠送 [-->\
	<p  class="count fl J-sendBottom" style="display:none;">\
		已选好友\
		<a class="act J-selectedName" href="javascript:void(0)"></a>\
	</p>\
	<p  class="btnbox fr J-btnSendPropParent1" style="display:none;">\
		<a  class="btn btn_orange J-btnSendMyProp" href="javascript:;">赠  送</a>\
		<a class="btn btn_gray J-btnCancelSendMyProp" href="javascript:;">取  消</a>\
	</p>\
	<!--赠送 ]-->\
</div>';
		return html;
	}

	function _buildReciveHtml() {
		var reciveHtml = '<div class="props_receive">\
	<div id="sendPropMenu" class="menu">\
		<a  href="javascript:;" class="cur J-getSendProp" data-type="1"> <i class="ico_props ico_props_friends"></i>\
			好友赠送\
		</a>\
		<a  href="javascript:;" class="J-getSendProp" data-type="2"> <i class="ico_props ico_props_mission"></i>\
			系统奖励\
		</a>\
	</div>\
	<div class="list J-sendPropList"></div>\
</div>';
		return reciveHtml;
	}
	//获取道具赠送返回html 1 为好友赠送 2 为系统赠送
	function _getSendProp(aPropList, type) {
		var html = '';
		var aPropList = aPropList;
		if (aPropList.length <= 0) {
			html += '<p class="air">您还没有可领取的道具，快去<a class="act J-showMall" href="javascript:void(0)">道具商城</a>购买吧~</p>';
		} else {
			html += '<ul>';
			for (var i = 0; i < aPropList.length; i++) {
				whoHtml = _buildSendPropListHtml(aPropList[i], type);
				html += '<li>' + whoHtml + '<p class="intro">\
								<span class="img"><img src="' + _aUrl.urlResource + aPropList[i].prop_info.ico + '" width="40" height="40" alt=""></span>\
								<span class="desc">\
									功效：' + aPropList[i].prop_info.effect + '<br/>\
									使用范围：' + aPropList[i].prop_info.range + '\
								</span>\
							</p>\
							<p class="btnbox">\
								<a  data-id="' + aPropList[i].id + '" data-type="' + type + '" class="btn btn_orange J-getProp" href="javascript:;">领  取</a>\
								<a data-id="' + aPropList[i].id + '" data-type="' + type + '" class="btn btn_gray J-ignoreProp" href="javascript:;">忽  略</a>\
							</p>\
						</li>';
			}
			html += '</ul>';
		}
		return html;
	}
	function _buildSendPropListHtml(aPropList, type) {
		if (type == 1) {
			//头像
			var userProfile = Ui1.buildProfile({
					id : aPropList.user_info.id,
					profile : aPropList.user_info.profile
				}, false, {addClass : 'item'});
			//名字
			var userName = Ui1.buildVipName(aPropList.user_info);
			return '<p class="head">' + userProfile + '</p>\
		<p class="part">\
			<span class="name">' + userName + '</span>\
			<span class="time">' + aPropList.create_time + '</span>\
			给您送了一个<span class="sum">' + aPropList.prop_info.name + '</span>\
		</p>\
		<p class="advice">赠  言：' + aPropList.message + '</p>';
		}
		return '<p class="part" style="margin-left:-49px;">\
		<span class="name">系统</span>\
		<span class="time">' + aPropList.create_time + '</span>\
		奖励您一个<span class="sum">' + aPropList.prop_info.name + '</span>\
		</p>';
	}

	function _showMall() {
		$_mall.show();
		$_mask.show();
	}
	function _setMark(logo, mark) {
		_$dom.find('.' + logo).attr('mark', mark);
	}
	function _getMark(logo) {
		return _$dom.find('.' + logo).attr('mark');
	}
	//道具赠送好友提交操作
	function _sendProp() {
		var propId = _aSelectedProp;
		if (!propId) {
			UBox.show('请选择道具', -1);
			_$dom.find('.J-btnCancelSendMyProp').click();
			return;
		}
		//留言内容
		var message = $.trim($('#sendMessage').val());
		if (!message || message == '') {
			UBox.show('给您的好友留个言吧', -1);
			return;
		}
		var friendId = _$dom.find('.J-friendSelect.selected').data('id');
		if (!friendId) {
			UBox.show('请选择一个好友', -1);
			return;
		}
		ajax({
			url: _aUrl.urlSendProp,
			data: {toUserId: friendId, message: message, propId: propId},
			success: function (aResult) {
				UBox.show(aResult.msg, aResult.status);
				if (aResult.status == 1) {
					//通知工具条减少数量
					var oEvent = new UmFunEvent({
						//action 0 表示删除了道具操作 1表示购买或者新加了道具
						xSenderData: {propId: propId, num: 1, action: 0},
					});
					self.triggerEvent(self.EVENT_AFTER_PROP_UPDATE, oEvent);
					_$dom.find('.J-btnCancelSendMyProp').click();
				}
			}
		});
	}
	/**
	 * 丢弃道具
	 */
	function _discardProp() {
		//获取丢掉选中的道具
		var propId = _$dom.find('.J-myProp.selected').data('my_prop_id');
		if (!propId) {
			UBox.show('请先选择道具', -1);
			return;
		}
		UBox.confirm('您确定要丢去该道具？', function () {
			ajax({
				url: _aUrl.urlDiscardProp,
				data: {id: propId},
				success: function (aResult) {
					UBox.show(aResult.msg, aResult.status);
					if (aResult.status == 1) {
						//通知工具条减少数量
						var oEvent = new UmFunEvent({
							//action 0 表示删除了道具操作 1表示购买或者新加了道具
							xSenderData: {propId: propId, num: 1, action: 0},
						});
						self.triggerEvent(self.EVENT_AFTER_PROP_UPDATE, oEvent);
					}
				}
			});
		});
	}
	function _deleteMyProp(id) {
		//获取选中的道具
		var mySelf = _$dom.find('.J-myProp[data-my_prop_id="' + id + '"]:first');
		//设置道具数量
		var oDom = _$dom.find('#myPropSum');
		var myPropNums = _$dom.find('.J-myProp').length;
		oDom.html((myPropNums - 1));
		//删除选中的道具
		mySelf.remove();
		//统计现有的道具个数并且判断是否定义了节点防止复活之后操作导致我的道具显示不正常
		var nowPropNums = _$dom.find('.J-myProp').length;
		if ((nowPropNums == 0) && (mySelf.html() !== undefined)) {
			_$dom.channelMyPropContent = $(_buildMyPropHtml({prop_list: []}));
			_$dom.find('.J-body').html(_$dom.channelMyPropContent);
			return;
		}
	}
	/**
	 * 领取道具
	 * @param {type} id 道具id
	 * @param {type} type 道具类型
	 * @param {type} oBj 当前操作dom对象
	 */
	function _getProp(id, type, oBj) {
		if (type != 1 && type != 2) {
			UBox.show('参数错误', -1);
			return;
		}
		ajax({
			url: _aUrl.urlGetMyProp,
			data: {id: id, type: type},
			success: function (aResult) {
				UBox.show(aResult.msg, aResult.status);
				if (aResult.status == 1) {
					//事件通知道具发生变化
					var oEvent = new UmFunEvent({
						//购买道具由于涉及到批量购买所以数量没有指定获取数量应该从propId 的长度
						//action 0 表示删除了道具操作 1表示购买或者新加了道具
						xSenderData: {propId: id, action: 1},
					});
					self.triggerEvent(self.EVENT_AFTER_PROP_UPDATE, oEvent);
					oBj.parents('li').slideUp('normal', function () {
						$(this).remove();
					});
				}
			}
		});
	}
	/**
	 * 忽略道具
	 * @param {type} id 道具id
	 * @param {type} type 道具类型
	 * @param {type} oBj 当前操作dom对象
	 */
	function _ignoreProp(id, type, oBj) {
		if (type != 1 && type != 2) {
			UBox.show('参数错误', -1);
			return;
		}
		ajax({
			url: _aUrl.urlIgnoreMyProp,
			data: {id: id, type: type},
			success: function (aResult) {
				UBox.show(aResult.msg, aResult.status);
				if (aResult.status == 1) {
					oBj.parents('li').slideUp('normal', function () {
						$(this).remove();
					});
				}
			}
		});
	}
	/**
	 * 加入购物车
	 * @param {type} id 道具id
	 * @param {type} oBj 当前dom
	 */
	function _putCart(id, oBj) {
		var oDom = $(oBj).parents('.J-btnbox').prev().find('.J-propNums');
		var nums = oDom.val();
		//限制不是数字的输入
		var pattern = /^\d+$/gi;
		if (!pattern.test(nums) || (nums <= 0) || (nums > _cartNumsLimit)) {
			UBox.show('数量必须是大于0小于' + _cartNumsLimit + '的数字', 0);
			oDom.val(1);
			return;
		}
		//获取选中的数量
		var nums = parseInt(nums);
		//cookie生命周期
		var date = new Date();
		date.setTime(date.getTime() + _cookieLifeTime);
		var idsList = [];
		//购物车不为空
		if ($.cookie('aCartList') !== undefined) {
			//临时交换数组
			var aTemp = _stringToArray($.cookie('aCartList'));
			//存在更新数量
			for (var i in aTemp) {
				idsList.push(aTemp[i].id);
			}
			//道具种类已经在购物车
			if (JsTools.inArray(id, idsList)) {
				for (var j in aTemp) {
					if (aTemp[j].id == id) {
						aTemp[j].nums = Number(aTemp[j].nums) + Number(nums);
						$.cookie('aCartList', _arrayToString(aTemp), {expires: date,path: '/'});
					}
				}
			} else {
				//新加道具
				var aCartList = [{id: id, nums: nums}];
				$.cookie('aCartList', $.cookie('aCartList') + '|' + _arrayToString(aCartList),{path: '/'});
			}
		} else {
			//第一次添加
			var aCartList = [{id: id, nums: nums}];
			$.cookie('aCartList', _arrayToString(aCartList), {expires: date,path: '/'});
		}
		_updateCartList();

	}
	function _updateCartFrom() {
		var aCartListCookie = $.cookie('aCartList');
		//获取购物车信息
		if (aCartListCookie === undefined) {
			var html = '';
			for (var i = 0; i < 23; i++) {
				html += '<li class="J-empty"></li>';
			}
			$('.J-cartList').html(html);
			return;
		}
		var aCartList = _stringToArray(aCartListCookie);
		ajax({
			url: _aUrl.urlGetPropCartInfo,
			data: {prop_cart_list: aCartList},
			success: function (aResult) {
				if (aResult.status == 1) {
					//更新购物车信息
					var aPropCartList = aResult.data;
					//构建cookie中的道具html
					var updateCartListHtml = _buildCartListHtml(aPropCartList.cart_list);
					//插入道具购物车html
					$('.J-cartList').html(updateCartListHtml).css('width', '1008px');
					//更新购物车价格
					$('.J-cartGoldCount').html(aPropCartList.total_gold);
				}
			}
		});
	}
	/**
	 * 更新购物车信息
	 * @returns {undefined}
	 */
	function _updateCartList() {
		_updateCartFrom();
		//购物车数量
		$('.J-propSum').html(_getCartListNums());
		//u币金币
		$('.J-myUb').text(App.oCurrentStudent.ub);
		$('.J-myGold').text(App.oCurrentStudent.gold);
	}
	/**
	 * 删除购物车道具
	 * @param {type} aIds id列表数组
	 */
	function _deleteCartProp(aIds) {
		var cookies = $.cookie('aCartList');
		if (cookies === undefined) {
			return;
		}
		var aCartList = _stringToArray(cookies);
		var aTemp = [];
		for (var i in aCartList) {
			//判断道具存在道具数组则删除
			if (JsTools.inArray(aCartList[i].id, aIds)) {
				//删除指定下标
				delete aCartList[i];
			}
		}
		//保持索引构建元素个数
		for (var t in aCartList) {
			if (aCartList[t] !== undefined) {
				aTemp.push(aCartList[t]);
			}
		}
		if (aTemp.length == 0) {
			$('.J-cartGoldCount').text(0);
			//购物车为空cookie过期
			$.cookie('aCartList', null, {expires: -10,path: '/'});
		} else {
			$.cookie('aCartList', _arrayToString(aCartList),{path: '/'});
		}
		//删除后更新购物车信息
		_updateCartList();
	}
	/**
	 * 购物车实时数量
	 * @returns {Number} 数量
	 */
	function _getCartListNums() {
		//购物车商品数量
		var cartCount = 0;
		var aCartListCookie = $.cookie('aCartList');
		if (aCartListCookie !== undefined) {
			var aTemp = _stringToArray(aCartListCookie);
			for (var i in aTemp) {
				cartCount += parseInt(aTemp[i].nums);
			}
		}
		return cartCount;
	}
	/**
	 * 构建购物车的实时html
	 * @param {type} aCart  道具数据
	 * @returns {String} 构建好的html
	 */
	function _buildCartListHtml(aCart) {
		var cartHtml = '';
		var aCartListCookie = $.cookie('aCartList');
		//获取购物车信息
		if (aCartListCookie === undefined) {
			var html = '';
			for (var i = 0; i < 23; i++) {
				html += '<li class="J-empty"></li>';
			}
			return html;
		}

		var aCartList = _stringToArray(aCartListCookie);
		for (var i = 0; i < 24; i++) {
			if (aCartList[i] !== undefined) {
				for (var key in aCart) {
					if (aCart[key].id == aCartList[i].id) {
						var ico = aCart[key].ico;
					}
				}
				cartHtml += '<li data-id="' + aCartList[i].id + '">\
									<a data-id="' + aCartList[i].id + '"  class="J-selectCartProp" href="javascript:void(0);">\
										<span class="img"><img src="' + _aUrl.urlResource + ico + '" width="34" height="34" alt=""/></span>\
										<span class="num">' + aCartList[i].nums + '</span>\
									</a>\
								</li>';
			} else {
				cartHtml += '<li class="J-empty"></li>';
			}
		}
		return cartHtml;
	}
	/**
	 * 动态计算总价格分会员等级后台异步计算
	 * @returns {Number|undefined}
	 */
	function _getTatolPrice() {
		var aCartListCookie = $.cookie('aCartList');
		if (aCartListCookie === undefined) {
			return 0;
		}
		var aCartList = _stringToArray(aCartListCookie);
		var aList = [];
		var totalPrice = 0;
		for (var i in aCartList) {
			var aTemp = [];
			totalPrice += parseInt(aCartList[i].nums);
			//后台算价格
			aTemp = {id: aCartList[i].id, nums: aCartList[i].nums};
			aList.push(aTemp);
		}
		//异步过得价格
		return totalPrice;
	}
	/**
	 * 获取购物车信息
	 * @returns {Array}
	 */
	function _getPropCart() {
		var aPropList = [];
		var aCookieCartList = _stringToArray($.cookie('aCartList'));
		if (aCookieCartList === undefined) {
			UBox.show('购物车为空请先将道具加入购物车再购买', -1);
			_updateCartList();
			return;
		}
		for (var key in aCookieCartList) {
			for (var i = 0; i < aCookieCartList[key].nums; i++) {
				aPropList.push(aCookieCartList[key].id);
			}
		}
		return aPropList;
	}

	/**
	 * 加入购物车数量减1
	 * @param {oBj} 当前dom
	 */
	function _minusPropNums(oBj) {
		var oBjNum = $(oBj).next();
		var val = parseInt(oBjNum.val()) - 1;
		if (val < 1) {
			val = 1;
		}
		oBjNum.val(val);
	}
	/**
	 * 加入购物车数量加1
	 * @param {oBj} 当前dom
	 */
	function _addPropNums(oBj) {
		var oBjNum = $(oBj).prev();
		var val = parseInt(oBjNum.val()) + 1;
		if (val > 99) {
			val = 99;
		}
		oBjNum.val(val);
	}
	/**
	 * 数组转字符串
	 * @param {type} aArr 要转换的数组
	 * @returns {String} 以|连接的字符串
	 */
	function _arrayToString(aArr) {
		var aCookies = [];
		for (var i in aArr) {
			aCookies.push(aArr[i].id + ',' + aArr[i].nums);
		}
		return aCookies.join('|');
	}

	function _isNumber(number) {
		//限制不是数字的输入
		var pattern = /^\d+$/gi;
		if (!pattern.test(number)) {
			return false;
		}
		return true;
	}
	/**
	 * 字符串转数组
	 * @param {type} 要转换的字符串
	 * @returns {Array} 返回 以 | 分割的数组
	 */
	function _stringToArray(string) {
		if (string === undefined) {
			return [];
		}
		var aCookie = [];
		var aTemps = string.split('|');
		for (var i in aTemps) {
			var aTemp = aTemps[i].split(',');
			aCookie.push({id: aTemp[0], nums: aTemp[1]});
		}
		return aCookie;
	}

	/**
	 * 购买道具
	 */
	function _buyFromCart() {
		var aIds = _getPropCart();
		if (aIds <= 0) {
			UBox.show('请先选择道具', -1);
			return;
		}
		ajax({
			url: _aUrl.urlBuyFromCart,
			data: {ids: aIds},
			success: function (aResult) {
				UBox.show(aResult.msg, aResult.status);
				if (aResult.status == 1) {
					$.cookie('aCartList', null, {expires: -10,path: '/'});
					$('.J-propSum').text(0);
					$('#deleteProp').hide();
					//删除购物车列表
					var selectedObj = $('.J-cartList li').not('.J-empty');
					var selectedNums = selectedObj.length;
					$(selectedObj).remove();

					var html = '';
					for (var i = 0; i < selectedNums; i++) {
						html += '<li class="J-empty"></li>';
					}
					$('.J-cartList').append(html);
					//清零购物车价格
					$('.J-cartGoldCount').text(0);
					//道具条事件通知
					var oEvent = new UmFunEvent({
						//购买道具由于涉及到批量购买所以数量没有指定获取数量应该从propId 的长度
						//action 0 表示删除了道具操作 1表示购买或者新加了道具
						xSenderData: {propId: aIds, action: 1},
					});
					self.triggerEvent(self.EVENT_AFTER_PROP_UPDATE, oEvent);
					//触发减少用户金币的事件
					App.oCurrentStudent.updateInfo();
				}
			}
		});
	}
	/**
	 * 道具工具条html构建
	 * @param {type} 道具数据
	 * @returns {String} 构建好的dom
	 */
	function _buildPropBarHtml(aResult) {
		var aEnableList = aResult.enable;
		var aDisableList = aResult.disable;
		var aBarListHtml = [];
		var num = (aEnableList.length + aDisableList.length);
		//时间的触发绑定
		if (num == 0) {
			aBarListHtml.push('<div class="modm um-mpropbar J-prorpBarParent nodata">\
			<div class="prop-nodata">\
				还没有道具，去<a href="javascript:;" class="J-showMall">道具商店</a>看看吧！\
			</div>\
			</div>');
			return aBarListHtml.join('');
		}
		aBarListHtml.push('<div class="modm um-mpropbar J-prorpBarParent">\
				<div class="slide-warp J-barPropParentDiv" id="propBar">\
				<a href="javascript:;" class="prev">\
					<i class="v3-common-prev"></i>\
				</a>\
				<div class="slide J-barPropSlide">\
					<ul class=list-unstyled J-barPropList">');
		//列表
		aBarListHtml.push(_buildBarPropListHtml(aEnableList, aDisableList));
		aBarListHtml.push('</ul>\
				</div>\
				<a href="javascript:;" class="next">\
					<i class="v3-common-next"></i>\
				</a>\
			</div>\
			<!-- 道具详情 -->\
			<div class="prop-detail J-barPropDetail" id="propDetail">\
			</div>\
		</div>');
		return aBarListHtml.join('');
	}
	function _buildBarPropListHtml(aPropBarEnableList, aPropBarDisableList) {
		var aEnableList = aPropBarEnableList;
		var aDisableList = aPropBarDisableList;
		var aBarListHtml = [];
		//可使用的循环拼接
		for (var key in aEnableList) {
			aBarListHtml.push('<li class="J-barProp" data-fun=\'' + aEnableList[key].fun + '\' data-id=\'' + aEnableList[key].id + '\' data-type=\''+ aEnableList[key].type +'\' data-detail=\'\
							<div class="description">\
									<span class="name">' + aEnableList[key].name + '</span>' + aEnableList[key].description + '\
							</div>\
							<div class="opts">\
								<a href="javascript:;" class="um-btn um-btn-xs um-btn-default  J-useProp">使用道具</a>\
								<a href="javascript:;" class="prop-store J-showMall">道具商店</a>\
							</div>\' >\
							<a href="javascript:;">\
								<img class="prop-ico" src="' + _aUrl.urlResource + aEnableList[key].ico + '">\
								<span class="num J-barPropNum">' + aEnableList[key].nums + '</span>\
							</a>\
						</li>');
		}
		//不可使用的循环拼接
		for (var j in aDisableList) {
			aBarListHtml.push('<li class="J-barProp J-gray" data-detail=\'\
							<div class="description">\
									<span class="name">' + aDisableList[j].name + '</span>' + aDisableList[j].description + '\
							</div>\
							<div class="opts">\
								<a href="javascript:;" class="um-btn um-btn-xs um-btn-default disabled J-useProp J-barPropDisabled">使用道具</a>\
								<a href="javascript:;" class="prop-store J-showMall">道具商店</a>\
							</div>\' >\
							<a href="javascript:;">\
								<img class="prop-ico" src="' + _aUrl.urlResource + aDisableList[j].ico + '">\
								<span class="num J-barPropNum">' + aDisableList[j].nums + '</span>\
							</a>\
						</li>');
		}
		return aBarListHtml.join('');
	}

	/**
	 *工具条点击切换html
	 * @param {type} html
	 * @param {$this} 当前的对象
	 * @returns {undefined}
	 */
	function _buildBarPropDetailHtml(html, $this) {
		//防止调用两次使用当前对象查找节点
		$this.closest('.J-barPropParentDiv').siblings('.J-barPropDetail').html(html);
	}

	//事件的触发绑定
	function _bindEvent() {
		//顶部切换操作
		_$dom.switchTab = function (channel) {
			$(this).find('.J-tab:eq(' + channel + ')').addClass('cur').siblings().removeClass('cur');
		};
		//道具商城左侧切换操作
		_$dom.on('click', '.J-categoryTab', function () {
			var category = $(this).data('category');
			_$dom.switchMallCategory(category);
		});
		_$dom.find('.J-btnCloseMall').click(function () {
			$_mask.hide();
			$_mall.hide();
		});
		_$dom.channelMallContent = null;
		_$dom.channelMyPropContent = null;
		_$dom.channelReciveContent = null;
		//缓存切换顶部操作
		_$dom.find('.J-channelMall').click(function () {
			//获取上一个标识
			var mark = _getMark('J-body');
			//设置新标识
			_setMark('J-body', 'J-channelMall');
			if (!_$dom.channelMyPropContent && (mark == 'J-channelMyProp')) {
				_$dom.channelMyPropContent = _$dom.find('.J-body').children().detach();
			} else if (!_$dom.channelReciveContent && (mark == 'J-channelRecieve')) {
				_$dom.channelReciveContent = _$dom.find('.J-body').children().detach();
			}

			if (_$dom.channelMallContent) {
				_$dom.switchTab(self.CHANNEL_MALL);
				_$dom.find('.J-body').empty().append(_$dom.channelMallContent);
			}
		});

		_$dom.find('.J-channelMyProp').click(function () {
			//获取上一个标识
			var mark = _getMark('J-body');
			//设置新标识
			_setMark('J-body', 'J-channelMyProp');
			if (!_$dom.channelMallContent && (mark == 'J-channelMall')) {
				_$dom.channelMallContent = _$dom.find('.J-body').children().detach();
			} else if (!_$dom.channelReciveContent && (mark == 'J-channelRecieve')) {
				_$dom.channelReciveContent = _$dom.find('.J-body').children().detach();
			}
			if (!_$dom.channelMyPropContent || self._isChangeMyProp) {
				_$dom.switchTab(self.CHANNEL_MYPROP);
				ajax({
					url: _aUrl.urlGetPackage,
					success: function (aResult) {
						//设置变化为false 因为已经是最新
						self._isChangeMyProp = false;
						//防止网络延迟窃走出现内容不对(内容差错)
						var mark = _getMark('J-body');
						var channelMypropHtml = $(_buildMyPropHtml(aResult.data));
						_$dom.channelMyPropContent = null;
						if (mark == 'J-channelMyProp') {
							_$dom.find('.J-body').empty().append(channelMypropHtml);
							_$dom.find('.J-myProp:first').click();
							//设置道具数量
							_$dom.find('#myPropSum').html(_myPropCountNums);
						} else {
							_$dom.channelMyPropContent = channelMypropHtml;
						}
					}
				});
			} else {
				_$dom.switchTab(self.CHANNEL_MYPROP);
				_$dom.find('.J-body').empty().append(_$dom.channelMyPropContent);
			}
		});

		_$dom.find('.J-channelRecieve').click(function () {
			//获取上一个标识
			var mark = _getMark('J-body');
			//设置新标识
			_setMark('J-body', 'J-channelRecieve');
			if (!_$dom.channelMallContent && (mark == 'J-channelMall')) {
				_$dom.channelMallContent = _$dom.find('.J-body').children().detach();
			} else if (!_$dom.channelMyPropContent && (mark == 'J-channelMyProp')) {
				_$dom.channelMyPropContent = _$dom.find('.J-body').children().detach();
			}
			if (!_$dom.channelReciveContent) {
				_$dom.switchTab(self.CHANNEL_RECIVCE);
				_$dom.find('.J-body').empty().append(_buildReciveHtml());
				_$dom.find('.J-getSendProp:first').click();
			} else {
				_$dom.switchTab(self.CHANNEL_RECIVCE);
				_$dom.find('.J-body').empty().append(_$dom.channelReciveContent);
			}

		});
		//获取赠送的道具操作
		_$dom.on('click', '.J-getSendProp', function () {
			var mySelf = $(this);
			//根据类型获取是好友赠送还是系统赠送 1 好友 2 系统
			var type = mySelf.data('type');
			//上一个选中元素
			var curre = _$dom.find('.J-getSendProp.cur').data('type');
			if (!_aSendPropList[curre]) {
				_aSendPropList[curre] = _$dom.find('.J-propList').children().detach();
			}
			//高亮选中
			mySelf.addClass('cur').siblings().removeClass('cur');
			//当前
			if (mySelf.attr('isOk') === undefined || _sendPropNumsHasChanges) {
				ajax({
					url: _aUrl.urlGetSendProp,
					data: {type: type},
					success: function (aResult) {
						_aSendPropList[type] = _getSendProp(aResult.data, type);
						//获取赠送道具html
						_$dom.find('.J-sendPropList').html(_aSendPropList[type]);
						mySelf.attr('isOk', '1');

					}
				});
			} else {
				_$dom.find('.J-sendPropList').html(_aSendPropList[type]);
			}


		});
		//收取道具
		_$dom.on('click', '.J-getProp', function () {
			var id = $(this).data('id');
			var type = $(this).data('type');
			var oBj = $(this);
			_getProp(id, type, oBj);
			_sendPropNumsHasChanges = true;
			$(this).removeClass('J-getProp');
		});
		//忽略道具
		_$dom.on('click', '.J-ignoreProp', function () {
			var id = $(this).data('id');
			var type = $(this).data('type');
			var oBj = $(this);
			_ignoreProp(id, type, oBj);
			_sendPropNumsHasChanges = true;
			$(this).removeClass('J-ignoreProp');
		});
		//道具商城的分类内容填充方法
		_$dom.showMallCategoryContent = function ($content) {
			_$dom.find('.J-propList').empty().append($content);
		}

		//道具商城左侧列表点击切换事件
		_$dom.switchMallCategory = function (category) {
			//alert('现在开始切换到' + category);
			var $category = _$dom.find('.J-categoryTab.cur');
			var currentCategory = $category.data('category');
			//alert('当前' + currentCategory);
			_$dom.find('.J-categoryTab:eq(' + (category - 1) + ')').addClass('cur').siblings().removeClass('cur');

			if (!_aCategoryDom[currentCategory]) {
				_aCategoryDom[currentCategory] = _$dom.find('.J-propList').children().detach();
			}

			var fShowNewCategoryContent = function _buildMyPropSendFriendHtml(aPropList) {
				var $categoryContent = _buildPropsSellListHtml(aPropList);
				_$dom.showMallCategoryContent($categoryContent);
			}

			if (!_aCategoryDom[category]) {
				if (!_aPropCategorySellList[category]) {
					//获取后台数据
					ajax({
						url: _aUrl.urlGetProp,
						data: {type: category},
						success: function (aResult) {
							_aPropCategorySellList[category] = aResult.data;
							fShowNewCategoryContent(_aPropCategorySellList[category]);
						}
					});
				} else {
					fShowNewCategoryContent(_aPropCategorySellList[category]);
				}
			} else {
				_$dom.showMallCategoryContent(_aCategoryDom[category]);
			}
		}
		//选中我的道具
		_$dom.selectMyProp = function (id) {
			for (var key in _aMemberHaveList) {
				if (_aMemberHaveList[key].id == id) {
					//构建切换共同拥有道具列表
					var propHaveListHtml = _buildPropHaveList(_aMemberHaveList[key].aHaveList);
					_$dom.find('.J-memberHaveList').html(propHaveListHtml);
				}
			}
		}
		//单击我的道具显示详细和共同好友拥有
		_$dom.on('click', '.J-myProp', function () {
			var myPropListHtml = $(this).data('have_list');
			var myPropDetailHtml = $(this).data('detail');
			//高亮
			$(this).addClass('selected').siblings().removeClass('selected');
			//共同拥有好友列表
			_$dom.find('.J-memberHaveList').html(myPropListHtml);
			//详细
			_$dom.find('.J-myPropDetail').html(myPropDetailHtml);

		});
		//好友分组切换
		_$dom.on('click', '.J-groupSwitch', function () {
			var groupFriendHtml = $(this).data('this_group_friend');
			//高亮
			$(this).addClass('cur').siblings().removeClass('cur');
			//共同拥有好友列表
			_$dom.find('.J-friendList').html(groupFriendHtml);

		});

		//选中赠送好友
		_$dom.on('click', '.J-friendSelect', function () {
			var friendName = $(this).find('.J-friendName').html();

			//高亮
			$(this).addClass('selected').siblings().removeClass('selected');
			//共同拥有好友列表
			_$dom.find('.J-selectedName').html(friendName);

		});

		//点击赠送按钮切换
		_$dom.on('click', '.J-btnSendProp', function () {
			//获得选中的道具保存到数组
			_aSelectedProp = _$dom.find('.J-myProp.selected').data('my_prop_id');
			//道具列表
			_$dom.find('.J-myPropList').hide();
			//选中好友名称
			_$dom.find('.J-sendBottom').show();
			//赠送好友页面
			_$dom.find('.J-sendProp').show();
			//当前面板隐藏
			_$dom.find('.J-btnSendPropParent').hide();
			_$dom.find('.J-propBottom').hide();
			_$dom.find('.J-btnSendPropParent1').show();
		});
		//开始赠送道具
		_$dom.on('click', '.J-btnSendMyProp', function () {
			_sendProp();
		});
		_$dom.on('click', '.J-btnDiscardProp', function () {
			_discardProp();
		});
		//取消
		_$dom.on('click', '.J-btnCancelSendMyProp', function () {
			//道具列表
			_$dom.find('.J-myPropList').show();
			//选中好友名称
			_$dom.find('.J-sendBottom').hide();
			//赠送好友页面
			_$dom.find('.J-sendProp').hide();
			//当前面板隐藏
			_$dom.find('.J-btnSendPropParent').show();
			_$dom.find('.J-propBottom').show();
			_$dom.find('.J-btnSendPropParent1').hide();
		});
		//加入购车加减
		_$dom.on('click', '.J-minusPropNums,.J-addPropNums', function () {
			if ($(this).hasClass('J-minusPropNums')) {
				_minusPropNums(this);
			} else {
				_addPropNums(this);
			}
		});
		//加入购物车
		_$dom.on('click', '.J-putCart', function () {
			var mySelf = $(this);
			var id = $(this).data('id');
			_putCart(id, mySelf);
		});
		//选中购物车中的道具
		_$dom.on('click', '.J-selectCartProp', function () {
			//选中效果
			if ($(this).parent('li').hasClass('selected')) {
				$(this).parent('li').removeClass('selected');
			} else {
				$(this).parent('li').addClass('selected');
			}
			//显示删除按钮
			$('#deleteProp').show();
		});

		//删除选中购物车中的道具
		_$dom.on('click', '.J-deleteCart', function () {
			var aIds = [];
			//获取选中的li取出id
			var id = $('.J-cartList .selected').each(function () {
				aIds.push($(this).data('id'));
			});
			//删除道具
			_deleteCartProp(aIds);
			//显示删除按钮
			$('#deleteProp').hide();
		});
		//购买操作
		_$dom.on('click', '.J-buyFromCart', function () {
			_buyFromCart();
		});
		_$dom.on('click', '.J-showMall', function () {
			_$dom.find('.J-channelMall').click();
		});


		//事件同步更新操作
		//自己更新和触发工具条页面的更新
		self.bindEvent(self.EVENT_AFTER_PROP_UPDATE, function (oEvent) {
			var addOrreduce = oEvent.xSenderData.action;
			//只有购买了道具在需要重新加载因为丢弃道具之类的道具列表肯定是有原来的dom不要新加直接remove即可 购买的操作就要重新生成
			if (addOrreduce == 1) {
				self._isChangeMyProp = true;
				return;
			}
			var id = oEvent.xSenderData.propId;
			//删除道具的
			_deleteMyProp(id);
		});
		// _$propBar.bindEvent('update_prop_bar_prop', function () {
		// 	//自己操作
		// });



	}
	/**
	 *工具条时间绑定
	 * @returns {undefined}
	 */
	function _getBarBindEvent() {

		//道具工具条鼠标经过切换选中效果
		_$propBar.on({
			mouseover: function () {
				var $this = $(this);
				//保存选中
				//_$propBar.data('select_prop_id', $this.data('id'));
				//高亮
				//$this.addClass('active').siblings().removeClass('active');
				//切换内容
				_buildBarPropDetailHtml($this.data('detail'), $this);
			},
			mouseout:function(){
				var prop_id = _$propBar.data('select_prop_id');
				if(prop_id === undefined){
					return;
				}
				_$propBar.find('.J-barProp[data-id="'+prop_id+'"]').click();
			},
			click:function(){
				var $this = $(this);
				//保存选中
				_$propBar.data('select_prop_id', $this.data('id'));
				//高亮
				$this.addClass('active').siblings().removeClass('active');
				//切换内容
				_buildBarPropDetailHtml($this.data('detail'), $this);
			}

		}, '.J-barProp');

		//道具条点击显示商城
		_$propBar.on('click', '.J-showMall', function () {
			self.showMall();
		});

		//使用道具点击事件
		_$propBar.on('click', '.J-useProp', function () {
			//禁用不可用道具的点击
			if ($(this).hasClass('J-barPropDisabled')) {
				return;
			}
			_$propBar.triggerEvent('update_prop_bar_prop');
			var id = _$propBar.data('select_prop_id');
			//找到相应的道具
			var $this = _$propBar.find('.J-barProp[data-id="' + id + '"]');
			//获取道具的使用类型判断当前的类型是否符合
			/*var scencType = $this.data('type');
			//如果当前的道具是通用道具2或者是积分5或者是背包容量6类型这放行
			if (!JsTools.inArray(scencType, [self.SCENE_PROP_TYPE_GENERAL, self.SCENE_PROP_TYPE_POINTS, self.SCENE_PROP_TYPE_GROOMING])) {
				if (scencType != _$propBar.scenc) {
					UBox.show('当前页面不适合使22用该道具');
					return;
				}
			}*/

			//根据情况使用不用函数对使用道具的使用
			var func = $this.data('fun');
			self.useProp(id, func);
		});

		//道具发生变化的时候执行的方法
		_$propBar.updateProp = function (oProps) {
			//操作标示 0 删除 1 增加
			var addOrreduce = oProps.action;
			//删除道具操作
			if (addOrreduce == 0) {
				_$propBar.reduce(oProps);
				return;
			}
			//调用相减操作
			_$propBar.addProp(oProps);

		};

		//道具商城道具减少操作
		_$propBar.reduce = function (oProps) {
			//获取具体删除那一个
			var id = oProps.propId;
			//找到丢弃道具对象
			var $prop = _$propBar.find('.J-barProp[data-id="' + id + '"]:first');
			//具体数量一般都只有一个
			var updateNums = oProps.num;
			//获取数量
			var num = $prop.find('.J-barPropNum').html();
			//限制非数字
			if (!_isNumber(num)) {
				return;
			}

			num = parseInt(num);
			var propLength = _$propBar.find('.J-barProp').length;
			if (propLength == 1 && ((num <= 1) || (updateNums >= num))) {
				//使用_$dom 为了兼顾克隆的对象同时也能出现这种效果
				_$dom.find('.J-prorpBarParent').addClass('nodata');
				_$dom.find('.J-prorpBarParent').html('<div class="prop-nodata">还没有道具，去<a href="javascript:;" class="J-showMall">道具商店</a>看看吧！</div>');
			}
			//通知克隆体减少
			_$propBar.cloneBarPropReduce(id, num, updateNums);
			//判断是否删除数量大于等于现有数量或者剩余一个如有则删除当前道具
			if ((num <= 1) || (updateNums >= num)) {
				$prop.remove();
				//设置下一个选中
				_$propBar.selectProp();
				return;
			}

			//获得数量相减
			$prop.find('.J-barPropNum').html((num - updateNums));
		};

		//使用道具选中第一个方法
		_$propBar.selectProp = function(){
			_$propBar.find('.J-barProp:first').click();
			//克隆体点击
			for (var i in _$cloneBarProp) {
				 _$cloneBarProp[i].find('.J-barProp:first').mouseover();
			}

		}

		//道具商城新增操作
		_$propBar.addProp = function (oProps) {
			//添加道具操作
			var aPropIds = oProps.propId;
			var aAddPropCountList = {};
			_$propBar.clonePropAdd(aPropIds);
			//统计数量
			for (var propId in aPropIds) {
				if (aAddPropCountList[aPropIds[propId]] === undefined) {
					aAddPropCountList[aPropIds[propId]] = 1;
				} else {
					aAddPropCountList[aPropIds[propId]]++;
				}
			}
			//页面操作
			for (var i in aAddPropCountList) {
				var $oProp = _$propBar.find('.J-barProp[data-id="' + i + '"]:first');
				//没有找到在工具条列表这认为是新的道具
				if ($oProp.length == 0) {
					//只要一个在列表中不存在的都认为数据不足,自动后台更新
					//构建新型的道具单元
					_$propBar.renewBarPropHtml();
					return;
				}
				//居于已经存在的道具执行数量相加
				var $oNum = $oProp.find('.J-barPropNum');
				var nums = $oNum.html();
				var num = parseInt(nums) + aAddPropCountList[i];
				$oNum.html(num);
			}

		};

		//克隆体减少操作
		_$propBar.cloneBarPropReduce = function (id, num, updateNums) {
			//减少
			if ((num <= 1) || (updateNums >= num)) {
				for (var i in _$cloneBarProp) {
					var $cloneBar = _$cloneBarProp[i].find('.J-barProp[data-id="' + id + '"]:first');
					$cloneBar.remove();
				}
				return;
			}
			for (var i in _$cloneBarProp) {
				var $cloneBar = _$cloneBarProp[i].find('.J-barProp[data-id="' + id + '"]:first');
				$cloneBar.find('.J-barPropNum').html((num - updateNums));
			}

		};
		//克隆体增加操作
		_$propBar.clonePropAdd = function (id) {
			var aPropIds = id;
			var barHtml = null;
			var aAddPropCountList = {};
			//加
			//统计数量
			for (var propId in aPropIds) {
				if (aAddPropCountList[aPropIds[propId]] === undefined) {
					aAddPropCountList[aPropIds[propId]] = 1;
				} else {
					aAddPropCountList[aPropIds[propId]]++;
				}
			}
			//页面操作
			for (var i in aAddPropCountList) {
				for (var k in _$cloneBarProp) {
					var $oProp = _$cloneBarProp[k].find('.J-barProp[data-id="' + i + '"]:first');
					//没有找到在工具条列表这认为是新的道具
					if ($oProp.length == 0) {
						//只要一个在列表中不存在的都认为数据不足,自动后台更新
						//构建新型的道具单元
						if (!barHtml) {
							ajax({
								url: _aUrl.urlGetToolBar,
								data: {scene : _$propBar.scenc},
								async: false,
								success: function (aResult) {
									if (aResult.status != 1) {
										UBox.show(aResult.msg, aResult.status);
										return;
									}

									//取出可用列表和非可用列表
									var aEnableList = aResult.data.enable;
									var aDisableList = aResult.data.disable;
									barHtml = _buildBarPropListHtml(aEnableList, aDisableList);
									_$cloneBarProp[k].find('.J-barPropList').html(barHtml);

								}
							});
						} else {
							_$cloneBarProp[k].find('.J-barPropList').html(barHtml);
						}

					} else {
						//居于已经存在的道具执行数量相加
						var $oNum = $oProp.find('.J-barPropNum');
						var nums = $oNum.html();
						var num = parseInt(nums) + aAddPropCountList[i];
						$oNum.html(num);
					}


				}

			}

		};


		/**
		 * 重新构建道具条列表替换存在的列表
		 * 插入替换原来的就列表
		 */
		_$propBar.renewBarPropHtml = function () {
			ajax({
				url: _aUrl.urlGetToolBar,
				data: {scene: _$propBar.scenc},
				success: function (aResult) {
					if (aResult.status != 1) {
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					//取出可用列表和非可用列表
					var aEnableList = aResult.data.enable;
					var aDisableList = aResult.data.disable;
					var $prorpBarParent = _$dom.find('.J-prorpBarParent');
					//当购买第一件道具的时候构建整个html
					if ($prorpBarParent.hasClass('nodata')) {
						$prorpBarParent.removeClass('nodata');
						var renewBarhtml = '<div class="slide-warp J-barPropParentDiv" id="propBar">\
						<a href="javascript:;" class="prev">\
							<i class="v3-common-prev"></i>\
						</a>\
						<div class="slide J-barPropSlide">\
							<ul class=list-unstyled J-barPropList">';
						//列表
						renewBarhtml += _buildBarPropListHtml(aEnableList, aDisableList);
						renewBarhtml += '</ul>\
						</div>\
						<a href="javascript:;" class="next">\
							<i class="v3-common-next"></i>\
						</a>\
					</div>\
					<!-- 道具详情 -->\
					<div class="prop-detail J-barPropDetail" id="propDetail">\
					</div>';
						$prorpBarParent.html(renewBarhtml);
						_$propBar.find('.J-barProp:first').click();
						return;
					}
					//重新生成道具条
					//道具列表已经存在的情况
					var propBarHtml = _buildBarPropListHtml(aEnableList, aDisableList);
					_$propBar.find('.J-barPropList').html(propBarHtml);
					_$propBar.selectProp();

				}
			});
		}

		//继承父级事件
		_$propBar = $.extend(_$propBar, new Component());

		//事件同步更新操作
		//当道具商城的道具发生改变触发该事件通知$propBar.update 执行操作
		self.bindEvent(self.EVENT_AFTER_PROP_UPDATE, function (oEvent) {
			_$propBar.updateProp(oEvent.xSenderData);
		});

		//自己更新是触发道具商城主页面的更新
		_$propBar.bindEvent('update_prop_bar_prop', function (oEvent) {
			oEvent.xParams
			//道具商店的触发
			//self.update_prop_bar_rop();
		});
	}

	Prop = $.extend(Prop, new Component());
	var _propList = [];
	var _$cloneBarProp = [];
	//我的道具的数量
	var _myPropCountNums = 0;
	var _aCategoryList = ['', 1, 2, 3, 4, 5, 6];
	var _aCategoryDom = [];
	//cookie生命周期
	var _cookieLifeTime = 1440000;
	//购物车限制数量
	var _cartNumsLimit = 100;
	//赠送道具存储
	var _aSelectedProp = null;
	//赠送存储列表 //获取道具的状态是否发生变化
	var _aSendPropList = [],_sendPropNumsHasChanges = false;
	var self = Prop,
			$_mall = null,
			$_mask = null,
			_aPropCategorySellList = {};
	var self = Prop,
			$_mall = null,
			$_mask = null,
			_aPropCategorySellList = {},
			_$propBar = null;	//道具条对象

	var _aUrl = {
		urlGetProp: '',
		urlPutCart: '',
		urlBuyFromCart: '',
		urlGetPackage: '',
		urlDiscardProp: '',
		urlSendProp: '',
		urlGetToolBar: '',
		urlGetSendProp: '',
		urlGetMyProp: '',
		urlIgnoreMyProp: '',
		urlUseProp: '',
		urlGetPropCartInfo: '',
		urlResource: ''
	};
	var _$dom = $("body,#newHead,#header").last();
})(jQuery, window, App);