(function($, win){
	win.UMDialogs = {
		TYPE_ADD_FRIEND : 1,
		TYPE_SEND_MESSAGE : 2,
		TYPE_USER_INFO : 3,
		configType : 1,
		dialogs : '',
		oCache : {user_info : [], oImg : {}},
		oConfig : {
			user_target_id : 0,
			user_info_url : '',
			add_friend_url : '',
			send_message_url : ''
		},
		
		build : function(type, config){
			$('.J-dialogs-wraper').remove();
			this.configType = type;
			$.extend(this.oConfig, config);
			var htmlStr = '';
			if(self.configType == self.TYPE_ADD_FRIEND){
				htmlStr = _buildAddFriendDialogsHtml();
			}else if(self.configType == self.TYPE_SEND_MESSAGE){
				htmlStr = _buildSendMessageDialogsHtml();
			}else if(self.configType == self.TYPE_USER_INFO){
				htmlStr = _buildUserPostcardDialogsHtml();
			}
			this.dialogs = $(htmlStr);
			this.dialogs.show = _show;
			
			return this.dialogs;
		},
		
		listenToShowStudentInfo : function(oDom, oConfig){
			var oThis = this;
			$.extend(oThis.oConfig, oConfig);
			oDom.on('mouseover', function(){
				var oImg = $(this);
				var timeOutHandle = setTimeout(function(){
					if(oThis.dialogs != ''){
						oThis.dialogs.remove();
					}
					oThis.oCache.oImg = oImg;
					oThis.build(oThis.TYPE_USER_INFO, {
						user_target_id : oImg.attr('data-student_id'),
						user_info_url : oConfig.user_info_url
					}).show();
				}, 1000);
				$(this).mouseout(function(){
					clearInterval(timeOutHandle);
				});
			});
		}
		
	};
		
	function _show(){
		if(self.configType == self.TYPE_ADD_FRIEND){
			_getUserInfo(self.oConfig.user_target_id, _showAddFriend);
		}else if(self.configType == self.TYPE_SEND_MESSAGE){
			_getUserInfo(self.oConfig.user_target_id, _showSendMessage);
		}else if(self.configType == self.TYPE_USER_INFO){
			_getUserInfo(self.oConfig.user_target_id, _showUserPostcard);
		}
	}
	
	function _showAddFriend(data){
		var htmlStr = _buildUserInfo(data);
		self.dialogs.find('.J-user-info').html(htmlStr);
		_showDialogs();
		self.dialogs.find('.J-add-friend-btn').unbind();
		self.dialogs.find('.J-add-friend-btn').on('click', function(){
			var textArea = $(this).parent().parent().find('textarea');
			_commitAddFriend(textArea.val());
		});
	}
	
	function _showSendMessage(data){
		var htmlStr = _buildUserInfo(data);
		self.dialogs.find('.J-user-info').html(htmlStr);
		_showDialogs();
		self.dialogs.find('.J-send-msg-btn').unbind();
		self.dialogs.find('.J-send-msg-btn').on('click', function(){
			var textArea = $(this).parent().parent().find('textarea');
			if(textArea.val() == ''){
				UBox.show('请输入纸条信息！', -1);
				return;
			}
			_commitSendMessage(textArea.val());
		});
	}
	
	function _showUserPostcard(data){
		_fillUserPostcardData(data);
		var imgTop = self.oCache.oImg.offset().top + self.oCache.oImg.width() / 2,
		imgLeft = self.oCache.oImg.offset().left + self.oCache.oImg.width() + 2 - self.oCache.oImg.width() / 2;
		if(imgLeft + 360 > $(document).scrollLeft() + $(window).width()){
			imgLeft = imgLeft - 360;
		}
		if(imgTop + 310 > $(document).scrollTop() + $(window).height()){
			imgTop = imgTop - 310;
		}
		$('body,#wrapPage').last().append(self.dialogs);
		self.dialogs.fadeIn();
		self.dialogs.css({top : imgTop, left : imgLeft});
		
		self.oCache.oImg.on('mouseleave', function(){
			var t = setTimeout(function(){
				self.dialogs.fadeOut(function(){
					$(this).remove();
				});
			}, 1000);
			self.dialogs.on('mouseover', function() {
				clearInterval(t);
			});
		});
		self.dialogs.on('mouseleave', function(){
			self.dialogs.fadeOut(function(){
				$(this).remove();
			});
		});
		
		self.dialogs.find('.J-add-friend').on('click', function(){
			self.dialogs.fadeOut(function(){
				$(this).remove();
			});
			var t = setTimeout(function(){
				self.build(self.TYPE_ADD_FRIEND, self.oConfig).show();
			}, 500);
		});
		self.dialogs.find('.J-send-msg').on('click', function(){
			self.dialogs.fadeOut(function(){
				$(this).remove();
			});
			var t = setTimeout(function(){
				self.build(self.TYPE_SEND_MESSAGE, self.oConfig).show();
			}, 500);
		});
	}
	
	function _commitAddFriend(content){
		ajax({
			url : self.oConfig.add_friend_url,
			data : {
				userId : self.oConfig.user_target_id,
				confirmMessage : content
			},
			success : function(aResult){
				if(aResult.status == 1){
					self.dialogs.modal('hide');
					UBox.show('操作成功！', aResult.status);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error : function(){
				UBox.show('抱歉，系统错误！', 0);
			}
		});
	}
	
	function _commitSendMessage(content){
		ajax({
			url : self.oConfig.send_message_url,
			data : {
				receiver_user_id : self.oConfig.user_target_id,
				content : content
			},
			success : function(aResult){
				if(aResult.status == 1){
					self.dialogs.modal('hide');
					UBox.show('操作成功！', aResult.status);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error : function(){
				UBox.show('抱歉，系统错误！', 0);
			}
		});
	}
	
	function _showDialogs(){
		self.dialogs.addClass('J-dialogs-wraper');
		var timeOutHandle = setTimeout(function(){
			$('body,#wrapPage').last().append(self.dialogs);
			self.dialogs.modal('show');
		}, 300);
	}
	
	function _getUserInfo(userId, callback){
		var key = 'u_' + userId;
		if(typeof(self.oCache.user_info[key]) != 'undefined'){
			callback(self.oCache.user_info[key]);
			return ;
		}
		ajax({
			url : self.oConfig.user_info_url,
			data : {user_id : userId},
			success : function(aResult){
				if(aResult.status == 1){
					self.oCache.user_info[key] = aResult.data;
					callback(aResult.data);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			},
			error : function(){
				UBox.show('抱歉，系统错误！', 0);
			}
		});
	}
	
	function _buildAddFriendDialogsHtml(){
		var htmlStr = '';
		htmlStr += '<div id="fricheck" class="modal hide fade min-modal fricheck">\
				<div class="hd">\
					<h2>好友申请</h2>\
				</div>\
				<div class="bd">\
					<div class="modal-body">\
						<div class="J-user-info modal-info"></div>\
						<div class="modal-cont">\
							<div class="label">请输入验证信息：</div>\
							<div class="textbox">\
								<textarea class="text" placeholder="Hi,我是.."></textarea>\
							</div>\
							<div class="btnbox">\
								<a href="javascript:void(0);" class="J-add-friend-btn um-btn um-btn-default um-btn-xlg">确定</a>\
							</div>\
						</div>\
					</div>\
				</div>\
				<a href="javascript:;" class="close J-close" data-dismiss="modal">×</a>\
			</div>\
		';
		
		return htmlStr;
	}
	
	function _buildSendMessageDialogsHtml(){
		var htmlStr = '';
		htmlStr += '<div id="paper" class="modal hide fade min-modal paper">\
				<div class="hd">\
					<h2>小纸条</h2>\
				</div>\
				<div class="bd">\
					<div class="modal-body">\
						<div class="J-user-info modal-info"></div>\
						<div class="modal-cont">\
							<div class="textbox">\
								<textarea class="text" placeholder="请输入纸条信息"></textarea>\
							</div>\
							<div class="btnbox">\
								<a href="javascript:void(0);" class="J-send-msg-btn um-btn um-btn-default um-btn-xlg">确定</a>\
							</div>\
						</div>\
					</div>\
				</div>\
				<a href="javascript:;" class="close J-close" data-dismiss="modal">×</a>\
			</div>\
		';
		
		return htmlStr;
	}
		
	function _buildUserPostcardDialogsHtml(){
		var htmlStr = '';
		htmlStr += '<div class="minicard">\
				<div class="minicard-hd">\
					<a href="javascript:;" class="J-avatar avatar"></a>\
					<div class="info">\
						<div class="i1">\
							<a href="###" class="J-vip-name vip3-name vname"></a>\
							<i class="J-sex-ico ico ico_boy"></i>\
							<a href="javascript:;" disabled="" class="J-vip-icon vip1-icon vicon">\
								<i class="icon"></i>\
							</a>\
							<i class="J-mail v3-acc"></i>\
						</div>\
						<div class="i2">\
							<p class="J-school"></p>\
							<p class="J-class"></p>\
						</div>\
						<div class="J-gold i3">\
							金币：0\
						</div>\
					</div>\
				</div>\
				<div class="minicard-bd">\
					<div class="w1">\
						<div class="J-Dan rank5 rank-icon"></div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_copper_b"></i>\
							<span class="J-copper-num text">0</span>\
						</div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_silver_b"></i>\
							<span class="J-silver-num text">0</span>\
						</div>\
						<div class="brand">\
							<i class="ico_brand ico_brand_gold_b"></i>\
							<span class="J-gold-num text">0</span>\
						</div>\
					</div>\
					<div class="J-thread w2"></div>\
				</div>\
				<div class="minicard-ft">\
					<a href="#fricheck" data-toggle="modal" class="J-add-friend">加好友</a>\
					<a href="#paper" data-toggle="modal" class="J-send-msg">小纸条</a>\
				</div>\
			</div>\
		';
		
		return htmlStr;
	}
	
	function _fillUserPostcardData(data){
		self.dialogs.find('.J-avatar').replaceWith(Ui1.buildProfile(data, true));
		self.dialogs.find('.J-vip-name').replaceWith(Ui1.buildVipName(data, true));
		self.dialogs.find('.J-vip-icon').replaceWith(Ui1.buildVipIcon(data.vip));
		if(data.is_email_active == 1){
			self.dialogs.find('.J-mail').replaceWith('<i class="v3-acc-active"></i>');
		}else{
			self.dialogs.find('.J-mail').replaceWith('<i class="v3-acc"></i>');
		}
		if(data.gender == 1){
			self.dialogs.find('.J-sex-ico').replaceWith('<i class="J-sex-ico ico ico_boy"></i>');
		}else{
			self.dialogs.find('.J-sex-ico').replaceWith('<i class="J-sex-ico ico ico_girl"></i>');
		}
		self.dialogs.find('.J-school').html(data.school);
		self.dialogs.find('.J-class').html(data.gradeName + data.class);
		self.dialogs.find('.J-gold').html('金币：' + data.gold);
		self.dialogs.find('.J-Dan').html('<img src="' + data.dan_info.image + '"><span class="text">' + data.dan_info.name + '</span>');
		self.dialogs.find('.J-copper-num').html(data.medal_info.cuprum_medal);
		self.dialogs.find('.J-silver-num').html(data.medal_info.silver_medal);
		self.dialogs.find('.J-gold-num').html(data.medal_info.gold_medal);
		if(typeof(data.last_thread_info.title) != 'undefined'){
			self.dialogs.find('.J-thread').html('最近发表话题：' + data.last_thread_info.title);
		}else{
			self.dialogs.find('.J-thread').html('最近发表话题：暂无发表话题');
		}
		
		if(data.is_friend != 0){
			self.dialogs.find('.J-add-friend').css({background : '#ccc'});
			self.dialogs.find('.J-add-friend').removeClass('J-add-friend');
		}
		if(data.is_friend != 1){
			self.dialogs.find('.J-send-msg').css({background : '#ccc'});
			self.dialogs.find('.J-send-msg').removeClass('J-send-msg');
		}
	}
	
	function _buildUserInfo(data){
		return '<div class="img">\
				' + Ui1.buildProfile(data, true) + '\
			</div>\
			<div class="pub">\
				' + Ui1.buildVipName(data, true) + '\
				<i class="lv lv' + data.level + '"></i>\
			</div>\
			<div class="uid">\
				' + data.id + '\
			</div>\
			<div class="feature">\
				<i class="ico ico_feature"></i>\
				' + data.genderStr + ',' + data.age + '岁,' + data.constellation + '\
			</div>\
			<div class="site">\
				<i class="ico ico_site"></i>\
				' + data.province + '-' + data.city + '-' + data.area + '\
			</div>\
			<div class="school">\
				<i class="ico ico_school"></i>\
				' + data.school + '\
			</div>\
		';
	}
	
	var self = win.UMDialogs;


})(jQuery, window);
