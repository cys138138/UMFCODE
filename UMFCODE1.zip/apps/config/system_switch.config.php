<?php
$GLOBALS['SYSTEM_SWITCH'] = array (
  'is_open_system_m' => '1',
  'm_close_tip' => '',
  'is_open_system_www' => '1',
  'www_close_tip' => '',
  'is_open_system_sns' => '1',
  'sns_close_tip' => '',
  'is_open_system_pay' => '1',
  'pay_close_tip' => '',
  'is_open_system_proxy' => '1',
  'proxy_close_tip' => '',
);