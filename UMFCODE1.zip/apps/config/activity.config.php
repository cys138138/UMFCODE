<?php
$GLOBALS['ACTIVE'] = array(
	'activity_center'	=>	array(
		array(
			'title'			=>	'新年红包大作战',
			'start_time'	=>	1423929600,
			'end_time'		=>	1425571200,
			'url'			=>	'http://' . APP_HOME . '/mission_x/red_packet.html',
			'm_url'			=>	'http://' . APP_XXT . '/x/red_packet.html',
			'hall_img'		=>	'data/activity/center/red_packet.jpg'
		),
		/*
		array(
			'title'			=>	'巅峰队决',
			'start_time'	=>	1419523200,
			'end_time'		=>	1429977600,
			'url'			=>	'http://' . APP_HOME . '/activity/team_award.html',
			'm_url'			=>	'http://' . APP_HOME . '/activity/team_intro_do.html',
			'hall_img'		=>	'data/activity/center/team.jpg'
		),
		*/
		array(
			'title'			=>	'兑换商城活动',
			'start_time'	=>	1418400000,
			'end_time'		=>	1426176000,
			'url'			=>	'http://' . APP_HOME . '/mission_x/article/398.html',
			'm_url'			=>	'http://' . APP_XXT . '/activity/exchange_activity.html',
			'hall_img'		=>	'data/activity/center/exchange.jpg'
		),
		array(
			'title'			=>	'争分夺宝',
			'start_time'	=>	1415030401,
			'end_time'		=>	1419955200,
			'url'			=>	'http://' . APP_HOME . '/mission_x/article/390.html',
			'm_url'			=>	'http://' . APP_HOME . '/activity/study_tour_do.html',
			'hall_img'		=>	'data/activity/center/duobao.jpg'
		),
		array(
			'title'			=>	'闯关有礼',
			'start_time'	=>	1411920000,
			'end_time'		=>	1419696000,
			'url'			=>	'http://' . APP_HOME . '/activity/mission.html',
			'm_url'			=>	'http://' . APP_XXT . '/activity/mission.html',
			'hall_img'		=>	'data/activity/center/03.jpg'
		),
		array(
			'title'			=>	'2014教师节',
			'start_time'	=>	1408896000,
			'end_time'		=>	1410278400,
			'url'			=>	'http://' . APP_HOME . '/teachers_day.html',
			'm_url'			=>	'http://' . APP_XXT . '/activity/teacher_activity.html',
			'hall_img'		=>	'data/activity/center/06.jpg'
		),
	),
);
