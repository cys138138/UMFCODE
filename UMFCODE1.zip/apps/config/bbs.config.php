<?php
$GLOBALS['BBS'] = array(
	'hot' => 100,
	'defult_channel' => 1
);