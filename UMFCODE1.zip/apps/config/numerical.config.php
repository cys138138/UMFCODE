<?php
define('UB_GOLD_RATE', 10);

//经验加成控制配置
$GLOBALS['POINT'] = array(
	'new' => array(
		'mission' => 100,
		'pk' => 50,
		'join_match' => 50,
		'perfect_information' => 30,
		'active_email' => 50,
		'invited' => 50,
	),
	'shuoshuo' => 5,
	'add_friend' => 10,
	'es' => 1,
	'mission' => array(
		'limit_es' => 50,
		'practice_extra_base' => 50,
		'breaking_world_record_min' => 10,
		'breaking_world_record_max' => 100,
		'first_finish_mission_base' => 100,
	),
	'match' => array(
		'limit_es' => 50,
		'first_rate' => 1,
		'second_rate' => 0.80,
		'third_rate' => 0.60,
		'excellent_rate' => 0.40,
		'lucky_rate' => 0.20,
		'limit_join_min' => 1000,
		'limit_join_max' => 5000,
	),
	'blue_box' => array(
		10 => 2000,
		20 => 1000,
		50 => 100,
		100 => 40,
		200 => 5,
	),
	'rotate_prizes' => array(
		3 => 50,
		4 => 100,
		5 => 50,
		6 => 25,
	),

	'daily_tasks' => array(
		0 => array(
			'name' => '邀请1位好友',
			'times' => 1,
			'point' => 50,
			'gold' => 2,
		),
		1 => array(
			'name' => '挑战1个关卡并首次达到90+分',
			'times' => 1,
			'point' => 30,
			'gold' => 2,
		),
		2 => array(
			'name' => '通过2个新的语文关卡',
			'times' => 2,
			'point' => 30,
			'gold' => 2,
		),
		3 => array(
			'name' => '通过2个新的数学关卡',
			'times' => 2,
			'point' => 30,
			'gold' => 2,
		),
		4 => array(
			'name' => '通过2个新的英语关卡',
			'times' => 2,
			'point' => 30,
			'gold' => 2,
		),
		5 => array(
			'name' => '发一场带金币PK到PK大厅',	//任务名称
			'times' => 1, //任务数量
			'point' => 5, //任务经验
			'gold' => 3, //任务金币
		),
		6 => array(
			'name' => '获得1场PK胜利',
			'times' => 1,
			'point' => 30,
			'gold' => 1,
		),
		7 => array(
			'name' => '参加2场比赛',
			'times' => 2,
			'point' => 20,
			'gold' => 1,
		),
		8 => array(
			'name' => '参加1场比赛并获得80+分',
			'times' => 1,
			'point' => 30,
			'gold' => 2,
		),
	)
);

//等级经验表
$GLOBALS['LEVEL'] = array(
	0,
	210,
	420,
	630,
	840,
	1090,
	1340,
	1590,
	1840,
	2100,
	2310,
	2520,
	2730,
	2940,
	3150,
	3360,
	3570,
	3780,
	3990,
	4200,
	5015,
	5831,
	6743,
	7758,
	8882,
	10120,
	11479,
	12965,
	14582,
	16339,
	18239,
	20290,
	22498,
	24867,
	27405,
	30117,
	33009,
	36088,
	39358,
	42827,
	46499,
	50382,
	54480,
	58800,
	63349,
	68131,
	73152,
	78420,
	83939,
	89716,
	95757,
	102067,
	108652,
	115520,
	122674,
	130122,
	137870,
	145923,
	154287,
	162969,
	180333,
	197697,
	215061,
	232425,
	249789,
	267153,
	284517,
	301881,
	319245,
	353973,
	388701,
	423429,
	458157,
	492885,
	527613,
	562341,
	597069,
	631797,
	666525,
	718617,
	770709,
	822801,
	874893,
	926985,
	979077,
	1031169,
	1083261,
	1135353,
	1187445,
	1256901,
	1326357,
	1395813,
	1465269,
	1534725,
	1604181,
	1673637,
	1743093,
	1812549,
	1882005
);

//金币产出控制配置
$GLOBALS['GOLD'] = array(
	'mark' => array(
		2 => 1,
		6 => 2,
		14 => 3,
		30 => 4,
		31 => 5,
	),
	'red_box' => array(
		2 => 1000,
		5 => 200,
		10 => 50,
		100 => 5,
		1000 => 1,
	),
	'feedback_wrong_es' => 2,
	'rotate_prizes' => array(
		2 => 2000,
		4 => 200,
		5 => 100,
		6 => 50,
	),
	'verificate_mail' => 20,
	'rand_gold5' => 5,
	'rand_gold10' => 10,
);


//过关斩将勋章等级配置
$GLOBALS['PASSED_MISSIONS_MEDAL'] = array(
	1 => array('nums' => 1, 'point' => 10, 'gold' => 1),
	2 => array('nums' => 10, 'point' => 30, 'gold' => 2),
	3 => array('nums' => 30, 'point' => 50, 'gold' => 3),
	4 => array('nums' => 90, 'point' => 70, 'gold' => 4),
	5 => array('nums' => 180, 'point' => 100, 'gold' => 5),
	6 => array('nums' => 300, 'point' => 200, 'gold' => 10),
	7 => array('nums' => 450, 'point' => 400, 'gold' => 20),
	8 => array('nums' => 650, 'point' => 800, 'gold' => 50),
	9 => array('nums' => 1000, 'point' => 1000, 'gold' => 100),
);

//箭无虚发勋章等级配置
$GLOBALS['EXCELLENT_MISSIONS_SCORE'] = 9000;
$GLOBALS['EXCELLENT_MISSIONS_MEDAL'] = array(
	1 => array('nums' => 1, 'point' => 10, 'gold' => 1),
	2 => array('nums' => 3, 'point' => 30, 'gold' => 2),
	3 => array('nums' => 10, 'point' => 50, 'gold' => 3),
	4 => array('nums' => 30, 'point' => 70, 'gold' => 4),
	5 => array('nums' => 100, 'point' => 100, 'gold' => 5),
	6 => array('nums' => 200, 'point' => 200, 'gold' => 10),
	7 => array('nums' => 350, 'point' => 400, 'gold' => 20),
	8 => array('nums' => 600, 'point' => 800, 'gold' => 50),
	9 => array('nums' => 1000, 'point' => 1000, 'gold' => 100),
);


//PK胜者勋章等级配置
$GLOBALS['PK_WIN_MEDAL'] = array(
	1 => array('nums' => 3, 'point' => 10, 'gold' => 1, 'name' => '初入江湖'),
	2 => array('nums' => 10, 'point' => 30, 'gold' => 2, 'name' => '江湖闲杂'),
	3 => array('nums' => 50, 'point' => 50, 'gold' => 3, 'name' => '崭露头角'),
	4 => array('nums' => 100, 'point' => 70, 'gold' => 4, 'name' => '小有名气'),
	5 => array('nums' => 500, 'point' => 100, 'gold' => 5, 'name' => '出类拔萃'),
	6 => array('nums' => 1000, 'point' => 200, 'gold' => 10, 'name' => '声名鹊起'),
	7 => array('nums' => 2000, 'point' => 400, 'gold' => 20, 'name' => '纵横江湖'),
	8 => array('nums' => 4000, 'point' => 600, 'gold' => 50, 'name' => '名震四方'),
	9 => array('nums' => 6000, 'point' => 1000, 'gold' => 100, 'name' => '孤独求败'),
);



//勋章事件类型配置
$GLOBALS['MEDAL_EVENT'] = array(
	//1 => '身经百战勋章',
	2 => '闯关勋章',
	3 => '闯关奖章',
	//4 => '百战百胜勋章',
	//5 => 'PK战神勋章',
	6 => 'PK勋章',
	//7 => '赛事达人勋章',
	//8 => '赛事奖者勋章',
	//9 => '妙语连珠勋章',
);

//勋章图片
$GLOBALS['MEDAL_IMG'] = array(
	//1 => SYSTEM_RESOURCE_URL . 'data/medal/challenge_times.png',
	2 => SYSTEM_RESOURCE_URL . 'data/medal/passed_missions.png',
	3 => SYSTEM_RESOURCE_URL . 'data/medal/excellent_missions.png',
	//4 => SYSTEM_RESOURCE_URL . 'data/medal/perfect_missions.png',
	//5 => SYSTEM_RESOURCE_URL . 'data/medal/pk_times.png',
	6 => SYSTEM_RESOURCE_URL . 'data/medal/pk_win_times.png',
	//7 => SYSTEM_RESOURCE_URL . 'data/medal/match_times.png',
	//8 => SYSTEM_RESOURCE_URL . 'data/medal/match_win_times.png',
	//9 => SYSTEM_RESOURCE_URL . 'data/medal/comment_support_times.png',
);

//会员相关数值配置
$GLOBALS['VIP'] = array(
	0 => array(
		'vip' => 0,
		'name' => '普通用户',
		'update' => 1.0,
		'collection' => 100,
		'repair_wrong' => 0,
		'prop_price' => 10,
		'day_gold' => 0,
		'day_points' => 0,
		'day_prop' => 0,
		'exchange' => 1,
	),
	1 => array(
		'vip' => 1,
		'name' => 'VIP会员',
		'month_price' => 10,
		'year_price' => 100,
		'update' => 1.1,
		'collection' => 200,
		'repair_wrong' => 0,
		'prop_price' => 10,
		'day_gold' => 2,
		'day_points' => 7,
		'day_prop' => 1,
		'exchange' => 0.95,
	),
	2 => array(
		'vip' => 2,
		'name' => 'VIP会员',
		'month_price' => 30,
		'year_price' => 298,
		'update' => 1.3,
		'collection' => 600,
		'repair_wrong' => 80,
		'prop_price' => 10,
		'day_gold' => 4,
		'day_points' => 10,
		'day_prop' => 3,
		'exchange' => 0.85,
	),
	//以上两个会员暂时废除
	3 => array(
		'vip' => 3,
		'name' => 'VIP会员',
		'month_price' => 10,
		'year_price' => 100,
		'update' => 1.4,
		'collection' => 800,
		'repair_wrong' => 100,
		'prop_price' => 10,
		'day_gold' => 5,
		'day_points' => 12,
		'day_prop' => 4,
		'exchange' => 0.82,
	),
);


//修炼抽奖奖品
$GLOBALS['ZODIAC_PRIZE'] = array(
	array(
		'rank' => 1,
		'prize' => 'mouse',
		'chance' => 100
	),
	array(
		'rank' => 12,
		'prize' => 'pig',
		'chance' => 100
	),
	array(
		'rank' => 11,
		'prize' => 'dog',
		'chance' => 100
	),
	array(
		'rank' => 10,
		'prize' => 'chicken',
		'chance' => 100
	),
	array(
		'rank' => 9,
		'prize' => 'monkey',
		'chance' => 100
	),
	array(
		'rank' => 8,
		'prize' => 'sheep',
		'chance' => 100
	),
	array(
		'rank' => 7,
		'prize' => 'horse',
		'chance' => 30
	),
	array(
		'rank' => 6,
		'prize' => 'snake',
		'chance' => 100
	),
	array(
		'rank' => 5,
		'prize' => 'long',
		'chance' => 10
	),
	array(
		'rank' => 4,
		'prize' => 'rabbit',
		'chance' => 100
	),
	array(
		'rank' => 3,
		'prize' => 'tiger',
		'chance' => 20
	),
	array(
		'rank' => 2,
		'prize' => 'cow',
		'chance' => 100
	),
	array(
		'rank' => 13,
		'prize' => 0,
		'chance' => 43
	),
	array(
		'rank' => 14,
		'prize' => 0,
		'chance' => 42
	),
	array(
		'rank' => 15,
		'prize' => 5,
		'chance' => 10
	),
	array(
		'rank' => 16,
		'prize' => 10,
		'chance' => 5
	),
);


//挑战抽奖奖品信息
$GLOBALS['NUMERICAL_PRIZE'] = array(
	array(
		'rank' => 1,
		'prize' => array(
			'gold' => 100
		),
		'chance' => 0
	),
	array(
		'rank' => 2,
		'prize' => array(
			'prop' => 1
		),
		'chance' => 200
	),
	array(
		'rank' => 3,
		'prize' => array(
			'gold' => 5
		),
		'chance' => 50
	),
	array(
		'rank' => 4,
		'prize' => array(
			'points' => 40
		),
		'chance' => 100
	),
	array(
		'rank' => 5,
		'prize' => array(
			'points' => 20
		),
		'chance' => 200
	),
	array(
		'rank' => 6,
		'prize' => array(),
		'chance' => 300
	),
);

//注册抽奖奖品配置
$GLOBALS['REGISTER_PRIZE'] = array(
	array(
		'pageLevel' => '特等奖',
		'dbLevel' => '2',
		'prizes' => '2000金币',
		'numberClassPoints' => '0',
		'numberClassMoney' => '9',
		'chance' => 10,
	),array(
		'pageLevel' => '安慰奖',
		'dbLevel' => '3',
		'prizes' => '50经验',
		'numberClassPoints' => '18',
		'numberClassMoney' => '0',
		'chance' => 300,
	),array(
		'pageLevel' => '一等奖',
		'dbLevel' => '4',
		'prizes' => '200金币+100经验',
		'numberClassPoints' => '19',
		'numberClassMoney' => '10',
		'chance' => 50,
	),array(
		'pageLevel' => '二等奖',
		'dbLevel' => '5',
		'prizes' => '100金币+50经验',
		'numberClassPoints' => '20',
		'numberClassMoney' => '11',
		'chance' => 100,
	),array(
		'pageLevel' => '三等奖',
		'dbLevel' => '6',
		'prizes' => '50金币+25经验',
		'numberClassPoints' => '21',
		'numberClassMoney' => '12',
		'chance' => 200,
	),
);
