<?php
return array(
	array(
		'name'		=>	'蒋玉菡',
		'profile'	=>	'data/user/default/m1.png',
	),
	array(
		'name'		=>	'王作梅',
		'profile'	=>	'data/user/default/m2.png',
	),
	array(
		'name'		=>	'张华',
		'profile'	=>	'data/user/default/m3.png',
	),
	array(
		'name'		=>	'张歆怡',
		'profile'	=>	'data/user/default/m4.png',
	),
	array(
		'name'		=>	'赵焕',
		'profile'	=>	'data/user/default/m5.png',
	),
	array(
		'name'		=>	'张逗逗',
		'profile'	=>	'data/user/default/m6.png',
	),
	array(
		'name'		=>	'李玥敏',
		'profile'	=>	'data/user/default/m7.png',
	),
	array(
		'name'		=>	'孙佳',
		'profile'	=>	'data/user/default/m8.png',
	),
	array(
		'name'		=>	'蒋超',
		'profile'	=>	'data/user/default/m9.png',
	),
	array(
		'name'		=>	'胡欣',
		'profile'	=>	'data/user/default/m10.png',
	),
	array(
		'name'		=>	'戴玉凤',
		'profile'	=>	'data/user/default/m11.png',
	),
	array(
		'name'		=>	'杨妮',
		'profile'	=>	'data/user/default/m12.png',
	),
);