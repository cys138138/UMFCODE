<?php
define('APP_LOGIN_URL', url('m=Login&a=showLogin', 'reference=' . base64_encode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']), APP_LOGIN));
define('TITLE', ' - 优满分(UMFun) - 游戏你的学习！');
header("Content-type: text/html; charset=utf-8");
$GLOBALS['VIEW'] = new View(APP_VIEW_PATH);
if(get('sf')){
	Cookie::set('sf', get('sf'), time()+30*24*3600);
}
function displayHeader($title = ''){
	echo getHeader($title);
}

function getHeader($title = ''){
	if($title){
		$title .= TITLE;
	}else{
		$title = '充值中心' . TITLE;
	}
	assign('title', $title);
	return fetch('header.html.php');
}


function displayFooter(){
	echo getFooter();
}

function getFooter(){
	return fetch('footer.html.php');
}

function checkLogin(){
	//return userId
}











