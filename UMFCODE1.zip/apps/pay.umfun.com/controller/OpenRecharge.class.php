<?php
/**
 * 默认控制器
 * @author Administrator
 */

//开放API
class OpenRechargeController{
	public function __construct(){}

	//创建订单
	private function getOrderNumber($numberInfo){
		$aData = array(
			'user_id' 			=> $numberInfo['userId'],
			'type'				=> $numberInfo['type'],
			'quantity'			=> $numberInfo['ub'],
			'proxy_user_id'		=> $numberInfo['proxy_user_id'],
			'by_proxy_user_id'	=> $numberInfo['by_proxy_user_id'],
			'pay_type'			=> $numberInfo['payType'],
			'pay_money'			=> $numberInfo['payMoney'],
			'ub_finish'			=> 1,
			'create_time' 		=> time(),
		);

		$aRechargeId = m('Recharge')->addRecharge($aData);
		if($aRechargeId){
			return $aRechargeId;
		}else{
			return 0;
		}
	}

	private function returnAlert($RESPONSE_CODE, $DATA){
		header('Content-Type:application/json; charset=utf-8');
		$arr = array(
			'RESPONSE_CODE' => $RESPONSE_CODE,
			'DATA' 			=> $DATA,
		);
		exit(json_encode($arr));
	}

	public function pay(){
		$aData = json_decode(base64_decode(post('data')), true);

		//代理商ID错误
		if(!preg_match('/^\d{5}$/', $aData['DLS_ID'])){
			$this->returnAlert(0, 101);
		}

		$aProxyInfo = m('Proxy')->getProxyUserInfoById($aData['DLS_ID']);

		//代理商不存在
		if(!$aProxyInfo){
			$this->returnAlert(0, 101);
		}

		//代理商Key错误
		if(md5($aProxyInfo['api_key']) != $aData['DLS_KEY']){
			$this->returnAlert(0, 102);
		}

		//代理商代理支付未通过申请
		if($aProxyInfo['api_is_active'] != 1 ){
			$this->returnAlert(0, 103);
		}

		//代理商IP非法
		$ip = getClientIP();
		$ipArray = explode('|', $aProxyInfo['api_ip_list']);
		if(!in_array($ip, $ipArray)){
			$this->returnAlert(0, 104);
		}
///////////////////////////////
		//代理商流水号为空
		if($aData['DLS_ORDER_NUMBER'] == ''){
			$this->returnAlert(0, 105);
		}

		$isEmail = w('isEmail()', $aData['USER_ACCOUNT']);
		$isNumber = preg_match('/^\d{8,}$/', $aData['USER_ACCOUNT']);

		//支付会员格式错误
		if(!$isEmail && !$isNumber){
			$this->returnAlert(0, 106);
		}

		$oUser = m('User');
		$method = $isEmail ? 'getUserInfoByEmail' : 'getUserInfoByNumberId';
		$aUserInfo = $oUser->$method($aData['USER_ACCOUNT']);

		//会员不存在
		if(!$aUserInfo){
			$this->returnAlert(0, 106);
		}

		//更新会员代理商
		if($aUserInfo['proxy_id'] < 1){
			$aUserData = array(
				'id' 		=> $aUserInfo['id'],
				'proxy_id' 	=> $aData['DLS_ID'],
			);
			$setRow = $oUser->setUserIndexInfo($aUserData);
			if($setRow === false){
				alert('系统出错', 0);
			}
		}

		///充值金额未设上限
		//充值UB金额非法
		if(!preg_match('/^[1-9]\d+$/', $aData['USER_MONEY'])){
			$this->returnAlert(0, 107);
		}

		//此代理商此订单己存在
		$oRecharge = m('Recharge');
		$aRechargeCount = $oRecharge->getRechargeStatistics(0, $aData['DLS_ORDER_NUMBER'], '', 0, 0, 0, $aData['DLS_ID'], $aData['DLS_ID'], 7, 0, '');
		if($aRechargeCount > 0){
			$this->returnAlert(0, 108);
		}

		$aRechargeData = array(
			'user_id' 		=> $aUserInfo['id'],
			'type'	 		=> 1,
			'quantity' 		=> $aData['USER_MONEY'],
			'proxy_user_id' => $aData['DLS_ID'],
			'by_proxy_user_id' => $aData['DLS_ID'],
			'pay_type' 		=> 7,
			'pay_money'		=> $aData['USER_MONEY'] * $aProxyInfo['commission'],
			'serial_number' => $aData['DLS_ORDER_NUMBER'],
			'ub_finish' 	=> 1,
			'create_time' 	=> time(),
		);

		$rechargeId = $oRecharge->addRecharge($aRechargeData);
		if($rechargeId){
			$aResult = array(
				'DSL_ID' 			=> $aData['DLS_ID'],
				'DSL_ORDER_NUMBER' 	=> $aData['DLS_ORDER_NUMBER'],
				'USER_ACCOUNT' 		=> $aData['USER_ACCOUNT'],
				'USER_MONEY' 		=> $aData['USER_MONEY'],
				'UMFUN_ORDER_ID' 	=> $rechargeId,
				'DLS_ COMMISION'	=> $aData['USER_MONEY'] * (100 - $aProxyInfo['commission']),
			);
			$this->returnAlert(1, $aResult);
		}else{
			//系统暂停服务
			$this->returnAlert(0, 901);
		}
	}
}
