<?php
/**
 * 默认控制器
 * @author Administrator
 */
class AccountController{
	private $_aRechargeTypeName = array(
		1 => 'U币卡充值',
		2 => '月费卡充值',
		3 => '会员体验卡充值',
		4 => 'U币支付',
		5 => '支付宝',
		6 => '银联在线',
		7 => 'API代理商月结'
	);

	public function __construct(){}

	/*
	 *根据数字账号或邮箱获取用户另一个账号,输入邮箱则获取数字账号,输入数字账号则获取邮箱账号
	 */
	public function getUserInfoByEmailOrUserId(){
		$account = get('account');
		$getVip = intval(get('get_vip')) == 1 ? intval(get('get_vip')) : 0; // 1 0
		$oUser = m('User');

		//验证账号
		$isEmail = w('isEmail()', $account);
		$isMobile = w('isPhone()', $account);
		$getUserInfoMethod = 'getUserInfoByEmail';

		if(!$isEmail){
			$isEmail = w('isNumber(8)', $account);
			if(!$isEmail && !$isMobile){
				alert('充值帐号格式不正确！', -1);
			}
			if($isMobile){
				$getUserInfoMethod = 'getUserInfoByMobile';
			}else{
				$getUserInfoMethod = 'getUserInfoByUserId';
			}
			$isEmail = false;
		}else{
			$getUserInfoMethod = 'getUserInfoByEmail';
		}

		//读取用户信息
		$aUserInfo = $oUser->$getUserInfoMethod($account);
		if($aUserInfo === false){
			alert('抱歉，网络可能有点慢，请稍后再试', 0);
		}elseif(!$aUserInfo){
			alert('抱歉，找不到该用户', -1);
		}
		//获取用户另一种账号
		$aPersonalInfo = $oUser->getPersonalInfoByUserId($aUserInfo['id']);
		if($aPersonalInfo === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}elseif(!$aPersonalInfo){
			alert('抱歉，找不到该用户的相关信息', -1);	//有索引记录,但没有个人资料记录
		}

		$aUserNameAndAccount = array();
		$aUserNameAndAccount = array(
			'name' => substr_replace($aPersonalInfo['name'], '*', 0, 3),
			'account' => $aUserInfo['id'],
		);
		//读取Vip
		if($getVip == 1){
			$aUserVipInfo = m('UserNumerical')->getUserNumericalInfoById($aUserInfo['id']);
			if($aUserVipInfo){
				$aUserNameAndAccount = array_merge($aUserNameAndAccount, $aUserVipInfo, array(
					'fromat_date' => date('Y年m月d日', $aUserVipInfo['vip_expiration_time']),
				));
			}else{
				alert('不存在这个用户' , -1);
			}
		}

		//返回用户姓名和账号
		alert('', 1, $aUserNameAndAccount);
	}

	/*
	 *我的账户信息页面
	 */
	public function showList(){
		$aUser = checkUserLogin();
		$aUserInfo = m('User')->getUserInfoByUserId($aUser['id']);
		if(!$aUserInfo){
			alert('会员不存在', -1);
		}

		$pageHtml = '';
		$oRecharge = m('Recharge');
		$type = intval(get('type', 0));
		$page = intval(get('page', 1));
		if($page < 1){
			$page = 1;
		}
		$pageSize = 10;

		//月数充值之和
		$monthCount = $oRecharge->getUbOrMothCountByUserId($aUser['id'], 2);
		if($monthCount === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		//充值记录总数
		$aRechargeCount = $oRecharge->getRechargeStatistics(0, '', $aUser['id'], 0, 0, 0, 0, 0, 0, $type, 1);
		if($aRechargeCount === false){
			alert('网络可能有点慢，请稍后再试', 0);
		}

		$aRechargeList = array();
		if($aRechargeCount > 0){
			if($page > $tmpPage = ceil($aRechargeCount / $pageSize)){
				$page = $tmpPage;
			}
			//根据用户id和充值类型获取充值记录
			$aRechargeList = $oRecharge->getRechargeList($page, $pageSize, '`id` desc', 0, '', $aUser['id'], 0, 0, 0, 0, 0, 0, $type, 1);
			if($aRechargeList === false){
				alert('网络可能有点慢，请稍后再试', 0);
			}

			//支付方式
			if($aRechargeList){
				foreach($aRechargeList as $key => $aRechargeInfo){
					$aRechargeList[$key]['typeName'] = '';
					if(isset($this->_aRechargeTypeName[$aRechargeInfo['pay_type']])){
						$aRechargeList[$key]['typeName'] = $this->_aRechargeTypeName[$aRechargeInfo['pay_type']];
					}
				}
			}

			$aPageInfo = array(
				'url' => url('m=Account&a=showList&type=' . $type . '&page=_PAGE_'),
				'total' => $aRechargeCount,
				'size' => $pageSize,
				'page' => $page,
			);
			$pageHtml = page($aPageInfo);
		}

		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($aUser['id']);
		assign('aUserNumerical', $aUserNumerical);

		assign('type', $type);
		assign('aUser', $aUser);
		assign('aRechargeList', $aRechargeList);
		assign('pageHtml', $pageHtml);
		displayHeader('我的账户');
		display('account/info.html.php');
		displayFooter();
	}

	/*
	 *U币兑换为金币
	 */
	public function exchangeGold(){
		$aUser = checkUserLogin();
		$ub = post('ub');
		if(!preg_match('/^[0-9]*[1-9][0-9]*$/', $ub)){
			alert('U币必须为正整数', -1);
		}
		$mStudent = common\model\Student::findOne($aUser['id']);
		if(!$mStudent->getVipLevel()){
			Yii::$app->notifytion->add(\common\lib\Notifytion::NOTICE_TIPS_VIP_ACTIVATION, '只有会员才能兑换哦！立即开通会员，金币无上限，畅玩优满分！');
			alert('兑换金币失败', 0);
		}
		$oUser = m('UserNumerical');
		$aUserNum = $oUser->getUserNumericalInfoById($aUser['id']);
		if($ub > $aUserNum['ub']){
			alert('U币余额不足啦', -1);
		}

		$oUb = m('UbUsed');
		if($oUb->exchangeUbToGold($aUser['id'], $ub)){
			alert('兑换金币成功', 1, 'reload');
		}else{
			alert('兑换金币失败', 0);
		}
	}
}
