<?php
/**
 * 默认控制器
 * @author Administrator
 */
class PayController{
	private $_aAlipayConfig = array(
		'partner'		=> ALIPAY_PARTNER_ID,
		'key'			=> ALIPAY_KEY_ID,
		'sign_type'		=> 'MD5',
		'input_charset'	=> 'utf-8',
		'transport'		=> 'https',
		'cacert'		=> CACERT_PEM,
	);
	private $_userId = 0;

	public function __construct(){}

	//UB充值视图
	public function showUbPay(){
		$aUser = isLogin();
		$userId = 0;
		if($aUser){
			$userId = $aUser['id'];
		}
		assign('userId' , $userId);
		displayHeader('U币充值');
		display('pay/ub_pay.html.php');
		displayFooter();
	}

	public function showVipPay(){
		$aUser = isLogin();
		if(!$aUser){
			$this->_userId = 0;
		}else{
			$this->_userId = $aUser['id'];
		}
		$aThisUserIdAndUb = array(
			'id' => 0,
			'ub' => 0
		);
		if($this->_userId){
			$aThisUserIdAndUb = m('UserNumerical')->getUserNumericalInfoById($this->_userId);
		}
		assign('aThisUserIdAndUb', $aThisUserIdAndUb);
		assign('aGlobalsVip' , $GLOBALS['VIP']);
		displayHeader('开通会员');
		display('vip/index.html.php');
		displayFooter();
	}

	public function ubPay(){
		$account = get('account');
		$payType = get('payType');

		//验证账号
		$isNumberAccount = false;
		$isEmailAccount = w('isEmail()', $account);
		$isMobileAccount = w('isPhone()', $account);
		if(!$isEmailAccount){
			$isNumberAccount = w('isNumber(8)', $account);
			if(!$isNumberAccount && !$isMobileAccount){
				alert('请输入邮箱账号或数字账号或手机账号充值', 0);
			}
		}

		//判断是否代理商
		$isProxy = intval(get('isProxy'));
		$aProxy = array();
		if($isProxy){
			$aProxy = isProxyLogin();
			if(!$aProxy){
				alert('请先登陆', 0);
			}elseif($aProxy['status'] != 3){
				alert('抱歉，需要先通过代理商审核才能进行充值', 0);
			}
		}

		//读取用户资料
		if($isEmailAccount){
			$method = 'getUserInfoByEmail';
		}elseif($isNumberAccount){
			$method = 'getUserInfoByUserId';
		}elseif($isMobileAccount){
			$method = 'getUserInfoByMobile';
		}
		$aUser = m('User')->$method($account);
		if($aUser === false){
			alert('抱歉，读取用户数据失败');
		}elseif(!$aUser){
			alert('抱歉，找不到该用户');
		}

		//如果会员没有指定代理商ID,将代理商ID指向公司平台;如果用户代理商ID大于1,将订单分成指向该代理商
		if($aUser['proxy_id'] == 0){
			$this->_updateUserProxy($aUser['id'], $isProxy ? $aProxy['id'] : 1);
		}

		$now = time();
		if($payType == 'alipay'){
			//支付宝充值
			$ub = intval(get('ub'));
			w('range(1, 10000)', $ub) || alert('抱歉，U币的充值金额范围为1到10000', 0);
			$payMoney = $ub * ($isProxy ? $aProxy['commission'] : 100);
			$oRecharge = m('Recharge');
			$orderId = $oRecharge->addRecharge(array(
				'user_id' 			=> $aUser['id'],
				'type'				=> $oRecharge::PRODUCT_UB,
				'quantity'			=> $ub,
				'proxy_user_id'		=> $isProxy ? $aProxy['id'] : ($aUser['proxy_id'] > 1 ? $aUser['proxy_id'] : 0),
				'by_proxy_user_id'	=> $isProxy ? $aProxy['id'] : 0,
				'pay_type'			=> $oRecharge::PAY_TYPE_ALIPAY,
				'pay_money'			=> $payMoney,
				'serial_number'		=> '',
				'pay_finish'		=> 0,
				'ub_finish'			=> 0,
				'create_time' 		=> $now,
			));
			if(!$orderId){
				myLog('生成支付宝U币充值订单失败');
				alert('抱歉，系统暂时无法下单，请稍后再试', 0);
			}
			$this->_alipay($orderId, $payMoney / 100);
			//End:支付宝充值

		}elseif($payType == 'ubCard'){
			//U币充值卡充值
			$this->_cardPay($payType, $aUser, $aProxy);
		}else{
			alert('抱歉，暂不支持该充值方式', 0);
		}
	}

	private function _cardPay($payType, $aUser, $aProxy){
		$cardId = get($payType . 'No', '');
		preg_match('/^[0-9A-Z]{20}$/', $cardId) || alert('请输入正确的充值卡号格式', -1);
		$oRecharge = m('Recharge');
		//读取充值卡信息
		$method = $payType == 'ubCard' ? 'getUbRechargeCardInfoByCardId' : 'getMonthlyFeeRechargeCardInfoByCardId';
		$aCard = $oRecharge->$method($cardId);
		if($aCard === false){
			alert('抱歉，网络可能有点慢，请稍后再试！', 0);
		}elseif(!$aCard){
			alert('抱歉，该充值卡不存在', -1);
		}elseif($aCard['is_payed'] == 1){
			alert('抱歉，该充值卡己被充值', -1);
		}

		$now = time();
		$cardProductName = $payType == 'ubCard' ? 'U币' : ($payType == 'monthCard' ? '月费' : '体验');
		//读取充值卡相关批次信息
		$aBatch = $oRecharge->getBatchInfoByBatchId($aCard['batch_id']);
		if($aBatch === false){
			alert('抱歉，网络可能有点慢，请稍后再试！', 0);
		}elseif(!$aBatch){
			myLog($cardProductName . '充值卡 ' . $cardId . ' 的批次信息不存在');
			alert('抱歉，网络可能有点慢，请稍后再试！', 0);
		}elseif($payType != 'ubCard' && !(($aBatch['card_type'] == $oRecharge::CARD_EXPERIENCE && $payType == 'experienceCard') || ($aBatch['card_type'] == $oRecharge::CARD_MONTH && $payType == 'monthCard'))){
			//如果在月费卡框里输入了体验卡号,或者在体验卡框里输入了月费卡号
			alert('抱歉，您所输入的是 ' . ($payType == 'monthCard' ? '体验' : '月费') . ' 卡号，请到相应的充值卡选项卡下输入卡号进行充值', 0);
		}elseif($aBatch['is_release'] == 0){
			myLog('发现有用户买到了未发行的' . $cardProductName . '充值卡');
			alert('抱歉，该充值卡末发行', -1);
		}elseif($aBatch['is_recycle'] == 1){
			myLog('发现有用户买到了已被回收的' . $cardProductName . '充值卡');
			alert('抱歉，该充值卡己回收', -1);
		}elseif($aBatch['over_time'] <= $now){
			myLog('发现有用户买到了过期的' . $cardProductName . '充值卡');
			alert('抱歉，该充值卡己过期', -1);
		}elseif($aBatch['card_type'] == $oRecharge::CARD_EXPERIENCE){
			//检查该用户是否使用过体验卡
			$aExperienceRechargeLog = m('Recharge')->getRechargeInfoByUserIdAndPayType($aUser['id'], $oRecharge::CARD_EXPERIENCE);
			if($aExperienceRechargeLog === false){
				alert('抱歉，系统运行出错，请稍后再试！', 0);
			}elseif($aExperienceRechargeLog){
				alert('抱歉，该用户己使用过' . $cardProductName . '卡，一个用户只能充值一次' . $cardProductName . '卡', -1);
			}
		}

		$userProxyId = $aUser['proxy_id'] > 1 ? $aBatch['proxy_id'] : 0;
		$payMoney = 0;
		if($aProxy){
			$userProxyId = $aProxy['id'];

			if($aBatch['card_type'] == $oRecharge::CARD_MONTH){
				$payMoney = $aBatch['card_money'] * 75 * $aProxy['commission']/100;
			}else{
				$payMoney = $aBatch['card_money'] * $aProxy['commission'];
			}
			if($aBatch['card_type'] == $oRecharge::CARD_MONTH){
				 $payMoney *= 100;
			}elseif($aBatch['card_type'] == $oRecharge::CARD_EXPERIENCE){
				//如果是体验卡则免费
				$payMoney *= 0;
			}
		}

		$aRecharge = array(
			'user_id' 			=> $aUser['id'],
			'type'				=> $payType == 'ubCard' ? $oRecharge::PRODUCT_UB : $oRecharge::PRODUCT_TIME,
			'quantity'			=> $aBatch['card_money'],
			'proxy_user_id'		=> $aBatch['proxy_id'],
			'by_proxy_user_id'	=> $userProxyId,
			'pay_type'			=> $aBatch['card_type'],
			'pay_money'			=> $payMoney,
			'serial_number'		=> $cardId,
			'pay_finish'		=> 1,
			'ub_finish'			=> 0,
			'create_time' 		=> $now,
		);
		$orderId = $oRecharge->addRecharge($aRecharge);
		if(!$orderId){
			myLog($cardProductName . '充值卡 ' . $cardId . ' 充值时生成充值订单失败');
			alert('抱歉，网络可能有点慢，请稍后再试');
		}

		//先更新充值卡状态为已充值
		$method = $payType == 'ubCard' ? 'setUbRechargeCardById' : 'setMonthlyFeeRechargeCardById';
		$row = $oRecharge->$method(array(
			'id'		 => $aCard['id'],
			'is_payed'	 => 1,
			'payed_time' => $now,
		));
		if(!$row){
			//充值失败,充值卡数据回滚
			myLog($cardProductName . '充值卡 ' . $cardId . ' 充值失败');
			$row = $oRecharge->deleteRechargeById($orderId);	//删除已产生的订单,但不管删除成不成功
			if(!$row){
				myLog($cardProductName . '充值卡 ' . $cardId . ' 充值失败时数据回滚失败');
				email(array(
					'to' => SMTP_ACCOUNT,
					'subject' => 'UMFun充值模块出错报告',
					'name' => 'UMFun充值模块',
					'content' => '充值模块充值'. $cardProductName . '时出现异常，充值失败后回滚充值卡状态失败，请尽快排查问题！<br />卡号：' . $cardId,
				));
				alert('抱歉，系统错误！', 0);
			}
			alert('抱歉，系统运行出错，本次充值失败，请稍后再试', 0);
		}


		if($aBatch['card_type'] == $oRecharge::CARD_MONTH || $aBatch['card_type'] == $oRecharge::CARD_EXPERIENCE){
			//如果是月费充值卡或体验卡则对用户的使用时长做延续处理
			$limitTime = $oRecharge->addUserLimitTime($aUser['id'], $aBatch['card_money'], 2);
			if($limitTime === false){
				myLog($cardProductName . '充值卡 ' . $cardId . ' 充值后为用户增加使用期限失败');
				$oRecharge->deleteRechargeById($orderId);
				//充值失败,充值卡数据回滚
				$row = $oRecharge->setMonthlyFeeRechargeCardById(array(
					'id' 		 => $aCard['id'],
					'is_payed'	 => 0,
					'payed_time' => 0,
				));
				if(!$row){
					myLog($cardProductName . '充值卡 ' . $cardId . ' 充值失败时数据回滚失败');
					//邮件通知
					email(array(
						'to' => SMTP_ACCOUNT,
						'subject' => 'UMFun充值模块出错报告',
						'name' => 'UMFun充值模块',
						'content' => '充值模块充值' . $cardProductName . '时出现异常，充值失败后回滚充值卡状态失败，请尽快排查问题！<br />本地订单号：' . $orderId . '<br />卡号：' . $cardId,
					));
					alert('抱歉，系统错误！', 0);
				}
				alert('抱歉，系统运行出错，本次充值失败，请稍后再试', 0);
			}
		}elseif($aBatch['card_type'] == $oRecharge::CARD_UB){
			//UB卡充值更新用户UB
			//更新用户UB数目
			$oUserNumerical = m('UserNumerical');
			$aUserInfo = $oUserNumerical->getUserNumericalInfoById($aRecharge['user_id']);
			if($aUserInfo === false){
				alert('抱歉，系统错误！', 0);
			}
			$updateUserUb = $oUserNumerical->setUserNumerical(array(
				'id' => $aRecharge['user_id'],
				'ub' => intval($aUserInfo['ub']) + intval($aRecharge['quantity']) ,
			));

			if($updateUserUb === false){
				myLog('充值订单 ' . $orderId . ' 充值后为用户更新UB失败');
				$aRecharge['pay_finish'] = 0;
				$row = $oRecharge->setRechargeById($aRecharge);
				if($row === false){
					myLog('充值订单 ' . $orderId . ' 支付状态回滚失败');
					//邮件通知
					email(array(
						'to' => SMTP_ACCOUNT,
						'subject' => 'UMFun充值模块出错报告',
						'name' => 'UMFun充值模块',
						'content' => '充值模块通过U币卡充值 UB 时出现异常，充值失败后回滚充值卡状态失败，请尽快排查问题！<br />本地订单号:' . $orderId . '<br />支付宝流水号：' . $tradeNo,
					));
				}
				alert('抱歉，系统运行出错，本次充值失败，请稍后再试', 0);
			}
		}
		alert('充值完毕');
	}

	public function monthPay(){
		$account = get('account');
		$payType = get('payType');

		//验证账号
		$isNumberAccount = false;
		$isEmailAccount = w('isEmail()', $account);
		$isMobileAccount = w('isPhone()', $account);
		if(!$isEmailAccount){
			$isNumberAccount = w('isNumber(8)', $account);
			if(!$isNumberAccount && !$isMobileAccount){
				alert('请输入邮箱账号或数字账号或手机账号充值', 0);
			}
		}

		//判断是否代理商
		$aProxy = array();
		$isProxy = intval(get('isProxy'));
		if($isProxy){
			$aProxy = isProxyLogin();
			if(!$aProxy){
				alert('请先登陆', 0);
			}elseif($aProxy['status'] != 3){
				alert('抱歉，需要先通过代理商审核才能进行充值', 0);
			}
		}

		//读取用户资料
		if($isEmailAccount){
			$method = 'getUserInfoByEmail';
		}elseif($isNumberAccount){
			$method = 'getUserInfoByUserId';
		}elseif($isMobileAccount){
			$method = 'getUserInfoByMobile';
		}
		$aUser = m('User')->$method($account);
		if($aUser === false){
			alert('抱歉，读取用户数据失败');
		}elseif(!$aUser){
			alert('抱歉，找不到该用户');
		}

		//如果会员没有指定代理商ID,将代理商ID指向公司平台;如果用户代理商ID大于1,将订单分成指向该代理商
		if($aUser['proxy_id'] == 0){
			$this->_updateUserProxy($aUser['id'], $isProxy ? $aProxy['id'] : 1);
		}

		$now = time();
		if($payType == 'alipay'){
			//支付宝充值
			$month = intval(get('month'));
			w('_in(1,2,3,6,12,24)', $month) || alert('充值月费时长只有1、2、3、6、12、24个月，请重新选择', 0);
			$payMoney = $month * 7500;
			if($isProxy){
				if($aProxy['commission']){
					$payMoney *= $aProxy['commission'] / 100;
				}
			}
			$orderId = m('Recharge')->addRecharge(array(
				'user_id' 			=> $aUser['id'],
				'type'				=> 2,
				'quantity'			=> $month,
				'proxy_user_id'		=> $isProxy ? $aProxy['id'] : ($aUser['proxy_id'] > 1 ? $aUser['proxy_id'] : 0),
				'by_proxy_user_id'	=> $isProxy ? $aProxy['id'] : 0,
				'pay_type'			=> 5,
				'pay_money'			=> $payMoney,
				'serial_number'		=> '',
				'ub_finish'			=> 0,
				'create_time' 		=> $now,
			));
			if(!$orderId){
				myLog('生成支付宝U币充值订单失败');
				alert('抱歉，系统暂时无法下单，请稍后再试', 0);
			}
			$this->_alipay($orderId, $payMoney / 100);
			//End:支付宝充值

		}elseif($payType == 'monthCard' || $payType == 'experienceCard'){
			//月费卡和体验卡充值
			$this->_cardPay($payType, $aUser, $aProxy);
		}else{
			alert('抱歉，暂不支持该充值方式', 0);
		}
	}

	//月费充值视图
	public function showMonthPay(){
		displayHeader('月费充值');
		display('pay/month_pay.html.php');
		displayFooter();
	}

	/**
	 * 更新用户代理商ID
	 * @param type $userId
	 * @param type $proxyId
	 */
	private function _updateUserProxy($userId, $proxyId){
		$aUserData = array(
			'id' => $userId,
			'proxy_id' => $proxyId,
		);
		$setRow = m('User')->setUserIndexInfo($aUserData);
		if($setRow === false){
			myLog('更新用户代理商为官方代理商时发生');
		}
	}

	//支付宝支付
	private function _alipay($orderId, $orderMoney){
		echo '处理中，请稍候...';
		$orderName = '广州新宜讯网络科技有限公司即时充值｜充值金额 RMB ' . $orderMoney . ' 元';
		$orderDesc = '广州新宜讯网络科技有限公司即时充值｜充值金额 RMB ' . $orderMoney . ' 元';
		$orderUrl = '';
		$unFishKey = '';
		$clientIp = '';
		$notifyUrl = url('m=Pay&a=notifyAfterPay');
		$returnUrl = url('m=Pay&a=successJump&id=' . $orderId);

		//构造要请求的参数数组
		$aParam = array(
			'payment_type'		=> 1,
			'notify_url'		=> $notifyUrl,
			'return_url'		=> $returnUrl,
			'seller_email'		=> 'umfun@vip.qq.com',
			'out_trade_no'		=> $orderId,
			'subject'			=> $orderName,
			'total_fee'			=> $orderMoney,//-------订单金额
			'body'				=> $orderDesc,
			'show_url'			=> $orderUrl,
			'anti_phishing_key'	=> $unFishKey,
			'exter_invoke_ip'	=> $clientIp,
			'service' 			=> 'create_direct_pay_by_user',
			'partner' 			=> $this->_aAlipayConfig['partner'],
			'_input_charset'	=> $this->_aAlipayConfig['input_charset'],
		);
		$alipay = new Alipay($this->_aAlipayConfig);
		$htmlText = $alipay->buildRequestForm($aParam, 'post', '确认');
		echo $htmlText;
	}

	/**
	 *    VIp充值方法
	 */
	public function vipPay(){
		$account = (string)post('account');
		$vipType = intval(post('vipType', 0));
		$dateType = intval(post('dateType'));
		$month = intval(post('month'));
		$payPrice = 0;
		$payType = post('payType');

		if(!in_array($dateType, [0, 1, 2])){
			alert('无效的充值时长', -1);
		}

		if($dateType == 1 && ($month >= 100 || $month <= 0)){
			alert('年费会员更优惠喔', -1);
		}

		if(($vipType > 3 || $vipType < 0) || ($payType != 'ubpay' && $payType != 'alipay')){
			alert('请认勿非法提交', -1);
		}

		//验证账号
		$isNumberAccount = false;
		$isEmailAccount = w('isEmail()', $account);
		$isMobileAccount = w('isPhone()', $account);
		if(!$isEmailAccount){
			$isNumberAccount = w('isNumber(8)', $account);
			if(!$isNumberAccount && !$isMobileAccount){
				alert('请输入邮箱账号或数字账号或手机账号充值', -1);
			}
		}

		//读取用户资料
		if($isEmailAccount){
			$method = 'getUserInfoByEmail';
		}elseif($isNumberAccount){
			$method = 'getUserInfoByUserId';
		}elseif($isMobileAccount){
			$method = 'getUserInfoByMobile';
		}
		$aUser = m('User')->$method($account);
		if($aUser === false){
			alert('抱歉，读取用户数据失败', 0);
		}elseif(!$aUser){
			alert('抱歉，找不到该用户', -1);
		}

		$oUserNumerical = m('UserNumerical');
		$aVipInfo = $oUserNumerical->getUserNumericalInfoById($aUser['id']);
		if($aVipInfo === false){
			alert('读取该用户时出错', -1);
		}elseif(!$aVipInfo){
			alert('没有找到该用户', -1);
		}

		//*****价格计算*****
		$now = time();
		if($vipType > $aVipInfo['vip'] && $aVipInfo['vip'] != 0){
			//升级
			$payPrice = ceil(($aVipInfo['vip_expiration_time'] - $now) / 86400 / 30 *
				($GLOBALS['VIP'][$vipType]['month_price'] - $GLOBALS['VIP'][$aVipInfo['vip']]['month_price']));
		}else{
			//续费 + 开通
			$payPrice = $GLOBALS['VIP'][$vipType]['month_price'] * $month;
			if(!$dateType){
				$payPrice = $GLOBALS['VIP'][$vipType]['year_price'];
			}elseif($dateType == 2){
				$payPrice = 55;
			}
		}

		//重新调整写入数据库的会员类型
		$aFormatVipType = array(
			1 => RechargeModel::PRODUCT_VIP1,
			2 => RechargeModel::PRODUCT_VIP2,
			3 => RechargeModel::PRODUCT_VIP3,
		);
		$vipType = $aFormatVipType[$vipType];
		$oRecharge = m('Recharge');
		//$payPrice = 0.01;	//测试付款时的金额
		if($payType == 'alipay'){
			//支付宝充值
			$orderId = $oRecharge->addRecharge(array(
				'user_id' 			=> $aUser['id'],
				'type'				=> $vipType,
				'quantity'			=> $dateType == 1 ? $month : 12, //计算月 否则是年
				'proxy_user_id'		=> 0,
				'by_proxy_user_id'	=> 0,
				'pay_type'			=> $oRecharge::PAY_TYPE_ALIPAY,
				'pay_money'			=> $payPrice,
				'serial_number'		=> '',
				'pay_finish'		=> 0,
				'ub_finish'			=> 0,
				'create_time' 		=> $now
			));
			if(!$orderId){
				myLog('生成支付宝会员充值订单失败');
				alert('抱歉，系统暂时无法下单，请稍后再试', 0);
			}

			$this->_alipay($orderId, $payPrice);
			//End:支付宝充值
		}elseif($payType == 'ubpay'){
			//U币充值
			$orderId = $oRecharge->addRecharge(array(
				'user_id' 			=> $aUser['id'],
				'type'				=> $vipType,  // 会员类型 3普通 4白金 5砖石
				'quantity'			=> $dateType == 1 ? $month : 12, //计算月 否则是年
				'proxy_user_id'		=> 0,
				'by_proxy_user_id'	=> 0,
				'pay_type'			=> $oRecharge::PAY_TYPE_UB,
				'pay_money'			=> $payPrice,
				'serial_number'		=> '',
				'pay_finish'		=> 0,
				'ub_finish'			=> 0,
				'create_time' 		=> $now
			));
			if(!$orderId){
				myLog('生成UB支付充值订单失败');
				alert('抱歉，系统暂时无法下单，请稍后再试', 0);
			}
			$this->_ubPay($orderId);
		}else{
			alert('抱歉，暂不支持该充值方式', -1);
		}
	}

	//Ub支付
	private function _ubPay($orderId){
		$aUser = isLogin();
		if(!$aUser){
			alert('很抱歉，您尚未登录，请登录后再操作', -1);
		}
		$this->_userId = $aUser['id'];
		//VIP类别回转
		$aFormatVipType = array(
			3 => 1,
			4 => 2,
			5 => 3
		);
		//开始更新订单状态
		$oRecharge = m('Recharge');
		$aRecharge = $oRecharge->getRechargeInfoById($orderId);
		if($aRecharge === false){
			myLog('ub读取充值订单 ' . $orderId . ' 的充值记录失败，数据库出现异常');
			alert('无法读取该订单', 0);
		}elseif(!$aRecharge){
			myLog('ub找不到充值订单 ' . $orderId . ' 的充值记录');
			alert('无该订单', -1);
		}

		$oUserNumerical = m('UserNumerical');
		$aVipInfo = $oUserNumerical->getUserNumericalInfoById($aRecharge['user_id']);
		$aThisInfo = $oUserNumerical->getUserNumericalInfoById($this->_userId);
		if($aThisInfo === false){
			myLog('Ub在读取当前用户数据失败');
			alert('读取当前付款用户错误', 0);
		}
		if($aVipInfo === false){
			myLog('支付成功后读取用户失败');
			alert('数据更新失败', -1);
		}

		if($aThisInfo['ub'] >= $aRecharge['pay_money']){
			$updateThisUser = $oUserNumerical->setUserNumerical(array(
				'id' => $this->_userId,
				'ub' => $aThisInfo['ub'] - $aRecharge['pay_money']
			));
			if(!$updateThisUser){
				myLog('Ub订单'. $orderId .'在扣取当前用户UB时读取数据失败' . $updateThisUser);
				alert('UB付款失败', 0, $updateThisUser);
			}
		}else{
			alert('用户UB不足无法完成付款', -1);
		}

		$aRecharge['ub_finish'] =  1;
		$oRecharge->setRechargeById($aRecharge);
		myLog('ub更新付款状态已经成功');
		if($oRecharge === false){
			myLog('ub更新充值订单 ' . $orderId . ' 的充值记录状态失败');
			alert('数据更新失败', 0);
		}

		//计算到期时间 [
		$now = time();
		$payTipsText = '操作完成！';
		if($aVipInfo['vip_expiration_time'] == 0 || $aVipInfo['vip_expiration_time'] < $now){
			//未开通过的 普通用户 与 过期 的用户 设置 时间
			$expirationTime = strtotime('+' . $aRecharge['quantity'] . ' month');
			$payTipsText = '开通会员成功！';
		}else{
			//还未过期的用户
			//会员等级相等的情况则续费
			if($aFormatVipType[$aRecharge['type']] == $aVipInfo['vip']){
				$expirationTime = $aVipInfo['vip_expiration_time'] - $now + strtotime('+' . $aRecharge['quantity'] . ' month');
				$payTipsText = '续费会员成功！';
			}elseif($aFormatVipType[$aRecharge['type']] > $aVipInfo['vip']){
				//会员等级升级
				$expirationTime = $aVipInfo['vip_expiration_time'];
				$payTipsText = '升级会员成功！';
			}
		}
		//计算到期时间 ]

		//更新用户到期时间 [
		myLog('开始更新用户数据');
		$updateVipTime = $oUserNumerical->setUserNumerical(array(
			'id' => $aRecharge['user_id'],
			'vip' => $aFormatVipType[$aRecharge['type']] ,
			'vip_expiration_time' => $expirationTime
		));
		if($updateVipTime === false){
			myLog('充值订单 ' . $orderId . ' 充值后为更新会员等级和过期时间失败');
			$aRecharge['ub_finish'] = 0;
			$row = $oRecharge->setRechargeById($aRecharge);
			if($row === false){
				myLog('充值订单 ' . $orderId . ' 支付状态回滚失败');
			}
			alert('更新过期时间失败', 0);
		}

		//新版写事件
		$this->_addBecomeVipEvent($aFormatVipType[$aRecharge['type']]);

		// ]更新用户到期时间
		alert('恭喜！' . $payTipsText, 1);
	}


	/**
	 * 显示支付成功页面
	 */
	public function showSuccess(){
		$id = intval(get('id', 0));
		$headerType = '充值首页';
		$menu = 'UbPay';
		$oRecharge = m('Recharge');
		$aRechargeInfo = $oRecharge->getRechargeInfoById($id);
		if($aRechargeInfo){
			if($aRechargeInfo['type'] == $oRecharge::PRODUCT_UB){
				$headerType = 'U币充值结果';
			}elseif($aRechargeInfo['type'] == $oRecharge::PRODUCT_TIME){
				$menu = 'MonthPay';
				$headerType = '月费充值结果';
			}
		}
		assign('menu', $menu);
		assign('aRechargeInfo', $aRechargeInfo);
		displayHeader($headerType);
		display('pay/pay_result.html.php');
		displayFooter();
	}

	/**
	 * 支付成功后跳转页面
	 */
	public function successJump(){
		$id = intval(get('id', 0));
		header('LOCATION:' . url('m=Pay&a=showSuccess&id=' . $id));
	}

	//支付宝支付成功后异步通知页面
	public function notifyAfterPay(){
		$alipayNotify = new AlipayNotify($this->_aAlipayConfig);
		$verifyResult = $alipayNotify->verifyNotify();
		$successFlag = 'success';
		$failFlag = 'fail';
		if($verifyResult){
			//验证成功
			$orderStatus = post('trade_status');
			$orderId = post('out_trade_no');
			$tradeNo = post('trade_no');
			if($orderStatus == 'TRADE_SUCCESS'){
				//成功,更新订单状态
				$oRecharge = m('Recharge');
				$aRecharge = $oRecharge->getRechargeInfoById($orderId);
				if($aRecharge === false){
					myLog('读取充值订单 ' . $orderId . ' 的充值记录失败，数据库出现异常');
					exit($failFlag);
				}elseif(!$aRecharge){
					myLog('找不到充值订单 ' . $orderId . ' 的充值记录');
					exit($failFlag);
				}
				$aRecharge['serial_number'] = $tradeNo;
				$aRecharge['pay_finish'] =  1;
				$oRecharge->setRechargeById($aRecharge);
				if($oRecharge === false){
					myLog('更新充值订单 ' . $orderId . ' 的充值记录状态失败');
					exit($failFlag);
				}

				// 数据流程更新开始 [
				$oUserNumerical = m('UserNumerical');
				$aVipInfo = $oUserNumerical->getUserNumericalInfoById($aRecharge['user_id']);
				if($aVipInfo === false){
					myLog('异步通知数据库读取用户失败');
					exit($failFlag);
				}

				//月费卡更新用户到期时间
				if($aRecharge['type'] == $oRecharge::PAY_TYPE_MONTH_CARD){
					$limitTime = $oRecharge->addUserLimitTime($aRecharge['user_id'], $aRecharge['quantity'], 2);
					if($limitTime === false){
						myLog('充值订单 ' . $orderId . ' 充值后为用户增加使用期限失败');
						$aRecharge['pay_finish'] = 0;
						$row = $oRecharge->setRechargeById($aRecharge);
						if($row === false){
							myLog('充值订单 ' . $orderId . ' 支付状态回滚失败');
							//邮件通知
							email(array(
								'to' => SMTP_ACCOUNT,
								'subject' => 'UMFun充值模块出错报告',
								'name' => 'UMFun充值模块',
								'content' => '充值模块通过支付宝充值' . ($aRecharge['type'] == $oRecharge::PRODUCT_UB ? 'U币' : '月费') . '时出现异常，充值失败后回滚充值卡状态失败，请尽快排查问题！<br />本地订单号:' . $orderId . '<br />支付宝流水号：' . $tradeNo,
							));
						}
						exit($failFlag);
					}
				}
				//支付宝充值UB
				elseif($aRecharge['type'] == $oRecharge::PRODUCT_UB){
					//更新用户UB数目
					$updateUserUb = $oUserNumerical->setUserNumerical(array(
						'id' => $aRecharge['user_id'],
						'ub' => intval($aVipInfo['ub']) + intval($aRecharge['quantity']) ,
					));

					if($updateUserUb === false){
						myLog('充值订单 ' . $orderId . ' 充值后为用户更新UB失败');
						$aRecharge['pay_finish'] = 0;
						$row = $oRecharge->setRechargeById($aRecharge);
						if($row === false){
							myLog('充值订单 ' . $orderId . ' 支付状态回滚失败');
							//邮件通知
							email(array(
								'to' => SMTP_ACCOUNT,
								'subject' => 'UMFun充值模块出错报告',
								'name' => 'UMFun充值模块',
								'content' => '充值模块通过支付宝充值 UB 时出现异常，充值失败后回滚充值卡状态失败，请尽快排查问题！<br />本地订单号:' . $orderId . '<br />支付宝流水号：' . $tradeNo,
							));
						}
						exit($failFlag);
					}
				}
				//直接付款开通会员
				elseif($aRecharge['type'] < 6 && $aRecharge['type'] > 2){

					//VIP类别回转
					$aFormatVipType = array(
						3 => 1,
						4 => 2,
						5 => 3
					);
					$now = time();
					if($aVipInfo['vip_expiration_time'] == 0 || $aVipInfo['vip_expiration_time'] < $now){
						//开通设置时间
						$expirationTime = strtotime('+' . $aRecharge['quantity'] . ' month');
					}else{
						//续费,会员等级相等的情况则增加时间
						if($aFormatVipType[$aRecharge['type']] == $aVipInfo['vip']){
							$expirationTime =  $aVipInfo['vip_expiration_time'] - $now + strtotime('+' . $aRecharge['quantity'] . ' month');
						}elseif($aFormatVipType[$aRecharge['type']] > $aVipInfo['vip']){
							//会员等级升级
							$expirationTime = $aVipInfo['vip_expiration_time'];
						}
					}

					//更新用户到期时间 [
					$updateVipTime = $oUserNumerical->setUserNumerical(array(
						'id' => $aRecharge['user_id'],
						'vip' => $aFormatVipType[$aRecharge['type']] ,
						'vip_expiration_time' => $expirationTime
					));
					if($updateVipTime === false){
						myLog('充值订单 ' . $orderId . ' 充值后为更新会员等级和过期时间失败');
						$aRecharge['pay_finish'] = 0;
						$row = $oRecharge->setRechargeById($aRecharge);
						if($row === false){
							myLog('充值订单 ' . $orderId . ' 支付状态回滚失败');
							if($aRecharge['type'] == 3){
								$vipTypeName = $GLOBALS['VIP'][1]['name'];
							}elseif($aRecharge['type'] == 4 ){
								$vipTypeName = $GLOBALS['VIP'][2]['name'];
							}elseif($aRecharge['type'] == 5 ){
								$vipTypeName = $GLOBALS['VIP'][3]['name'];
							}
							//邮件通知
							email(array(
								'to' => SMTP_ACCOUNT,
								'subject' => 'UMFun充值模块出错报告',
								'name' => 'UMFun充值模块',
								'content' => '充值模块通过支付宝充值' . $vipTypeName . '时出现异常，充值失败后回滚充值卡状态失败，请尽快排查问题！<br />本地订单号:' . $orderId . '<br />支付宝流水号：' . $tradeNo,
							));
						}
						exit($failFlag);
					}// ]更新用户到期时间
					//新版写事件
					$this->_addBecomeVipEvent($aFormatVipType[$aRecharge['type']]);
				}else{
					exit($failFlag);
				}// ] 数据更新流程结束

			}
			exit($successFlag);
		}else{
			exit($failFlag);
		}
	}

	private function _addBecomeVipEvent($vipLevel){
		$aEventData = array(
			'user_id'	=>	$this->_userId,
			'type'		=> 36,
			'data_id'	=>	0,
			'data'		=>	array(
				'vip_level' => $vipLevel,
				'create_time' => time()
			)
		);
		$oSnsEvent = m('SnsEvent');
		$oSnsEvent->addEvent($aEventData);
		//是否首次充值VIP---首次充值送金币，写动态
		$aWhere = [
			'and',
			['user_id' => $this->_userId],
			['type' => RechargeModel::PRODUCT_VIP3],
			[
				'or',
				['pay_finish' => 1],
				['ub_finish' => 1],
			],
		];
		$payVipSuccessCount = (new \umeworld\lib\Query())->from(\common\model\Recharge::tableName())->where($aWhere)->count();
		if($payVipSuccessCount <= 1 && $this->_userId){
			//为用户加金币
			$mStudent = \common\model\Student::findOne($this->_userId);
			$addMoney = 30;
			$mStudent->addCurrency($addMoney, \common\model\UserNumerical::CURRENCY_SCENE_FIRST_RECHARGE_VIP);
			//写动态
			$aData = [
				'type' => \common\model\Event::FIRST_RECHARGE_VIP,
				'user_id' => $mStudent->id,
				'data_id' => 0,
				'data' => [
					'get_gold' => $addMoney,
					'create_time' => NOW_TIME,
				]
			];
			\common\model\Event::add($aData);
		}
	}
}