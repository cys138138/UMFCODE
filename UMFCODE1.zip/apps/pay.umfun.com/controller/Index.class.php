<?php
class IndexController{
	public function __construct(){}

	public function index(){
		displayHeader();
		display('index/index.html.php');
		displayFooter();
	}
}