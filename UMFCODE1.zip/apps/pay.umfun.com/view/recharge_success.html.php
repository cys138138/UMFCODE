<style>
.container { width:980px; margin:20px auto; }

/* 充值成功 */
.payment_success { width:400px; min-height:200px; border:1px solid #ddd; margin:0 auto; line-height:30px; text-align:center; font-size:20px; padding:50px 20px; border-radius:5px; box-shadow:1px 1px 5px #ddd; }
.payment_success .link { display:block; color:#0553A9; margin-top:20px; }
.payment_success b { color:#f60; }

</style>
<div class="container">
    <div class="payment_success">
    	
        恭喜您，<b>充值成功！</b><br>
        <a href="/?m=Index&a=RechargeList&uid=<?php echo $userId;?>" class="link">查看充值记录</a>
    </div>
</div>