<style>
body,ul,ol,li,h1,h2,h3,h4,h5,h6,p,img { margin:0; padding:0; }
body { font:12px/18px Microsoft YaHei,Arial; color:#555; }
a { color:#555; text-decoration:none; }
a:hover { text-decoration:underline; }
ul,ol { list-style:none; }
input,textarea { outline:none; }
table { border-collapse:collapse; border-spacing:0; }
.container { width:980px; margin:20px auto; }

.payment_record { font-size:14px; }
.record_list { width:100%; border-top:1px solid #ddd; border-left:1px solid #ddd; }
.record_list td { border-right:1px solid #ddd; border-bottom:1px solid #ddd; padding:6px 10px; }
.record_list thead td { background-color:#f5f5f5; font-weight:bold; }
.record_list tbody tr:hover td { background-color:#FEFAED; }
.record_list tbody tr:nth-of-type(even) { background-color:#f9f9f9; }
.page { padding:20px 2px; text-align:right; }
.no_data{color:red;text-align:center;}

</style>
<div class="container">

	<h2 class="title">充值记录</h2>
    <div class="payment_record">
    	<table class="record_list">
        	<thead>
            	<tr>
            		<td>流水账号</td>
            		<td>充值时间</td>
            		<td>支付方式</td>
            		<td>充值金额</td>
            		<td>状态</td>
            	</tr>
            </thead>
            <tbody>
            <?php 
            	if($aRechargeList){
            		foreach($aRechargeList as $key=>$rechargeInfo){
            ?>
            	<tr>
            		<td><?php echo $rechargeInfo['serial_number'];?></td>
            		<td><?php if($rechargeInfo['create_time']){echo date('Y-m-d H:i:s',$rechargeInfo['create_time']);}?></td>
            		<td><?php if($rechargeInfo['pay_type'] == 1){echo '支付宝';}elseif($rechargeInfo['pay_type'] == 2){echo '银联';}?></td>
            		<td><?php echo $rechargeInfo['money'] . 'U币';?></td>
            		<td><?php if($rechargeInfo['is_finish'] == 1){echo  '成功';}?></td>
            	</tr>
            <?php 
            	}
			}else{
			?>
				<tr>
            		<td colspan="5" class="no_data">暂无数据</td>
            	</tr>
			<?php	
				}
            ?>	

            </tbody>
        </table>
        <div class="page">
        	<?php echo $pageHtml;?>
        </div>
    </div>

</div>