<!--主体 [-->
<div class="main pay_main">
	<div class="pay_main_bg"></div>
	<div class="column c">

		<div class="pay_sidebar">
			<div class="pay_sidebar_mod">
				<h3 class="pay_sidebar_title">
					<em>会员充值</em>
					<i class="pay_icon icon_pay_title_ucoin"></i>
				</h3>
				<div class="pay_sidebar_info">
					<?php for($i = 3; $i <= 3; $i++){
						echo '<p>' . $aGlobalsVip[$i]['name'] . '  ' . $aGlobalsVip[$i]['month_price'] . '/月</p>';
					} ?>
				</div>
			</div>
			<div class="pay_sidebar_mod">
				<h3 class="pay_sidebar_title">
					<em>支付合作</em>
					<i class="pay_icon icon_pay_title_cooperation"></i>
				</h3>
				<div class="pay_sidebar_cooperation">
					<i class="pay_icon icon_sidebar_unlon"></i>
					<span class="line"></span>
					<i class="pay_icon icon_sidebar_alipay"></i>
				</div>
			</div>
		</div>


		<div class="pay_content">
			<div class="pay_member">
			<form id="payForm" class="payForm" action="<?php echo url('m=Pay&a=vipPay'); ?>" method="POST" target="_blank">
				<div class="item c">
					<label for="account" class="name">充值帐号：</label>
					<div class="controls" id="Recharge">
						<input class="text" type="text" name="account" id="account" value="<?php echo $aThisUserIdAndUb['id'] ? $aThisUserIdAndUb['id'] : '';?>"/>
						<span></span>
					</div>
					<div class="pay_tips" id="payTips"><i class="pay_icon icon_pay_tips"></i>请填写用户ID或手机、邮件。</div>
				</div>

				<div class="item c" style="display:none;">
					<label for="" class="name">会员类型:</label>
					<div class="controls">

						<div id="vipTypeChange" class="type">
							<input type="hidden" name="vipType" id="vipType" value="0" />
							<?php //for($i = 3; $i <= 3; $i++){ ?>
								<!--a class="option" href="javascript:;" data-viptype="<?php //echo $i; ?>">
									<?php //if($i == 2){ ?>
										<i class="pay_icon icon_pay_rec"></i>
									<?php //} ?>
									<span><?php //echo $aGlobalsVip[$i]['name'];?></span>
									<i class="pay_icon icon_pay_selected"></i>
								</a-->
							<?php //} ?>
							<a class="option selected" href="javascript:;" data-viptype="3">
								<span><?php echo $aGlobalsVip[3]['name'];?></span>
								<i class="pay_icon icon_pay_selected"></i>
							</a>
						</div>
					</div>
				</div>

				<div class="item c" id="payTimeType">
					<label class="name">开通时长:</label>
					<div class="controls">

						<div class="type" id="dateTypeChange">
							<span class="option">
								年费<span id="yearPrice" data-dateprice="0" data-datetype="0">0</span>元<em>（原价：<span id="yearOldPrice">0</span>）</em>
								<i class="pay_icon icon_pay_selected"></i>
							</span>
							<span class="option">
								半年<span id="halfYearPrice" data-dateprice="0" data-datetype="2">0</span>元<em>（原价：<span id="halfYearOldPrice">0</span>）</em>
								<i class="pay_icon icon_pay_selected"></i>
							</span>
							<span class="option">
								按月  <input type="text" value="3" maxlength="2" id="month" name="month"/>	个月	<span id="monthPrice" data-dateprice="0" data-onemonthprice="0" data-datetype="1">0</span>元
								<i class="pay_icon icon_pay_selected"></i>
							</span>

						</div>
						<p class="prompt">按年付费更加优惠喔</p>
					</div>
				<input type="hidden" name="vipDatePrice" id="vipDatePrice" value="0" data-datetype="1"/>
				</div>

				<div class="item c">
					<label class="name"></label>
					<div class="pay_tips" style="display: none;" id="payTimeTypeTips">
						<i class="pay_icon icon_pay_tips"></i>年费更加优惠
					</div>
				</div>


				<div class="item c">
					<label for="" class="name">支付方式：</label>
					<div class="controls">
						<ul id="pay_select" class="pay_select">
							<li class="cur" data-paytype="alipay">支付宝在线支付</li>
							<li data-paytype="ubpay">U币充值</li>
						</ul>
						<ul id="pay_panel" class="pay_panel">
							<li class="pay_alipay">
								<div class="pay_tips"><i class="pay_icon icon_pay_tips"></i>支付宝在线支付，可使用支付宝余额或银行卡快捷支付，方便快捷。</div>
								<div class="pay_tips_info">
									<a href="#"><i class="pay_icon icon_tips_alipay"></i></a>
								</div>
							</li>
							<li class="pay_card">
								<div class="pay_tips"><i class="pay_icon icon_pay_tips"></i>
								<?php if($aThisUserIdAndUb['id']){ ?>
									您当前可用U币余额为 <span id="userUb"> <?php echo $aThisUserIdAndUb['ub'];?></span> ( 1元 = 1UB )
								<?php }else{ ?>
									点击<a href="<?php echo Yii::$app->urlManagerLogin->createUrl(['login/show-pc-login']); ?>" >【登录】</a>后即可可使用UB付款
								<?php } ?>
								</div>
								<div class="pay_tips_info">
									<div class="controls"></div>
								</div>
							</li>
						</ul>
					</div>
				</div>


				<div class="item c">
					<label for="" class="name">应付金额：</label>
					<div class="controls">
						<div class="money">
							<span class="pay_fee" id="pay_fee">0</span> 元
						</div>
					</div>
				</div>
				<div class="item c">
					<input type="hidden" id="dateType" name="dateType" value="1" />
					<input type="hidden" id="payType" name="payType" value="alipay" />
					<label for="payButton" class="name"></label>
					<img id="doing" class="doing" src="<?php echo SYSTEM_RESOURCE_URL; ?>view/image/doing.gif" width="32" height="32" />
					<div class="controls"><input type="button" id="payButton" name="payButton" value="立即支付" class="icon btn_blue"/></div>
				</div>
			</div>
		</div>
		</form>
	</div>
</div>
<!--充值弹窗 [-->
<div id="mask" class="mask"></div>
<div id="pay_pop" class="pay_pop">
    <div class="hd">
        <h2>网上充值</h2>
        <a id="pay_pop_close" class="pay_pop_close" title="关闭">×</a>
    </div>
    <div class="info">
        <div class="tips">请在新开网银页面完成充值后选择：</div>
        <div class="pay_succ"><b>充值成功</b> ｜ 您可以选择： <a href="<?php echo url('m=Account&a=showList'); ?>">查看充值记录</a></div>
        <div class="pay_fail"><b>充值失败 </b> ｜ 建议您选择其他充值方式</div>
    </div>
</div>
<!--充值弹窗 ]-->
<!--主体 ]-->

<script type="text/javascript">
var userVipInfo = [],
	isLogin = <?php echo $aThisUserIdAndUb['id'] ? 1 : 0;?>,
	nowTime = parseInt($.now() /1000);
heighlightMenu('Vip');
$('#account').val().length > 4 ? getAccount($('#account').val()) : '';


$(function(){
	thisUserUb = <?php echo $aThisUserIdAndUb['ub'];?>;
    changeVipTypePrice(3);
	//用户填写交互
	$("#account").focus(function(){
		$('#payTips').html('<i class="pay_icon icon_pay_tips"></i>请填写用户ID或手机、邮件。');
		$('#Recharge span').text('');
		//resetFrom();
		$('#account').select();
	}).blur(function(){
		if($('#account').val().length < 5 ){
			return false;
		}
		getAccount($('#account').val());
	});

	//选择会员类型
	$('#vipTypeChange a').click(function(){
		var self = $(this),
			thisVipType = self.attr('data-viptype');
		if($('#account').val().length < 5){
			UBox.show('请填写账号后再选择', -1);
			return false;
		}
		if(thisVipType < userVipInfo.vip && userVipInfo.vip_expiration_time > nowTime && userVipInfo.vip != 0){
			UBox.show('请重选择可用会员类型', -1);
			return false;
		}
		self.siblings().removeClass('selected').end().addClass('selected');

		/*if(userVipInfo.vip != 0 && thisVipType > userVipInfo.vip && userVipInfo.vip_expiration_time > nowTime){
			$('#payTimeType').css('display', 'none');
			$('#payTimeTypeTips')
				.css('display', 'block')
				.html(
					'<i class="pay_icon icon_pay_tips"></i><b>'+
					fromatVip(userVipInfo.vip) +
					'</b>剩余 :' + Math.ceil((userVipInfo.vip_expiration_time - nowTime) / 86400) + '天升级为'+
					self.text()
				);
		}else{
			$('#payTimeType').css('display', 'block');
			$('#payTimeTypeTips').css('display', 'none');
		}*/

		$('#vipType').val(thisVipType);
		changeVipTypePrice(thisVipType);
	});

	//充值日期类型
	$('#dateTypeChange span').click(function(){
		if($('#vipTypeChange a.selected').length <= 0){
			UBox.show('请优先选择会员类型', -1);
			return false;
		}
		$(this).addClass('selected').siblings().removeClass('selected');

		$('#vipDatePrice')
			.val($(this).find('span:first').attr('data-onemonthprice') * $('#month').val())
			.attr('data-datetype', $(this).find('span:first').attr('data-datetype'));
		$('#dateType')
			.val($('#vipDatePrice').attr('data-datetype'));
		changeVipTypePrice($('#vipTypeChange a.selected').attr('data-viptype'));
	});

	//实时绑定月份价格变动
	$('#month').keyup(function(){
		if(this.value == 0 || this.value < 0 || this.value >= 100 || !$.isNumeric($(this).val())){
			$(this).val('');
		}else{
			$('#monthPrice')
				.text($('#monthPrice').attr('data-onemonthprice') * $('#month').val())
				.attr('data-dateprice', $('#monthPrice').text());
			$('#vipDatePrice').val($('#monthPrice').text());
			$('#pay_fee').text($('#vipDatePrice').val());
		}
	});

	//用户ub
	$('#pay_select li').click(function(){
		$('#payType').val($(this).attr("data-paytype"));
		if(parseInt(thisUserUb) < parseInt($('#pay_fee').text())){
			if($('#payType').val() == 'ubpay'){
				//$('#payButton').attr('disabled','disabled');
			}
		}else{
			$('#payButton').removeAttr('disabled');
		}
	});

	$('#payButton').click(function(){
		if(!checkForm()){
			return false;
		}

		var oPayForm = $('#payForm') , payType = $('#payType').val() , oDoing = $('#doing');
		if($.inArray(payType, ['alipay']) != -1){
			oPayForm.submit();
			$('#mask').height($('body').height()).show();
			$('#pay_pop').show();
		}else if(payType == 'ubpay'){
			$.ajax({
				url : '<?php echo url('m=Pay&a=vipPay'); ?>',
				data: oPayForm.serialize(),
				type : 'post',
				dataType : 'json',
				beforeSend : function(){
					oDoing.show();
				},
				complete : function(){
					oDoing.hide();
				},
				success : function(aResult){
					UBox.show(aResult.msg, aResult.status, '', 10);
					if(aResult.status == 1){
						//尚未处理功能
						resetFrom();
						$('#vipTypeChange a').click();
						//$('#mask').height($('body').height()).show();
						//$('#pay_pop').show();
					}
				}
			});
		}
	});

	<?php if(!Yii::$app->student->isGuest){ ?>
		$('#vipTypeChange a').click();
	<?php } ?>
});

function getAccount(account){

	$.get('<?php echo  url('m=Account&a=getUserInfoByEmailOrUserId&account=_account&get_vip=_getvip'); ?>'.replace('_account', account).replace('_getvip', 1),
		function(aResult) {
			userVipInfo = aResult.data;
			if(aResult.status == 1){
				var surplusTime = parseInt(aResult.data.vip_expiration_time) - parseInt($.now() /1000);
				$('#Recharge span')
					.text(aResult.data.name + '(' + aResult.data.id.substr(0,5) + '***)')
					.css('color', ' #999;');
				if( surplusTime > 0){
					$('#payTips').html('您是<b>' + fromatVip(aResult.data.vip) + '</b>，到期时间为：' + aResult.data.fromat_date);
				}else{
					$('#payTips').html('<i class="pay_icon icon_pay_tips"></i>您不是VIP会员。');
					$('#vipTypeChange a:first').css('display','block');
				}
			}else{
				$('#payTips').html('<i class="pay_icon icon_pay_tips"></i>' + aResult.msg);
			}
		});
}

function changeVipTypePrice(typeId){
	var monthPrice = 0,
		yearPrice = 0;

			monthPrice = <?php echo $aGlobalsVip[3]['month_price'];?>;
			yearPrice  = <?php echo $aGlobalsVip[3]['year_price'];?>;
	/*switch(parseInt(typeId)){
		case 1:
			monthPrice = <?php echo $aGlobalsVip[1]['month_price'];?>;
			yearPrice  = <?php echo $aGlobalsVip[1]['year_price'];?>;
			break;
		case 2:
			monthPrice = <?php echo $aGlobalsVip[2]['month_price'];?>;
			yearPrice  = <?php echo $aGlobalsVip[2]['year_price'];?>;
			break;
		case 3:
			monthPrice = <?php echo $aGlobalsVip[3]['month_price'];?>;
			yearPrice  = <?php echo $aGlobalsVip[3]['year_price'];?>;
			break;
		default:
			monthPrice = <?php echo $aGlobalsVip[2]['month_price'];?>;
			yearPrice  = <?php echo $aGlobalsVip[2]['year_price'];?>;
	}*/
	//能看到的

	$('#yearPrice').text(yearPrice).attr('data-dateprice', yearPrice);
	$('#halfYearPrice').text(55).attr('data-dateprice', 55);
	$('#yearOldPrice').text( monthPrice * 12 );
	$('#halfYearOldPrice').text(60);
	$('#monthPrice')
		.text($('#month').val() * monthPrice)
		.attr('data-dateprice', $('#month').val() * monthPrice)
		.attr('data-onemonthprice', monthPrice);
	$('#dateType').val(
		$('#vipDatePrice').attr('data-datetype')
	);

	//最终金额
	$('#vipType').val(typeId);

	if(userVipInfo.vip != 0 && typeId > userVipInfo.vip && userVipInfo.vip_expiration_time > nowTime){
			//#升级会员 补升级差价 向上取整
			var agio =  Math.ceil(
				(userVipInfo.vip_expiration_time - $.now() /1000) / 86400
				/ 30 * (monthPrice - vipMonthPrice(userVipInfo.vip))
			);
			$('#vipDatePrice').val(agio);
			$('#pay_fee').text(agio);
	}else{
		//#非会员 | 续费会员 全额开通
		var datePrice = $('#dateTypeChange .option.selected span').attr('data-dateprice');
		$('#vipDatePrice').val(datePrice ? datePrice : 0);
		$('#pay_fee').text($('#vipDatePrice').val());
	}
}

function vipMonthPrice(vipType){
	return [
	'<?php echo $aGlobalsVip[2]['month_price'];?>',
	'<?php echo $aGlobalsVip[1]['month_price'];?>',
	'<?php echo $aGlobalsVip[2]['month_price'];?>',
	'<?php echo $aGlobalsVip[3]['month_price'];?>'][vipType];
}

function fromatVip(type){
	return [
	'<?php echo $aGlobalsVip[0]['name'];?>',
	'<?php echo $aGlobalsVip[1]['name'];?>',
	'<?php echo $aGlobalsVip[2]['name'];?>',
	'<?php echo $aGlobalsVip[3]['name'];?>'][type];
}

function resetFrom(){
	$('#vipTypeChange a, #dateTypeChange span').removeClass('selected');
	$('#vipTypeChange a, #payTimeType').css('display','block');
	$('#vipType, #dateType, #vipDatePrice').val('0');
	$('#payTimeTypeTips').css('display','none');
	$('#yearPrice, #monthPrice, #pay_fee, #yearOldPrice').text(0);
	$('#yearPrice, #monthPrice').data('dateprice', 0);
	$('#monthPrice').data('onemonthprice', 0);
	$('#vipDatePrice').data('datetype', 0);
}

function checkForm(){
	//检查账号
	var oAccountValidater = new Validater('account'),
	accountValidateResult = oAccountValidater.isEmail();
	if(accountValidateResult != true){
		accountValidateResult = oAccountValidater.isNumber(8);
		if(accountValidateResult != true && oAccountValidater.isPhone() != true){
			oAccountValidater.errorCallBack('请输入您的邮箱或数字账号', accountValidateResult);
			return false;
		}
	}

	if($('#vipTypeChange a.selected').length == 0){
		UBox.show('请选择会员类型！', -1);
		return false;
	}

	//非会员判断
	if(userVipInfo.vip == 0 && $('#dateTypeChange span.selected').length == 0){
		UBox.show('请选择开通时长！', -1);
		return false;
	}

	if(userVipInfo.vip > 0 &&
	   userVipInfo.vip == $('#vipTypeChange a.selected').data('viptype') &&
	   $('#dateTypeChange span.selected').length == 0){
			UBox.show('请选择开通时长！', -1);
			return false;
	}

	if($('#month').val().length > 4){
		UBox.show('你确定你不是在开玩笑？', -1);
		return false;
	}

	if($('#payType').val() == 'ubpay'){
		if(isLogin == 0){
			UBox.show('您尚未登录，请登录后使用该付款方式', -1);
			return false;
		}
		//检查用户Ub
		if(parseInt(thisUserUb) < parseInt($('#pay_fee').text()) || parseInt(thisUserUb) == 0){
			UBox.show('您 UB 不足，请先充值 或 选择其他付款方式', -1);
			return false;
		}
	}

	return true;
}
</script>