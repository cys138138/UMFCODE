	<?php echo about\widgets\Footer::widget(); ?>
</div>
<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>
<!--umfun