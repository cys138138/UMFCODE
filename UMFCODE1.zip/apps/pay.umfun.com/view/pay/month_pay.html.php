<!--主体 [-->
<!--
<div class="main pay_main">
	<div class="pay_main_bg"></div>
	<div class="column c">
		<div class="pay_sidebar">
			<div class="pay_sidebar_mod">
				<h3 class="pay_sidebar_title">
					<em>月费充值</em>
					<i class="pay_icon icon_pay_title_monthly"></i>
				</h3>
				<div class="pay_sidebar_info">
					<p>月费充值：75元/月</p>
					<p>月费是用户使用UMFun平台服务的资格服务。</p>
				</div>
			</div>
			<div class="pay_sidebar_mod">
				<h3 class="pay_sidebar_title">
					<em>支付合作</em>
					<i class="pay_icon icon_pay_title_cooperation"></i>
				</h3>
				<div class="pay_sidebar_cooperation">
					<i class="pay_icon icon_sidebar_unlon"></i>
					<span class="line"></span>
					<i class="pay_icon icon_sidebar_alipay"></i>
				</div>
			</div>
		</div>
		<form id="payForm" class="payForm" action="<?php //echo url('m=Pay&a=monthPay'); ?>" method="GET" target="_blank">
			<div class="pay_content">
				<div class="pay_form">
					<div class="item c">
						<label for="" class="name">充值帐号：</label>
						<div class="controls">
							<input class="text" type="text" name="account" id="account" title="请输入邮箱或数字帐号" />
							<b id="msg_b"></b>
						</div>
					</div>
					<div class="item c">
						<label for="" class="name">充值时长：</label>
						<div class="controls  select_controls">
							<div class="selectbox" id="quantity_div">
							   <input type="hidden" maxlength="2" name="month" id="month" value="0" />
							   <div xid="select_active" class="select_active">
								   <span>请选择</span>
								   <i class="triangle"></i>
							   </div>
							   <div xid="select_options" class="select_options">
								   <ul class="select_inner">
										<li value="1">1个月</li>
										<li value="2">2个月</li>
										<li value="3">3个月</li>
										<li value="6">6个月</li>
										<li value="12">12个月</li>
										<li value="24">24个月</li>
								   </ul>
							   </div>
							</div>
							<input id="cardSpan" class="text text_num"  type="text" value="以卡面时长为准" disabled="disabled" />
						</div>
					</div>
					<div class="item c">
						<label for="" class="name">支付方式：</label>
						<div class="controls">
							<ul id="pay_select" class="pay_select">
								<!-- <li class="cur" onclick="setType('unionPay');">银联在线支付</li> -->
								<!--<li class="cur" onclick="setType('alipay');">支付宝在线支付</li>
								<li onclick="setType('monthCard');">充值卡支付</li>
								<li onclick="setType('experienceCard');">会员体验卡支付</li>
							</ul>
							<ul id="pay_panel" class="pay_panel">
								<li class="pay_unlon">
									<div class="pay_tips"><i class="pay_icon icon_pay_tips"></i>银联在线支付，只需银行卡即可支付，无需开通网银等其他业务。</div>
									<div class="pay_tips_info">
										<a href="#"><i class="pay_icon icon_tips_alipay"></i></a>
									</div>
								</li>
								<!-- 
								<li class="pay_alipay">
									<div class="pay_tips"><i class="pay_icon icon_pay_tips"></i>支付宝在线支付，可使用支付宝余额或银行卡快捷支付，方便快捷。</div>
									<div class="pay_tips_info">
										<a href="#"><i class="pay_icon icon_tips_unlon"></i></a>
									</div>
								</li>
								 -->
								<!--
								<li class="pay_card">
									<div class="pay_tips"><i class="pay_icon icon_pay_tips"></i>充值卡仅用于一次性充值，充值数量为充值卡面额数量，不可更改。</div>
									<div class="pay_tips_info c">
										<label for="" class="name">卡号：</label>
										<div class="controls"><input class="text" type="text" name="monthCardNo" id="monthCardNo" title="请刮开充值卡背面卡号区 并输入卡号" /></div>
									</div>
								</li>
								<li class="pay_card">
									<div class="pay_tips">
										<i class="pay_icon icon_pay_tips"></i>体验卡仅用于一次性充值且每账户仅可使用一次体验卡充值。
									</div>
									<div class="pay_tips_info c">
										<label for="" class="name">卡号：</label>
										<div class="controls">
											<input class="text" type="text" name="experienceCardNo" id="experienceCardNo" title="请刮开体验卡背面卡号区 并输入卡号" />
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
					<div class="item c">
						<label class="name">应付金额：</label>
						<div class="controls">
							<span class="pay_fee" id="payFee">0.00</span>
							<span class="primary" id="payFeeSpan">元</span>
							<span class="pay_fee" id="cardFeeSpan" style="display:none">以卡面金额为准</span>
						</div>
					</div>
					<div class="item c">
						<label for="" class="name"></label>
						<div class="controls">
							<input type="hidden" id="payType" name="payType" value="alipay" />
							<input type="button" value="立即支付" class="icon btn_blue" id="payButton" />
							<img id="doing" class="doing" src="<?php //echo SYSTEM_RESOURCE_URL; ?>view/image/doing.gif" width="32" height="32" />
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
<!--主体 ]-->
<!--充值弹窗 [-->
<!--
<div id="mask" class="mask"></div>
<div id="pay_pop" class="pay_pop">
    <div class="hd">
        <h2>网上充值</h2>
        <a id="pay_pop_close" class="pay_pop_close" title="关闭">×</a>
    </div>
    <div class="info">
        <div class="tips">请在新开网银页面完成充值后选择：</div>
        <div class="pay_succ"><b>充值成功</b> ｜ 您可以选择：<a href="<?php //echo url('m=Account&a=showList&type=2'); ?>">查看充值记录</a></div>
        <div class="pay_fail"><b>充值失败</b> ｜ 建议您选择其他充值方式</div>
    </div>
</div>
<!--充值弹窗 ]-->

<script type="text/javascript">
	/*
	function isAccount(){
		var oAccountValidater = new Validater('account'),
		accountValidateResult = oAccountValidater.isEmail();
		if(accountValidateResult != true){
			accountValidateResult = oAccountValidater.isNumber(8);
			if(accountValidateResult != true){
				return false;
			}
		}
		return true;
	}

	function setType(payType){
		$('#payType').val(payType);
		if($.inArray(payType, ['monthCard', 'experienceCard']) != -1){
			$('#quantity_div').hide();
			$('#cardSpan').show();

			$('#payFee').hide();
			$('#payFeeSpan').hide();
			$('#cardFeeSpan').show();
		}else{
			$('#quantity_div').show();
			$('#cardSpan').hide();

			$('#payFee').show();
			$('#payFreeSpan').show();
			$('#cardFeeSpan').hide();
		}
	}

	/**
	 * 表单检查
	 */
	/*
	function checkForm(){
		//检查账号
		var oAccountValidater = new Validater('account'),
		accountValidateResult = oAccountValidater.isEmail();
		if(accountValidateResult != true){
			accountValidateResult = oAccountValidater.isNumber(8);
			if(accountValidateResult != true){
				oAccountValidater.errorCallBack('请输入您的邮箱或数字账号', accountValidateResult);
				return false;
			}
		}

		//根据支付类型检查相关输入
		var payType = $('#payType').val();
		if($.inArray(payType, ['unionPay', 'alipay']) != -1){
			//检查U币充值面额
			if(parseInt($('#month').val()) == 0){
				oAccountValidater.errorCallBack('请选择充值时长', {dom : $('#quantity_div')[0]});
				return false;
			}
		}else if($.inArray(payType, ['monthCard', 'experienceCard']) != -1){
			//检查充值卡号
			var oCardNo = $('#' + payType + 'No');
			if(!/^[A-Z0-9]{20}$/.test($.trim(oCardNo.val()))){
				UBox.show('充值卡号为空或格式错误', -1);
				oAccountValidater.errorCallBack('充值卡号为空或格式错误', {dom : oCardNo[0]});
				oCardNo.val('').select();
				return false;
			}
		}
		return true;
	}

	$(function(){
		document.getElementById('payForm').reset();
		$('#month').val(0);
		heighlightMenu('MonthPay');

		$('#account,#monthCardNo,#experienceCardNo').blur(function(){
			if(this.value == this.getAttribute('title') || this.value == ''){
				this.style.color = '#999';
				this.value = this.getAttribute('title');
			}else{
				this.style.color = '#000';
			}
		}).keyup(function(){
			if(this.value == this.getAttribute('title') || this.value == ''){
				this.style.color = '#999';
			}else{
				this.style.color = '#000';
			}
		}).each(function(){
			this.value = this.getAttribute('title');
		});

		//账号输入交互
		$('#account').focus(function(){
			if(!isAccount()){
				$('#msg_b').html('');
				$(this).val('');
			}
		}).blur(function(){
			var lastAccount = $(this).data('lastAccount'),
			currentAccount = $.trim(this.value);
			if($.inArray(currentAccount, [lastAccount, '', $(this).attr('title')]) != -1){
				return;
			}else if(isAccount() != true){
				$('#msg_b').html('');
			}

			$.ajax({
				url : '<?php echo url('m=Account&a=getUserInfoByEmailOrUserId&account=_account'); ?>'.replace('_account', $('#account').val()),
				success : function(aResult){
					var tip = aResult.status == 1 ? aResult.data.name + '（' + aResult.data.account + '）' : aResult.msg;
					$('#msg_b').html(tip);
				}
			});
			$(this).data('lastAccount', currentAccount);
		});

		$('#monthCardNo,#experienceCardNo').focus(function(){
			if($(this).val() == $(this).attr('title')){
				$(this).val('');
			}
		});

		$('#payButton').click(function(){
			if(!checkForm()){
				return false;
			}

			var payType = $('#payType').val(), oPayForm = $('#payForm'), oDoing = $('#doing');
			if($.inArray(payType, ['unionPay', 'alipay']) != -1){
				oPayForm.submit();
				$('#mask').height($('body').height()).show();
				$('#pay_pop').show();
			}else if($.inArray(payType, ['monthCard', 'experienceCard']) != -1){
				$.ajax({
					url : oPayForm.attr('action') + '?' + oPayForm.serialize(),
					dataType : 'json',
					beforeSend : function(){
						oDoing.show();
					},
					complete : function(){
						oDoing.hide();
					},
					success : function(aResult){
						UBox.show(aResult.msg, aResult.status, '', 5);
						if(aResult.status == 1){
							$('#' + payType + 'No').val('');
						}
					},
					error : function(aRequest){
						UBox.show('抱歉，网络可能有点慢，请稍后再试');
					}
				});
			}
		});
	});
	*/
</script>