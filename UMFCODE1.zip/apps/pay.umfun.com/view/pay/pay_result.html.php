<!--主体 [-->
<div class="main pay_main">
	<div class="pay_main_bg"></div>
	<div class="column c">
		<div class="pay_sidebar">
			<div class="pay_sidebar_mod">
				<ul id="pay_sidebar_record" class="pay_sidebar_record">
					<li><i class="pay_icon icon_record_unlon"></i><a href="<?php echo url('m=Account&a=showList&type=1'); ?>">U 币充值记录查询</a></li>
					<!--<li><i class="pay_icon icon_record_monthlys"></i><a href="<?php //echo url('m=Account&a=showList&type=2'); ?>">月费充值记录查询</a></li>-->
				</ul>
			</div>
			<div class="pay_sidebar_mod">
				<h3 class="pay_sidebar_title">
					<em>支付合作</em>
					<i class="pay_icon icon_pay_title_cooperation"></i>
				</h3>
				<div class="pay_sidebar_cooperation">
					<i class="pay_icon icon_sidebar_unlon"></i>
					<span class="line"></span>
					<i class="pay_icon icon_sidebar_alipay"></i>
				</div>
			</div>
		</div>
		<div class="pay_content">
			<div class="pay_myaccount">
				<h3 class="title">充值详情</h3>
				<div class="pay_details">
				<?php if($aRechargeInfo){ ?>
					<?php if($aRechargeInfo['pay_finish'] == 1){ ?>
					<div class="pay_success">
						<span class="pay_details_icon pay_success_ico">√</span>充值成功！！！
					</div>
					<?php }else{ ?>
					<div class="pay_failure">
						<span class="pay_details_icon pay_failure_ico">χ</span>抱歉，充值失败！！！
					</div>
					<?php } ?>
				<?php }else{ ?>
					<div class="pay_failure">
						<span class="pay_details_icon pay_failure_ico">χ</span>抱歉，订单错误！！！
					</div>
				<?php } ?>
					<div class="pay_con">需要帮助？<a href="http://<?php echo APP_SERVICE ?>">联系客服</a></div>
			   </div>
			</div>
		</div>
	</div>
</div>
<!--主体 ]-->
<script type="text/javascript">
	heighlightMenu('<?php echo $menu; ?>');
</script>