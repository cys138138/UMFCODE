<!--主体 [-->
<div class="main pay_main">
	<div class="pay_banner">
		<div class="column">
			<div class="pay_banner_active">
				<a href="<?php echo url('m=Pay&a=showUbPay'); ?>" title="U币充值"></a>
				<a href="<?php echo url('m=Pay&a=showVipPay'); ?>" title="会员充值"></a>
			</div>
		</div>
	</div>
	<div class="column c">
		<div class="pay_product_mod">
			<ul class="c">
				<li>
					<span class="pay_sign"><i class="pay_icon icon_ucoin_sign"></i></span>
					<h3><em>U币可用于：</em><i class="pay_icon icon_ucoin_title"></i></h3>
					<p class="txt">
						购买游戏道具 让你驰骋江湖<br />
						装扮空间饰品 让你与众不同<br />
						购买或使用UMFun所有业务
					</p>
					<a href="<?php echo url('m=Pay&a=showUbPay'); ?>" class="active">
						<em>立刻去充值</em>
						<i class="pay_icon icon_ucoin_active"></i>
					</a>
				</li>
				<!--
				<li>
					<span class="pay_sign"><i class="pay_icon icon_monthly_sign"></i></span>
					<h3><em>月费是什么？</em><i class="pay_icon icon_monthly_title"></i></h3>
					<p class="txt">
						UMFun为用户提供最优质付费服务 月费为75元/月 参与在线闯关 好友PK 参加全国竞赛……
					</p>
					<a href="<?php //echo url('m=Pay&a=showMonthPay'); ?>" class="active">
						<em>立刻去充值</em>
						<i class="pay_icon icon_monthly_active"></i>
					</a>
				</li>
				-->
				<li class="pay_product_cooperation">
					<span class="pay_sign"><i class="pay_icon icon_cooperation_sign"></i></span>
					<h3><em>支持的支付方式：</em><i class="pay_icon icon_cooperation_title"></i></h3>
					<p class="txt">
						银联在线<i class="pay_icon icon_cooperation_unlon"></i>(无需网银 银行卡即可支付)  支付宝在线
						<i class="pay_icon icon_cooperation_alipay"></i>冠铭一卡通<i class="pay_icon icon_cooperation_99193"></i>充值卡
						<i class="pay_icon icon_cooperation_umfun"></i>
					</p>
					<a href="<?php echo url('m=Pay&a=showUbPay'); ?>" class="active">
						<em>立刻去充值</em><i class="pay_icon icon_cooperation_active"></i>
					</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<!--主体 ]-->
<script type="text/javascript">
	heighlightMenu('Index');
</script>
