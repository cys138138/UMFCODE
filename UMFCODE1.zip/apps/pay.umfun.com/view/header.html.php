<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo $title; ?></title>
<link  href="<?php echo $GLOBALS['RESOURCE']['style_home']; ?>" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['validater']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['library']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_home']; ?>"></script>
 <!--[if lte IE 6]><script src="<?php echo $GLOBALS['RESOURCE']['dd_belated_png']; ?>"></script><![endif]-->
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<script src="<?php echo Yii::getAlias('@r.js.core'); ?>"></script>
</head>
<body>
<div class="container">
    <?php echo about\widgets\Header::widget(); ?>
    <!--头部 [-->
    <div class="header pay_header">
        <div class="column">
            <h1 class="logo pay_logo"><a href="<?php echo url('m=Index&a=index')?>" title="umFun-充值中心">umFun-充值中心</a></h1>
            <ul class="pay_nav c">
                <li id="menuIndex"><a href="<?php echo url('m=Index&a=index')?>">充值首页</a></li>
                <li id="menuUbPay"><a href="<?php echo url('m=Pay&a=showUbPay')?>">U币充值</a></li>
                <li id="menuVip"><a href="<?php echo url('m=Pay&a=showVipPay')?>">会员充值</a></li>
                <!--<li id="menuMonthPay"><a href="<?php //echo url('m=Pay&a=showMonthPay')?>">月费充值</a></li>-->
                <li id="menuAccount"><a href="<?php echo url('m=Account&a=showList')?>">我的账户</a></li>
            </ul>
        </div>
    </div>
    <!--头部 ]-->
	<script type="text/javascript">
		function heighlightMenu(menuId){
			$('#menu' + menuId).addClass('cur');
		}
	</script>