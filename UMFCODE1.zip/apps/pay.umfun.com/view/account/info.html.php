<!--主体 [-->
<div class="main pay_main">
	<div class="pay_main_bg"></div>
	<div class="column c">
		<div class="pay_sidebar">
			<div class="pay_sidebar_mod">
				<div class="user_pane c">
					<div class="head"><img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php echo SYSTEM_RESOURCE_URL . $aUser['profile'];?>" onload="h(this)" width="56" height="56" /></div>
					<div class="name"><?php echo $aUser['name'];?></div>
					<div class="uin"><?php echo $aUser['id'];?></div>
				</div>
				<ul id="pay_sidebar_record" class="pay_sidebar_record">
					<li><i class="pay_icon icon_record_unlon"></i><a href="<?php echo url('m=Account&a=showList&type=1'); ?>">U 币充值记录查询</a></li>
					<!--<li><i class="pay_icon icon_record_monthlys"></i><a href="<?php //echo url('m=Account&a=showList&type=2'); ?>">月费充值记录查询</a></li>-->
				</ul>
			</div>
		</div>

		<div class="pay_content">
			<div class="pay_myaccount">
				<h3 class="title">我的账户</h3>
				<ul class="pay_myaccount_mod c">
					<li>
						<span class="pay_unlon_num">U 币余额：<?php echo $aUserNumerical['ub'];?></span>
						<a class="pay_icon pay_btn_blue" href="<?php echo url('m=Pay&a=showUbPay'); ?>">立即充值</a>
					</li>
					<li>
						<span class="pay_unlon_num">金币余额：<?php echo $aUserNumerical['gold'];?></span>
					</li>
				</ul>

                <div class="exchange_mod c">
                    <div class="item">
                        请填写要兑换的U币：<input class="text" type="text" name="exchangeUb" id="exchangeUb" onkeyup="exchange()" />
                    </div>
                    <div class="item gold_item">
                        获得金币：<b id="exchangeGold">0</b>
                    </div>
                    <div class="item">
                        <input id="exchangeBtn" class="icon btn_blue" type="button" value="立即兑换" onclick="exchangeGold()" />
                    </div>
                </div>

                <div class="exchange_mod c gold_info">
                	<style>
						.exchange_mod.gold_info dt{
							font-weight:700;
						}

						.exchange_mod.gold_info dd{
							line-height: 1.8
						}
                	</style>
                	<dl>
                		<dt>金币,U币说明：</dt>
                		<dd>a. 金币可以在游戏中通过每日任务、签到、修炼抽奖、参加比赛、参加PK等方式获得</dd>
                		<dd>b. 获得的金币可以在兑换商城兑换礼品</dd>
                		<dd>c. 用户也可以通过充值U币来获得金币，1U币=10金币</dd>
                	</dl>
                </div>

				<ul id="pay_record_menu" class="pay_record_menu">
					<a href="<?php echo url('m=Account&a=showList'); ?>"><li <?php if($type == 0){echo 'class="cur"';}?>>全部记录</li></a>
					<a href="<?php echo url('m=Account&a=showList&type=1'); ?>"><li <?php if($type == 1){echo 'class="cur"';}?>>U 币充值记录查询</li></a>
					<!--<a href="<?php //echo url('m=Account&a=showList&type=2'); ?>"><li <?php //if($type == 2){echo 'class="cur"';}?>>月费充值记录查询</li></a>-->
				</ul>

                <ul id="pay_record_info" class="pay_record_info">
                    <li>
                        <table class="pay_record_list">
                            <thead>
                                <tr>
                                    <td>充值流水号</td>
                                    <td>第三方订单号</td>
                                    <td>充值金额/月数</td>
                                    <td>支付方式</td>
                                    <td>充值时间</td>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if($aRechargeList){
                                    foreach($aRechargeList as $key => $aRechargeInfo){
                            ?>
                                <tr>
                                    <td><?php echo $aRechargeInfo['id']; ?></td>
                                    <td><?php echo $aRechargeInfo['serial_number']; ?></td>
                                    <td><?php echo $aRechargeInfo['quantity'];echo $aRechargeInfo['type'] == 1 ? ' U币' : '　月'; ?></td>
                                    <td><?php echo $aRechargeInfo['typeName']; ?></td>
                                    <td><?php echo date('Y-m-d H:i:s', $aRechargeInfo['create_time']); ?></td>
                                </tr>

                            <?php
                                    }
                            }else{
                                echo '<tr><td colspan="5" align="center">暂无记录</td></tr>';

                            }?>
                            </tbody>
                        </table>
                            <?php echo $pageHtml;?>
                    </li>
                </ul>

			</div>
		</div>

	</div>
</div>
<!--主体 ]-->
<script type="text/javascript">
	heighlightMenu('Account');
	$('#exchangeUb').val('');

	function exchange(){
		var ub = $('#exchangeUb').val();
		if(!ub.match(/^[0-9]*[1-9][0-9]*$/)){
			UBox.show('U币必须为正整数', -1);
			$('#exchangeUb').val('');
			return false;
		}
		var gold = ub * <?php echo UB_GOLD_RATE; ?>;
		$('#exchangeGold').text(gold);
	}

	function exchangeGold(){
		var ub = $('#exchangeUb').val();
		if(!ub.match(/^[0-9]*[1-9][0-9]*$/)){
			UBox.show('U币必须为正整数', -1);
			$('#exchangeUb').val('');
			return false;
		}

		$('#exchangeBtn').css({'background':'#CDCDCD'});
		$('#exchangeBtn').attr('onclick', '');
		$.ajax({
			url : '<?php echo url('m=Account&a=exchangeGold'); ?>',
			type : 'post',
			data : {ub : ub},
			dataType : 'json',
			success : function(aResult){
				if(typeof(aResult.notice) != 'undefined' && typeof(aResult.notice.tips_vip_activation) != 'undefined'){
					UBox.confirm('只有会员才能兑换哦！立即开通会员，金币无上限，畅玩优满分！ 去开通', function(){
						var aDomainInfo = document.domain.split('.');
						aDomainInfo.shift();
						window.location.href = 'http://vip.' + aDomainInfo.join('.');
					});
					return;
				}
				UBox.show(aResult.msg, aResult.status, aResult.data);
				if(aResult.status != 1){
					$('#exchangeBtn').css({'background':'#3283BE'});
					$('#exchangeBtn').attr('onclick', 'exchangeGold()');
				}
			},
			error: function(aRequest){
				UBox.show('网络可能有点慢误啦');
			}
		});
	}

</script>
