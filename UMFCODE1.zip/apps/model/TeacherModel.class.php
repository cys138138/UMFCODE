<?php
/*
*老师模型
*/

class TeacherModel{
	public static function  xCrypt($password){
		return md5($password);
	}

	//添加老师
	public function addTeacher($aData){
		if(isset($aData['password'])){
			$aData['password'] = $this->xCrypt($aData['password']);
		}
		$aData['student_group'] = json_encode(array('-1' => ''));
		if(isset($aData['relations'])){
			$aData['relations'] = json_encode($aData['relations']);
		}else{
			$aData['relations'] = json_encode(array());
		}
		$oTeacher = new Model(T_TEACHER);
		return $oTeacher->add($aData);
	}

	//修改信息-------除了分组信息不能修改
	public function setTeacher($aData){
		$oTeacher = new Model(T_TEACHER);
		if(isset($aData['student_group'])){
			unset($aData['student_group']);
		}
		if(isset($aData['password'])){
			$aData['password'] = $this->xCrypt($aData['password']);
		}
		if(isset($aData['relations'])){
			$aData['relations'] = json_encode($aData['relations']);
		}
		return $oTeacher->update($aData, array('id' => $aData['id']));
	}

	//登陆需要
	public function getTeacherInfoByMobileAndPassword($mobile, $password){
		$password = $this->xCrypt($password);
		$where = "`mobile`='" . $mobile . "' AND `password`='" . $password . "'";
		$oTeacher = new Model(T_TEACHER);
		$aTeacherInfo = $oTeacher->get('`id`,`mobile`,`school_id`,`subject_id`,`create_time`', $where);
		if($aTeacherInfo){
			$aTeacherInfo = $aTeacherInfo[0];
		}
		return $aTeacherInfo;
	}

	//验证手机号是否已使用
	public function getTeacherInfoByMobile($mobile){
		$where = "`mobile`='" . $mobile . "'";
		$oTeacher = new Model(T_TEACHER);
		$aTeacherInfo = $oTeacher->get('`id`,`mobile`,`school_id`,`subject_id`,`create_time`', $where);
		if($aTeacherInfo){
			$aTeacherInfo = $aTeacherInfo[0];
		}
		return $aTeacherInfo;
	}

	public function getTeacherInfoById($id){
		$oTeacher = new Model(T_TEACHER);
		$aTeacherInfo = $oTeacher->get('', array('id' => $id));
		if($aTeacherInfo){
			$aTeacherInfo = $aTeacherInfo[0];
			$aTeacherInfo = $this->_parseTeacherInfo($aTeacherInfo);
			$oTeacherIndex = new Model(T_TEACHER_INDEX);
			$aTeacherIndex = $oTeacherIndex->get('', array('id' => $id));
			$aTeacherInfo = array_merge($aTeacherInfo, $aTeacherIndex[0]);
		}
		return $aTeacherInfo;
	}

	//验证用户是否存在
	public function getTeacherInfoByExtendCode($extendCode, $extendType){
		$fileds = '`id`,`name`,`create_time`,`check_time`,`school_id`';
		$where = "`extend_type`=" . $extendType . " AND `extend_code`='" . $extendCode . "'";
		$oTeacher = new Model(T_TEACHER);
		$aTeacherInfo = $oTeacher->get($fileds, $where);
		if($aTeacherInfo){
			$aTeacherInfo = $aTeacherInfo[0];
		}
		return $aTeacherInfo;
	}

	private function _parseTeacherInfo($aTeacherInfo){
		$aTeacherInfo['class_relation'] = json_decode($aTeacherInfo['class_relation'], true);
		$aTeacherInfo['xxt_data'] = json_decode($aTeacherInfo['xxt_data'], true);
		return $aTeacherInfo;
	}

	//修改密码用
	public function setTeacherInfoByMobile($aData, $mobile){
		$oTeacher = new Model(T_TEACHER);
		return $oTeacher->update($aData, '`mobile`=' . $mobile);
	}

	//添加分组
	public function addGroup($teacherId, $groupName){
		$aData = array(
			'name' => $groupName,
			'create_time' => time(),
		);
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$groupId = $oDboi->table(T_STUDENT_GROUP)->data($aData)->insert();
		if(!$groupId){
			return $groupId;
		}
		$aGroupList = $this->_getGroupUserList($teacherId);
		if(!$aGroupList){
			$oDboi->rollBack();
			return false;
		}
		$aGroupList[$groupId] = array();
		$studentGroup = $this->_convertArrayToJson($aGroupList);
		$result = $oDboi->table(T_TEACHER)->data(array('student_group' => $studentGroup))->where(array('id' => $teacherId))->update();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		return $groupId;
	}

	//删除分组
	public function deleteGroup($teacherId, $groupId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//取出分组列表
		$aGroupList = $this->_getGroupUserList($teacherId);
		if(!$aGroupList){
			return false;
		}
		//移动要删除分组的用户到默认分组中
		$aGroupList[-1] = array_merge($aGroupList[-1], $aGroupList[$groupId]);
		unset($aGroupList[$groupId]);
		$studentGroup = $this->_convertArrayToJson($aGroupList);
		$result = $oDboi->table(T_TEACHER)->data(array('student_group' => $studentGroup))->where(array('id' => $teacherId))->update();
		if(!$result){
			return $result;
		}
		//删除分组记录
		$row = $oDboi->table(T_STUDENT_GROUP)->where(array('id' => $groupId))->delete();
		if(!$row){
			$oDboi->rollBack();
			return false;
		}
		return $row;
	}

	//移动分组
	public function moveStudentToGroup($teacherId, $aStudentIds, $newGroupId){
		$aGroupList = $this->_getGroupUserList($teacherId);
		//在旧分组删除该学生id
		foreach($aStudentIds as $studentId){
			foreach($aGroupList as $groupId => $aGroupUserIds){
				if($aKey = array_keys($aGroupUserIds, $studentId)){
					unset($aGroupList[$groupId][$aKey[0]]);
				}
			}
			//添加该学生到新分组
			$aGroupList[$newGroupId][] = $studentId;
		}
		$studentGroup = $this->_convertArrayToJson($aGroupList);
		$oTeacher = new Model(T_TEACHER);
		return $oTeacher->update(array('student_group' => $studentGroup), array('id' => $teacherId));
	}

	//关注学生
	public function attentionStudent($teacherId, $aStudentIds, $groupId = -1){
		$aGroupList = $this->_getGroupUserList($teacherId);
		//添加该学生到新分组
		$aGroupList[$groupId] = array_merge($aGroupList[$groupId], $aStudentIds);
		$studentGroup = $this->_convertArrayToJson($aGroupList);
		$oTeacher = new Model(T_TEACHER);
		return $oTeacher->update(array('student_group' => $studentGroup), array('id' => $teacherId));
	}

	//取消关注
	public function cancelAttentionStudent($teacherId, $aStudentIds){
		$aGroupList = $this->_getGroupUserList($teacherId);
		//在分组中删除该学生id
		foreach($aStudentIds as $studentId){
			foreach($aGroupList as $groupId => $aGroupUserIds){
				if($aKey = array_keys($aGroupUserIds, $studentId)){
					unset($aGroupList[$groupId][$aKey[0]]);
				}
			}
		}
		$studentGroup = $this->_convertArrayToJson($aGroupList);
		$oTeacher = new Model(T_TEACHER);
		return $oTeacher->update(array('student_group' => $studentGroup), array('id' => $teacherId));
	}

	//获取学生列表
	public function getGroupStudentList($teacherId, $page = 1, $pageSize = 10, $groupId = 0){
		$aGroupUserIds = $this->_getGroupUserList($teacherId);
		if(!$aGroupUserIds){
			return $aGroupUserIds;
		}
		if($groupId){
			$aUserIds = $aGroupUserIds[$groupId];
		}else{
			$aUserIds = array();
			foreach($aGroupUserIds as $key => $aStudentUserIds){
				$aUserIds = array_merge($aUserIds, $aGroupUserIds[$key]);
			}
		}
		$offect = ($page - 1) * $pageSize;
		$aUserIds = array_slice($aUserIds, $offect, $pageSize);
		if(!$aUserIds){
			return $aUserIds;
		}
		$aUserList = getUserListByUserIds($aUserIds, array('class', 'numerical'));
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aUserList as &$aUser){
			foreach($aGroupUserIds as $key => $aStudentUserIds){
				if(in_array($aUser['id'], $aStudentUserIds)){
					$aUser['group_id'] = $key;
				}
			}
		}
		return $aUserList;
	}

	//获取学生id列表
	public function getGroupStudentIds($teacherId, $groupId = 0){
		$aGroupUserIds = $this->_getGroupUserList($teacherId);
		if(!$aGroupUserIds){
			return $aGroupUserIds;
		}
		if($groupId){
			$aUserIds = $aGroupUserIds[$groupId];
		}else{
			$aUserIds = array();
			foreach($aGroupUserIds as $key => $aStudentUserIds){
				$aUserIds = array_merge($aUserIds, $aGroupUserIds[$key]);
			}
		}
		return $aUserIds;
	}

	//获取老师的分组ids
	public function getGroupIds($teacherId){
		$aGroupUserIds = $this->_getGroupUserList($teacherId);
		if(!$aGroupUserIds){
			return $aGroupUserIds;
		}
		$aGroupIds = array();
		foreach($aGroupUserIds as $groupId => $aStudentUserIds){
			$aGroupIds[] = $groupId;
		}
		return $aGroupIds;
	}

	//获取老师的分组列表
	public function getGroupList($teacherId){
		$aGroupUserIds = $this->_getGroupUserList($teacherId);
		if(!$aGroupUserIds){
			return $aGroupUserIds;
		}
		$aGroupIds = array();
		foreach($aGroupUserIds as $groupId => $aStudentUserIds){
			$aGroupIds[] = $groupId;
		}
		if(!$aGroupIds){
			return $aGroupIds;
		}
		$aKey = array_keys($aGroupIds, -1);
		if($aKey){
			unset($aGroupIds[$aKey[0]]);
		}
		$aGroupList = array();
		if($aGroupIds){
			$oStudentGroup = new Model(T_STUDENT_GROUP);
			$aGroupList = $oStudentGroup->get('', array('id' => array('in', $aGroupIds)));
			if($aGroupList === false){
				return false;
			}
		}
		array_unshift($aGroupList, array('id' => -1, 'name' => '默认分组'));
		foreach($aGroupList as &$aGroup){
			foreach($aGroupUserIds as $groupId => $aStudentUserIds){
				if($aGroup['id'] == $groupId){
					$aGroup['member_count'] = count($aStudentUserIds);
					break;
				}
			}
		}
		return $aGroupList;
	}

	//根据学校和班级查找学生
	public function getStuentListInSchool($teacherId, $schoolId, $grade = 0, $class = '', $page = 1, $pageSize = 20){
		$where = '`is_active`=1 AND `school_id`=' . $schoolId;
		if($class){
			$where .= " AND `class`='" . $class . "'";
		}
		if($grade){
			$where .= " AND `grade`=" . $grade;
		}
		$offect = ($page - 1) * $pageSize;
		$oClass = new Model(T_USER_CLASS);
		$aClassList = $oClass->get('DISTINCT `user_id`', $where);
		if(!$aClassList){
			return $aClassList;
		}
		$aUserIds = array();
		foreach($aClassList as $aClass){
			$aUserIds[] = $aClass['user_id'];
		}
		//去掉我关注过的
		$aTeacherAttentionStudent = $this->getGroupStudentIds($teacherId);
		if($aTeacherAttentionStudent === false){
			return false;
		}
		$aUserIds = array_diff($aUserIds, $aTeacherAttentionStudent);
		if(!$aUserIds){
			return $aUserIds;
		}
		$aUserIds = array_slice($aUserIds, $offect, $pageSize);
		return getUserListByUserIds($aUserIds, array('class', 'numerical'));
	}

	public function getStuentListInSchoolCount($teacherId, $schoolId, $grade = 0, $class = ''){
		$where = '`school_id`=' . $schoolId;
		if($class){
			$where .= " AND `class`='" . $class . "'";
		}
		if($grade){
			$where .= " AND `grade`=" . $grade;
		}
		$oClass = new Model(T_USER_CLASS);
		$aClassList = $oClass->get('DISTINCT `user_id`', $where);
		if($aClassList === false){
			return false;
		}elseif(!$aClassList){
			return 0;
		}
		$aUserIds = array();
		foreach($aClassList as $aClass){
			$aUserIds[] = $aClass['user_id'];
		}
		//去掉我关注过的
		$aTeacherAttentionStudent = $this->getGroupStudentIds($teacherId);
		if($aTeacherAttentionStudent === false){
			return false;
		}
		$aUserIds = array_diff($aUserIds, $aTeacherAttentionStudent);
		return count($aUserIds);
	}

	//取得用户分组的数组格式
	private function _getGroupUserList($teacherId){
		$oTeacher = new Model(T_TEACHER);
		$aTeacherInfo = $oTeacher->get('`student_group`', array('id' => $teacherId));
		if(!$aTeacherInfo){
			return $aTeacherInfo;
		}
		$aGroupList = json_decode($aTeacherInfo[0]['student_group'], true);
		foreach($aGroupList as $groupId => $groupUserIds){
			if($groupUserIds){
				$aGroupList[$groupId] = explode(',', $groupUserIds);
			}else{
				$aGroupList[$groupId] = array();
			}
		}
		return $aGroupList;
	}

	//将用户分组的数组格式转换成json格式
	private function _convertArrayToJson($aGroupList){
		foreach($aGroupList as $groupId => $aGroupUserIds){
			$aGroupList[$groupId] = implode(',', $aGroupUserIds);
		}
		return json_encode($aGroupList);
	}

	public function saveTeacherRelations($teacherId, $aRelationList){
		$aStudentIds = array();
		foreach($aRelationList as $aRelation){
			foreach($aRelation['student_list'] as $aStudent){
				$aStudentIds[] = $aStudent['StudentId'];
			}
		}
		if($aStudentIds){
			$oUser = new Model(T_USER);
			$aUserList = $oUser->get('`id`,`xxt_id`', '`xxt_id` in (' . implode(',', $aStudentIds) . ')');
			if($aUserList === false){
				return false;
			}
			$aExistStudentIds = array();
			$aUserReferList = array();
			foreach($aUserList as $aUser){
				$aExistStudentIds[] = $aUser['xxt_id'];
				$aUserReferList[$aUser['xxt_id']] = $aUser;
			}
			unset($aUserList);
			foreach($aRelationList as $key => $aClass){
				$aStudentList = array();
				foreach($aClass['student_list'] as $aStudent){
					if(in_array($aStudent['StudentId'], $aExistStudentIds)){
						$aStudent['uf_id'] = $aUserReferList[$aStudent['StudentId']]['id'];
						$aStudentList[] = $aStudent;
					}
				}
				$aRelationList[$key]['student_list'] = $aStudentList;
			}
		}
		$oTeacher = new Model(T_TEACHER);
		return $oTeacher->update(array('relations' => json_encode($aRelationList), 'check_time' => time()), array('id' => $teacherId));
	}

	/*
	 *$aCondition = array(
	 *		'city_id'	=> 'cs'  城市拼音缩写
	 *		'uf_id'		=>
	 *		'name'		=>	'逗比启军'
	 * )
	 *
	 */
	public function getXxtTeacherList($page, $pageSize, $aCondition = array()){
		$where = $this->_parseWhereForXxtTeacherList($aCondition);
		$offect = ($page - 1) * $pageSize;
		$oTeacher = new Model(T_TEACHER_INDEX);
		$aTeacherList = $oTeacher->get('`id`,`extend_code`,`name`,`city_id`,`create_time`,`school_id`', $where, '`id` DESC', $offect, $pageSize);
		return $this->_convertDataForTeacherList($aTeacherList);
	}

	public function getXxtTeacherCount($aCondition = array()){
		$where = $this->_parseWhereForXxtTeacherList($aCondition);
		$oTeacher = new Model(T_TEACHER_INDEX);
		return $oTeacher->count($where);
	}

	private function _parseWhereForXxtTeacherList($aCondition){
		$where = '';
		if(isset($aCondition['uf_id']) && $aCondition['uf_id']){
			$where = array('id' => $aCondition['uf_id']);
		}else{
			$where = '`extend_code`>0';
			if(isset($aCondition['city_id']) && $aCondition['city_id']){
				//处理cs 和gz的
				if($aCondition['city_id'] == 'cs'){
					$where .= " AND (`city_id`='" . $aCondition['city_id'] . "' or `city_id` = 'gz')";
				//处理未知城市标志的情况
				}else if($aCondition['city_id'] == 11000000){
					$where .= " AND `city_id`=''";
				}else{
					$where .= " AND `city_id`='" . $aCondition['city_id'] . "'";
				}
			}
			if(isset($aCondition['name']) && $aCondition['name']){
				$where .= " AND `name`='" . $aCondition['name'] . "'";
			}
			if(isset($aCondition['start_time']) && $aCondition['start_time']){
				$where .= " AND `create_time`>='" . $aCondition['start_time'] . "'";
			}
			if(isset($aCondition['end_time']) && $aCondition['end_time']){
				$where .= " AND `create_time`<='" . $aCondition['end_time'] . "'";
			}			
			if(isset($aCondition['schoolId']) && $aCondition['schoolId']){
				$where .= " AND `school_id`='" . $aCondition['schoolId'] . "'";
			}			
		}
		return $where;
	}

	private function _convertDataForTeacherList($aTeacherList){
		if(!$aTeacherList){
			return $aTeacherList;
		}
		foreach($aTeacherList as &$aTeacher){
			if(isset($aTeacher['relations'])){
				if($aTeacher['relations']){
					$aTeacher['relations'] = json_decode($aTeacher['relations'], true);
				}else{
					$aTeacher['relations'] = array();
				}
			}
		}
		return $aTeacherList;
	}
}
