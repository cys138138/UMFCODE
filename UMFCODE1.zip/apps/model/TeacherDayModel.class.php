<?php
/*
*教师节模型
*/

class TeacherDayModel{
	public function getTeacherDayTeacherInfo($xxtTeacherId, $cityId){
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		$aTeacherInfo = $oTeacher->get('', 'xxt_teacher_id=' . $xxtTeacherId . " AND `city_id`='" . $cityId . "'");
		if($aTeacherInfo){
			$aTeacherInfo = $this->_parseTeacherList($aTeacherInfo);
			$aTeacherInfo = $aTeacherInfo[0];
		}
		return $aTeacherInfo;
	}

	public function getTeacherDayStudentInfo($userId){
		$oStudent = new Model(T_TEACHER_DAY_STUDENT);
		$aStudentInfo = $oStudent->get('', array('id' => $userId));
		if($aStudentInfo){
			$aStudentInfo = $aStudentInfo[0];
		}
		return $aStudentInfo;
	}

	public function addTeacherDayTeacher($aData){
		$aData['xxt_data'] = json_encode($aData['xxt_data']);
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		return $oTeacher->add($aData);
	}

	public function addTeacherDayStudent($aData){
		$oStudent = new Model(T_TEACHER_DAY_STUDENT);
		return $oStudent->add($aData);
	}

	public function updateTeacehrDayTeacher($aData){
		if(isset($aData['xxt_data'])){
			$aData['xxt_data'] = json_encode($aData['xxt_data']);
		}
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		return $oTeacher->update($aData, array('id' => $aData['id']));
	}

	public function updateTeacherDayStudent($aData){
		$oStudent = new Model(T_TEACHER_DAY_STUDENT);
		return $oStudent->update($aData, array('id' => $aData['id']));
	}

	public function getTeacherRankingList($length){
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		$aTeacherList = $oTeacher->get('', '', '`xin_number` desc,`last_receive_time` asc', 0, $length);
		return $this->_parseTeacherList($aTeacherList);
	}

	public function getStudentRankingList($length){
		$oStudent = new Model(T_TEACHER_DAY_STUDENT);
		$aStudentList = $oStudent->get('', '', '`xin_number` desc,`last_send_time` asc', 0, $length);
		if($aStudentList){
			$aUserIds = array();
			foreach($aStudentList as $aStudent){
				$aUserIds[] = $aStudent['id'];
			}
			$aUserList = getUserListByUserIds($aUserIds, array('personal', 'class'));
			foreach($aStudentList as $key => $aStudent){
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aStudent['id']){
						$aStudentList[$key]['user_info'] = $aUser;
						break;
					}
				}
			}
		}
		return $aStudentList;
	}

	public function getReachNumTeacherList($length = 20){
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		$aTeacherList = $oTeacher->get('', '`reach_100_time`>0', '`reach_100_time` ASC', 0, $length);
		return $this->_parseTeacherList($aTeacherList);
	}

	public function getReachPointNumTeacherList($length = 20, $pointNum = 50){
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		$aTeacherList = $oTeacher->get('', '`xin_number`>=' . $pointNum, '`last_receive_time` DESC', 0, 100);
		if(count($aTeacherList) > $length){
			$aReturnData = array();
			$aKeys = array_rand($aTeacherList, $length);
			if(is_array($aKeys)){
				foreach($aKeys as $key){
					$aReturnData[] = $aTeacherList[$key];
				}
			}else{
				$aReturnData[] = $aTeacherList[$aKeys];
			}
			$aTeacherList = $aReturnData;
		}
		return $this->_parseTeacherList($aTeacherList);
	}

	private function _parseTeacherList($aTeacherList){
		if($aTeacherList){
			foreach($aTeacherList as $key => $aTeacher){
				$aTeacherList[$key]['xxt_data'] = json_decode($aTeacher['xxt_data'], true);
			}
		}
		return $aTeacherList;
	}

	public function getReachPointNumTeacherCount($pointNum = 1){
		$oTeacher = new Model(T_TEACHER_DAY_TEACHER);
		return $oTeacher->count('`xin_number`>=' . $pointNum);
	}
}
