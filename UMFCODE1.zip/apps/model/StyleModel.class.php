<?php
/*
 * 用户访客模型
 */
class StyleModel{
	public function addStyles($aData){
		$oStyle = new Model(T_STYLE);
		return $oStyle->add($aData);
	}

	public function deleteStyles($styleId){
		$oStyle = new Model(T_STYLE);
		return $oStyle->delete(array('id' => $styleId));
	}

	public function getStyleInfoById($styleId){
		$oStyle = new Model(T_STYLE);
		$aStyleInfo = $oStyle->get('', array('id' => $styleId));
		if($aStyleInfo){
			$aStyleInfo = $aStyleInfo[0];
		}
		return $aStyleInfo;
	}

	public function setStyle($aData){
		$oStyle = new Model(T_STYLE);
		return $oStyle->update($aData, array('id' => $aData['id']));
	}

	/*
		'name' => ,
		'status'=>,
		'Is_default'=>,
		'level_limit'=> 0:表示不限制,
		'gold_coin'=> array(1,3),
		'used_count'=>array(1,3),
		'create_time_start'=>,
		'create_time_end'=>,
		'vip_limit'=>0：普通用户，1，2,3对应VIP类型   -1:所有的
	 */
	public function getStyleList($aCondition = array(), $page = 1, $pageSize = 10, $order = '`orders` desc,`id` desc'){
		$offect = ($page - 1) * $pageSize;
		$where = $this->_parseWhere($aCondition);
		$oStyle = new Model(T_STYLE);
		$aStyleList = $oStyle->get('', $where, $order, $offect, $pageSize);
		return $aStyleList;
	}

	public function getStyleCount($aCondition = array()){
		$where = $this->_parseWhere($aCondition);
		$oStyle = new Model(T_STYLE);
		return $oStyle->count($where);
	}

	public function setDefaultStyle($styleId){
		$aData= array('is_default' => 0);
		$oStyle = new Model(T_STYLE);
		$where = '`id` != ' . $styleId;
		return $oStyle->update($aData, $where);
	}

	private function _parseWhere($aCondition){
		$where = '';
		if(!$aCondition){
			return $where;
		}

		if(isset($aCondition['category_id'])){
			$where .= "`category_id`=" . $aCondition['category_id'];
		}

		if(isset($aCondition['name']) && $aCondition['name']){
			$where .= "`name`='" . $aCondition['name'] . "'";
		}

		if(isset($aCondition['status'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`status`=' . $aCondition['status'];
		}

		if(isset($aCondition['is_default'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_default`=' . $aCondition['is_default'];
		}

		if(isset($aCondition['level_limit']) && $aCondition['level_limit']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`level_limit`=' . $aCondition['level_limit'];
		}

		if(isset($aCondition['gold_coin'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`gold_coin`>=' . $aCondition['gold_coin'][0] . ' AND `gold_coin`<' . $aCondition['gold_coin'][1];
		}

		if(isset($aCondition['used_count'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`used_count`>=' . $aCondition['used_count'][0] . ' AND `used_count`<' . $aCondition['used_count'][1];
		}

		if(isset($aCondition['create_time_start']) && $aCondition['create_time_start']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`>=' . $aCondition['create_time_start'];
		}

		if(isset($aCondition['create_time_end']) && $aCondition['create_time_end']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`<=' . $aCondition['create_time_end'];
		}
		if(isset($aCondition['vip_limit']) && $aCondition['vip_limit'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`vip_limit`=' . $aCondition['vip_limit'];
		}
		return $where;
	}


	//取最新的风格一条----林云龙
	public function getNewStyle(){
		$oStyle = new Model(T_STYLE);
		$aStyle = $oStyle->get('','status=1','create_time DESC',0,1);
		if(!$aStyle){
			return $aStyle;
		}
		return $aStyle[0];
	}

	//获取默认皮肤信息
	public function getDefaultStyleInfo(){
		$oStyle = new Model(T_STYLE);
		$aStyleInfo = $oStyle->get('', '`status`=1 AND `is_default`=1');
		if($aStyleInfo){
			$aStyleInfo = $aStyleInfo[0];
		}
		return $aStyleInfo;
	}
}