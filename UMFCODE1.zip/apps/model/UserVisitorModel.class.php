<?php
/*
 * 用户访客模型
 */
class UserVisitorModel{
	public function addUserVisitors($aData){
		$oUserVisitors = new Model(T_USER_VISITOR);
		if(isset($aData['visitors'])){
			$aData['visitors'] = json_encode($aData['visitors']);
		}else{
			$aData['visitors'] = json_encode(array());
		}
		return $oUserVisitors->add($aData);
	}

	public function getUserVisitorsById($userId){
		$oUserVisitors = new Model(T_USER_VISITOR);
		$aUserVisitorsInfo = $oUserVisitors->get('', array('id' => $userId));
		if($aUserVisitorsInfo){
			$aUserVisitorsInfo = $aUserVisitorsInfo[0];
			$aUserVisitorsInfo['visitors'] = json_decode($aUserVisitorsInfo['visitors'], true);
		}
		return $aUserVisitorsInfo;
	}

	public function setUserVisitors($aData){
		$oUserVisitors = new Model(T_USER_VISITOR);
		if(isset($aData['visitors'])){
			$aData['visitors'] = json_encode($aData['visitors']);
		}
		return $oUserVisitors->update($aData, array('id' => $aData['id']));
	}
}