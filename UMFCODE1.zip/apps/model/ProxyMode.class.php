<?php
class ProxyModel{
	const CREATE_TIME = 1;
	const API_CREATE_TIME = 2;
	const SPECIFY_NEXT = 1;
	const SPECIFY_BACK = 1;

	/**
	 * 公告读取方式
	 */
	const GET_NEXT = 1;	//读取下一条公告
	const GET_PREVIOUS = 2;	//读取上一条公告

	/**
	 * 文档类型
	 */
	const DOCUMENT_ANNOUNCEMENT = 1;	//公告文档
	const DOCUMENT_APPLY = 2;	//申请说明文档
	const DOCUMENT_API = 3;	//API文档

	public static function  xCrypt($password){
		return md5($password);
	}

	public function addProxyUser($aData){
		$oProxyUser = new Model(T_PROXY_USER);
		if(isset($aData['password'])){
			$aData['password'] = self::xCrypt($aData['password']);
		}
		if(isset($aData['content'])){
			$aData['content'] = json_encode($aData['content']);
		}
		$proxyUserId = $oProxyUser->add($aData);
		return $proxyUserId;
	}

	public function getProxyUserInfoById($proxyUserId){
		$oProxyUser = new Model(T_PROXY_USER);
		$aProxyUserInfo = $oProxyUser->get('', array('id' => $proxyUserId));
		if($aProxyUserInfo){
			return $aProxyUserInfo[0];
		}
		return $aProxyUserInfo;
	}

	public function getProxyUserInfoByEmailAndPassword($email, $password){
		$oProxyUser = new Model(T_PROXY_USER);
		$password = self::xCrypt($password);
		$aProxyUserInfo = $oProxyUser->get('', "`email`='" . $email . "' AND `password`='" . $password . "'");
		if($aProxyUserInfo){
			return $aProxyUserInfo[0];
		}
		return $aProxyUserInfo;
	}

	public function setProxyUser($aData){
		$oProxyUser = new Model(T_PROXY_USER);
		if(isset($aData['password'])){
			$aData['password'] = self::xCrypt($aData['password']);
		}
		if(isset($aData['content'])){
			$aData['content'] = json_encode($aData['content']);
		}
		$row = $oProxyUser->update($aData, array('id' => $aData['id']));
		return $row;
	}

	public function deleteProxyUserById($proxyUserId){
		$oProxyUser = new Model(T_PROXY_USER);
		$row = $oProxyUser->delete(array('id' => $proxyUserId));
		return $row;
	}

	public function getProxyUserInfoByEmail($email){
		$oProxyUser = new Model(T_PROXY_USER);
		$aProxyUserInfo = $oProxyUser->get('', "`email`='" . $email . "'");
		if($aProxyUserInfo){
			return $aProxyUserInfo[0];
		}else{
			return $aProxyUserInfo;
		}
	}
	
	private function _parserWhereForProxyUserList($email = '', $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $province = 0, $city = 0, $area = 0, $status = 0, $apiIsActive = ''){
		if($email){
			$where = "`email`='" . $email . "'";
		}else{
			$where = '';
			if($telephone){
				$where .= "`telephone`='" . $telephone . "'";
			}
			if($mobile){
				if($where){
					$where .= ' AND ';
				}
				$where .= "`mobile`='" . $mobile . "'";
			}
			if($fax){
				if($where){
					$where .= ' AND ';
				}
				$where .= "`fax`='" . $fax . "'";
			}
			if($commission > 0){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`commission`=' . $commission;
			}
			if($searchCreateTime > 0){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`create_time`=' . $searchCreateTime;
			}
			if($province > 0){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`province`=' . $province;
			}
			if($city > 0){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`city`=' . $city;
			}
			if($area > 0){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`area`=' . $area;
			}
			if($status > 0){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`status`=' . $status;
			}
			if($apiIsActive == '0' || $apiIsActive == '1'){
				if($where){
					$where .= ' AND ';
				}
				$where .= "`api_is_active`='" . $apiIsActive . "'";
			}
		}
		return $where;
	}
	
	public function getProxyStatistic($page, $pageSize, $email = '', $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $province = 0, $city = 0, $area = 0, $status = 0, $apiIsActive = '', $rechargeType = 0, $startTimeStamp = 0, $endTimeStamp = 0){
	
		$aProxyList = $this->getProxyUserList($page, $pageSize, $email, $telephone, $mobile, $fax, $commission, $searchCreateTime, $province, $city, $area, $status, $apiIsActive, $rechargeType, $startTimeStamp, $endTimeStamp);
		
		$aInIds = array();
		foreach($aProxyList as $aProxyid){
			$aInIds[] = $aProxyid['id'];
		}
		$oUser = new Model(T_USER);
		$typeAndTimeWhere = '';
		if($rechargeType){
			$typeAndTimeWhere .= '`type`=' . $rechargeType . ' AND ';
		}
		if($startTimeStamp){
			$typeAndTimeWhere .= '`create_time` >' . $startTimeStamp . ' AND `create_time` < ' . $endTimeStamp . ' AND ';
		
		}
		$rechargeIdWhere = $userIdWhere = '';
		
		$implode = '(' . implode(',', $aInIds) . ')';
		if($aInIds){
			$userIdWhere = '`proxy_id` in' . $implode;
			$rechargeIdWhere = '`proxy_user_id` in' . $implode;	
		}
		$aUserCount = $oUser->get('`proxy_id` as id,count(*) as nums', $userIdWhere, '', '', '', '`proxy_id`');
		$oRecharge = new Model(T_RECHARGE);
		if($rechargeIdWhere){
			$rechargeIdWhere .= ' AND';
		}
		$aRechargeList = $oRecharge->get('`proxy_user_id`,`type`,`pay_type`,count(*) as recharge_nums,sum(`quantity`) as recharge_total_money', $typeAndTimeWhere . $rechargeIdWhere . ' `pay_finish`=1', '','','','`proxy_user_id`,`type`,`pay_type`');
		foreach($aProxyList as $key => $aProxy){
			$aProxyList[$key]['user_count'] = 0;
			foreach($aUserCount as $aUser){
				if($aProxy['id'] == $aUser['id']){
					$aProxyList[$key]['user_count'] = $aUser['nums'];
				}
			}
			if(!$aProxy['commission']){
				$aProxyList[$key]['commission'] = 100;
			}
			$aProxyList[$key]['recharge_nums'] = 0;
			$aProxyList[$key]['recharge_total_money'] = 0;
			$aProxyList[$key]['real_pay_money'] = 0;
			$realPayMoney = 0;
			foreach($aRechargeList as $aRecharge){
				if($aProxy['id'] == $aRecharge['proxy_user_id']){
					if($aRecharge['type'] == 1){  
						$realPayMoney = $aProxyList[$key]['recharge_total_money'] += $aRecharge['recharge_total_money'];
					}else{
						$aProxyList[$key]['recharge_total_money'] += $aRecharge['recharge_total_money'] * 75;
						if($aRecharge['pay_type'] != 3){
							$realPayMoney += $aRecharge['recharge_total_money'] * 75;
						}
					}
					$aProxyList[$key]['recharge_nums'] += $aRecharge['recharge_nums'];
					$aProxyList[$key]['real_pay_money'] = $realPayMoney * $aProxyList[$key]['commission'] / 100;
				}
			}	
		}
		return $aProxyList;
	}
	
	public function getProxyUserList($page, $pageSize, $email = '', $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $province = 0, $city = 0, $area = 0, $status = 0, $apiIsActive = '', $rechargeType = 0, $startTimeStamp = 0, $endTimeStamp = 0){
		$where = $this->_parserWhereForProxyUserList($email, $telephone, $mobile, $fax, $commission, $searchCreateTime, $province, $city, $area, $status, $apiIsActive, $rechargeType, $startTimeStamp, $endTimeStamp);
		$oProxyUser = new Model(T_PROXY_USER);
		$offset = ($page - 1) * $pageSize;
		return $oProxyUser->get('', $where, '', $offset, $pageSize);	
	}

	public function getProxyUserCount($email = '', $telephone = '', $mobile = '', $fax = '', $commission = 0, $searchCreateTime = 0, $province = 0, $city = 0, $area = 0, $status = 0, $apiIsActive = '', $rechargeType = 0, $startTimeStamp = 0, $endTimeStamp = 0){
		$where = $this->_parserWhereForProxyUserList($email, $telephone, $mobile, $fax, $commission, $searchCreateTime, $province, $city, $area, $status, $apiIsActive, $rechargeType, $startTimeStamp, $endTimeStamp);

		$oProxyUser = new Model(T_PROXY_USER);
		$aCountInfo = $oProxyUser->get('count(*) as `nums`', $where);
		if($aCountInfo){
			return $aCountInfo[0]['nums'];
		}else{
			return false;
		}
	}

	public function addProxyAnnouncement($aData){
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		return $oProxyAnnouncement->add($aData);
	}

	public function deleteProxyAnnouncementById($id){
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		return $oProxyAnnouncement->delete(array('id' => $id));
	}

	/**
	 * 读取指定ID的代理商公告
	 * @param int $id 公告ID
	 * @return array 代理商公告
	 */
	public function getProxyAnnouncementInfoById($id){
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		$aProxyAnnouncementInfo = $oProxyAnnouncement->get('', array('id' => $id));
		if($aProxyAnnouncementInfo){
			return $aProxyAnnouncementInfo[0];
		}else{
			return $aProxyAnnouncementInfo;
		}
	}

	/**
	 * 读取指定公告的上一条或下一条公告
	 * @param int $id 公告ID
	 * @param int $type 1:上一条;2:下一条;
	 * @return array 代理商公告
	 */
	public function getPreviousOrNextProxyAnnouncementInfoById($id, $type = 1){
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		$where = '`id` > ' . $id;
		$order = 'id ASC';
		if($type == 2){
			$where = '`id` < ' . $id;
			$order = 'id DESC';
		}

		$aProxyAnnouncementInfo = $oProxyAnnouncement->get('', $where, $order, 0, 1);
		if($aProxyAnnouncementInfo){
			return $aProxyAnnouncementInfo[0];
		}else{
			return $aProxyAnnouncementInfo;
		}

	}

	private function _parserWhereForProxyAnnouncementList($title = '', $publisherId = 0, $createTime = 0, $type = 0){
		$where = '';
		if($title){
			$where .= "`title`='" . $title . "'";
		}

		if($publisherId > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' publisherId=' . $publisherId;
		}

		if($createTime > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' create_time=' . $createTime;
		}

		if($type > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' type=' . $type;
		}
		return $where;

	}


	public function getProxyAnnouncementList($page, $pageSize, $order = ' id DESC', $title = '', $publisherId = 0, $createTime = 0, $type = 0){
		$where = $this->_parserWhereForProxyAnnouncementList($title, $publisherId, $createTime, $type);
		$offset = ($page - 1) * $pageSize;
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		return $oProxyAnnouncement->get('', $where, $order, $offset, $pageSize);

	}



	public function getProxyAnnouncementCount($title = '', $publisherId = 0, $createTime = 0, $type = 0){
		$where = $this->_parserWhereForProxyAnnouncementList($title, $publisherId, $createTime, $type);
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		return $oProxyAnnouncement->count($where);
	}

	public function editProxyAnnouncement($aData){
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		return $oProxyAnnouncement->update($aData, array('id' => $aData['id']));
	}

	public function getSpecifyProxyAnnouncementInfo($proxyAnnouncementId, $specify = self::SPECIFY_NEXT, $type = 0, $order = '`id` desc'){
		$oProxyAnnouncement = new Model(T_PROXY_ANNOUNCEMENT);
		if($specify == self::SPECIFY_NEXT){
			$where = '`id`<' . $proxyAnnouncementId;
		}elseif($specify == self::SPECIFY_BACK){
			$where = '`id`>' . $proxyAnnouncementId;
		}
		if($type){
			$where .= ' AND `type`=' . $type;
		}
		$aProxyAnnouncement = $oProxyAnnouncement->get('', $where, $order, 0, 1);
		if($aProxyAnnouncement){
			return $aProxyAnnouncement[0];
		}else{
			return $aProxyAnnouncement;
		}

	}
//====================================pipeline标识 版本号:1752======================================
}