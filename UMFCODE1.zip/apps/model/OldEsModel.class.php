<?php
/**
 *题目对象模型
 */
class OldEsModel{
	//未审核的题目列表
	public function getEsList($subjectId, $type = 0, $categoryId = 0, $page = 1, $pageSize = 10, $status = 0, $startTime = 0, $endTime = 0, $order = '`index`.`id` ASC'){
		$oDboi = new DBOI();
		$offect = ($page -1) * $pageSize;
		$where = '`index`.`subject_id`=' . $subjectId;
		if($type){
			$where .= ' AND `index`.`type_id`=' . $type;
		}
		if($categoryId){
			$where .= ' AND `index`.`category_id`=' . $categoryId;
		}
		if($status){
			if($status == 1){	//未审核审核
				$where .= ' AND `index`.`status`=0';
			}elseif($status == 2){	//已经审核
				$where .= ' AND `t1`.`approve_time`>0 AND `index`.`status`=5';
				if($startTime){
					$where .= ' AND `t1`.`approve_time`>=' . $startTime;
				}
				if($endTime){
					$where .= ' AND `t1`.`approve_time`<=' . $endTime;
				}
				$order = '`t1`.`approve_time` DESC';
			}
		}
		$fields = '`index`.*, t1.approve_time';
		$aEsIndexList = $oDboi->fields($fields)->table(T_NEW_AND_OLD_ES_RELATION)->leftjoin(T_ES_INDEX, 'as `index` on `t1`.`new_es_id`=`index`.`id`')->where($where)->orderby($order)->limit($offect, $pageSize)->select();
		if($aEsIndexList){
			foreach($aEsIndexList as $aEsIndex){
				$aEsIds[] = $aEsIndex['id'];
			}
			$aEsList = $oDboi->table(T_ES)->where(array('id' => array('in', $aEsIds)))->select();
			foreach($aEsIndexList as &$aEsIndex){
				foreach($aEsList as $aEs){
					if($aEsIndex['id'] == $aEs['id']){
						$aEsIndex['content_text'] = $aEs['content_text'];
						$aEsIndex['content_json'] = $aEs['content_json'];
						break;
					}
				}
				if($aEsIndex['approve_time']){
					$aEsIndex['approve_time'] = date('Y-m-d H:i:s', $aEsIndex['approve_time']);
				}else{
					$aEsIndex['approve_time'] = '---';
				}
				if($aEsIndex['category_id']){
					$aEsIndex['category_tree'] = $this->_getDetailCategoryTree($aEsIndex['category_id']);
				}else{
					$aEsIndex['category_tree'] = '未知目录';
				}
			}
		}
		return $aEsIndexList;
	}

	//未审核的题目数量
	public function getEsCount($subjectId, $type = 0, $categoryId = 0, $status = 0, $startTime = 0, $endTime = 0){
		$oDboi = new DBOI();
		$where = '`index`.`subject_id`=' . $subjectId;
		if($type){
			$where .= ' AND `index`.`type_id`=' . $type;
		}
		if($categoryId){
			$where .= ' AND `index`.`category_id`=' . $categoryId;
		}
		if($status){
			if($status == 1){	//未审核审核
				$where .= ' AND `index`.`status`=0';
			}elseif($status == 2){	//已经审核
				$where .= ' AND `t1`.`approve_time`>0 AND `index`.`status`=5';
				if($startTime){
					$where .= ' AND `t1`.`approve_time`>=' . $startTime;
				}
				if($endTime){
					$where .= ' AND `t1`.`approve_time`<=' . $endTime;
				}
			}
		}
		$aEsCount = $oDboi->fields('count(*) as `nums`')->table(T_NEW_AND_OLD_ES_RELATION)->leftjoin(T_ES_INDEX, 'as `index` on `t1`.`new_es_id`=`index`.`id`')->where($where)->select();
		if($aEsCount){
			return $aEsCount[0]['nums'];
		}
		return $aEsCount;
	}

	/*public function setEs($aData){
		if(isset($aData['status'])){
			$aEsIndexData['status'] = $aData['status'];
		}
		$oEsIndex = new Model(T_ES_INDEX);
		$result = $oEsIndex->update($aEsIndexData, array('id' => $aData['id']));

		return $result;
	}*/

	public function setEs($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aEsIndexData = array();
		$aIndexFields = array(
			'subject_id',
			'category_id',
			'type_id',
			'status',
			'correct_counts',
			'answer_counts',
			'correct_percent',
			'answer_time_total',
		);
		foreach($aIndexFields as $field){
			if(isset($aData[$field])){
				$aEsIndexData[$field] = $aData[$field];
			}
		}
		$result1 = $result2 = 0;
		if($aEsIndexData){
			$result1 = $oDboi->table(T_ES_INDEX)->where(array('id' => $aData['id']))->data($aEsIndexData)->update();
			if($result1 === false){
				return false;
			}elseif($result1){
				if(isset($aData['approve_time'])){
					$aRelation['approve_time'] = $aData['approve_time'];
					$row = $oDboi->table(T_NEW_AND_OLD_ES_RELATION)->where('`new_es_id`=' . $aData['id'])->data($aRelation)->update();
					if(!$row){
						$oDboi->rollBack();
						return false;
					}
				}
			}
		}
		$aEsData = array();
		if(isset($aData['content_json'])){
			$aEsData['content_json'] = $aData['content_json'];
		}
		if(isset($aData['content_text'])){
			$aEsData['content_text'] = $aData['content_text'];
		}
		if(isset($aData['recent_record'])){
			$aEsData['recent_record'] = json_encode($aData['recent_record']);
		}
		if($aEsData){
			$result2 = $oDboi->table(T_ES)->where(array('id' => $aData['id']))->data($aEsData)->update();
			if($result2 === false){
				$oDboi->rollBack();
				return false;
			}
		}
		if($result1 || $result2){
			return 1;
		}
		return 0;
	}

	public function deleteEs($esId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$esIndexRow = $oDboi->table(T_ES_INDEX)->where(array('id' => $esId))->delete();
		if($esIndexRow){
			$esRow = $oDboi->table(T_ES)->where(array('id' => $esId))->delete();
			if($esRow){
				$relationRow = $oDboi->table(T_NEW_AND_OLD_ES_RELATION)->where('`new_es_id`=' . $esId)->delete();
				if($relationRow){
					return $relationRow;
				}else{
					$oDboi->rollBack();
					return false;
				}
			}else{
				$oDboi->rollBack();
				return false;
			}
		}
		return $esIndexRow;
	}

	private function _getDetailCategoryById($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$aEsCategoryInfo = $oEsCategory->get('', array('id' => $categoryId));
		if(!$aEsCategoryInfo){
			return false;
		}
		$this->_detailCategoryList[] = $aEsCategoryInfo[0];
		if($aEsCategoryInfo[0]['parent_id']){
			$this->_getDetailCategoryById($aEsCategoryInfo[0]['parent_id']);
		}
		return $this->_detailCategoryList;
	}

	private function _getDetailCategoryTree($categoryId){
		$this->_detailCategoryList = array();
		$aCategoryList = $this->_getDetailCategoryById($categoryId);
		if(!$aCategoryList){
			return false;
		}
		foreach($aCategoryList as $key => $aCategory){
			$aCategoryRefer[$aCategory['id']] = &$aCategoryList[$key];
		}
		foreach($aCategoryList as $key => $aCategory){
			if(!$aCategory['parent_id']){
				$aTree[] = &$aCategoryList[$key];
			}else{
				$parentId = $aCategory['parent_id'];
				$aParent = &$aCategoryRefer[$parentId];
				$aParent['child'] = &$aCategoryList[$key];
			}
		}
		return $aTree[0]['child'];
	}
}