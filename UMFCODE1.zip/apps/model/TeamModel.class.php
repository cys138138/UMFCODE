<?php
/*
 * 团队赛模型
 * 罗启军
 * 455538375@qq.com
 * 如果你不拼命努力，就永远不知道你就是这个水平---罗启军
 */
class TeamModel{
	public function addPrize($aData){
		$oPrize = new Model(T_TEAM_PRIZE);
		return $oPrize->add($aData);
	}

	public function setPrize($aData){
		$oPrize = new Model(T_TEAM_PRIZE);
		return $oPrize->update($aData, array('id' => $aData['id']));
	}

	public function getPrizeInfoById($id){
		$oPrize = new Model(T_TEAM_PRIZE);
		$aPrizeInfo = $oPrize->get('', array('id' => $id));
		if($aPrizeInfo){
			$aPrizeInfo = $aPrizeInfo[0];
		}
		return $aPrizeInfo;
	}

	public function getPrizeInfoByIds($aIds){
		array_filter($aIds);
		$oPrize = new Model(T_TEAM_PRIZE);
		$aPrizeList= $oPrize->get('', '`id` IN ( ' . implode(',', $aIds) . ')');
		if($aPrizeList){
			$aPrizeResult = array();
			foreach($aIds as $key => $id){
				foreach($aPrizeList as $key2 => $aPrize){
					if($aPrize['id'] == $id){
						$aPrizeResult[$key] = $aPrize;
					}

				}
			}
			return $aPrizeResult;
		}
		return $aPrizeList;
	}

	public function getPrizeList($where, $page = 1, $pageSize = 10){
		$offect = ($page - 1) * $pageSize;
		$oPrize = new Model(T_TEAM_PRIZE);
		$aPrizeList = $oPrize->get('', $where, '`id` ASC', $offect, $pageSize);
		return $aPrizeList;
	}

	public function getPrizeCount($where){
		$oPrize = new Model(T_TEAM_PRIZE);
		return $oPrize->count($where);
	}


	public function getMatchPrizeList($aIds){
		if(!$aIds || !is_array($aIds)){
			return false;
		}
		$where = '`id` IN ( ' . implode(',', $aIds) . ')';
		$oPrize = new Model(T_TEAM_PRIZE);
		$aPrizeList = $oPrize->get('', $where, '`id` ASC');
		return $aPrizeList;
	}

	public function getNewestMatchId($offset){
		$oMatch = new Model(T_TEAM_MATCH);
		$aMatch = $oMatch->get('`id`', '`id`>0', '`id` DESC', $offset, 1);
		if($aMatch){
			return $aMatch[0]['id'];
		}
		return $aMatch;
	}

	public function getMatchById($id){
		$oMatch = new Model(T_TEAM_MATCH);
		$aMatch = $oMatch->get('', array('id' => $id));
		if($aMatch){
			$aMatch = $aMatch[0];
			$aMatch = $this->_decodeMatch($aMatch);
			$oMatch2 = new Model(T_MATCH);
			$aFirst = $oMatch2->get('', '`id`=' . $aMatch['first_match_id']);
			$aSecond = $oMatch2->get('', '`id`=' . $aMatch['second_match_id']);
			$aMatch['first_match'] = $aFirst[0];
			$aMatch['second_match'] = $aSecond[0];
			foreach($aMatch['prizes'] as $key => $prizeId){
				$aMatch[$key] = $this->getPrizeInfoById($prizeId);
			}
			return $aMatch;
		}
		return $aMatch;
	}
	
	public function getPassTeamList($matchId){
		$get = '`id`,`name`,`member_one`,`member_two`,`member_three`,`match_id`,`first_one_score`,`first_two_score`,`first_three_score`,`prize_list`,(`first_one_score`+`first_two_score`+`first_three_score`)  AS `first_total`, `second_one_score`,`second_two_score`,`second_three_score`';
		$aList = $this->getJoinList($get, '`match_id`=' . $matchId . ' AND (`first_one_score` > 0 OR `first_two_score` > 0 OR `first_three_score` > 0)', 1, 1000, '`first_total` DESC');
		
		$aPassList = array('list' => array(), 'end_time' => $aList['end_time']);
		if(isset($aList['list']) && $aList['list']){
			foreach($aList['list'] as $aJoin){
				$firstTotal = $aJoin['first_one_score'];
				$memberCount = 1;
				$passScore = Team::ONE_AVERAGE;
				if($aJoin['member_two']){
					$memberCount = 2;
					$passScore = Team::TWO_AVERAGE;
					$firstTotal += $aJoin['first_two_score'];
				}
				if($aJoin['member_three']){
					$memberCount = 3;
					$passScore = Team::THREE_AVERAGE;
					$firstTotal += $aJoin['first_three_score'];
				}
				if(($firstTotal / $memberCount) >= $passScore){
					$aPassList['list'][] = $aJoin;
				}
			}
		}
		return $aPassList;
	}
	
	public function getAwardTeamList($matchId){
		$get = '`id`,`name`,`member_one`,`member_two`,`member_three`,`match_id`,`prize_list`,(`second_one_score`+`second_two_score`+`second_three_score`)  AS `second_total`, `second_one_score`,`second_two_score`,`second_three_score`';
		$aJoinList = $this->getJoinList($get, '`match_id`=' . $matchId . ' AND (`second_one_score` > 0 OR `second_two_score` > 0 OR `second_three_score` > 0)', 1, 10, '`second_total` DESC');
		return $aJoinList;
	}

	private function _decodeMatch($aData){
		if(isset($aData['prizes'])){
			$aData['prizes'] = json_decode($aData['prizes'], true);
		}
		return $aData;
	}

	public function getMathchList($where, $page = 1, $pageSize = 10, $orderby = '`id` DESC'){
		$offect = ($page - 1) * $pageSize;
		$oTeam = new Model(T_TEAM_MATCH);
		$aMatchList = $oTeam->get('', $where, $orderby, $offect, $pageSize);
		if($aMatchList){
			$aMatchIds = array();
			$oMatch = new Model(T_MATCH);
			foreach($aMatchList as $key => $aMatch){
				$aMatchList[$key] = $this->_decodeMatch($aMatch);
				$aMatchIds[] = $aMatch['id'];
				$aPrizeList = $this->getMatchPrizeList($aMatchList[$key]['prizes']);
				$prizes = '';
				foreach($aPrizeList as $aPrize){
					$prizes .= '，' . $aPrize['name'];
				}
				$aMatchList[$key]['prizes_name'] = $prizes;
				$aFirstMatch = $oMatch->get('`id`,`name`', array('id' => $aMatch['first_match_id']));
				$aSecondMatch = $oMatch->get('`id`,`name`', array('id' => $aMatch['second_match_id']));
				if($aFirstMatch){
					$aMatchList[$key]['first_match'] = $aFirstMatch[0];
				}
				if($aSecondMatch){
					$aMatchList[$key]['second_match'] = $aSecondMatch[0];
				}

			}

			$aCountList = $this->_getTeamCountByMatchId($aMatchIds);
			foreach($aMatchList as $key => $aMatch){
				foreach($aCountList as $aCount){
					if($aMatch['id'] == $aCount['match_id']){
						$aMatchList[$key]['count'] = $aCount['team_nums'];
					}
				}
			}
		}
		return $aMatchList;
	}


	public function addMatch($aData){
		$aData = $this->_parseDataForMatch($aData);
		$oMatch = new Model(T_TEAM_MATCH);
		return $oMatch->add($aData);
	}

	public function setMatch($aData){
		$aData = $this->_parseDataForMatch($aData);
		$oMatch = new Model(T_TEAM_MATCH);
		return $oMatch->update($aData, array('id' => $aData['id']));
	}

	public function getTeamMatchByLitteMatch($matchId){
		$oMatch = new Model(T_TEAM_MATCH);
		$aMatch = $oMatch->get('', '`first_match_id`=' . $matchId . ' OR `second_match_id`=' . $matchId, '`id` DESC', 0, 1);
		if($aMatch){
			$aMatch = $aMatch[0];
			return $aMatch;
		}
		return $aMatch;

	}

	private function _parseDataForMatch($aData){
		if(isset($aData['prizes'])){
			$aData['prizes'] = json_encode($aData['prizes']);
		}
		return $aData;
	}

	public function getJoinById($id){
		$oJoin = new Model(T_TEAM_JOIN);
		$aJoin = $oJoin->get('', array('id' => $id));
		if($aJoin){
			$aJoin = $aJoin[0];
			$aJoin = $this->_decodeJoin($aJoin);
			$aJoin['match'] = $this->getMatchById($aJoin['match_id']);
			$oMatch = new Model(T_MATCH);
			$aSecondMatch = $oMatch->get('`match_end_time`', '`id`=' . $aJoin['match']['second_match_id']);
			$secondTotal = $aJoin['second_one_score'] + $aJoin['second_two_score'] + $aJoin['second_three_score'];
			if($aSecondMatch[0]['match_end_time'] < time() && $secondTotal){
				$rank = $this->_getRank($aJoin['match_id'], $secondTotal);
				if($rank == 1){
					$aJoin['prize_list']['rank'] = $aJoin['match']['prizes']['first'];
				}elseif($rank >= 2 && $rank <= 10){
					$aJoin['prize_list']['rank'] = $aJoin['match']['prizes']['second_tenth'];
				}
			}
			$aJoin['prize'] = $this->getPrizeInfoByIds($aJoin['prize_list']);

			$aIds = array($aJoin['member_one'], $aJoin['member_two'], $aJoin['member_three']);
			$aUserList = $this->_getUserList($aIds);
			if($aUserList){
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aJoin['member_one']){
						$aJoin['info_one'] = $aUser;
					}elseif($aUser['id'] == $aJoin['member_two']){
						$aJoin['info_two'] = $aUser;
					}elseif($aUser['id'] == $aJoin['member_three']){
						$aJoin['info_three'] = $aUser;
					}
				}
			}
		}
		return $aJoin;
	}

	public function getJoinByMatchIdUserId($matchId, $userId){
		$oJoin = new Model(T_TEAM_JOIN);
		$where = '`match_id`=' . $matchId . ' AND (`member_one`=' . $userId . ' OR `member_two`=' . $userId . ' OR `member_three`=' . $userId . ')';
		$aJoin = $oJoin->get('', $where);
		if($aJoin){
			$aJoin = $aJoin[0];
			$aJoin = $this->_decodeJoin($aJoin);
			$aJoin['match'] = $this->getMatchById($aJoin['match_id']);
			$oMatch = new Model(T_MATCH);
			$aSecondMatch = $oMatch->get('`match_end_time`', '`id`=' . $aJoin['match']['second_match_id']);
			$secondTotal = $aJoin['second_one_score'] + $aJoin['second_two_score'] + $aJoin['second_three_score'];
			if($aSecondMatch[0]['match_end_time'] < time() && $secondTotal){
				$rank = $this->_getRank($aJoin['match_id'], $secondTotal);
				if($rank == 1){
					$aJoin['prize_list']['rank'] = $aJoin['match']['prizes']['first'];
				}elseif($rank >= 2 && $rank <= 10){
					$aJoin['prize_list']['rank'] = $aJoin['match']['prizes']['second_tenth'];
				}
			}
			$aJoin['prize'] = $this->getPrizeInfoByIds($aJoin['prize_list']);

			$aIds = array($aJoin['member_one'], $aJoin['member_two'], $aJoin['member_three']);
			$aUserList = $this->_getUserList($aIds);
			if($aUserList){
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aJoin['member_one']){
						$aJoin['info_one'] = $aUser;
					}elseif($aUser['id'] == $aJoin['member_two']){
						$aJoin['info_two'] = $aUser;
					}elseif($aUser['id'] == $aJoin['member_three']){
						$aJoin['info_three'] = $aUser;
					}
				}
			}
		}
		return $aJoin;
	}

	public function checkJoin($matchId, $userId){
		$oJoin = new Model(T_TEAM_JOIN);
		$where = '`match_id`=' . $matchId . ' AND (`member_one`=' . $userId . ' OR `member_two`=' . $userId . ' OR `member_three`=' . $userId . ')';
		$aJoin = $oJoin->get('', $where);
		if($aJoin){
			return $aJoin[0];
		}else{
			return false;
		}
	}

	public function checkCreate($matchId, $userId){
		$oJoin = new Model(T_TEAM_JOIN);
		$where = '`match_id`=' . $matchId . ' AND (`member_one`=' . $userId . ' OR `member_two`=' . $userId . ' OR `member_three`=' . $userId . ')';
		$aJoin = $oJoin->get('', $where);
		if($aJoin){
			$aJoin = $aJoin[0];
			return $aJoin;
		}else{
			return false;
		}
	}

	//$prize('first_lucky'：第一轮幸运奖,'second_lucky':第二轮幸运奖)
	public function countLuckyPrizes($matchId, $prize = 'first_lucky'){
		$oJoin = new Model(T_TEAM_JOIN);
		$aJoinList = $oJoin->get('`prize_list`', '`match_id`=' . $matchId, '', 0, 99999);
		$prizeCount = 0;
		if(!$aJoinList){
			return $prizeCount;
		}

		foreach($aJoinList as $aJoin){
			if(isset($aJoin['prize_list'][$prize]) && $aJoin['prize_list'][$prize] > 0){
				$prizeCount++;
			}
		}
		return $prizeCount;
	}


	private function _getRank($matchId, $secondTotal){
		$oJoin = new Model(T_TEAM_JOIN);
		$rank = $oJoin->count('`match_id`=' . $matchId . ' AND (`second_one_score` + `second_two_score` + `second_three_score`) > ' . $secondTotal);
		return $rank + 1;
	}

	private function _encodeJoin($aData){
		if(isset($aData['prize_list'])){
			$aData['prize_list'] = json_encode($aData['prize_list']);
		}
		return $aData;
	}

	private function _decodeJoin($aData){
		if(isset($aData['prize_list'])){
			$aData['prize_list'] = json_decode($aData['prize_list'], true);
		}
		return $aData;
	}

	public function getJoinList($get, $where, $page = 1, $pageSize = 10, $ordey = '`id` DESC'){
		$offect = ($page - 1) * $pageSize;
		$oJoin = new Model(T_TEAM_JOIN);
		$aJoinList = $oJoin->get($get, $where, $ordey, $offect, $pageSize);
		$oMatch = new Model(T_MATCH);
		$endTime = 0;
		foreach($aJoinList as $key => $aJoin){
			$aJoinList[$key] = $this->_decodeJoin($aJoinList[$key]);
			$aIds = array($aJoin['member_one'], $aJoin['member_two'], $aJoin['member_three']);
			$aJoinList[$key]['user_info'] = $this->_getUserList($aIds);
			$aJoinList[$key]['match'] = $this->getMatchById($aJoin['match_id']);
			if(!$endTime){
				$aSecondMatch = $oMatch->get('`match_end_time`', '`id`=' . $aJoinList[$key]['match']['second_match_id']);
				$endTime = $aSecondMatch[0]['match_end_time'];
			}
	
			$secondTotal = $aJoin['second_one_score'] + $aJoin['second_two_score'] + $aJoin['second_three_score'];
			if($endTime < time() && $secondTotal){
				$rank = $this->_getRank($aJoin['match_id'], $secondTotal);
				if($rank == 1){
					$aJoinList[$key]['prize_list']['rank'] = $aJoinList[$key]['match']['prizes']['first'];
				}elseif($rank >= 2 && $rank <= 10){
					$aJoinList[$key]['prize_list']['rank'] = $aJoinList[$key]['match']['prizes']['second_tenth'];
				}
			}
			$aJoinList[$key]['prize'] = $this->getPrizeInfoByIds($aJoinList[$key]['prize_list']);
		}
		return array('list' => $aJoinList, 'end_time' => $endTime);
	}

	private function _getTeamCountByMatchId($aMatchIds){
		$oJoin = new Model(T_TEAM_JOIN);
		$aCountList = $oJoin->get('`match_id`,count(`id`) as team_nums', '`match_id` IN( ' . implode(',', $aMatchIds) . ')' , '', '', '', '`match_id`');
		return $aCountList;
	}

	private function _getUserList($aUserIds){
		$oPersonal = new Model(T_PERSONAL);
		return $oPersonal->get('`id`,`name`,`profile`', array('id' => array('in', $aUserIds)));
	}

	public function getUserInfoById($id){
		$oPersonal = new Model(T_PERSONAL);
		$aUser = $oPersonal->get('`id`,`name`,`profile`', array('id' => $id));
		if($aUser){
			return $aUser[0];
		}
		return $aUser;
	}

	public function addJoin($aData){
		$oJoin = new Model(T_TEAM_JOIN);
		$aData = $this->_encodeJoin($aData);
		return $oJoin->add($aData);
	}

	public function deleteJoinById($id){
		$oJoin = new Model(T_TEAM_JOIN);
		return $oJoin->delete(array('id' => $id));
	}

	public function setJoin($aData){
		$oJoin = new Model(T_TEAM_JOIN);
		$aData = $this->_encodeJoin($aData);
		return $oJoin->update($aData, array('id' => $aData['id']));
	}


}