<?php
/**
 * 后台用户模型
 */
class ServiceModel{
	public function addFeedback($aData){
		$oFeedback = new Model(T_FEEDBACK);
		return $oFeedback->add($aData);
	}

	public function editFeedback($aData){
		$oFeedback = new Model(T_FEEDBACK);
		return $oFeedback->update($aData, array('id' => $aData['id']));
	}

	public function deleteFeedbackById($id){
		$oFeedback = new Model(T_FEEDBACK);
		if(is_array($id)){
			$where = '`id` in (' . implode(',', $id) . ')';
		}else{
			$where = array('id' => $id);
		}
		return $oFeedback->delete($where);
	}

	public function getFeedbackInfoById($id){
		$oFeedback = new Model(T_FEEDBACK);
		$aFeedbackInfo = $oFeedback->get('', array('id' => $id));
		if($aFeedbackInfo){
			$aFeedbackInfo = $aFeedbackInfo[0];
		}
		return $aFeedbackInfo;
	}

	//$aCondition = array(
	//	'type'	=>
	//	'is_handled'		=>	-1:全部，0：未处理，1：已处理
	//	'start_time'		=>
	//	'end_time'		=>
	//)
	public function getFeedbackList($aCondition, $page, $pageSize){
		$where = $this->_parseWhereForFeedBackList($aCondition);
		$oFeedback = new Model(T_FEEDBACK);
		$offect = ($page - 1) * $pageSize;
		return $oFeedback->get('', $where, '`create_time` DESC', $offect, $pageSize);
	}

	public function getFeedbackCount($aCondition){
		$where = $this->_parseWhereForFeedBackList($aCondition);
		$oFeedback = new Model(T_FEEDBACK);
		return $oFeedback->count($where);
	}

	private function _parseWhereForFeedBackList($aCondition){
		$where = '';
		if(isset($aCondition['type']) && $aCondition['type']){
			$where = '`type`=' . $aCondition['type'];
		}
		if(isset($aCondition['is_handled']) && $aCondition['is_handled'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_handled`=' . $aCondition['is_handled'];
		}
		if(isset($aCondition['start_time']) && $aCondition['start_time']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`>=' . $aCondition['start_time'];
		}
		if(isset($aCondition['end_time']) && $aCondition['end_time']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`<=' . $aCondition['end_time'];
		}
		return $where;
	}
	/**
	 * 通过用户保存在反馈表的Name字段分类取出三种用户的用户名通过user_id
	 * @param type $aFeedBackList 反馈数据数组
	 * @return boolean 含有中文的用户名数组
	 */
	public function converUserNameByName($aFeedBackList){
		$aUserIds = array();
		$aParentIds = array();
		$aTeacherIds = array();
		foreach($aFeedBackList as $aFeedBack){
			if($aFeedBack['user_id']){			
				if($aFeedBack['name'] == '和教育教师'){
					$aTeacherIds[] = $aFeedBack['user_id'];
				}else if($aFeedBack['name'] == '和教育家长'){
					$aParentIds[] = $aFeedBack['user_id'];
				}else{
					$aUserIds[] = $aFeedBack['user_id'];
				}
			}
		}
		$aUserList = array();
		$aParentList = array();
		$aTeacherList = array();
		if($aUserIds){
			$aUserList = getUserListByUserIds($aUserIds);
			if($aUserList === false){
				return false;
			}
		}
		if($aTeacherIds){
			$oTeacher = new Model(T_TEACHER);
			$aTeacherList = $oTeacher->get('`id`,`name`', array('id' => array('in', $aTeacherIds)));
			if($aTeacherList === false){
				return false;
			}
		}
		if($aParentIds){
			$oParent = new Model(T_PARENT);
			$aParentList = $oParent->get('`id`,`name`', array('id' => array('in', $aParentIds)));
			if($aParentList === false){
				return false;
			}
		}
		foreach($aFeedBackList as $key => $aBack){
			$aFeedBackList[$key]['name'] = '未知';
			if($aBack['name'] == '和教育教师'){
				foreach($aTeacherList as $aTeacher){
					if($aBack['user_id'] == $aTeacher['id']){
						$aFeedBackList[$key]['name'] = $aTeacher['name'];
						break;
					}
				}
			}elseif($aBack['name'] == '和教育家长'){
				foreach($aParentList as $aParent){
					if($aBack['user_id'] == $aParent['id']){
						$aFeedBackList[$key]['name'] = $aParent['name'];
						break;
					}
				}
			}else{
				foreach($aUserList as $aUser){
					if($aBack['user_id'] == $aUser['id']){
						$aFeedBackList[$key]['name'] = $aUser['name'];
						break;
					}
				}
			}
		}
		return $aFeedBackList;
	}
}