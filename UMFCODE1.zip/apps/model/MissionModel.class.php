<?php
/**
 * 关卡模型
 */
class MissionModel{
	const TASK_NO_FINISHED = 0;
	const TASK_IS_FINISHED = 1;
	const MISSION_NO_PASSED = 0;
	const MISSION_IS_PASSED = 1;
	const OFFICIAL_ES_STATU = 5;

	public function getMissionList($userId, $subjectId,  $page, $pageSize){
		$oMission = new Model(T_MISSION);
		$offset = ($page - 1) * $pageSize;
		$aMissionList = $oMission->get('', '`subject_id`=' . $subjectId, '`orders` ASC', $offset, $pageSize);
		if($aMissionList){
			$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
			foreach($aMissionList as &$aMission){
				$aMission['challenge_es_count'] = json_decode($aMission['challenge_es_count'], true);
				$aMission['task_content'] = json_decode($aMission['task_content'], true);
				if($aMission['category_ids']){
					$aMission['category_ids'] = explode(',', $aMission['category_ids']);
				}else{
					$aMission['category_ids'] = array();
				}
				if($aMission['recent_record']){
					$aMission['recent_record'] = json_decode($aMission['recent_record'], true);
				}else{
					$aMission['recent_record'] = array();
				}
				$aMissionUserRelationIndexInfo = $oMissionUserRelationIndex->get('', '`user_id`=' . $userId . ' AND `mission_id`=' . $aMission['id']);
				if($aMissionUserRelationIndexInfo === false){
					return false;
				}elseif($aMissionUserRelationIndexInfo){
					$aMission['is_task_finish'] = $aMissionUserRelationIndexInfo[0]['is_task_finish'];
					$aMission['is_pass'] = $aMissionUserRelationIndexInfo[0]['is_pass'];
					//$aMission['duration'] = $aMissionUserRelationIndexInfo[0]['duration'];
					$aMission['create_time'] = $aMissionUserRelationIndexInfo[0]['create_time'];
				}
			}
		}
		return $aMissionList;
	}

	public function getMissionCount($subjectId, $aCategoryIds = array()){
		$oMission = new Model(T_MISSION);
		$where = '`subject_id`=' . $subjectId;
		if($aCategoryIds){
			$where .= ' AND `category_ids` in (' . implode(',', $aCategoryIds) . ')';
		}
		$aMissionCount = $oMission->get('count(*) as `nums`', $where);
		if($aMissionCount){
			return $aMissionCount[0]['nums'];
		}
		return $aMissionCount;
	}

	/**
	 * 获得用户最后一个解锁的关卡
	 */
	public function getLastDeblockingMissionOrders($userId, $subjectId){
		$oDboi = new DBOI();
		//$where = '`mission_user`.`user_id`=' . $userId . ' AND `mission_user`.`is_pass`=' . self::MISSION_IS_PASSED . ' AND `t1`.`subject_id`=' . $subjectId;
		$where = '`mission_user`.`user_id`=' . $userId . ' AND `t1`.`subject_id`=' . $subjectId . ' AND `t1`.`is_forbidden`!=1';
		$aPassMissionInfo = $oDboi->fields('`t1`.`orders`,`mission_user`.`is_pass`')->table(T_MISSION)->leftjoin(T_MISSION_USER_RELATION_INDEX, 'as `mission_user` on `t1`.`id`=`mission_user`.`mission_id`')->where($where)->orderby('`t1`.`orders` desc')->limit(0, 1)->select();
		if($aPassMissionInfo){
			if($aPassMissionInfo[0]['is_pass'] != 1){
				return $aPassMissionInfo[0]['orders'];
			}
			$aLastDeblockingMissionInfo = $oDboi->fields('`orders`')->table(T_MISSION)->where('`subject_id`=' . $subjectId . ' AND orders>' . $aPassMissionInfo[0]['orders'] . ' AND `is_forbidden`!=1')->orderby('`orders` ASC')->limit(0, 1)->select();
		}else{
			return 0;
			//$aLastDeblockingMissionInfo = $oDboi->fields('`orders`')->table(T_MISSION)->where('`subject_id`=' . $subjectId . ' AND `is_forbidden`!=1')->orderby('`orders` ASC')->limit(0, 1)->select();
		}
		if($aLastDeblockingMissionInfo === false){
			return false;
		}elseif($aLastDeblockingMissionInfo){
			return $aLastDeblockingMissionInfo[0]['orders'];
		}else{
			return $aPassMissionInfo[0]['orders'];
		}
	}

	public function isOrdersExist($subjectId, $orders){
		$oMission = new Model(T_MISSION);
		return $oMission->count('`orders`=' . $orders . ' AND `subject_id`=' . $subjectId . ' AND `is_forbidden`!=1');
	}

	public function addMission($aData){
		$oMission = new Model(T_MISSION);
		if(isset($aData['task_content'])){
			$aData['task_content'] = json_encode($aData['task_content']);
		}else{
			$aData['task_content'] = json_encode(array());
		}
		if(isset($aData['challenge_es_count'])){
			$aData['challenge_es_count'] = json_encode($aData['challenge_es_count']);
		}else{
			$aData['challenge_es_count'] = json_encode(array());
		}
		if(isset($aData['category_ids']) && $aData['category_ids']){
			$aData['category_ids'] = implode(',', $aData['category_ids']);
		}else{
			$aData['category_ids'] = '';
		}
		if(isset($aData['recent_record']) && $aData['recent_record']){
			$aData['recent_record'] = json_encode($aData['recent_record']);
		}else{
			$aData['recent_record'] = json_encode(array());
		}
		return $oMission->add($aData);
	}

	public function setMission($aData){
		$oMission = new Model(T_MISSION);
		if(isset($aData['task_content'])){
			$aData['task_content'] = json_encode($aData['task_content']);
		}
		if(isset($aData['challenge_es_count'])){
			$aData['challenge_es_count'] = json_encode($aData['challenge_es_count']);
		}
		if(isset($aData['category_ids']) && $aData['category_ids']){
			$aData['category_ids'] = implode(',', $aData['category_ids']);
		}
		if(isset($aData['recent_record'])){
			$aData['recent_record'] = json_encode($aData['recent_record']);
		}
		return $oMission->update($aData, array('id' => $aData['id']));
	}

	public function deleteMissionById($missionId){
		$oMission = new Model(T_MISSION);
		return $oMission->delete(array('id' => $missionId));
	}
//====================================pipeline标识 版本号:1752======================================

	public function getNextMissionInfo($subjectId, $orders){
		$oMission = new Model(T_MISSION);
		$where = '`subject_id`=' . $subjectId . ' AND `orders`>' . $orders . ' AND `is_forbidden`!=1';
		$aMissionInfo = $oMission->get('', $where, '`orders` asc', 0, 1);
		if($aMissionInfo){
			$aMissionInfo = $aMissionInfo[0];
			$aMissionInfo['challenge_es_count'] = json_decode($aMissionInfo['challenge_es_count'], true);
			$aMissionInfo['task_content'] = json_decode($aMissionInfo['task_content'], true);
			$aMissionInfo['category_ids'] = explode(',', $aMissionInfo['category_ids']);
			if($aMissionInfo['recent_record']){
				$aMissionInfo['recent_record'] = json_decode($aMissionInfo['recent_record'], true);
			}else{
				$aMissionInfo['recent_record'] = array();
			}
		}
		return $aMissionInfo;
	}

	public function getOriginalMissionList($subjectId = 0, $page = 1, $pageSize = null, $manager = 0, $aCategoryIds = array(), $name = ''){
		$oMission = new Model(T_MISSION);
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if($subjectId){
			$where = '`subject_id`=' . $subjectId;
		}
		if(!$manager){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_forbidden`!=1';
		}else{
			if($aCategoryIds){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`category_ids` in (' . implode(',', $aCategoryIds) . ')';
			}
			if($name){
				if($where){
					$where .= ' AND ';
				}
				$where .= "`name`='" . $name . "'";
			}
		}
		$aMissionList = $oMission->get('', $where, '`grade` ASC, `orders` ASC', $offect, $pageSize);
		if($aMissionList){
			foreach($aMissionList as &$aMission){
				$aMission['challenge_es_count'] = json_decode($aMission['challenge_es_count'], true);
				$aMission['task_content'] = json_decode($aMission['task_content'], true);
				if($aMission['category_ids']){
					$aMission['category_ids'] = explode(',', $aMission['category_ids']);
				}else{
					$aMission['category_ids'] = array();
				}
			}
		}
		return $aMissionList;
	}

	public function getMissionInfoById($missionId){
		$oMission = new Model(T_MISSION);
		$aMissionInfo = $oMission->get('', array('id' => $missionId));
		if($aMissionInfo){
			$aMissionInfo = Mission::convertMissionList($aMissionInfo);
			$aMissionInfo = $aMissionInfo[0];
			$aMissionInfo['challenge_es_count'] = json_decode($aMissionInfo['challenge_es_count'], true);
			$aMissionInfo['task_content'] = json_decode($aMissionInfo['task_content'], true);
			if($aMissionInfo['category_ids']){
				$aMissionInfo['category_ids'] = explode(',', $aMissionInfo['category_ids']);
			}else{
				$aMissionInfo['category_ids'] = array();
			}
			if($aMissionInfo['recent_record']){
				$aMissionInfo['recent_record'] = json_decode($aMissionInfo['recent_record'], true);
			}else{
				$aMissionInfo['recent_record'] = array();
			}
		}
		return $aMissionInfo;
	}
	//在指定目录下随机抽N题出来
	public function getRandomEsListByMissionExerciseCondition($aCategoryIds, $esCount, $aExceptEsIds = array(), $aPointType = array()){
		$categoryIds = implode(',', $aCategoryIds);
		$oDboi = new DBOI();
		//$where = '`category_id` in (' . $categoryIds . ') AND `status`=' . self::OFFICIAL_ES_STATU . ' AND `type_id` not in(6,7)';
		if($aPointType){
			$where = '`category_id` in (' . $categoryIds . ') AND `status`=' . self::OFFICIAL_ES_STATU . ' AND `type_id` in (' . implode(',', $aPointType) . ')';
		}else{
			$where = '`category_id` in (' . $categoryIds . ') AND `status`=' . self::OFFICIAL_ES_STATU;
		}

		if($aExceptEsIds){
			$exceptEsIds = implode(',', $aExceptEsIds);
			$where .= ' AND `id` not in (' . $exceptEsIds . ')';
		}

		//$where = 'id = 138457';	//英语单选题
		//$where = 'id = 47118';		//英语多选题
		//$where = 'id = 140669';	//英语填空题
		//$where = 'id = 110513';	//英语选词填空题
		//$where = 'id = 93661';		//英语完形填空
		//$where = 'id = 93796';		//英语完形填空
		//$where = 'id = 121731';		//临时

		$aAllEsIndexlist = $oDboi->fields('')->table(T_ES_INDEX)->where($where)->select();
		if(!$aAllEsIndexlist){
			return $aAllEsIndexlist;
		}
		if(count($aAllEsIndexlist) > $esCount){
			$aKeys = array_rand($aAllEsIndexlist, $esCount);
			if(is_array($aKeys)){
				foreach($aKeys as $Key){
					$aEsIndexlist[] = $aAllEsIndexlist[$Key];
				}
			}else{
				$aEsIndexlist[] = $aAllEsIndexlist[$aKeys];
			}
		}else{
			$aEsIndexlist = $aAllEsIndexlist;
		}
		unset($aAllEsIndexlist);
		$esIds = '';
		foreach($aEsIndexlist as $aEs){
			$esIds .= $aEs['id'] . ',';
		}
		$esIds = substr($esIds, 0, -1);
		$aEslist = $oDboi->table(T_ES)->where(array('id' => array('in', $esIds)))->select();
		foreach($aEsIndexlist as &$aEsIndex){
			foreach($aEslist as $aEs){
				if($aEsIndex['id'] == $aEs['id']){
					$aEsIndex['content_json'] = $aEs['content_json'];
					$aEsIndex['content_text'] = $aEs['content_text'];
					if($aEs['recent_record']){
						$aEsIndex['recent_record'] = json_decode($aEs['recent_record'], true);
					}else{
						$aEsIndex['recent_record'] = array();
					}
				}
			}
		}
		return $aEsIndexlist;
	}

	public function getUserMissionInfoById($userMissionId){
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserMissionIndexInfo = $oUserMissionIndex->get('', array('id' => $userMissionId));
		if($aUserMissionIndexInfo){
			$oUserMission = new Model(T_MISSION_USER_RELATION);
			$aUserMissionIndexInfo = $aUserMissionIndexInfo[0];
			$aUserMissionInfo = $oUserMission->get('', array('id' => $aUserMissionIndexInfo['id']));
			if($aUserMissionInfo === false){
				return false;
			}elseif($aUserMissionInfo){
				$aUserMissionIndexInfo['task_process'] = $aUserMissionInfo[0]['task_process'];
				if($aUserMissionInfo[0]['current_challenge_process']){
					$aUserMissionIndexInfo['current_challenge_process'] = json_decode($aUserMissionInfo[0]['current_challenge_process'], true);
				}else{
					$aUserMissionIndexInfo['current_challenge_process'] = array();
				}
				$aUserMissionIndexInfo['challenge_history'] = json_decode($aUserMissionInfo[0]['challenge_history'], true);
			}else{
				return false;
			}
		}
		return $aUserMissionIndexInfo;
	}

	//得到用户在这一关的记录
	public function getUserMissionInfo($missionId, $userId){
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`user_id`=' . $userId . ' AND `mission_id`=' . $missionId;
		$aUserMissionIndexInfo = $oUserMissionIndex->get('', $where);
		if($aUserMissionIndexInfo){
			$oUserMission = new Model(T_MISSION_USER_RELATION);
			$aUserMissionIndexInfo = $aUserMissionIndexInfo[0];
			$aUserMissionInfo = $oUserMission->get('', array('id' => $aUserMissionIndexInfo['id']));
			if($aUserMissionInfo === false){
				return false;
			}elseif($aUserMissionInfo){
				$aUserMissionIndexInfo['task_process'] = $aUserMissionInfo[0]['task_process'];
				if($aUserMissionInfo[0]['current_challenge_process']){
					$aUserMissionIndexInfo['current_challenge_process'] = json_decode($aUserMissionInfo[0]['current_challenge_process'], true);
				}else{
					$aUserMissionIndexInfo['current_challenge_process'] = array();
				}
				$aUserMissionIndexInfo['challenge_history'] = json_decode($aUserMissionInfo[0]['challenge_history'], true);
			}else{
				return false;
			}
		}
		return $aUserMissionIndexInfo;
	}

	public function getUserMissionDetailInfo($missionId, $userId){
		$oMission = new Model(T_MISSION);
		$aMissionInfo = $oMission->get('`id`,`name`,`grade`,`challenge_count`,`challenge_success_count`,`recent_record`', array('id' => $missionId));
		if(!$aMissionInfo){
			return $aMissionInfo;
		}
		$aMissionInfo = Mission::convertMissionList($aMissionInfo);
		$aMissionInfo = $aMissionInfo[0];
		$aMissionInfo['recent_record'] = json_decode($aMissionInfo['recent_record'], true);
		$aUserIds = array();
		foreach($aMissionInfo['recent_record'] as $aRecord){
			$aUserIds[] = $aRecord['user_id'];
		}
		if($aUserIds){
			$aUserList = getUserListByUserIds($aUserIds);
		}else{
			$aUserList = array();
		}
		unset($aMissionInfo['recent_record']);
		$aMissionInfo['recent_user_list'] = $aUserList;
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`user_id`=' . $userId . ' AND `mission_id`=' . $missionId;
		$aUserMissionIndexInfo = $oUserMissionIndex->get('`id`,`es_count`,`es_correct_count`,`es_repair_count`,`score`,`is_task_finish`,`task_finish_time`,`is_pass`,`pass_time`', $where);
		if($aUserMissionIndexInfo === false){
			return false;
		}elseif(!$aUserMissionIndexInfo){
			$aMissionInfo['user_mission_info'] = array();
		}else{
			$aUserMissionIndexInfo = $aUserMissionIndexInfo[0];
			$oUserMissionRelation = new Model(T_MISSION_USER_RELATION);
			$aUserMissionRelationInfo =	$oUserMissionRelation->get('`challenge_history`', array('id' => $aUserMissionIndexInfo['id']));
			if($aUserMissionRelationInfo === false){
				return false;
			}elseif(!$aUserMissionRelationInfo){
				$aUserMissionIndexInfo['challenge_times'] = 0;
			}else{
				$aUserMissionIndexInfo['challenge_times'] = count(json_decode($aUserMissionRelationInfo[0]['challenge_history']));
			}
			$aMissionInfo['user_mission_info'] = $aUserMissionIndexInfo;
		}
		return $aMissionInfo;
	}

	public function addUserMission($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aIndexFields = array(
			'user_id',
			'mission_id',
			'is_task_finish',
			'is_pass',
			'es_count',
			'es_correct_count',
			//'start_time',
			//'duration',
			//'use_blood',
			'score',
			'create_time',
			'pass_time',
			'best_score_time',
			'last_es_id'
		);
		foreach($aIndexFields as $field){
			if(isset($aData[$field])){
				$aUserMissionIndex[$field] = $aData[$field];
			}
		}
		$userMissionId = $oDboi->table(T_MISSION_USER_RELATION_INDEX)->data($aUserMissionIndex)->insert();
		if($userMissionId){
			$aUserMission['id'] = $userMissionId;
			if(isset($aData['task_process'])){
				$aUserMission['task_process'] = $aData['task_process'];
			}else{
				$aUserMission['task_process'] = 0;
			}
			if(isset($aData['current_challenge_process'])){
				$aUserMission['current_challenge_process'] = json_encode($aData['current_challenge_process']);
			}else{
				$aUserMission['current_challenge_process'] = json_encode(array());
			}
			if(isset($aData['challenge_history'])){
				$aUserMission['challenge_history'] = json_encode($aData['challenge_history']);
			}else{
				$aUserMission['challenge_history'] = json_encode(array());
			}
			$reuslt = $oDboi->table(T_MISSION_USER_RELATION)->data($aUserMission)->insert();
			if(!$reuslt){
				$oDboi->rollBack();
				return false;
			}
		}
		return $userMissionId;
	}

	public function setUserMission($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aIndexFields = array(
			'is_task_finish',
			'is_pass',
			'es_count',
			'es_correct_count',
			//'start_time',
			//'duration',
			//'use_blood',
			'score',
			'create_time',
			'best_score_time',
			'pass_time',
			'last_es_id',
			'task_finish_time',
			'lottery_draw_status'
		);
		$aUserMissionIndex = array();
		$aUserMission = array();
		if(isset($aData['task_process'])){
			$aUserMission['task_process'] = $aData['task_process'];
		}
		if(isset($aData['current_challenge_process'])){
			$aUserMission['current_challenge_process'] = json_encode($aData['current_challenge_process']);
		}
		if(isset($aData['challenge_history'])){
			$aUserMission['challenge_history'] = json_encode($aData['challenge_history']);
		}
		if(isset($aData['break_record'])){
			$aUserMission['break_record'] = json_encode($aData['break_record']);
		}
		foreach($aIndexFields as $field){
			if(isset($aData[$field])){
				$aUserMissionIndex[$field] = $aData[$field];
			}
		}
		$where = array('id' => $aData['id']);
		$row = $result = 0;
		if($aUserMissionIndex){
			$row = $oDboi->table(T_MISSION_USER_RELATION_INDEX)->where($where)->data($aUserMissionIndex)->update();
			if($row === false){
				return false;
			}
		}
		if($aUserMission){
			$reuslt = $oDboi->table(T_MISSION_USER_RELATION)->where($where)->data($aUserMission)->update();
			if($reuslt === false){
				return false;
			}
		}
		if($row){
			return $row;
		}else{
			return $result;
		}
	}

	public function getRandomEsListForChallenge($aCategoryIds, $aChallengeEsCount){
		if(!$aChallengeEsCount || !$aCategoryIds){
			return array();
		}

		$categoryIds = implode(',', $aCategoryIds);
		$oEsIndex = new Model(T_ES_INDEX);
		$oEs = new Model(T_ES);
		$aEsResultList = array();
		foreach($aChallengeEsCount as $aChallengeEs){
			$esTypeId = $aChallengeEs['es_type_id'];
			$esCount = $aChallengeEs['es_count'];
			if($esTypeId == 0){
				$where = '`category_id` in (' . $categoryIds . ')' . ' AND `status`=' . self::OFFICIAL_ES_STATU;
			}else{
				$where = '`category_id` in (' . $categoryIds . ') AND `type_id`=' . $esTypeId . ' AND `status`=' . self::OFFICIAL_ES_STATU;
			}
			$aAllEsIndexlist = $oEsIndex->get('', $where);
			if($aAllEsIndexlist === false){
				return $aAllEsIndexlist;
			}
			$aEsIndexlist = array();
			if(count($aAllEsIndexlist) > $esCount){
				$aKeys = array_rand($aAllEsIndexlist, $esCount);
				if(is_array($aKeys)){
					foreach($aKeys as $Key){
						$aEsIndexlist[] = $aAllEsIndexlist[$Key];
					}
				}else{
					$aEsIndexlist[] = $aAllEsIndexlist[$aKeys];
				}
			}else{
				$aEsIndexlist = $aAllEsIndexlist;
			}
			unset($aAllEsIndexlist);
			$aEsResultList = array_merge($aEsResultList, $aEsIndexlist);
		}
		if($aEsResultList){
			$esIds = '';
			foreach($aEsResultList as $aEs){
				$esIds .= $aEs['id'] . ',';
			}
			$esIds = substr($esIds, 0, -1);
			$aEslist = $oEs->get('', array('id' => array('in', $esIds)));
			foreach($aEsResultList as &$aEsIndex){
				foreach($aEslist as $aEs){
					if($aEsIndex['id'] == $aEs['id']){
						$aEsIndex['content_json'] = $aEs['content_json'];
						$aEsIndex['content_text'] = $aEs['content_text'];
						if($aEs['recent_record']){
							$aEsIndex['recent_record'] = json_decode($aEs['recent_record'], true);
						}else{
							$aEsIndex['recent_record'] = array();
						}
					}
				}
			}
		}
		return $aEsResultList;
	}

	public function initUserMission($aMissionIds, $userId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		foreach($aMissionIds as $missionId){
			$aData = array();
			$aData['user_id'] = $userId;
			$aData['mission_id'] = $missionId;
			$aData['is_task_finish'] = self::TASK_NO_FINISHED;
			$aData['is_pass'] = self::MISSION_NO_PASSED;
			$aData['es_count'] = 0;
			$aData['es_correct_count'] = 0;
			//$aData['start_time'] = 0;
			//$aData['duration'] = 0;
			//$aData['use_blood'] = 0;
			$aData['score'] = 0;
			$aData['create_time'] = 0;
			$aData['pass_time'] = 0;
			$aData['best_score_time'] = 0;
			$aData['last_es_id'] = 0;
			$missionUserId = $oDboi->table(T_MISSION_USER_RELATION_INDEX)->data($aData)->insert();
			if($missionUserId){
				$aData = array();
				$aData['id'] = $missionUserId;
				$aData['task_process'] = 0;
				$aData['current_challenge_process'] = json_encode(array());
				$aData['challenge_history'] = json_encode(array());
				$result = $oDboi->table(T_MISSION_USER_RELATION)->data($aData)->insert();
				if(!$result){
					$oDboi->rollBack();
					return false;
				}
			}else{
				$oDboi->rollBack();
				return false;
			}
		}
		return $missionUserId;
	}

	public function getPreviousOrders($subjectId, $orders){
		$oMission = new Model(T_MISSION);
		$aMissionInfo = $oMission->get('`orders`', '`subject_id`=' .$subjectId . ' AND `orders` <' . $orders, '`orders` DESC', 0, 1);
		if($aMissionInfo){
			return $aMissionInfo[0]['orders'];
		}
		return $aMissionInfo;
	}

	public function getLastOrders($subjectId){
		$oMission = new Model(T_MISSION);
		$aMissionInfo = $oMission->get('`orders`', '`subject_id`=' .$subjectId, '`orders` DESC', 0, 1);
		if($aMissionInfo){
			return $aMissionInfo[0]['orders'];
		}
		return $aMissionInfo;
	}

	public function getMissionScoreRanking($missionId, $score){
		$oUserMission = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`mission_id`=' . $missionId . ' AND `score`>' . $score;
		$count = $oUserMission->count($where);
		if($count === false){
			return false;
		}
		return $count + 1;
	}

	public function getCurrentMissionPage($userId, $pageSize, $subjectId = 0){
		$oMission = new Model(T_MISSION);
		if($subjectId){
			//用户当前关卡的排序
			$userOrders = $this->getLastDeblockingMissionOrders($userId, $subjectId);
			if($userOrders === false){
				return false;
			}
			//排当前关卡前面有多少关
			$aheadOrdersCount = $oMission->count('`subject_id`=' . $subjectId . ' AND `orders`<' . $userOrders . ' AND `is_forbidden`!=1');
			if($aheadOrdersCount === false){
				return false;
			}
			$aheadPage = $aheadOrdersCount / $pageSize;
			$page = ceil($aheadPage);
			if($page == $aheadPage){
				return $page + 1;
			}else{
				return $page;
			}
		}else{
			$aReturn = array();
			$aSubjectList = $GLOBALS['SUBJECT'];
			foreach($aSubjectList as $key => $val){
				$userOrders = $this->getLastDeblockingMissionOrders($userId, $key);
				if($userOrders === false){
					return false;
				}
				//排当前关卡前面有多少关
				$aheadOrdersCount = $oMission->count('`subject_id`=' . $key . ' AND `orders`<' . $userOrders . ' AND `is_forbidden`!=1');
				if($aheadOrdersCount === false){
					return false;
				}
				$aheadPage = $aheadOrdersCount / $pageSize;
				$page = ceil($aheadPage);
				if($page == $aheadPage){
					$aReturn[$key] = $page + 1;
				}else{
					$aReturn[$key] = $page;
				}
			}
			return $aReturn;
		}
	}


	public function getUserMissionList($userId, $subjectId, $page = 1, $pageSize = 10, $order = '`grade` ASC, `orders` ASC'){
		$offect = ($page - 1) * $pageSize;
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`orders`,`grade`', '`subject_id`=' . $subjectId . ' AND `is_forbidden`!=1', $order, $offect, $pageSize);
		if($aMissionList){
			//当前关卡的排序
			$currentOrder = $this->getLastDeblockingMissionOrders($userId, $subjectId);
			if($currentOrder === false){
				return false;
			}
			foreach($aMissionList as $aMission){
				$aMissionIds[] = $aMission['id'];
			}
			$aMissionUserRelationList = $this->_getMissionUserRelationList($userId, $aMissionIds);
			if($aMissionUserRelationList === false){
				return false;
			}
			foreach($aMissionList as &$aMission){
				if($aMission['orders'] < $currentOrder){
					$aMission['can_enter'] = 1;
				}elseif($aMission['orders'] == $currentOrder){
					$aMission['can_enter'] = 2;
				}else{
					$aMission['can_enter'] = 0;
				}
				foreach($aMissionUserRelationList as $aMissionUserRelation){
					if($aMissionUserRelation['mission_id'] == $aMission['id']){
						$aMission['is_task_finish'] = $aMissionUserRelation['is_task_finish'];
						$aMission['is_pass'] = $aMissionUserRelation['is_pass'];
						$aMission['create_time'] = $aMissionUserRelation['create_time'];
						$aMission['score'] = $aMissionUserRelation['score'];
						//$aMission['challenge_history'] = $aMissionUserRelation['challenge_history'];
					}
				}
			}
		}

		if($aMissionList){
			$aMissionList = Mission::convertMissionList($aMissionList);
		}
		return $aMissionList;
	}

	public function getUserMissionCount($subjectId = 0){
		$oMission = new Model(T_MISSION);
		$where = '`is_forbidden`!=1';
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		return $oMission->count($where);
	}

	private function _getMissionUserRelationList($userId, $aMissionIds){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aMissionUserRelationIndexList = $oMissionUserRelationIndex->get('', '`user_id`=' . $userId . ' AND `mission_id` in (' . implode(',', $aMissionIds) . ')');
		if($aMissionUserRelationIndexList){
			foreach($aMissionUserRelationIndexList as $aMissionUserRelationIndex){
				$aRelationIds[] = $aMissionUserRelationIndex['id'];
			}
			$oMissionUserRelation = new Model(T_MISSION_USER_RELATION);
			$aMissionUserRelationList = $oMissionUserRelation->get('', array('id' => array('in', $aRelationIds)));
			if($aMissionUserRelationList === false){
				return false;
			}
			foreach($aMissionUserRelationIndexList as &$aMissionUserRelationIndex){
				foreach($aMissionUserRelationList as $aMissionUserRelation){
					if($aMissionUserRelation['id'] == $aMissionUserRelationIndex['id']){
						$aMissionUserRelationIndex['challenge_history'] = json_decode($aMissionUserRelation['challenge_history'], true);
					}
				}
			}
		}
		return $aMissionUserRelationIndexList;
	}

	public function getCurrentMission($userId){
		$oMission = new Model(T_MISSION);
		$where = '';
		foreach($GLOBALS['SUBJECT'] as $subjectId => $value){
			$userOrders = $this->getLastDeblockingMissionOrders($userId, $subjectId);
			if($where){
				$where .= ' OR ';
			}
			$where .= '(`subject_id`=' . $subjectId . ' AND `orders`=' . $userOrders . ')';
		}
		$aMissionList = $oMission->get('', $where);
		if(!$aMissionList){
			return $aMissionList;
		}
		$aMissionIds = array();
		foreach($aMissionList as $aMission){
			$aMissionIds[] = $aMission['id'];
		}
		$aMissionUserRelationList = $this->_getMissionUserRelationList($userId, $aMissionIds);
		if($aMissionUserRelationList === false){
			return false;
		}
		$aReturnData = array();
		foreach($aMissionList as $aMission){
			$aMission['challenge_es_count'] = json_decode($aMission['challenge_es_count'], true);
			$aMission['task_content'] = json_decode($aMission['task_content'], true);
			if($aMission['category_ids']){
				$aMission['category_ids'] = explode(',', $aMission['category_ids']);
			}else{
				$aMission['category_ids'] = array();
			}
			if($aMission['recent_record']){
				$aMission['recent_record'] = json_decode($aMission['recent_record'], true);
			}else{
				$aMission['recent_record'] = array();
			}
			$aMission['is_task_finish'] = self::TASK_NO_FINISHED;
			$aMission['is_pass'] = self::MISSION_NO_PASSED;
			$aMission['create_time'] = '';
			$aMission['score'] = 0;
			$aMission['challenge_history'] = array();
			foreach($aMissionUserRelationList as $aMissionUserRelation){
				if($aMissionUserRelation['mission_id'] == $aMission['id']){
					$aMission['is_task_finish'] = $aMissionUserRelation['is_task_finish'];
					$aMission['is_pass'] = $aMissionUserRelation['is_pass'];
					$aMission['create_time'] = $aMissionUserRelation['create_time'];
					$aMission['score'] = $aMissionUserRelation['score'];
					$aMission['challenge_history'] = $aMissionUserRelation['challenge_history'];
				}
			}
			$aReturnData[$aMission['subject_id']] = $aMission;
		}
		return $aReturnData;
	}

	//获得某一关卡的前n名
	public function getTopScoreUserListByMissionId($missionId, $page = 1, $pageSize = 10, $order = '`score` desc'){
		$offect = ($page - 1) * $pageSize;
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`mission_id`=' . $missionId . ' AND `is_pass`=1';
		$aTopUserMissionList = $oUserMissionIndex->get('', $where, $order, $offect, $pageSize);
		if(!$aTopUserMissionList){
			return $aTopUserMissionList;
		}else{
			$aUserIds = array();
			foreach($aTopUserMissionList as $aTopUserMission){
				$aUserIds[] = $aTopUserMission['user_id'];
			}
			$aUserList = $this->_getUserListByUserIds($aUserIds);
			$aReturnData = array();
			foreach($aTopUserMissionList as $aTopUserMission){
				$aData = $aTopUserMission;
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aData['user_id']){
						$aData['user_info'] = $aUser;
					}
				}
				$aReturnData[] = $aData;
			}
			return $aReturnData;
		}
	}

	public function getDefeatedPercent($missionId, $score){
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`mission_id`=' . $missionId . ' AND `is_pass`=1';
		//通过关卡的人数
		$passMissionCount = $oUserMissionIndex->count($where);
		//比特定分数高的人数
		$where .= ' AND `score`>' . $score;
		$higherScoreCount = $oUserMissionIndex->count($where);
		//击败的百分比
		return round((1 - $higherScoreCount/$passMissionCount) * 100);
	}

	public function getTopScoreUserListByMissionIdAndUserIds($missionId, $aUserIds, $order = '`score` desc', $page = '', $pageSize = ''){
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`mission_id`=' . $missionId . ' AND `is_pass`=1' . ' AND `user_id` in (' . implode(',', $aUserIds) . ')';
		if($page){
			$offect = ($page - 1) * $pageSize;
		}else{
			$offect = '';
		}
		$aTopUserMissionList = $oUserMissionIndex->get('', $where, $order, $offect, $pageSize);
		if(!$aTopUserMissionList){
			return $aTopUserMissionList;
		}else{
			$aUserList = $this->_getUserListByUserIds($aUserIds);
			$aReturnData = array();
			foreach($aTopUserMissionList as $aTopUserMission){
				$aData = $aTopUserMission;
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aData['user_id']){
						$aData['user_info'] = $aUser;
					}
				}
				$aReturnData[] = $aData;
			}
			return $aReturnData;
		}
	}

	public function getTopScoreUserCountByMissionIdAndUserIds($missionId, $aUserIds){
		$oUserMissionIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`mission_id`=' . $missionId . ' AND `is_pass`=1' . ' AND `user_id` in (' . implode(',', $aUserIds) . ')';
		return $oUserMissionIndex->count($where);
	}

	private function _getUserListByUserIds($aUserIds){
		//$oPersonal = new Model(T_PERSONAL);
		//$aUserList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
		//return $aUserList;
		return getUserListByUserIds($aUserIds);
	}

	//做过的题目数统计
	public function getMissionDidEsCount($userId){
		$oMissionUserIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aMissionUserList = $oMissionUserIndex->get('', '`user_id`=' . $userId);
		if($aMissionUserList === false){
			return false;
		}elseif(!$aMissionUserList){
			return array(
				'all_es_count'	=>	0,
				'correct_es_count'	=>	0,
				'pass_mission_count'	=>	0,
			);
		}
		$allEsCount = 0;
		$correctEsCount = 0;
		$passMissionCount = 0;
		foreach($aMissionUserList as $aMissionUser){
			$allEsCount += $aMissionUser['es_count'];
			$correctEsCount += $aMissionUser['es_correct_count'];
			if($aMissionUser['is_pass'] == 1){
				$passMissionCount++;
			}
		}
		return array(
			'all_es_count'	=>	$allEsCount,
			'correct_es_count'	=>	$correctEsCount,
			'pass_mission_count'	=>	$passMissionCount,
		);
	}

	public function getHistoryMissionList($userId, $subjectId, $page = 1, $pageSize = 10, $order = ''){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('', '`subject_id`=' . $subjectId);
		if(!$aMissionList){
			return $aMissionList;
		}
		$aMissionIds = array();
		foreach($aMissionList as $aMission){
			$aMissionIds[] = $aMission['id'];
		}
		$oMissionUserIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`user_id`=' . $userId . ' AND `is_pass`=1' . ' AND `mission_id` in (' . implode(',', $aMissionIds) . ')';
		$offect = ($page - 1) * $pageSize;
		$aMissionUserRelationIndexList = $oMissionUserIndex->get('', $where, $order, $offect, $pageSize);
		if(!$aMissionUserRelationIndexList){
			return $aMissionUserRelationIndexList;
		}
		foreach($aMissionUserRelationIndexList as &$aMissionUserRelation){
			foreach($aMissionList as $aMission){
				if($aMission['id'] == $aMissionUserRelation['mission_id']){
					$aMissionUserRelation['mission_name'] = $aMission['name'];
				}
			}
		}
		return $aMissionUserRelationIndexList;
	}

	public function getHistoryMissionCount($userId, $subjectId){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('', '`subject_id`=' . $subjectId);
		if(!$aMissionList){
			return $aMissionList;
		}
		$aMissionIds = array();
		foreach($aMissionList as $aMission){
			$aMissionIds[] = $aMission['id'];
		}
		$oMissionUserIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`user_id`=' . $userId . ' AND `is_pass`=1' . ' AND `mission_id` in (' . implode(',', $aMissionIds) . ')';
		return $oMissionUserIndex->count($where);
	}

	/**
	 * 判断列表里的用户是否全通过关卡
	 * @param int		$missionId		关卡id
	 * @param array		$userIdList		用户id列表
			$userIdList = array(
				用户id,
				......
			);
	 */
	public function isPassMissionByUserIdList($missionId, $userIdList){
		$oMission = new Model(T_MISSION_USER_RELATION_INDEX);
		if(is_numeric($userIdList)){
			$where = '`mission_id`=' . $missionId . ' AND user_id=' . $userIdList . ' AND is_pass=1';
			return $oMission->count($where);
		}
		$where = '`mission_id`=' . $missionId . ' AND user_id in(' . implode(',', $userIdList) . ') AND is_pass=1';
		$count = $oMission->count($where);
		if($count == count($userIdList)){
			return true;
		}
		return false;
	}

	/**
	 *获得用户已过关卡列表
	 * @param type $userId
	 * @param type $subjectId
	 * @param type $page
	 * @param type $pageSize
	 * @param type $order
	 */
	public function getUserPassMissionList($userId){
		$where = '`user_id`=' . $userId . ' AND `is_pass`=1';
		$oMissionUserRelation = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserMissionList = $oMissionUserRelation->get('`mission_id`,`es_count`,`es_correct_count`,`score`', $where);
		if($aUserMissionList === false){
			return $aUserMissionList;
		}
		$aMissionIds = array();
		foreach($aUserMissionList as $aUserMission){
			$aMissionIds[] = $aUserMission['mission_id'];
		}
		//查出共同关卡
		$oMission = new Model(T_MISSION);
		if($aMissionIds){
			$aMissionList = $oMission->get('`id`,`name`,`subject_id`', array('id' => array('in', $aMissionIds)));
			if($aMissionList === false){
				return false;
			}
		}else{
			$aMissionList = array();
		}
		//查出其他科目关卡
		$aOtherMissionList = $oMission->get('`id`,`name`,`subject_id`', '`subject_id`=4 AND `is_forbidden`!=1');
		if($aOtherMissionList === false){
			return false;
		}
		foreach($aOtherMissionList as $aOtherMission){
			if(!in_array($aOtherMission['id'], $aMissionIds)){
				$aMissionList[] = $aOtherMission;
			}
		}
		foreach($aMissionList as $key => $aMission){
			foreach($aUserMissionList as $aUserMission){
				if($aUserMission['mission_id'] == $aMission['id']){
					$aMissionList[$key]['es_count'] = $aUserMission['es_count'];
					$aMissionList[$key]['es_correct_count'] = $aUserMission['es_correct_count'];
					$aMissionList[$key]['score'] = $aUserMission['score'];
					break;
				}
			}
		}
		//初始化
		$aSubjectMissionList = array();
		foreach($GLOBALS['SUBJECT'] as $subjectId => $subjectName){
			$aSubjectMissionList[$subjectId] = array();
		}
		foreach($aMissionList as $aMission){
			$aSubjectMissionList[$aMission['subject_id']][] = $aMission;
		}
		return $aSubjectMissionList;
	}

	//获得过关人数
	public function getPassMissionUserCount($missionId){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		return $oMissionUserRelationIndex->count('`mission_id`=' . $missionId . ' AND `is_pass`=1');
	}

	//得到关卡的目前世界纪录
	public function getMissionRecordScore($missionId){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aBestScore = $oMissionUserRelationIndex->get('max(`score`) as `score`', '`mission_id`=' . $missionId);
		if(!$aBestScore){
			return $aBestScore;
		}
		return $aBestScore[0]['score'];
	}

	public function getUserPassMissionCount($userId){
		$oMission = new Model(T_MISSION_USER_RELATION_INDEX);
		return  $oMission->count('`user_id`=' . $userId . ' AND `is_pass`=1');
	}

	//闯关数排行----days为最近多少天的，为0是全部
	public function getPassMissionCountRankingList($page, $pageSize, $days = 0, $beginTime = 0, $endTime = 0, $aUserDetail = array()){
		$oMission = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`is_pass`=1 AND `user_id` not in (61532073,65168048,14718479,78674803,36953465,32542174,63439427,67845258,58433374,79293784,15629886,76261629,65902523,85709338,82352875,87447509,89470396,16909681,43411382,34065414,87340771,60392386,86678220,34232049,80344436,30221572,56453564,47336139,58313929,39903387)';
		if($days){
			$beforeTime = time() - $days * 24 * 60 * 60;
			$where = '`is_pass`=1 AND `pass_time`>' . $beforeTime;
		}elseif($beginTime){
			$where = '`is_pass`=1 AND `pass_time`>=' . $beginTime;
			if($endTime){
				$where .= ' AND `pass_time`<=' . $endTime;
			}
		}
		$offect = ($page - 1) * $pageSize;
		$aMissionUserRelationList = $oMission->get('`user_id`,count(*) as `nums`,max(`pass_time`) as `pass_time`', $where, '`nums` DESC,`pass_time` ASC', $offect, $pageSize, '`user_id`');
		if(!$aMissionUserRelationList){
			return $aMissionUserRelationList;
		}
		$aUserIds = array();
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			$aUserIds[] = $aMissionUserRelation['user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds, $aUserDetail);
		$aReturnData = array();
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			foreach($aUserList as $aUser){
				if($aMissionUserRelation['user_id'] == $aUser['id']){
					$aUser['pass_count'] = $aMissionUserRelation['nums'];
					$aReturnData[] = $aUser;
					break;
				}
			}
		}
		return $aReturnData;
	}

	/**
	 * 特定的用户类型参与闯关统计
	 * ~~~~~
	 *	$aCondition = [
	 *		'xxt_type' => 数字或数组  用户类型
	 *		'start_time'	 => 闯关统计开始时间
	 *		'end_time'	 => 闯关统计结束时间
	 * ]
	 *
	 * $aControl = [
	 *		'page' => 1
	 *		'page_size' => 10
	 * ]
	 * ~~~~~
	 */
	public function getXxtTypePassMissionCountRankingList($aCondition, $aControl){
		$oDboi = new DBOI();
		$where = '';
		if(is_array($aCondition['xxt_type'])){
			$where = '`t2`.`xxt_type` in (' . implode(',', $aCondition['xxt_type']) . ')';
		}else{
			$where = '`t2`.`xxt_type`=' . $aCondition['xxt_type'];
		}
		$where .= ' AND `t1`.`is_pass`=1 AND `t1`.`pass_time`>' . $aCondition['start_time'];
		if(isset($aCondition['end_time'])){
			$where .= ' AND `t1`.`pass_time`<=' . $aCondition['end_time'];
		}
		$offset = ($aControl['page'] - 1) * $aControl['page_size'];
		$aMissionUserRelationList = $oDboi->fields('`user_id`,count(*) as `nums`,max(`pass_time`) as `pass_time`')->table(T_MISSION_USER_RELATION_INDEX)->leftjoin(T_USER, 'as `t2` on `t1`.`user_id`=`t2`.`id`')->where($where)->groupby('user_id')->orderby('`nums` DESC,`pass_time` ASC')->limit($offset, $aControl['page_size'])->select();
		if(!$aMissionUserRelationList){
			return $aMissionUserRelationList;
		}
		$aUserIds = array();
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			$aUserIds[] = $aMissionUserRelation['user_id'];
		}
		$aUserDetail = ['class'];
		$aUserList = getUserListByUserIds($aUserIds, $aUserDetail);
		$aReturnData = array();
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			foreach($aUserList as $aUser){
				if($aMissionUserRelation['user_id'] == $aUser['id']){
					$aUser['pass_count'] = $aMissionUserRelation['nums'];
					$aReturnData[] = $aUser;
					break;
				}
			}
		}
		return $aReturnData;
	}

	//过关数量和题目的统计
	public function getAllMissionStatisticsByUserId($userId){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`subject_id`', '');
		if(!$aMissionList){
			return $aMissionList;
		}
		$aSubjectMissionList = array();
		foreach($aMissionList as $aMission){
			$aSubjectMissionList[$aMission['subject_id']][] = $aMission['id'];
		}
		unset($aMissionList);
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserPassMissionList = $oMissionUserRelationIndex->get('`mission_id`,`es_count`,`es_correct_count`,`score`,`pass_time`', '`user_id`=' . $userId . ' AND `is_pass`=1');
		if(!$aUserPassMissionList){
			return $aUserPassMissionList;
		}

		$aLast12MonthList = array();
		$thisYear = date('Y');
		$thisMonth = date('m');
		for($i = 11; $i >= 0; $i --){
			if($thisMonth - $i > 0){
				$year = $thisYear;
				$month = $thisMonth - $i;
			}else{
				$year = $thisYear - 1;
				$month = 12 - ($i - $thisMonth);
			}
			if($month < 10){
				$month = 0 . $month;
			}
			$monthStartTime = mktime(0, 0, 0, $month, 1, $year);
			if($month < 12){
				$monthEndTime = mktime(0, 0, 0, $month + 1, 1, $year) - 1;
			}else{
				$monthEndTime = mktime(0, 0, 0, 1, 1, $year + 1) - 1;
			}
			$aLast12MonthList[$year . $month] = array(
				'start_time' => $monthStartTime,
				'end_time' => $monthEndTime,
				'pass_mission_count' => 0,
				'es_count'	=> 0,
				'sum_score'	=> 0,
			);
		}

		$allPassMissionCount = count($aUserPassMissionList);	//过关总数
		$allEsCount = 0;	//答题总数
		$allCorrectEsCount = 0;	//答题总数
		$aSubjectStatisticsList = array();	//各科目统计
		$aSubjectList = $GLOBALS['SUBJECT'];
		//初始化各个科目的统计数据
		foreach($aSubjectList as $subjectId => $subjectName){
			$aSubjectStatisticsList[$subjectId]['es_count'] = 0;
			$aSubjectStatisticsList[$subjectId]['es_correct_count'] = 0;
			$aSubjectStatisticsList[$subjectId]['pass_mission_count'] = 0;
		}
		unset($aSubjectList);

		foreach($aUserPassMissionList as $aUserPassMission){
			//给各科目统计加值
			foreach($aSubjectMissionList as $subjectId => $aMissionIds){
				if(in_array($aUserPassMission['mission_id'], $aMissionIds)){
					$aSubjectStatisticsList[$subjectId]['es_count'] += $aUserPassMission['es_count'];
					$aSubjectStatisticsList[$subjectId]['es_correct_count'] += $aUserPassMission['es_correct_count'];
					$aSubjectStatisticsList[$subjectId]['pass_mission_count'] += 1;
					break;
				}
			}
			//给每月的统计加值
			foreach($aLast12MonthList as $monthKey => $aLast12Month){
				if($aUserPassMission['pass_time'] >= $aLast12Month['start_time'] && $aUserPassMission['pass_time'] <= $aLast12Month['end_time']){
					$aLast12MonthList[$monthKey]['pass_mission_count'] += 1;
					$aLast12MonthList[$monthKey]['es_count'] += $aUserPassMission['es_count'];
					$aLast12MonthList[$monthKey]['sum_score'] += $aUserPassMission['score'];
					break;
				}
			}
			$allEsCount += $aUserPassMission['es_count'];
			$allCorrectEsCount += $aUserPassMission['es_correct_count'];
		}
		return array(
			'pass_mission_count'	=>	$allPassMissionCount,	//过关总数
			'es_count'				=>	$allEsCount,	//答题总数
			'es_correct_count'		=>	$allCorrectEsCount,	//总正确题目数
			'subject_count'			=>	$aSubjectStatisticsList,	//按科目统计
			'last_12_month_count'	=>	$aLast12MonthList,	//最近12个月的统计
		);
	}

	//战绩的月统计
	public function getUserMonthStatistics($userId, $year, $month){
		$aSubjectStatisticsList = array();	//各科目统计
		$aSubjectList = $GLOBALS['SUBJECT'];
		//初始化各个科目的统计数据
		foreach($aSubjectList as $subjectId => $subjectName){
			$aSubjectStatisticsList[$subjectId]['es_count'] = 0;
			$aSubjectStatisticsList[$subjectId]['es_correct_count'] = 0;
			$aSubjectStatisticsList[$subjectId]['pass_mission_count'] = 0;
			$aSubjectStatisticsList[$subjectId]['pass_mission_list'] = array();
		}
		unset($aSubjectList);
		$monthStarTime = mktime(0, 0, 0, $month, 1, $year);
		if($month == 12){
			$monthEndTime = mktime(0, 0, 0, 1, 1, $year + 1) - 1;
		}else{
			$monthEndTime = mktime(0, 0, 0, $month + 1, 1, $year) - 1;
		}
		$where = '`user_id`=' . $userId . ' AND `is_pass`=1 AND `pass_time`>=' . $monthStarTime . ' AND `pass_time`<=' . $monthEndTime;
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserMissionList = $oMissionUserRelationIndex->get('`mission_id`,`es_count`,`es_correct_count`,`score`,`pass_time`', $where);
		if($aUserMissionList === false){
			return false;
		}elseif(!$aUserMissionList){
			return array(
				'pass_mission_count'	=>	0,	//过关总数
				'es_count'				=>	0,			//总题数
				'es_correct_count'		=>	0,	//正确题数
				'subject_count'			=>	$aSubjectStatisticsList,	//各科目统计
			);
		}
		$passMissionCount = count($aUserMissionList);
		$esCount = 0;
		$esCorrectCount = 0;
		$aMissionIds = array();
		foreach($aUserMissionList as $aUserMission){
			$aMissionIds[] = $aUserMission['mission_id'];
			$esCount += $aUserMission['es_count'];
			$esCorrectCount += $aUserMission['es_correct_count'];
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`subject_id`,`grade`', array('id' => array('in', $aMissionIds)));
		if($aMissionList === false){
			return false;
		}elseif($aMissionList){
			$aMissionList = Mission::convertMissionList($aMissionList);
		}
		foreach($aUserMissionList as $aUserMission){
			foreach($aMissionList as $aMission){
				if($aUserMission['mission_id'] == $aMission['id']){
					$aSubjectStatisticsList[$aMission['subject_id']]['es_count'] += $aUserMission['es_count'];
					$aSubjectStatisticsList[$aMission['subject_id']]['es_correct_count'] += $aUserMission['es_correct_count'];
					$aSubjectStatisticsList[$aMission['subject_id']]['pass_mission_count'] += 1;
					$aUserMission['mission_name'] = $aMission['name'];
					$aSubjectStatisticsList[$aMission['subject_id']]['pass_mission_list'][] = $aUserMission;
				}
			}
		}
		return array(
			'pass_mission_count'	=>	$passMissionCount,	//过关总数
			'es_count'				=>	$esCount,			//总题数
			'es_correct_count'		=>	$esCorrectCount,	//正确题数
			'subject_count'			=>	$aSubjectStatisticsList,	//各科目统计
		);
	}

	//关卡题目统计-------错题集首页用
	public function getUserMissionEsStatisticList($userId, $subjectId = 0, $page = 1, $pageSize = 10){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$offect = ($page - 1) * $pageSize;
		if($subjectId){
			$where = '`subject_id`=' . $subjectId . ' AND `user_id`=' . $userId;
		}else{
			$where = '`user_id`=' . $userId;
		}
		$aUserEsWrongList = $oUserEsWrong->get('`mission_id`,count(*) as `nums`', $where, '`mission_id` ASC', $offect, $pageSize, '`mission_id`');
		if(!$aUserEsWrongList){
			return $aUserEsWrongList;
		}
		$aMissionIds = array();
		foreach($aUserEsWrongList as $aUserEsWrong){
			$aMissionIds[] = $aUserEsWrong['mission_id'];
		}
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aMissionUserRelationList = $oMissionUserRelationIndex->get('`mission_id`,`es_count`,`es_correct_count`,`es_repair_count`', '`mission_id` in (' . implode(',', $aMissionIds) . ') AND `user_id`=' . $userId);
		if(!$aMissionUserRelationList){
			return $aMissionUserRelationList;
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', array('id' => array('in', $aMissionIds)));
		if(!$aMissionList){
			return $aMissionList;
		}elseif($aMissionList){
			$aMissionList = Mission::convertMissionList($aMissionList);
		}
		foreach($aMissionList as $key => $aMission){
			foreach($aMissionUserRelationList as $aMissionUserRelation){
				if($aMissionUserRelation['mission_id'] == $aMission['id']){
					$aMissionList[$key]['wrong_es_times'] = $aMissionUserRelation['es_count'] - $aMissionUserRelation['es_correct_count'];
					$aMissionList[$key]['repair_es_count'] = $aMissionUserRelation['es_repair_count'];
					$aMissionList[$key]['wrong_es_count'] = 0;
					break;
				}
			}
		}
		unset($aMissionUserRelationList);
		foreach($aMissionList as $key => $aMission){
			foreach($aUserEsWrongList as $aUserEsWrong){
				if($aUserEsWrong['mission_id'] == $aMission['id']){
					$aMissionList[$key]['wrong_es_count'] = $aUserEsWrong['nums'];
				}
			}
		}
		return $aMissionList;
	}

	public function getMissionListByIds($aMissionIds){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('', array('id' => array('in', $aMissionIds)));
		if(!$aMissionList){
			return $aMissionList;
		}
		return Mission::convertMissionList($aMissionList);
	}

	public function getMissionUserRelationIndexList($userId, $aMissionIds){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$where = '`user_id`=' . $userId . ' AND `mission_id` in (' . implode(',', $aMissionIds) . ')';
		return $oMissionUserRelationIndex->get('`mission_id`,`es_repair_count`', $where);
	}
}