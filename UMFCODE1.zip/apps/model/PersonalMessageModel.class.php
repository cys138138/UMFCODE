<?php
class PersonalMessageModel{

	//用户个人消息表配置
	private $_aPesonalType = array(
		'ait'	=>	1,
		'comment_ait' =>100,
		'retransmission'	=>	2,
		'comment'	=>	3,
		'reply_comment'	=>	4,
		'public_message'	=>	8,
		'reply_public_message'	=>	9,
		'match_result' =>  20,
		'sponsor_pk' =>  30,
		'refuse_pk' =>  31,
		'pk_result' =>  32,
		'es_feedback'	=>	10,
		'prop_send'	=>	33,
	);

	const TRANSMIT_SHUOSHUO = 1;//转发说说
	const SUPPORT_COUNT = 11; //赞的用户数量
	const REPLY_COUNT = 20;	//回复的数量
	const PUBLIC_MESSAGE_REPLY_COUNT = 10;//留言回复数量
	const COMMENT_COUNT = 10; //评论的数量
	const MATCH_COUNT = 11; //比赛的用户数量

	public function deletePersonalMessage($id = 0, $userId = 0, $type = 0, $dataId = 0){
		$where = '';
		if($id){
			if(!$userId && !$type && !$dataId){
				$where = array('id'=>$id);
			}else{
				$where .= '`id``='.$id;
			}
		}
		if($userId){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`user_id`='.$userId;
		}
		if($type){
			if($where){
				$where .= ' AND ';
			}
			if(is_array($type)){
				$type = implode(',',$type);
				$where .= '`type` in('.$type.')';
			}else{
				$where .= '`type`='.$type;
			}
		}
		if($dataId){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`data_id`='.$dataId;
		}
		if(!$where){
			return false;
		}

		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		return $oPersonalMessage->delete($where);
	}

	public function addPersonalMessage($aData){
		//覆盖操作
		$aUserId = array();
		foreach($aData as $data){
			if(!is_array($data)){
				break;
			}else{
				$aUserId[] = $data['user_id'];
			}
		}

		if($aData['type'] == $this->_aPesonalType['pk_result']){
			$this->deletePersonalMessage(0, $aData['user_id'], array($this->_aPesonalType['sponsor_pk']),$aData['data_id']);
		}elseif($aData['type'] == $this->_aPesonalType['public_message'] || $aData['type'] == $this->_aPesonalType['reply_public_message']){
			$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
			$aPublicMessage = $oPublicMessage->get('`user_id`,`parent_id`',array('id'=>$aData['data_id']));
			if($aPublicMessage[0]['parent_id'] > 0){
				$where = '(parent_id='.$aPublicMessage[0]['parent_id'].' OR `id`='.$aPublicMessage[0]['parent_id'] .') AND user_id='.$aPublicMessage[0]['user_id'];
				$aPublicMessage2 = $oPublicMessage->get('`id`,`parent_id`', $where, 'id DESC');
				if(isset($aPublicMessage2[1]['id']) && $aPublicMessage2[1]['id']){
					if($aPublicMessage2[1]['parent_id'] == 0){
						$this->deletePersonalMessage(0, $aPublicMessage[0]['user_id'], array($this->_aPesonalType['public_message']) ,$aPublicMessage2[1]['id']);
					}else{
						$this->deletePersonalMessage(0, $aPublicMessage[0]['user_id'], array($this->_aPesonalType['reply_public_message']) ,$aPublicMessage2[1]['id']);
					}
				}
			}
		}
		//更新通知
		$oPersonal = new Model(T_PERSONAL);
		if($aUserId){
			$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>array('in',$aUserId)));
		}else{
			$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>$aData['user_id']));
		}
		if($personal === false){
			return false;
		}

		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		return $oPersonalMessage->add($aData);
	}

	//根据id获取与我相关动态
	public function getPersonalMessageById($personalMessageId){
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$aPersonalMessage = $oPersonalMessage->get('',array('id'=>$personalMessageId));
		if(!$aPersonalMessage){
			return $aPersonalMessage;
		}else{
			return $aPersonalMessage[0];
		}
	}


	//获取个人详细动态消息
	public function getPersonalMessageList($userId, $aType = array(), $dataId = 0, $page = 1, $pageSize = 20){
		if(!$userId){
			return false;
		}
		$aFriendsId = $this->_getUserFriendsId($userId);
		if($aFriendsId === false){
			return false;
		}elseif(!$aFriendsId){
			$aFriendsId[] = $userId;
		}else{
			array_unshift($aFriendsId,$userId);
		}
		//更新通知
		$oPersonal = new Model(T_PERSONAL);
		$oPersonal->update(array('new_feed_flag'=>0), array('id'=>$userId));

		$offect = ($page - 1) * $pageSize;
		$where = 'user_id='.$userId;
		if($aType){
			if(count($aType) == 1){
				$where .= ' AND `type`='.$aType[0];
			}else{
				$type = implode(',',$aType);
				$where .= 'AND `type` in('.$type.')';
			}
		}
		if($dataId){
			$where .= ' AND `data_id`='.$dataId;
		}

		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$aPersonalMessageList = $oPersonalMessage->get('', $where, '`id` DESC', $offect, $pageSize);
		if(!$aPersonalMessageList){
			return $aPersonalMessageList;
		}

		$aPersonalMessageList = $this->_getDetialPersonalMessageList($aPersonalMessageList, $aFriendsId);
		return $aPersonalMessageList;
	}

	//获取详细个人动态消息
	private function _getDetialPersonalMessageList($aPersonalMessageList, $aFriendsId){
		$aShuoshuoIds = array();
		$aCommentIds = array();
		$aPublicMessageIds = array();
		$aMatchUserRelationIds = array();
		$aPkIds =array();
		$aUserIds = array();
		$aFeedbackIds = array();
		$aPropSendIds = array();
		foreach($aPersonalMessageList as $key => $aPersonalMessage){
			if($aPersonalMessage['type'] == $this->_aPesonalType['ait'] || $aPersonalMessage['type'] == $this->_aPesonalType['retransmission']){
				$aShuoshuoIds[] = $aPersonalMessage['data_id'];
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['comment_ait'] || $aPersonalMessage['type'] == $this->_aPesonalType['comment'] || $aPersonalMessage['type'] == $this->_aPesonalType['reply_comment']){
				$aCommentIds[] = $aPersonalMessage['data_id'];
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['public_message'] || $aPersonalMessage['type'] == $this->_aPesonalType['reply_public_message']){
				$aPublicMessageIds[] = $aPersonalMessage['data_id'];
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['match_result']){
				$aMatchUserRelationIds[] = $aPersonalMessage['data_id'];
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['sponsor_pk'] || $aPersonalMessage['type'] == $this->_aPesonalType['refuse_pk'] || $aPersonalMessage['type'] == $this->_aPesonalType['pk_result']){
				$aPkIds[] = $aPersonalMessage['data_id'];
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['es_feedback']){
				$aFeedbackIds[] = $aPersonalMessage['data_id'];
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['prop_send']){
				$aPropSendIds[] = $aPersonalMessage['data_id'];
			}else{
				unset($aPersonalMessageList[$key]);
			}
		}


		//得到详细说说
		$aShuoshuoList = array();
		if($aShuoshuoIds || $aCommentIds){
			$aShuoshuoList = $this -> _getShuoshuoList($aShuoshuoIds, $aCommentIds);
			if($aShuoshuoList === false){
				return false;
			}
			//收集出现的用户user_id
			foreach($aShuoshuoList as $aShuoshuo){
				$aUserIds[] = $aShuoshuo['user_id'];
				if($aShuoshuo['source_info']){
					if($aShuoshuo['source_info']['user_id']){
						$aUserIds[] = $aShuoshuo['source_info']['user_id'];
					}
					if($aShuoshuo['source_info']['support']){
						$aUserIds = array_merge($aUserIds,explode(',',$aShuoshuo['source_info']['support']));
					}
				}
				if($aShuoshuo['support']){
					$aUserIds = array_merge($aUserIds,explode(',',$aShuoshuo['support']));
				}
				if($aShuoshuo['comment']){
					foreach($aShuoshuo['comment'] as $aComment){
						$aUserIds[] = $aComment['user_id'];
						if( $aComment['replyed_user_id']){
							$aUserIds[] = $aComment['replyed_user_id'];
						}
						if(isset($aComment['reply']) && $aComment['reply']){
							foreach($aComment['reply'] as $aReply){
								$aUserIds[]= $aReply['user_id'];
								if( $aReply['replyed_user_id']){
									$aUserIds[] = $aReply['replyed_user_id'];
								}
							}
						}
					}
				}
			}
		}

		//得到详细留言
		if($aPublicMessageIds){
			$aPublicMessageList = $this->_getPublicMessageList($aPublicMessageIds);
			if($aPublicMessageList === false){
				return false;
			}
			//收集出现的user_id
			foreach($aPublicMessageList as $aPublicMessage){
				$aUserIds[] = $aPublicMessage['sender_user_id'];
				if(isset($aPublicMessage['reply']) && $aPublicMessage['reply']){
					foreach($aPublicMessage['reply'] as $aReply){
						$aUserIds[] = $aReply['user_id'];
						$aUserIds[] = $aReply['sender_user_id'];
					}
				}
			}
		}

		//得到详细比赛结果
		$aMatchList = array();
		if($aMatchUserRelationIds){
			$aMatchList = $this->_getMatchResultList($aMatchUserRelationIds);
			if($aMatchList === false){
				return false;
			}

			//收集出现的user_id
			foreach($aMatchList as $aMatch){
				if($aMatch['match_winners']){
					foreach($aMatch['match_winners']['top'] as $aMatchTop){
						$aUserIds[] = $aMatchTop['user_id'];
					}
					foreach($aMatch['match_winners']['rand'] as $aMatchRand){
						$aUserIds[] = $aMatchRand['user_id'];
					}
				}
			}
		}

		//得到详细Pk信息
		if($aPkIds){
			$aPkList = $this->_getPkList($aPkIds);
			if($aPkList === false){
				return false;
			}
			//收集出现的User_id
			foreach($aPkList as $aPk){
				$aUserIds[] = $aPk['sender_user_id'];
				$aUserIds[] = $aPk['receiver_user_id'];
			}
		}

		//得到详细的反馈信息
		$aEsIds = array();
		if($aFeedbackIds){
			$aUserFeedbackList = $this->_getUserFeedbackInfo($aFeedbackIds);
			if($aUserFeedbackList === false){
				return false;
			}
			//收集出现的es_id
			foreach($aUserFeedbackList as $aUserFeedback){
				$aEsIds[] = $aUserFeedback['es_id'];
			}
		}

		//查出题目信息
		if($aEsIds){
			$aEsInfo = $this->_getEsInfo($aEsIds);
			if($aEsInfo === false){
				return false;
			}
			$aEsRefer = array();
			foreach($aEsInfo as $aEs){
				$aEsRefer[$aEs['id']] = $aEs['content_json'];
			}
			unset($aEsInfo);
			$aEsTypeInfo = $this->_getEsType($aEsIds);
			if($aEsTypeInfo === false){
				return false;
			}
		}

		//查出道具赠送的详细信息
		if($aPropSendIds){
			$aPropSendInfo = $this->_getPropSendInfo($aPropSendIds);
			if($aPropSendInfo === false){
				return false;
			}

			//收集出现的用户id
			$aPropSendRefer = array();
			foreach($aPropSendInfo as $aPropSend){
				$aUserIds[] = $aPropSend['user_id'];
				$aPropSendRefer[$aPropSend['id']] = $aPropSend;
			}
			unset($aPropSendInfo);
		}



		//查出所有用户信息
		if($aUserIds){
			//去掉数组中为空的值
			//$aUserIds = array_filter($aUserIds,create_function('$v','return !empty($v);'));
			$aUserList = $this->_getUserList($aUserIds);
			if($aUserList === false){
				return false;
			}
			$aUserReferList = array();
			foreach($aUserList as $key => $value){
				$aUserReferList[$value['id']] = &$aUserList[$key];
			}
			unset($aUserList);
		}

		//给说说组装用户信息以及赞
		foreach($aShuoshuoList as $key => $aShuoshuo){
			$aShuoshuoList[$key]['support_count'] = 0;
			//先把转发的源说说的赞扔给说说的赞进行处理
			// if(isset($aShuoshuo['source_info']['support']) && $aShuoshuo['source_info']['support'] && $aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				// $aShuoshuoList[$key]['support'] = '';
				// $aShuoshuoList[$key]['support'] = $aShuoshuoList[$key]['source_info']['support'];
			// }elseif(isset($aShuoshuo['source_info']['support']) && !$aShuoshuo['source_info']['support'] && $aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				// $aShuoshuoList[$key]['support'] = '';
			// }
			if($aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				if($aShuoshuo['source_info'] && $aShuoshuo['source_info']['support']){
					if($aShuoshuo['source_info']['support']){
						$aShuoshuoList[$key]['support'] = '';
						$aShuoshuoList[$key]['support'] = $aShuoshuoList[$key]['source_info']['support'];
					}else{
						$aShuoshuoList[$key]['support'] = '';
					}
				}else{
					$aShuoshuoList[$key]['support'] = '';
				}
				unset($aShuoshuoList[$key]['source_info']['support']);
			}

			if($aShuoshuoList[$key]['support']){
				$aShuoshuoList[$key]['support'] = explode(',',$aShuoshuoList[$key]['support']);
				$aShuoshuoList[$key]['support_count'] = count($aShuoshuoList[$key]['support']);
				$aShuoshuoSupport = $aShuoshuoList[$key]['support'];
				if($aFriendsId){
					$aShuoshuoList[$key]['support'] = array_intersect($aShuoshuoList[$key]['support'], $aFriendsId);
					sort($aShuoshuoList[$key]['support']);
					$aUserLocation = array_keys($aShuoshuoList[$key]['support'],$aFriendsId[0]);
					if($aUserLocation && ($aUserLocation[0] != 0)){
						list($aShuoshuoList[$key]['support'][0],$aShuoshuoList[$key]['support'][$aUserLocation[0]]) = array($aShuoshuoList[$key]['support'][$aUserLocation[0]],$aShuoshuoList[$key]['support'][0]);
					}
				}
				if(count($aShuoshuoList[$key]['support']) > self::SUPPORT_COUNT){
					array_splice($aShuoshuoList[$key]['support'],self::SUPPORT_COUNT);
				}elseif(count($aShuoshuoList[$key]['support']) < self::SUPPORT_COUNT){
					$aShuoshuoSupport = array_diff($aShuoshuoSupport, $aShuoshuoList[$key]['support']);
					$aShuoshuoList[$key]['support'] = array_merge($aShuoshuoList[$key]['support'], $aShuoshuoSupport);
					array_splice($aShuoshuoList[$key]['support'],self::SUPPORT_COUNT);
				}
				//给赞组装用户信息
				foreach($aShuoshuoList[$key]['support'] as $key2 => $aSupport){
					$aShuoshuoList[$key]['support'][$key2] = $aUserReferList[$aSupport];
				}
			}else{
				$aShuoshuoList[$key]['support'] = array();
			}
			if($aShuoshuo['source_info']){
				$aShuoshuoList[$key]['source_info']['user_info'] = $aUserReferList[$aShuoshuo['source_info']['user_id']];
			}
			if($aShuoshuo['comment']){
				foreach($aShuoshuo['comment'] as $key2 => $aComment){
					$aShuoshuoList[$key]['comment'][$key2]['user_info'] = $aUserReferList[$aComment['user_id']];
					if(isset($aComment['reply']) && $aComment['reply']){
						foreach($aComment['reply'] as $key3 => $aReply){
							$aShuoshuoList[$key]['comment'][$key2]['reply'][$key3]['user_info'] = $aUserReferList[$aReply['user_id']];
							$aShuoshuoList[$key]['comment'][$key2]['reply'][$key3]['reply_user_info'] = $aUserReferList[$aReply['replyed_user_id']];
						}
					}
				}
			}
		}


		if($aMatchList){
			$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		}
		//给比赛组装比赛结果信息以及奖品信息以及赢家的用户信息以及用户排名
		foreach($aMatchList as $key => $aMatch){
			$aMatchUserRankingList = array();
			$aMatchUserRankingList = $oMatchUserRelation->get('`user_id`,`match_id`,`best_score`','match_id ='.$aMatch['match_id'],'best_score DESC');
			//参赛人数统计
			if(!$aMatchUserRankingList){
				$aMatchList[$key]['member_count'] = 0;
				$aMatchList[$key]['champion_score'] = 0;
			}else{
				$aMatchList[$key]['champion_score'] = $aMatchUserRankingList[0]['best_score'];
				$aMatchList[$key]['member_count'] = count($aMatchUserRankingList);
				if($aMatch['best_score'] != 0 && $aMatchUserRankingList){
					foreach($aMatchUserRankingList as $key4 => $aMatchUserRanking){
						if($aMatch['user_id'] == $aMatchUserRanking['user_id']){
							$aMatchList[$key]['ranking'] = $key4+1;
							break;
						}
					}
				}else{
					$aMatchList[$key]['ranking'] = 0;
				}
			}
			if($aMatch['match_winners']){
				foreach($aMatch['match_winners']['top'] as $key2 => $aMatchWinnerTop){
					if($aMatch['user_id'] == $aMatchWinnerTop['user_id']){
						$aMatchList[$key]['win_info']['type'] = 1;
						$aMatchList[$key]['win_info']['ranking'] = $key2;
						$aMatchList[$key]['win_info']['receive_time'] = $aMatchWinnerTop['receive_time'];
						foreach($aMatch['match_awards']['top'] as $key3 => $aAwardsTop ){
							if($key2 == $key3){

								if($aAwardsTop['accumulate_points']){
									$aMatchList[$key]['win_info']['awards_info']['accumulate_points'] = $aAwardsTop['accumulate_points'];
								}elseif($aAwardsTop['gold']){
									$aMatchList[$key]['win_info']['awards_info']['gold'] = $aAwardsTop['gold'];
								}elseif($aAwardsTop['prize']){
									$aMatchList[$key]['win_info']['awards_info']['prize'] = $aAwardsTop['prize'];
								}else{
									$aMatchList[$key]['win_info']['awards_info'] = array();
								}
							}
						}
					}else{
						foreach($aMatch['match_winners']['rand'] as $aMatchWinnerRand){
							if($aMatch['user_id'] == $aMatchWinnerRand['user_id']){
								$aMatchList[$key]['win_info']['type'] = 2;
								$aMatchList[$key]['win_info']['creare_time'] = $aMatchWinnerRand['receive_time'];
								if($aMatch['match_awards']['rand']){
									if($aMatchWinnerRand['accumulate_points']){
										$aMatchList[$key]['win_info']['awards_info']['accumulate_points'] = $aMatch['match_awards']['rand']['accumulate_points'];
									}elseif($aMatchWinnerRand['gold']){
										$aMatchList[$key]['win_info']['awards_info']['gold'] = $aMatch['match_awards']['rand']['gold'];
									}elseif($aMatchWinnerRand['prize']){
										$aMatchList[$key]['win_info']['awards_info']['prize'] = $aMatch['match_awards']['rand']['prize'];
									}else{
										$aMatchList[$key]['win_info']['awards_info'] = array();
									}
								}else{
									$aMatchList[$key]['win_info']['awards_info'] = array();
								}
							}else{
								$aMatchList[$key]['win_info'] = array();
							}
						}
					}
				}
			}else{
				$aMatchList[$key]['win_info'] = array();
			}
			unset($aMatchList[$key]['user_id'],$aMatchList[$key]['match_awards']);
		}

		//给比赛组装赢家的用户信息并且限制为10个
		foreach($aMatchList as $key => $aMatch){
			if($aMatch['match_winners']){
				$aMatchList[$key]['match_winner_top_count'] = count($aMatch['match_winners']['top']);
				if($aMatchList[$key]['match_winner_top_count'] > self::MATCH_COUNT){
					if($aMatchList[$key]['match_winner_top_count'] > self::MATCH_COUNT){
						array_splice($aMatchList[$key]['match_winners']['top'], self::MATCH_COUNT + 1);
					}
				}elseif($aMatchList[$key]['match_winner_top_count'] < self::MATCH_COUNT){
					$length = self::MATCH_COUNT - $aMatchList[$key]['match_winner_top_count'];
					$number = $aMatchList[$key]['match_winner_top_count'];
					array_splice($aMatchList[$key]['match_winners']['rand'],$length);
					foreach($aMatchList[$key]['match_winners']['rand'] as $key3 => $aMatchWinnerRand){
						$aMatchList[$key]['match_winners']['top'][++$number] = $aMatchList[$key]['match_winners']['rand'][$key3];
					}
				}

				foreach($aMatchList[$key]['match_winners']['top'] as $key2 => $aMatchWinnerTop){
					$aMatchList[$key]['match_winners']['top'][$key2]['user_info'] = $aUserReferList[$aMatchWinnerTop['user_id']];
				}
				$aMatchList[$key]['users'] = $aMatchList[$key]['match_winners']['top'];
			}else{
				$aMatchList[$key]['users'] = array();
			}
			unset($aMatchList[$key]['match_winners']);
		}

		//合并数据结构
		foreach($aPersonalMessageList as $key => $aPersonalMessage){
			$aPersonalMessageList[$key]['data'] = array();

			//说说结构
			//某人在某说说中@了我或者某人转发了我的某说说
			if($aPersonalMessage['type'] == $this->_aPesonalType['ait'] || $aPersonalMessage['type'] == $this->_aPesonalType['retransmission']){
				foreach($aShuoshuoList as $aShuoshuo){
					if($aShuoshuo['id'] == $aPersonalMessage['data_id']){
						$aPersonalMessageList[$key]['user_id'] = $aShuoshuo['user_id'];
						if($aUserReferList[$aShuoshuo['user_id']]){
							$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aShuoshuo['user_id']];
						}
						$aPersonalMessageList[$key]['data'] = $aShuoshuo;
						if($aPersonalMessage['type'] == $this->_aPesonalType['ait']){
							$aPersonalMessageList[$key]['data']['user_info'] = $aUserReferList[$aPersonalMessageList[$key]['data']['user_id']];
						}
						break;
					}
				}
		   //某人在某说说的评论或回复中@了我或者某人评论了我的某说说或者某人在某说说回复了我的评论（包含基于任何人的说说）某人在某说说回复了我的回复
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['comment_ait'] || $aPersonalMessage['type'] == $this->_aPesonalType['comment'] || $aPersonalMessage['type'] == $this->_aPesonalType['reply_comment']){
				foreach($aShuoshuoList as $aShuoshuo){
					foreach($aShuoshuo['comment'] as $key2=>$aComment){
						if($aComment['id'] == $aPersonalMessage['data_id']){
							$aPersonalMessageList[$key]['user_id'] = $aComment['user_id'];
							$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aComment['user_id']];
							$aPersonalMessageList[$key]['data'] = $aShuoshuo;
							$commentCount = count($aShuoshuo['comment']);
							$aPersonalMessageList[$key]['data']['comment'] = array();
							$aPersonalMessageList[$key]['data']['comment'][$key2] = $aComment;
							$aPersonalMessageList[$key]['data']['comment_count'] = $commentCount;
							$replyCount = count($aComment['reply']);
							$aPersonalMessageList[$key]['data']['comment_count'] = $commentCount;
							$aPersonalMessageList[$key]['data']['comment'][$key2]['reply_count'] = $replyCount;
							if($aPersonalMessage['type'] != $this->_aPesonalType['comment']){
								$aPersonalMessageList[$key]['data']['user_info'] = $aUserReferList[$aPersonalMessageList[$key]['data']['user_id']];
							}
							break;
						}else{
							foreach($aComment['reply'] as $aReply){
								if($aReply['id'] == $aPersonalMessage['data_id']){
									$aPersonalMessageList[$key]['user_id'] = $aReply['user_id'];
									$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aReply['user_id']];
									$aPersonalMessageList[$key]['data'] = $aShuoshuo;
									$commentCount = count($aShuoshuo['comment']);
									$aPersonalMessageList[$key]['data']['comment'] = array();
									$aPersonalMessageList[$key]['data']['comment'][$key2] = $aComment;
									$replyCount = count($aComment['reply']);
									$aPersonalMessageList[$key]['data']['comment_count'] = $commentCount;
									$aPersonalMessageList[$key]['data']['comment'][$key2]['reply_count'] = $replyCount;
									if($aPersonalMessage['type'] != $this->_aPesonalType['comment']){
										$aPersonalMessageList[$key]['data']['user_info'] = $aUserReferList[$aPersonalMessageList[$key]['data']['user_id']];
									}
									break;
								}
							}
						}
					}
				}

			//留言结构
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['public_message'] || $aPersonalMessage['type'] == $this->_aPesonalType['reply_public_message']){
				foreach($aPublicMessageList as $aPublicMessage){
					if($aPublicMessage['id'] == $aPersonalMessage['data_id']){
						$aPersonalMessageList[$key]['user_id'] = $aPublicMessage['sender_user_id'];
						$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aPublicMessage['sender_user_id']];
						$aPersonalMessageList[$key]['data'] = $aPublicMessage;
						break;
					}
					if(isset($aPublicMessage['reply']) && $aPublicMessage['reply']){
						foreach($aPublicMessage['reply'] as $aReply){
							if($aReply['id'] == $aPersonalMessage['data_id'] && $aReply['user_id'] == $aPersonalMessage['user_id']){
								$aPersonalMessageList[$key]['user_id'] = $aReply['sender_user_id'];
								$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aReply['sender_user_id']];
								$aPersonalMessageList[$key]['data'] = $aPublicMessage;
								break;
							}
						}
					}

				}


			//比赛结构
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['match_result']){
				foreach($aMatchList as $aMatch){
					if($aPersonalMessage['data_id'] == $aMatch['id']){
						$aPersonalMessageList[$key] = array();
						$aPersonalMessageList[$key] = $aMatch;
						$aPersonalMessageList[$key]['type'] = $aPersonalMessage['type'];
						break;
					}
				}


			//pk结构
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['sponsor_pk'] || $aPersonalMessage['type'] == $this->_aPesonalType['refuse_pk'] || $aPersonalMessage['type'] == $this->_aPesonalType['pk_result']){
				foreach($aPkList as $key2 => $aPk){
					if($aPk['id'] == $aPersonalMessage['data_id']){
						if($aPk['winner_user_id']){
							$aPkList[$key2]['winner_user_info'] = $aUserReferList[$aPk['winner_user_id']];
						}else{
							$aPkList[$key2]['winner_user_info'] = array();
						}
						if($aPersonalMessage['type'] == $this->_aPesonalType['refuse_pk']){
							$aPersonalMessageList[$key]['user_id'] = $aPk['receiver_user_id'];
							$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aPk['receiver_user_id']];
						}else{
							if($aPersonalMessage['user_id'] != $aPk['sender_user_id']){
								$aPersonalMessageList[$key]['user_id'] = $aPk['sender_user_id'];
								$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aPk['sender_user_id']];
							}else{
								$aPersonalMessageList[$key]['user_id'] = $aPk['receiver_user_id'];
								$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$aPk['receiver_user_id']];
							}
						}
						$aPersonalMessageList[$key]['data'] = $aPk;
						break;
					}
				}

			//反馈
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['es_feedback']){
				foreach($aUserFeedbackList as $key2=>$aUserFeedback){
					if($aUserFeedback['id'] == $aPersonalMessage['data_id']){
						$aUserFeedbackList[$key2]['es'] = array();
						$aUserFeedbackList[$key2]['es'] = $aEsRefer[$aUserFeedback['es_id']];
						$aUserFeedbackList[$key2]['es_type'] = $aEsTypeInfo[$aUserFeedback['es_id']];
						$aPersonalMessageList[$key]['data'] = $aUserFeedbackList[$key2];
						break;
					}
				}

			//赠送道具
			}elseif($aPersonalMessage['type'] == $this->_aPesonalType['prop_send']){
				$userId = $aPropSendRefer[$aPersonalMessage['data_id']]['user_id'];
				$aPersonalMessageList[$key]['user_id'] = $userId;
				$aPersonalMessageList[$key]['user_info'] = $aUserReferList[$userId];
				$aPersonalMessageList[$key]['data'] = $aPropSendRefer[$aPersonalMessage['data_id']];
			}

		}

		//限制10条评论以及20条回复
		foreach($aPersonalMessageList as $key=>$aPersonalMessage){
			if($aPersonalMessage['type'] == $this->_aPesonalType['ait'] || $aPersonalMessage['type'] == $this->_aPesonalType['retransmission']){
				$aPersonalMessageList[$key]['data']['comment_count'] = count($aPersonalMessage['data']['comment']);

				if($aPersonalMessageList[$key]['data']['comment_count'] > self::COMMENT_COUNT){
					$length = $aPersonalMessageList[$key]['data']['comment_count'] - self::COMMENT_COUNT;
					array_splice($aPersonalMessageList[$key]['data']['comment'],0,$length);
				}
				foreach($aPersonalMessageList[$key]['data']['comment'] as $key3=>$aComment){
					if(isset($aComment['reply']) && $aComment['reply']){
						$aPersonalMessageList[$key]['data']['comment'][$key3]['reply_count'] = count($aComment['reply']);
					}else{
						$aPersonalMessageList[$key]['data']['comment'][$key3]['reply_count'] = 0;
					}
					if($aPersonalMessageList[$key]['data']['comment'][$key3]['reply_count'] > self::REPLY_COUNT){
						$length = $aPersonalMessageList[$key]['data']['comment'][$key3]['reply_count'] - self::REPLY_COUNT;
						array_splice($aPersonalMessageList[$key]['data']['comment'][$key]['reply'],0,$length);
					}
				}
			}
		}

		return $aPersonalMessageList;
	}


	//详细说说
	private function _getShuoshuoList($aShuoshuoIds = array(), $aCommentIds = array()){

		//当有评论id
		if($aCommentIds){
			$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
			$aShuoshuoIdList = $oShuoshuoComment->get('shuoshuo_id',array('id'=>array('in',$aCommentIds)), '`id` ASC');
			if($aShuoshuoIdList === false){
				return false;
			}
			//收集说说Ids
			foreach($aShuoshuoIdList as $aShuoshuo){
				$aShuoshuoIds[] = $aShuoshuo['shuoshuo_id'];
			}

		}

		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoList = $oShuoshuo -> get('`id`,`user_id`,`content`,`images`,`create_time`,`source_type`,`source_id`,`transmit_times`,`support`,`views`',array('id' => array('in',$aShuoshuoIds)));
		if(!$aShuoshuoList){
			return $aShuoshuoList;
		}

		//收集说说Ids以及说说源Ids
		$aShuoshuoIds = array();
		$aShuoshuoSourceIds = array();
		foreach($aShuoshuoList as $aShuoshuo){
			if($aShuoshuo['source_id']){
				$aShuoshuoSourceIds[] = $aShuoshuo['source_id'];
			}
			$aShuoshuoIds[] = $aShuoshuo['id'];
		}



		//转发模块
		//获得说说的源信息
		$aSourceShuoshuoList = array();
		if($aShuoshuoSourceIds){
			//$shuoshuoSourceIds = implode(',',$aShuoshuoSourceIds);
			$aSourceShuoshuoList = $oShuoshuo->get('',array('id' => array('in',$aShuoshuoSourceIds)));
			if($aSourceShuoshuoList === false){
				return false;
			}
		}

		/*--------评论模块---------*/
		//查出当前说说的所有评论
		$shuoshuoIds = implode(',',$aShuoshuoIds);
		$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aShuoshuoCommentList = $oShuoshuoComment->get('', '`shuoshuo_id` in (' . $shuoshuoIds . ')', '`id` ASC');
		if($aShuoshuoCommentList === false){
			return false;
		}


		$aCommentRefer = array();
		foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
			$aCommentRefer[$aShuoshuoComment['id']] = $aShuoshuoCommentList[$key];
		}
		//组装评论结构
		$aCommentTree = array();
		if($aShuoshuoCommentList){
			foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
				if(!$aShuoshuoComment['parent_id']){
					$aCommentTree[$aShuoshuoComment['id']] = $aShuoshuoComment;
					$aCommentTree[$aShuoshuoComment['id']]['reply'] = array();
				}else{
					$parentId = $aShuoshuoComment['parent_id'];
					if($aCommentRefer[$parentId]){
						$aCommentTree[$parentId]['reply'][] = $aCommentRefer[$aShuoshuoComment['id']];
					}
				}
			}
		}

		//给转发源说说组装说说图片
		if($aSourceShuoshuoList){
			foreach($aSourceShuoshuoList as $key=>$aSourceShuoshuo){
				//组装源说说图片
				if($aSourceShuoshuo['images']){
					$aSourceShuoshuoList[$key]['images'] = explode(',', $aSourceShuoshuo['images']);
				}else{
					$aSourceShuoshuoList[$key]['images'] = array();
				}
			}
		}

		//组装数据
		foreach($aShuoshuoList as &$aShuoshuo){
			//组装转发说说
			$aShuoshuo['source_info'] = array();
			if($aShuoshuo['source_id']){
				$aShuoshuo['images'] = array();
				foreach($aSourceShuoshuoList as $aSourceShuoshuo){
					if($aSourceShuoshuo['id'] == $aShuoshuo['source_id']){
						$aShuoshuo['source_info'] = $aSourceShuoshuo;
						break;
					}else{
						$aShuoshuo['source_info'] = array();
					}
				}
			}else{
				//组装说说图片
				if($aShuoshuo['images']){
					$aShuoshuo['images'] = explode(',', $aShuoshuo['images']);
				}else{
					$aShuoshuo['images'] = array();
				}
			}
			//组装评论
			$aShuoshuo['comment'] = array();
			foreach($aCommentTree as $key=>$aComment){
				if($aComment['shuoshuo_id'] == $aShuoshuo['id']){
					$aShuoshuo['comment'][$key] = $aComment;
				}
			}
		}
		unset($aShuoshuo);
		return $aShuoshuoList;
	}

	//详细留言
	private function _getPublicMessageList($aPublicMessageIds){
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		$aPublicMessageList = $oPublicMessage->get('',array('id'=>array('in',$aPublicMessageIds)),'id ASC');
		if($aPublicMessageList === false){
			return false;
		}

		$aParentIds = array();
		//当只传过来回复信息的时候，收集父Id
		foreach($aPublicMessageList as $aPublicMessage){
			if($aPublicMessage['parent_id']){
				$parentId = $aPublicMessage['parent_id'];
				if(!in_array($parentId,$aPublicMessageIds)){
					$aParentIds[] = $parentId;
				}
			}else{
				$aParentIds[] = $aPublicMessage['id'];
			}
		}


		//查出所有留言信息以及回复
		if($aParentIds){
			$aPublicMessageList2 = array();
			$parentId = implode(',',$aParentIds);
			$aPublicMessageList2 = $oPublicMessage->get('','id in ('.$parentId.')'.' OR parent_id in ('.$parentId.')','id ASC');

			//去掉重复
			foreach($aPublicMessageList as $aPublicMessage){
				foreach($aPublicMessageList2 as $key => $aPublicMessage2){
					if($aPublicMessage['id'] == $aPublicMessage2['id']){
						unset($aPublicMessageList2[$key]);
					}
				}
			}

			//合并留言信息
			$aPublicMessageList = array_merge($aPublicMessageList2,$aPublicMessageList);
			sort($aPublicMessageList);
		}

		$aPublicMessageReferList = array();
		foreach($aPublicMessageList as $aPublicMessage){
			$aPublicMessageReferList[$aPublicMessage['id']] = $aPublicMessage;
		}

		//组装数据
		$aPublicMessageTree = array();
		foreach($aPublicMessageList as $aPublicMessage){
			if(!$aPublicMessage['parent_id']){
				$aPublicMessageTree[$aPublicMessage['id']] = $aPublicMessage;
				$aPublicMessageTree[$aPublicMessage['id']]['reply'] = array();
			}else{
				$parentId = $aPublicMessage['parent_id'];
				$aPublicMessageTree[$parentId]['reply'][] = $aPublicMessageReferList[$aPublicMessage['id']];
			}
		}

		unset($aPublicMessageList2,$aPublicMessageList);
		sort($aPublicMessageTree);

		//限制10条留言回复
		foreach($aPublicMessageTree as $key=>$aPublicMessage){
			if(!isset($aPublicMessage['reply']) && $aPublicMessage['reply']){
				$aPublicMessageTree[$key]['reply_count'] = 0;
				continue;
			}
			$aPublicMessageTree[$key]['reply_count'] = count($aPublicMessage['reply']);
			if($aPublicMessageTree[$key]['reply_count'] > self::PUBLIC_MESSAGE_REPLY_COUNT){
				$length = $aPublicMessageTree[$key]['reply_count'] - self::PUBLIC_MESSAGE_REPLY_COUNT;
				array_splice($aPublicMessageTree[$key]['reply'],0,$length);
			}
		}

		return $aPublicMessageTree;
	}

	//详细比赛结果
	private function _getMatchResultList($aMatchUserRelationIds){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('`id`,`user_id`,`match_id`,`best_score`', array('id' => array('in', $aMatchUserRelationIds)));
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}

		$aMatchIds = array();

		//得到赛事Id
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aMatchIds[] = $aMatchUserRelation['match_id'];
		}
		$aMatchIds = array_unique($aMatchIds);

		//得到赛事详细列表
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`name`,`profile`,`description`,`match_start_time`,`match_end_time`,`awards`,`winners`', array('id' => array('in', $aMatchIds)));
		if($aMatchList === false){
			return false;
		}

		//组装数据
		foreach($aMatchUserRelationList as &$aMatchUserRelation){
			foreach($aMatchList as $aMatch){
				if($aMatch['id'] == $aMatchUserRelation['match_id']){
					$aMatchUserRelation['match_name'] = $aMatch['name'];
					$aMatchUserRelation['match_end_time'] = $aMatch['match_end_time'];
					$aMatchUserRelation['match_profile'] = $aMatch['profile'];
					$aMatchUserRelation['match_winners'] = json_decode($aMatch['winners'],true);
					$aMatchUserRelation['match_awards'] = json_decode($aMatch['awards'],true);
					$aMatchUserRelation['description'] = $aMatch['description'];
					$aMatchUserRelation['match_start_time'] = $aMatch['match_start_time'];

				}
			}
		}
		return $aMatchUserRelationList;
	}


	//详细pk信息
	private function _getPkList($aPkIds){
		$oPkIndex = new Model(T_PK_INDEX);
		$aPkIndexList = $oPkIndex->get('',array('id' => array('in',$aPkIds)));

		//收集关卡Id
		$aMissionIds = array();
		foreach($aPkIndexList as $aPkIndex){
			$aMissionIds[] = $aPkIndex['mission_id'];
		}

		//获取关卡信息
		$aMissionList = $this->_getUserMissionInfo($aMissionIds);
		if($aMissionList === false){
			return false;
		}
		$aMisssionReferList = array();
		foreach($aMissionList as $aMission){
			$aMisssionReferList[$aMission['id']] = $aMission['name'];
		}

		//组装数据
		foreach($aPkIndexList as $key => $aPkIndex){
			$aPkIndexList[$key]['mission_name'] = '';
			$aPkIndexList[$key]['mission_name'] = $aMisssionReferList[$aPkIndex['mission_id']];
		}

		unset($aMissionList);
		return $aPkIndexList;

	}

	//查出题目类型
	private function _getEsType($aEsIds){
		$oEs = new Model(T_ES_INDEX);
		$aEsList = $oEs->get('`id`,`type_id`',array('id'=>array('in',$aEsIds)));
		if(!$aEsList){
			return $aEsList;
		}
		$aEsRefer = array();
		foreach($aEsList as $aEs){
			$aEsRefer[$aEs['id']] = $aEs['type_id'];
		}
		unset($aEsList);
		return $aEsRefer;
	}

	//查出题目信息
	private function _getEsInfo($aEsIds){
		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('`id`,`content_json`',array('id'=>array('in',$aEsIds)));
		if(!$aEsList){
			return $aEsList;
		}
		foreach($aEsList as &$aEs){
			$aEs['content_json'] = json_decode($aEs['content_json'],true);
		}
		return $aEsList;
	}

	//得到详细的反馈信息
	private function _getUserFeedbackInfo($aFeedbackIds){
		$oFeedback = new Model(T_ES_FEEDBACK);
		$aFeedbackList = $oFeedback->get('`id`,`user_id`,`es_id`,`reason`,`reply`,`status`,`reward`,`create_time`',array('id'=>array('in',$aFeedbackIds)));
		if(!$aFeedbackList){
			return $aFeedbackList;
		}
		foreach($aFeedbackList as &$aFeedback){
			$aFeedback['reward'] = json_decode($aFeedback['reward'],true);
		}

		return $aFeedbackList;
	}

	//得到详细的道具赠送信息
	private function _getPropSendInfo($aPropSendIds){
		$oPropSend = new Model(T_PROP_SEND_RECORDS);
		$aPropSendList = $oPropSend->get('', array('id'=>array('in',$aPropSendIds)));
		if(!$aPropSendList){
			return $aPropSendList;
		}
		$aPropIds = array();
		foreach($aPropSendList as $aPropSend){
			$aPropIds[] = $aPropSend['prop_id'];
		}
		$oProp = new Model(T_PROP);
		$aPropList = $oProp->get('', array('id'=>array('in',$aPropIds)));
		if(!$aPropList){
			return $aPropList;
		}

		$aPropRefer = array();
		foreach($aPropList as $aProp){
			$aPropRefer[$aProp['id']] = $aProp;
			unset($aPropRefer[$aProp['id']]['id']);
		}
		unset($aPropList);

		foreach($aPropSendList as $key=>$aPropSend){
			$aPropSendList[$key] = array_merge($aPropSend, $aPropRefer[$aPropSend['prop_id']]);
		}

		return $aPropSendList;
	}


	//查出所有关卡信息
	private function _getUserMissionInfo($aMissionIds){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', array('id' => array('in', $aMissionIds)));
		$aMissionList = Mission::convertMissionList($aMissionList);
		return $aMissionList;
	}

	//查出用户信息
	private function _getUserList($aUserIds){
		//$oUser = new Model(T_PERSONAL);
		//$aUserList = $oUser->get('id,name,profile', 'id in (' . implode(',', $aUserIds) . ')');
		//return $aUserList;
		return getUserListByUserIds($aUserIds);
	}

	//得到用户好友
	private function _getUserFriendsId($userId){
		$oUserFriend = new Model(T_USER_FRIEND);
		$aUserFriendInfo = $oUserFriend -> get('',array('id'=>$userId));
		if(!$aUserFriendInfo){
			return $aUserFriendInfo;
		}else{
			$aUserFriendInfo[0]['friends'] = json_decode($aUserFriendInfo[0]['friends'],true);
			$friendIds = '';
			if($aUserFriendInfo[0]['friends']){
				foreach($aUserFriendInfo[0]['friends'] as $friends){
					if($friends){
						$friendIds .= $friends . ',';
					}
				}
				if($friendIds){
					$friendIds = substr($friendIds, 0, -1);
				}
			}
			if($friendIds){
				return explode(',',$friendIds);
			}else{
				return $friendIds;
			}

		}
	}

}