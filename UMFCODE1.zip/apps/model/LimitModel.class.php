<?php
/*
 * 限制模型
 */
class LimitModel{
	public function addLimit($aData){
		$aData = $this->_parseLimitToDb($aData);
		return $this->_addLimit($aData);
	}

	public function addLoginLimit($aData){
		return $this->_addLoginLimit($aData);
	}

	public function addEmailLimit($aData){
		return $this->_addEmailLimit($aData);
	}

	//增加判断有没有数据，有就执行更新----林云龙
	private function _addLimit($aData){
		$oLimit = new Model(T_LIMIT);
		if(!$oLimit->count(array('id'=>$aData['id']))){
			return $oLimit->add($aData);
		}else{
			return $oLimit->update($aData, array('id'=>$aData['id']));
		}
	}

	private function _addLoginLimit($aData){
		$oLoginLimit = new Model(T_LOGIN_LIMIT);
		if(!$oLoginLimit->count(array('id'=>$aData['id']))){
			return $oLoginLimit->add($aData);
		}else{
			return $oLoginLimit->update($aData, array('id'=>$aData['id']));
		}
	}

	private function _addEmailLimit($aData){
		$oEmailLimit = new Model(T_EMAIL_LIMIT);
		if(!$oEmailLimit->count(array('id'=>$aData['id']))){
			return $oEmailLimit->add($aData);
		}else{
			return $oEmailLimit->update($aData, array('id'=>$aData['id']));
		}
	}



	public function deleteEmailLimit($beginToday){
		$oEmailLimit = new Model(T_EMAIL_LIMIT);
		return $oEmailLimit->delete('`create_time`<' . $beginToday);
	}

	public function getLimitInfo($userId, $field){
		$oLimit = new Model(T_LIMIT);
		$aLimitInfo = $oLimit->get($field, array('id' => $userId));
		if($aLimitInfo){
			$aLimitInfo = $aLimitInfo[0];
			$aLimitInfo[$field] = json_decode($aLimitInfo[$field], true);
			
		}
		return $aLimitInfo;
	}

	public function getLoginLimitInfo($ip, $field){
		$oLimit = new Model(T_LOGIN_LIMIT);
		$aLimitInfo = $oLimit->get($field, array('id' => $ip));
		if($aLimitInfo){
			$aLimitInfo = $aLimitInfo[0];
			$aLimitInfo[$field] = json_decode($aLimitInfo[$field], true);
		}
		return $aLimitInfo;
	}

	public function getEmailLimitInfo($qq){
		$oEmailLimit = new Model(T_EMAIL_LIMIT);
		$aLimitInfo = $oEmailLimit->get('', array('id' => $qq));
		if($aLimitInfo){
			$aLimitInfo = $aLimitInfo[0];
		}
		return $aLimitInfo;
	}

	public function setLimit($aData){
		$aData = $this->_parseLimitToDb($aData);       
		$oLimit = new Model(T_LIMIT);
		 return $oLimit->update($aData, array('id' => $aData['id']));
                 
	}

	public function setLoginLimit($aData){
		$oLimit = new Model(T_LOGIN_LIMIT);
		return $oLimit->update($aData, array('id' => $aData['id']));
	}

	public function getRemainedShuoshuoAccumulateTime($userId){
		$limitConfig = include dirname(dirname(__DIR__)) . '/apps/config/limit.config.php';
		$aLimit = explode(',', $limitConfig['SHUOSHUO_ACCUMULATE']);
		$remainedTimes = $aLimit[0];
		$aLimitInfo = $this->getLimitInfo($userId, 'shuoshuo_accumulate');
		if($aLimitInfo === false){
			return false;
		}elseif(!$aLimitInfo){
			return $remainedTimes;
		}
		$todayStartStamp = strtotime(date('Y-m-d') . ' 00:00:00');	//今天的开始时间戳
		if($aLimitInfo['shuoshuo_accumulate']){
			foreach($aLimitInfo['shuoshuo_accumulate'] as $shuoshuoTime){
				if($shuoshuoTime > $todayStartStamp){
					$remainedTimes--;
				}
			}
		}
		if($remainedTimes >= 0){
			return $remainedTimes;
		}else{
			return 0;
		}
	}

	private function _parseLimitToDb($aData){
		if(isset($aData['note'])){
			$aData['note'] = json_encode($aData['note']);
          
		}
		return $aData;
	}
}