<?php
/**
 * 后台用户模型
 */
class ManagerModel{
	public static function  xCrypt($password){
		return md5($password);
	}

	/**
	 * 根据email账号和密码得到用户信息
	 * @param type $email
	 * @param type $password
	 * @return array
	 */
	public function getUserInfoByEmailAndPassword($email, $password){
		$oUser = new Model(T_MANAGER);
		$password = self::xCrypt($password);
		$aUserInfo = $oUser->get('', "`email`='" . $email . "' and `password`='" . $password . "'");
		if($aUserInfo){
			$aUserInfo[0]['personal_info'] = json_decode($aUserInfo[0]['personal_info'], true);
			if($aUserInfo[0]['allowed_subject']){
				$aUserInfo[0]['allowed_subject'] = explode(',', $aUserInfo[0]['allowed_subject']);
			}
			return $aUserInfo[0];
		}else{
			return $aUserInfo;
		}
	}

	public function getUserInfoByEmail($email){
		$oUser = new Model(T_MANAGER);
		$aUserInfo = $oUser->get('', "email='" . $email . "'");
		if($aUserInfo){
			$aUserInfo[0]['personal_info'] = json_decode($aUserInfo[0]['personal_info'], true);
			if($aUserInfo[0]['allowed_subject']){
				$aUserInfo[0]['allowed_subject'] = explode(',', $aUserInfo[0]['allowed_subject']);
			}
			return $aUserInfo[0];
		}else{
			return $aUserInfo;
		}
	}

	/**
	 *根据用户id得到用户名
	 * @param type $userId 用户id
	 * @return string 用户名
	 */
	public function getUserNameByUserId($userId){
		$aUserInfo = $this->getUserInfoByUserId($userId);
		if($aUserInfo){
			return $aUserInfo['name'];
		}else{
			return $aUserInfo;
		}
	}

	/**
	 *根据用户id得到允许科目列表
	 * @param type $userId 用户id
	 * @return string 科目列表
	 */
	public function getUserAllowedSubjectByUserId($userId){
		$aUserInfo = $this->getUserInfoByUserId($userId);
		if($aUserInfo){
			return $aUserInfo['allowed_subject'];
		}else{
			return $aUserInfo;
		}
	}

	/**
	 *根据用户组id得到用户列表
	 * @param type $groupId 用户组id
	 * @param type $order 排序字段
	 * @param type $offset 偏移位置
	 * @param type $length 数量
	 * @return array
	 */
	public function getUserListByGroupId($groupId = 0, $order = '', $offset = '', $length = ''){
		$oUser = new Model(T_MANAGER);
		if($groupId){
			$aUserList = $oUser->get('', '`group_id`=' . $groupId, $order, $offset, $length);
		}else{
			$aUserList = $oUser->get('', '', $order, $offset, $length);
		}
		foreach($aUserList as &$aUser){
			$aUser['allowed_subject'] = explode(',', $aUser['allowed_subject']);
			$aUser['personal_info'] = json_decode($aUser['personal_info'], true);
		}
		return $aUserList;
	}

	/**
	 *根据用户id得到用户所有信息
	 * @param type $userId 用户组id
	 * @return array
	 */
	public function getUserInfoByUserId($userId){
		$oUser = new Model(T_MANAGER);
		$aUserInfo = $oUser->get('', array('id' => $userId));
		if(!$aUserInfo){
			return $aUserInfo;
		}else{
			$aUserInfo = $aUserInfo[0];
			$aUserInfo['personal_info'] = json_decode($aUserInfo['personal_info'], true);
			if($aUserInfo['allowed_subject']){
				$aUserInfo['allowed_subject'] = explode(',', $aUserInfo['allowed_subject']);
			}else{
				$aUserInfo['allowed_subject'] = array();
			}
			return $aUserInfo;
		}
	}

	/**
	 *添加一个用户
	 * @param type $aData
	 * @return int
	 */
	public function addUser($aData){
		$oUser = new Model(T_MANAGER);
		$aData['password'] = self::xCrypt($aData['password']);
		if(isset($aData['allowed_subject'])){
			$aData['allowed_subject'] = implode(',', $aData['allowed_subject']);
		}
		$aData['personal_info'] = json_encode($aData['personal_info']);
		$userId = $oUser->add($aData);
		return $userId;
	}

	/*
	 * 删除用户
	 * @param type $userId 用户id
	 * @return int
	 */
	public function deleteUserByUserId($userId){
		$oUser = new Model(T_MANAGER);
		$row = $oUser->delete(array('id' => $userId));
		return $row;
	}

	/**
	 *保存用户数据
	 * @param type $aData
	 * @return int
	 */
	public function setUserInfo($aData){
		$oUser = new Model(T_MANAGER);
		if(isset($aData['password'])){
			$aData['password'] = self::xCrypt($aData['password']);
		}
		if(isset($aData['personal_info'])){
			$aData['personal_info'] = json_encode($aData['personal_info']);
		}
		if(isset($aData['allowed_subject'])){
			$aData['allowed_subject'] = implode(',', $aData['allowed_subject']);
		}
		$row = $oUser->update($aData, array('id' => $aData['id']));
		return $row;
	}

	/**
	 *得到分组名
	 * @param type $groupId
	 * @return string
	 */
	public function getGroupNameByGroupId($groupId){
		$aGroupInfo = $this->getGroupInfoByGroupId($groupId);
		if($aGroupInfo){
			return $aGroupInfo['name'];
		}else{
			return $aGroupInfo;
		}
	}

	/**
	 *得到分组全部信息
	 * @param type $groupId
	 * @return array
	 */
	public function getGroupInfoByGroupId($groupId){
		$oGroup = new Model(T_MANAGER_GROUP);
		$aGroupInfo = $oGroup->get('', array('id' => $groupId));
		if($aGroupInfo){
			if($aGroupInfo[0]['permission']){
				$aGroupInfo[0]['permission'] = explode(',', $aGroupInfo[0]['permission']);
			}
			return $aGroupInfo[0];
		}else{
			return $aGroupInfo;
		}
	}

	/**
	 *得到分组列表
	 * @param type $order 排序字段
	 * @param type $offset 偏移位置
	 * @param type $length 数量
	 * @return array
	 */
	public function getGroupList($order = '', $offset = '', $length = ''){
		$oGroup = new Model(T_MANAGER_GROUP);
		$aGroupList = $oGroup->get('', '', $order, $offset, $length);
		if($aGroupList){
			foreach($aGroupList as &$aGroup){
				if($aGroup['permission']){
					$aGroup['permission'] = explode(',', $aGroup['permission']);
				}
			}
		}
		return $aGroupList;
	}

	/**
	 *添加一个分组
	 * @param type $aData 必须包含permission键名
	 * @return int
	 */
	public function addGroup($aData){
		$oGroup = new Model(T_MANAGER_GROUP);
		$aData['permission'] = implode(',', $aData['permission']);
		$groupId = $oGroup->add($aData);
		return $groupId;
	}

	/**
	 *更新组信息
	 * @param type $aData
	 * @return int
	 */
	public function setGroupInfo($aData){
		if(isset($aData['permission'])){
			$aData['permission'] = implode(',', $aData['permission']);
		}
		$oGroup = new Model(T_MANAGER_GROUP);
		$row = $oGroup->update($aData, array('id' => $aData['id']));
		return $row;
	}

	/*
	 * 删除组
	 * @param type $userId 用户id
	 * @return int
	 */
	public function deleteGroupByGroupId($groupId){
		$oGroup = new Model(T_MANAGER_GROUP);
		$row = $oGroup->delete(array('id' => $groupId));
		return $row;
	}
//====================================pipeline标识 版本号:1752======================================

	public function getUserCountByName($name){
		$oUser = new Model(T_MANAGER);
		return $oUser->count("`name`='" . $name . "'");
	}


	//---林云龙
	public function getUserList($name = '', $email='', $startTime = 0, $endTime = 0, $isForbidden = 0, $group = 0, $page = 1, $pageSize = 20){
		$offect = ($page-1) * $pageSize;
		$where = '';
		if($name){
			$where .= "name='" . $name . "'";
		}

		if($email){
			if($where){
				$where .= ' AND ';
			}
			$where .= "email='" . $email . "'";
		}

		if($startTime && $endTime){
			if($where){
				$where .= ' AND ';
			}
			$where .= 'create_time<=' . $endTime . ' AND create_time>' . $startTime;
		}

		if($isForbidden){
			if($where){
				$where .= ' AND ';
			}
			$where .= 'is_forbidden=' . $isForbidden;
		}

		if($group){
			if($where){
				$where .= ' AND ';
			}
			$where .= 'group_id=' . $group;
		}
		$oUser = new Model(T_MANAGER);
		return $oUser->get('', $where, '', $offect, $pageSize);
	}

	//取得这个科目出过题目的人员id
	public function getCreatedEsManagerIdsBySubject($subjectId){
		$oEsLog = new Model(T_ES_LOG);
		$aEsLogList = $oEsLog->get('DISTINCT `submiter_user_id`', '`subject_id`=' . $subjectId . ' AND `action`=1');
		if(!$aEsLogList){
			return $aEsLogList;
		}
		$aManagerIds = array();
		foreach($aEsLogList as $aEsLog){
			$aManagerIds[] = $aEsLog['submiter_user_id'];
		}
		return $aManagerIds;
	}

	public function getManagerListByIds($aManagerIds){
		if(!$aManagerIds){
			return $aManagerIds;
		}
		$oManager = new Model(T_MANAGER);
		return $oManager->get('`id`,`name`', array('id' => array('in', $aManagerIds)));
	}

}