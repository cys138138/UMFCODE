<?php
/*
 * 前台用户模型
 */
class UserModel{
	const VIP_COMMON = 1;	//普通vip
	const VIP_PLATINUM = 2;	//白金vip
	const VIP_DIAMOND = 3;	//钻石vip

	public static function  xCrypt($password){
		return md5($password);
	}

	public function getUserInfoByEmailAndPassword($email, $password){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', "`email`='" . $email . "' AND `password`='" . self::xCrypt($password) . "'");
		if($aUserInfo){
			//$this->_writeUserLoginLog($aUserInfo[0]['id']);
			return $aUserInfo[0];
		}
		return $aUserInfo;
	}

	public function getUserInfoByNumberIdAndPassword($numberId, $password){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', '`id`=' . $numberId . " AND `password`='" . self::xCrypt($password) . "'");
		if($aUserInfo){
			//$this->_writeUserLoginLog($aUserInfo[0]['id']);
			return $aUserInfo[0];
		}
		return $aUserInfo;
	}

	public function getUserInfoByMobileAndPassword($mobile, $password){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', '`mobile`=' . $mobile . " AND `password`='" . self::xCrypt($password) . "'");
		if($aUserInfo){
			return $aUserInfo[0];
		}
		return $aUserInfo;
	}

	public function isEmailExist($email){
		$oUser = new Model(T_USER);
		return $oUser->count("`email`='" . $email . "'");
	}

	public function isNumberIdExist($NumberId){
		$oUser = new Model(T_USER);
		return $oUser->count("`id`=" . $NumberId);
	}

	public function isMobileExist($mobile){
		$oUser = new Model(T_USER);
		return $oUser->count("`mobile`=" . $mobile);
	}

	public function getSchoolInfoByAreaIdAndSchoolName($areaId, $schoolName, $isCityId = 0){
		$oSchool = new Model(T_SCHOOL);
		$where = '';
		if($isCityId){
			$oArea = new Model(T_AREA);
			$aAreaList = $oArea->get('`id`', '`pid`=' . $areaId);
			if(!$aAreaList){
				return $aAreaList;
			}
			$aAreaIds = array();
			foreach($aAreaList as $aArea){
				$aAreaIds[] = $aArea['id'];
			}
			$where = '`area_id` in (' . implode(',', $aAreaIds) . ") AND `name`='" . $schoolName . "'";
		}else{
			$where = '`area_id`=' . $areaId . " AND `name`='" . $schoolName . "'";
		}
		$schoolInfo = $oSchool->get('', $where);
		if($schoolInfo){
			return $schoolInfo[0];
		}else{
			return $schoolInfo;
		}
	}

	public function getSchoolInfoBySchoolId($schoolId){
		$oSchool = new Model(T_SCHOOL);
		$aSchoolInfo = $oSchool->get('', array('id' => $schoolId));
		if($aSchoolInfo){
			return $aSchoolInfo[0];
		}
		return $aSchoolInfo;
	}

	public function setSchoolInfo($aData){
		$oSchool = new Model(T_SCHOOL);
		$row = $oSchool->update($aData, array('id' => $aData['id']));
		return $row;
	}

	public function getRegisterNumberAccount(){
		$oAccountNumber = new Model(T_ACCOUNT_NUMBER);
		$where = '`level`=0';
		$accountNumberCount = $oAccountNumber->count($where);
		if($accountNumberCount){
			if($accountNumberCount < 10000){
				//警告、通知
			}
			$offect = rand(0, $accountNumberCount - 1);
			$aAccountNumberInfo = $oAccountNumber->get('', $where, '', $offect, 1);
			if($aAccountNumberInfo){
				$result = $oAccountNumber->delete('`number`=' . $aAccountNumberInfo[0]['number']);
				if($result){
					return $aAccountNumberInfo[0]['number'];
				}else{
					return false;
				}
			}
			return $aAccountNumberInfo;
		}
		return $accountNumberCount;
	}

	public function getUserInfoByNumberId($NumberId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', '`id`=' . $NumberId);
		if($aUserInfo){
			return $aUserInfo[0];
		}else{
			return $aUserInfo;
		}
	}

	public function getUserInfoByMobile($mobile){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('`id`,`email`,`proxy_id`', '`mobile`=' . $mobile);
		if($aUserInfo){
			$aUserInfo = $aUserInfo[0];
			$oPersonal = new Model(T_PERSONAL);
			$aPersonalInfo = $oPersonal->get('`name`', array('id' => $aUserInfo['id']));
			if($aPersonalInfo === false){
				return false;
			}elseif(isset($aPersonalInfo[0]['name'])){
				$aUserInfo['name'] = $aPersonalInfo[0]['name'];
			}else{
				$aUserInfo['name'] = '';
			}
		}
		return $aUserInfo;
	}

	public function getUserInfoByUserId($userId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('*', array('id' => $userId));
		if($aUserInfo){
			return $aUserInfo[0];
		}else{
			return $aUserInfo;
		}
	}

	public function getUserInfoByEmail($email){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', "`email`='" . $email . "'");
		if($aUserInfo){
			return $aUserInfo[0];
		}else{
			return $aUserInfo;
		}
	}

	public function getUserDetailInfoByUserId($userId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('*', array('id' => $userId));
		if($aUserInfo){
			$oPersonal = new Model(T_PERSONAL);
			$aPersonalInfo = $oPersonal->get('', array('id' => $userId));
			if($aPersonalInfo === false){
				return false;
			}elseif($aPersonalInfo){
				$aUserInfo[0]['name'] = $aPersonalInfo[0]['name'];
				$aUserInfo[0]['profile'] = $aPersonalInfo[0]['profile'];
				$aUserInfo[0]['birth_day'] = date('Y-m-d', $aPersonalInfo[0]['birth_date']);
				$aUserInfo[0]['call_phone'] = $aPersonalInfo[0]['call_phone'];
				$aUserInfo[0]['gender'] = $aPersonalInfo[0]['gender'];
				$aUserInfo[0]['address'] = $aPersonalInfo[0]['address'];
				$aUserInfo[0]['signature'] = $aPersonalInfo[0]['signature'];
				$aUserInfo[0]['accept_pk_count'] = $aPersonalInfo[0]['accept_pk_count'];
				$oArea = new Model(T_AREA);
				$aAreaInfo = $oArea->get('', array('id' => $aPersonalInfo[0]['area_id']));
				if($aAreaInfo === false){
					return false;
				}elseif($aAreaInfo){
					$aUserInfo[0]['area_id'] = $aPersonalInfo[0]['area_id'];
					$aCityInfo = $oArea->get('', array('id' => $aAreaInfo[0]['pid']));
					if($aCityInfo === false){
						return false;
					}else{
						$aUserInfo[0]['city_id'] = $aCityInfo[0]['id'];
						$aUserInfo[0]['province_id'] = $aCityInfo[0]['pid'];
					}
				}else{
					$aUserInfo[0]['province_id'] = 0;
					$aUserInfo[0]['city_id'] = 0;
					$aUserInfo[0]['area_id'] = 0;
				}
			}
			$oClass = new Model(T_USER_CLASS);
			$aClassInfo = $oClass->get('', '`user_id`=' . $userId . ' AND `is_active`=1');
			if($aClassInfo){
				$aUserInfo[0]['grade_num'] = $aClassInfo[0]['grade'];
				$aUserInfo[0]['grade'] = $GLOBALS['GRADE'][$aClassInfo[0]['grade']];
				$aUserInfo[0]['class'] = $aClassInfo[0]['class'];
				$oSchool = new Model(T_SCHOOL);
				$aSchoolInfo = $oSchool->get('', array('id' => $aClassInfo[0]['school_id']));
				if($aSchoolInfo === false){
					return false;
				}elseif($aSchoolInfo){
					$aUserInfo[0]['school_name'] = $aSchoolInfo[0]['name'];
				}else{
					$aUserInfo[0]['school_name'] = '-';
				}
			}
			return $aUserInfo[0];
		}else{
			return $aUserInfo;
		}
	}

	public function getPersonalInfoByUserId($userId, $fileds = ''){
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalInfo = $oPersonal->get($fileds, array('id' => $userId));
		if($aPersonalInfo){
			if(isset($aPersonalInfo[0]['xxt_data'])){
				$aPersonalInfo[0]['xxt_data'] = json_decode($aPersonalInfo[0]['xxt_data'], true);
			}
			return $aPersonalInfo[0];
		}else{
			return $aPersonalInfo;
		}
	}

	public function setUserInfo($aData){
		if(isset($aData['xxt_data'])){
			$aData['xxt_data'] = json_encode($aData['xxt_data']);
		}
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalInfo = $oPersonal->get('', array('id' => $aData['id']));
		if($aPersonalInfo === false){
			return false;
		}elseif($aPersonalInfo){
			$row = $oPersonal->update($aData, array('id' => $aData['id']));
		}else{
			$row = $oPersonal->add($aData);
		}
		return $row;
	}

	public function setUserIndexInfo($aData){
		$oUser = new Model(T_USER);
		$row = $oUser->update($aData, array('id' => $aData['id']));
		return $row;
	}

	public function setUserIndexInfoByMobile($aData, $mobile){
		$oUser = new Model(T_USER);
		$row = $oUser->update($aData, '`mobile`=' . $mobile);
		return $row;
	}

	public function getUserLotteryDrawList(){
		$oUser = new Model(T_USER);
		$aUserList = $oUser->get('`id`,`lottery_draw_status`,`lottery_draw_time`', '`lottery_draw_status`!=0 AND `lottery_draw_status`!=1', '`lottery_draw_time` DESC', 0, 50);
		if(!$aUserList){
			return $aUserList;
		}
		$aUserIds = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['id'];
		}
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalList = $oPersonal->get('`id`,`name`', array('id' => array('in', $aUserIds)));
		if($aPersonalList === false){
			return false;
		}
		foreach($aUserList as $key => $aUser){
			$aUserList[$key]['name'] = $aUser['id'];
			foreach($aPersonalList as $aPersonal){
				if($aUser['id'] == $aPersonal['id']){
					$aUserList[$key]['name'] = $aPersonal['name'];
					break;
				}
			}
		}
		return $aUserList;
	}

	public function setUserPasswordByNumberId($numberId, $password){
		$oUser = new Model(T_USER);
		return $oUser->update(array('password' => self::xCrypt($password)), '`id`=' . $numberId);

	}

	public function _writeUserLoginLog($userId){
		$oUserLoginLog = new Model(T_USER_LOGIN_LOG);
		$currentTime = time();
		$aUserLogInfo = $oUserLoginLog->get('', 'user_id=' . $userId);
		if($aUserLogInfo === false){
			return false;
		}elseif($aUserLogInfo){
			$aLoginTimes = explode(',', $aUserLogInfo[0]['login_times']);
			foreach($aLoginTimes as $key => $value){
				if(($currentTime - $value) > 2592000){
					unset($aLoginTimes[$key]);
				}
			}
			$loginTimes = implode(',', $aLoginTimes) . ',' . $currentTime;
			$aData['login_times'] = $loginTimes;
			$row = $oUserLoginLog->update($aData, 'user_id=' . $userId);
			if(!$row){
				$data = json_encode($aData);
				myLog('更新用户id为: ' . $userId . ' 的登陆日志到用户登陆日志表失败，失败数据的json: ' . $data);
			}
		}else{
			$aLogData['user_id'] = $userId;
			$aLogData['login_times'] = $currentTime;
			$aLogId = $oUserLoginLog->add($aLogData);
			if(!$aLogId){
				$logData = json_encode($aLogData);
				myLog('添加登陆日志到用户登陆日志表失败，失败数据的json: ' . $logData);
			}
		}
		$oAllUserLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$aAllLogData['user_id'] = $userId;
		$aAllLogData['login_time'] = $currentTime;
		$logId = $oAllUserLoginLog->add($aAllLogData);
		if(!$logId){
			$logData = json_encode($aAllLogData);
			myLog('写登陆日志到用户登陆日志全纪录表失败，失败数据的json: ' . $logData);
		}
	}

	public function addUser($aData){
		if(isset($aData['password'])){
			$aData['password'] = self::xCrypt($aData['password']);
		}
		$oUser = new Model(T_USER);
		$userId = $oUser->add($aData);
		if($userId){
			//$this->_writeUserLoginLog($userId);
		}
		return $userId;
	}

	public function addSchool($aData){
		$oSchool = new Model(T_SCHOOL);
		$schoolId = $oSchool->add($aData);
		return $schoolId;
	}

	public function addClass($aData){
		$oSchool = new Model(T_SCHOOL);
		$aSchoolInfo = $oSchool->get('area_id', array('id' => $aData['school_id']));
		if(!$aSchoolInfo){
			return false;
		}
		$oArea = new Model(T_AREA);
		$aAreaInfo = $oArea->get('', array('id' => $aSchoolInfo[0]['area_id']));
		if(!$aAreaInfo){
			return false;
		}
		$aCityInfo = $oArea->get('', array('id' => $aAreaInfo[0]['pid']));
		if(!$aCityInfo){
			return false;
		}
		$aData['province_id'] = $aCityInfo[0]['pid'];
		$aData['city_id'] = $aCityInfo[0]['id'];
		$aData['area_id'] = $aAreaInfo[0]['id'];
		$oClass = new Model(T_USER_CLASS);
		return $oClass->add($aData);
	}

	public function isClassExist($year, $schoolId, $grade, $class, $userId = 0){
		$oClass = new Model(T_USER_CLASS);
		$where = '`year`=' . $year . ' AND `school_id`=' . $schoolId . ' AND `grade`=' . $grade . " AND `class`='" . $class . "'";
		if($userId){
			$where .= ' AND `user_id`=' . $userId;
		}
		$count = $oClass->count($where);
		return $count;
	}

	public function getAreaList(){
        //读取
        //$this->trueTableName = 'place';
		$oArea = new Model(T_AREA);
        //$data = $this->select();
		$aAreaList = $oArea->get();
        //组装成分层数组
        $aResult = array();
        $aData = array();
        $deleteKey = array();
        foreach ($aAreaList as $aPlace) {
            $aResult[$aPlace['id']] = $aPlace;
        }
        $aData = $aResult;

        foreach ($aResult as $key => $val) {
            if ($val['pid']) {
                $aResult[$val['pid']]['area'][$val['id']] = &$aResult[$val['id']];
                $deleteKey[] = $key;
            }
        }

        foreach ($deleteKey as $k) {
            unset($aResult[$k]);
        }
        return array('idList' => $aData, 'lvList' => $aResult);
    }

	public function getAreaInfoByAreaId($areaId){
		$oArea = new Model(T_AREA);
		$aAreaInfo = $oArea->get('', array('id' => $areaId));
		if($aAreaInfo){
			return $aAreaInfo[0];
		}else{
			return $aAreaInfo;
		}
	}

	public function getAreaListByAreaIds($aAreaIds){
		$oArea = new Model(T_AREA);
		return $oArea->get('', array('id' => array('in', $aAreaIds)));
	}

	private function _parseGetSchoolListCondition($areaId = 0, $type = -1){
		$where = '';
		if($areaId){
			$oArea = new Model(T_AREA);
			$aAreaList = $oArea->get('', '`pid`=' . $areaId);
			if($aAreaList === false){
				return false;
			}elseif(!$aAreaList){
				$areaIds = $areaId;
			}else{
				$areaIds = '';
				foreach($aAreaList as $aArea){
					$areaIds .= $aArea['id'] . ',';
				}
				$areaIds = substr($areaIds, 0, -1);
				$aLastAreaList = $oArea->get('', '`pid` in (' . $areaIds . ')');
				if($aLastAreaList === false){
					return false;
				}elseif($aLastAreaList){
					$lastAreaIds = '';
					foreach($aLastAreaList as $aLastArea){
						$lastAreaIds .= $aLastArea['id'] . ',';
					}
					$areaIds = substr($lastAreaIds, 0, -1);
				}
			}
			if(substr_count($areaIds, ',')){
				$where = '`area_id` in (' . $areaIds . ')';
			}else{
				$where = '`area_id`=' . $areaIds;
			}
		}
		if($type != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`type`=' . $type;
		}
		return $where;
	}

	/**
	*根据地区id和类型查询学校
	*
	*/
	public function getSchoolListByAreaId($areaId = 0, $type = -1, $offect = 0, $length = null){
		$where = $this->_parseGetSchoolListCondition($areaId, $type);
		if($where === false){
			return false;
		}
		$oSchool = new Model(T_SCHOOL);
		$aSchoolList = $oSchool->get('', $where, '', $offect, $length);
		return $aSchoolList;
	}

	public function getSchoolCountByAreaId($areaId = 0, $type = -1){
		$where = $this->_parseGetSchoolListCondition($areaId, $type);
		if($where === false){
			return false;
		}
		$oSchool = new Model(T_SCHOOL);
		$aSchoolCountInfo = $oSchool->get('count(*) as `nums`', $where);
		if($aSchoolCountInfo){
			return $aSchoolCountInfo[0]['nums'];
		}else{
			return false;
		}
	}


	public function getClassListBySchoolId($schoolId, $year = 0){
		if(!$year){
			$year = date('Y');
		}
		$oClass = new Model(T_USER_CLASS);
		$aClassList = $oClass->get('distinct `grade`,`class`', '`school_id`=' . $schoolId . ' AND `year`=' . $year);
		if($aClassList === false){
			return false;
		}
		foreach($aClassList as &$aClass){
			$aClass = $aClass['grade'] . ',' . $aClass['class'];
		}
		$aOriginalClassList = array();
		for($i = 1; $i < 10; $i++){
			for($j = 1; $j < 21; $j++){
				$aOriginalClassList[] = $i . ',' . $j . '班';
			}
		}
		$aClassList = array_merge($aOriginalClassList, $aClassList);
		$aClassList = array_unique($aClassList);
		$aGradeList = array();
		foreach($aClassList as $class){
			$aClassArr = explode(',', $class);
			$aGradeList[$aClassArr[0]][] = $aClassArr[1];
		}
		$aResult = array();
		foreach($aGradeList as $key => $value){
			$aTemp = array();
			$aTemp['name'] = $GLOBALS['GRADE'][$key];
			$aTemp['child'] = $value;
			$aResult[$key] = $aTemp;
		}
		return $aResult;
	}

	public function getClassListBySchoolIdAndGrade($schoolId, $grade = 0){
		$where = '`school_id`=' . $schoolId;
		if($grade){
			$where .= ' AND `grade`=' . $grade;
		}
		$oClass = new Model(T_USER_CLASS);
		return $oClass->get('distinct `grade`,`class`', $where);
	}

	public function getActiveClassInfoByUserId($userId){
		$oClass = new Model(T_USER_CLASS);
		$aClassInfo = $oClass->get('', '`user_id`=' . $userId . ' AND `is_active`=1');
		if($aClassInfo){
			return $aClassInfo[0];
		}else{
			return $aClassInfo;
		}
	}

	public function getUserList($page, $pageSize, $startTime = 0, $endTime = 0, $areaId = 0, $schoolId = 0, $gender= 0, $name = '', $ageStart = 0, $ageEnd = 0, $account = 0, $orderByCreateTime = 0, $approveStatu = -1, $vip = -1, $isConfirmEmail = -1, $isConfirmMobile = -1){
		$offset = ($page -1) * $pageSize;
		$oDboi = new DBOI();
		$where = $this->_parseUserListCondition($startTime, $endTime, $areaId, $schoolId, $gender, $name, $ageStart, $ageEnd, $account, $approveStatu, $vip, $isConfirmEmail, $isConfirmMobile);
		if($where === false){
			return false;
		}
		if($orderByCreateTime){
			$order = '`t1`.`last_login_time` desc';
		}else{
			$order = '`t1`.`id` desc';
		}
		if(($areaId || $schoolId) && !$account){
			$aUserList = $oDboi->fields('`t1`.`id`,`t1`.`email`,`t1`.`mobile`,`t1`.`xxt_id`,`t1`.`is_forbidden`,`t1`.`approve_status`,`t1`.`create_time`,`t1`.`last_login_time`,`pers`.`name`,`pers`.`gender`,`pers`.`birth_date`,`pers`.`profile`,`pers`.`is_email_active`,`class`.`school_id`,`class`.`grade`,`class`.`class`,`num`.`vip`,`num`.`vip_expiration_time`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `pers` on `t1`.`id`=`pers`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `t1`.`id`=`class`.`user_id`')->leftjoin(T_USER_NUMERICAL, 'as `num` on `t1`.`id`=`num`.`id`')->where($where)->orderby($order)->limit($offset, $pageSize)->select();
			if(!$aUserList){
				return $aUserList;
			}
		}else{
			$aUserList = $oDboi->fields('`t1`.`id`,`t1`.`email`,`t1`.`mobile`,`t1`.`xxt_id`,`t1`.`is_forbidden`,`t1`.`approve_status`,`t1`.`create_time`,`t1`.`last_login_time`,`pers`.`name`,`pers`.`gender`,`pers`.`birth_date`,`pers`.`profile`,`pers`.`is_email_active`,`num`.`vip`,`num`.`vip_expiration_time`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `pers` on `t1`.`id`=`pers`.`id`')->leftjoin(T_USER_NUMERICAL, 'as `num` on `t1`.`id`=`num`.`id`')->where($where)->orderby($order)->limit($offset, $pageSize)->select();
			if(!$aUserList){
				return $aUserList;
			}
			$aUserIds = array();
			foreach($aUserList as $aUser){
				$aUserIds[] = $aUser['id'];
			}
			$oClass = new Model(T_USER_CLASS);
			$aClassList = $oClass->get('', '`user_id` in (' . implode(',', $aUserIds) . ') AND `is_active`=1');
			if($aClassList === false){
				return false;
			}
			foreach($aUserList as $key => $aUser){
				$aUserList[$key]['school_id'] = null;
				$aUserList[$key]['grade'] = null;
				$aUserList[$key]['class'] = null;
				foreach($aClassList as $aClass){
					if($aClass['user_id'] == $aUser['id']){
						$aUserList[$key]['school_id'] = $aClass['school_id'];
						$aUserList[$key]['grade'] = $aClass['grade'];
						$aUserList[$key]['class'] = $aClass['class'];
						break;
					}
				}
			}
		}
		$oArea = new Model(T_AREA);
		$oSchool = new Model(T_SCHOOL);
		//$oUserLoginLog = new Model(T_USER_LOGIN_LOG);
		foreach($aUserList as &$aUser){
			if($aUser['vip'] > 0 && $aUser['vip_expiration_time'] < time()){
				$aUser['vip'] = 0;
			}

			if(!$aUser['name']){
				$aUser['name'] = '---';
			}
			if($aUser['gender'] == 1){
				$aUser['gender'] = '男';
			}elseif($aUser['gender'] == 2){
				$aUser['gender'] = '女';
			}else{
				$aUser['gender'] = '-';
			}
			if($aUser['birth_date']){
				$birthday = date('m-d', $aUser['birth_date']);	//生日
				$currentYear = date('Y');
				$birthYear = date('Y', $aUser['birth_date']);
				$birthdayStamp = date($currentYear . '-' . $birthday);	//今年的生日时间戳
				//是否已经过了生日
				if($birthdayStamp < time()){
					$aUser['age'] = $currentYear - $birthYear; //过了生日了
				}else{
					$aUser['age'] = $currentYear - $birthYear - 1; //没过生日
				}
			}else{
				$aUser['age'] = '--';
			}
			if($aUser['school_id']){
				$aSchoolInfo = $oSchool->get('`name`,`area_id`', array('id' => $aUser['school_id']));
				if($aSchoolInfo === false){
					return false;
				}elseif($aSchoolInfo){
					$aUser['school_name'] = $aSchoolInfo[0]['name'];
					$schoolAreaId = $aSchoolInfo[0]['area_id'];
					if($schoolAreaId){
						$aAreaInfo = $oArea->get('', array('id' => $schoolAreaId));
						if($aAreaInfo){
							$areaName = $aAreaInfo[0]['name'];
							$aAreaInfo = $oArea->get('', array('id' => $aAreaInfo[0]['pid']));
							if($aAreaInfo){
								$cityName = $aAreaInfo[0]['name'];
								$aAreaInfo = $oArea->get('', array('id' => $aAreaInfo[0]['pid']));
								if($aAreaInfo){
									$provinceName = $aAreaInfo[0]['name'];
									$aUser['area_name'] = $provinceName . ' ' . $cityName . ' ' . $areaName;
								}
							}
						}
					}else{
						$aUser['area_name'] = '---';
					}


				}else{
					$aUser['school_name'] = '---';
					$aUser['area_name'] = '---';
				}
			}else{
				$aUser['school_name'] = '---';
				$aUser['area_name'] = '---';
			}

			if($aUser['grade']){
				$aUser['grade'] = $GLOBALS['GRADE'][$aUser['grade']];
			}else{
				$aUser['grade'] = '---';
			}
			/*$aUserLoginInfo = $oUserLoginLog->get('', '`user_id`=' . $aUser['id']);
			if($aUserLoginInfo){
				$aUser['login_times'] = substr_count($aUserLoginInfo[0]['login_times'], ',') + 1;
			}elseif($aUserLoginInfo === false){
				return false;
			}else{
				$aUser['login_times'] = 0;
			}*/
		}
		return $aUserList;
	}

	public function getUserCount($startTime = 0, $endTime = 0, $areaId = 0, $schoolId = 0, $gender= 0, $name = '', $ageStart = 0, $ageEnd = 0, $account = 0, $approveStatu = -1, $vip = -1, $isConfirmEmail = -1, $isConfirmMobile = -1){
		$oDboi = new DBOI();
		$where = $this->_parseUserListCondition($startTime, $endTime, $areaId, $schoolId, $gender, $name, $ageStart, $ageEnd, $account, $approveStatu, $vip, $isConfirmEmail, $isConfirmMobile);
		if(($areaId || $schoolId) && !$account){
			$aUserCount = $oDboi->fields('count(*) as nums')->table(T_USER)->leftjoin(T_PERSONAL, 'as `pers` on `t1`.`id`=`pers`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `t1`.`id`=`class`.`user_id`')->leftjoin(T_USER_NUMERICAL, 'as `num` on `t1`.`id`=`num`.`id`')->where($where)->select();
		}else{
			$aUserCount = $oDboi->fields('count(*) as nums')->table(T_USER)->leftjoin(T_PERSONAL, 'as `pers` on `t1`.`id`=`pers`.`id`')->leftjoin(T_USER_NUMERICAL, 'as `num` on `t1`.`id`=`num`.`id`')->where($where)->select();
		}
		if($aUserCount){
			return $aUserCount[0]['nums'];
		}else{
			return $aUserCount;
		}
	}

	private function _parseUserListCondition($startTime = 0, $endTime = 0, $areaId = 0, $schoolId = 0, $gender= 0, $name = '', $ageStart = 0, $ageEnd = 0, $account = 0, $approveStatu = -1, $vip = 0, $isConfirmEmail = -1, $isConfirmMobile = -1){
		$where = '';
		if($account){
			if(preg_match('/^[0-9]*$/', $account)){
				$where = '`t1`.`id`=' . $account;
			}else{
				$where = "`t1`.`email`='" . $account . "'";
			}
		}else{
			if($startTime){
				$where = '`t1`.`create_time`>=' . $startTime;
			}
			if($endTime){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`t1`.`create_time`<=' . $endTime;
			}
			if($approveStatu != -1){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`t1`.`approve_status`=' . $approveStatu;
			}
			if($schoolId){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`class`.`school_id`=' . $schoolId . ' AND `class`.`is_active`=1';
			}else{
				if($areaId){
					if($where){
						$where .= ' AND ';
					}
					$oArea = new Model(T_AREA);
					$aAreaInfo = $oArea->get('', array('id' => $areaId));
					if(!$aAreaInfo){
						return false;
					}elseif($aAreaInfo[0]['pid'] == 0){	//省份ID
						$where = '`class`.`province_id`=' . $areaId;
					}else{
						$aAreaInfo = $oArea->get('', array('id' => $aAreaInfo[0]['pid']));
						if(!$aAreaInfo){
							return false;
						}elseif($aAreaInfo[0]['pid'] == 0){	//城市ID
							$where = '`class`.`city_id`=' . $areaId;
						}else{	//区县ID
							$where = '`class`.`area_id`=' . $areaId;
						}
					}
				}
			}
			if($gender){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`pers`.`gender`=' . $gender;
			}
			if($name){
				if($where){
					$where .= ' AND ';
				}
				$where .= "`pers`.`name`='" . $name . "'";
			}
			if($ageStart){
				if($where){
					$where .= ' AND ';
				}
				$ageStartYear = date('Y') - $ageStart;
				$ageStartMothDay = date('m-d');
				$ageStartTime = strtotime($ageStartYear . '-' . $ageStartMothDay);
				$where .= '`pers`.`birth_date`<=' . $ageStartTime;
			}
			if($ageEnd){
				if($where){
					$where .= ' AND ';
				}
				$ageEndYear = date('Y') - $ageEnd - 1;
				$ageEndMothDay = date('m-d');
				$ageEndTime = strtotime($ageEndYear . '-' . $ageEndMothDay . ' 23:59:59');
				$where .= '`pers`.`birth_date`>' . $ageEndTime;
			}
			if($vip != -1){
				if($where){
					$where .= ' AND ';
				}
				if($vip){
					$where .= '`num`.`vip`=' . $vip . ' AND `num`.`vip_expiration_time`>' . time();
				}else{
					$where .= '`num`.`vip`=0';
				}
			}
			if($isConfirmEmail != -1){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`pers`.`is_email_active`=' . $isConfirmEmail;
			}
			if($isConfirmMobile != -1){
				if($where){
					$where .= ' AND ';
				}
				if($isConfirmMobile){
					$where .= '`t1`.`mobile`>0';
				}else{
					$where .= '`t1`.`mobile`=0';
				}
			}
		}
		return $where;
	}

	private function _getAreaSchoolIds($areaId){
		$oArea = new Model(T_AREA);
		$aAreaList = $oArea->get('', '`pid`=' . $areaId);
		if($aAreaList === false){
			return false;
		}elseif(!$aAreaList){
			$areaIds = $areaId;
		}else{
			$areaIds = '';
			foreach($aAreaList as $aArea){
				$areaIds .= $aArea['id'] . ',';
			}
			$areaIds = substr($areaIds, 0, -1);
			$aLastAreaList = $oArea->get('', '`pid` in (' . $areaIds . ')');
			if($aLastAreaList === false){
				return false;
			}elseif($aLastAreaList){
				$lastAreaIds = '';
				foreach($aLastAreaList as $aLastArea){
					$lastAreaIds .= $aLastArea['id'] . ',';
				}
				$areaIds = substr($lastAreaIds, 0, -1);
			}
		}
		$oSchool = new Model(T_SCHOOL);
		$aSchoolList = $oSchool->get('`id`', '`area_id` in (' . $areaIds . ')');
		if($aSchoolList === false){
			return false;
		}elseif(!$aSchoolList){
			return '';
		}else{
			$schoolIds = '';
			foreach($aSchoolList as $aSchool){
				$schoolIds .= $aSchool['id'] . ',';
			}
			$schoolIds = substr($schoolIds, 0, -1);
			return $schoolIds;
		}
	}

	/**
	*根据学校id删除学校
	*
	*/
	public function deleteSchoolBySchoolId($schoolId){
		$oSchool = new Model(T_SCHOOL);
		$row = $oSchool->delete(array('id' => $schoolId));
		return $row;
	}
//====================================pipeline标识 版本号:1752======================================
	public function getSimilarSchoolList($schoolName, $aSchoolList, $setPercent){
		$aSimilarSchoolList = array();
		foreach($aSchoolList as $aSchool){
			similar_text($aSchool['name'], $schoolName, $percent);
			if($percent >= $setPercent){
				$aSimilarSchoolList[] = $aSchool;
			}
		}
		return $aSimilarSchoolList;
	}

	//=======================================================邱安晓=========================================================================================
	/**
	 *根据学校id获得列表
	 * @param type $schoolId
	 * @param type $year
	 * @return boolean|int
	 */
	public function getSchoolClassListBySchoolId($schoolId, $year = 0, $offect = 0, $length = 20){
		$where =  '`school_id`=' . $schoolId;
		if($year){
			$where .= ' AND `year`=' . $year;
		}
		$oClass = new Model(T_USER_CLASS);
		$aGradeAndClassList = $oClass->get('`school_id`,`year`,`grade`,`class`', $where, '`grade` ASC', $offect, $length, '`year`,`grade`,`class`');
		foreach($aGradeAndClassList as &$aGradeAndClass){
			$where = '`school_id`=' . $aGradeAndClass['school_id'] . ' AND `year`=' . $aGradeAndClass['year'] . ' AND `grade`=' . $aGradeAndClass['grade'] . " AND `class`='" . $aGradeAndClass['class'] . "' AND `user_id`!=0";
			$aCountInfo = $oClass->get('count(*) as `nums`', $where);
			if(!$aCountInfo){
				return false;
			}else{
				$aGradeAndClass['nums'] = $aCountInfo[0]['nums'];
			}
		}
		return $aGradeAndClassList;
	}


	public function getClassNumsBySchoolIdAndGradeAndClass($schoolId, $grade, $class, $year){
		if(!$year){
			$year = date('Y');
		}
		$oClass = new Model(T_USER_CLASS);
		$where =  '`school_id`=' . $schoolId . ' AND `user_id`!=0' . ' AND `grade`=' . $grade . " AND `class`='" . $class . "' AND `year`=" . $year;
		$aCountInfo = $oClass->get('count(*) as `nums`', $where);
		if($aCountInfo){
			return $aCountInfo[0]['nums'];
		}else{
			return $aCountInfo;
		}
	}

	public function getClassInfoByClassId($classId){
		$oClass = new Model(T_USER_CLASS);
		$aClassInfo = $oClass->get('', array('id' => $classId));
		if($aClassInfo){
			return $aClassInfo[0];
		}
		return $aClassInfo;
	}

	public function deleteClassBySchoolIdAndGradeAndClass($schoolId, $grade, $class, $year = 0){
		if(!$year){
			$year = date('Y');
		}
		$oClass = new Model(T_USER_CLASS);
		$where = '`school_id`=' . $schoolId . ' AND `grade`=' . '"' . $grade . '"' . ' AND `class`=' . '"' .$class . '"' . ' AND `year`=' . $year;
		$row = $oClass->delete($where);
		return $row;
	}

	public function setClassBySchoolIdAndGradeAndClass($newClass, $schoolId, $grade, $oldClass, $year = 0){
		if(!$year){
			$year = date('Y');
		}
		$oClass = new Model(T_USER_CLASS);
		$aData = array(
			'class' => $newClass,
		);
		$where = '`school_id`=' . $schoolId . ' AND `grade`=' . '"' . $grade . '"' . ' AND `class`=' . '"' . $oldClass . '"' . ' AND `year`=' . $year;
		$row = $oClass->update($aData, $where);
		return $row;
	}
	//=======================================================邱安晓=========================================================================================
	public function getClassListByUserId($userId){
		$oClass = new Model(T_USER_CLASS);
		$aClassList = $oClass->get('', '`user_id`=' . $userId);
		if($aClassList){
			foreach($aClassList as $aClass){
				$aSchoolIds[] = $aClass['school_id'];
			}
			$aSchoolIds = array_unique($aSchoolIds);
			$oSchool = new Model(T_SCHOOL);
			$aSchoolList = $oSchool->get('', array('id' => array('in', $aSchoolIds)));
			$aReturnData = array();
			foreach($aClassList as $aClass){
				$aClass['grade_name'] = $GLOBALS['GRADE'][$aClass['grade']];
				if(isset($aReturnData[$aClass['school_id']])){
					$aReturnData[$aClass['school_id']]['class_list'][] = $aClass;
				}else{
					$aReturnData[$aClass['school_id']]['school_id'] = $aClass['school_id'];
					$aReturnData[$aClass['school_id']]['school_name'] = '未知学校';
					foreach($aSchoolList as $aSchool){
						if($aClass['school_id'] == $aSchool['id']){
							$aReturnData[$aClass['school_id']]['school_name'] = $aSchool['name'];
							$aReturnData[$aClass['school_id']]['area_id'] = $aSchool['area_id'];
						}
					}
					$aReturnData[$aClass['school_id']]['class_list'][] = $aClass;
				}
			}
		}
		return $aReturnData;
	}

	public function setActiveClass($userId, $classId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result = $oDboi->table(T_USER_CLASS)->where('`user_id`=' . $userId . ' and `is_active`=1')->data(array('is_active' => 2))->update();
		if($result){
			$row = $oDboi->table(T_USER_CLASS)->where(array('id' => $classId))->data(array('is_active' => 1))->update();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}
			return $row;
		}
		return $result;
	}

	public function getClassListByUserIdAndYear($userId, $year){
		$oClass = new Model(T_USER_CLASS);
		return $oClass->get('', '`user_id`=' . $userId . ' AND `year`=' . $year);
	}

	public function getUserStatistics($startTime = 0, $endTime = 0, $areaId = 0){
		$where = '';
		if($startTime){
			$where = '`t1`.`create_time`>=' . $startTime;
		}
		if($endTime){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`t1`.`create_time`<=' . $endTime;
		}
		if($areaId){
			if($where){
				$where .= ' AND ';
			}
			$oArea = new Model(T_AREA);
			$aAreaList = $oArea->get('', '`pid`=' . $areaId);
			if($aAreaList === false){
				return false;
			}elseif($aAreaList){
				$aAreaList = $oArea->get('', '`pid`=' . $aAreaList[0]['id']);
				if($aAreaList === false){
					return false;
				}elseif($aAreaList){
					$where .= '`class`.`province_id`=' . $areaId;
				}else{
					$where .= '`class`.`city_id`=' . $areaId;
				}
			}else{
				$where .= '`class`.`area_id`=' . $areaId;
			}
			$where .= ' AND `class`.`is_active`=1';
		}
		$oDboi = new DBOI();
		$currentTime = time();
		$crrentYear = date('Y', $currentTime);
		$crrentMonth = date('m', $currentTime);
		$crrentDay = date('d', $currentTime);
		$aAgeList = array();
		//小于八岁的
		$timeStamp = strtotime(($crrentYear - 8) . '-' . $crrentMonth . '-' . $crrentDay);
		$where1 = $where;
		if($where){
			$where1 .= ' AND ';
		}
		$where1 .= '`per`.`birth_date`>' . $timeStamp;
		if($areaId){
			$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($where1)->select();
		}else{
			$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->where($where1)->select();
		}
		$aAgeList[] = array('小于8' => $aUserCount[0]['nums']);
		for($i = 8; $i < 18; $i++){
			$where2 = 'where' . $i;
			$timeStartStamp = strtotime(($crrentYear - $i - 1) . '-' . $crrentMonth . '-' . $crrentDay);
			$timeEndStamp = strtotime(($crrentYear - $i) . '-' . $crrentMonth . '-' . $crrentDay);
			$where2 = $where;
			if($where){
				$where2 .= ' AND ';
			}
			$where2 .= '`per`.`birth_date`>=' . $timeStartStamp . ' AND `per`.`birth_date`<' . $timeEndStamp;
			if($areaId){
				$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($where2)->select();
			}else{
				$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->where($where2)->select();
			}
			$aAgeList[] = array($i => $aUserCount[0]['nums']);
		}
		$where3 = $where;
		if($where){
			$where3 .= ' AND ';
		}
		$where3 .= '`per`.`birth_date`<=' . $timeStartStamp;
		if($areaId){
			$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($where3)->select();
		}else{
			$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->where($where3)->select();
		}
		$aAgeList[] = array('大于17' => $aUserCount[0]['nums']);
		//男女比例
		$whereBoy = $where;
		$wheregirl = $where;
		if($where){
			$whereBoy .= ' AND ';
			$wheregirl .= ' AND ';
		}
		$whereBoy .= '`per`.`gender`=1';
		$wheregirl .= '`per`.`gender`=2';
		if($areaId){
			$aBoyCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($whereBoy)->select();
			$aGirlCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($wheregirl)->select();
		}else{
			$aBoyCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->where($whereBoy)->select();
			$aGirlCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_PERSONAL, 'as `per` on `per`.`id`=`t1`.`id`')->where($wheregirl)->select();
		}
		$boyCount = $aBoyCount[0]['nums'];
		$girlCount = $aGirlCount[0]['nums'];
		$aGenderList = array('男' => $boyCount, '女' => $girlCount);
		//年级比列
		for($i = 5; $i < 10; $i++){
			$where4 = $where;
			if($where){
				$where4 .= ' AND ';
			}
			$where4 .= '`class`.`grade`=' . $i;
			$aGradeUserCount = $oDboi->fields('count(*) as `nums`')->table(T_USER)->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($where4)->select();
			$aGradeList[] = array($i => $aGradeUserCount[0]['nums']);
		}
		if($areaId){
			$allUserCount = $oDboi->fields('count(*) as nums')->table(T_USER)->leftjoin(T_USER_CLASS, 'as `class` on `class`.`user_id`=`t1`.`id`')->where($where)->select();
		}else{
			$where = str_replace('`t1`.', '', $where);
			$allUserCount = $oDboi->fields('count(*) as nums')->table(T_USER)->where($where)->select();
		}
		return array(
			'all_count' => $allUserCount[0]['nums'],
			'age_list' => $aAgeList,
			'gender_list' => $aGenderList,
			'grade_list' => $aGradeList,
		);
	}

	/*public function getUserSignatureByUserId($userId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$where = '`user_id`=' . $userId;
		$aShuoshuoInfo = $oShuoshuo->get('', $where, '`create_time` desc', 0, 1);
		if($aShuoshuoInfo){
			return $aShuoshuoInfo[0]['content'];
		}elseif($aShuoshuoInfo === false){
			return false;
		}else{
			return '';
		}
	}*/

	/**
	 * @author	李超宇
	 * @date	2013/12/3
	 * 用户世界动态专用，显示两名最新注册人员
	 */
	public function getNewsRegisterUser(){
		$oDboi = new DBOI();
		return $oDboi->fields('t1.id as user_id, name, profile, create_time')->table(T_USER)->leftjoin(T_PERSONAL, 'as `p` on `t1`.`id`=`p`.`id`')->where("name<>''")->orderby('`t1`.`create_time` desc')->limit(0, 2)->select();
	}

	///--------------------------------分割线20131227--------------------------------------------------
	public function getUserDetailPersonalInfoByUserId($userId, $aCondition = array()){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('`xxt_type`,`xxt_id`', array('id' => $userId));
		if(!$aUserInfo){
			return $aUserInfo;
		}
		$oPersonal = new Model(T_PERSONAL);
		/*if(!$aCondition){
			$aPersonalInfo = $oPersonal->get('`id`,`name`,`profile`', array('id' => $userId));
			if($aPersonalInfo){
				$aPersonalInfo = $aPersonalInfo[0];
			}
			return $aPersonalInfo;
		}*/
		$personalWhere = '`id`,`name`,`profile`';
		if(in_array('personal', $aCondition)){
			$personalWhere .= ',`call_phone`,`gender`,`birth_date`,`signature`,`qq`,`new_feed_flag`,`new_friend_flag`,`xxt_data`,`class_teacher_relation`';
		}
		$aPersonalInfo = $oPersonal->get($personalWhere, array('id' => $userId));
		if($aPersonalInfo){
			$aPersonalInfo = $aPersonalInfo[0];
			$aPersonalInfo['xxt_id'] = $aUserInfo[0]['xxt_id'];
			$aPersonalInfo['xxt_type'] = $aUserInfo[0]['xxt_type'];
			if(isset($aPersonalInfo['xxt_data'])){
				if($aPersonalInfo['xxt_data']){
					$aPersonalInfo['xxt_data'] = json_decode($aPersonalInfo['xxt_data'], true);
				}else{
					$aPersonalInfo['xxt_data'] = array();
				}
			}
			if(isset($aPersonalInfo['class_teacher_relation'])){
				if($aPersonalInfo['class_teacher_relation']){
					$aPersonalInfo['class_teacher_relation'] = json_decode($aPersonalInfo['class_teacher_relation'], true);
				}else{
					$aPersonalInfo['xxt_data'] = array();
				}
			}
			if(in_array('invite_code', $aCondition)){
				$oUserInvite = new Model(T_USER_INVITATION);
				$aUserInviteInfo = $oUserInvite->get('`invite_code`', array('id' => $userId));
				if($aUserInviteInfo === false){
					return false;
				}elseif($aUserInviteInfo){
					$aPersonalInfo['invite_code'] = $aUserInviteInfo[0]['invite_code'];
				}else{
					$aPersonalInfo['invite_code'] = 0;
				}
			}
			if(in_array('area', $aCondition) || in_array('class', $aCondition)){
				$oClass = new Model(T_USER_CLASS);
				$aClassInfo = $oClass->get('`year`,`province_id`,`city_id`,`area_id`,`school_id`,`grade`,`class`', '`user_id`=' . $userId . ' AND `is_active`=1');
				if($aClassInfo === false){
					return false;
				}
				if(in_array('area', $aCondition)){
					if($aClassInfo){
						$aPersonalInfo['city_id'] = $aClassInfo[0]['city_id'];
						$aAreaIds = array($aClassInfo[0]['province_id'], $aClassInfo[0]['city_id'], $aClassInfo[0]['area_id']);
						$oArea = new Model(T_AREA);
						$aAreaList = $oArea->get('`id`,`name`', array('id' => array('in', $aAreaIds)));
						if($aAreaList === false){
							return false;
						}
						foreach($aAreaList as $aArea){
							if($aArea['id'] == $aClassInfo[0]['province_id']){
								$aPersonalInfo['province_name'] = $aArea['name'];
							}elseif($aArea['id'] == $aClassInfo[0]['city_id']){
								$aPersonalInfo['city_name'] = $aArea['name'];
							}else{
								$aPersonalInfo['area_name'] = $aArea['name'];
							}
						}
					}else{
						$aPersonalInfo['city_id'] = 0;
						$aPersonalInfo['province_name'] = '';
						$aPersonalInfo['city_name'] = '';
						$aPersonalInfo['area_name'] = '';
					}
				}
				if(in_array('class', $aCondition)){
					if($aClassInfo){
						$oSchool = new Model(T_SCHOOL);
						$aSchoolInfo = $oSchool->get('`name`', array('id' => $aClassInfo[0]['school_id']));
						if($aSchoolInfo === false){
							return false;
						}
						$aPersonalInfo['year'] = $aClassInfo[0]['year'];
						$aPersonalInfo['school_id'] = $aClassInfo[0]['school_id'];
						$aPersonalInfo['school_name'] = $aSchoolInfo[0]['name'];
						$aPersonalInfo['grade'] = $aClassInfo[0]['grade'];
						$aPersonalInfo['class'] = $aClassInfo[0]['class'];
					}else{
						$aPersonalInfo['year'] = 0;
						$aPersonalInfo['school_id'] = 0;
						$aPersonalInfo['school_name'] = '';
						$aPersonalInfo['grade'] = 0;
						$aPersonalInfo['class'] = '';
					}
				}
			}
			$oNumerical = new Model(T_USER_NUMERICAL);
			$aNumericalInfo = $oNumerical->get('`level`,`accumulate_points`,`vip`,`vip_expiration_time`', array('id' => $userId));
			$aPersonalInfo['vip'] = $aNumericalInfo[0]['vip'];
			if($aNumericalInfo[0]['vip'] && $aNumericalInfo[0]['vip_expiration_time'] < time()){
				$aPersonalInfo['vip'] = 0;
			}
			if(in_array('numerical', $aCondition)){
				$aPersonalInfo['level'] = $aNumericalInfo[0]['level'];
				$aPersonalInfo['accumulate_points'] = $aNumericalInfo[0]['accumulate_points'];
			}
		}
		if($aPersonalInfo['profile'] && $aPersonalInfo['profile'][0] == '@'){
			$defaultProfileId = substr($aPersonalInfo['profile'], 1);
			$aPersonalInfo['profile'] = Yii::getAlias(Yii::$app->ui->getDefaultProfile($defaultProfileId));
		}
		return $aPersonalInfo;
	}

	public function getUserDetailPersonalListByUserIds($aUserIds, $aCondition = array()){
		$oPersonal = new Model(T_PERSONAL);
		/*if(!$aCondition){
			$aPersonalList = $oPersonal->get('`id`,`name`,`profile`', array('id' => array('in', $aUserIds)));
			return $aPersonalList;
		}*/
		$personalWhere = '`id`,`name`,`profile`';
		if(in_array('personal', $aCondition)){
			$personalWhere .= ',`gender`,`birth_date`,`signature`,`qq`,`xxt_data`';
		}
		$aPersonalList = $oPersonal->get($personalWhere, array('id' => array('in', $aUserIds)));
		if($aPersonalList){
			if(in_array('personal', $aCondition)){
				foreach($aPersonalList as $key => $aPersonal){
					if($aPersonal['xxt_data']){
						$aPersonalList[$key]['xxt_data'] = json_decode($aPersonal['xxt_data'], true);
					}else{
						$aPersonalList[$key]['xxt_data'] = array();
					}
				}
			}
			if(in_array('area', $aCondition) || in_array('class', $aCondition)){
				$oClass = new Model(T_USER_CLASS);
				$aClassList = $oClass->get('`user_id`,`year`,`province_id`,`city_id`,`area_id`,`school_id`,`grade`,`class`', '`user_id` in (' . implode(',', $aUserIds) . ') AND `is_active`=1');
				if($aClassList === false){
					return false;
				}elseif(!$aClassList){
					foreach($aPersonalList as $key => $aPersonal){
						if(in_array('area', $aCondition)){
							$aPersonalList[$key]['province_name'] = '';
							$aPersonalList[$key]['city_name'] = '';
							$aPersonalList[$key]['area_name'] = '';
						}
						if(in_array('class', $aCondition)){
							$aPersonalList[$key]['year'] = 0;
							$aPersonalList[$key]['school_name'] = '';
							$aPersonalList[$key]['grade'] = 0;
							$aPersonalList[$key]['class'] = '';
						}
					}
				}else{
					$aAreaIds = array();
					$aSchoolIds = array();
					foreach($aClassList as $aClass){
						$aAreaIds[] = $aClass['province_id'];
						$aAreaIds[] = $aClass['city_id'];
						$aAreaIds[] = $aClass['area_id'];
						$aSchoolIds[] = $aClass['school_id'];
					}
					$aAreaList = $aSchoolList = array();
					if(in_array('area', $aCondition)){
						$oArea = new Model(T_AREA);
						$aAreaList = $oArea->get('`id`,`name`', array('id' => array('in', $aAreaIds)));
						if($aAreaList === false){
							return false;
						}
					}
					if(in_array('class', $aCondition)){
						$oSchool = new Model(T_SCHOOL);
						$aSchoolList = $oSchool->get('`id`,`name`', array('id' => array('in', $aSchoolIds)));
						if($aSchoolList === false){
							return false;
						}
					}
					foreach($aPersonalList as $key => $aPersonal){
						if(in_array('area', $aCondition)){
							$aPersonalList[$key]['province_name'] = '';
							$aPersonalList[$key]['city_name'] = '';
							$aPersonalList[$key]['area_name'] = '';
						}
						if(in_array('class', $aCondition)){
							$aPersonalList[$key]['year'] = 0;
							$aPersonalList[$key]['school_name'] = '';
							$aPersonalList[$key]['grade'] = 0;
							$aPersonalList[$key]['class'] = '';
						}
						foreach($aClassList as $aClass){
							if($aClass['user_id'] == $aPersonal['id']){
								if(in_array('area', $aCondition)){
									$aPersonalList[$key]['province_name'] = '';
									$aPersonalList[$key]['city_name'] = '';
									$aPersonalList[$key]['area_name'] = '';
								}
								if(in_array('class', $aCondition)){
									$aPersonalList[$key]['year'] = $aClass['year'];
									$aPersonalList[$key]['school_name'] = '';
									$aPersonalList[$key]['grade'] = $aClass['grade'];
									$aPersonalList[$key]['class'] = $aClass['class'];
								}
								foreach($aAreaList as $aArea){
									if($aArea['id'] == $aClass['province_id']){
										$aPersonalList[$key]['province_name'] = $aArea['name'];
									}elseif($aArea['id'] == $aClass['city_id']){
										$aPersonalList[$key]['city_name'] = $aArea['name'];
									}elseif($aArea['id'] == $aClass['area_id']){
										$aPersonalList[$key]['area_name'] = $aArea['name'];
									}
								}
								foreach($aSchoolList as $aSchool){
									if($aSchool['id'] == $aClass['school_id']){
										$aPersonalList[$key]['school_name'] = $aSchool['name'];
										break;
									}
								}
								break;
							}
						}
					}
				}
			}
			$oNumerical = new Model(T_USER_NUMERICAL);
			$aNumericalList = $oNumerical->get('`id`,`level`,`accumulate_points`,`vip`,`vip_expiration_time`', array('id' => array('in', $aUserIds)));
			foreach($aPersonalList as $key => $aPersonal){
				if(in_array('numerical', $aCondition)){
					$aPersonalList[$key]['level'] = 0;
					$aPersonalList[$key]['accumulate_points'] = 0;
				}
				foreach($aNumericalList as $aNumerical){
					if($aNumerical['id'] == $aPersonal['id']){
						if(in_array('numerical', $aCondition)){
							$aPersonalList[$key]['level'] = $aNumerical['level'];
							$aPersonalList[$key]['accumulate_points'] = $aNumerical['accumulate_points'];
						}
						$aPersonalList[$key]['vip'] = $aNumerical['vip'];
						if($aNumerical['vip'] && $aNumerical['vip_expiration_time'] < time()){
							$aPersonalList[$key]['vip'] = 0;
						}
						break;
					}
				}
				if($aPersonal['profile'] && $aPersonal['profile'][0] == '@'){
					$defaultProfileId = substr($aPersonal['profile'], 1);
					$aPersonalList[$key]['profile'] = Yii::getAlias(Yii::$app->ui->getDefaultProfile($defaultProfileId));
				}
			}
		}
		return $aPersonalList;
	}

	public function getLoginInfoByUserId($userId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('`id`,`xxt_type`,`xxt_id`,`password`,`email`,`mobile`,`is_forbidden`,`approve_status`,`last_login_time`', array('id' => $userId));
		if($aUserInfo){
			$aUserInfo = $aUserInfo[0];
			$oPersonal = new Model(T_PERSONAL);
			$aPersonalInfo = $oPersonal->get('`name`,`profile`,`style_id`,`new_feed_flag`', array('id' => $userId));
			if($aPersonalInfo === false){
				return false;
			}elseif(!$aPersonalInfo){
				$aUserInfo['name'] = '';
				$aUserInfo['profile'] = '';
				$aUserInfo['style_id'] = 0;
				$aUserInfo['new_feed_flag'] = 0;
			}else{
				$aUserInfo['name'] = $aPersonalInfo[0]['name'];
				$aUserInfo['profile'] = $aPersonalInfo[0]['profile'];
				$aUserInfo['style_id'] = $aPersonalInfo[0]['style_id'];
				$aUserInfo['new_feed_flag'] = $aPersonalInfo[0]['new_feed_flag'];
			}
		}
		return $aUserInfo;
	}

	/*
	 *$aCondition = array(
	 *	'gender' => 0:不限,1:男，2：女
	 *	'age'	=>	array(0,10):0-10岁,array(15):15岁以上
	 *	'area'	=>	0:不限
	 *	'school_id'	=>	0:不限
	 * )
	 */
	public function getUserListBySearch($aCondition, $page, $pageSize, $order = ''){
		$where = $this->_parseWhereForSearch($aCondition);
		if($where === false){
			return false;
		}
		$offect = ($page - 1) * $pageSize;
		if(((isset($aCondition['gender']) && $aCondition['gender']) || (isset($aCondition['age']) && $aCondition['age'])) && ((isset($aCondition['area']) && $aCondition['area']) || (isset($aCondition['school_id']) && $aCondition['school_id']))){
			//联表查询
			$oDboi = new DBOI();
			$aUserList = $oDboi->fields('`t1`.`id` as `id`')->table(T_PERSONAL)->leftjoin(T_USER_CLASS, 'as `cls` on `t1`.`id`=`cls`.`user_id`')->where($where)->limit($offect, $pageSize)->orderby($order)->select();
		}elseif(!$where || (isset($aCondition['gender']) && $aCondition['gender']) || (isset($aCondition['age']) && $aCondition['age'])){
			//只查personal表
			if(!$where){
				$where = "`name`!=''";
			}
			$oPersonal = new Model(T_PERSONAL);
			$aUserList = $oPersonal->get('`id`', $where, $order, $offect, $pageSize);
		}else{
			//只查class表
			$oClass = new Model(T_USER_CLASS);
			$aUserList = $oClass->get('`user_id` as `id`', $where, $order, $offect, $pageSize);
		}
		if(!$aUserList){
			return $aUserList;
		}
		$aUserIds = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['id'];
		}
		return getUserListByUserIds($aUserIds, array('personal', 'area'));
	}

	public function getUserCountBySearch($aCondition){
		$where = $this->_parseWhereForSearch($aCondition);
		if($where === false){
			return false;
		}
		if(((isset($aCondition['gender']) && $aCondition['gender']) || (isset($aCondition['age']) && $aCondition['age'])) && ((isset($aCondition['area']) && $aCondition['area']) || (isset($aCondition['school_id']) && $aCondition['school_id']))){
			//联表查询
			$oDboi = new DBOI();
			$aUserCount = $oDboi->fields('count(*) as `nums`')->table(T_PERSONAL)->leftjoin(T_USER_CLASS, 'as `cls` on `t1`.`id`=`cls`.`user_id`')->where($where)->select();
			if($aUserCount){
				return $aUserCount[0]['nums'];
			}else{
				return $aUserCount;
			}
		}elseif((isset($aCondition['gender']) && $aCondition['gender']) || (isset($aCondition['age']) && $aCondition['age'])){
			//只查personal表
			if(!$where){
				$where = "`name`!=''";
			}
			$oPersonal = new Model(T_PERSONAL);
			return $oPersonal->count($where);
		}else{
			//只查class表
			$oClass = new Model(T_USER_CLASS);
			return $oClass->count($where);
		}
	}

	public function getUserInfoBySearchAccount($account, $isEmail = 0){
		if($isEmail){
			$oUser = new Model(T_USER);
			$aUserInfo = $oUser->get('`id`', "`email`='" . $account . "'");
			if(!$aUserInfo){
				return $aUserInfo;
			}
			$userId = $aUserInfo[0]['id'];
		}else{
			$userId = $account;
		}
		return getUserInfo($userId, array('personal', 'area'));
	}

	public function getUserListBySearchName($name, $page, $pageSize){
		$oPersonal = new Model(T_PERSONAL);
		$offect = ($page - 1) * $pageSize;
		$aUserList = $oPersonal->get('`id`', "`name`='" . $name . "'", '', $offect, $pageSize);
		if(!$aUserList){
			return $aUserList;
		}
		$aUserIds = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['id'];
		}
		return getUserListByUserIds($aUserIds, array('personal', 'area'));
	}

	public function getUserCountBySearchName($name){
		$oPersonal = new Model(T_PERSONAL);
		return $oPersonal->count("`name`='" . $name . "'");
	}

	private function _parseWhereForSearch($aCondition){
		$where = '';
		$isJoin = 0;
		if(((isset($aCondition['gender']) && $aCondition['gender']) || (isset($aCondition['age']) && $aCondition['age'])) && ((isset($aCondition['area']) && $aCondition['area']) || (isset($aCondition['school_id']) && $aCondition['school_id']))){
			$isJoin = 1;
		}
		if(isset($aCondition['gender']) && $aCondition['gender']){
			if($isJoin){
				$where = '`t1`.`gender`=' . $aCondition['gender'];
			}else{
				$where = '`gender`=' . $aCondition['gender'];
			}
		}
		if(isset($aCondition['age']) && $aCondition['age']){
			if($where){
				$where .= ' AND ';
			}
			if(count($aCondition['age']) == 1){
				$lastTime = mktime(0, 0, 0, date('m'), date('d'), date('Y') - $aCondition['age'][0]);	//最近的时间点
				if($isJoin){
					$where .= '`t1`.`birth_date`<=' . $lastTime;
				}else{
					$where .= '`birth_date`<=' . $lastTime;
				}
			}else{
				$lastTime = mktime(date('H'), date('i'), date('s'), date('m'), date('d'), date('Y') - $aCondition['age'][0]);
				$startTime = mktime(0, 0, 0, date('m'), date('d'), date('Y') - $aCondition['age'][1]);
				if($isJoin){
					$where .= '`t1`.`birth_date`<=' . $lastTime . ' AND `t1`.`birth_date`>=' . $startTime;
				}else{
					$where .= '`birth_date`<=' . $lastTime . ' AND `birth_date`>=' . $startTime;
				}
			}
		}
		if(isset($aCondition['area']) && $aCondition['area']){
			$oArea = new Model(T_AREA);
			$aAreaInfo = $oArea->get('', array('id' => $aCondition['area']));
			if(!$aAreaInfo){
				return $aAreaInfo;
			}
			if($where){
				$where .= ' AND ';
			}
			if($aAreaInfo[0]['pid']){
				$aAreaInfo2 = $oArea->get('', array('id' => $aAreaInfo[0]['pid']));
				if(!$aAreaInfo2){
					return $aAreaInfo2;
				}
				if($aAreaInfo2[0]['pid']){
					//区id
					if($isJoin){
						$where .= '`cls`.`area_id`=' . $aCondition['area'];
					}else{
						$where .= '`area_id`=' . $aCondition['area'];
					}
				}else{
					//市id
					if($isJoin){
						$where .= '`cls`.`city_id`=' . $aCondition['area'];
					}else{
						$where .= '`city_id`=' . $aCondition['area'];
					}
				}
			}else{
				//省份id
				if($isJoin){
					$where .= '`cls`.`province_id`=' . $aCondition['area'];
				}else{
					$where .= '`province_id`=' . $aCondition['area'];
				}
			}
		}
		if(isset($aCondition['school_id']) && $aCondition['school_id']){
			if($where){
				$where .= ' AND ';
			}
			if($isJoin){
				$where .= '`cls`.`school_id`=' . $aCondition['school_id'];
			}else{
				$where .= '`school_id`=' . $aCondition['school_id'];
			}
		}
		if((isset($aCondition['area']) && $aCondition['area']) || (isset($aCondition['school_id']) && $aCondition['school_id'])){
			$where .= ' AND ';
			if($isJoin){
				$where .= '`cls`.`is_active`=1';
			}else{
				$where .= '`is_active`=1';
			}
		}
		return $where;
	}

	//当前月中奖的人数----林云龙
	public function countUserPrize(){
		$oUser = new Model(T_USER);
		$currentMonth = strtotime(date('Y-m',time()));
		$aUserList = $oUser->get('`id`,lottery_draw_status','lottery_draw_time>=' . $currentMonth . ' AND lottery_draw_time<=' . time() . ' AND lottery_draw_status>1');

		if($aUserList === false){
			return $aUserList;
		}

		$aCountUserPrize[2] = 0;
		$aCountUserPrize[3] = 0;
		$aCountUserPrize[4] = 0;
		$aCountUserPrize[5] = 0;
		$aCountUserPrize[6] = 0;

		if(!$aUserList){
			return $aCountUserPrize;
		}

		foreach($aUserList as $aUser){
			if($aUser['lottery_draw_status'] == 2){
				$aCountUserPrize[2] += 1;
			}elseif($aUser['lottery_draw_status'] == 3){
				$aCountUserPrize[3] += 1;
			}elseif($aUser['lottery_draw_status'] == 4){
				$aCountUserPrize[4] += 1;
			}elseif($aUser['lottery_draw_status'] == 5){
				$aCountUserPrize[5] += 1;
			}elseif($aUser['lottery_draw_status'] == 6){
				$aCountUserPrize[6] += 1;
			}
		}
		return $aCountUserPrize;
	}

	//根据错题id删除错题记录---林云龙
	public function deleteUserEsWrongByEsId($esId = 0){
		if(!$esId){
			return $esId;
		}
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		return $oUserEsWrong->delete(array('id'=>$esId));
	}

	//根据收藏id删除收藏记录---林云龙
	public function deleteUserEsFavoriteByEsId($favoriteId = 0){
		if(!$favoriteId){
			return $favoriteId;
		}
		$oUserEsfavorite = new Model(T_USER_ES_FAVORITE);
		return $oUserEsfavorite->delete(array('id'=>$favoriteId));
	}

	//添加用户待审核的信息
	public function addUserInfoApprove($aData){
		$oUserInfoApprove = new Model(T_USER_INFO_APPROVE);
		if(isset($aData['content'])){
			$aData['content'] = json_encode($aData['content']);
		}else{
			$aData['content'] = json_encode(array());
		}
		return $oUserInfoApprove->add($aData);
	}

	//删除用户待审核的信息
	public function deleteUserInfoApprove($userId){
		$oUserInfoApprove = new Model(T_USER_INFO_APPROVE);
		return $oUserInfoApprove->delete(array('id' => $userId));
	}

	//查找用户待审核的信息
	public function getUserApproveInfo($userId){
		$oUserInfoApprove = new Model(T_USER_INFO_APPROVE);
		$aUserApproveInfo = $oUserInfoApprove->get('', array('id' => $userId));
		if($aUserApproveInfo){
			$aUserApproveInfo = $aUserApproveInfo[0];
			$aUserApproveInfo['content'] = json_decode($aUserApproveInfo['content'], true);
		}
		return $aUserApproveInfo;
	}

	//修改用户待审核的信息
	public function setUserInfoApprove($aData){
		$oUserInfoApprove = new Model(T_USER_INFO_APPROVE);
		if(isset($aData['content'])){
			$aData['content'] = json_encode($aData['content']);
		}
		return $oUserInfoApprove->update($aData, array('id' => $aData['id']));
	}

	//查找用户待审核的信息列表
	public function getUserInfoApproveList($approveFinish, $page, $pageSize){
		$oUserInfoApprove = new Model(T_USER_INFO_APPROVE);
		if($approveFinish == -1){
			$where = '';
		}else{
			$where = '`approve_finish`=' . $approveFinish;
		}
		$offect = ($page - 1) * $pageSize;
		$aUserApproveList = $oUserInfoApprove->get('', $where, '`create_time` ASC', $offect, $pageSize);
		if($aUserApproveList){
			foreach($aUserApproveList as &$aUserApprove){
				$aUserApprove['content'] = json_decode($aUserApprove['content'], true);
			}
		}
		return $aUserApproveList;
	}

	public function getUserInfoApproveCount($approveFinish){
		$oUserInfoApprove = new Model(T_USER_INFO_APPROVE);
		if($approveFinish == -1){
			$where = '';
		}else{
			$where = '`approve_finish`=' . $approveFinish;
		}
		return $oUserInfoApprove->count($where);
	}

	//查出用户从注册到现在的月份列表
	public function getUserMonthList($userId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('`create_time`', array('id' => $userId));
		if(!$aUserInfo){
			return $aUserInfo;
		}
		//注册年月
		$registerYear = date('Y', $aUserInfo[0]['create_time']);
		$registerMonth = date('m', $aUserInfo[0]['create_time']);
		//当前年月
		$currentYear = date('Y');
		$currentMonth = date('m');
		$aMothList = array();
		for($i = $registerYear; $i <= $currentYear; $i++){
			if($i < $currentYear){
				if($i == $registerYear){
					for($j = $registerMonth; $j <= 12; $j++){
						$aMonth = array(
							'year'	=>	$i,
							'month'	=>	$j,
						);
						$aMothList[] = $aMonth;
					}
				}else{
					for($j = 1; $j <= 12; $j++){
						$aMonth = array(
							'year'	=>	$i,
							'month'	=>	$j,
						);
						$aMothList[] = $aMonth;
					}
				}
			}else{
				for($j = 1; $j <= $currentMonth; $j++){
					$aMonth = array(
							'year'	=>	$i,
							'month'	=>	$j,
						);
						$aMothList[] = $aMonth;
				}
			}
		}
		return $aMothList;
	}

	//增加用户登录记录
	public function addUserLoginLog($aData){
		$oLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		return $oLoginLog->add($aData);
	}

	//查看用户登录记录
	public function getUserLoginLogList($aUserIds = array(), $page = 1, $pageSize = 10){
		$oLoginLog = new Model(T_ALL_USER_LOGIN_LOG);
		$where = '';
		if($aUserIds){
			if(count($aUserIds) == 1){
				$where = '`user_id`=' . $aUserIds[0];
			}else{
				$where = '`user_id` in (' . implode(',', $aUserIds) . ')';
			}
		}
		$offect = ($page - 1) * $pageSize;
		return $oLoginLog->get('', $where, '`create_time` DESC', $offect, $pageSize);
	}


	//----用户注册---林云龙
	public function userRegister($aData, $inviteCode = 0){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aData['password'] = $aData['password'] ? $this->xCrypt($aData['password']) : '';
		$result = $oDboi->table(T_USER)->data($aData)->insert();
		if(!$result){
			return $result;
		}
		$aData2['id'] = $aData['id'];
		$result2 = $oDboi->table(T_PERSONAL)->data($aData2)->insert();
		if(!$result2){
			$oDboi->rollBack();
			return false;
		}
		$aData3['id'] = $aData['id'];
		$aData3['invite_code'] = $inviteCode;
		$result3 = $oDboi->table(T_USER_INVITATION)->data($aData3)->insert();
		if(!$result3){
			$oDboi->rollBack();
			return false;
		}

		$aData4['id'] = $aData['id'];
		$result4 = $oDboi->table(T_USER_NUMERICAL)->data($aData4)->insert();
		if(!$result4){
			$oDboi->rollBack();
			return false;
		}
		return 1;
	}

	public function getUserInfoByQqOpenId($qqOpenId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', "`qq_open_id`='" . $qqOpenId . "'" );
		if($aUserInfo){
			$aUserInfo = $aUserInfo[0];
		}
		return $aUserInfo;
	}

	public function getUserInfoByXxtId($xxtId){
		$oUser = new Model(T_USER);
		$aUserInfo = $oUser->get('', '`xxt_type`=2 AND `xxt_id`=' . $xxtId );
		if($aUserInfo){
			$aUserInfo = $aUserInfo[0];
		}
		return $aUserInfo;
	}

	public function getXxtUserList($page, $pageSize, $order = '`create_time` desc'){
		$offect = ($page - 1) * $pageSize;
		$oUser = new Model(T_USER);
		$aUserList = $oUser->get('`id`,`xxt_id`', '`xxt_id`>0', $order, $offect, $pageSize);
		if(!$aUserList){
			return $aUserList;
		}
		$aUserIds = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['id'];
		}
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalList = $oPersonal->get('`id`,`name`,`xxt_data`', array('id' => array('in', $aUserIds)));
		if($aPersonalList === false){
			return false;
		}
		foreach($aUserList as &$aUser){
			foreach($aPersonalList as $aPersonal){
				if($aPersonal['id'] == $aUser['id']){
					$aUser['name'] = $aPersonal['name'];
					$aUser['xxt_data'] = $aPersonal['xxt_data'];
					break;
				}
			}
			if(isset($aUser['xxt_data'])){
				if($aUser['xxt_data']){
					$aUser['xxt_data'] = json_decode($aUser['xxt_data'], true);
				}else{
					$aUser['xxt_data'] = array();
				}
			}
		}
		return $aUserList;
	}

	public function getXxtUserCount(){
		$oUser = new Model(T_USER);
		return $oUser->count('`xxt_id`>0');
	}

	/*
	 * 获取班级校讯通用户数量
	 */
	public function getClassXxtUserIds($schoolId, $class){
		$oClass = new Model(T_USER_CLASS);
		$aClassUserList = $oClass->get('`user_id`', '`school_id`=' . $schoolId . " AND `class`='" . $class . "'" . ' AND `is_active`=1 AND `year`=' . date('Y'));
		if(!$aClassUserList){
			return $aClassUserList;
		}
		$aUserIds = array();
		foreach($aClassUserList as $aClassUser){
			$aUserIds[] = $aClassUser['user_id'];
		}
		$oUser = new Model(T_USER);
		$aUserList = $oUser->get('`id`', '`xxt_id`>0 AND `id` in (' . implode(',', $aUserIds) . ')');
		if(!$aUserList){
			return $aUserList;
		}
		$aUserIds = array();
		foreach($aUserList as $aUser){
			$aUserIds[] = $aUser['id'];
		}
		return $aUserIds;
	}

	/*
	 * 得到用户班级列表
	 * $aCondition = array(
	 *		'year'
	 *		'city_id'
	 *		'school_id'
	 *		'grade'
	 *		'class'
	 *		'is_active'
	 * );
	 */
	public function getClassListByCondition($aCondition = array('is_active' => 1)){
		$where = $this->_parseWhereForClassList($aCondition);
		$oClass = new Model(T_USER_CLASS);
		return $oClass->get('`user_id`', $where);
	}

	private function _parseWhereForClassList($aCondition){
		$where = '';
		if(isset($aCondition['year']) && $aCondition['year']){
			$where = '`year`=' . $aCondition['year'];
		}
		if(isset($aCondition['city_id']) && $aCondition['city_id']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`city_id`=' . $aCondition['city_id'];
		}
		if(isset($aCondition['school_id']) && $aCondition['school_id']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`school_id`=' . $aCondition['school_id'];
		}
		if(isset($aCondition['grade']) && $aCondition['grade']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`grade`=' . $aCondition['grade'];
		}

		if(isset($aCondition['class']) && $aCondition['class']){
			if($where){
				$where .= ' AND ';
			}
			$where .= "`class`='" . $aCondition['class'] . "'";
		}
		if(isset($aCondition['is_active']) && $aCondition['is_active'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_active`=' . $aCondition['is_active'];
		}
		return $where;
	}

	public function getHaveProfileUserIdList($page, $pageSize, $aNotInUserIds = array()){
		$where = "`t2`.`profile`!='' AND `t2`.`profile`!='data/user/default/default.png' AND `t2`.`name`!=''";
		if($aNotInUserIds){
			$where .= ' AND `t1`.`id` not in (' . implode(',', $aNotInUserIds) . ')';
		}
		$offect = ($page - 1) * $pageSize;
		$oDboi = new DBOI();
		$aUserIdList = $oDboi->fields('`t1`.`id`')->table(T_USER)->leftjoin(T_PERSONAL, ' as `t2` on `t2`.`id`=`t1`.`id`')->where($where)->orderby('`t1`.`last_login_time` DESC')->limit($offect, $pageSize)->select();
		if(!$aUserIdList){
			return $aUserIdList;
		}
		$aUserIds = array();
		foreach($aUserIdList as $aUserId){
			$aUserIds[] = $aUserId['id'];
		}
		return $aUserIds;
	}
}