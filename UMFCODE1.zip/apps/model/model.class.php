<?php
/**
 * 通用模型
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-6-7
 */
class Model{
	protected $_table = '';	//操作的表
	protected $_oDBOI = null;	//DBOI对象

	public function __construct($table = ''){
		$this->_oDBOI = new DBOI();
		$this->_table = $table;
	}

	/**
	 * 获取当前操作的表
	 */
	protected function getTable(){
		return $this->_table;
	}

	/**
	 * 设置要操作的表
	 * @param string $table
	 */
	protected function setTable($table){
		$this->_table = $table;
		return $this;
	}

	/**
	 * 查询
	 * @param string $fields 查询的字段
	 * @param type $where 查询条件，数组或字符串
	 * @param int $offect 开始位置
	 * @param int $length 查询个数
	 * @param string $orderby  排列
	 * @param string $groupby 分组
	 * @return array
	 */
	public function get($fields = '*', $where = '', $orderby = '', $offect = '', $length = '', $groupby = ''){
		if(is_numeric($offect) && $offect >= 0 && is_numeric($length) && $length > 0){
			$this->_oDBOI->limit($offect . ',' . $length);
		}
		$aList = $this->_oDBOI->fields($fields)->table($this->_table)->where($where)->groupby($groupby)->orderby($orderby)->select();
		return $aList;
	}
	

	/**
	 * 删除
	 * @param type $where 条数组或字符串
	 */
	public function delete($where){
		if($where == ''){
			return false;
		}
		return $this->_oDBOI->table($this->_table)->where($where)->delete();
	}

	/**
	 * 修改
	 * @param type $data	修改的键名和值的数组
	 * @param type $where	条件
	 * @return int 影响的行数
	 */
	public function update($data, $where){
		if($data == '' || !is_array($data) || $where == ''){
			return false;
		}
		return $this->_oDBOI->table($this->_table)->where($where)->data($data)->update();
	}

	/**
	 * 新增
	 * @param type $data 新增的内容数组
	 * @return int 成功就返回用户ID失败就返回0
	 */
	public function add($data){
		if(empty($data) || !is_array($data)){
			return false;
		}
		return $this->_oDBOI->table($this->_table)->data($data)->insert();
	}

	/**
	 * 统计
	 *  @param type $where 统计条件
	 *  @return int 统计个数
	 */
	public function count($where){
		$aCount = $this->_oDBOI->fields('count("id") as nums')->table($this->_table)->where($where)->select();
		if($aCount){
			return $aCount[0]['nums'];
		}else{
			return 0;
		}
	}
}


