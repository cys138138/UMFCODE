<?php
class UserInvitationModel{
	const STATU_TASK_FINISH = 1;	//可领取
	const DIRECT_INVITER_RECEIVED = 2;	//直接推荐人已领取，间接推荐人未领取
	const INDIRECT_INVITER_RECEIVED = 3;	//直接推荐人未领取，间接推荐人已领取
	const ALL_INVITER_RECEIVED = 4;	//直接推荐、间接推荐人都已领取


	//add
	public function addUserInvitaion($aData){
		$oUserInvitation = new Model(T_USER_INVITATION);
		return $oUserInvitation->add($aData);
	}

	//update
	public function setUserInvitation($aData){
		$oUserInvitation = new Model(T_USER_INVITATION);
		if(isset($aData['new_task_process_status'])){
			$aProcessStatus = explode(',', $aData['new_task_process_status']);
			$finishFlag = 1;
			foreach($aProcessStatus as $processStatu){
				if($processStatu != 1){
					$finishFlag = 0;
					break;
				}
			}
			if($finishFlag){
				$aData['invite_prize_status'] = 1;
			}
		}
		return $oUserInvitation->update($aData, array('id' => $aData['id']));
	}


	public function getUserInvitationById($id){
		$oUserInvitation = new Model(T_USER_INVITATION);
		$aInvitationInfo =  $oUserInvitation->get('', array('id'=>$id));
		if(!$aInvitationInfo){
			return $aInvitationInfo;
		}else{
			return $aInvitationInfo[0];
		}

	}

	/**
	 * 我的推荐详情
	 * @param type $userId 邀请的用户ID
	 * @param type $isReceiveAward 是否领取了奖励
	 * @param type $page 页数
	 * @param type $pageSize 页码
	 * @return boolean
	 */
	public function getUserInvitationDetailList($userId, $isReceiveAward, $page, $pageSize){
		$oUserInvitation = new Model(T_USER_INVITATION);
		if($isReceiveAward){
			//己领取
			$indirectWhere = '(`invite_prize_status`=' . self::INDIRECT_INVITER_RECEIVED . ' OR `new_task_process_status`=' . self::ALL_INVITER_RECEIVED . ')';
		}else{
			//末领取
			$indirectWhere = '`invite_prize_status`<' . self::INDIRECT_INVITER_RECEIVED;
		}
		$directWhere = '`invite_code`=' . $userId;

		//获得直接推荐人id列表
		$aUserDirectInviteList = $oUserInvitation->get('', $directWhere);
		if(!$aUserDirectInviteList){
			return $aUserDirectInviteList;
		}

		//获得用户间接推荐人
		$aUserIds = array();
		$aUserDirectInviteListRefer = array();
		foreach($aUserDirectInviteList as $key => $aUserDirectInvite){
			$aUserIds[] = $aUserDirectInvite['id'];
			$aUserDirectInviteListRefer[$aUserDirectInvite['id']] = $aUserDirectInvite;
			$aUserDirectInviteListRefer[$aUserDirectInvite['id']]['invite_list'] = array();
		}
		unset($aUserDirectInviteList);
		$aUserIndirectInviteList = $oUserInvitation->get('', $indirectWhere . ' AND `invite_code` in (' . implode(',', $aUserIds) . ')');
		if($aUserIndirectInviteList === false){
			return false;
		}
		//组装推荐人列表结构
		foreach($aUserIndirectInviteList as $aUserIndirectInvite){
			$aUserDirectInviteListRefer[$aUserIndirectInvite['invite_code']]['invite_list'][] = $aUserIndirectInvite;
		}
		$aUserIds = array();
		//组装需要查找的用户的id,把不需要的数据干掉
		foreach($aUserDirectInviteListRefer as $key => $aUserDirectInviteRefer){
			if($aUserDirectInviteRefer['invite_list']){
				$aUserIds[] = $aUserDirectInviteRefer['id'];
				foreach($aUserDirectInviteRefer['invite_list'] as $aUserIndirectInvite){
					$aUserIds[] = $aUserIndirectInvite['id'];
				}
			}elseif($isReceiveAward){
				if($aUserDirectInviteRefer['invite_prize_status'] == self::DIRECT_INVITER_RECEIVED || $aUserDirectInviteRefer['invite_prize_status'] == self::ALL_INVITER_RECEIVED){
					$aUserIds[] = $aUserDirectInviteRefer['id'];
				}else{
					unset($aUserDirectInviteListRefer[$key]);
				}
			}elseif(!$isReceiveAward){
				if($aUserDirectInviteRefer['invite_prize_status'] != self::DIRECT_INVITER_RECEIVED && $aUserDirectInviteRefer['invite_prize_status'] != self::ALL_INVITER_RECEIVED){
					$aUserIds[] = $aUserDirectInviteRefer['id'];
				}else{
					unset($aUserDirectInviteListRefer[$key]);
				}
			}
		}

		if(!$aUserIds){
			return $aUserIds;
		}
		$aUserList = $this->_getUserList($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}

		//给用户组装名字和头像
		foreach($aUserDirectInviteListRefer as &$aUserDirectInviteRefer){
			foreach($aUserList as $aUser){
				if($aUserDirectInviteRefer['id'] == $aUser['id']){
					$aUserDirectInviteRefer['name'] = $aUser['name'];
					$aUserDirectInviteRefer['profile'] = $aUser['profile'];
					break;
				}
			}
			foreach($aUserDirectInviteRefer['invite_list'] as &$aUserIndirectInvite){
				foreach($aUserList as $aUser){
					if($aUserIndirectInvite['id'] == $aUser['id']){
						$aUserIndirectInvite['name'] = $aUser['name'];
						$aUserIndirectInvite['profile'] = $aUser['profile'];
						break;
					}
				}
			}
		}
		$aReturnData = array();
		$i = 0;
		$offect = ($page - 1) * $pageSize;
		$end = $offect + $pageSize;
		$allCount = count($aUserDirectInviteListRefer);
		foreach($aUserDirectInviteListRefer as $aUserDirectInviteRefers){
			if($i >= $end){
				break;
			}elseif($i >= $offect){
				$aReturnData[] = $aUserDirectInviteRefers;
			}
			$i++;
		}
		return array('count' => $allCount, 'data' => $aReturnData);
	}

	//推荐好友排行
	public function getInvitationUserRankList($page = 1, $pageSize = 10){
		$offect = ($page - 1) * $pageSize;
		$oUserInvitation = new Model(T_USER_INVITATION);
		$aUserInvitationList = $oUserInvitation->get('`id`,`direct_invite_nums`,`indirect_invite_nums`,`receive_ub`', '', '`receive_ub` DESC', $offect, $pageSize);
		if(!$aUserInvitationList){
			return $aUserInvitationList;
		}
		$aUserIds = array();
		foreach($aUserInvitationList as $aUserInvitation){
			$aUserIds[] = $aUserInvitation['id'];
		}
		$oPersonal = new Model(T_PERSONAL);
		$aUserList = $oPersonal->get('`id`,`name`', array('id' => array('in', $aUserIds)));
		if($aUserList === false){
			return false;
		}
		foreach($aUserInvitationList as &$aUserInvitation){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aUserInvitation['id']){
					$aUserInvitation['name'] = $aUser['name'];
					break;
				}
			}
		}
		return $aUserInvitationList;
	}


	//当前会员的推荐详情
	public function getInvitationInfoByUserId($userId){
		$oUser = m('User');
		$aPersonalInfo = $oUser->getPersonalInfoByUserId($userId);
		if(!$aPersonalInfo){
			return false;
		}

		$oUserNumericalModel = m('UserNumerical');
		$aUserNumericalInfo = $oUserNumericalModel->getUserNumericalInfoById($userId);
		if(!$aUserNumericalInfo){
			return false;
		}

		$returnArray = array(
			'id'	 =>	$userId,
			'name'	 =>	$aPersonalInfo['name'],
			'profile'=>	$aPersonalInfo['profile'],
			'level'	 => $aUserNumericalInfo['level'],
			'direct_invite_nums'	=>	0,
			'indirect_invite_nums'	=>	0,
			'receive_ub'	=> 0
		);
		unset($aPersonalInfo);
		unset($aUserNumericalInfo);
		$aUserInvitationInfo = $this->getUserInvitationById($userId);
		if(!$aUserInvitationInfo){
			return $returnArray;
		}

		$returnArray['direct_invite_nums'] = $aUserInvitationInfo['direct_invite_nums'];
		$returnArray['indirect_invite_nums'] = $aUserInvitationInfo['indirect_invite_nums'];
		$returnArray['receive_ub'] = $aUserInvitationInfo['receive_ub'];
		unset($aUserInvitationInfo);
		return $returnArray;
	}

	public function getUserNewTaskStatusInfo($userId){
		$oUserInvitation = new Model(T_USER_INVITATION);
		$aUserInvitationInfo = $oUserInvitation->get('`new_task_process_status`', array('id' => $userId));
		if(!$aUserInvitationInfo){
			return $aUserInvitationInfo;
		}
		return $aUserInvitationInfo[0];
	}


	private function _getUserList($aUserIds){
		$oPersonal = new Model(T_PERSONAL);
		return $oPersonal->get('`id`, `name`, `profile`', array('id' => array('in', $aUserIds)));
	}
}
