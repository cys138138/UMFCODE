<?php
/**
 * 赛事模型
 */
class MatchModel{
	public $aStatus =  array(
		'not_released'		=>	1,	//未发布
		'released'			=>	2,	//已发布
		'wait_registration'	=>	3,	//等待报名
		'registrationing'	=>	4,	//报名中
		'wait_match'		=>	5,	//等待开赛
		'matching'			=>	6,	//赛事中
		'end_match'			=>	7,	//赛事已结束
		'not_over'			=>	8,	//赛事未结束
	);

	public $aTimeType = array(
		'registration_start_time'	=>	1,	//报名开始时间
		'registration_end_time'		=>	2,	//报名结束时间
		'match_start_time'			=>	3,	//赛事开始时间
		'match_end_time'			=>	4,	//赛事结束时间
	);

	const EVENT_REGISTRATION = 9;	//报名事件
	const EVENT_REJOIN = 17;			//再次参赛事件
	const EVENT_PRIZE = 12;			//得奖事件
	const PERSONAL_MESSAGE_MATCH_END = 20;			//比赛结束消息
	const PRIZE_UNRECEIVED = 1;		//比赛获奖未领取

	//添加赛事
	public function addMatch($aData){
		$oMatch = new Model(T_MATCH);
		$aData = $this->_parseMatchBeforToDB($aData, true);
		return $oMatch->add($aData);
	}

	//删除赛事
	public function deleteMatchById($matchId){
		$oMatch = new Model(T_MATCH);
		return $oMatch->delete(array('id' => $matchId));
	}

	//修改赛事
	public function setMatch($aData){
		$oMatch = new Model(T_MATCH);
		$aData = $this->_parseMatchBeforToDB($aData);
		return $oMatch->update($aData, array('id' => $aData['id']));
	}

	//根据赛事id得到赛事详细
	public function getMatchInfoById($matchId, $isFromManager = false){
		$oMatch = new Model(T_MATCH);
		$aMatchInfo = $oMatch->get('', array('id' => $matchId));
		if($aMatchInfo){
			if(!$isFromManager && !$aMatchInfo[0]['is_release']){	//如果是前台调用，并且没有发布
				return array();
			}
			$aMatchInfo = $this->_parseMatch($aMatchInfo);
			$aMatchInfo = $aMatchInfo[0];
			if($aMatchInfo['winners']){
				$aUserIds = array();
				foreach($aMatchInfo['winners'] as $aWinner){
					if(is_array($aWinner)){
						foreach($aWinner as $aUserData){
							$aUserIds[] = $aUserData['user_id'];
						}
					}
				}
				$aUserList = $this->_getUserListByIds($aUserIds);
				foreach($aMatchInfo['winners'] as &$aWinner){
					if(is_array($aWinner)){
						foreach($aWinner as &$aUserData){
							foreach($aUserList as $aUser){
								if($aUserData['user_id'] == $aUser['id']){
									$aUserData['user_info'] = $aUser;
								}
							}
						}
					}
				}
			}
		}
		return $aMatchInfo;
	}

	/*得到赛事列表
	$aCondition = array(
		'name',
		'status',
		'grade'
		'level'
		'time_type'
		'time_rate_start'
		'time_rate_end'
		'fee' => 1/0
	 	'is_xxt_user'	=>	0:非校讯通用户,1：校讯通用户
		'limit_xxt'	=>	0,1  -1全部
		'xxt_type'	=>	0:互联网用户，2：广东校讯通，3:山西校讯通
	);
	$page
	$from
	*/
	public function getMatchList($aCondition, $page = 1, $pageSize = 10, $order = '`id` DESC', $isFromCustomer = false, $userId = 0){
		$oMatch = new Model(T_MATCH);
		$offect = ($page - 1) * $pageSize;
		$where = $this->_parseWhereForGetMatchList($aCondition, $isFromCustomer);
		$aMatchList = $oMatch->get('', $where, $order, $offect, $pageSize);
		if($aMatchList){
			$aMatchList = $this->_parseMatch($aMatchList, $isFromCustomer);
			$aMatchIds = array();
			foreach($aMatchList as $aMatch){
				$aMatchIds[] = $aMatch['id'];
			}
			$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
			$aMatchUserRelationList = $oMatchUserRelation->get('', '`user_id`=' . $userId . ' AND `match_id` in (' . implode(',', $aMatchIds) . ')');
			if($aMatchUserRelationList === false){
				return false;
			}
			$aMatchList = $this->_mergeMatchListANDMatchUserRelationList($aMatchList, $aMatchUserRelationList);
		}
		return $aMatchList;
	}

	public function getMatchCount($aCondition,$isFromCustomer = false){
		$oMatch = new Model(T_MATCH);
		$where = $this->_parseWhereForGetMatchList($aCondition, $isFromCustomer);
		return $oMatch->count($where);
	}

	//得到用户的赛事列表
	public function getUserMatchList($userId, $aCondition = array(), $page = 1, $pageSize = 10, $order = '`id` DESC'){
		$offect = ($page - 1) * $pageSize;
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('', '`user_id`=' . $userId);
		if($aMatchUserRelationList){
			$aMatchIds = array();
			foreach($aMatchUserRelationList as $key => $aMatchUserRelation){
				$aMatchIds[] = $aMatchUserRelation['match_id'];
			}
			$oMatch = new Model(T_MATCH);
			$where = $this->_parseWhereForGetMatchList($aCondition, true);
			if($where){
				$where .= ' AND ';
			}
			$where .= '`id` in (' . implode(',', $aMatchIds) . ')';
			$aMatchList = $oMatch->get('', $where, $order, $offect, $pageSize);
			if(!$aMatchList){
				return $aMatchList;
			}
			$aMatchList = $this->_parseMatch($aMatchList, true);
			$aMatchList = $this->_mergeMatchListANDMatchUserRelationList($aMatchList, $aMatchUserRelationList);
			return $aMatchList;
		}
		return $aMatchUserRelationList;
	}

	/*
	 *用户的赛事列表
	 */
	public function getUserMatchListNew($userId, $page = 1, $pageSize = 10, $order = '', $prizeFlag = 0){
		$offect = ($page - 1) * $pageSize;
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$field = '`id`,`match_id`,`remainder_es_ids`,`best_score`,`start_time`,`end_time`,`prize_status`,`ranking`';
		$specialFlag = 0;
		if(strpos($order, 'create_time') !== false || strpos($order, 'best_score') !== false){
			$specialFlag = 1;
		}
		if($specialFlag){
			$where = '`user_id`=' . $userId;
			if($prizeFlag){
				$where .= ' AND `prize_status`>0';
			}
			$aMatchUserRelationList = $oMatchUserRelation->get($field, $where, $order, $offect, $pageSize);
		}else{
			$aMatchUserRelationList = $oMatchUserRelation->get($field, '`user_id`=' . $userId);
		}
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}
		$aMatchIds = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aMatchIds[] = $aMatchUserRelation['match_id'];
		}
		$oMatch = new Model(T_MATCH);
		$field = '`id`,`name`,`profile`,`description`,`match_end_time`,`duration`,`grade_id`,`subject_id`,`winners`';
		$aMatchList = $oMatch->get($field, array('id' => array('in', $aMatchIds)));
		if(!$aMatchList){
			return $aMatchList;
		}
		$aMatchList = $this->_mergeMatchListANDMatchUserRelationListNew($aMatchList, $aMatchUserRelationList);
		if($specialFlag){
			return $aMatchList;
		}
		unset($aMatchUserRelationList);
		//计算排名
		$currentTime = time();
		foreach($aMatchList as $key => $aMatch){
			//如果还没有排名的话,计算排名
			if(!$aMatch['match_user_relation']['ranking']){
				$ranking = $oMatchUserRelation->count('`match_id`=' . $aMatch['id'] . ' AND `best_score`>' . $aMatch['match_user_relation']['best_score']) + 1;
				$aMatchList[$key]['match_user_relation']['ranking'] = $ranking;
				//如果比赛结束了,保存排名
				if($aMatch['match_end_time'] <= $currentTime){
					$oMatchUserRelation->update(array('ranking' => $ranking), array('id' => $aMatch['match_user_relation']['id']));
				}
			}
		}

		//排序
		$count = count($aMatchList);
		if($order){	//最好排名排序
			for($i = 0; $i < $count - 1; $i++){
				for($j = $i + 1; $j < $count; $j++){
					if($aMatchList[$i]['match_user_relation']['ranking'] > $aMatchList[$j]['match_user_relation']['ranking']){
						$aTemp = $aMatchList[$i];
						$aMatchList[$i] = $aMatchList[$j];
						$aMatchList[$j] = $aTemp;
					}
				}
			}
		}else{	//默认排序
			$expireTime = $this->_getAwardExpireTime();
			$aTempMatchList = array();
			foreach($aMatchList as $key => $aMatch){	//待领奖的比赛
				if($aMatch['match_user_relation']['prize_status'] == self::PRIZE_UNRECEIVED && $aMatch['match_end_time'] > $expireTime){
					$aTempMatchList[] = $aMatch;
					unset($aMatchList[$key]);
				}
			}
			foreach($aMatchList as $key => $aMatch){	//进行中的比赛
				if($aMatch['match_end_time'] > $currentTime){
					$aTempMatchList[] = $aMatch;
					unset($aMatchList[$key]);
				}
			}
			$remainderCount = count($aMatchList);	//剩余的数量
			//给剩余的比赛按结束时间排序
			$aMatchList = array_merge($aMatchList);
			for($i = 0; $i < $remainderCount - 1; $i++){
				for($j = $i + 1; $j < $remainderCount; $j++){
					if($aMatchList[$i]['match_end_time'] < $aMatchList[$j]['match_end_time']){
						$aTemp = $aMatchList[$i];
						$aMatchList[$i] = $aMatchList[$j];
						$aMatchList[$j] = $aTemp;
					}
				}
			}
			$aMatchList = array_merge($aTempMatchList, $aMatchList);
		}
		if($prizeFlag){
			foreach($aMatchList as $key => $aMatch){
				if($aMatch['match_user_relation']['prize_status'] == 0){
					unset($aMatchList[$key]);
				}
			}
			$aMatchList = array_merge($aMatchList);
		}
		$aMatchList = array_slice($aMatchList, $offect, $pageSize);
		return $aMatchList;
	}

	public function getUserMatchCount($userId){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->count('`user_id`=' . $userId);
	}

	public function getUserPrizeMatchCount($userId){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->count('`user_id`=' . $userId . ' AND `prize_status`>0');
	}

	public function getUserPrizeMatchList($userId, $page, $pageSize){
		$offect = ($page - 1) * $pageSize;
		$field = '`id`,`match_id`,`remainder_es_ids`,`best_score`,`start_time`,`end_time`,`prize_status`,`ranking`';
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get($field, '`user_id`=' . $userId . ' AND `prize_status`>0', '`create_time` DESC', $offect, $pageSize);
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}
		$aMatchIds = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aMatchIds[] = $aMatchUserRelation['match_id'];
		}
		$oMatch = new Model(T_MATCH);
		$field = '`id`,`name`,`profile`,`description`,`match_end_time`,`duration`,`grade_id`,`subject_id`';
		$aMatchList = $oMatch->get($field, array('id' => array('in', $aMatchIds)));
		if(!$aMatchList){
			return $aMatchList;
		}
		return $this->_mergeMatchListANDMatchUserRelationListNew($aMatchList, $aMatchUserRelationList);
	}

	//得到用户最近赛事
	public function getUserLatestMatchList($userId, $length = 3){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('`match_id`', '`user_id`=' . $userId, '`id` DESC', 0, $length);
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}

		$aMatchIds = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aMatchIds[] = $aMatchUserRelation['match_id'];
		}
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`profile`,`name`,`registration_start_time`,`registration_end_time`,`match_start_time`,`match_end_time`,`duration`', array('id' => array('in', $aMatchIds)));
		if(!$aMatchList){
			return $aMatchList;
		}

		$aMatchCountList = $oMatchUserRelation->get('`match_id`,count(*) as `nums`', '`match_id` in (' . implode(',', $aMatchIds) . ')', '', '', '', '`match_id`');
		if($aMatchCountList === false){
			return false;
		}
		foreach($aMatchList as &$aMatch){
			foreach($aMatchCountList as $aMatchCount){
				if($aMatch['id'] == $aMatchCount['match_id']){
					$aMatch['member_count'] = $aMatchCount['nums'];
					break;
				}
			}
		}
		return $aMatchList;
	}

	//根据id得到用户参赛信息
	public function getMatchUserRelationInfoById($relationId){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationInfo = $oMatchUserRelation->get('', array('id' => $relationId));
		if($aMatchUserRelationInfo){
			$aMatchUserRelationInfo = $aMatchUserRelationInfo[0];
			$aMatchUserRelationInfo['remainder_es_ids'] = json_decode($aMatchUserRelationInfo['remainder_es_ids'], true);
			if($aMatchUserRelationInfo['match_history']){
				$aMatchUserRelationInfo['match_history'] = json_decode($aMatchUserRelationInfo['match_history'], true);
			}else{
				$aMatchUserRelationInfo['match_history'] = array();
			}
			if($aMatchUserRelationInfo['address']){
				$aMatchUserRelationInfo['address'] = json_decode($aMatchUserRelationInfo['address'], true);
			}else{
				$aMatchUserRelationInfo['address'] = array();
			}
		}
		return $aMatchUserRelationInfo;
	}

	public function getMatchUserRelationInfo($userId, $matchId){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationInfo = $oMatchUserRelation->get('', '`user_id`=' . $userId . ' AND `match_id`=' . $matchId);
		if($aMatchUserRelationInfo){
			$aMatchUserRelationInfo = $aMatchUserRelationInfo[0];
			$aMatchUserRelationInfo['remainder_es_ids'] = json_decode($aMatchUserRelationInfo['remainder_es_ids'], true);
			if($aMatchUserRelationInfo['match_history']){
				$aMatchUserRelationInfo['match_history'] = json_decode($aMatchUserRelationInfo['match_history'], true);
			}else{
				$aMatchUserRelationInfo['match_history'] = array();
			}
			if($aMatchUserRelationInfo['address']){
				$aMatchUserRelationInfo['address'] = json_decode($aMatchUserRelationInfo['address'], true);
			}else{
				$aMatchUserRelationInfo['address'] = array();
			}
		}
		return $aMatchUserRelationInfo;
	}

	//添加用户参赛信息
	public function addMatchUserRelation($aData){
		if(isset($aData['remainder_es_ids'])){
			$aData['remainder_es_ids'] = json_encode($aData['remainder_es_ids']);
		}else{
			$aData['remainder_es_ids'] = json_encode(array());
		}
		if(isset($aData['address'])){
			$aData['address'] = json_encode($aData['address']);
		}else{
			$aData['address'] = json_encode(array());
		}
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->add($aData);
	}

	//更新用户参赛信息
	public function setMatchUserRelation($aData){
		if(isset($aData['remainder_es_ids'])){
			$aData['remainder_es_ids'] = json_encode($aData['remainder_es_ids']);
		}
		if(isset($aData['match_history'])){
			$aData['match_history'] = json_encode($aData['match_history']);
		}

		if(isset($aData['address'])){
			$aData['address'] = json_encode($aData['address']);
		}

		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->update($aData, array('id' => $aData['id']));
	}

	//报名动作，包括扣金币和写事件
	public function registrationAction($aData, $gold){
		if(isset($aData['remainder_es_ids'])){
			$aData['remainder_es_ids'] = json_encode($aData['remainder_es_ids']);
		}else{
			$aData['remainder_es_ids'] = json_encode(array());
		}

		if(isset($aData['address'])){
			$aData['address'] = json_encode($aData['address']);
		}

		$oDboi = new DBOI();
		$oDboi->startTrans();
		$relationId = $oDboi->table(T_MATCH_USER_RELATION)->data($aData)->insert();
		if($relationId){
			if($gold){
				$result = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aData['user_id']))->data(array('gold' => array('sub', $gold)))->update();
				if(!$result){
					$oDboi->rollBack();
					return false;
				}
			}
//			$aEvent = array();
//			$aEvent['user_id'] = $aData['user_id'];
//			$aEvent['type'] = self::EVENT_REGISTRATION;
//			$aEvent['data_id'] = $relationId;
//			$oDboi->table(T_SNS_EVENT)->data($aEvent)->insert();	//写事件失败不回滚、不报错
			//为老师增加金币
			$aMatch = $oDboi->table(T_MATCH)->where(['id' => $aData['match_id']])->select();
			$matchSubjectId = $aMatch[0]['subject_id'];
			if(in_array($matchSubjectId, [1, 2, 3])){
				$result = $this->_addTeacherGold($aData['user_id'], $oDboi, $matchSubjectId);
				if(!$result){
					$oDboi->rollBack();
					return false;
				}
			}
		}
		return $relationId;
	}

	private function _addTeacherGold($userId, $oDboi, $subjectId){
		$aUserInfo = getUserInfo($userId, ['personal']);
		if(!$aUserInfo){
			$oDboi->rollBack();
			return false;
		}
		$aClassTeacherRelation = $aUserInfo['class_teacher_relation'];
		if(!$aClassTeacherRelation){
			return true;
		}
		$aTeacherExtendCodeList = [];
		$aExtendCodeList = [];
		foreach($aClassTeacherRelation as $aClassTeacherRelationOne){
			$aTemp = [];
			$aTemp['classId'] = $aClassTeacherRelationOne['ClassId'];
			$aTemp['extendCode'] = $aClassTeacherRelationOne['TeacherId'];
			$aExtendCodeList[] = $aClassTeacherRelationOne['TeacherId'];
			$aTeacherExtendCodeList[] = $aTemp;
		}
		if(!$aTeacherExtendCodeList){
			return true;
		}
		$where = '`extend_type`=' . $aUserInfo['xxt_type'] . ' AND `extend_code` in (' . implode(',', $aExtendCodeList) . ') AND `open_plan_time`>0';
		$aTeacherList = $oDboi->table(T_TEACHER_INDEX)->where($where)->orderby('`open_plan_time` ASC')->select();
		if(!$aTeacherList){
			return true;
		}
		$aTeacherIds = [];
		foreach($aTeacherList as $aTeacher){
			$aTeacherIds[] = $aTeacher['id'];
		}
		$aTeacherDataList = $oDboi->table(T_TEACHER)->where(['id' => ['in', $aTeacherIds]])->select();
		$aTeacherInfo = [];
		foreach($aTeacherList as $aTeacher){
			$aClassRelation = [];
			foreach($aTeacherDataList as $aTeacherData){
				if($aTeacherData['id'] == $aTeacher['id']){
					if($aTeacherData['class_relation']){
						$aClassRelation = json_decode($aTeacherData['class_relation'], true);
					}
					break;
				}
			}
			if(!$aClassRelation){
				continue;
			}
			$classId = 0;
			foreach($aTeacherExtendCodeList as $aTeacherExtendCode){
				if($aTeacher['extend_code'] == $aTeacherExtendCode['extendCode']){
					$classId = $aTeacherExtendCode['classId'];
					break;
				}
			}
			$aStudentClass = [];
			foreach($aClassRelation as $aClassInfo){
				if($classId == $aClassInfo['classId']){
					$aStudentClass = $aClassInfo;
				}
			}
			if(!$aStudentClass || !isset($aStudentClass['selectSubject']) || $aStudentClass['selectSubject'] != $subjectId){
				continue;
			}
			$aTeacherInfo = $aTeacher;
		}
		if(!$aTeacherInfo){
			return true;
		}
		$aMonth = $this->_getThisMonthStartAndEndTime();

		$passMissionCount = 0;
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`', '`subject_id`=' . $subjectId . ' AND `is_forbidden`=0');
		if($aMissionList){
			$aMissionIds = [];
			foreach($aMissionList as $aMission){
				$aMissionIds[] = $aMission['id'];
			}

			$oMissionUserRelation = new Model(T_MISSION_USER_RELATION_INDEX);
			$where = '`user_id`=' . $userId . ' AND `pass_time`>=' . $aMonth['start_time'] . ' AND `pass_time`<=' . $aMonth['end_time'] . ' AND `is_pass`=1 AND `mission_id` in (' . implode(',', $aMissionIds) . ')';
			$passMissionCount = $oMissionUserRelation->count($where);
		}

		$joinMatchCount = 0;
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('id', '`subject_id`=' . $subjectId);
		if($aMatchList){
			$aMatchIds = [];
			foreach($aMatchList as $aMatch){
				$aMatchIds[] = $aMatch['id'];
			}
			$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
			$where = '`user_id`=' . $userId . ' AND `create_time`>=' . $aMonth['start_time'] . ' AND `create_time`<=' . $aMonth['end_time'] . ' AND `match_id` in (' . implode(',', $aMatchIds) . ')';
			$joinMatchCount = $oMatchUserRelation->count($where);
		}
		if($passMissionCount + $joinMatchCount > 100){
			return true;
		}
		return $oDboi->table(T_TEACHER_INDEX)->where(['id' => $aTeacherInfo['id']])->data(['gold' => ['add', 1]])->update();
	}

	private function _getThisMonthStartAndEndTime(){
		$month = date('Ym');
		$selectYear = substr($month, 0, 4);
		$selectMonth = substr($month, 4, 2);
		$startTime = mktime(0, 0, 0, $selectMonth, 1, $selectYear);
		if($selectMonth == 12){
			$selectMonth = 1;
			$selectYear += 1;
		}else{
			$selectMonth += 1;
		}
		$endTime = mktime(0, 0, 0, $selectMonth, 1, $selectYear) - 1;
		return ['start_time' => $startTime, 'end_time' => $endTime];
	}

	//再次参赛
	public function joinMatchAgain($aUserRelationInfo, $gold){
		$aData = array();
		$aData['correct_es_count'] = 0;
		$aData['start_time'] = 0;
		$aData['end_time'] = 0;
		$aData['rejoin_times'] = array('add', 1);
		$aData['last_rejoin_time'] = time();
		$aData['prop_use_times'] = 0;
		$aData['remainder_es_ids'] = json_encode($aUserRelationInfo['remainder_es_ids']);
		if(isset($aUserRelationInfo['address'])){
			$aData['address'] = json_encode($aUserRelationInfo['address']);
		}
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result = $oDboi->table(T_MATCH_USER_RELATION)->where(array('id' => $aUserRelationInfo['id']))->data($aData)->update();
		if($result){
			if($gold){
				$row = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aUserRelationInfo['user_id']))->data(array('gold' => array('sub', $gold)))->update();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}
			}
			//覆盖本场比赛的其他动态
			//$oDboi->table(T_SNS_EVENT)->where('`type` in (9,11,17) AND `data_id`=' . $aUserRelationInfo['id'])->delete();
			//产生再次参赛动态
//			$aEventData = array();
//			$aEventData['user_id'] = $aUserRelationInfo['user_id'];
//			$aEventData['type'] = self::EVENT_REJOIN;
//			$aEventData['data_id'] = $aUserRelationInfo['id'];
//			$eventId = $oDboi->table(T_SNS_EVENT)->data($aEventData)->insert();
		}
		return $result;
	}

	//获取某比赛最新排名,返回名次数字
	public function getMatchRanking($matchId, $score){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$where = '`match_id`=' . $matchId . ' AND `best_score`>' . $score;
		return $oMatchUserRelation->count($where) + 1;
	}

	//获取比赛的排行榜
	public function getMatchRankingList($matchId, $page = 1, $pageSize = 10, $order = '`best_score` DESC'){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$offect = ($page - 1) * $pageSize;
		$aMatchUserRelationList =$oMatchUserRelation->get('', '`match_id`=' . $matchId, $order, $offect, $pageSize);
		if($aMatchUserRelationList){
			$aUserIds = array();
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				$aUserIds[] = $aMatchUserRelation['user_id'];
			}
			$aUserList = $this->_getUserListByIds($aUserIds, 1);
			if($aUserList){
				$aReturnData = array();
				foreach($aMatchUserRelationList as $aMatchUserRelation){
					foreach($aUserList as $aUser){
						if($aUser['id'] == $aMatchUserRelation['user_id']){
							$aUser['best_score'] = $aMatchUserRelation['best_score'];
							$aReturnData[] = $aUser;
							break;
						}
					}
				}
				return $aReturnData;
			}else{
				return $aUserList;
			}
		}else{
			return $aMatchUserRelationList;
		}
	}

	//随机生成竞赛题目
	public function distributeEsList($aEsRule, $aEsSet){
		$aResultEsIds = array();

		foreach($aEsRule as $aRule){
			$aAllEsSet = array();
			if($aRule['es_type_id'] == 0){
				foreach($aEsSet as $esSet){
					if($esSet){
						$aAllEsSet = array_merge($aAllEsSet, $esSet);
					}
				}
			}else{
				$aAllEsSet = $aEsSet[$aRule['es_type_id']];
			}
			$aKeys = array_rand($aAllEsSet, $aRule['es_count']);
			if(is_array($aKeys)){
				foreach($aKeys as $Key){
					$aResultEsIds[] = $aAllEsSet[$Key];
				}
			}else{
				$aResultEsIds[] = $aAllEsSet[$aKeys];
			}
		}
		return $aResultEsIds;
	}

	//用户得奖信息列表
	public function getUserReceivePrizeList($userId, $prizeStatus, $page = 1, $pageSize = 10, $order = '`id` DESC'){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$offect = ($page - 1) * $pageSize;
		$aUserPrizeMatchList = $oMatchUserRelation->get('', '`user_id`=' . $userId . ' AND `prize_status`=' . $prizeStatus, $order, $offect, $pageSize);
		if($aUserPrizeMatchList){
			$aMatchIds = array();
			$aReturnData = array();
			foreach($aUserPrizeMatchList as $aUserPrizeMatch){
				$aMatchIds[] = $aUserPrizeMatch['match_id'];
			}
			$oMatch = new Model(T_MATCH);
			$aMatchList = $oMatch->get('', array('id' => array('in', $aMatchIds)));
			if(!$aMatchList){
				return $aMatchList;
			}
			$aMatchList = $this->_parseMatch($aMatchList, true);
			foreach($aMatchList as $aMatch){
				foreach($aMatch['winners'] as $key => $aWinner){
					if($key == 'create_time'){
						continue;
					}
					foreach($aWinner as $ranking => $aUserData){
						if($aUserData['user_id'] == $userId){
							$aData = array();
							$aData['user_id'] = $userId;
							$aData['match_id'] = $aMatch['id'];
							$aData['match_name'] = $aMatch['name'];
							$aData['match_profile'] = $aMatch['profile'];
							$aData['prize_type'] = $key;
							$aData['ranking'] = $ranking;
							$aReturnData[] = $aData;
							break;
						}
					}
				}
			}
			return $aReturnData;
		}
		return $aUserPrizeMatchList;
	}

	//获取报名人数
	public function getRegistrationCountByMatchId($matchId){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->count('`match_id`=' . $matchId);
	}

	//获取参赛人数
	public function getAttendMatchCountByMatchId($matchId){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->count('`match_id`=' . $matchId);
	}

	//得到题目集
	public function getEsSetForMatch($aCategoryIds){
		$oEsIndex = new Model(T_ES_INDEX);
		$where = '`category_id` in (' . implode(',', $aCategoryIds) . ') AND `status`=5';
		$aTypeIds = $oEsIndex->get('distinct `type_id`', $where);
		if(!$aTypeIds){
			return $aTypeIds;
		}
		$aEsSet = array();
		foreach($aTypeIds as $aTypeId){
			$aEsSet[$aTypeId['type_id']] = array();
		}
		$aEsList = $oEsIndex->get('', $where);
		if(!$aEsList){
			return $aEsList;
		}
		foreach($aEsList as $aEs){
			$aEsSet[$aEs['type_id']][] = $aEs['id'];
		}
		return $aEsSet;
	}

	public function getPrizeUserList($matchId, $aAwards){
		$topNum = count($aAwards['top']);	//取前多少名
		$randNum = $aAwards['rand']['number'];	//幸运奖人数
		$aRandRange = $aAwards['rand']['ranking_rate'];	//抽奖范围
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aTopList = $oMatchUserRelation->get('', '`match_id`=' . $matchId . ' AND best_score>0', '`best_score` DESC', 0, $topNum);
		if(!$aTopList){
			return $aTopList;
		}
		$aUserIds = array();
		$aTopUserList = array();
		$i = 1;
		foreach($aTopList as $aTop){
			$aTemp = array();
			$aTemp['user_id'] = $aTop['user_id'];
			$aTemp['best_score'] = $aTop['best_score'];
			$aTopUserList[$i] = $aTemp;
			$i++;
			$aUserIds[] = $aTop['user_id'];
		}
		$aRandUserList = array();
		if($randNum){
			$aRandList = $oMatchUserRelation->get('', '`match_id`=' . $matchId . ' AND `best_score`>0', '`best_score` DESC', $aRandRange[0] - 1, $aRandRange[1] - $aRandRange[0] + 1);
			if($aRandList === false){
				return false;
			}elseif($aRandList){
				if(count($aRandList) < $randNum){
					$randNum = count($aRandList);
				}
				$aKeys = array_rand($aRandList, $randNum);
				$aUserList = array();
				if(is_array($aKeys)){
					foreach($aKeys as $Key){
						$aUserList[] = $aRandList[$Key];
					}
				}else{
					$aUserList[] = $aRandList[$aKeys];
				}
				foreach($aUserList as $aUser){
					$aTemp = array();
					$aTemp['user_id'] = $aUser['user_id'];
					$aTemp['best_score'] = $aUser['best_score'];
					$aRandUserList[] = $aTemp;
					$aUserIds[] = $aUser['user_id'];
				}
			}
		}
		$oPersonal = new Model(T_PERSONAL);
		$aUserList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aTopUserList as &$aTopUser){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aTopUser['user_id']){
					$aTopUser['user_name'] = $aUser['name'];
					break;
				}
			}
		}
		foreach($aRandUserList as &$aRandUser){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aRandUser['user_id']){
					$aRandUser['user_name'] = $aUser['name'];
					break;
				}
			}
		}
		return array('top' => $aTopUserList, 'rand' => $aRandUserList);
	}

	//发奖
	public function awardPrizes($matchId, $aAwards){
		$topNum = count($aAwards['top']);	//取前多少名
		$randNum = $aAwards['rand']['number'];	//幸运奖人数
		$aRandRange = $aAwards['rand']['ranking_rate'];	//抽奖范围
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aTopList = $oMatchUserRelation->get('', '`match_id`=' . $matchId, '`best_score` DESC', 0, $topNum);
		if(!$aTopList){
			return $aTopList;
		}
		$aTopUserList = array();
		$i = 1;
		foreach($aTopList as $aTop){
			$aData = array();
			$aData['user_id'] = $aTop['user_id'];
			$aData['receive_time'] = 0;
			$aTopUserList[$i] = $aData;
			$i++;
		}
		$aRandUserList = array();
		if($randNum){
			$aRandList = $oMatchUserRelation->get('', '`match_id`=' . $matchId . ' AND `best_score`>0', '`best_score` DESC', $aRandRange[0] - 1, $aRandRange[1] - $aRandRange[0] + 1);
			if($aRandList === false){
				return false;
			}elseif($aRandList){
				if(count($aRandList) < $randNum){
					$randNum = count($aRandList);
				}
				$aKeys = array_rand($aRandList, $randNum);
				$aUserList = array();
				if(is_array($aKeys)){
					foreach($aKeys as $Key){
						$aUserList[] = $aRandList[$Key];
					}
				}else{
					$aUserList[] = $aRandList[$aKeys];
				}
				foreach($aUserList as $aUser){
					$aData = array();
					$aData['user_id'] = $aUser['user_id'];
					$aData['receive_time'] = 0;
					$aRandUserList[] = $aData;
				}
			}
		}
		$aUpdate = array();
		$aUpdate['winners'] = json_encode(array('top' => $aTopUserList, 'rand' => $aRandUserList, 'create_time' => time()));
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result = $oDboi->table(T_MATCH)->data($aUpdate)->where(array('id' => $matchId))->update();
		if($result){
			$aPrizeUserList = array_merge($aTopUserList, $aRandUserList);
			$aNotice = array();
			$aUserIds = array();
			foreach($aPrizeUserList as $aTopUser){
				if(in_array($aTopUser['user_id'], $aUserIds)){
					continue;
				}
				$aUserIds[] = $aTopUser['user_id'];
				$row = $oDboi->table(T_MATCH_USER_RELATION)->where('`match_id`=' . $matchId . ' AND `user_id`=' . $aTopUser['user_id'])->data(array('prize_status' => 1))->update();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}

				$aData = array();
				$aData['user_id'] = $aTopUser['user_id'];
				$aData['type'] = self::EVENT_PRIZE;
				$aRelationInfo = $oMatchUserRelation->get('', '`match_id`=' . $matchId . ' AND `user_id`=' . $aTopUser['user_id']);
				if($aRelationInfo === false){
					$oDboi->rollBack();
					return false;
				}
				$aData['data_id'] = $aRelationInfo[0]['id'];
				$aNotice[] = $aData;
				//覆盖本赛事其他的动态
				//$oDboi->table(T_SNS_EVENT)->where('`type` in (9,11,17) AND `data_id`='. $aRelationInfo[0]['id'])->delete();
			}
			//$id = $oDboi->table(T_SNS_EVENT)->data($aNotice)->insert();
//			if(!$id){
//				$oDboi->rollBack();
//				return false;
//			}
			//给所有报名用户写通知
			$aMatchUserRelationList = $oDboi->table(T_MATCH_USER_RELATION)->fields('`id`,`user_id`')->where('`match_id`=' . $matchId)->select();
			if($aMatchUserRelationList === false){
				$oDboi->rollBack();
				return false;
			}
			$aPersonalMessageData = array();
			$aUserId = array();
			$oPersonal = new Model(T_PERSONAL);
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				$aTempData = array();
				$aTempData['user_id'] = $aMatchUserRelation['user_id'];
				$aUserId[] = $aMatchUserRelation['user_id'];
				$aTempData['type'] = self::PERSONAL_MESSAGE_MATCH_END;
				$aTempData['data_id'] = $aMatchUserRelation['id'];
				$aPersonalMessageData[] = $aTempData;
				if(count($aPersonalMessageData) >= 100){	//够一百条插入一次
					$oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessageData)->insert();
					$aPersonalMessageData = array();	//清空
					$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>array('in', $aUserId)));
					$aUserId = array();
				}
			}
			//如果还有没有插入的
			if($aPersonalMessageData){
				$oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessageData)->insert();
				$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>array('in', $aUserId)));
			}
		}
		return $result;
	}

	//领奖
	public function receivePrize($userId, $matchId){
		$oMatch = new Model(T_MATCH);
		$aMatchInfo = $oMatch->get('', array('id' => $matchId));
		$aMatchInfo = $aMatchInfo[0];
		$aWinners = json_decode($aMatchInfo['winners'], true);
		$aAwards = json_decode($aMatchInfo['awards'], true);
		$aUserPrize = array();
		foreach($aWinners as $type => $aPrizeType){
			if(is_array($aPrizeType) && $aPrizeType){
				foreach($aPrizeType as $order => $aUser){
					if($aUser['user_id'] == $userId && $aUser['receive_time'] == 0){
						$aUserPrize['type'] = $type;
						$aUserPrize['order'] = $order;
						break;
					}
				}
			}
		}
		if($aUserPrize){
			if($aUserPrize['type'] == 'top'){
				$aPrize = $aAwards[$aUserPrize['type']][$aUserPrize['order']];
			}else{
				$aPrize = $aAwards[$aUserPrize['type']];
			}
			$aUpdateWinners = $aWinners;
			$aUpdateWinners[$aUserPrize['type']][$aUserPrize['order']]['receive_time'] = time();
			$oDboi = new DBOI();
			$oDboi->startTrans();
			$result = $oDboi->table(T_MATCH)->data(array('winners' => json_encode($aUpdateWinners)))->where(array('id' => $aMatchInfo['id']))->update();
			if($result){
				$row = $oDboi->table(T_MATCH_USER_RELATION)->where('`match_id`=' . $matchId . ' AND `user_id`=' . $userId)->data(array('prize_status' => 2))->update();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}
				/*$aUserNumericalUpdate = array();
				if(isset($aPrize['gold']) && $aPrize['gold']){
					$aUserNumericalUpdate['gold'] = array('add', $aPrize['gold']);
				}
				if(isset($aPrize['accumulate_points']) && $aPrize['accumulate_points']){
					$aUserNumericalUpdate['accumulate_points'] = array('add', $aPrize['accumulate_points']);
				}
				$row = $oDboi->table(T_USER_NUMERICAL)->data($aUserNumericalUpdate)->where(array('id' => $userId))->update();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}*/
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	/*
	 报名人数不够12人（包含12人），且大于3人
		按真实显示 + 伪造[按时间点随机]  3
	 报名人数超过12人
		在线人数超过3人（包含3人）
			按真实显示（最多显示50头像）
		在线人数不够3人
			按真实显示 + 伪造[按时间点随机]  3
	 ===========================================================

	 */
	//得到在线用户
	public function getMatchOnlineCustomers($matchId, $length = 50){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$registerNum = $oMatchUserRelation->count('`match_id`=' . $matchId);	//报名人数
		$oMatch = new Model(T_MATCH);
		$aMatchInfo = $oMatch->get('', array('id' => $matchId));
		if(!$aMatchInfo){
			return false;
		}
		$duration = $aMatchInfo[0]['duration'];
		unset($aMatchInfo);
		unset($oMatch);
		$where = '`match_id`=' . $matchId . ' AND `end_time`=0 AND `start_time`>' . (time() - $duration * 60);
		$onLineCount = $oMatchUserRelation->count($where);	//在线人数
		//查出在线用户
		$aUserList = array();
		$aMatchUserRelationList = $oMatchUserRelation->get('', $where, '', 0, $length);
		if($aMatchUserRelationList === false){
			return false;
		}elseif($aMatchUserRelationList){
			$aUserIds = array();
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				$aUserIds[] = $aMatchUserRelation['user_id'];
			}
			$aUserList = $this->_getUserListByIds($aUserIds);
		}
		if($onLineCount < 3 && $registerNum > 3){	//如果在线人数小于3,并且注册人数大于3
			$configureFile = SYSTEM_ROOT_PATH . 'apps/config/online_user.config.php';
			if(file_exists($configureFile)){
				$aConfigUserList = include($configureFile);
			}else{
				return false;
			}
			if($registerNum - $onLineCount > 3){	//如果注册人数比在线人数多超过3人,则伪造3人
				$aKeys = array_rand($aConfigUserList, 3);
				$onLineCount = $onLineCount + 3;
			}else{	//注册人数很少，只显示3个
				$aKeys = array_rand($aConfigUserList, 3 - $onLineCount);
				$onLineCount = 3;
			}
			if(is_array($aKeys)){
				foreach($aKeys as $key){
					$aUserList[] = $aConfigUserList[$key];
				}
			}else{
				$aUserList[] = $aConfigUserList[$aKeys];
			}
		}
		return array('count' => $onLineCount, 'user_list' => $aUserList);
	}

	public function getRejoinMatchUserList($matchId, $page = 1, $pageSize = 10){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$offect = ($page - 1) * $pageSize;
		$where = '`match_id`=' . $matchId . ' AND `rejoin_times`>0';
		$aMatchUserRelationList = $oMatchUserRelation->get('', $where, '`last_rejoin_time` DESC', $offect, $pageSize);
		if($aMatchUserRelationList){
			$aUserIds = array();
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				$aUserIds[] = $aMatchUserRelation['user_id'];
			}
			$aUserList = $this->_getUserListByIds($aUserIds);
			if($aUserList){
				foreach($aUserList as &$aUser){
					foreach($aMatchUserRelationList as $aMatchUserRelation){
						if($aUser['id'] == $aMatchUserRelation['user_id']){
							$aUser['rejoin_times'] = $aMatchUserRelation['rejoin_times'];
							$aUser['last_rejoin_time'] = $aMatchUserRelation['last_rejoin_time'];
							break;
						}
					}
				}
			}
			return $aUserList;
		}else{
			return $aMatchUserRelationList;
		}
	}

	//得到奖励的积分数量
	public function getPrizeAccumulatePoints($matchId, $ranking = 0){
		$registCount = $this->getRegistrationCountByMatchId($matchId);
		if($ranking){
			if($ranking == -1){
				$rate = 0.2;
			}elseif($ranking < 4){
				$rate = 1 - ($ranking - 1) * 0.2;
			}elseif($ranking <= 10){
				$rate = 0.4;
			}
			if($registCount < 1000){
				return 1000/10 * $rate;
			}elseif($registCount > 5000){
				return 5000/10 * $rate;
			}else{
				return $registCount/10 * $rate;
			}
		}else{
			$aReturnData = array();
			if($registCount < 1000){
				$aReturnData[1] = 1000/10;
				$aReturnData[2] = 1000/10 * 0.8;
				$aReturnData[3] = 1000/10 * 0.6;
				$aReturnData[4] = 1000/10 * 0.4;
				$aReturnData[-1] = 1000/10 * 0.2;
			}elseif($registCount > 5000){
				$aReturnData[1] = 5000/10;
				$aReturnData[2] = 5000/10 * 0.8;
				$aReturnData[3] = 5000/10 * 0.6;
				$aReturnData[4] = 5000/10 * 0.4;
				$aReturnData[-1] = 5000/10 * 0.2;
			}else{
				$aReturnData[1] = $registCount/10;
				$aReturnData[2] = $registCount/10 * 0.8;
				$aReturnData[3] = $registCount/10 * 0.6;
				$aReturnData[4] = $registCount/10 * 0.4;
				$aReturnData[-1] = $registCount/10 * 0.2;
			}
			return $aReturnData;
		}
	}


	public function getUserMatchStatisticsList($userId){
		$expireTime = $this->_getAwardExpireTime();
		$oMatch = new Model(T_MATCH);
		$aAwardMatchList = $oMatch->get('`id`', '`match_end_time`<' . time() . ' AND `match_end_time`>' . $expireTime);
		if($aAwardMatchList === false){
			return false;
		}elseif(!$aAwardMatchList){
			$prizeMatchs = 0;
		}else{
			$aAwardMatchIds = array();
			foreach($aAwardMatchList as $aAwardMatch){
				$aAwardMatchIds[] = $aAwardMatch['id'];
			}
			//获奖场次,未领取
			$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
			$prizeMatchs = $oMatchUserRelation->count('`user_id`=' . $userId . ' AND `prize_status`=1' . ' AND `match_id` in (' . implode(',', $aAwardMatchIds) . ')');
			if($prizeMatchs === false){
				return false;
			}
		}
		/*$aRejoinMatchList = array();	//可以再次参赛的列表
		$onMatchingCount = 0;	//还没有参赛的场次
		$currentTime = time();
		$oMatch = new Model(T_MATCH);
		//目前进行中的比赛
		$aOnMatchingList = $oMatch->get('`id`,`duration`,`name`', '`match_start_time`<=' . $currentTime . ' AND `match_end_time`>' . $currentTime);
		if($aOnMatchingList === false){
			return false;
		}elseif($aOnMatchingList){
			$aOnMatchingReferList = array();
			$aMatchIds = array();
			foreach($aOnMatchingList as $aOnMatching){
				$aMatchIds[] = $aOnMatching['id'];
				$aOnMatchingReferList[$aOnMatching['id']] = $aOnMatching;
			}
			unset($aOnMatchingList);
			$matchIds = implode(',', $aMatchIds);
			//用户在进行中报名的比赛
			$aUserMatchList = $oMatchUserRelation->get('`match_id`,`start_time`,`end_time`,`best_score`,`first_join_time`', '`user_id`=' . $userId . ' AND `match_id` in (' . $matchIds . ')');
			if($aUserMatchList === false){
				return false;
			}elseif($aUserMatchList){
				foreach($aUserMatchList as $aUserMatch){
					if($aUserMatch['first_join_time'] == 0){	//还没有进入比赛
						$onMatchingCount++;
					}elseif($aUserMatch['end_time'] > 0 || ($aUserMatch['start_time'] > 0 && $aUserMatch['end_time'] == 0 && $aUserMatch['start_time'] + $aOnMatchingReferList[$aUserMatch['match_id']]['duration'] * 60 < $currentTime)){	//本次已经完成了
						$ranking = $this->getMatchRanking($aUserMatch['match_id'], $aUserMatch['best_score']);	//取得本场比赛的排名
						if($ranking === false){
							return false;
						}
						$aTemp = array();
						$aTemp['match_id'] = $aUserMatch['match_id'];
						$aTemp['match_name'] = $aOnMatchingReferList[$aUserMatch['match_id']]['name'];
						$aTemp['ranking'] = $ranking;
						$aRejoinMatchList[] = $aTemp;
					}else{
						//比赛中的
					}
				}
			}
		}

		$waitRegister = 0;
		//进行中的比赛
		$aRegisteringList = $oMatch->get('`id`', '`match_start_time`<' . $currentTime . ' AND `match_end_time`>' . $currentTime . ' AND `is_release`=1');
		if($aRegisteringList === false){
			return false;
		}elseif($aRegisteringList){
			$aRegisterMatchs = array();
			foreach($aRegisteringList as $aRegistering){
				$aRegisterMatchs[] = $aRegistering['id'];
			}
			//我报名了多少场
			//$registerCount = $oMatchUserRelation->count('`user_id`=' . $userId . ' AND `match_id` in (' . implode(',', $aRegisterMatchs) . ')');
			$waitRegister = count($aRegisterMatchs); //- $registerCount;
		}*/
		return array(
			'prize_count'	=>	$prizeMatchs,
			//'wait_join_count'		=>	$onMatchingCount,
			//'finish_list'	=>	$aRejoinMatchList,
			//'registering_count'	=>	$waitRegister,
		);
	}

	//报名的赛事场数
	public function getUserRegisterMatchCount($userId, $startTime = 0, $endTime = 0){
		$timeCondition = '';
		if($startTime){
			$timeCondition .= ' AND `create_time`>=' . $startTime;
		}
		if($endTime){
			$timeCondition .= ' AND `create_time`<=' . $endTime;
		}
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->count('`user_id`=' . $userId . $timeCondition);
	}

	//获奖的赛事场数
	public function getUserWinPrizeCount($userId, $startTime = 0, $endTime = 0){
		$timeCondition = '';
		if($startTime){
			$timeCondition .= ' AND `create_time`>=' . $startTime;
		}
		if($endTime){
			$timeCondition .= ' AND `create_time`<=' . $endTime;
		}
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		return $oMatchUserRelation->count('`user_id`=' . $userId . ' AND `prize_status`>0' . $timeCondition);
	}

	//推荐的比赛
	public function getRecommendMacthList($userId, $length = 4, $exceptMatchId = 0){
		//我当前的年级
		$oClass = new Model(T_USER_CLASS);
		$aUserGrade = $oClass->get('grade', '`user_id`=' . $userId . ' AND `is_active`=1');
		if(!$aUserGrade){
			return false;
		}
		//我的用户类型
		$oUser = new Model(T_USER);
		$aUser = $oUser->get('', ['id' => $userId]);
		if(!$aUser){
			return false;
		}
		$aUser = $aUser[0];
		//我参加过的比赛
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('`match_id`', '`user_id`=' . $userId);
		if($aMatchUserRelationList === false){
			return false;
		}
		$aUserJoinMatchIds = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aUserJoinMatchIds[] = $aMatchUserRelation['match_id'];
		}
		//当前进行中的比赛
		$currentTime = time();
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`name`,`description`,`profile`,`grade_id`,`subject_id`', '`match_start_time`<=' . $currentTime . ' AND `match_end_time`>' . $currentTime . '-`duration` AND `is_release`=1 AND `id`!=' . $exceptMatchId . " AND FIND_IN_SET(" . $aUser['xxt_type'] . ', limit_xxt_type)');
		if(!$aMatchList){
			return $aMatchList;
		}
		$aCurrentGradeAndNotJoin = array();	//我当前年级没参加的
		$aNotJoin = array();	//我没参加的
		$aCurrentGrade = array();	//同年级的
		$aOthers = array();			//剩下的
		foreach($aMatchList as $aMatch){
			if($aMatch['grade_id'] == $aUserGrade[0]['grade'] && !in_array($aMatch['id'], $aUserJoinMatchIds)){
				$aCurrentGradeAndNotJoin[] = $aMatch;
			}elseif(!in_array($aMatch['id'], $aUserJoinMatchIds)){
				$aNotJoin[] = $aMatch;
			}elseif($aMatch['grade_id'] == $aUserGrade[0]['grade']){
				$aCurrentGrade[] = $aMatch;
			}else{
				$aOthers[] = $aMatch;
			}
		}
		$aRecommmendMatchList = array();
		$currentLength = 0;
		if($aCurrentGradeAndNotJoin){
			$aRecommmendMatchList = array_slice($aCurrentGradeAndNotJoin, 0, $length);
			$currentLength = count($aRecommmendMatchList);
			if($currentLength >= $length){
				return $aRecommmendMatchList;
			}
		}
		if($aNotJoin){
			$aNotJoinMatch = array_slice($aNotJoin, 0, $length - $currentLength);
			$aRecommmendMatchList = array_merge($aRecommmendMatchList, $aNotJoinMatch);
			$currentLength = count($aRecommmendMatchList);
			if($currentLength >= $length){
				return $aRecommmendMatchList;
			}
		}
		if($aCurrentGrade){
			$aCurrentGradeMatch = array_slice($aCurrentGrade, 0, $length - $currentLength);
			$aRecommmendMatchList = array_merge($aRecommmendMatchList, $aCurrentGradeMatch);
			$currentLength = count($aRecommmendMatchList);
			if($currentLength >= $length){
				return $aRecommmendMatchList;
			}
		}
		if(count($aOthers) > $length - $currentLength){
			$aRandKeys = array_rand($aOthers, $length - $currentLength);
			if(is_array($aRandKeys)){
				foreach($aRandKeys as $key){
					$aRecommmendMatchList[] = $aOthers[$key];
				}
			}else{
				$aRecommmendMatchList[] = $aOthers[$aRandKeys];
			}
		}else{
			$aRecommmendMatchList = array_merge($aRecommmendMatchList, $aOthers);
		}
		return $aRecommmendMatchList;
	}

	private function _parseMatch($aMatchList, $isFromCustomer = false){
		$now = time();
		foreach($aMatchList as &$aMatch){
			if($aMatch['limit_grades']){
				$aMatch['limit_grades'] = explode(',', $aMatch['limit_grades']);
			}
			if($aMatch['limit_xxt_type'] != ''){
				$aMatch['limit_xxt_type'] = explode(',', $aMatch['limit_xxt_type']);
			}else{
				$aMatch['limit_xxt_type'] = array();
			}
			if($aMatch['es_category_rule']){
				if($aMatch['is_big_match']){
					$aMatch['es_category_rule'] = json_decode($aMatch['es_category_rule'], true);
				}else{
					$aMatch['es_category_rule'] = explode(',', $aMatch['es_category_rule']);
				}
			}else{
				$aMatch['es_category_rule'] = [];
			}

			$aMatch['es_rule'] = json_decode($aMatch['es_rule'], true);
			$aMatch['awards'] = json_decode($aMatch['awards'], true);
			if(isset($aMatch['awards']['rand']['ranking_rate'])){
				$aMatch['awards']['rand']['ranking_rate'] = explode(',', $aMatch['awards']['rand']['ranking_rate']);
			}
			$aMatch['winners'] = json_decode($aMatch['winners'], true);
			if($aMatch['is_release'] == 0){
				$aMatch['status'] = $this->aStatus['not_released'];
			}elseif($aMatch['match_start_time'] > $now){
				$aMatch['status'] = $this->aStatus['wait_match'];
				$aMatch['registration_user_nums'] = $this->getRegistrationCountByMatchId($aMatch['id']);
			}elseif($aMatch['match_end_time'] > $now){
				$aMatch['status'] = $this->aStatus['matching'];
				$aMatch['match_user_nums'] = $this->getAttendMatchCountByMatchId($aMatch['id']);
			}elseif($aMatch['match_end_time'] < $now){
				$aMatch['status'] = $this->aStatus['end_match'];
				$aMatch['match_user_nums'] = $this->getAttendMatchCountByMatchId($aMatch['id']);
			}
		}
		return $aMatchList;
	}

	private function _parseMatchBeforToDB($aData, $isInsert = false){
		if(isset($aData['limit_grades']) && $aData['limit_grades']){
			$aData['limit_grades'] = implode(',', $aData['limit_grades']);
		}
		if(isset($aData['limit_xxt_type']) && $aData['limit_xxt_type']){
			$aData['limit_xxt_type'] = implode(',', $aData['limit_xxt_type']);
		}
		if(isset($aData['es_category_ids']) && $aData['es_category_ids']){
			$aData['es_category_ids'] = implode(',', $aData['es_category_ids']);
		}
		if(isset($aData['es_set'])){
			foreach($aData['es_set'] as &$aEsIds){
				if($aEsIds){
					$aEsIds = implode(',', $aEsIds);
				}
			}
		}
		if(isset($aData['awards']['rand']['ranking_rate'])){
			$aData['awards']['rand']['ranking_rate'] = implode(',', $aData['awards']['rand']['ranking_rate']);
		}
		$aIndexArray = array('es_set', 'es_rule', 'awards', 'winners');
		foreach($aIndexArray as $aIndex){
			if(isset($aData[$aIndex])){
				$aData[$aIndex] = json_encode($aData[$aIndex]);
			}elseif($isInsert){
				$aData[$aIndex] = json_encode(array());
			}
		}
		return $aData;
	}

	private function _parseWhereForGetMatchList($aCondition, $isFromCustomer){
		$where = '';
		if(isset($aCondition['status'])){
			if($aCondition['status'] == $this->aStatus['not_released']){
				$where = '`is_release`=0';
			}elseif($aCondition['status'] == $this->aStatus['released']){
				$where = '`is_release`=1';
			}else{
				$where = '`is_release`=1';
				$now = time();
				if($aCondition['status'] == $this->aStatus['wait_registration']){
					$where .= ' AND `registration_start_time`>' . $now;
				}elseif($aCondition['status'] == $this->aStatus['registrationing']){
					$where .= ' AND `registration_start_time`<' . $now . ' AND `registration_end_time`>' . $now;
				}elseif($aCondition['status'] == $this->aStatus['wait_match']){
					$where .= ' AND `match_start_time`>' . $now;
				}elseif($aCondition['status'] == $this->aStatus['matching']){
					$where .= ' AND `match_start_time`<' . $now . ' AND `match_end_time`>' . $now;
				}elseif($aCondition['status'] == $this->aStatus['end_match']){
					$where .= ' AND `match_end_time`<' . $now;
				}elseif($aCondition['status'] == $this->aStatus['not_over']){
					$where .= ' AND `match_end_time`>' . $now;
				}
			}
		}
		if(isset($aCondition['grade'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= 'FIND_IN_SET(' . $aCondition['grade'] . ', `limit_grades`)';
		}
		if(isset($aCondition['level'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`limit_level`=' . $aCondition['level'];
		}
		if(isset($aCondition['time_type'])){
			if($where){
				$where .= ' AND ';
			}
			if($aCondition['time_type'] == $this->aTimeType['registration_start_time']){
				$where .= '`registration_start_time`>=' . $aCondition['time_rate_start'] . ' AND `registration_start_time`<=' . $aCondition['time_rate_end'];
			}elseif($aCondition['time_type'] == $this->aTimeType['registration_end_time']){
				$where .= '`registration_end_time`>=' . $aCondition['time_rate_start'] . ' AND `registration_end_time`<=' . $aCondition['time_rate_end'];
			}elseif($aCondition['time_type'] == $this->aTimeType['match_start_time']){
				$where .= '`match_start_time`>=' . $aCondition['time_rate_start'] . ' AND `match_start_time`<=' . $aCondition['time_rate_end'];
			}elseif($aCondition['time_type'] == $this->aTimeType['match_start_time']){
				$where .= '`match_start_time`>=' . $aCondition['time_rate_start'] . ' AND `match_start_time`<=' . $aCondition['time_rate_end'];
			}
		}
		if(isset($aCondition['fee'])){
			if($where){
				$where .= ' AND ';
			}
			if($aCondition['fee']){
				$where .= '`registration_fee`>0';
			}else{
				$where .= '`registration_fee`=0';
			}
		}
		if(!isset($aCondition['status']) && $isFromCustomer){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_release`=1';
		}
		if(isset($aCondition['name'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= "`name`='" . $aCondition['name'] . "'";
		}
		if(isset($aCondition['grade_id'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= "`grade_id`=" . $aCondition['grade_id'];
		}
		if(isset($aCondition['subject_id'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= "`subject_id`=" . $aCondition['subject_id'];
		}

		if(isset($aCondition['limit_xxt'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= "`limit_xxt`=" . $aCondition['limit_xxt'];
		}
		
		if(isset($aCondition['is_activity_match'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= "`is_activity_match`=" . $aCondition['is_activity_match'];
		}
		
		if(isset($aCondition['xxt_type'])){
			if($where){
				$where .= ' AND ';
			}
			$where .= "(`limit_xxt_type`='' OR FIND_IN_SET(" . $aCondition['xxt_type'] . ', limit_xxt_type))';
		}
		return $where;
	}

	private function _mergeMatchListANDMatchUserRelationList($aMatchList, $aMatchUserRelationList){
		foreach($aMatchList as &$aMatch){
			$aMatch['match_user_relation'] = array();
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				if($aMatchUserRelation['match_id'] == $aMatch['id']){
					$aMatch['match_user_relation'] = $aMatchUserRelation;
					break;
				}
			}
			if($aMatch['match_user_relation']){
				$aMatch['match_user_relation']['remainder_es_ids'] = json_decode($aMatch['match_user_relation']['remainder_es_ids'], true);
			}
		}
		return $aMatchList;
	}

	private function _mergeMatchListANDMatchUserRelationListNew($aMatchList, $aMatchUserRelationList){
		$aReturnList = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aTemp = array();
			foreach($aMatchList as $aMatch){
				if($aMatch['id'] == $aMatchUserRelation['match_id']){
					if(isset($aMatch['winners'])){
						$aMatch['winners'] = json_decode($aMatch['winners'], true);
					}
					$aTemp = $aMatch;
					break;
				}
			}
			$aTemp['match_user_relation'] = $aMatchUserRelation;
			$aTemp['match_user_relation']['remainder_es_ids'] = json_decode($aTemp['match_user_relation']['remainder_es_ids'], true);
			$aReturnList[] = $aTemp;
		}
		return $aReturnList;
	}

	private function _getUserListByIds($aUserIds, $getXxtId = 0){
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
		if(!$aPersonalList || !$getXxtId){
			return $aPersonalList;
		}
		$oUser = new Model(T_USER);
		$aUserList = $oUser->get('`id`,`xxt_id`', array('id' => array('in', $aUserIds)));
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aPersonalList as &$aPersonal){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPersonal['id']){
					$aPersonal['xxt_id'] = $aUser['xxt_id'];
				}
			}
		}
		return $aPersonalList;
	}

	public function _getAwardExpireTime(){
		$expireDays = 7;
		if(isset($GLOBALS['MATCH_AWARD'])){
			$expireDays = $GLOBALS['MATCH_AWARD'];
		}
		return time() - $expireDays * 24 * 3600;
	}

	public function getUserMatchRelationList($matchId, $aUserIds){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('`user_id`,`address`', '`match_id`=' . $matchId . ' and user_id in (' . implode(',', $aUserIds) . ')');
		foreach($aMatchUserRelationList as $key => $aMatchUserRelation){
			if($aMatchUserRelation['address']){
				$aMatchUserRelationList[$key]['address'] = json_decode($aMatchUserRelation['address'], true);
			}else{
				$aMatchUserRelationList[$key]['address'] = array();
			}
		}
		return $aMatchUserRelationList;
	}
}