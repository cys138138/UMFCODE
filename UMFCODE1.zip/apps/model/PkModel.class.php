<?php
/**
 *题目对象模型
 */
class PkModel{
	const OFFICIAL_ES_STATU = 5;
	const RECEIVE_PK_MESSAGE_TYPE = 30;	//收到PK的通知类型
	const RESTORE_ACHIVEMENT_GOLD_MESSAGE_TYPE = 31;	//返还赌注的通知类型
	const PK_RESULT_EVENT_TYPE = 13;	//PK结果的动态
	const PK_FAILED_DURATION = 30;		//统计PK失败的时间维度
	const OTHER_SUBJECT = 4;	//其他科目
	/*获取用户的赛事列表
	 * $aCondition = array
	 (
		'send_method'		=>	0:全部，1：我发起的，2：我收到的
		'pk_status'			=>	0:全部，1：等待PK，2：等待PK结果，3：已结束
		'win_status'			=>	0:全部，1：获胜，2：失败
		'is_receive_prize'		=>	-1:全部，1：已领取，0：未领取
	 )
	 */
	public function getUserPkList($userId, $aCondition, $page = 1, $pageSize = 10, $order = '`id` desc'){
		$where = '(`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId .')';
		$currentTime = time();
		if(isset($aCondition['pk_status']) && $aCondition['pk_status']){
			if($aCondition['pk_status'] == 1){
				$where = '`winner_user_id`=0 AND ((`sender_user_id`=' . $userId . ' AND (`sender_user_start_time`=0 OR (`sender_user_end_time`=0 AND `sender_user_start_time`+`duration`*60>' . $currentTime . '))) OR (`receiver_user_id`=' . $userId . ' AND (`receiver_user_start_time`=0 OR (`receiver_user_end_time`=0 AND `receiver_user_start_time`+`duration`*60>' . $currentTime . '))))';
			}elseif($aCondition['pk_status'] == 2){
				$where = '`winner_user_id`=0 AND ((`sender_user_id`=' . $userId . ' AND `sender_user_end_time`>0) OR (`receiver_user_id`=' . $userId . ' AND `receiver_user_end_time`>0))';
			}elseif($aCondition['pk_status'] == 3){
				$where = '`winner_user_id`>0 AND (`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId .')';
			}
		}
		if(isset($aCondition['send_method']) && $aCondition['send_method']){
			if($aCondition['send_method'] == 1){
				$where = '`sender_user_id`=' . $userId;
				if(isset($aCondition['pk_status']) && $aCondition['pk_status']){
					if($aCondition['pk_status'] == 1){
						$where = '`winner_user_id`=0 AND (`sender_user_id`=' . $userId . ' AND (`sender_user_start_time`=0 OR (`sender_user_end_time`=0 AND `sender_user_start_time`+`duration`*60>' . $currentTime . ')))';
					}elseif($aCondition['pk_status'] == 2){
						$where = '`winner_user_id`=0 AND `sender_user_id`=' . $userId . ' AND `sender_user_end_time`>0';
					}elseif($aCondition['pk_status'] == 3){
						$where = '`winner_user_id`>0 AND `sender_user_id`=' . $userId;
					}
				}
			}elseif($aCondition['send_method'] == 2){
				$where = '`receiver_user_id`=' . $userId;
				if(isset($aCondition['pk_status']) && $aCondition['pk_status']){
					if($aCondition['pk_status'] == 1){
						$where = '`winner_user_id`=0 AND `receiver_user_id`=' . $userId . ' AND (`receiver_user_start_time`=0 OR (`receiver_user_end_time`=0 AND `receiver_user_start_time`+`duration`*60>' . $currentTime . '))';
					}elseif($aCondition['pk_status'] == 2){
						$where = '`winner_user_id`=0 AND `receiver_user_id`=' . $userId . ' AND `receiver_user_end_time`>0';
					}elseif($aCondition['pk_status'] == 3){
						$where = '`winner_user_id`>0 AND `receiver_user_id`=' . $userId;
					}
				}
			}
		}

		if(isset($aCondition['win_status']) && $aCondition['win_status']){
			if($aCondition['win_status'] == 1){
				$where .= ' AND `winner_user_id`=' . $userId;
			}elseif($aCondition['win_status'] == 2){
				if(strpos($where, '`winner_user_id`>0') === false){
					$where .= ' AND `winner_user_id`>0 AND `winner_user_id`!=' . $userId;
				}else{
					$where .= ' AND `winner_user_id`!=' . $userId;
				}
			}
		}

		if(isset($aCondition['is_receive_prize']) && $aCondition['is_receive_prize'] != -1){
			$where .= ' AND `winner_user_id`=' . $userId . ' AND `is_receive_prize`=' . $aCondition['is_receive_prize'];
		}
		$where .= ' AND `delete_user_id`!=' . $userId . ' AND `delete_user_id`!=1';
		$offect = ($page - 1) * $pageSize;
		$oPk = new Model(T_PK_INDEX);
		$aPkList = $oPk->get('', $where, $order, $offect, $pageSize);
		if($aPkList){
			$aUserIds = array();
			$aMissionIds = array();
			foreach($aPkList as $aPk){
				$aUserIds[] = $aPk['sender_user_id'];
				$aUserIds[] = $aPk['receiver_user_id'];
				$aMissionIds[] = $aPk['mission_id'];
			}
			$aUserList = $this->_getUserListByIds($aUserIds);
			$oMission = new Model(T_MISSION);
			$aMissionList = $oMission->get('`id`,`name`', array('id' => array('in', $aMissionIds)));
			foreach($aPkList as &$aPk){
				foreach($aUserList as $aUser){
					if($aPk['sender_user_id'] == $aUser['id']){
						$aPk['sender_user_info'] = $aUser;
					}elseif($aPk['receiver_user_id'] == $aUser['id']){
						$aPk['receiver_user_info'] = $aUser;
					}
				}
				foreach($aMissionList as $aMission){
					if($aPk['mission_id'] == $aMission['id']){
						$aPk['mission_name'] = $aMission['name'];
						break;
					}
				}
			}
		}
		return $aPkList;
	}

	//发起PK
	public function addPk($aData, $sendFee = 0){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$content = $aData['content'];
		unset($aData['content']);
		$pkId = $oDboi->table(T_PK_INDEX)->data($aData)->insert();
		if($pkId){
			$aPkData = array();
			$aPkData['id'] = $pkId;
			$aPkData['content'] = json_encode($content);
			$row = $oDboi->table(T_PK)->data($aPkData)->insert();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}
			//扣除发起PK和筹码的费用
			$payGold = $sendFee + $aData['attachment_gold'];	//应扣费用
			if($payGold){
				/*$result = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aData['sender_user_id']))->data(array('gold' => array('sub', $payGold)))->update();
				if(!$result){
					$oDboi->rollBack();
					return false;
				}*/
				$mStudent = \common\model\Student::findOne($aData['sender_user_id']);
				$mStudent->deductCurrency($payGold, \common\model\UserNumerical::USE_CURRENCY_SCENE_PK_ATTACHMENT);
			}
			//给被挑战的人发通知
			$aPersonalMessage = array();
			$aPersonalMessage['user_id'] = $aData['receiver_user_id'];
			$aPersonalMessage['type'] = self::RECEIVE_PK_MESSAGE_TYPE;
			$aPersonalMessage['data_id'] = $pkId;
			$result = $oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessage)->insert();
			$oPersonal = new Model(T_PERSONAL);
			$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>$aPersonalMessage['user_id']));
		}
		return $pkId;
	}

	//得到最近发起PK的人
	public function getNearestPkUserList($userId, $page, $pageSize, $aUserIds = array(), $missionId = 0){
		$offect = ($page - 1) * $pageSize;
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '';
		if($aUserIds){
			$where = '`sender_user_id` in (' . implode(',', $aUserIds) . ')';
		}else{
			$where = '`sender_user_id`!=' . $userId;
		}
		if($missionId){
			$where .= ' AND `mission_id`=' . $missionId;
		}
		$aPkIndexList = $oPkIndex->get('distinct `sender_user_id`', $where, '`create_time` DESC', $offect, $pageSize);
		if(!$aPkIndexList){
			return $aPkIndexList;
		}
		$aUserIds = array();
		foreach($aPkIndexList as $aPkIndex){
			$aUserIds[] = $aPkIndex['sender_user_id'];
		}
		return $this->getUserPkCountListByUserIds($aUserIds);
	}

	//得到PK索引表信息
	public function getPkIndexInfoById($pkId){
		$oPkIndex = new Model(T_PK_INDEX);
		$aPkIndexInfo = $oPkIndex->get('', array('id' => $pkId));
		if($aPkIndexInfo){
			$aPkIndexInfo = $aPkIndexInfo[0];
		}
		return $aPkIndexInfo;
	}

	//得到PK题目信息
	public function getPkInfoById($pkId){
		$oPk = new Model(T_PK);
		$aPkInfo = $oPk->get('', array('id' => $pkId));
		if($aPkInfo){
			$aPkInfo = $aPkInfo[0];
			$aPkInfo['content'] = json_decode($aPkInfo['content'], true);
		}
		return $aPkInfo;
	}

	//得到PK详细信息
	public function getDetailPkInfo($pkId){
		$aPkIndexInfo = $this->getPkIndexInfoById($pkId);
		if($aPkIndexInfo){
			$aPkInfo = $this->getPkInfoById($pkId);
			if(!$aPkInfo){
				return $aPkInfo;
			}
			$aPkIndexInfo['content'] = $aPkInfo['content'];
		}
		return $aPkIndexInfo;
	}

	//更新PK信息
	public function setPk($aData){
		$aPkIndexFields = array('receiver_user_id', 'sender_user_start_time', 'sender_user_end_time', 'sender_score', 'receiver_user_start_time', 'receiver_user_end_time', 'receiver_score', 'is_receive_attachment', 'winner_user_id', 'is_receive_prize', 'delete_user_id');
		$aPkIndexData = array();
		foreach($aPkIndexFields as $Field){
			if(isset($aData[$Field])){
				$aPkIndexData[$Field] = $aData[$Field];
			}
		}
		$aPkData = array();
		if(isset($aData['content'])){
			$aPkData['content'] = json_encode($aData['content']);
		}
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result1 = $result2 = false;
		if($aPkIndexData){
			$result1 = $oDboi->table(T_PK_INDEX)->where(array('id' => $aData['id']))->data($aPkIndexData)->update();
			if($result1 === false){
				return false;
			}
		}
		if($aPkData){
			$result2 = $oDboi->table(T_PK)->where(array('id' => $aData['id']))->data($aPkData)->update();
			if($result1 && $result2 === false){
				$oDboi->rollBack();
				return false;
			}elseif($result2 === false){
				return false;
			}
		}
		if($result1 || $result2){
			return 1;
		}else{
			return 0;
		}
	}

	//是否接受筹码的处理
	public function setIsReceiveAttachment($aPkInfo){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$reuslt = $oDboi->table(T_PK_INDEX)->where(array('id' => $aPkInfo['id']))->data(array('is_receive_attachment' => $aPkInfo['is_receive_attachment']))->update();
		if($aPkInfo['attachment_gold']){
			if($reuslt && $aPkInfo['is_receive_attachment'] == 1){	//接受筹码，扣除被挑战人的筹码
				/*$row = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aPkInfo['receiver_user_id']))->data(array('gold' => array('sub', $aPkInfo['attachment_gold'])))->update();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}*/
				$mStudent = \common\model\Student::findOne($aPkInfo['receiver_user_id']);
				$mStudent->deductCurrency($aPkInfo['attachment_gold'], \common\model\UserNumerical::USE_CURRENCY_SCENE_PK_ATTACHMENT);
			}elseif($reuslt && $aPkInfo['is_receive_attachment'] == 0){	//拒绝加筹码,给发起人返还筹码
				/*$row = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aPkInfo['sender_user_id']))->data(array('gold' => array('add', $aPkInfo['attachment_gold'])))->update();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}*/
				$mStudent = \common\model\Student::findOne($aPkInfo['sender_user_id']);
				$mStudent->addCurrency($aPkInfo['attachment_gold'], \common\model\UserNumerical::CURRENCY_SCENE_PK_RESTORE, false);
				//给发起人写通知
				$aPersonalMessageData = array();
				$aPersonalMessageData['user_id'] = $aPkInfo['sender_user_id'];
				$aPersonalMessageData['type'] = self::RESTORE_ACHIVEMENT_GOLD_MESSAGE_TYPE;
				$aPersonalMessageData['data_id'] = $aPkInfo['id'];
				$personalMessageId = $oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessageData)->insert();
				if(!$personalMessageId){
					$oDboi->rollBack();
					return false;
				}
				$oPersonal = new Model(T_PERSONAL);
				$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>$aPersonalMessageData['user_id']));
			}
		}
		return $reuslt;
	}

	//根据pk的人得到通过的共同关卡
	public function getMissionListByPkUser($userId, $pkUserId){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserPassMissionIdList = $oMissionUserRelationIndex->get('distinct `mission_id`', '`user_id`=' . $userId . ' AND `is_pass`=1');
		if($aUserPassMissionIdList === false){
			return false;
		}
		$aUserPassMissionIds = array();
		foreach($aUserPassMissionIdList as $aUserPassMission){
			$aUserPassMissionIds[] = $aUserPassMission['mission_id'];
		}
		$aPkUserPassMissionIdList = $oMissionUserRelationIndex->get('distinct `mission_id`', '`user_id`=' . $pkUserId . ' AND `is_pass`=1');
		if($aPkUserPassMissionIdList === false){
			return false;
		}
		$aPkUserPassMissionIds = array();
		foreach($aPkUserPassMissionIdList as $aPkUserPassMission){
			$aPkUserPassMissionIds[] = $aPkUserPassMission['mission_id'];
		}
		$aMissionIds = array_intersect($aPkUserPassMissionIds, $aUserPassMissionIds);
		//查出共同关卡
		$oMission = new Model(T_MISSION);
		if($aMissionIds){
			$aMissionList = $oMission->get('`id`,`name`,`subject_id`,`grade`', array('id' => array('in', $aMissionIds)));
			if($aMissionList === false){
				return false;
			}
		}else{
			$aMissionList = array();
		}
		//查出其他科目关卡
		$aOtherMissionList = $oMission->get('`id`,`name`,`subject_id`,`grade`', '`subject_id`=4 AND `is_forbidden`!=1');
		if($aOtherMissionList === false){
			return false;
		}
		foreach($aOtherMissionList as $aOtherMission){
			if(!in_array($aOtherMission['id'], $aMissionIds)){
				$aMissionList[] = $aOtherMission;
			}
		}
		//初始化
		$aSubjectMissionList = array();
		foreach($GLOBALS['SUBJECT'] as $subjectId => $subjectName){
			$aSubjectMissionList[$subjectId] = array();
		}
		//转换关卡名
		$aMissionList = Mission::convertMissionList($aMissionList);
		foreach($aMissionList as $aMission){
			$aSubjectMissionList[$aMission['subject_id']][] = $aMission;
		}
		return $aSubjectMissionList;
	}

	//根据关卡得到过了同一关卡的用户列表
	public function getUserListByPkMission($userId, $pkMissionId, $page, $pageSize, $aInUserIds = array()){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$offect = ($page - 1) * $pageSize;
		if($aInUserIds){
			$where = '`mission_id`=' . $pkMissionId . ' AND `is_pass`=1 AND `user_id` in (' . implode(',', $aInUserIds) . ')';
		}else{
			$where = '`mission_id`=' . $pkMissionId . ' AND `is_pass`=1 AND `user_id`!=' . $userId;
		}
		$aPassMissionUserIdList = $oMissionUserRelationIndex->get('distinct `user_id`', $where, '`pass_time` DESC', $offect, $pageSize);
		if(!$aPassMissionUserIdList){
			return $aPassMissionUserIdList;
		}
		$aUserIds = array();
		foreach($aPassMissionUserIdList as $aPassMissionUserId){
			$aUserIds[] = $aPassMissionUserId['user_id'];
		}
		return $this->getUserPkCountListByUserIds($aUserIds);
	}

	//关卡PK统计的用户列表
	public function getUserListByMissionId($userId, $missionId, $page, $pageSize, $aInUserIds = array(), $aExceptUserIds = array()){
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$offect = ($page - 1) * $pageSize;
		$where = '`mission_id`=' . $missionId . ' AND `is_pass`=1 AND `user_id`!=' . $userId;
		if($aInUserIds){
			$where .= ' AND `user_id` in (' . implode(',', $aInUserIds) . ')';
		}
		if($aExceptUserIds){
			$where .= ' AND `user_id` not in (' . implode(',', $aExceptUserIds) . ')';
		}
		$aPassMissionUserIdList = $oMissionUserRelationIndex->get('`user_id`,`score`', $where, '`score` DESC', $offect, $pageSize);
		if(!$aPassMissionUserIdList){
			return $aPassMissionUserIdList;
		}
		$aUserIds = array();
		foreach($aPassMissionUserIdList as $aPassMissionUserId){
			$aUserIds[] = $aPassMissionUserId['user_id'];
		}
		$aUserList =  $this->getUserPkCountListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aUserList as &$aUser){
			foreach($aPassMissionUserIdList as $aPassMissionUser){
				if($aPassMissionUser['user_id'] == $aUser['id']){
					$aUser['score'] = $aPassMissionUser['score'];
				}
			}
		}
		return $aUserList;
	}

	//根据用户ids得到用户信息和PK次数及胜率------时间条件只对单个用户id有效
	public function getUserPkCountListByUserIds($aUserIds, $startTime = 0, $endTime = 0){
		$aUserList = $this->_getUserListByIds($aUserIds, true);
		return $this->_getUserPkStatisticByUserList($aUserList, $startTime, $endTime);
	}

	//得到用户今天的PK次数	$pkType 0:所有的、1：发起的、2收到的
	public function getUserTodayPkCount($userId, $pkType = 0){
		if($pkType == 1){
			$where = '`sender_user_id`=' . $userId;
		}elseif($pkType == 2){
			$where = '`receiver_user_id`=' . $userId;
		}else{
			$where = '(`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ')';
		}
		$beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
		$where .= ' AND `create_time`>' . $beginToday;
		$oPkIndex = new Model(T_PK_INDEX);
		return $oPkIndex->count($where);
	}

	//领取PK奖励
	public function receivePrize($aPkInfo){
		$oDboi = new DBOI();
		//修改领取状态
		$result = $oDboi->table(T_PK_INDEX)->where(array('id' => $aPkInfo['id']))->data(array('is_receive_prize' => 1))->update();
		/*if($result){
			$aUserNumerical = array();
			//给予获胜人积分奖励
			$aUserNumerical['accumulate_points'] = array('add', self::AWARD_ACCUMULATE_POINTS);
			//赢取的金币
			if($aPkInfo['is_receive_attachment'] == 1 && $aPkInfo['attachment_gold']){
				$aUserNumerical['gold'] = array('add', $aPkInfo['attachment_gold'] * 2);
			}
			$row = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aPkInfo['winner_user_id']))->data($aUserNumerical)->update();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}
		}*/
		return $result;
	}

	//PK排名列表
	public function getPkRankingList($page, $pageSize, $aPointUserIds = array(), $missionId = 0, $startTime = 0, $endTime = 0){
		$oPkIndex = new Model(T_PK_INDEX);
		$fields = '`winner_user_id`,count(*) as `nums`';
		$where = '`winner_user_id`>0';
		if($missionId){
			$where .= ' AND `mission_id`=' . $missionId;
		}
		if($aPointUserIds){
			$where = '`winner_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		if($startTime && $endTime){
			$where .= ' AND `create_time`>=' . $startTime . ' AND `create_time`<=' . $endTime;
		}
		$order = '`nums` DESC';
		$group = '`winner_user_id`';
		$offect = ($page - 1) * $pageSize;
		$aPkRankingList = $oPkIndex->get($fields, $where, $order, $offect, $pageSize, $group);
		if(!$aPkRankingList){
			return $aPkRankingList;
		}
		$aUserIds = array();
		foreach($aPkRankingList as $aPkRanking){
			$aUserIds[] = $aPkRanking['winner_user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		$aReturnData = array();
		foreach($aPkRankingList as $aPkRanking){
			$offect += 1;
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPkRanking['winner_user_id']){
					$aUser['win_count'] = $aPkRanking['nums'];
					$aUser['rank'] = $offect;
					$aReturnData[] = $aUser;
					break;
				}
			}
		}
		return $aReturnData;
	}

	//得到用户PK记录
	public function getUserPkRecord($userId, $page, $pageSize){
		$oPkIndex = new Model(T_PK_INDEX);
		$aSenderAllCountList = $oPkIndex->get('`receiver_user_id`,count(*) as `nums`', '`sender_user_id`=' . $userId . ' AND `winner_user_id`>0', '', '', '', '`receiver_user_id`');
		if($aSenderAllCountList === false){
			return false;
		}
		$aSenderWinCountList = $oPkIndex->get('`receiver_user_id`,count(*) as `nums`', '`sender_user_id`=' . $userId . ' AND `winner_user_id`=' . $userId, '', '', '', '`receiver_user_id`');
		if($aSenderWinCountList === false){
			return false;
		}
		$aReceiverAllCountList = $oPkIndex->get('`sender_user_id`,count(*) as `nums`', '`receiver_user_id`=' . $userId . ' AND `winner_user_id`>0', '', '', '', '`sender_user_id`');
		if($aReceiverAllCountList === false){
			return false;
		}
		$aReceiverWinCountList = $oPkIndex->get('`sender_user_id`,count(*) as `nums`', '`receiver_user_id`=' . $userId . ' AND `winner_user_id`=' . $userId, '', '', '', '`sender_user_id`');
		if($aReceiverWinCountList === false){
			return false;
		}
		$aResultList = array();
		foreach($aSenderAllCountList as $aSenderAllCount){
			$aResultList[$aSenderAllCount['receiver_user_id']] = array(
				'user_id' => $aSenderAllCount['receiver_user_id'],
				'pk_count' => $aSenderAllCount['nums'],
				'win_count' => 0,
			);
		}
		foreach($aReceiverAllCountList as $aReceiverAllCount){
			if(isset($aResultList[$aReceiverAllCount['sender_user_id']])){
				$aResultList[$aReceiverAllCount['sender_user_id']]['pk_count'] += $aReceiverAllCount['nums'];
			}else{
				$aResultList[$aReceiverAllCount['sender_user_id']] = array(
					'user_id' => $aReceiverAllCount['sender_user_id'],
					'pk_count' => $aReceiverAllCount['nums'],
					'win_count' => 0,
				);
			}
		}
		$pkUserCount = count($aResultList);
		if(!$aResultList){
			return array('pk_user_count' => 0, 'user_list' => array());
		}
		foreach($aSenderWinCountList as $aSenderWinCount){
			$aResultList[$aSenderWinCount['receiver_user_id']]['win_count'] += $aSenderWinCount['nums'];
		}
		foreach($aReceiverWinCountList as $aReceiverWinCount){
			$aResultList[$aReceiverWinCount['sender_user_id']]['win_count'] += $aReceiverWinCount['nums'];
		}

		$aUserIds = array();
		$start = ($page - 1) * $pageSize;
		$end = $start + $pageSize;
		$i = 0;
		foreach($aResultList as $aResult){
			if($i >= $end){
				break;
			}elseif($i >= $start){
				$aUserIds[] = $aResult['user_id'];
			}
			$i++;
		}
		if(!$aUserIds){
			return array();
		}
		$aUserList = $this->_getUserListByIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aUserList as &$aUser){
			$aUser['pk_count'] = $aResultList[$aUser['id']]['pk_count'];
			$aUser['win_count'] = $aResultList[$aUser['id']]['win_count'];
			$aUser['loss_count'] = $aUser['pk_count'] - $aUser['win_count'];
		}
		return array('pk_user_count' => $pkUserCount, 'pk_user_list' => $aUserList);
	}

	//本关PK记录
	public function getMissionPkEventList($missionId, $page, $pageSize){
		$oDboi = new DBOI();
		$fields = '`t1`.*,`pk`.`id` as `pk_id`,`sender_user_id`,`receiver_user_id`,`sender_user_end_time`,`receiver_user_end_time`,`over_time`,`winner_user_id`';
		$where = '`t1`.`type`=' . self::PK_RESULT_EVENT_TYPE . ' AND `pk`.`mission_id`=' . $missionId;
		$offect = ($page - 1) * $pageSize;
		$aPkEventList = $oDboi->fields($fields)->table(T_SNS_EVENT)->leftjoin(T_PK_INDEX, 'as `pk` on `pk`.`id`=`t1`.`data_id`')->where($where)->orderby('`t1`.`id` desc')->limit($offect, $pageSize)->select();
		if(!$aPkEventList){
			return $aPkEventList;
		}
		$aUserIds = array();
		foreach($aPkEventList as $aPkEvent){
			$aUserIds[] = $aPkEvent['sender_user_id'];
			$aUserIds[] = $aPkEvent['receiver_user_id'];
		}
		$aUserList = $this->_getUserListByIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		$aResultList = array();
		foreach($aPkEventList as $aPkEvent){
			$aResultData = array();
			$aResultData['id'] = $aPkEvent['id'];
			$aResultData['user_id'] = $aPkEvent['user_id'];
			$aResultData['type'] = $aPkEvent['type'];
			$aResultData['data_id'] = $aPkEvent['data_id'];
			$aPkData = array();
			$aPkData['id'] = $aPkEvent['pk_id'];
			$aPkData['winner_user_id'] = $aPkEvent['winner_user_id'];
			if($aPkEvent['user_id'] == $aPkEvent['sender_user_id']){
				$aPkData['opposite_user_id'] = $aPkEvent['receiver_user_id'];
				$aPkData['is_me_sender'] = 1;
			}else{
				$aPkData['opposite_user_id'] = $aPkEvent['sender_user_id'];
				$aPkData['is_me_sender'] = 0;
			}
			if($aPkEvent['sender_user_end_time'] == 0 || $aPkEvent['receiver_user_end_time'] == 0){
				$aPkData['create_time'] = $aPkEvent['over_time'];
			}elseif($aPkEvent['sender_user_end_time'] > $aPkEvent['receiver_user_end_time']){
				$aPkData['create_time'] = $aPkEvent['sender_user_end_time'];
			}else{
				$aPkData['create_time'] = $aPkEvent['receiver_user_end_time'];
			}
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aResultData['user_id']){
					$aResultData['user_info'] = $aUser;
				}elseif($aUser['id'] == $aPkData['opposite_user_id']){
					$aPkData['opposite_user_info'] = $aUser;
				}
			}
			$aResultData['data'] = $aPkData;
			$aResultList[] = $aResultData;
		}
		return $aResultList;
	}

	//获取PK超时未判定结果的列表
	public function getOverTimePkList(){
		$oPkIndex = new Model(T_PK_INDEX);
		$currentTime = time();
		$where = '`winner_user_id`=0 AND (`over_time`<' . $currentTime . ' OR (`sender_user_end_time`>0 AND `receiver_user_start_time`>0 AND `receiver_user_end_time`=0 AND `receiver_user_start_time`+`duration`*60<' . $currentTime . ') OR (`receiver_user_end_time`>0 AND `sender_user_start_time`>0 AND `sender_user_end_time`=0 AND `sender_user_start_time`+`duration`*60<' . $currentTime . '))';
		return $oPkIndex->get('', $where);
	}

	public function getLastPkRecord($userId, $opponentUserId, $missionId){
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '`mission_id`=' . $missionId . ' AND ((`sender_user_id`=' . $userId . ' AND `receiver_user_id`=' . $opponentUserId . ') OR (`sender_user_id`=' . $opponentUserId . ' AND `receiver_user_id`=' . $userId . '))';
		$aPkIndexInfo = $oPkIndex->get('', $where, '`create_time` DESC', 0, 1);
		if($aPkIndexInfo){
			$aPkIndexInfo = $aPkIndexInfo[0];
		}
		return $aPkIndexInfo;
	}

	public function getUserPkStatisticsList($userId){
		//待领取的PK场次
		$oPkIndex = new Model(T_PK_INDEX);
		$prizeCount = $oPkIndex->count('`winner_user_id`=' . $userId . ' AND `is_receive_prize`=0');
		if($prizeCount === false){
			return false;
		}

		//今日要超时的,还没有超时的
		$beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));	//今天开始时间戳
		$endToday = mktime(0, 0, 0, date('m'), date('d')+1, date('Y'))-1;	//今天结束时间戳
		$where = '`over_time`>' . $beginToday . ' AND `over_time`<=' . $endToday . ' AND ((`sender_user_id`=' . $userId . ' AND `sender_user_start_time`=0) OR (`receiver_user_id`=' . $userId . ' AND `receiver_user_start_time`=0))';
		$beOverTimeCount = $oPkIndex->count($where);
		if($beOverTimeCount === false){
			return false;
		}

		//收到的PK未做的，和今天收到的未做的
		$where = '`winner_user_id`=0 AND `receiver_user_id`=' . $userId . ' AND `receiver_user_start_time`=0';
		$aReceivePkList = $oPkIndex->get('`create_time`', $where);
		if($aReceivePkList === false){
			return false;
		}
		$todayReceiveCount = 0;
		foreach($aReceivePkList as $aReceivePk){
			if($aReceivePk['create_time'] >= $beginToday || $aReceivePk['create_time'] <= $endToday){
				$todayReceiveCount++;
			}
		}

		//最近失败的场次
		$where = '`winner_user_id`>0 AND `winner_user_id`!=' . $userId . ' AND (`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ') AND `create_time`>' . (time() - self::PK_FAILED_DURATION * 24 * 3600) ;
		$aFailedPkList = $oPkIndex->get('`sender_user_id`,`receiver_user_id`', $where);
		if($aFailedPkList === false){
			return false;
		}
		$aUserIds = array();
		foreach($aFailedPkList as $aFailedPk){
			if($aFailedPk['sender_user_id'] == $userId){
				$aUserIds[] = $aFailedPk['receiver_user_id'];
			}else{
				$aUserIds[] = $aFailedPk['sender_user_id'];
			}
		}
		$aUserList = array();
		if($aUserIds){
			$aUserIds = array_unique($aUserIds);
			$aUserIds = array_slice($aUserIds, 0, 8);
			$aUserList = getUserListByUserIds($aUserIds);
		}
		return array(
			'win_count'				=>	$prizeCount,
			'beovertime_count'		=>	$beOverTimeCount,
			'receive_total_count'	=>	count($aReceivePkList),
			'receive_today_count'	=>	$todayReceiveCount,
			'failed_statistics'		=>	array(
				'failed_count'		=>	count($aFailedPkList),
				'user_list'			=>	$aUserList,
			),
		);
	}

	private function _getUserListByIds($aUserIds, $isGetGrade = false){
		//$oPersonal = new Model(T_PERSONAL);
		//$aUserList = $oPersonal->get('`id`,`name`,`profile`', array('id' => array('in', $aUserIds)));
		$aUserList = getUserListByUserIds($aUserIds);
		if($isGetGrade){
			if(!$aUserList){
				return $aUserList;
			}
			$oClass = new Model(T_USER_CLASS);
			$aClassList = $oClass->get('', '`user_id` in (' . implode(',', $aUserIds) . ') AND `is_active`=1');
			if($aClassList === false){
				return false;
			}
			foreach($aUserList as &$aUser){
				foreach($aClassList as $aClass){
					if($aUser['id'] == $aClass['user_id']){
						$aUser['grade'] = $aClass['grade'];
						break;
					}
				}
			}
		}
		return $aUserList;
	}

	public function getUserSendPkCount($userId){
		$oPkIndex = new Model(T_PK_INDEX);
		return $oPkIndex->count('`sender_user_id`=' . $userId);
	}

	//获得用户某关的PK胜负次数
	public function getUserMissionPkStatistics($userId, $missionId){
		$oPkIndex = new Model(T_PK_INDEX);
		//PK次数
		$pkCount = $oPkIndex->count('(`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ') AND `winner_user_id`>0 AND `mission_id`=' . $missionId);
		if($pkCount === false){
			return false;
		}
		$winCount = $oPkIndex->count('`winner_user_id`=' . $userId . ' AND `mission_id`=' . $missionId);
		if($winCount === false){
			return false;
		}
		return array(
			'pk_count' => $pkCount,
			'win_count' => $winCount
		);
	}

	//我的本关pk记录
	public function getUserPkListByMissionId($userId, $missionId, $page, $pageSize){
		$oPkIndex = new Model(T_PK_INDEX);
		//PK次数
		$where = '(`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ') AND `mission_id`=' . $missionId . ' AND `receiver_user_id` > 0';
		$offect = ($page - 1) * $pageSize;
		$aUserPkList = $oPkIndex->get('', $where, '`create_time` DESC', $offect, $pageSize);
		if(!$aUserPkList){
			return $aUserPkList;
		}
		$aUserIds = array();
		foreach($aUserPkList as $aUserPk){
			if($aUserPk['sender_user_id'] == $userId){
				$aUserIds[] = $aUserPk['receiver_user_id'];
			}else{
				$aUserIds[] = $aUserPk['sender_user_id'];
			}
		}
		$aUserIds[] = $userId;
		$aUserList = getUserListByUserIds($aUserIds);
		foreach($aUserPkList as &$aUserPk){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aUserPk['sender_user_id']){
					$aUserPk['sender_user_info'] = $aUser;
				}elseif($aUser['id'] == $aUserPk['receiver_user_id']){
					$aUserPk['receiver_user_info'] = $aUser;
				}
			}
		}
		return $aUserPkList;
	}

	//关卡PK动态
	public function getPkEventListByMissionId($missionId, $page, $pageSize){
		$oPkIndex = new Model(T_PK_INDEX);
		$offect = ($page - 1) * $pageSize;
		$aPkList = $oPkIndex->get('`sender_user_id`,`receiver_user_id`,`winner_user_id`,`create_time`', '`mission_id`=' . $missionId . ' AND `receiver_user_id` > 0', '`create_time` DESC', $offect, $pageSize);
		if(!$aPkList){
			return $aPkList;
		}
		$aUserIds = array();
		foreach($aPkList as $aPk){
			$aUserIds[] = $aPk['sender_user_id'];
			$aUserIds[] = $aPk['receiver_user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aPkList as &$aPk){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPk['sender_user_id']){
					$aPk['sender_user_info'] = $aUser;
				}elseif($aUser['id'] == $aPk['receiver_user_id']){
					$aPk['receiver_user_info'] = $aUser;
				}
			}
		}
		return $aPkList;
	}

	//关卡发起次数排名
	public function getUserSendPkRankingList($missionId = 0, $page = 1, $pageSize = 10, $aPointUserIds = array()){
		$oPkIndex = new Model(T_PK_INDEX);
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if($missionId){
			$where = '`mission_id`=' . $missionId;
		}
		if($aPointUserIds){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`sender_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		$aPkList = $oPkIndex->get('`sender_user_id`,count(*) as `nums`', $where, '`nums` DESC', $offect, $pageSize, '`sender_user_id`');
		if(!$aPkList){
			return $aPkList;
		}
		$aUserIds = array();
		foreach($aPkList as $aPk){
			$aUserIds[] = $aPk['sender_user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		$aReturnData = array();
		foreach($aPkList as $aPk){
			$offect += 1;
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPk['sender_user_id']){
					$aUser['send_count'] = $aPk['nums'];
					$aUser['rank'] = $offect;
					$aReturnData[] = $aUser;
					break;
				}
			}
		}
		return $aReturnData;
	}

	/*
	 * 获取用户闯过的关卡及该关卡的PK次数和发起PK人数统计
	 */
	public function getUserPassMissionListForPkArena($userId, $page, $pageSize, $subjectId = 0, $order = '`grade` ASC, `orders` ASC', $haveGold = 0, $aMissionIds = array(), $aPointUserIds = array()){
		$aReturnMissionList = array(
			'mission_list'	=>	array(),
			'mission_count'	=>	0,
		);
		//我闯过的关卡
		/*$aMissionIds = $this->_getCanPkMissionIdsForPk($userId);
		if($aMissionIds === false){
			return false;
		}elseif(!$aMissionIds){
			return $aReturnMissionList;
		}*/
		$oPkIndex = new Model(T_PK_INDEX);
		//我过的关卡的PK场中未应战的PK统计
		//$where = '`mission_id` in (' . implode(',', $aMissionIds) . ') AND `receiver_user_id`=0 AND `over_time`>' . time();
		$where = '`receiver_user_id`=0 AND `over_time`>' . time();
		if($haveGold){
			$where .= ' AND `attachment_gold`>0';
		}
		if($aMissionIds){
			$where .= ' AND `mission_id` in (' . implode(',', $aMissionIds) . ')';
		}
		if($aPointUserIds){
			$where .= ' AND `sender_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		//关卡PK数统计
		$aPkCountStatistcList = $oPkIndex->get('`mission_id`,count(*) as `nums`', $where, '', '', '', '`mission_id`');
		if($aPkCountStatistcList === false){
			return false;
		}
		$aHavePkMissionIds = array();
		foreach($aPkCountStatistcList as $key => $aPkCountStatistc){
			if($aPkCountStatistc['nums'] > 0){
				$aHavePkMissionIds[] = $aPkCountStatistc['mission_id'];
			}else{
				unset($aPkCountStatistcList[$key]);
			}
		}
		if(!$aHavePkMissionIds){
			return $aReturnMissionList;
		}
		$aReturnMissionList['mission_count'] = count($aHavePkMissionIds);
		//关卡PK发起人数统计
		/*$where = '`mission_id` in (' . implode(',', $aHavePkMissionIds) . ') AND `receiver_user_id`=0 AND `over_time`>' . time();
		$aPkUserCountStatistcList = $oPkIndex->get('`mission_id`,count(DISTINCT `sender_user_id`) as `nums`', $where, '', '', '', '`mission_id`');
		if($aPkUserCountStatistcList === false){
			return false;
		}*/

		if($aMissionIds){
			$where = array('id' => array('in', $aHavePkMissionIds));
		}elseif($subjectId){
			$where = '`id` in (' . implode(',', $aHavePkMissionIds) . ') AND `subject_id`=' . $subjectId;
		}else{
			$where = array('id' => array('in', $aHavePkMissionIds));
		}
		$offect = ($page - 1) * $pageSize;
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', $where, $order, $offect, $pageSize);
		if($aMissionList === false){
			return false;
		}
		$aMissionList = Mission::convertMissionList($aMissionList);
		foreach($aMissionList as $key => $aMission){
			$aMissionList[$key]['pk_count'] = 0;
			//$aMissionList[$key]['pk_user_count'] = 0;
			foreach($aPkCountStatistcList as $aPkCountStatistc){
				if($aPkCountStatistc['mission_id'] == $aMission['id']){
					$aMissionList[$key]['pk_count'] = $aPkCountStatistc['nums'];
					break;
				}
			}
			/*foreach($aPkUserCountStatistcList as $aPkUserCountStatistc){
				if($aPkUserCountStatistc['mission_id'] == $aMission['id']){
					$aMissionList[$key]['pk_user_count'] = $aPkUserCountStatistc['nums'];
					break;
				}
			}*/
		}
		$aReturnMissionList['mission_list'] = $aMissionList;
		return $aReturnMissionList;
	}

	public function getMissionPkArenaPkList($missionId, $page, $haveGold = 0, $aPointUserIds = array(), $pageSize = 5, $haveGoldPageSize = 3, $noGoldPageSize = 2){
		$aPkArenaPkList = $this->_getMissionPkArenaPkList($missionId, $page, $haveGold, $aPointUserIds, $pageSize, $haveGoldPageSize, $noGoldPageSize);
		if($aPkArenaPkList === false){
			return false;
		}
		$aPkList = $this->_getUserInfoForPkList($aPkArenaPkList['pk_list'], array('numerical'));
		if($aPkList === false){
			return false;
		}
		$aPkArenaPkList['pk_list'] = $aPkList;
		return $aPkArenaPkList;
	}

	/*
	 * PK场的PK列表
	 */
	private function _getMissionPkArenaPkList($missionId, $page, $haveGold, $aPointUserIds, $pageSize, $haveGoldPageSize, $noGoldPageSize){
		$oPkIndex = new Model(T_PK_INDEX);
		$currentTime = time();
		$pointUserWhere = '';
		if($aPointUserIds){
			$pointUserWhere = ' AND `sender_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		//带金币的PK数量
		$goldWhere = '`receiver_user_id`=0 AND `attachment_gold`>0 AND `over_time`>' . $currentTime . ' AND `mission_id`=' . $missionId . $pointUserWhere;
		$fileds = '`id`,`sender_user_id`,`receiver_user_id`,`sender_user_start_time`,`sender_user_end_time`,`create_time`,`duration`,`mission_id`,`es_counts`,`attachment_gold`';
		$offect = ($page - 1) * $pageSize;
		$haveGoldPkCount = $oPkIndex->count($goldWhere);
		if($haveGoldPkCount === false){
			return false;
		}
		$haveGoldOder = '`attachment_gold` DESC,`create_time` DESC';
		if($haveGold){
			$aHaveGoldPkList = $oPkIndex->get($fileds, $goldWhere, $haveGoldOder, $offect, $pageSize);
			if($aHaveGoldPkList === false){
				return false;
			}
			return array('pk_count' => $haveGoldPkCount, 'pk_list' => $aHaveGoldPkList);
		}

		//不带金币的PK数量
		$noGoldWhere = '`receiver_user_id`=0 AND `attachment_gold`=0 AND `over_time`>' . $currentTime . ' AND `mission_id`=' . $missionId . $pointUserWhere;
		$noGoldPkCount = $oPkIndex->count($noGoldWhere);
		if($noGoldPkCount === false){
			return false;
		}

		$noGoldOder = '`create_time` DESC';
		if($haveGoldPkCount >= $page * $haveGoldPageSize && $noGoldPkCount >= $page * $noGoldPageSize){	//如果都足够的话
			$haveGoldOffect = ($page - 1) * $haveGoldPageSize;
			$noGoldOffect = ($page - 1) * $noGoldPageSize;
			$haveGoldLength = $haveGoldPageSize;
			$noGoldLength = $noGoldPageSize;
		}elseif($haveGoldPkCount < $page * $haveGoldPageSize && $noGoldPkCount >= $page * $noGoldPageSize){	//如果带金币的不足,不带金币的足够
			if($haveGoldPkCount > ($page - 1) * $haveGoldPageSize){
				$haveGoldOffect = ($page - 1) * $haveGoldPageSize;
				$noGoldOffect = ($page - 1) * $noGoldPageSize;
				$haveGoldLength = $haveGoldPkCount - ($page - 1) * $haveGoldPageSize;
				$noGoldLength = $pageSize - $haveGoldLength;
			}else{
				$haveGoldLength = 0;
				$noGoldLength = $pageSize;
				$noGoldOffect = $offect - $haveGoldPkCount;
			}
		}elseif($haveGoldPkCount >= $page * $haveGoldPageSize && $noGoldPkCount < $page * $noGoldPageSize){	//如果带金币的足够,不带金币的不足
			if($noGoldPkCount > ($page - 1) * $noGoldPageSize){
				$haveGoldOffect = ($page - 1) * $haveGoldPageSize;
				$noGoldOffect = ($page - 1) * $noGoldPageSize;
				$noGoldLength = $noGoldPkCount - ($page - 1) * $noGoldPageSize;
				$haveGoldLength = $pageSize - $noGoldLength;
			}else{
				$haveGoldLength = $pageSize;
				$noGoldLength = 0;
				$haveGoldOffect = $offect - $noGoldPkCount;
			}
		}else{	//都不足
			if($haveGoldPkCount <= ($page - 1) * $haveGoldPageSize){	//没有带金币的啦
				$haveGoldLength = 0;
				$noGoldLength = $pageSize;
				$noGoldOffect = $offect - $haveGoldPkCount;
			}elseif($noGoldPkCount <= ($page - 1) * $noGoldPageSize){	//没有不带金币的了
				$haveGoldLength = $pageSize;
				$noGoldLength = 0;
				$haveGoldOffect = $offect - $noGoldPkCount;
			}else{	//两者都有
				$haveGoldOffect = ($page - 1) * $haveGoldPageSize;
				$noGoldOffect = ($page - 1) * $noGoldPageSize;
				$noGoldLength = $noGoldPkCount - ($page - 1) * $noGoldPageSize;
				$haveGoldLength = $pageSize - $noGoldLength;
			}
		}
		$aHaveGoldPkList = array();
		if($haveGoldLength){
			$aHaveGoldPkList = $oPkIndex->get($fileds, $goldWhere, $haveGoldOder, $haveGoldOffect, $haveGoldLength);
			if($aHaveGoldPkList === false){
				return false;
			}
		}
		$aNoGoldPkList = array();
		if($noGoldLength){
			$aNoGoldPkList = $oPkIndex->get($fileds, $noGoldWhere, $noGoldOder, $noGoldOffect, $noGoldLength);
			if($aNoGoldPkList === false){
				return false;
			}
		}
		return array(
			'pk_count' => $haveGoldPkCount + $noGoldPkCount,
			'pk_list' => array_merge($aHaveGoldPkList, $aNoGoldPkList),
		);
	}

	/*
	 *PK竞技场的用户列表
	 */
	public function getMissionPkArenaUserList($missionId, $page, $pageSize){
		//取出最近PK的人
		$offect = ($page - 1) * $pageSize;
		$where = '`mission_id`=' . $missionId . ' AND `receiver_user_id`=0 AND `over_time`>' . time();
		$fields = '`sender_user_id`,count(*) as `nums`,max(`attachment_gold`) as `attachment_gold`,max(`create_time`) as `create_time`';
		$oPkIndex = new Model(T_PK_INDEX);
		$aPkUserList = $oPkIndex->get($fields, $where, '`create_time` DESC', $offect, $pageSize, '`sender_user_id`');
		if(!$aPkUserList){
			return $aPkUserList;
		}
		$aUserIds = array();
		foreach($aPkUserList as $aPkUser){
			$aUserIds[] = $aPkUser['sender_user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds, array('personal'));
		if($aUserList === false){
			return false;
		}
		$aUserList = $this->_getUserPkStatisticByUserList($aUserList);
		foreach($aUserList as &$aUser){
			foreach($aPkUserList as $aPkUser){
				if($aUser['id'] == $aPkUser['sender_user_id']){
					$aUser['attachment_gold'] = $aPkUser['attachment_gold'];
					$aUser['pk_arena_count'] = $aPkUser['nums'];
				}
			}
		}
		return $aUserList;
	}

	/*
	 * PK竞技场的用户数量
	 */
	public function getMissionPkArenaUserCount($missionId){
		$fields = 'count(DISTINCT `sender_user_id`) as `nums`';
		$where = '`mission_id`=' . $missionId . ' AND `receiver_user_id`=0 AND `over_time`>' . time();
		$oPkIndex = new Model(T_PK_INDEX);
		$aCountInfo = $oPkIndex->get($fields, $where);
		if(!$aCountInfo){
			return false;
		}else{
			return $aCountInfo[0]['nums'];
		}
	}

	/*
	 * 用户在PK场发起的PK列表
	 */
	public function getPkArenaUserSendPkList($userId, $missionId, $page = 0, $pageSize = 0, $order = ''){
		if($page == 0 || $pageSize == 0){
			$offect = '';
			$pageSize = '';
		}else{
			$offect = ($page - 1) * $pageSize;
		}
		$fields = '`id`,`sender_user_start_time`,`sender_user_end_time`,`duration`,`es_counts`,`attachment_gold`';
		$where = '`sender_user_id`=' . $userId . ' AND `receiver_user_id`=0 AND `over_time`>' . time() . ' AND `mission_id`=' . $missionId;
		$oPkIndex = new Model(T_PK_INDEX);
		return $oPkIndex->get($fields, $where, $order, $offect, $pageSize);
	}

	/*
	 * 获取我的最近pk用户列表
	 */
	public function getUserNearlyPkUserList($userId, $page, $pageSize){
		$offect = ($page - 1) * $pageSize;
		$oPkIndex = new Model(T_PK_INDEX);
		$aUserPkList = $oPkIndex->get('`sender_user_id`,`receiver_user_id`,`create_time`', '`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId, '`create_time` DESC');
		if(!$aUserPkList){
			return $aUserPkList;
		}
		$aUserIds = array();
		foreach($aUserPkList as $aUserPk){
			if($aUserPk['sender_user_id'] == $userId){
				$pkUserId = $aUserPk['receiver_user_id'];
			}else{
				$pkUserId = $aUserPk['sender_user_id'];
			}
			if(!in_array($pkUserId, $aUserIds)){
				array_unshift($aUserIds, $pkUserId);
			}
		}
		unset($aUserPkList);
		$aUserIds = array_slice($aUserIds, $offect, $pageSize);
		if($aUserIds){
			$aUserList = getUserListByUserIds($aUserIds);
			return $this->_getUserPkStatisticByUserList($aUserList);
		}else{
			return $aUserIds;
		}
	}

	private function _getUserPkStatisticByUserList($aUserList, $startTime = 0, $endTime = 0){
		if($aUserList){
			$timeCondition = '';
			if($startTime){
				$timeCondition = ' AND `create_time`>=' . $startTime;
			}
			if($endTime){
				$timeCondition .= ' AND `create_time`<=' . $endTime;
			}
			$oPkIndex = new Model(T_PK_INDEX);
			if(count($aUserList) == 1){
				$userId = $aUserList[0]['id'];
				//PK次数
				$pkCount = $oPkIndex->count('(`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ') AND `winner_user_id`>0' . $timeCondition);
				$winCount = $oPkIndex->count('`winner_user_id`=' . $userId . $timeCondition);
				$aUserList[0]['pk_count'] = $pkCount;
				$aUserList[0]['win_count'] = $winCount;
				if($pkCount == 0){
					$aUserList[0]['win_percent'] = 0;
				}else{
					$aUserList[0]['win_percent'] = ceil($winCount/$pkCount * 100);
				}
			}else{
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['id'];
				}
				//作为发起人PK次数
				$aSenderPkCountList = $oPkIndex->get('`sender_user_id` as `user_id`,count(*) as `nums`', '`sender_user_id` in (' . implode(',', $aUserIds) . ') AND `winner_user_id`>0', '', '', '', '`sender_user_id`');
				if($aSenderPkCountList === false){
					return false;
				}
				//作为接受者PK次数
				$aReceiverPkCountList = $oPkIndex->get('`receiver_user_id` as `user_id`,count(*) as `nums`', '`receiver_user_id` in (' . implode(',', $aUserIds) . ') AND `winner_user_id`>0', '', '', '', '`receiver_user_id`');
				if($aReceiverPkCountList === false){
					return false;
				}
				//PK胜利次数
				$aWinnerCountList = $oPkIndex->get('`winner_user_id`, count(*) as `nums`', '`winner_user_id` in (' . implode(',', $aUserIds) . ')', '', '', '', '`winner_user_id`');
				if($aWinnerCountList === false){
					return false;
				}
				foreach($aUserList as &$aUser){
					$aUser['pk_count'] = 0;
					$aUser['win_count'] = 0;
					foreach($aSenderPkCountList as $aSenderPkCount){
						if($aUser['id'] == $aSenderPkCount['user_id']){
							$aUser['pk_count'] += $aSenderPkCount['nums'];
							break;
						}
					}
					foreach($aReceiverPkCountList as $aReceiverPkCount){
						if($aUser['id'] == $aReceiverPkCount['user_id']){
							$aUser['pk_count'] += $aReceiverPkCount['nums'];
							break;
						}
					}
					foreach($aWinnerCountList as $aWinnerCount){
						if($aUser['id'] == $aWinnerCount['winner_user_id']){
							$aUser['win_count'] = $aWinnerCount['nums'];
						}
					}
					if($aUser['pk_count'] == 0){
						$aUser['win_percent'] = 0;
					}else{
						$aUser['win_percent'] = ceil($aUser['win_count']/$aUser['pk_count'] * 100);
					}
				}
			}
		}
		return $aUserList;
	}

	//获取用户在某个关卡中发起的等待PK的pk次数
	public function getUserPkArenaMissionPkCount($userId, $missionId){
		$oPkIndex = new Model(T_PK_INDEX);
		return $oPkIndex->count('`sender_user_id`=' . $userId . ' AND `mission_id`=' . $missionId . ' AND `over_time`>' . time() . ' AND `receiver_user_id`=0');
	}

	//用户PK列表----------我的PK页面使用
	public function getNewUserPkList($userId, $page, $pageSize, $order = '', $isWin = 0, $waitPk = 0){
		$aPkList = $this->_getNewUserPkList($userId, $page, $pageSize, $order, $isWin, $waitPk);
		if(!$aPkList){
			return $aPkList;
		}
		$aMissionIds = array();
		foreach($aPkList as $aPk){
			$aMissionIds[] = $aPk['mission_id'];
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', array('id' => array('in', $aMissionIds)));
		if($aMissionList === false){
			return false;
		}
		$aMissionList = Mission::convertMissionList($aMissionList);
		foreach($aPkList as $key => $aPk){
			foreach($aMissionList as $aMission){
				if($aMission['id'] == $aPk['mission_id']){
					$aPkList[$key]['mission_name'] = $aMission['name'];
					break;
				}
			}
		}
		return $this->_getUserInfoForPkList($aPkList);
	}


	private function _getNewUserPkList($userId, $page, $pageSize, $order = '', $isWin = 0, $waitPk = 0){
		//排序优先级别:1、待领奖，2、进行中的PK，3、别人发起的等我P的，4、我发起的PK等我P，5、我发起的PK等别人P，6、已结束的PK
		$oPkIndex = new Model(T_PK_INDEX);
		$currentTime = time();
		$offect = ($page - 1) * $pageSize;
		if($waitPk){
			$where = '`over_time`>' . $currentTime . ' AND ((`sender_user_id`=' . $userId . ' AND `sender_user_start_time`=0) OR (`receiver_user_id`=' . $userId . ' AND `receiver_user_start_time`=0))';
			return $oPkIndex->get('', $where, '`create_time` DESC', $offect, $pageSize);
		}
		if($isWin){
			if($order){	//按发起时间
				return $oPkIndex->get('', '`winner_user_id`=' . $userId, '`create_time` DESC', $offect, $pageSize);
			}
			//待领取的放前面
			$aWaitReceivePkList = $oPkIndex->get('', '`winner_user_id`=' . $userId . ' AND `is_receive_prize`=0', '`create_time` DESC');
			if($aWaitReceivePkList === false){
				return false;
			}
			$waitReceivePkCount = count($aWaitReceivePkList);
			$aWaitReceivePkList = array_slice($aWaitReceivePkList, $offect, $pageSize);
			if(count($aWaitReceivePkList) == $pageSize){
				return $aWaitReceivePkList;
			}
			$offect2 = $offect - $waitReceivePkCount;
			if($offect2 < 0){
				$offect2 = 0;
			}
			$aReceivedPkList = $oPkIndex->get('', '`winner_user_id`=' . $userId . ' AND `is_receive_prize`=1', '`create_time` DESC', $offect2, $pageSize - count($aWaitReceivePkList));
			if($aReceivedPkList === false){
				return false;
			}
			return array_merge($aWaitReceivePkList, $aReceivedPkList);
		}

		if($order){	//按发起时间
			return $oPkIndex->get('', '`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId, '`create_time` DESC', $offect, $pageSize);
		}

		//取出待领奖和未完成的PK
		$where = '(`winner_user_id`=' . $userId . ' AND `is_receive_prize`=0) OR (`winner_user_id`=0 AND `over_time`>' . $currentTime . ' AND (`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . '))';
		$aUserPkList = $oPkIndex->get('', $where);
		if($aUserPkList === false){
			return false;
		}

		$aPkIds = array();
		foreach($aUserPkList as $aUserPk){
			$aPkIds[] = $aUserPk['id'];
		}
		$firstLength = count($aUserPkList);
		$aFirstUserPkList = array();
		if($firstLength > $offect){
			//给取出来的PK列表排序
			$aOrderPkList = array();
			//首先取出待领取的
			foreach($aUserPkList as $key => $aUserPk){
				if($aUserPk['winner_user_id'] == $userId){
					$aOrderPkList[] = $aUserPk;
					unset($aUserPkList[$key]);
				}
			}
			//进行中的PK
			foreach($aUserPkList as $key => $aUserPk){
				if(($aUserPk['sender_user_id'] == $userId && $aUserPk['sender_user_start_time'] > 0 && $aUserPk['sender_user_end_time'] == 0 && $aUserPk['sender_user_start_time'] + $aUserPk['duration'] * 60 > $currentTime) || ($aUserPk['receiver_user_id'] == $userId && $aUserPk['receiver_user_start_time'] > 0 && $aUserPk['receiver_user_end_time'] == 0 && $aUserPk['receiver_user_start_time'] + $aUserPk['duration'] * 60 > $currentTime)){
					$aOrderPkList[] = $aUserPk;
					unset($aUserPkList[$key]);
				}
			}
			//别人发起的等我P的
			foreach($aUserPkList as $key => $aUserPk){
				if($aUserPk['receiver_user_id'] == $userId && $aUserPk['receiver_user_start_time'] == 0){
					$aOrderPkList[] = $aUserPk;
					unset($aUserPkList[$key]);
				}
			}
			//我发起的PK等我P
			foreach($aUserPkList as $key => $aUserPk){
				if($aUserPk['sender_user_id'] == $userId && $aUserPk['sender_user_start_time'] == 0){
					$aOrderPkList[] = $aUserPk;
					unset($aUserPkList[$key]);
				}
			}
			//我发起的PK等别人P
			foreach($aUserPkList as $key => $aUserPk){
				$aOrderPkList[] = $aUserPk;
				unset($aUserPkList[$key]);
			}
			$aFirstUserPkList = array_slice($aOrderPkList, $offect, $pageSize);
		}
		if(count($aFirstUserPkList) == $pageSize){
			return $aFirstUserPkList;
		}
		//取出剩余的PK
		$offect1 = $offect - $firstLength;
		if($offect1 < 0){
			$offect1 = 0;
		}
		$pageSize1 = $pageSize - count($aFirstUserPkList);
		if($aPkIds){
			$where1 = '(`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ') AND `id` NOT IN (' . implode(',', $aPkIds) . ')';
		}else{
			$where1 = '`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId;
		}
		$aPkList = $oPkIndex->get('', $where1, '`create_time` DESC', $offect1, $pageSize1);
		if($aPkList === false){
			return false;
		}
		return array_merge($aFirstUserPkList, $aPkList);
	}

	private function _getUserInfoForPkList($aPkList, $aUserDetail = array()){
		if(!$aPkList){
			return $aPkList;
		}
		$aUserIds = array();
		foreach($aPkList as $aPk){
			$aUserIds[] = $aPk['sender_user_id'];
			if($aPk['receiver_user_id']){
				$aUserIds[] = $aPk['receiver_user_id'];
			}
		}
		$aUserList = getUserListByUserIds($aUserIds, $aUserDetail);
		if($aUserList === false){
			return false;
		}
		foreach($aPkList as &$aPk){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPk['sender_user_id']){
					$aPk['sender_user_info'] = $aUser;
				}elseif($aUser['id'] == $aPk['receiver_user_id']){
					$aPk['receiver_user_info'] = $aUser;
				}
			}
		}
		return $aPkList;
	}

	public function getNewUserPkCount($userId, $isWin = 0){
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '`receiver_user_id`!=0 AND (`sender_user_id`=' . $userId . ' OR `receiver_user_id`=' . $userId . ')';
		if($isWin){
			$where = '`winner_user_id`=' . $userId;
		}
		return $oPkIndex->count($where);
	}

	//为用户推荐的PK
	public function getRecommendPkForUser($userId, $length){
		$aMissionIds = $this->_getCanPkMissionIdsForPk($userId);
		if(!$aMissionIds){
			return $aMissionIds;
		}
		//取出最近的100条PK
		$currentTime = time();
		$where = '`receiver_user_id`=0  AND `over_time`>' . $currentTime . ' AND `mission_id` in(' . implode(',', $aMissionIds) . ')';
		$fileds = '`id`,`sender_user_id`,`receiver_user_id`,`create_time`,`duration`,`mission_id`,`es_counts`,`attachment_gold`';
		$oPkIndex = new Model(T_PK_INDEX);
		$aPkList = $oPkIndex->get($fileds, $where, '`create_time` DESC', 0, 100);
		if(!$aPkList){
			return $aPkList;
		}
		$aReturnPkList = array();
		if(count($aPkList) > $length){
			$aKeys = array_rand($aPkList, $length);
			if(is_array($aKeys)){
				foreach($aKeys as $key){
					$aReturnPkList[] = $aPkList[$key];
				}
			}else{
				$aReturnPkList[] = $aPkList[$aKeys];
			}
		}else{
			$aReturnPkList = $aPkList;
		}
		$aMissionIds = array();
		foreach($aReturnPkList as $aReturnPk){
			$aMissionIds[] = $aReturnPk['mission_id'];
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', array('id' => array('in', $aMissionIds)));
		if($aMissionList === false){
			return false;
		}
		$aMissionList = Mission::convertMissionList($aMissionList);
		foreach($aReturnPkList as $key => $aReturnPk){
			foreach($aMissionList as $aMission){
				if($aMission['id'] == $aReturnPk['mission_id']){
					$aReturnPkList[$key]['mission_name'] = $aMission['name'];
					break;
				}
			}
		}
		return $this->_getUserInfoForPkList($aReturnPkList);
	}

	private function _getCanPkMissionIdsForPk($userId){
		//我闯过的关卡
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aMissionUserRelationList = $oMissionUserRelationIndex->get('`mission_id`', '`user_id`=' . $userId . ' AND `is_pass`=1');
		if($aMissionUserRelationList === false){
			return false;
		}
		$aMissionIds = array();
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			$aMissionIds[] = $aMissionUserRelation['mission_id'];
		}
		//还需要其他科目的关卡
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`', '`subject_id`=' . self::OTHER_SUBJECT);
		if($aMissionList === false){
			return false;
		}
		foreach($aMissionList as $aMission){
			$aMissionIds[] = $aMission['id'];
		}
		return $aMissionIds;
	}

	//用户发起场次排名位置
	public function getUserSendPkRanking($userId, $aPointUserIds = array()){
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '';
		if($aPointUserIds){
			$where .= '`sender_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		$aPkList = $oPkIndex->get('`sender_user_id`,count(*) as `nums`', $where, '`nums` DESC', '', '', '`sender_user_id`');
		if(!$aPkList){
			return $aPkList;
		}
		$ranking = 1;
		foreach($aPkList as $aPk){
			if($aPk['sender_user_id'] == $userId){
				break;
			}
			$ranking++;
		}
		return $ranking;
	}

	//用户胜场排名位置
	public function getUserWinPkRanking($userId, $aPointUserIds = array()){
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '`winner_user_id`>0';
		if($aPointUserIds){
			$where .= ' AND `winner_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		$aPkList = $oPkIndex->get('`winner_user_id`,count(*) as `nums`', $where, '`nums` DESC', '', '', '`winner_user_id`');
		if(!$aPkList){
			return $aPkList;
		}
		$myWinTimes = 0;
		foreach($aPkList as $aPk){
			if($aPk['winner_user_id'] == $userId){
				$myWinTimes = $aPk['nums'];
				break;
			}
		}
		$ranking = 1;
		foreach($aPkList as $aPk){
			if($aPk['nums'] <= $myWinTimes){
				break;
			}
			$ranking++;
		}
		return $ranking;
	}

	//清除PK场中没人应战并且过期的PK
	public function deleteOverTimePkArenaPkList(){
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '`receiver_user_id`=0 AND `over_time`<=' . time();
		$aPkList = $oPkIndex->get('`id`,`sender_user_id`,`attachment_gold`', $where);
		if(!$aPkList){
			return $aPkList;
		}
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aPkIds = array();
		foreach($aPkList as $aPk){
			if($aPk['attachment_gold'] > 0){
				$result = $oDboi->table(T_USER_NUMERICAL)->data(array('gold' => array('add', $aPk['attachment_gold'])))->where(array('id' => $aPk['sender_user_id']))->update();
				if($result === false){
					$oDboi->rollBack();
					return false;
				}
			}
			$aPkIds[] = $aPk['id'];
		}
		$result = $oDboi->table(T_PK_INDEX)->where(array('id' => array('in', $aPkIds)))->delete();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		$result = $oDboi->table(T_PK)->where(array('id' => array('in', $aPkIds)))->delete();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		return $result;
	}

	public function getPkEventList($page, $pageSize, $aPointUserIds){
		$oPkIndex = new Model(T_PK_INDEX);
		$where = '';
		if($aPointUserIds){
			$where = '`sender_user_id` in (' . implode(',', $aPointUserIds) . ')';
		}
		$offect = ($page - 1) * $pageSize;
		$aPkIndexList = $oPkIndex->get('`sender_user_id`,`create_time`', $where, '`create_time` DESC', $offect, $pageSize);
		if(!$aPkIndexList){
			return $aPkIndexList;;
		}
		$aUserIds = array();
		foreach($aPkIndexList as $aPkIndex){
			$aUserIds[] = $aPkIndex['sender_user_id'];
		}
	}

	//PK场最近的几场PK----首页展示用
	public function getNearlyPkArenaPkList($length, $userId){
		//用户过的关卡ID
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserPassMissionList = $oMissionUserRelationIndex->get('`mission_id`', '`user_id`=' . $userId . ' AND `is_pass`=1');
		if($aUserPassMissionList === false){
			return false;
		}
		$aUserPassMissionIds = array();
		foreach($aUserPassMissionList as $aUserPassMission){
			$aUserPassMissionIds[] = $aUserPassMission['mission_id'];
		}
		//其他科目的关卡ID
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`', '`subject_id`=4 AND `is_forbidden`=0');
		if($aMissionList === false){
			return false;
		}
		foreach($aMissionList as $aMission){
			$aUserPassMissionIds[] = $aMission['id'];
		}
		$oPkIndex = new Model(T_PK_INDEX);
		$currentTime = time();
		//我可以参加的PK
		$where = '`receiver_user_id`=0  AND `over_time`>' . $currentTime . ' AND `sender_user_id`!=' . $userId . ' AND `mission_id` in (' . implode(',', $aUserPassMissionIds) . ')';
		$fileds = '`id`,`sender_user_id`,`receiver_user_id`,`sender_user_start_time`,`sender_user_end_time`,`create_time`,`duration`,`mission_id`,`es_counts`,`attachment_gold`';
		$aPkList = $oPkIndex->get($fileds, $where, '`create_time` DESC', 0, $length);
		if($aPkList === false){
			return $aPkList;
		}
		if(count($aPkList) < $length){
			//补充少的
			$length = $length - count($aPkList);
			$where = '`receiver_user_id`=0  AND `over_time`>' . $currentTime . ' AND `sender_user_id`!=' . $userId . ' AND `mission_id` not in (' . implode(',', $aUserPassMissionIds) . ')';
			$aOtherPkList = $oPkIndex->get($fileds, $where, '`create_time` DESC', 0, $length);
			if($aOtherPkList === false){
				return false;
			}
			$aPkList = array_merge($aPkList, $aOtherPkList);
		}
		$aPkList = $this->_getUserInfoForPkList($aPkList);
		$aPkList = $this->_getMissionInfoForPkList($aPkList);
		return $aPkList;
	}

	private function _getMissionInfoForPkList($aPkList){
		if(!$aPkList){
			return $aPkList;
		}
		$aMissionIds = array();
		foreach($aPkList as $aPk){
			$aMissionIds[] = $aPk['mission_id'];
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', array('id' => array('in', $aMissionIds)));
		if($aMissionList === false){
			return false;
		}
		$aMissionList = Mission::convertMissionList($aMissionList);
		foreach($aPkList as $key => $aPk){
			$aPkList[$key]['mission_name'] = '';
			foreach($aMissionList as $aMission){
				if($aMission['id'] == $aPk['mission_id']){
					$aPkList[$key]['mission_name'] = $aMission['name'];
					break;
				}
			}
		}
		return $aPkList;
	}

	//我收到的PK未开始的数量
	public function getUserWaitPkCount($userId){
		$oPk = new Model(T_PK_INDEX);
		$where = '`receiver_user_id`=' . $userId . ' AND `receiver_user_start_time`=0 AND `over_time`>' . time();
		return $oPk->count($where);
	}

	//好友在PK场发送的PK
	public function getPointUserSendPkArenaPkCount($aPointUserIds){
		if(!$aPointUserIds){
			return 0;
		}
		$oPk = new Model(T_PK_INDEX);
		$where = '`sender_user_id` in (' . implode(',', $aPointUserIds) . ') AND `receiver_user_id`=0 AND `over_time`>' . time();
		return $oPk->count($where);
	}

	//pk场带金币的数量
	public function getPkArenaHaveGoldPkCount(){
		$oPk = new Model(T_PK_INDEX);
		$where = '`attachment_gold`>0 AND `receiver_user_id`=0 AND `over_time`>' . time();
		return $oPk->count($where);
	}

	//PK场的PK总数
	public function getPkArenaPkCount(){
		$oPk = new Model(T_PK_INDEX);
		$where = '`receiver_user_id`=0 AND `over_time`>' . time();
		return $oPk->count($where);
	}
}
