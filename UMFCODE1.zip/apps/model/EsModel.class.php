<?php
/**
 *题目对象模型
 */
class EsModel{
	private $_categoryList = array();
	private $_detailCategoryList = array();
	private $_aCategory = array();
	private $_aTree = array();
	const OFFICIAL_ES_STATU = 5;	//正式题目状态配置
	const SIMILAR_PERCENT = 90;		//题目相似度配置
	const ANSWER_COUNT = 5;			//计算错误率时用的最少答题次数，才参与统计
	private $_aStatus = array(
		'wait_submit'		=>	1,
		'wait_approve'		=>	2,
		'first_approved'	=>	3,
		'is_sendback'		=>	4,
		'pass_end_approved'		=>	5,
		'not_pass_end_approved'		=>	6,
		'blank_out'			=>	7,
		'delete'			=>	8,
	);

	private $_aAction = array(
		'create'		=>	1,
		'submit'		=>	2,
		'first_approved'	=>	3,
		'sendback'		=>	4,
		'pass_end_approved'		=>	5,
		'not_pass_end_approved'		=>	6,
		'blank_out'			=>	7,
		'delete'			=>	8,
	);

	private $_aChineseRate = array(
		'1' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'2' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'3' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'4' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'5' => array(
			'1'	=> 0.52,
			'2'	=> 1,
			'3'	=> 0.27,
			'4'	=> 1,
			'5'	=> 1,
			'6'	=> 1,
			'7'	=> 1,
		),
		'6' => array(
			'1'	=> 0.52,
			'2'	=> 1,
			'3'	=> 0.27,
			'4'	=> 1,
			'5'	=> 1,
			'6'	=> 1,
			'7'	=> 1,
		),
		'7' => array(
			'1'	=> 0.743,
			'2'	=> 1,
			'3'	=> 0.31,
			'4'	=> 1,
			'5'	=> 1,
			'6'	=> 1,
			'7'	=> 1,
		),
		'8' => array(
			'1'	=> 0.743,
			'2'	=> 1,
			'3'	=> 0.31,
			'4'	=> 1,
			'5'	=> 1,
			'6'	=> 1,
			'7'	=> 1,
		),
		'9' => array(
			'1'	=> 0.743,
			'2'	=> 1,
			'3'	=> 0.31,
			'4'	=> 1,
			'5'	=> 1,
			'6'	=> 1,
			'7'	=> 1,
		),
	);

	private $_aMathRate = array(
		'1' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'2' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'3' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'4' => array(
			'1'	=> 0.52,
			'2'	=> 0.52,
			'3'	=> 0.27,
		),
		'5' => array(
			'1'	=> 0.5,
			'2'	=> 0.5,
			'3'	=> 0.32,
			'4'	=> 0.75,
		),
		'6' => array(
			'1'	=> 0.5,
			'2'	=> 0.5,
			'3'	=> 0.32,
			'4'	=> 0.75,
		),
		'7' => array(
			'1'	=> 1,
			'2'	=> 1,
			'3'	=> 0.5,
			'4'	=> 0.95,
		),
		'8' => array(
			'1'	=> 1,
			'2'	=> 1,
			'3'	=> 0.5,
			'4'	=> 0.95,
		),
		'9' => array(
			'1'	=> 1,
			'2'	=> 1,
			'3'	=> 0.5,
			'4'	=> 0.95,
		),
	);
	private $_aEnglishRate = array(
		'1' => array(
			'1'	=> 0.41,
			'2'	=> 0.41,
			'3'	=> 0.29,
		),
		'2' => array(
			'1'	=> 0.41,
			'2'	=> 0.41,
			'3'	=> 0.29,
		),
		'3' => array(
			'1'	=> 0.41,
			'2'	=> 0.41,
			'3'	=> 0.29,
		),
		'4' => array(
			'1'	=> 0.41,
			'2'	=> 0.41,
			'3'	=> 0.29,
		),
		'5' => array(
			'1'	=> 0.43,
			'2'	=> 0.43,
			'3'	=> 0.29,
			'4'	=> 0.29,
			'5'	=> 1.14,
			'6'	=> 0.71,
			'7'	=> 0.71,
		),
		'6' => array(
			'1'	=> 0.43,
			'2'	=> 0.43,
			'3'	=> 0.29,
			'4'	=> 0.29,
			'5'	=> 1.14,
			'6'	=> 0.71,
			'7'	=> 0.71,
		),
		'7' => array(
			'1'	=> 0.43,
			'2'	=> 0.43,
			'3'	=> 0.29,
			'4'	=> 0.29,
			'5'	=> 1.14,
			'6'	=> 0.71,
			'7'	=> 0.71,
		),
		'8' => array(
			'1'	=> 0.57,
			'2'	=> 0.57,
			'3'	=> 0.57,
			'4'	=> 0.43,
			'5'	=> 1.2,
			'6'	=> 1.14,
			'7'	=> 1.14,
		),
		'9' => array(
			'1'	=> 0.57,
			'2'	=> 0.57,
			'3'	=> 0.57,
			'4'	=> 0.43,
			'5'	=> 1.2,
			'6'	=> 1.14,
			'7'	=> 1.14,
		),
		'10' => array(
			'1'	=> 0.517,
			'2'	=> 0.517,
			'3'	=> 0.31,
		),
		'11' => array(
			'1'	=> 0.517,
			'2'	=> 0.517,
			'3'	=> 0.31,
		),
		'12' => array(
			'1'	=> 0.517,
			'2'	=> 0.517,
			'3'	=> 0.31,
		),
	);

	private $_step = 1;
	/**
	 * 添加一条题目
	 * @param type $aData
	 * @return type
	 */
	public function addEs($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aEsIndexData = array();
		$aIndexFields = array(
			'subject_id',
			'category_id',
			'type_id',
			'status',
			'correct_counts',
			'answer_counts',
			'correct_percent',
			'ub',
			'appeal_status'
		);
		foreach($aIndexFields as $field){
			if(isset($aData[$field])){
				$aEsIndexData[$field] = $aData[$field];
			}
		}
		$esIndexId = $oDboi->table(T_ES_INDEX)->data($aEsIndexData)->insert();
		if($esIndexId){
			$aEsData = array();
			$aEsData['id'] = $esIndexId;
			if(isset($aData['content_json'])){
				$aEsData['content_json'] = $aData['content_json'];
			}
			if(isset($aData['content_text'])){
				$aEsData['content_text'] = $aData['content_text'];
			}
			$row = $oDboi->table(T_ES)->data($aEsData)->insert();
			if($row){
				//写数据到日志表
				$aLogData = array();
				$aLogData['es_id'] = $esIndexId;
				$aLogFields = array(
					'subject_id',
					'submiter_user_id',
					'approver_user_id',
					'operating_time',
					'action',
					'comment',
				);
				foreach($aLogFields as $field){
					if(isset($aData[$field])){
						$aLogData[$field] = $aData[$field];
					}
				}
				$esLogId = $oDboi->table(T_ES_LOG)->data($aLogData)->insert();
				if(!$esLogId){
					//回滚
					$oDboi->rollBack();
					return false;
				}
				return $esIndexId;
			}else{
				//回滚
				$oDboi->rollBack();
				return false;
			}
		}else{
			return $esIndexId;
		}
	}

	/**
	 *批量添加
	 * @param type $aData
	 * @return boolean|int 最后一个题目的id
	 */
	public function addBatchEs($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aIndexData = $aEsData = $aLogData = array();
		foreach($aData as $aRecord){
			$aIndex = array();
			$aIndexFields = array(
				'subject_id',
				'category_id',
				'type_id',
				'status',
				'correct_counts',
				'answer_counts',
				'correct_percent',
				'ub',
				'appeal_status'
			);
			foreach($aIndexFields as $field){
				if(isset($aRecord[$field])){
					$aIndex[$field] = $aRecord[$field];
				}
			}
			$aIndexData[] = $aIndex;
		}
		$esIndexId = $oDboi->table(T_ES_INDEX)->data($aIndexData)->insert();
		if($esIndexId){
			foreach($aData as $aRecord){
				$aEs = array();
				$aEs['id'] = $esIndexId;
				if(isset($aRecord['content_json'])){
					$aEs['content_json'] = $aRecord['content_json'];
				}
				if(isset($aRecord['content_text'])){
					$aEs['content_text'] = $aRecord['content_text'];
				}
				$aEsData[] = $aEs;
				//组装日志数据
				$aLogFields = array(
					'subject_id',
					'submiter_user_id',
					'approver_user_id',
					'operating_time',
					'action',
					'comment',
				);
				$aLog = array();
				$aLog['es_id'] = $esIndexId;
				foreach($aLogFields as $field){
					if(isset($aRecord[$field])){
						$aLog[$field] = $aRecord[$field];
					}
				}
				$aLogData[] = $aLog;
				$esIndexId += $this->_step;
			}
			$row = $oDboi->table(T_ES)->data($aEsData)->insert();
			if($row){
				//写数据到日志表
				$esLogId = $oDboi->table(T_ES_LOG)->data($aLogData)->insert();
				if(!$esLogId){
					//回滚
					$oDboi->rollBack();
					return false;
				}
				return $esIndexId;
			}else{
				//回滚
				$oDboi->rollBack();
				return false;
			}
		}else{
			return false;
		}
	}

	public function setEs($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aEsIndexData = array();
		$aIndexFields = array(
			'subject_id',
			'category_id',
			'type_id',
			'status',
			'correct_counts',
			'answer_counts',
			'correct_percent',
			'answer_time_total',
		);
		foreach($aIndexFields as $field){
			if(isset($aData[$field])){
				$aEsIndexData[$field] = $aData[$field];
			}
		}
		$result1 = $result2 = 0;
		if($aEsIndexData){
			$result1 = $oDboi->table(T_ES_INDEX)->where(array('id' => $aData['id']))->data($aEsIndexData)->update();
			if($result1 === false){
				return false;
			}
		}
		$aEsData = array();
		if(isset($aData['content_json'])){
			$aEsData['content_json'] = $aData['content_json'];
		}
		if(isset($aData['content_text'])){
			$aEsData['content_text'] = $aData['content_text'];
		}
		if(isset($aData['recent_record'])){
			$aEsData['recent_record'] = json_encode($aData['recent_record']);
		}
		if($aEsData){
			$result2 = $oDboi->table(T_ES)->where(array('id' => $aData['id']))->data($aEsData)->update();
			if($result2 === false){
				$oDboi->rollBack();
				return false;
			}
		}
		if($result1 || $result2){
			return 1;
		}
		return 0;
	}

	public function changeStatus($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aEsIndexData['status'] = $aData['status'];
		$row = $oDboi->table(T_ES_INDEX)->data($aEsIndexData)->where(array('id' => $aData['id']))->update();
		if($row && isset($aData['action'])){
			//写数据到日志表
			$aLogData = array();
			$aLogData['es_id'] = $aData['id'];
			$aLogFields = array(
				'subject_id',
				'submiter_user_id',
				'approver_user_id',
				'operating_time',
				'action',
				'comment',
			);
			foreach($aLogFields as $field){
				if(isset($aData[$field])){
					$aLogData[$field] = $aData[$field];
				}
			}
			$esLogId = $oDboi->table(T_ES_LOG)->data($aLogData)->insert();
			if($esLogId){
				if($aData['action'] == 3 || $aData['action'] == 4){
					$result = $oDboi->table(T_APPROVER_ES_RELATION)->where('`es_id`=' . $aData['id'])->delete();
					if($result === false){
						$oDboi->rollBack();
						return false;
					}
				}
				return true;
			}
			$oDboi->rollBack();
		}elseif($row){
			return true;
		}
		return false;
	}

	public function isUserEs($userId, $esId){
		$oEsIndex = new Model(T_ES_LOG);
		$result = $oEsIndex->count('`submiter_user_id`=' . $userId . ' AND `es_id`=' . $esId . ' AND `action`=1');
		return $result;
	}

	public function deleteEsByEsId($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result1 = $oDboi->table(T_ES_INDEX)->where(array('id' => $aData['id']))->delete();
		if($result1){
			$result2 = $oDboi->table(T_ES)->where(array('id' => $aData['id']))->delete();
			if($result2){
				//写数据到日志表
				$aLogData = array();
				$aLogData['es_id'] = $aData['id'];
				$aLogFields = array(
					'subject_id',
					'submiter_user_id',
					'approver_user_id',
					'operating_time',
					'action',
					'comment',
				);
				foreach($aLogFields as $field){
					if(isset($aData[$field])){
						$aLogData[$field] = $aData[$field];
					}
				}
				$esLogId = $oDboi->table(T_ES_LOG)->data($aLogData)->insert();
				if($esLogId){
					return true;
				}else{
					$oDboi->rollBack();
					return $esLogId;
				}
			}else{
				$oDboi->rollBack();
				return $result2;
			}
		}else{
			return $result1;
		}
	}

	public function getEsInfoByEsId($esId){
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexInfo = $oEsIndex->get('', array('id' => $esId));
		if($aEsIndexInfo === false){
			return false;
		}
		$oEs = new Model(T_ES);
		$aEsInfo = $oEs->get('', array('id' => $esId));
		if($aEsInfo === false){
			return false;
		}
		if($aEsIndexInfo && $aEsInfo){
			$aEsIndexInfo[0]['content_json'] = $aEsInfo[0]['content_json'];
			$aEsIndexInfo[0]['content_text'] = $aEsInfo[0]['content_text'];
			$aEsIndexInfo[0]['category_tree'] = $this->getDetailCategoryTree($aEsIndexInfo[0]['category_id']);
			$oEsLog = new Model(T_ES_LOG);
			$aEsLogInfo = $oEsLog->get('', '`es_id`=' . $esId . ' AND `action` in (1,2,3,4)');
			if($aEsLogInfo === false){
				return false;
			}elseif(!$aEsLogInfo){
				//myLog('题目在es_log表中找不到记录，题目ID为:' . $esId);
			}else{
				$oManager = new Model(T_MANAGER);
				foreach($aEsLogInfo as $aEsLog){
					if($aEsLog['action'] == 1){
						$aEsIndexInfo[0]['create_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
						$aUserInfo = $oManager->get('name', array('id' => $aEsLog['submiter_user_id']));
						if(!$aUserInfo){
							return false;
						}
						$aEsIndexInfo[0]['submiter_user_id'] = $aEsLog['submiter_user_id'];
						$aEsIndexInfo[0]['create_user_name'] = $aUserInfo[0]['name'];
					}elseif($aEsLog['action'] == 2){
						$aEsIndexInfo[0]['submit_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
					}elseif($aEsLog['action'] == 3 || $aEsLog['action'] == 4){
						$aEsIndexInfo[0]['approve_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
						if($aEsLog['action'] == 4){
							$aEsIndexInfo[0]['sendback_reason'] = $aEsLog['comment'];
						}
						$aEsIndexInfo[0]['approver_user_id'] = $aEsLog['approver_user_id'];
						$aUserInfo = $oManager->get('name', array('id' => $aEsLog['approver_user_id']));
						if(!$aUserInfo){
							return false;
						}
						$aEsIndexInfo[0]['approve_user_name'] = $aUserInfo[0]['name'];
					}
				}
			}
			return $aEsIndexInfo[0];
		}elseif(!$aEsIndexInfo && !$aEsInfo){
			return array();
		}else{
			myLog('题目在es_index表和es表数据不同步，题目ID为:' . $esId);
			return false;
		}
	}

	public function getEsList($fields = '', $where = '', $orderby = '', $offect = '', $length = '', $groupby = ''){
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsList = $oEsIndex->get($fields, $where, $orderby, $offect, $length, $groupby);
		if($aEsList){
			$oEs = new Model(T_ES);
			foreach($aEsList as &$aEs){
				if(isset($aEs['category_id'])){
					$aEs['category_tree'] = $this->getDetailCategoryTree($aEs['category_id']);
				}
				$aEsInfo = $oEs->get('', array('id' => $aEs['id']));
				if($aEsInfo === false){
					return false;
				}elseif($aEsInfo){
					$aEs['content_json'] = $aEsInfo[0]['content_json'];
					$aEs['content_text'] = $aEsInfo[0]['content_text'];
				}else{
					myLog('题目在es_index表和es表数据不同步，题目ID为:' . $aEs['id']);
					return false;
				}
			}
		}
		return $aEsList;
	}

	private function _getDetailEsCount($role, $action, $startTime, $endTime, $userId, $subjectId, $esType, $status, $searcher = 0, $categoryId = 0){
		$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $action;
		if($categoryId && $status == 5 && !$startTime && $endTime > time() - 30){
			$grade = $this->_getEsGradeByCategoryId($categoryId);
			if($grade <= 4 || $grade > 9){
				$where = '`t1`.`category_id`=' . $categoryId;
			}
		}
		if($userId){
			if(is_array($userId)){
				$group = '';
				if($role == 'creater'){
					$fileds = '`log`.`submiter_user_id` as `manager_id`, count(*) as nums';
					$group = '`log`.`submiter_user_id`';
					$where .= ' AND `log`.`submiter_user_id` in (' . implode(',', $userId) . ')';
				}elseif($role == 'approver'){
					$fileds = '`log`.`approver_user_id` as `manager_id`, count(*) as nums';
					$group = '`log`.`approver_user_id`';
					$where .= ' AND `log`.`approver_user_id` in (' . implode(',', $userId) . ')';
				}elseif($role == 'chief'){
					$fileds = '`log`.`approver_user_id` as `manager_id`, count(*) as nums';
					$group = '`log`.`approver_user_id`';
					$where .= ' AND `log`.`approver_user_id` in (' . implode(',', $userId) . ')';
				}
			}else{
				if($role == 'creater'){
					$where .= ' AND `log`.`submiter_user_id`=' . $userId;
				}elseif($role == 'approver'){
					$where .= ' AND `log`.`approver_user_id`=' . $userId;
				}elseif($role == 'chief'){
					$where .= ' AND `log`.`approver_user_id`=' . $userId;
				}
			}
		}
		if($subjectId){
			$where .= ' AND `t1`.`subject_id`=' . $subjectId;
		}
		if($esType){
			$where .= ' AND `t1`.`type_id`=' . $esType;
		}
		if($status){
			if($role == 'creater' && $status == $this->_aStatus[ 'first_approved'] && !$searcher){
				$where .= ' AND `t1`.`status`>=' . $status . ' AND `t1`.`status`!=' . $this->_aStatus['is_sendback'];
			}else{
				$where .= ' AND `t1`.`status`=' . $status;
			}
		}
		if($categoryId){
			$where .= ' AND `t1`.`category_id`=' . $categoryId;
		}
		$oDboi = new DBOI();
		if(is_array($userId)){
			$aTotalInfo = $oDboi->fields($fileds)->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->groupby($group)->select();
		}else{
			$aTotalInfo = $oDboi->fields('count(DISTINCT `t1`.`id`) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->select();
		}
		if($aTotalInfo && !is_array($userId)){
			return $aTotalInfo[0]['nums'];
		}else{
			return $aTotalInfo;
		}
	}

	private function _getDetailCategoryById($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$aEsCategoryInfo = $oEsCategory->get('', array('id' => $categoryId));
		if(!$aEsCategoryInfo){
			return false;
		}
		$this->_detailCategoryList[] = $aEsCategoryInfo[0];
		if($aEsCategoryInfo[0]['parent_id']){
			$this->_getDetailCategoryById($aEsCategoryInfo[0]['parent_id']);
		}
		return $this->_detailCategoryList;
	}

	public function getDetailCategoryTree($categoryId){
		$this->_detailCategoryList = array();
		$aCategoryList = $this->_getDetailCategoryById($categoryId);
		if(!$aCategoryList){
			return false;
		}
		foreach($aCategoryList as $key => $aCategory){
			$aCategoryRefer[$aCategory['id']] = &$aCategoryList[$key];
		}
		foreach($aCategoryList as $key => $aCategory){
			if(!$aCategory['parent_id']){
				$aTree[] = &$aCategoryList[$key];
			}else{
				$parentId = $aCategory['parent_id'];
				$aParent = &$aCategoryRefer[$parentId];
				$aParent['child'] = &$aCategoryList[$key];
			}
		}
		return $aTree[0]['child'];
	}


	private function _getDetailEsList($role, $page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId, $esType, $status, $searcher = 0, $categoryId = 0){
		$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $action;
		$specialFlag = 0;
		if($categoryId && $status == 5 && !$startTime && $endTime > time() - 30){
			$grade = $this->_getEsGradeByCategoryId($categoryId);
			if($grade <= 4 || $grade > 9){
				$where = '`t1`.`category_id`=' . $categoryId;
				$specialFlag = 1;
			}
		}
		if($userId){
			if($role == 'creater'){
				$where .= ' AND `log`.`submiter_user_id`=' . $userId;
			}elseif($role == 'approver'){
				$where .= ' AND `log`.`approver_user_id`=' . $userId;
			}elseif($role == 'chief'){
				$where .= ' AND `log`.`approver_user_id`=' . $userId;
			}
		}
		if($subjectId){
			$where .= ' AND `t1`.`subject_id`=' . $subjectId;
		}
		if($esType){
			$where .= ' AND `t1`.`type_id`=' . $esType;
		}
		if($status){
			if($role == 'creater' && $status == $this->_aStatus['first_approved'] && !$searcher){
				$where .= ' AND `t1`.`status`>=' . $status . ' AND `t1`.`status`!=' . $this->_aStatus['is_sendback'];
			}else{
				$where .= ' AND `t1`.`status`=' . $status;
			}
		}
		if($categoryId){
			$where .= ' AND `t1`.`category_id`=' . $categoryId;
		}
		$offect = ($page - 1) * $pageSize;
		$oDboi = new DBOI();
		if($action == $this->_aAction['submit']){
			$aEsIdList = $oDboi->fields('DISTINCT `t1`.`id`')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->orderby('`t1`.`id` desc')->limit($offect, $pageSize)->select();
			if(!$aEsIdList){
				return $aEsIdList;
			}
			$aEsIds = array();
			foreach($aEsIdList as $aEsId){
				$aEsIds[] = $aEsId['id'];
			}
			$aEsList = $oDboi->table(T_ES_INDEX)->where(array('id' => array('in', $aEsIds)))->select();
		}else{
			if($specialFlag){
				$where = str_replace('`t1`.', '', $where);
				$aEsList = $oDboi->fields('*')->table(T_ES_INDEX)->where($where)->orderby('`id` desc')->limit($offect, $pageSize)->select();
			}else{
				$aEsList = $oDboi->fields('`t1`.*')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->orderby('`t1`.`id` desc')->limit($offect, $pageSize)->select();
			}
		}
		$esIds = '';
		foreach($aEsList as $aEs){
			$esIds .= $aEs['id'] . ',';
		}
		if($esIds){
			$esIds = substr($esIds, 0, -1);
			$aEsContentList = $oDboi->table(T_ES)->where(array('id' => array('in', $esIds)))->select();
			if($aEsContentList === false){
				return false;
			}
		}

		if($aEsList){
			$oEsCategory = new Model(T_ES_CATEGORY);
			$oEsLog = new Model(T_ES_LOG);
			$oManager = new Model(T_MANAGER);
			foreach($aEsList as &$aEs){
				foreach($aEsContentList as $aEsContent){
					if($aEsContent['id'] == $aEs['id']){
						$aEs['content_json'] = $aEsContent['content_json'];
						$aEs['content_text'] = $aEsContent['content_text'];
					}
				}
				$aEs['category_tree'] = $this->getDetailCategoryTree($aEs['category_id']);
				$aCategoryInfo = $oEsCategory->get('', array('id' => $aEs['category_id']));
				if($aCategoryInfo === false){
					return false;
				}elseif($aCategoryInfo){
					$aEs['category_name'] = $aCategoryInfo[0]['name'];
				}else{
					$aEs['category_name'] = '-';
				}
				$aEs['create_user_name'] = '---';
				$aEs['submit_time'] = '-- -- --';
				$aEs['approve_time'] = '-- -- --';
				$aEsLogList = $oEsLog->get('`submiter_user_id`,`operating_time`,`action`,`comment`', '`es_id`=' . $aEs['id'] . ' AND `action`<=' . $this->_aAction['not_pass_end_approved'] . ' AND `action`!=' . $this->_aAction['pass_end_approved'], '`id` ASC');
				if($aEsLogList === false){
					return false;
				}elseif($aEsLogList){
					foreach($aEsLogList as $aEsLog){
						if($aEsLog['action'] == $this->_aAction['create']){
							$aManagerInfo = $oManager->get('`name`', array('id' => $aEsLog['submiter_user_id']));
							if($aManagerInfo === false){
								return false;
							}elseif($aManagerInfo){
								$aEs['create_user_name'] = $aManagerInfo[0]['name'];
							}else{
								$aEs['create_user_name'] = '---';
							}
						}elseif($aEsLog['action'] == $this->_aAction['submit']){
							$aEs['submit_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
						}elseif($aEsLog['action'] == $this->_aAction['first_approved']){
							$aEs['approve_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
						}elseif($aEsLog['action'] == $this->_aAction['sendback']){
							$aEs['approve_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
							$aEs['sendback_reason'] = $aEsLog['comment'];
						}elseif($aEsLog['action'] == $this->_aAction['not_pass_end_approved']){
							$aEs['approve_time'] = date('Y-m-d H:i:s', $aEsLog['operating_time']);
							$aEs['sendback_reason'] = $aEsLog['comment'];
						}
					}
				}
			}
		}
		return $aEsList;
	}

	public function getEsCountByCreater($action, $startTime, $endTime, $userId, $subjectId = 0, $esType = 0, $status = 0, $searcher = 0){
		return $this->_getDetailEsCount('creater', $action, $startTime, $endTime, $userId, $subjectId, $esType, $status, $searcher);
	}

	public function getEsListByCreater($page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId = 0, $esType = 0, $status = 0, $searcher = 0){
		return $this->_getDetailEsList('creater', $page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId, $esType, $status, $searcher);
	}

	public function getEsCountByApprover($action, $startTime, $endTime, $userId, $subjectId = 0, $esType = 0, $status = 0){
		return $this->_getDetailEsCount('approver', $action, $startTime, $endTime, $userId, $subjectId, $esType, $status);
	}

	public function getEsListByApprover($page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId = 0, $esType = 0, $status = 0){
		return $this->_getDetailEsList('approver', $page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId, $esType, $status);
	}

	public function getEsCountByChiefEditer($action, $startTime, $endTime, $userId, $subjectId = 0, $esType = 0, $status = 0, $categoryId = 0){
		return $this->_getDetailEsCount('chief', $action, $startTime, $endTime, $userId, $subjectId, $esType, $status, 0, $categoryId);
	}

	public function getEsListByChiefEditer($page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId = 0, $esType = 0, $status = 0, $categoryId = 0){
		return $this->_getDetailEsList('chief', $page, $pageSize, $userId, $startTime, $endTime, $action, $subjectId, $esType, $status, 0, $categoryId);
	}

	public function getEsListByAppealStatus($appealStatus, $subjectId, $page = 1, $pageSize = 10, $typeId = 0){
		$offset = ($page - 1) * $pageSize;
		$oDboi = new DBOI();
		$field = '`t1`.*,`es`.`content_json`,`es`.`content_text`,`cate`.`name` as `category_name`';
		$where = '`t1`.`subject_id`=' . $subjectId . ' AND `t1`.`appeal_status`=' . $appealStatus;
		if($typeId){
			$where .= ' AND `t1`.`type_id`=' . $typeId;
		}
		$aAppealEsList = $oDboi->fields($field)->table(T_ES_INDEX)->leftjoin(T_ES, 'as `es` on `es`.`id`=`t1`.`id`')->leftjoin(T_ES_CATEGORY, 'as `cate` on `cate`.`id`=`t1`.`category_id`')->where($where)->limit($offset . ',' . $pageSize)->select();
		foreach($aAppealEsList as &$aAppealEs){
			$aEsLogList = $oDboi->table(T_ES_LOG)->where('`es_id`=' . $aAppealEs['id'])->orderby('`id` desc')->select();
			if(!$aEsLogList){
				return false;
			}
			$aAppealEs['approve_time'] = $aEsLogList[0]['operating_time'];
		}
		return $aAppealEsList;
	}

	public function getSimilarEsListByData($aData, $aExceptEsIds = array(), $setPercent = self::SIMILAR_PERCENT){
		$where = '';
		if(isset($aData['id'])){
			$where .= '`id`!=' . $aData['id'];
		}
		if(isset($aData['subject_id'])){
			if(strlen($where)){
				$where .= ' AND ';
			}
			$where .= '`subject_id`=' . $aData['subject_id'];
		}
		if(isset($aData['category_id'])){
			if(strlen($where)){
				$where .= ' AND ';
			}
			$where .= '`category_id`=' . $aData['category_id'];
		}
		if(isset($aData['type_id'])){
			if(strlen($where)){
				$where .= ' AND ';
			}
			$where .= '`type_id`=' . $aData['type_id'];
		}
		/*if(strlen($where)){
			$where .= ' AND ';
		}
		$where .= '`status` in (' . $this->_aStatus['first_approved'] . ',' . $this->_aStatus['pass_end_approved'] . ')';*/
		if($aExceptEsIds){
			$where .= ' AND `id` not in (' . implode(',', $aExceptEsIds) . ')';
		}
		$aSimilarEsList = array();
		$aEsList = $this->getEsList('id,status', $where);
		if($aEsList){
			foreach($aEsList as $aEs){
				if($setPercent < 100){
					similar_text($aEs['content_text'], $aData['content_text'], $percent);
					if($percent > $setPercent){
						$aSimilarEsList[] = $aEs;
					}
				}else{
					if($aEs['content_text'] == $aData['content_text']){
						$aSimilarEsList[] = $aEs;
					}
				}
			}
		}
		return $aSimilarEsList;
	}

	public function addEsCategory($aData){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$esCategoryId = $oEsCategory->add($aData);
		return $esCategoryId;
	}

	public function getCategoryInfoByCategoryId($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$aCategoryInfo = $oEsCategory->get('', array('id' => $categoryId));
		if($aCategoryInfo){
			return $aCategoryInfo[0];
		}else{
			return $aCategoryInfo;
		}
	}

	public function getCategoryListByCategoryId($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$aCategoryInfo = $oEsCategory->get('', array('id' => $categoryId));
		$this->_categoryList[] = $aCategoryInfo[0];
		$childCount = $oEsCategory->count('parent_id=' . $categoryId);
		if($childCount){
			$aChildList = $oEsCategory->get('', 'parent_id=' . $categoryId, 'orders asc');
			foreach($aChildList as $aChild){
				$this->getCategoryListByCategoryId($aChild['id']);
			}
		}
		return $this->_categoryList;
	}

	public function getCategoryDetailedListBySubjectId($subjectId){
		$aCateGoryList = $this->getCategoryListBySubjectId($subjectId);
		foreach($aCateGoryList as $key=>$aCateGory){
			$aCateGoryList[$key]['not_final_dir'] = 0;
			foreach($aCateGoryList as $aCateGory2){
				if($aCateGory['id'] == $aCateGory2['parent_id']){
					$aCateGoryList[$key]['not_final_dir'] = 1;
					break;
				}
			}
		}
		$oEsIndex = new Model(T_ES_INDEX);
		$fields = '`category_id`,`type_id`,`status`,`appeal_status`,count(*) as `nums`';
		$where = '`subject_id`=' . $subjectId;
		$group = '`category_id`,`type_id`,`status`,`appeal_status`';
		$aEsCountList = $oEsIndex->get($fields, $where, '', '', '', $group);
		$aCateGoryReferList = array();
		foreach($aCateGoryList as $aCateGory){
			$aCateGoryReferList[$aCateGory['id']] = $aCateGory;
		}
		foreach($aCateGoryList as $key => $aCateGory){
			if($aCateGory['parent_id']){
				$aCateGoryList[$key]['parent_name'] = $aCateGoryReferList[$aCateGory['parent_id']]['name'];
			}else{
				$aCateGoryList[$key]['parent_name'] = '--';
			}
			$aCateGoryList[$key]['select_es'] = 0;
			$aCateGoryList[$key]['judge_es'] = 0;
			$aCateGoryList[$key]['wait_appeal'] = 0;
			$aCateGoryList[$key]['wait_end_appeal'] = 0;
			$aCateGoryList[$key]['pass_end_appeal'] = 0;
			$aCateGoryList[$key]['all_es'] = 0;
			foreach($aEsCountList as $aEsCount){
				if($aEsCount['category_id'] == $aCateGory['id']){
					if($aEsCount['status'] == 5 && ($aEsCount['type_id'] == 1 || $aEsCount['type_id'] == 2)){	//正式题库的判断题数量
						$aCateGoryList[$key]['select_es'] += $aEsCount['nums'];
					}elseif($aEsCount['status'] == 5 && $aEsCount['type_id'] == 3){	//正式题库的选择题数量
						$aCateGoryList[$key]['judge_es'] += $aEsCount['nums'];
					}

					//待初审的题目数量 ---未提交的，已发回未申述的,已发回申述失败的
					if($aEsCount['status'] == 1 || $aEsCount['status'] == 2 || ($aEsCount['status'] == 4 && ($aEsCount['appeal_status'] == 1 || $aEsCount['appeal_status'] == 4))){
						$aCateGoryList[$key]['wait_appeal'] += $aEsCount['nums'];
					//待复核的题目数量 ---初审通过，已发回并在申述中的,复核未通过的
					}elseif($aEsCount['status'] == 3 || ($aEsCount['status'] == 4 && $aEsCount['appeal_status'] == 2) || $aEsCount['status'] == 6){
						$aCateGoryList[$key]['wait_end_appeal'] += $aEsCount['nums'];
					//已复核的数量
					}elseif($aEsCount['status'] == 5){
						$aCateGoryList[$key]['pass_end_appeal'] += $aEsCount['nums'];
					}

					//总题目数 ---除了作废的
					if($aEsCount['status'] != 7){
						$aCateGoryList[$key]['all_es'] += $aEsCount['nums'];
					}
				}
			}
		}
		return $aCateGoryList;
	}

	public function getCategoryListBySubjectId($subjectId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		/*$aSubjectRootInfo = $oEsCategory->get('`id`', '`parent_id`=0 and `subject_id`=' . $subjectId, 'orders ASC');
		if($aSubjectRootInfo){
			return $this->getCategoryListByCategoryId($aSubjectRootInfo[0]['id']);
		}else{
			return $aSubjectRootInfo;
		}*/
		$aCategoryList = $oEsCategory->get('', '`subject_id`=' . $subjectId, 'orders ASC');
		return $aCategoryList;
	}

	/**
	 +----------------------------------------------------------
	 * 把返回的数据集转换成Tree
	 +----------------------------------------------------------
	 * @access public
	 +----------------------------------------------------------
	 * @param array $list 要转换的数据集
	 * @param string $pid parent标记字段
	 * @param string $level level标记字段
	 +----------------------------------------------------------
	 * @return array
	 +----------------------------------------------------------
	 */
	function getCategoryTree($categoryId){
		$this->getCategoryListByCategoryId($categoryId);
		$aCategoryList = $this->_categoryList;
		// 创建Tree
		$aTree = array();
		if(is_array($aCategoryList)){
			// 创建基于主键的数组引用
			$refer = array();
			foreach ($aCategoryList as $key => $data){
				$refer[$data['id']] = &$aCategoryList[$key];
			}
			foreach ($aCategoryList as $key => $data){
				if($categoryId == $data['id']){
					$aTree[] = &$aCategoryList[$key];
				}else{
					$parentId = $data['parent_id'];
					if (isset($refer[$parentId])){
						$parent = &$refer[$parentId];
						$parent['child'][] = &$aCategoryList[$key];
					}
				}
			}
		}
		return $aTree;
	}

	public function setCategory($aData){
		$oCategory = new Model(T_ES_CATEGORY);
		$row = $oCategory->update($aData, array('id' => $aData['id']));
		return $row;
	}

	public function isExistRootCategory($subjectId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$count = $oEsCategory->count('`subject_id`=' . $subjectId . ' AND parent_id=0');
		return $count;
	}

	public function isExistEsInCategory($categoryId){
		$oEsIndex = new Model(T_ES_INDEX);
		$count = $oEsIndex->count('`category_id`=' . $categoryId);
		return $count;
	}

	public function isExistSubCategory($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$count = $oEsCategory->count('`parent_id`=' . $categoryId);
		return $count;
	}

	public function isExistEsNeedFinishByCreaterId($userId){
		$oDboi = new DBOI();
		$where = '`t1`.`status`=4 AND `t1`.`appeal_status`!=2 AND `log`.`submiter_user_id`=' . $userId . ' AND `log`.`action`=4 AND `log`.`operating_time`<' . (time() - 86400);
		$aCount = $oDboi->fields('count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.`es_id`')->where($where)->select();
		if($aCount){
			return $aCount[0]['nums'];
		}else{
			return $aCount;
		}
	}

	public function isExistEsNeedFinishByApproverId($userId){
		$oDboi = new DBOI();
		$where = '`t1`.`status`=6 AND `log`.`submiter_user_id`=' . $userId . ' AND `log`.`action`=6 AND `log`.`operating_time`<' . (time() - 86400);
		$aCount = $oDboi->fields('count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.`es_id`')->where($where)->select();
		if($aCount){
			return $aCount[0]['nums'];
		}else{
			return $aCount;
		}
	}

	public function appealByEsId($esId){
		$oEsIndex = new Model(T_ES_INDEX);
		$result = $oEsIndex->update(array('appeal_status' => 2), array('id' => $esId));
		return $result;
	}

	public function appealFailed($esId){
		$oEsIndex = new Model(T_ES_INDEX);
		$result = $oEsIndex->update(array('appeal_status' => 4), array('id' => $esId));
		return $result;
	}

	public function appealSucceed($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//改变题目申诉状态为成功,强制发回人通审该题,复核也通过
		$result = $oDboi->table(T_ES_INDEX)->data(array('appeal_status' => 3, 'status' => $this->_aStatus['pass_end_approved']))->where(array('id' => $aData['id']))->update();
		if(!$result){
			return $result;
		}

		//题目的科目、年级和类型
		$aEsInfo = $oDboi->table(T_ES_INDEX)->fields('`subject_id`,`category_id`,`type_id`')->where(array('id' => $aData['id']))->select();
		if(!$aEsInfo){
			$oDboi->rollBack();
			return false;
		}
		$grade = $this->_getEsGradeByCategoryId($aEsInfo[0]['category_id']);
		if(!$grade){
			$oDboi->rollBack();
			return false;
		}
		if($aEsInfo[0]['subject_id'] == 1){
			$money = $this->_aChineseRate[$grade][$aEsInfo[0]['type_id']];
		}elseif($aEsInfo[0]['subject_id'] == 2){
			$money = $this->_aMathRate[$grade][$aEsInfo[0]['type_id']];
		}elseif($aEsInfo[0]['subject_id'] == 3){
			$money = $this->_aEnglishRate[$grade][$aEsInfo[0]['type_id']];
		}elseif($aEsInfo[0]['subject_id'] == 4){
			$money = $this->_aChineseRate[$grade][$aEsInfo[0]['type_id']];
		}else{
			$oDboi->rollBack();
			return false;
		}

		//得到该题目被发回次数
		$aEsSendbackCount = $oDboi->fields('count(*) as `nums`')->table(T_ES_LOG)->where('`es_id`=' . $aData['id']  . ' AND `action`=' . $this->_aAction['sendback'])->select();
		if(!$aEsSendbackCount){
			$oDboi->rollBack();
			return false;
		}
		if($aEsSendbackCount[0]['nums'] > 3){
			$createrUb = round(($money * 100) * 0.1);
		}else{
			$createrUb = round((70 - $aEsSendbackCount[0]['nums'] * 20) * $money);
		}
		$approverUb = $money * 100 - $createrUb - 100;
		//给用户加减UB
		$aCreaterInfo = $oDboi->table(T_MANAGER)->where(array('id' => $aData['submiter_user_id']))->select();
		if(!$aCreaterInfo){
			$oDboi->rollBack();
			return false;
		}
		$result = $oDboi->table(T_MANAGER)->data(array('ub' => $aCreaterInfo[0]['ub'] + $createrUb))->where(array('id' => $aData['submiter_user_id']))->update();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		$aApproverInfo = $oDboi->table(T_MANAGER)->where(array('id' => $aData['approver_user_id']))->select();
		if(!$aApproverInfo){
			$oDboi->rollBack();
			return false;
		}
		$result = $oDboi->table(T_MANAGER)->data(array('ub' => $aApproverInfo[0]['ub'] + $approverUb))->where(array('id' => $aData['approver_user_id']))->update();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}

		//写日志
		$aSubmitLogData = array();
		$aPassFirstApproverLogData = array();
		$aPassEndApproverLogData = array();
		$aSubmitLogData['es_id'] = $aPassFirstApproverLogData['es_id'] = $aPassEndApproverLogData['es_id'] = $aData['id'];
		$aLogFields = array(
			'subject_id',
			'submiter_user_id',
			'approver_user_id',
			'operating_time',
			'comment',
		);
		foreach($aLogFields as $field){
			if(isset($aData[$field])){
				$aSubmitLogData[$field] = $aData[$field];
				$aPassFirstApproverLogData[$field] = $aData[$field];
				$aPassEndApproverLogData[$field] = $aData[$field];
			}
		}
		$aSubmitLogData['action'] = $this->_aAction['submit'];
		$aPassFirstApproverLogData['action'] = $this->_aAction['first_approved'];
		$aPassEndApproverLogData['action'] = $this->_aAction['pass_end_approved'];
		$aPassEndApproverLogData['submiter_user_id'] = $aData['approver_user_id'];
		$aPassEndApproverLogData['approver_user_id'] = $aData['chief_user_id'];
		$aLogDatas = array($aSubmitLogData, $aPassFirstApproverLogData, $aPassEndApproverLogData);
		$result = $oDboi->table(T_ES_LOG)->data($aLogDatas)->insert();
		if(!$result){
			$oDboi->rollBack();
		}
		return $result;
	}

	private function _getEsGradeByCategoryId($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$aEsCategoryInfo = $oEsCategory->get('', array('id' => $categoryId));
		if(!$aEsCategoryInfo){
			return false;
		}else{
			$this->_aCategory[] = $aEsCategoryInfo[0];
			if($aEsCategoryInfo[0]['parent_id']){
				return $this->_getEsGradeByCategoryId($aEsCategoryInfo[0]['parent_id']);
			}else{
				if(count($this->_aCategory) >= 2){
					$aGradeCategoryInfo = array_slice($this->_aCategory, -2, 1);
					$categoryName = $aGradeCategoryInfo[0]['name'];
					if(is_int(strpos($categoryName, '一年级'))){
						return 1;
					}elseif(is_int(strpos($categoryName, '二年级'))){
						return 2;
					}elseif(is_int(strpos($categoryName, '三年级'))){
						return 3;
					}elseif(is_int(strpos($categoryName, '四年级'))){
						return 4;
					}elseif(is_int(strpos($categoryName, '五年级'))){
						return 5;
					}elseif(is_int(strpos($categoryName, '六年级'))){
						return 6;
					}elseif(is_int(strpos($categoryName, '七年级'))){
						return 7;
					}elseif(is_int(strpos($categoryName, '八年级'))){
						return 8;
					}elseif(is_int(strpos($categoryName, '九年级'))){
						return 9;
					}elseif(is_int(strpos($categoryName, '高一'))){
						return 10;
					}elseif(is_int(strpos($categoryName, '高二'))){
						return 11;
					}elseif(is_int(strpos($categoryName, '高三'))){
						return 12;
					}else{
						return false;
					}
				}else{
					return false;
				}
			}
		}
	}

	public function passEndApprove($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//改变题目状态
		$result = $oDboi->table(T_ES_INDEX)->data(array('status' => $this->_aStatus['pass_end_approved']))->where(array('id' => $aData['id']))->update();
		if(!$result){
			myLog('改变是状态失败');
			return false;
		}
		//题目的科目、年级和类型
		$aEsInfo = $oDboi->table(T_ES_INDEX)->fields('`subject_id`,`category_id`,`type_id`')->where(array('id' => $aData['id']))->select();
		if(!$aEsInfo){
			myLog('找不到要审核的题目');
			$oDboi->rollBack();
			return false;
		}
		$grade = $this->_getEsGradeByCategoryId($aEsInfo[0]['category_id']);
		if(!$grade){
			myLog('找不到复核题目所在目录的年级');
			$oDboi->rollBack();
			return false;
		}
		if($aEsInfo[0]['subject_id'] == 1){
			$money = $this->_aChineseRate[$grade][$aEsInfo[0]['type_id']];
		}elseif($aEsInfo[0]['subject_id'] == 2){
			$money = $this->_aMathRate[$grade][$aEsInfo[0]['type_id']];
		}elseif($aEsInfo[0]['subject_id'] == 3){
			$money = $this->_aEnglishRate[$grade][$aEsInfo[0]['type_id']];
		}elseif($aEsInfo[0]['subject_id'] == 4){
			$money = $this->_aChineseRate[$grade][$aEsInfo[0]['type_id']];
		}else{
			myLog('复核的题目科目无效');
			$oDboi->rollBack();
			return false;
		}

		//题目被发回次数
		$aSendbackInfo = $oDboi->fields('count(*) as `nums`')->table(T_ES_LOG)->where('`es_id`=' . $aData['id'] . ' AND `action`=' . $this->_aAction['sendback'])->select();
		if(!$aSendbackInfo){
			myLog('更新题目发回次数失败');
			$oDboi->rollBack();
			return false;
		}
		if($aSendbackInfo[0]['nums'] > 3){
			$createrUb = round(($money * 100) * 0.1);
		}else{
			$createrUb = round((70 - $aSendbackInfo[0]['nums'] * 20) * $money);
		}
		//题目没通过复核次数
		$aNotPassEndApproveInfo = $oDboi->fields('count(*) as `nums`')->table(T_ES_LOG)->where('`es_id`=' . $aData['id'] . ' AND `action`=' . $this->_aAction['not_pass_end_approved'])->select();
		if(!$aNotPassEndApproveInfo){
			myLog('更新未通过复核次数失败');
			$oDboi->rollBack();
			return false;
		}
		$approverUb = round(($money * 100 - $createrUb) - $money * 100 * $aNotPassEndApproveInfo[0]['nums'] * 0.2);
		if($approverUb < $money * 100 * 0.1){
			$approverUb = round($money * 100 * 0.1);
		}
		//为用户加u币
		$aCreaterInfo = $oDboi->table(T_MANAGER)->where(array('id' => $aData['submiter_user_id']))->select();
		if(!$aCreaterInfo){
			$oDboi->rollBack();
			return false;
		}
		$result = $oDboi->table(T_MANAGER)->data(array('ub' => $aCreaterInfo[0]['ub'] + $createrUb))->where(array('id' => $aData['submiter_user_id']))->update();
		if(!$result){
			myLog('复核后为出题用户增加U币失败');
			$oDboi->rollBack();
			return false;
		}
		$aApproverInfo = $oDboi->table(T_MANAGER)->where(array('id' => $aData['approver_user_id']))->select();
		if(!$aApproverInfo){
			$oDboi->rollBack();
			return false;
		}
		$result = $oDboi->table(T_MANAGER)->data(array('ub' => $aApproverInfo[0]['ub'] + $approverUb))->where(array('id' => $aData['approver_user_id']))->update();
		if(!$result){
			myLog('复核后为审核用户增加U币失败');
			$oDboi->rollBack();
			return false;
		}
		//写日志
		$aLogData = array();
		$aLogData['es_id'] = $aData['id'];
		$aLogFields = array(
			'subject_id',
			'operating_time',
			'action',
			'comment',
		);
		foreach($aLogFields as $field){
			if(isset($aData[$field])){
				$aLogData[$field] = $aData[$field];
			}
		}
		$aLogData['submiter_user_id'] = $aData['approver_user_id'];
		$aLogData['approver_user_id'] = $aData['chief_user_id'];
		$result = $oDboi->table(T_ES_LOG)->data($aLogData)->insert();
		if(!$result){
			myLog('增加复核日志失败');
			$oDboi->rollBack();
		}
		return $result;
	}

	public function deleteCategory($categoryId){
		$oEsCategory = new Model(T_ES_CATEGORY);
		$row = $oEsCategory->delete(array('id' => $categoryId));
		return $row;
	}

	public function getStatisticsForCreater($startTime, $endTime, $userId, $subjectId, $typeId = 0){
		$createNums = $this->_getDetailEsCount('creater', $this->_aAction['create'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		$submitTimes = $this->_getDetailEsCount('creater', $this->_aAction['submit'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		$passApproveNums = $this->_getDetailEsCount('creater', $this->_aAction['first_approved'], $startTime, $endTime, $userId, $subjectId, $typeId, $this->_aStatus['first_approved']);
		$sendbackTimes = $this->_getDetailEsCount('creater', $this->_aAction['sendback'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//有效申诉数量
		if(is_array($userId)){
			$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $this->_aAction['first_approved'] . ' AND `log`.`submiter_user_id` in (' . implode(',', $userId) . ') AND `t1`.`subject_id`=' . $subjectId . ' AND `t1`.`appeal_status`=3';
		}else{
			$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $this->_aAction['first_approved'] . ' AND `log`.`submiter_user_id`=' . $userId . ' AND `t1`.`subject_id`=' . $subjectId . ' AND `t1`.`appeal_status`=3';
		}

		if($typeId){
			$where .= ' AND `t1`.`type_id`=' . $typeId;
		}
		$oDboi = new DBOI();
		if(is_array($userId)){
			$aEffectiveAppealNums = $oDboi->fields('`log`.`submiter_user_id` as `manager_id`,count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->groupby('`log`.`submiter_user_id`')->select();
			$aReturnArr = array();
			foreach($userId as $managerId){
				$aTempArr = array();
				$aTempArr['id'] = $managerId;
				$aTempArr['create_nums'] = 0;
				$aTempArr['submit_times'] = 0;
				$aTempArr['pass_approve_nums'] = 0;
				$aTempArr['sendback_times'] = 0;
				$aTempArr['effective_appeal_nums'] = 0;
				foreach($createNums as $aCreateNum){
					if($aCreateNum['manager_id'] == $managerId){
						$aTempArr['create_nums'] = $aCreateNum['nums'];
						break;
					}
				}
				foreach($submitTimes as $aSubmitTime){
					if($aSubmitTime['manager_id'] == $managerId){
						$aTempArr['submit_times'] = $aSubmitTime['nums'];
						break;
					}
				}
				foreach($passApproveNums as $aPassApproveNum){
					if($aPassApproveNum['manager_id'] == $managerId){
						$aTempArr['pass_approve_nums'] = $aPassApproveNum['nums'];
						break;
					}
				}
				foreach($sendbackTimes as $aSendbackTime){
					if($aSendbackTime['manager_id'] == $managerId){
						$aTempArr['sendback_times'] = $aSendbackTime['nums'];
						break;
					}
				}
				foreach($aEffectiveAppealNums as $aEffectiveAppealNum){
					if($aEffectiveAppealNum['manager_id'] == $managerId){
						$aTempArr['effective_appeal_nums'] = $aEffectiveAppealNum['nums'];
						break;
					}
				}
				$aReturnArr[] = $aTempArr;
			}
			return $aReturnArr;
		}else{
			$aEffectiveAppealNums = $oDboi->fields('count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->select();
			return array(
				'create_nums' => $createNums,
				'submit_times' => $submitTimes,
				'pass_approve_nums' => $passApproveNums,
				'sendback_times' => $sendbackTimes,
				'effective_appeal_nums'	=> $aEffectiveAppealNums[0]['nums'],
			);
		}
	}

	public function getStatisticsForApprove($startTime, $endTime, $userId, $subjectId = 0, $typeId = 0){
		//通过初审数量
		$passFirstApproveNums = $this->_getDetailEsCount('approver', $this->_aAction['first_approved'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//发回次数
		$sendbackTimes = $this->_getDetailEsCount('approver', $this->_aAction['sendback'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//通过复核数量
		$passEndApproveNums = $this->_getDetailEsCount('creater', $this->_aAction['pass_end_approved'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//复核不通过次数
		$notPassEndApproveTimes = $this->_getDetailEsCount('creater', $this->_aAction['not_pass_end_approved'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//被有效申诉数量
		if(is_array($userId)){
			$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $this->_aAction['pass_end_approved'] . ' AND `log`.`submiter_user_id` in (' . implode(',', $userId) . ') AND `t1`.`subject_id`=' . $subjectId . ' AND `t1`.`appeal_status`=3';
			if($typeId){
				$where .= ' AND `t1`.`type_id`=' . $typeId;
			}
			$oDboi = new DBOI();
			$aEffectiveAppealNums = $oDboi->fields('`log`.`submiter_user_id` as `manager_id`,count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->groupby('`log`.`submiter_user_id`')->select();
			$aReturnArr = array();
			foreach($userId as $managerId){
				$aTempArr = array();
				$aTempArr['id'] = $managerId;
				$aTempArr['pass_first_approve_nums'] = 0;
				$aTempArr['sendback_times'] = 0;
				$aTempArr['pass_end_approve_nums'] = 0;
				$aTempArr['not_pass_end_approve_times'] = 0;
				$aTempArr['effective_appeal_nums'] = 0;
				foreach($passFirstApproveNums as $aPassFirstApproveNum){
					if($aPassFirstApproveNum['manager_id'] == $managerId){
						$aTempArr['pass_first_approve_nums'] = $aPassFirstApproveNum['nums'];
						break;
					}
				}
				foreach($sendbackTimes as $aSendbackTime){
					if($aSendbackTime['manager_id'] == $managerId){
						$aTempArr['sendback_times'] = $aSendbackTime['nums'];
						break;
					}
				}
				foreach($passEndApproveNums as $aPassEndApproveNum){
					if($aPassEndApproveNum['manager_id'] == $managerId){
						$aTempArr['pass_end_approve_nums'] = $aPassEndApproveNum['nums'];
						break;
					}
				}
				foreach($notPassEndApproveTimes as $aNotPassEndApproveTime){
					if($aNotPassEndApproveTime['manager_id'] == $managerId){
						$aTempArr['not_pass_end_approve_times'] = $aNotPassEndApproveTime['nums'];
						break;
					}
				}
				foreach($aEffectiveAppealNums as $aEffectiveAppealNum){
					if($aEffectiveAppealNum['manager_id'] == $managerId){
						$aTempArr['effective_appeal_nums'] = $aEffectiveAppealNum['nums'];
						break;
					}
				}
				$aReturnArr[] = $aTempArr;
			}
			return $aReturnArr;
		}else{
			$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $this->_aAction['pass_end_approved'] . ' AND `log`.`submiter_user_id`=' . $userId . ' AND `t1`.`subject_id`=' . $subjectId . ' AND `t1`.`appeal_status`=3';
			if($typeId){
				$where .= ' AND `t1`.`type_id`=' . $typeId;
			}
			$oDboi = new DBOI();
			$aEffectiveAppealNums = $oDboi->fields('count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->select();
			return array(
				'pass_first_approve_nums'	=> $passFirstApproveNums,
				'sendback_times'	=> $sendbackTimes,
				'pass_end_approve_nums'	=> $passEndApproveNums,
				'not_pass_end_approve_times'	=> $notPassEndApproveTimes,
				'effective_appeal_nums'	=> $aEffectiveAppealNums[0]['nums'],
			);
		}
	}

	public function getAllStatisticsForChiefEdit($startTime, $endTime,$subjectId = 0, $typeId = 0){
		//创建的题目数量
		$createNums = $this->_getDetailEsCount('creater', $this->_aAction['create'], $startTime, $endTime, 0, $subjectId, $typeId, 0);
		//通过初审的数量
		$passFirstApproveNums = $this->_getDetailEsCount('creater', $this->_aAction['first_approved'], $startTime, $endTime, 0, $subjectId, $typeId, 0);
		//发回次数
		$sendbackTimes = $this->_getDetailEsCount('approver', $this->_aAction['sendback'], $startTime, $endTime, 0, $subjectId, $typeId, 0);
		//通过复核数量
		$passEndApproveNums = $this->_getDetailEsCount('creater', $this->_aAction['pass_end_approved'], $startTime, $endTime, 0, $subjectId, $typeId, 0);
		//复核不通过次数
		$notPassEndApproveTimes = $this->_getDetailEsCount('creater', $this->_aAction['not_pass_end_approved'], $startTime, $endTime, 0, $subjectId, $typeId, 0);
		//作废数量blank_out
		$blankOutNums = $this->_getDetailEsCount('creater', $this->_aAction['blank_out'], $startTime, $endTime, 0, $subjectId, $typeId, $this->_aStatus['blank_out']);
		//申诉有效数量
		$where = '`log`.`operating_time` >=' . $startTime . ' AND ' . '`log`.`operating_time` <=' . $endTime . ' AND `log`.`action`=' . $this->_aAction['pass_end_approved'] . ' AND `t1`.`subject_id`=' . $subjectId . ' AND `t1`.`appeal_status`=3';
		if($typeId){
			$where .= ' AND `t1`.`type_id`=' . $typeId;
		}
		$oDboi = new DBOI();
		$aEffectiveAppealNums = $oDboi->fields('count(*) as nums')->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `t1`.`id`=`log`.es_id')->where($where)->select();
		return array(
			'create_nums' => $createNums,
			'pass_first_approve_nums' => $passFirstApproveNums,
			'sendback_times' => $sendbackTimes,
			'pass_end_approve_nums' => $passEndApproveNums,
			'not_pass_end_approve_times' => $notPassEndApproveTimes,
			'blank_out_nums' => $blankOutNums,
			'effective_appeal_nums' => $aEffectiveAppealNums[0]['nums'],
		);
	}

	public function getStatisticsForChiefEdit($startTime, $endTime, $userId, $subjectId = 0, $typeId = 0){
		//复核通过数量
		$passEndApproveNums = $this->_getDetailEsCount('chief', $this->_aAction['pass_end_approved'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//复核不通过次数
		$notPassEndApproveTimes = $this->_getDetailEsCount('chief', $this->_aAction['not_pass_end_approved'], $startTime, $endTime, $userId, $subjectId, $typeId, 0);
		//作废数量blank_out
		$blankOutNums = $this->_getDetailEsCount('chief', $this->_aAction['blank_out'], $startTime, $endTime, $userId, $subjectId, $typeId, $this->_aStatus['blank_out']);
		if(is_array($userId)){
			$aReturnArr = array();
			foreach($userId as $managerId){
				$aTempArr = array();
				$aTempArr['id'] = $managerId;
				$aTempArr['pass_end_approve_nums'] = 0;
				$aTempArr['not_pass_end_approve_times'] = 0;
				$aTempArr['blank_out_nums'] = 0;
				foreach($passEndApproveNums as $aPassEndApproveNum){
					if($aPassEndApproveNum['manager_id'] == $managerId){
						$aTempArr['pass_end_approve_nums'] = $aPassEndApproveNum['nums'];
						break;
					}
				}
				foreach($notPassEndApproveTimes as $aNotPassEndApproveTime){
					if($aNotPassEndApproveTime['manager_id'] == $managerId){
						$aTempArr['not_pass_end_approve_times'] = $aNotPassEndApproveTime['nums'];
						break;
					}
				}
				foreach($blankOutNums as $aBlankOutNum){
					if($aBlankOutNum['manager_id'] == $managerId){
						$aTempArr['blank_out_nums'] = $aBlankOutNum['nums'];
						break;
					}
				}
				$aReturnArr[] = $aTempArr;
			}
			return $aReturnArr;
		}else{
			return array(
				'pass_end_approve_nums' => $passEndApproveNums,
				'not_pass_end_approve_times' => $notPassEndApproveTimes,
				'blank_out_nums' => $blankOutNums,
			);
		}
	}

	private function _getMySendbackEsList($userId, $subjectId, $type, $offSet, $pageSize){
		$oEsLog = new Model(T_ES_LOG);
		//我发回的题目id集
		$aMySendbackEsIds = $oEsLog->get('distinct `es_id`', '`approver_user_id`=' . $userId . ' AND `action`=' . $this->_aAction['sendback']);
		if($aMySendbackEsIds === false){
			return false;
		}elseif(!$aMySendbackEsIds){
			return array('is_exist' => false, 'es_list' => $aMySendbackEsIds);
		}elseif($aMySendbackEsIds){
			$mySendbackEsIds = '';
			foreach($aMySendbackEsIds as $aMySendbackEsId){
				$mySendbackEsIds .= $aMySendbackEsId['es_id'] . ',';
			}
			$mySendbackEsIds = substr($mySendbackEsIds, 0, -1);
			$where = '`status`=' . $this->_aStatus['wait_approve'] . ' AND `id` in (' . $mySendbackEsIds . ')';
			$oEsIndex = new Model(T_ES_INDEX);
			$count = $oEsIndex->count($where);
			if($count === false){
				return false;
			}elseif(!$count){
				return array('is_exist' => false, 'es_list' => array());
			}else{
				$where = '`status`=' . $this->_aStatus['wait_approve'] . ' AND `subject_id`=' . $subjectId . ' AND `id` in (' . $mySendbackEsIds . ')';
				if($type){
					$where .= ' AND `type_id`=' . $type;
				}
				$aSubmitAfterSendbackEsList = $this->getEsList('', $where, '', $offSet, $pageSize);
				return array('is_exist' => true, 'es_list' => $aSubmitAfterSendbackEsList);
			}
		}
	}

	private function _getLockedEsList($userId, $subjectId, $type, $offSet, $pageSize){
		$oApproverEsRelation = new Model(T_APPROVER_ES_RELATION);
		$result = $oApproverEsRelation->delete('`lock_time`<' . (time() - 1800));
		if($result === false){
			return false;
		}
		$aEsIds = $oApproverEsRelation->get('`es_id`', '`lock_user_id`=' . $userId);
		if($aEsIds === false){
			return false;
		}elseif(!$aEsIds){
			//自动为审核人锁定题目
			$aInApproverEsRelationEsIds = $oApproverEsRelation->get('`es_id`');	//被锁定的题目id集
			$inApproverEsRelationEsIds = '';
			if($aInApproverEsRelationEsIds === false){
				return false;
			}elseif($aInApproverEsRelationEsIds){
				foreach($aInApproverEsRelationEsIds as $aInApproverEsRelationEsId){
					$inApproverEsRelationEsIds .= $aInApproverEsRelationEsId['es_id'] . ',';
				}
			}
			$oEsLog = new Model(T_ES_LOG);
			$aSendBackedEsIds = $oEsLog->get('distinct `es_id`', '`action`=' . $this->_aAction['sendback']); //发回过的题目id集
			$senbackedEsIds = '';
			if($aSendBackedEsIds === false){
				return false;
			}elseif($aSendBackedEsIds){
				foreach($aSendBackedEsIds as $aSendBackedEsId){
					$senbackedEsIds .= $aSendBackedEsId['es_id'] . ',';
				}
			}
			$where = '`subject_id`=' . $subjectId . ' AND `status`=' . $this->_aStatus['wait_approve'];
			//为170,171这两个账户做特殊处理
			if($userId == 170 || $userId == 171){
				//高中英语总目录为2536
				$this->getCategoryListByCategoryId(2536);
				$aCategoryList = $this->_categoryList;
				$this->_categoryList = [];
				$aCategoryIds = [];
				foreach($aCategoryList as $aCategory){
					$aCategoryIds[] = $aCategory['id'];
				}
				if($userId == 170){
					$where .= ' AND `category_id` in (' . implode(',', $aCategoryIds) . ')';
				}else{
					$where .= ' AND `category_id` not in (' . implode(',', $aCategoryIds) . ')';
				}
			}
			if($type){
				$where .= ' AND `type_id`=' . $type;
			}
			$exceptEsIds = $inApproverEsRelationEsIds . $senbackedEsIds;
			if($exceptEsIds){
				$exceptEsIds = substr($exceptEsIds, 0, -1);
				$where .= ' AND `id` not in (' . $exceptEsIds . ')';
			}
			$aWaitApproveEsList = $this->getEsList('', $where, '', 0, 30); //查出30题
			if(!$aWaitApproveEsList){
				return $aWaitApproveEsList;
			}
			$aAddData = array();
			$currentTime = time();
			//将查出的题目id存入审核人和题目关系表中
			foreach($aWaitApproveEsList as $aWaitApproveEs){
				$aOneRecord = array();
				$aOneRecord['es_id'] = $aWaitApproveEs['id'];
				$aOneRecord['lock_user_id'] = $userId;
				$aOneRecord['lock_time'] = $currentTime;
				$aAddData[] = $aOneRecord;
			}
			$approverEsRelationId = $oApproverEsRelation->add($aAddData);
			if($approverEsRelationId === false){
				return false;
			}
			return array_slice($aWaitApproveEsList, 0, $pageSize);
		}else{
			//查出被锁定的题目
			$esIds = '';
			foreach($aEsIds as $aEsId){
				$esIds .= $aEsId['es_id'] . ',';
			}
			$esIds = substr($esIds, 0, -1);
			$where = '`id` in (' . $esIds . ') AND `subject_id`=' . $subjectId . ' AND `status`=' . $this->_aStatus['wait_approve'];
			if($type){
				$where .= ' AND `type_id`=' . $type;
			}
			$aLockedEsList = $this->getEsList('', $where, '', $offSet, $pageSize);
			return $aLockedEsList;
		}

	}

	public function getWaitApproveEsByApprover($userId, $subjectId, $page, $pageSize, $type = 0){
		$offSet = ($page - 1) * $pageSize;
		//已发回再提交的题目
		$aSubmitAfterSendbackEsList = $this->_getMySendbackEsList($userId, $subjectId, $type, $offSet, $pageSize);
		if($aSubmitAfterSendbackEsList === false){
			return false;
		}elseif($aSubmitAfterSendbackEsList['is_exist']){
			$aLockedEsList = $aSubmitAfterSendbackEsList['es_list'];
		}else{
			//列出被锁定的题目
			$aLockedEsList = $this->_getLockedEsList($userId, $subjectId, $type, $offSet, $pageSize);
		}
		if(!$aLockedEsList){
			return $aLockedEsList;
		}
		$aEsIds = array();
		foreach($aLockedEsList as $aLockedEs){
			$aEsIds[] = $aLockedEs['id'];
		}
		$oEsLog = new Model(T_ES_LOG);
		$aEsLogList = $oEsLog->get('', '`es_id` in (' . implode(',', $aEsIds) . ')', '`id` ASC');
		if($aEsLogList === false){
			return false;
		}
		foreach($aLockedEsList as $key => $aLockedEs){
			$aLockedEsList[$key]['submit_time'] = 0;
			$aLockedEsList[$key]['approve_time'] = 0;
			$aLockedEsList[$key]['sendback_reason'] = '';
			foreach($aEsLogList as $aEsLog){
				if($aLockedEs['id'] == $aEsLog['es_id']){
					if($aEsLog['action'] == 2){
						$aLockedEsList[$key]['submit_time'] = $aEsLog['operating_time'];
					}elseif($aEsLog['action'] == 4){
						$aLockedEsList[$key]['approve_time'] = $aEsLog['operating_time'];
						$aLockedEsList[$key]['sendback_reason'] = $aEsLog['comment'];
					}
				}
			}
		}
		$oEsCategory = new Model(T_ES_CATEGORY);
		foreach($aLockedEsList as &$aLockedEs){
			$aCategoryInfo = $oEsCategory->get('', array('id' => $aLockedEs['category_id']));
			if($aCategoryInfo === false){
				return false;
			}elseif($aCategoryInfo){
				$aLockedEs['category_name'] = $aCategoryInfo[0]['name'];
			}else{
				$aLockedEs['category_name'] = '-';
			}
		}
		return $aLockedEsList;
	}

	public function isMyWaitApproverEs($userId, $esId){
		//在审核人和题目关系表中是否有
		$oApproverEsRelation = new Model(T_APPROVER_ES_RELATION);
		$aEsLockCountInfo = $oApproverEsRelation->get('count(*) as `nums`', '`es_id`=' . $esId . ' AND `lock_user_id`=' . $userId);
		if(!$aEsLockCountInfo){
			return false;
		}elseif($aEsLockCountInfo[0]['nums']){
			return $aEsLockCountInfo[0]['nums'];
		}
		//如果没有记录，看是否是我发回的题目
		$oEsLog = new Model(T_ES_LOG);
		$aSendbackCountInfo = $oEsLog->get('count(*) as `nums`', '`approver_user_id`=' . $userId . ' AND `action`=' . $this->_aAction['sendback']);
		if(!$aSendbackCountInfo){
			return false;
		}else{
			return $aSendbackCountInfo[0]['nums'];
		}
	}
//====================================pipeline标识 版本号:1752======================================
	public function addUserEsWrong($aData){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		if(isset($aData['answer_last'])){
			$aData['answer_last'] = json_encode($aData['answer_last']);
		}
		return $oUserEsWrong->add($aData);
	}

	public function deleteUserEsWrong($id){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		return $oUserEsWrong->delete(array('id' => $id));
	}
	//增加一个按照题目id用户id，关卡id删除错题---林云龙
	public function deleteUserEsWrongByEsId($esid, $userId, $missionId){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		return $oUserEsWrong->delete('`es_id`=' . $esid . ' AND `mission_id`=' . $missionId . ' AND `user_id`=' . $userId);
	}

	//批量删除错题集
	public function deleteBatchUserEsWrong($aUserEsWrongIds){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		return $oUserEsWrong->delete(array('id' => array('in', $aUserEsWrongIds)));
	}

	//批量忽略错题集
	public function ignoreBatchUserEsWrong($aUserEsWrongIds){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		return $oUserEsWrong->update(array('is_ignore' => 1), array('id' => array('in', $aUserEsWrongIds)));
	}

	//

	public function setUserEsWrong($aData){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		if(isset($aData['answer_last'])){
			$aData['answer_last'] = json_encode($aData['answer_last']);
		}
		return $oUserEsWrong->update($aData, array('id' => $aData['id']));
	}

	public function getUserWrongEsByUserIdAndEsId($userId, $esId){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$aUserWrongEsInfo = $oUserEsWrong->get('', '`user_id`=' . $userId . ' AND `es_id`=' . $esId);
		if($aUserWrongEsInfo){
			$aUserWrongEsInfo[0]['answer_last'] = json_decode($aUserWrongEsInfo[0]['answer_last'], true);
			return $aUserWrongEsInfo[0];
		}
		return $aUserWrongEsInfo;
	}

	public function getUserWrongEsInfo($esWrongId){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$aUserEsWrongInfo = $oUserEsWrong->get('', array('id' => $esWrongId));
		if($aUserEsWrongInfo){
			$aEsList = $this->_getEsDetailListByEsIds(array($aUserEsWrongInfo[0]['es_id']));
			$aMissionList = $this->_getMissionListByMissionIds(array($aUserEsWrongInfo[0]['mission_id']));
			if($aMissionList === false){
				return false;
			}
			if($aEsList){
				$aEs = $aEsList[0];
				$aEs['answer_last'] = json_decode($aUserEsWrongInfo[0]['answer_last'], true);
				$aEs['create_time'] = date('Y-m-d H:i:s', $aUserEsWrongInfo[0]['create_time']);
				$aEs['mission_id'] = $aUserEsWrongInfo[0]['mission_id'];
				$aEs['mission_name'] = '未知关卡';
				if($aMissionList){
					$aEs['mission_name'] = $aMissionList[0]['name'];
				}
				$aEs['es_id'] = $aEs['id'];
				$aEs['id'] = $aUserEsWrongInfo[0]['id'];
				$aEs['is_ignore'] = $aUserEsWrongInfo[0]['is_ignore'];
				//做错该题的人
				$where = '`es_id`=' . $aUserEsWrongInfo[0]['es_id'] . ' AND `id`!=' . $aUserEsWrongInfo[0]['id'];
				$aUserEsWrongList = $oUserEsWrong->get('', $where, '`create_time` desc', 0, 10);
				if($aUserEsWrongList === false){
					return false;
				}
				$aUserIds = array();
				foreach($aUserEsWrongList as $aUserEsWrong){
					$aUserIds[] = $aUserEsWrong['user_id'];
				}
				$aEs['user_list'] = array();
				if($aUserIds){
					$oPersonal = new Model(T_PERSONAL);
					$aUserList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
					if($aUserList === false){
						return false;
					}
					foreach($aUserEsWrongList as $aUserEsWrong){
						$aData = array();
						$aData['id'] = 0;
						$aData['name'] = '';
						foreach($aUserList as $aUser){
							if($aUser['id'] == $aUserEsWrong['user_id']){
								$aData['id'] = $aUser['id'];
								$aData['name'] = $aUser['name'];
								$aData['profile'] = $aUser['profile'];
							}
						}
						$time = time() - $aUserEsWrong['create_time'];
						if($time > 86400){
							$aData['time'] = floor($time/86400) . '天前';
						}elseif($time > 3600){
							$aData['time'] = floor($time/3600) . '小时前';
						}elseif($time > 60){
							$aData['time'] = floor($time/60) . '分钟前';
						}else{
							$aData['time'] = $time . '秒前';
						}
						$aEs['user_list'][] = $aData;
					}
				}
				return $aEs;
			}
			return $aEsList;
		}
		return $aUserEsWrongInfo;
	}

	public function getUserFavouriteEsInfo($esFavouriteId){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$aEsFavouriteInfo = $oUserEsFavourite->get('', array('id' => $esFavouriteId));
		if($aEsFavouriteInfo){
			$aMissionList = $this->_getMissionListByMissionIds(array($aEsFavouriteInfo[0]['mission_id']));
			if($aMissionList === false){
				return false;
			}
			$aEsList = $this->_getEsDetailListByEsIds(array($aEsFavouriteInfo[0]['es_id']));
			if($aEsList){
				$aEs = $aEsList[0];
				$aEs['create_time'] = date('Y-m-d H:i:s', $aEsFavouriteInfo[0]['create_time']);
				$aEs['mission_id'] = $aEsFavouriteInfo[0]['mission_id'];
				$aEs['mission_name'] = '未知关卡';
				if($aMissionList){
					$aEs['mission_name'] = $aMissionList[0]['name'];
				}
				$aEs['es_id'] = $aEs['id'];
				$aEs['id'] = $aEsFavouriteInfo[0]['id'];
				//收藏该题的人列表
				$where = '`es_id`=' . $aEsFavouriteInfo[0]['es_id'] . ' AND `id`!=' . $aEsFavouriteInfo[0]['id'];
				$aUserEsFavouriteList = $oUserEsFavourite->get('', $where, '`create_time` desc', 0, 10);
				if($aUserEsFavouriteList === false){
					return false;
				}
				$aUserIds = array();
				foreach($aUserEsFavouriteList as $aUserEsFavourite){
					$aUserIds[] = $aUserEsFavourite['user_id'];
				}
				$aEs['user_list'] = array();
				if($aUserIds){
					$oPersonal = new Model(T_PERSONAL);
					$aUserList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
					if($aUserList === false){
						return false;
					}
					foreach($aUserEsFavouriteList as $aUserEsFavourite){
						$aData = array();
						$aData['id'] = 0;
						$aData['name'] = '';
						foreach($aUserList as $aUser){
							if($aUser['id'] == $aUserEsFavourite['user_id']){
								$aData['id'] = $aUser['id'];
								$aData['name'] = $aUser['name'];
								$aData['profile'] = $aUser['profile'];
							}
						}
						$time = time() - $aUserEsFavourite['create_time'];
						if($time > 86400){
							$aData['time'] = floor($time/86400) . '天前';
						}elseif($time > 3600){
							$aData['time'] = floor($time/3600) . '小时前';
						}elseif($time > 60){
							$aData['time'] = floor($time/60) . '分钟前';
						}else{
							$aData['time'] = $time . '秒前';
						}
						$aEs['user_list'][] = $aData;
					}
				}
				return $aEs;
			}
			return $aEsList;
		}
		return $aEsFavouriteInfo;
	}

	public function getUserWrongEsList($userId, $page = 1, $pageSize = 10, $subjectId = 0, $typeId = 0, $filter = 0, $missionId = 0, $startTime = 0, $endTime = 0, $oreder = '`create_time` desc'){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		if($typeId){
			$where .= ' AND `type_id`=' . $typeId;
		}
		if($filter != 2){
			if($missionId){
				$where .= ' AND `mission_id`=' . $missionId;
			}
		}elseif($filter != 1){
			if($startTime){
				$where .= ' AND `create_time`>=' . $startTime;
			}
			if($endTime){
				$where .= ' AND `create_time`<=' . $endTime;
			}
		}
		$offect = ($page - 1) * $pageSize;
		$aWrongEsList = $oUserEsWrong->get('', $where, $oreder, $offect, $pageSize);
		if($aWrongEsList){
			$aEsIds = array();
			$aMissionIds = array();
			foreach($aWrongEsList as $aWrongEs){
				$aEsIds[] = $aWrongEs['es_id'];
				$aMissionIds[] = $aWrongEs['mission_id'];
			}
			$aEsList = $this->_getEsDetailListByEsIds($aEsIds);
			$aMissionList = $this->_getMissionListByMissionIds($aMissionIds);
			if($aMissionList === false){
				return false;
			}elseif($aMissionList){
				$aMissionList = Mission::convertMissionList($aMissionList);
			}
			if($aEsList){
				$aReturnData = array();
				foreach($aWrongEsList as $aWrongEs){
					foreach($aEsList as $aEs){
						if($aEs['id'] == $aWrongEs['es_id']){
							$aEs['answer_last'] = json_decode($aWrongEs['answer_last'], true);
							$aEs['create_time'] = date('Y-m-d H:i:s', $aWrongEs['create_time']);
							$aEs['mission_id'] = $aWrongEs['mission_id'];
							$aEs['mission_name'] = '未知关卡';
							foreach($aMissionList as $aMission){
								if($aMission['id'] == $aWrongEs['mission_id']){
									$aEs['mission_name'] = $aMission['name'];
								}
							}
							$aEs['es_id'] = $aEs['id'];
							$aEs['id'] = $aWrongEs['id'];
							$aReturnData[] = $aEs;
							break;
						}
					}
				}
				return $aReturnData;
			}
			return $aEsList;
		}
		return $aWrongEsList;
	}

	public function getUserWrongEsCount($userId, $subjectId = 0, $typeId = 0, $filter = 0, $missionId = 0, $startTime = 0, $endTime = 0){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		if($typeId){
			$where .= ' AND `type_id`=' . $typeId;
		}
		if($filter != 2){
			if($missionId){
				$where .= ' AND `mission_id`=' . $missionId;
			}
		}elseif($filter != 1){
			if($startTime){
				$where .= ' AND `create_time`>=' . $startTime;
			}
			if($endTime){
				$where .= ' AND `create_time`<=' . $endTime;
			}
		}
		return $oUserEsWrong->count($where);
	}

	public function getUserWrongEsMonthStatistics($userId){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId;
		$aAllUserEsWrongList = $oUserEsWrong->get('`create_time`', $where, '`create_time` DESC');
		if(!$aAllUserEsWrongList){
			return $aAllUserEsWrongList;
		}
		$aReturnData = array();
		foreach($aAllUserEsWrongList as $aAllUserEsWrong){
			$month = date('Ym', $aAllUserEsWrong['create_time']);
			if(isset($aReturnData[$month])){
				$aReturnData[$month] += 1;
			}else{
				$aReturnData[$month] = 1;
			}
		}
		return $aReturnData;
	}

	public function getMissionWrongEsCountByMissionIds($userId, $aMissionIds){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId  . ' AND `mission_id` in (' . $aMissionIds . ')';
		return $oUserEsWrong->get('`mission_id`,count(*) as `nums`', $where, '', '', '', '`mission_id`');
	}

	public function getUserFavouriteEsCount($userId, $subjectId = 0, $typeId = 0, $filter = 0, $missionId = 0, $startTime = 0, $endTime = 0){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		if($typeId){
			$where .= ' AND `type_id`=' . $typeId;
		}
		if($filter != 2){
			if($missionId){
				$where .= ' AND `mission_id`=' . $missionId;
			}
		}elseif($filter != 1){
			if($startTime){
				$where .= ' AND `create_time`>=' . $startTime;
			}
			if($endTime){
				$where .= ' AND `create_time`<=' . $endTime;
			}
		}
		return $oUserEsFavourite->count($where);
	}

	private function _getEsDetailListByEsIds($aEsIds){
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexList = $oEsIndex->get('', array('id' => array('in', $aEsIds)));
		if($aEsIndexList){
			$oEs = new Model(T_ES);
			$aEsList = $oEs->get('', array('id' => array('in', $aEsIds)));
			if($aEsList){
				foreach($aEsIndexList as &$aEsIndex){
					foreach($aEsList as $aEs){
						if($aEsIndex['id'] == $aEs['id']){
							$aEsIndex['content_text'] = $aEs['content_text'];
							//$aEsIndex['content_json'] = json_decode($aEs['content_json'], true);
							$aEsIndex['content_json'] = $aEs['content_json'];
							$aEsIndex['recent_record'] = json_decode($aEs['recent_record'], true);
						}
					}
				}
			}else{
				return $aEsList;
			}
		}
		return $aEsIndexList;
	}

	private function _getMissionListByMissionIds($aMissionIds){
		$aMissionIds = array_unique($aMissionIds);
		$oMission = new Model(T_MISSION);
		return $oMission->get('', array('id' => array('in', $aMissionIds)));
	}

	//添加用户收藏的题目
	public function addUserEsFavourite($aData){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		return $oUserEsFavourite->add($aData);
	}

	//删除用户收藏的题目
	public function deleteUserEsFavourite($id){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		return $oUserEsFavourite->delete(array('id' => $id));
	}

	//批量删除用户收藏的题目
	public function deleteBacthUserEsFavourite($aUserEsFavouriteIds){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		return $oUserEsFavourite->delete(array('id' => array('in', $aUserEsFavouriteIds)));
	}

	//查看这道题目是否已经被收藏
	public function getUserEsFavouriteInfo($userId, $esId){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$aUserEsFavouriteInfo = $oUserEsFavourite->get('', '`user_id`=' . $userId . ' AND `es_id`=' . $esId);
		if($aUserEsFavouriteInfo){
			return $aUserEsFavouriteInfo[0];
		}
		return $aUserEsFavouriteInfo;
	}

	//查看用户的收藏题目列表
	public function getUserEsFavouriteList($userId, $page = 1, $pageSize = 10, $subjectId = 0, $typeId = 0, $filter = 0, $missionId = 0, $startTime = 0, $endTime = 0, $order = '`create_time` desc'){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$offect = ($page - 1) * $pageSize;
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		if($typeId){
			$where .= ' AND `type_id`=' . $typeId;
		}
		if($filter != 2){
			if($missionId){
				$where .= ' AND `mission_id`=' . $missionId;
			}
		}elseif($filter != 1){
			if($startTime){
				$where .= ' AND `create_time`>=' . $startTime;
			}
			if($endTime){
				$where .= ' AND `create_time`<=' . $endTime;
			}
		}
		$aUserEsFavouriteList = $oUserEsFavourite->get('', $where, $order, $offect, $pageSize);
		if($aUserEsFavouriteList){
			foreach($aUserEsFavouriteList as $aUserEsFavourite){
				$aEsIds[] = $aUserEsFavourite['es_id'];
				$aMissionIds[] = $aUserEsFavourite['mission_id'];
			}
			$aEsList = $this->_getEsDetailListByEsIds($aEsIds);
			$aMissionList = $this->_getMissionListByMissionIds($aMissionIds);
			if($aMissionList === false){
				return false;
			}
			if($aEsList){
				foreach($aEsList as &$aEs){
					foreach($aUserEsFavouriteList as $aUserEsFavourite){
						if($aEs['id'] == $aUserEsFavourite['es_id']){
							$aEs['favourite_id'] = $aUserEsFavourite['id'];
							$aEs['create_time'] = date('Y-m-d H:i:s', $aUserEsFavourite['create_time']);
							$aEs['mission_id'] = $aUserEsFavourite['mission_id'];
							$aEs['mission_name'] = '未知关卡';
							foreach($aMissionList as $aMission){
								if($aUserEsFavourite['mission_id'] == $aMission['id']){
									$aEs['mission_name'] = $aMission['name'];
								}
							}
							$aEs['es_id'] = $aEs['id'];
							$aEs['id'] = $aUserEsFavourite['id'];
						}
					}
				}
			}
			return $aEsList;
		}
		return $aUserEsFavouriteList;
	}

	public function getUserEsWrongById($id){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$aUserEsWrongInfo = $oUserEsWrong->get('', array('id' => $id));
		if($aUserEsWrongInfo){
			$aUserEsWrongInfo = $aUserEsWrongInfo[0];
		}
		return $aUserEsWrongInfo;
	}

	public function getEsWrongMissionList($userId, $page, $pageSize, $subjectId = 0){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		$offect = ($page - 1) * $pageSize;
		$aMissionIds = $oUserEsWrong->get('distinct `mission_id`', $where, '', $offect, $pageSize);
		if($aMissionIds){
			foreach($aMissionIds as $aMissionId){
				$aIds[] = $aMissionId['mission_id'];
			}
			$oMission = new Model(T_MISSION);
			$aMissionList = $oMission->get('', array('id' => array('in', $aIds)));
			if($aMissionList){
				$aMissionList = Mission::convertMissionList($aMissionList);
				$aReturnDatas = array();
				foreach($aMissionList as $aMission){
					$aReturnData = array();
					$aReturnData['id'] = $aMission['id'];
					$aReturnData['name'] = $aMission['name'];
					$aReturnDatas[] = $aReturnData;
				}
				return $aReturnDatas;
			}
			return $aMissionList;
		}else{
			return $aMissionIds;
		}
	}

	public function getEsWrongMissionCount($userId, $subjectId = 0){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		$aMissionCount = $oUserEsWrong->get('count(distinct `mission_id`) as `nums`', $where);
		if(!$aMissionCount){
			return false;
		}
		return $aMissionCount[0]['nums'];
	}

	public function getEsWrongMissionPage($userId, $missionId, $pageSize, $subjectId = 0){
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		$aMissionList = $oUserEsWrong->get('distinct `mission_id`', $where);
		if($aMissionList === false){
			return false;
		}
		$page = 1;
		$offect = 0;
		foreach($aMissionList as $key => $aMission){
			if($aMission['mission_id'] == $missionId){
				$offect = $key;
				break;
			}
		}
		if($offect > 0){
			$offect += 1;
			$page = ceil($offect / $pageSize);
		}
		return $page;
	}

	public function getEsFavouriteMissionList($userId, $page, $pageSize, $subjectId = 0){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		$offect = ($page - 1) * $pageSize;
		$aMissionIds = $oUserEsFavourite->get('distinct `mission_id`', $where, '', $offect, $pageSize);
		if($aMissionIds){
			foreach($aMissionIds as $aMissionId){
				$aIds[] = $aMissionId['mission_id'];
			}
			$oMission = new Model(T_MISSION);
			$aMissionList = $oMission->get('', array('id' => array('in', $aIds)));
			if($aMissionList){
				$aReturnDatas = array();
				foreach($aMissionList as $aMission){
					$aReturnData = array();
					$aReturnData['id'] = $aMission['id'];
					$aReturnData['name'] = $aMission['name'];
					$aReturnDatas[] = $aReturnData;
				}
				return $aReturnDatas;
			}
			return $aMissionList;
		}else{
			return $aMissionIds;
		}
	}

	public function getEsFavouriteMissionCount($userId, $subjectId = 0){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		$aMissionCount = $oUserEsFavourite->get('count(distinct `mission_id`) as `nums`', $where);
		if($aMissionCount === false){
			return false;
		}
		return $aMissionCount[0]['nums'];
	}

	public function getEsFavouriteMissionPage($userId, $missionId, $pageSize, $subjectId = 0){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$where = '`user_id`=' . $userId;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		$aMissionList = $oUserEsFavourite->get('distinct `mission_id`', $where);
		if($aMissionList === false){
			return false;
		}
		$page = 1;
		$offect = 0;
		foreach($aMissionList as $key => $aMission){
			if($aMission['mission_id'] == $missionId){
				$offect = $key;
				break;
			}
		}
		if($offect > 0){
			$offect += 1;
			$page = ceil($offect / $pageSize);
		}
		return $page;
	}

	public function isUserFavouriteEs($userId, $esId){
		$oUserEsFavourite = new Model(T_USER_ES_FAVOURITE);
		$where = '`user_id`=' . $userId . ' AND `es_id`=' . $esId;
		return $oUserEsFavourite->count($where);
	}

	//得到题库中正式题目信息
	public function getOfficialEsInfoById($esId){
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexInfo = $oEsIndex->get('', array('id' => $esId));
		if(!$aEsIndexInfo){
			return $aEsIndexInfo;
		}
		if($aEsIndexInfo[0]['status'] != self::OFFICIAL_ES_STATU){
			return array();
		}
		$oEs = new Model(T_ES);
		$aEsInfo = $oEs->get('', array('id' => $esId));
		if(!$aEsInfo){
			return $aEsInfo;
		}
		$aEsIndexInfo = $aEsIndexInfo[0];
		$aEsIndexInfo['content_json'] = $aEsInfo[0]['content_json'];
		$aEsIndexInfo['content_text'] = $aEsInfo[0]['content_text'];
		if($aEsInfo[0]['recent_record']){
			$aEsIndexInfo['recent_record'] = json_decode($aEsInfo[0]['recent_record'], true);
		}else{
			$aEsIndexInfo['recent_record'] = array();
		}
		return $aEsIndexInfo;
	}

	//根据题目科目及目录获得各题型题目数量
	public function getEsCountBySubjectAndCategoryIds($subjectId, $aCategoryIds){
		if(!$aCategoryIds){
			return array();
		}
		$aEsTypeList = $GLOBALS['SUBJECT_TYPE'][$subjectId];
		$oEsIndex = new Model(T_ES_INDEX);
		$categoryIds = implode(',', $aCategoryIds);
		$aEsCountList = array();
		foreach($aEsTypeList as $typeId){
			$esCount = $oEsIndex->count('`type_id`=' . $typeId . ' AND `status`=' . $this->_aStatus['pass_end_approved'] . ' AND `category_id` in(' . $categoryIds . ')');
			if($esCount === false){
				return false;
			}
			$aEsCountList[$typeId] = $esCount;
		}
		return $aEsCountList;
	}

	public function getEsCountByCategoryIds($aCategoryIds){
		if(!$aCategoryIds){
			return array();
		}
		$oEsIndex = new Model(T_ES_INDEX);
		$categoryIds = implode(',', $aCategoryIds);
		//$esCount = $oEsIndex->count('`status`=' . $this->_aStatus['pass_end_approved'] . ' AND `category_id` in(' . $categoryIds . ')');
		$aEsCountList = $oEsIndex->get('`status`,count(*) as nums', '`category_id` in(' . $categoryIds . ')', '', '', '', '`status`');
		$aReturnData = array(
			'1' => 0,
			'2' => 0,
			'3' => 0,
			'5' => 0
		);
		foreach($aEsCountList as $aEsCount){
			if($aEsCount['status'] == 1){
				$aReturnData[1] = $aEsCount['nums'];
			}elseif($aEsCount['status'] == 2){
				$aReturnData[2] = $aEsCount['nums'];
			}elseif($aEsCount['status'] == 3){
				$aReturnData[3] += $aEsCount['nums'];
			}elseif($aEsCount['status'] == 4){
				$aReturnData[3] += $aEsCount['nums'];
			}elseif($aEsCount['status'] == 5){
				$aReturnData[5] += $aEsCount['nums'];
			}elseif($aEsCount['status'] == 6){
				$aReturnData[5] += $aEsCount['nums'];
			}
		}
		return $aReturnData;
		//return $esCount;
	}

	//添加题目反馈
	public function addEsFeedback($aData){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		if(isset($aData['reward'])){
			$aData['reward'] = json_encode($aData['reward']);
		}else{
			$aData['reward'] = json_encode(array());
		}
		return $oEsFeedback->add($aData);
	}

	//根据用户id和题目id得到反馈题目信息
	public function getEsFeedbackInfoByUserIdAndEsId($userId, $esId, $userType = 1){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		$aEsFeedbackInfo = $oEsFeedback->get('', '`user_id`=' . $userId . ' AND `es_id`=' . $esId . ' AND `user_type`=' . $userType);
		if($aEsFeedbackInfo){
			$aEsFeedbackInfo = $aEsFeedbackInfo[0];
		}
		return $aEsFeedbackInfo;
	}

	//更具反馈的id得到反馈信息
	public function getEsFeedbackInfoById($feedbackId){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		$aEsFeedbackInfo = $oEsFeedback->get('', array('id' => $feedbackId));
		if($aEsFeedbackInfo){
			$aEsFeedbackInfo = $aEsFeedbackInfo[0];
			if($aEsFeedbackInfo['reward']){
				$aEsFeedbackInfo['reward'] = json_decode($aEsFeedbackInfo['reward'], true);
			}else{
				$aEsFeedbackInfo['reward'] = array();
			}
		}
		return $aEsFeedbackInfo;
	}

	//得到题目反馈列表
	public function getEsFeedbackList($subjectId, $statu =0, $page = 1, $pageSize = 10, $order = '`id` asc'){
		$where = '`subject_id`=' . $subjectId;
		if($statu){
			$where .= ' AND `status`='. $statu;
		}
		$offect = ($page - 1) * $pageSize;
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		$aEsFeedBackList = $oEsFeedback->get('', $where, $order, $offect, $pageSize, '`es_id`');
		return $aEsFeedBackList;
	}

	public function getEsFeedbackCount($subjectId, $statu = 0){
		$where = '`subject_id`=' . $subjectId;
		if($statu){
			$where .= ' AND `status`=' . $statu;
		}
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		$aEsFeedbackCount = $oEsFeedback->get('`es_id`', $where, '', '', '', '`es_id`');
		if($aEsFeedbackCount === false){
			return false;
		}else{
			return count($aEsFeedbackCount);
		}
	}

	public function deleteEsFeedbackByEsId($esId){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		return $oEsFeedback->delete('`es_id`=' . $esId);
	}

	public function setEsFeedback($aData){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		if(isset($aData['reward'])){
			$aData['reward'] = json_encode($aData['reward']);
		}
		return $oEsFeedback->update($aData, array('id' => $aData['id']));
	}

	public function getEsFeedbackListByEsId($esId, $statu = 0){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		$where = '`es_id`=' . $esId;
		if($statu){
			$where .= ' AND `status`=' . $statu;
		}
		return $oEsFeedback->get('', $where);
	}

	public function getEsFeedbackCountByEsId($esId){
		$oEsFeedback = new Model(T_ES_FEEDBACK);
		return $oEsFeedback->count('`es_id`=' . $esId);
	}

	public function getEsSeedBackReason($esId, $action = 6){
		$oEsLog = new Model(T_ES_LOG);
		$aEsLogInfo = $oEsLog->get('', '`es_id`=' . $esId . ' AND `action`=' . $action, '', 0, 1);
		if($aEsLogInfo){
			return $aEsLogInfo[0]['comment'];
		}else{
			return false;
		}
	}

	public function getDetailCategoryByEsId($esId){
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexInfo = $oEsIndex->get('', array('id' => $esId));
		if(!$aEsIndexInfo){
			return $aEsIndexInfo;
		}
		return $this->_getDetailCategoryById($aEsIndexInfo[0]['category_id']);
	}

	public function getEsListForSimilar($aEsIds){
		$aEsList = $this->getEsList('', array('id' => array('in', $aEsIds)));
		if(!$aEsList){
			return $aEsList;
		}
		$oEsLog = new Model(T_ES_LOG);
		$aEsLogList = $oEsLog->get('', '`es_id` in (' . implode(',', $aEsIds) . ') AND `action`=1');
		if($aEsLogList === false){
			return false;
		}
		$aManagerIds = array();
		foreach($aEsLogList as $aEsLog){
			$aManagerIds[] = $aEsLog['submiter_user_id'];
		}
		$aManagerList = array();
		if($aManagerIds){
			$oManager = new Model(T_MANAGER);
			$aManagerList = $oManager->get('', array('id' => array('in', $aManagerIds)));
			if($aManagerList === false){
				return false;
			}
		}
		foreach($aEsList as &$aEs){
			$aEs['creater'] = '';
			foreach($aEsLogList as $aEsLog){
				if($aEsLog['es_id'] == $aEs['id']){
					foreach($aManagerList as $aManager){
						if($aManager['id'] == $aEsLog['submiter_user_id']){
							$aEs['creater'] = $aManager['name'];
							break;
						}
					}
					break;
				}
			}
		}
		return $aEsList;
	}

	public function getEsIdsByCategoryId($aCategoryIds, $esCount, $excludeType = 0){
		if(count($aCategoryIds) == 1){
			$where = '`category_id`=' . $aCategoryIds[0] . ' AND `status`=' . self::OFFICIAL_ES_STATU;
		}else{
			$where = '`category_id` in (' . implode(',', $aCategoryIds) . ') AND `status`=' . self::OFFICIAL_ES_STATU;
		}
		if($excludeType){
			$where .= ' AND `type_id` != ' . $excludeType;
		}
		$oEsIndex = new Model(T_ES_INDEX);
		$aAllEsIndexlist = $oEsIndex->get('`id`', $where);
		if(!$aAllEsIndexlist){
			return $aAllEsIndexlist;
		}
		if(count($aAllEsIndexlist) >= $esCount){
			$aKeys = array_rand($aAllEsIndexlist, $esCount);
			if(is_array($aKeys)){
				foreach($aKeys as $Key){
					$aEsIndexlist[] = $aAllEsIndexlist[$Key]['id'];
				}
			}else{
				$aEsIndexlist[] = $aAllEsIndexlist[$aKeys]['id'];
			}
		}else{
			return array();
		}
		return $aEsIndexlist;
	}

	public function getOfficialEsCount($subjectId = 0){
		$oEs = new Model(T_ES_INDEX);
		$where = '`status`=' . self::OFFICIAL_ES_STATU;
		if($subjectId){
			$where .= ' AND `subject_id`=' . $subjectId;
		}
		return $oEs->count($where);
	}

	/*
	 *根据关卡得到相应题目列表
	 */
	public function getOfficialEsListByMissionId($missionId, $page = 0, $pageSize = 10, $order = ''){
		$oMission = new Model(T_MISSION);
		$aMissionInfo = $oMission->get('`category_ids`', array('id' => $missionId));
		if(!$aMissionInfo){
			return $aMissionInfo;
		}
		$aCategoryIds = explode(',', $aMissionInfo[0]['category_ids']);
		if(count($aCategoryIds) == 1){
			$where = '`category_id`=' . $aCategoryIds[0];
		}else{
			$where = '`category_id` in (' . implode(',', $aCategoryIds) . ')';
		}
		$where .= ' AND `status`=' . self::OFFICIAL_ES_STATU . ' AND `answer_counts`>' . self::ANSWER_COUNT;
		$offect = ($page - 1) * $pageSize;
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexList = $oEsIndex->get('`id`,`type_id`,`correct_percent`', $where, $order, $offect, $pageSize);
		if(!$aEsIndexList){
			return $aEsIndexList;
		}
		$aEsIds = array();
		foreach($aEsIndexList as $aEsIndex){
			$aEsIds[] = $aEsIndex['id'];
		}
		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('`id`,`content_text`', array('id' => array('in', $aEsIds)));
		if(!$aEsList){
			return $aEsList;
		}
		foreach($aEsIndexList as &$aEsIndex){
			foreach($aEsList as $aEs){
				if($aEsIndex['id'] == $aEs['id']){
					$aEsIndex['content_text'] = $aEs['content_text'];
					break;
				}
			}
		}
		return $aEsIndexList;
	}
	/*
	 * 根据关卡得到相应题目列表总计
	 */
	public function getOfficialEsCountByMissionId($missionId){
		$oMission = new Model(T_MISSION);
		$aMissionInfo = $oMission->get('`category_ids`', array('id' => $missionId));
		if(!$aMissionInfo){
			return $aMissionInfo;
		}
		$aCategoryIds = explode(',', $aMissionInfo[0]['category_ids']);
		if(count($aCategoryIds) == 1){
			$where = '`category_id`=' . $aCategoryIds[0];
		}else{
			$where = '`category_id` in (' . implode(',', $aCategoryIds) . ')';
		}
		$where .= ' AND `status`=' . self::OFFICIAL_ES_STATU . ' AND `answer_counts`>' . self::ANSWER_COUNT;
		$oEsIndex = new Model(T_ES_INDEX);
		return $oEsIndex->count($where);
	}

	//获取用户的题目列表通过关卡id和记录的类型（错题集和收藏夹）$recordType:1-错题集，2-收藏夹
	public function getUserEsListByMissionIdAndRecord($aUserIds, $missionId, $recordType = 1, $page = 1, $pageSize = 10){
		$where = '`mission_id`=' . $missionId . ' AND `user_id` in (' . implode(',', $aUserIds) . ')';
		$offect = ($page - 1) * $pageSize;
		if($recordType == 1){
			$oUserEs = new Model(T_USER_ES_WRONG);
		}else{
			$oUserEs = new Model(T_USER_ES_FAVOURITE);
		}
		$aEsIdList = $oUserEs->get('DISTINCT `es_id`', $where, '', $offect, $pageSize);
		if(!$aEsIdList){
			return $aEsIdList;
		}
		$aEsIds = array();
		foreach($aEsIdList as $aEsId){
			$aEsIds[] = $aEsId['es_id'];
		}
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexList = $oEsIndex->get('`id`,`correct_counts`,`answer_counts`,`correct_percent`', array('id' => array('in', $aEsIds)));
		if(!$aEsIndexList){
			return $aEsIndexList;
		}
		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('`id`,`content_text`', array('id' => array('in', $aEsIds)));
		if(!$aEsList){
			return $aEsList;
		}
		foreach($aEsIndexList as &$aEsIndex){
			foreach($aEsList as $aEs){
				if($aEsIndex['id'] == $aEs['id']){
					$aEsIndex['content_text'] = $aEs['content_text'];
					break;
				}
			}
		}
		return $aEsIndexList;
	}

	public function getPassAppealEsList($page, $pageSize){
		$where = '`appeal_status`=3';
		$offect = ($page - 1) * $pageSize;
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexList = $oEsIndex->get('`id`,`subject_id`,`type_id`,`category_id`', $where, '`id` DESC', $offect, $pageSize);
		if(!$aEsIndexList){
			return $aEsIndexList;
		}
		$aEsIds = array();
		$aCategoryIds = array();
		foreach($aEsIndexList as $aEs){
			$aEsIds[] = $aEs['id'];
			$aCategoryIds[] = $aEs['category_id'];
		}
		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('`id`,`content_json`,`content_text`', array('id' => array('in', $aEsIds)));
		if(!$aEsList){
			return $aEsList;
		}
		$oEsLog = new Model(T_ES_LOG);
		$aEsLogList = $oEsLog->get('', '`es_id` in (' . implode(',', $aEsIds) . ') AND `action`=4', '`id` DESC');
		$aManagerIds = array();
		foreach($aEsLogList as $aEsLog){
			$aManagerIds[] = $aEsLog['submiter_user_id'];
			$aManagerIds[] = $aEsLog['approver_user_id'];
		}
		$oManager = new Model(T_MANAGER);
		$aManagerList = $oManager->get('`id`,`name`', array('id' => array('in', $aManagerIds)));
		$aCategoryList = $this->_getCateGoryTreeByCateGoryIds($aCategoryIds);
		foreach($aEsIndexList as &$aEsIndex){
			foreach($aEsList as $aEs){
				if($aEs['id'] == $aEsIndex['id']){
					$aEsIndex['content_json'] = $aEs['content_json'];
					$aEsIndex['content_text'] = $aEs['content_text'];
					break;
				}
			}
			foreach($aCategoryList as $categoryId => $aCategoryTree){
				if($categoryId == $aEsIndex['category_id']){
					$aEsIndex['category_tree'] = $aCategoryTree;
					break;
				}
			}
			foreach($aEsLogList as $aEsLog){
				if($aEsLog['es_id'] == $aEsIndex['id']){
					$aEsIndex['sendback_time'] = $aEsLog['operating_time'];
					$aEsIndex['sendback_reason'] = $aEsLog['comment'];
					foreach($aManagerList as $aManager){
						if($aEsLog['submiter_user_id'] == $aManager['id']){
							$aEsIndex['submiter_user_name'] = $aManager['name'];
						}elseif($aEsLog['approver_user_id'] == $aManager['id']){
							$aEsIndex['approver_user_name'] = $aManager['name'];
						}
					}
					break;
				}
			}
		}
		return $aEsIndexList;
	}

	public function getPassAppealEsCount(){
		$where = '`appeal_status`=3';
		$oEsIndex = new Model(T_ES_INDEX);
		return $oEsIndex->count($where);
	}

	private function _getCateGoryTreeByCateGoryIds($aCategoryIds){
		$aChineseCategoryList = include_once SYSTEM_APPS_PATH . 'm.umfun.com/cache/es_1_category_tree_list.cache.php';
		$aMathCategoryList = include_once SYSTEM_APPS_PATH . 'm.umfun.com/cache/es_2_category_tree_list.cache.php';
		$aEnglishCategoryList = include_once SYSTEM_APPS_PATH . 'm.umfun.com/cache/es_3_category_tree_list.cache.php';
		$aCategoryList = array_merge($aChineseCategoryList, $aMathCategoryList, $aEnglishCategoryList);
		unset($aChineseCategoryList);
		unset($aMathCategoryList);
		unset($aEnglishCategoryList);
		$aNewCategoryList = array();
		foreach($aCategoryList as $aCategory){
			$aNewCategoryList[$aCategory['id']] = $aCategory;
		}
		unset($aCategoryList);
		$aReturnCategoryList = array();
		foreach($aCategoryIds as $categoryId){
			$aReturnCategoryList[$categoryId] = $this->_getTree($aNewCategoryList, $categoryId);
		}
		return $aReturnCategoryList;
	}

	private function _getTree($aNewCategoryList, $categoryId){
		$aTree = $aNewCategoryList[$categoryId];
		while($aTree['parent_id']){
			$aTree1 = $aNewCategoryList[$aTree['parent_id']];
			$aTree1['child'] = $aTree;
			$aTree = $aTree1;
		}
		return $aTree;
	}

	public function getEsCountForMissionStatistic($subjectId, $startTime, $endTime){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`category_ids`,`name`', '`subject_id`=' . $subjectId, '`orders`');
		if(!$aMissionList){
			return $aMissionList;
		}
		$aCategoryIds = array();
		foreach($aMissionList as $key => $aMission){
			$aMissionList[$key]['category_ids'] = explode(',', $aMission['category_ids']);
			$aCategoryIds = array_merge($aCategoryIds, $aMissionList[$key]['category_ids']);
		}
		$oEsIndex = new Model(T_ES_INDEX);
		$categoryIds = implode(',', $aCategoryIds);
		//$aCategoryEsStatisticList = $oEsIndex->get('`category_id`,`type_id`,count(*) as `nums`', '`category_id` in (' . $categoryIds . ') AND `status`=' . $this->_aStatus['pass_end_approved'], '', '', '', '`category_id`,`type_id`');
		$fields = '`t1`.`category_id`,`t1`.`type_id`,count(*) as `nums`';
		$where = '`t1`.`category_id` in (' . $categoryIds . ') AND `t1`.`status`=' . $this->_aStatus['pass_end_approved'] . ' AND `log`.`action`=5 AND `log`.`operating_time`>=' . $startTime . ' AND `log`.`operating_time`<=' . $endTime;
		$group = '`t1`.`category_id`,`t1`.`type_id`';
		$oDboi = new DBOI();
		$aCategoryEsStatisticList = $oDboi->fields($fields)->table(T_ES_INDEX)->leftjoin(T_ES_LOG, 'as `log` on `log`.`es_id`=`t1`.`id`')->where($where)->groupby($group)->select();

		if($aCategoryEsStatisticList === false){
			return false;
		}
		//待复核题目数列表
		$aWaitEndApprovedList = $oEsIndex->get('`category_id`,count(*) as `nums`', '`category_id` in (' . $categoryIds . ') AND `status`=' . $this->_aStatus['first_approved'], '', '', '', '`category_id`');
		if($aWaitEndApprovedList === false){
			return false;
		}
		$aMissionEsStatisticList = array();
		$aEsTypeList = $GLOBALS['SUBJECT_TYPE'][$subjectId];
		foreach($aMissionList as $aMission){
			foreach($aEsTypeList as $typeId){
				$aMission['es_count'][$typeId] = 0;
			}
			foreach($aCategoryEsStatisticList as $aCategoryEsStatistic){
				if(in_array($aCategoryEsStatistic['category_id'], $aMission['category_ids'])){
					$aMission['es_count'][$aCategoryEsStatistic['type_id']] += $aCategoryEsStatistic['nums'];
				}
			}
			$aMission['wait_end_approve_count'] = 0;
			foreach($aWaitEndApprovedList as $aWaitEndApproved){
				if(in_array($aWaitEndApproved['category_id'], $aMission['category_ids'])){
					$aMission['wait_end_approve_count'] += $aWaitEndApproved['nums'];
				}
			}
			$aMissionEsStatisticList[] = $aMission;
		}
		return $aMissionEsStatisticList;
	}

	//各科目的错题和已修复题目数量统计----------错题集首页用
	public function getUserSubjectWrongEsStatistic($userId){
		$aSubjectStatistic = array(
			'1'	=>	array(
				'wrong_es_times'	=>	0,
				'repair_es_count'	=>	0,
				'wrong_es_count'	=>	0,
			),
			'2'	=>	array(
				'wrong_es_times'	=>	0,
				'repair_es_count'	=>	0,
				'wrong_es_count'	=>	0,
			),
			'3'	=>	array(
				'wrong_es_times'	=>	0,
				'repair_es_count'	=>	0,
				'wrong_es_count'	=>	0,
			),
		);
		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aMissionUserRelationList = $oMissionUserRelationIndex->get('`mission_id`,`es_count`,`es_correct_count`,`es_repair_count`', '`user_id`=' . $userId);
		if($aMissionUserRelationList === false){
			return false;
		}elseif(!$aMissionUserRelationList){
			return $aSubjectStatistic;
		}

		$aMissionIds = array();
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			$aMissionIds[] = $aMissionUserRelation['mission_id'];
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`subject_id`', array('id' => array('in', $aMissionIds)));
		if($aMissionList === false){
			return false;
		}
		foreach($aMissionUserRelationList as $aMissionUserRelation){
			foreach($aMissionList as $aMission){
				if($aMission['id'] == $aMissionUserRelation['mission_id']){
					$aSubjectStatistic[$aMission['subject_id']]['wrong_es_times'] += $aMissionUserRelation['es_count'] - $aMissionUserRelation['es_correct_count'];
					$aSubjectStatistic[$aMission['subject_id']]['repair_es_count'] += $aMissionUserRelation['es_repair_count'];
					break;
				}
			}
		}
		//错题集剩余错题统计
		$oUserEsWrong = new Model(T_USER_ES_WRONG);
		$aUserWrongEsStatistic = $oUserEsWrong->get('`subject_id`,count(*) as `nums`', '`user_id`=' . $userId, '', '', '', '`subject_id`');
		if($aUserWrongEsStatistic === false){
			return false;
		}
		foreach($aUserWrongEsStatistic as $aUserWrongEs){
			$aSubjectStatistic[$aUserWrongEs['subject_id']]['wrong_es_count'] += $aUserWrongEs['nums'];
		}
		return $aSubjectStatistic;
	}

	//题目数量
	public function getEsCount($subject = 0, $statu = 0){
		$where = '';
		if($subject){
			$where = '`subject_id`=' . $subject;
		}
		if($statu){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`status`=' . $statu;
		}
		$oEsIndex = new Model(T_ES_INDEX);
		return $oEsIndex->count($where);
	}


	//过去一周都没有解锁的题目
	public function getUnlockApproveEsIds(){
		$weekTime = time() - 604800;
		$oApproverEsRelation = new Model(T_APPROVER_ES_RELATION);
		$aEsList = $oApproverEsRelation->get('`id`','`lock_time` < ' . $weekTime);
		if(!$aEsList){
			return $aEsList;
		}
		$aIds = array();
		foreach($aEsList as $aEs){
			$aIds[] = $aEs['id'];
		}
		unset($aEsList);
		return $aIds;
	}

	//解锁题目
	public function deleteLockApproveEsByIds($aIds){
		$oApproverEsRelation = new Model(T_APPROVER_ES_RELATION);
		return $oApproverEsRelation->delete(array('id'=>array('in',$aIds)));
	}

	public function getEsListByCategoryId($categoryId){
		$oEsIndex = new Model(T_ES_INDEX);
		$aEsIndexList = $oEsIndex->get('', '`category_id`=' . $categoryId);
		if(!$aEsIndexList){
			return $aEsIndexList;
		}
		$aEsIds = array();
		foreach($aEsIndexList as $aEsIndex){
			$aEsIds[] = $aEsIndex['id'];
		}
		$oEs = new Model(T_ES);
		$aEsList = $oEs->get('', array('id' => array('in', $aEsIds)));
		if($aEsList === false){
			return false;
		}
		foreach($aEsIndexList as &$aEsIndex){
			foreach($aEsList as $aEs){
				if($aEs['id'] == $aEsIndex['id']){
					$aEsIndex['content_json'] = $aEs['content_json'];
					$aEsIndex['content_text'] = $aEs['content_text'];
				}
			}
		}
		return $aEsIndexList;
	}

	public function getApproverUserInfoById($userId){
		$mEsLog = new Model(T_ES_LOG);
		$aApproverInfo = $mEsLog->get('`es_id`,`submiter_user_id`,`approver_user_id`,`operating_time`,`action`', '`action`=3 and `es_id`=' . $userId, '`operating_time` desc', 0, 1);
		if(!$aApproverInfo){
			return false;
		}

		$mManager = new Model(T_MANAGER);
		$aTemp = $mManager->get('`id`,`name`', array('id' => $aApproverInfo[0]['approver_user_id']));
		$aApproverUserInfo = $aTemp[0];
		if($aApproverUserInfo === false){
			return false;
		}
		unset($aTemp);
		$aApproverUserInfo['operating_time'] = $aApproverInfo[0]['operating_time'];

		return $aApproverUserInfo;
	}

	//返回正确率的位置
	public function getEsCorrectPercentRanking($categoryId, $CorrectPercent){
		$oEsIndex = new Model(T_ES_INDEX);
		//题目总数
		$where = '`category_id`=' . $categoryId . ' AND `status`=' . self::OFFICIAL_ES_STATU  . ' AND `answer_counts`>=' . es::lIMIT_ANSWERCOUNT;
		$allEsCount = $oEsIndex->count($where);
		if(!$allEsCount){
			return $allEsCount;
		}
		//大于这个正确率的题目数
		$where .= ' AND `correct_percent`>' . $CorrectPercent;
		$maxCorrectPercentEsCount = $oEsIndex->count($where);
		if($maxCorrectPercentEsCount === false){
			return false;
		}
		return ($maxCorrectPercentEsCount + 1) * 100/$allEsCount;
	}

	//$aCategoryIds:目录id集，$length:拿的题目数， $percent:正确率, $limitCount:至少要多少题随机
	public function getPointCorrectPercentEsIds($aCategoryIds, $length, $percent, $limitCount = 100){
		$oEsIndex = new Model(T_ES_INDEX);
		$where = '';
		if(count($aCategoryIds) == 1){
			$where = '`category_id`=' . $aCategoryIds[0];
		}else{
			$where = '`category_id` in (' . implode(',', $aCategoryIds) . ')';
		}
		$where .= ' AND `correct_percent`>=' . $percent;
		$aEsIdList = $oEsIndex->get('`id`', $where);
		if($aEsIdList === false){
			return false;
		}
		if(count($aEsIdList) < $limitCount){
			if(count($aCategoryIds) == 1){
				$where = '`category_id`=' . $aCategoryIds[0];
			}else{
				$where = '`category_id` in (' . implode(',', $aCategoryIds) . ')';
			}
			$aEsIdList = $oEsIndex->get('`id`', $where, '`correct_percent` DESC', 0, $limitCount);
			if($aEsIdList === false){
				return false;
			}
		}
		if(count($aEsIdList) < $length){
			return false;
		}
		$aEsIds = array();
		$aKeys = array_rand($aEsIdList, $length);
		if(is_array($aKeys)){
			foreach($aKeys as $key){
				$aEsIds[] = $aEsIdList[$key]['id'];
			}
		}else{
			$aEsIds[] = $aEsIdList[$aKeys];
		}
		return $aEsIds;
	}

	/**
	 * 添加解题思路
	 * @param type $aEsAnalysis 解题思路结构体
	 * @return int 添加后的ID
	 */
	public function addEsAnalysis($aEsAnalysis){
		$oEs = new Model(T_ES_ANALYSIS);
		return $oEs->add($aEsAnalysis);
	}

	/**
	 * 修改解题思路
	 * @param type $aEsAnalysis 解题思路结构体
	 * @return int 当前ID
	 */
	public function editEsAnalysis($aData){
		$oEs = new Model(T_ES_ANALYSIS);
		return $oEs->update($aData, array('id' => $aData['id']));
	}

	/**
	 * 批量获取题目的获取解题思路
	 * @param type $aEsIds 题目列表
	 * @param type $userType 前后台用户类型
	 * @param type $isApproved 是否审核
	 * @return array 解题思路列表
	 */
	public function getEsAnalysisList($aEsIds, $userType = null, $isApproved = null){
		$oEs = new Model(T_ES_ANALYSIS);
		$condition = '`id` in(' . implode(',', $aEsIds) . ')';

		if($userType !== null){
			$condition .= '  AND `user_type` = ' . $userType;
		}

		if($isApproved !== null){
			$condition .= '  AND `is_approved` = ' . $isApproved;
		}

		return $oEs->get('', $condition);
	}
}