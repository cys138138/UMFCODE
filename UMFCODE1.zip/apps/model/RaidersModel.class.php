<?php
/*
 * 争分夺宝模型
 */
class RaidersModel{
	public function addPrize($aData){
		$oPrize = new Model(T_RAIDERS_PRIZE);
		if(isset($aData['hd_image'])){
			$aData['hd_image'] = json_encode($aData['hd_image']);
		}
		return $oPrize->add($aData);
	}

	public function setPrize($aData){
		$oPrize = new Model(T_RAIDERS_PRIZE);
		if(isset($aData['hd_image'])){
			$aData['hd_image'] = json_encode($aData['hd_image']);
		}
		return $oPrize->update($aData, array('id' => $aData['id']));
	}

	public function getPrizeInfoById($id){
		$oPrize = new Model(T_RAIDERS_PRIZE);
		$aPrizeInfo = $oPrize->get('', array('id' => $id));
		if($aPrizeInfo){
			$aPrizeInfo = $aPrizeInfo[0];
			if($aPrizeInfo['hd_image']){
				$aPrizeInfo['hd_image'] = json_decode($aPrizeInfo['hd_image'], true);
			}else{
				$aPrizeInfo['hd_image'] = array();
			}
		}
		return $aPrizeInfo;
	}

	public function deletePrizeById($id){
		$oPrize = new Model(T_RAIDERS_PRIZE);
		return $oPrize->delete(array('id' => $id));
	}

	public function getPrizeList($level = 0, $page = 1, $pageSize = 10, $isGivePrize = false){
		$where = $this->_parseWhereForPrize($level, $isGivePrize);
		$offect = ($page - 1) * $pageSize;
		$oPrize = new Model(T_RAIDERS_PRIZE);
		$aPrizeList = $oPrize->get('', $where, '`id` ASC', $offect, $pageSize);
		foreach($aPrizeList as &$aPrize){
			if($aPrize['hd_image']){
				$aPrize['hd_image'] = json_decode($aPrize['hd_image'], true);
			}else{
				$aPrize['hd_image'] = array();
			}
		}
		return $aPrizeList;
	}

	public function getPrizeCount($level = 0){
		$where = $this->_parseWhereForPrize($level);
		$oPrize = new Model(T_RAIDERS_PRIZE);
		return $oPrize->count($where);
	}

	private function _parseWhereForPrize($level, $isGivePrize = false){
		$where = '';
		if($level){
			$where .= '`level`=' . $level;
		}
		if($isGivePrize){
			if($level){
				$where .= ' AND `surplus`>0';
			}else{
				$where .= '`surplus`>0';
			}
		}
		return $where;
	}

	public function addSelectPrizeRecord($aData){
		$oSelectPrizeRecord = new Model(T_RAIDERS_RAIDERS_SELECT_PRIZE_RECORD);
		return $oSelectPrizeRecord->add($aData);
	}

	public function addJoin($aData){
		$aData = $this->_parseDataForJoin($aData);
		$oJoin = new Model(T_RAIDERS_JOIN);
		return $oJoin->add($aData);
	}

	public function setJoin($aData){
		$aData = $this->_parseDataForJoin($aData);
		$oJoin = new Model(T_RAIDERS_JOIN);
		return $oJoin->update($aData, array('id' => $aData['id']));
	}

	private function _parseDataForJoin($aData){
		if(isset($aData['process'])){
			$aData['process'] = json_encode($aData['process']);
		}
		return $aData;
	}

	public function getJoinInfoByUserIdAndUserType($userId, $userType){
		$oJoin = new Model(T_RAIDERS_JOIN);
		$aJoinInfo = $oJoin->get('', '`user_id`=' . $userId . ' AND `user_type`=' . $userType);
		if($aJoinInfo){
			$aJoinInfo = $aJoinInfo[0];
			if($aJoinInfo['process']){
				$aJoinInfo['process'] = json_decode($aJoinInfo['process'], true);
			}else{
				$aJoinInfo['process'] = array();
			}
		}
		return $aJoinInfo;
	}

	public function addAward($aData){
		$oAward = new Model(T_RAIDERS_AWARD);
		return $oAward->add($aData);
	}

	public function setAward($aData){
		$oAward = new Model(T_RAIDERS_AWARD);
		return $oAward->update($aData, array('id' => $aData['id']));
	}

	public function getAwardInfoById($id){
		$oAward = new Model(T_RAIDERS_AWARD);
		$aAwardInfo = $oAward->get('', array('id' => $id));
		if($aAwardInfo){
			$aAwardInfo = $aAwardInfo[0];
		}
		return $aAwardInfo;
	}

	/*
	 * $aCondition = array(
	 *		'user_id'	=>
	 *		'user_type'	=>
	 * )
	 */
	public function getAwardList($page, $pageSize, $aCondition = array()){
		$where = $this->_parseWhereForAward($aCondition);
		$offect = ($page - 1) * $pageSize;
		$oAward = new Model(T_RAIDERS_AWARD);
		$aAwardList =  $oAward->get('', $where, '`create_time` DESC', $offect, $pageSize);
		if(!$aAwardList){
			return $aAwardList;
		}
		$aPrizeIds = array();
		$aTypeUserIds = array(
			1	=>	array(),
			2	=>  array(),
			3	=>  array(),
		);
		foreach($aAwardList as $aAward){
			$aPrizeIds[] = $aAward['prize_id'];
			$aTypeUserIds[$aAward['user_type']][] = $aAward['user_id'];
		}
		$aTypeUserList = $this->_getTypeUserList($aTypeUserIds);
		if($aTypeUserList === false){
			return false;
		}
		$aPrizeList = $this->_getPrizeList($aPrizeIds);
		if($aPrizeList === false){
			return false;
		}
		foreach($aAwardList as $key => $aAward){
			$aAwardList[$key]['user_info'] = array();
			foreach($aTypeUserList as $userType => $aUserList){
				if($userType != $aAward['user_type']){
					continue;
				}
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aAward['user_id']){
						$aAwardList[$key]['user_info'] = $aUser;
						break;
					}
				}
			}
			$aAwardList[$key]['prize_info'] = array();
			foreach($aPrizeList as $aPrize){
				$aPrize['hd_image'] = json_decode($aPrize['hd_image'], true);
				if($aPrize['id'] == $aAward['prize_id']){
					$aAwardList[$key]['prize_info'] = $aPrize;
					break;
				}
			}
		}
		return $aAwardList;
	}

	public function getAwardCount($userId = 0){
		$where = $this->_parseWhereForAward($userId);
		$oAward = new Model(T_RAIDERS_AWARD);
		return $oAward->count($where);
	}

	//$aCondition = array('id' => array(1,2), start_time => 0, end_time => 0)
	public function getOneAwardCount($aCondition = array()){
		$where = '';
		$where .= '`prize_id` in(' . implode(',', $aCondition['id']) . ')';
		$where .= ' AND `create_time` >= ' . $aCondition['start_time'] . ' AND `create_time` <=' . $aCondition['end_time'];
		$oAward = new Model(T_RAIDERS_AWARD);
		return $oAward->count($where);
	}

	private function _getTypeUserList($aTypeUserIds){
		$aTypeUserList = array(
			1	=>	array(),
			2	=>  array(),
			3	=>  array(),
		);
		foreach($aTypeUserIds as $userType => $aUserIds){
			if(!$aUserIds){
				continue;
			}
			if($userType == 2){
				$aTypeUserList[2] = getUserListByUserIds($aUserIds, array('class'));
				if($aTypeUserList[1] === false){
					return false;
				}
			}elseif($userType == 1){
				$oTeacher = new Model(T_TEACHER_INDEX);
				$aTypeUserList[1] = $oTeacher->get('`id`,`name`', array('id' => array('in', $aUserIds)));
				if($aTypeUserList[2] === false){
					return false;
				}
			}elseif($userType == 3){
				$oParent = new Model(T_PARENT);
				$aTypeUserList[3] = $oParent->get('`id`,`name`', array('id' => array('in', $aUserIds)));
				if($aTypeUserList[3] === false){
					return false;
				}
			}
		}
		return $aTypeUserList;
	}

	private function _getPrizeList($aPrizeIds){
		if(!$aPrizeIds){
			return $aPrizeIds;
		}
		$oPrize = new Model(T_RAIDERS_PRIZE);
		return $oPrize->get('', array('id' => array('in', $aPrizeIds)));
	}

	private function _parseWhereForAward($aCondition){
		$where = '';
		if(isset($aCondition['user_type']) && $aCondition['user_type']){
			$where = '`user_type`=' . $aCondition['user_type'];
		}
		if(isset($aCondition['user_id']) && $aCondition['user_id'] && isset($aCondition['user_type']) && $aCondition['user_type']){
			$where = '`user_id`=' . $aCondition['user_id'] . ' AND `user_type`=' . $aCondition['user_type'];
		}
		return $where;
	}

	/*
	 * $aCondition = array(
	 *		'user_type'	=>	0全部 1老师 2学生 3家长
	 *		'is_prize'	=>	0,1  -1全部
	 *		'luck_times'		=>	3 次数 -1 全部
	 *		'surplus_times'		=>	3 次数 -1 全部
	 *		'start_time'		=> 14101242011, 0 无限制
	 *		'end_time'		=>	141 ， 0 无限制
	 * );
	 */
	public function getJoinList($aCondition = array(), $page = 1, $pageSize = 10){
		if(!is_array($aCondition)){
			return false;
		}
		$where = $this->_parseWhereJoin($aCondition);
		$offect = ($page - 1) * $pageSize;
		$oJoin = new Model(T_RAIDERS_JOIN);
		$aJoinList = $oJoin->get('', $where, '`id` DESC', $offect, $pageSize);
		if(!$aJoinList){
			return $aJoinList;
		}
		$aUserIds = array();
		$aParentIds = array();
		$aTeacherIds = array();
		foreach($aJoinList as $aJoin){
			if($aJoin['user_type'] == 1){
				$aTeacherIds[] = $aJoin['user_id'];
			}elseif($aJoin['user_type'] == 3){
				$aParentIds[] = $aJoin['user_id'];
			}else{
				$aUserIds[] = $aJoin['user_id'];
			}
		}
		$aUserList = array();
		$aParentList = array();
		$aTeacherList = array();
		if($aUserIds){
			$aUserList = getUserListByUserIds($aUserIds);
			if($aUserList === false){
				return false;
			}
		}
		if($aTeacherIds){
			$oTeacher = new Model(T_TEACHER);
			$aTeacherList = $oTeacher->get('`id`,`name`', array('id' => array('in', $aTeacherIds)));
			if($aTeacherList === false){
				return false;
			}
		}
		if($aParentIds){
			$oParent = new Model(T_PARENT);
			$aParentList = $oParent->get('`id`,`name`', array('id' => array('in', $aParentIds)));
			if($aParentList === false){
				return false;
			}
		}
		foreach($aJoinList as $key => $aJoin){
			$aJoinList[$key]['user_name'] = '未知';
			if($aJoin['user_type'] == 1){
				foreach($aTeacherList as $aTeacher){
					if($aJoin['user_id'] == $aTeacher['id']){
						$aJoinList[$key]['user_name'] = $aTeacher['name'];
						break;
					}
				}
			}elseif($aJoin['user_type'] == 3){
				foreach($aParentList as $aParent){
					if($aJoin['user_id'] == $aParent['id']){
						$aJoinList[$key]['user_name'] = $aParent['name'];
						break;
					}
				}
			}else{
				foreach($aUserList as $aUser){
					if($aJoin['user_id'] == $aUser['id']){
						$aJoinList[$key]['user_name'] = $aUser['name'];
						break;
					}
				}
			}
		}
		return $aJoinList;
	}
	private function _parseWhereJoin($aCondition){
		$where = '';
		if(!$aCondition){
			return $where;
		}
		if(isset($aCondition['user_type']) && $aCondition['user_type']){
			$where .= '`user_type`=' . $aCondition['user_type'];
		}
		if(isset($aCondition['is_prize']) && $aCondition['is_prize'] != -1){
			if($where){
				$where .= ' AND ';
			}
			if($aCondition['is_prize']){
				$where .= '`award_time`>0';
			}else{
				$where .= '`award_time`=0';
			}
		}
		if(isset($aCondition['luck_times']) && $aCondition['luck_times'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`luck_times`=' . $aCondition['luck_times'];
		}
		if(isset($aCondition['surplus_times']) && $aCondition['surplus_times'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`surplus_times`=' . $aCondition['surplus_times'];
		}
		if(isset($aCondition['start_time']) && $aCondition['start_time']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`>=' . $aCondition['start_time'];
		}
		if(isset($aCondition['end_time']) && $aCondition['end_time']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`<=' . $aCondition['end_time'];
		}
		return $where;
	}

	public function getJoinCount($aCondition){
		$where = $this->_parseWhereJoin($aCondition);
		$oJoin = new Model(T_RAIDERS_JOIN);
		return $oJoin->count($where);
	}

	public function deleteJoinById($id){
		$oJoin = new Model(T_RAIDERS_JOIN);
		return $oJoin->delete(array('id' => $id));
	}
}