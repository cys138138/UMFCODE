<?php
/**
 * BBS模型
 */
class BbsModel{
	//添加目录
	public function addCategory($aData){
		$oBbsCategory = new Model(T_BBS_CATEGORY);
		return $oBbsCategory->add($aData);
	}

	//修改目录
	public function setCategory($aData){
		$oBbsCategory = new Model(T_BBS_CATEGORY);
		return $oBbsCategory->update($aData, array('id' => $aData['id']));
	}

	public function addType($aData){
		$oBbsCategory = new Model(T_BBS_TYPE);
		return $oBbsCategory->add($aData);
	}

	public function setType($aData){
		$oBbsCategory = new Model(T_BBS_TYPE);
		return $oBbsCategory->update($aData, array('id' => $aData['id']));
	}

	public function delType($typeId){
		$oBbsCategory = new Model(T_BBS_TYPE);
		return $oBbsCategory->delete(array('id' => $typeId));
	}

	public function getTypeById($id){
		$oBbsCategory = new Model(T_BBS_TYPE);
		$aType = $oBbsCategory->get('', array('id' => $id));
		if($aType){
			return $aType[0];
		}
		return $aType;
	}

	public function getTypeList($where, $page, $pageSize){
		$oType = new Model(T_BBS_TYPE);
		$offect = ($page - 1) * $pageSize;
		$aList = $oType->get('', $where, '', $offect, $pageSize);
		$oCate = new Model(T_BBS_CATEGORY);
		if($aList){
			foreach($aList as $key => $aType){
				$aName = $oCate->get('`name`', '`id`=' . $aType['category_id']);
				$aList[$key]['cagegory_name'] = $aName[0]['name'];
			}
		}
		return $aList;
	}

	//得到目录信息
	public function getCategoryInfoById($categoryId){
		$oBbsCategory = new Model(T_BBS_CATEGORY);
		$aCategoryInfo = $oBbsCategory->get('', array('id' => $categoryId));
		if($aCategoryInfo){
			$aCategoryInfo = $aCategoryInfo[0];
		}
		return $aCategoryInfo;
	}

	/*
	 * 得到目录列表
	 $aCondition = array(
		 'statu'		=>	0,	0:全部，1：正常，2：停用
		 'order'		=>	'`order` ASC'	排序
	 );
	 */
	public function getCategoryList($page, $pageSize, $aCondition = array('statu' => 1, 'order' => '`order` ASC')){
		if(!isset($aCondition['order'])){
			$aCondition['order'] = '`order` ASC';
		}
		$offect = ($page - 1) * $pageSize;
		$where = $this->_parseWhereForCategory($aCondition);
		$oBbsCategory = new Model(T_BBS_CATEGORY);
		$aCategoryList = $oBbsCategory->get('', $where, $aCondition['order'], $offect, $pageSize);
		return $aCategoryList;
	}

	//得到目录数量
	public function getCategoryCount($aCondition = array('statu' => 1)){
		$where = $this->_parseWhereForCategory($aCondition);
		$oBbsCategory = new Model(T_BBS_CATEGORY);
		return $oBbsCategory->count($where);
	}

	private function _parseWhereForCategory($aCondition){
		if(!isset($aCondition['statu'])){
			$aCondition['statu'] = 0;
		}
		$where = '';
		if($aCondition['statu']){
			$where = '`status`=' . $aCondition['statu'];
		}
		return $where;
	}

	//发帖
	public function addThread($aData){
		$aResultData = $this->_parseDataForThread($aData);
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$threadId = $oDboi->table(T_BBS_THREAD_INDEX)->data($aResultData['thread_index'])->insert();
		if($threadId){
			$aResultData['thread']['id'] = $threadId;
			if(!isset($aResultData['thread']['resource_list'])){
				$aResultData['thread']['resource_list'] = json_encode(array());
			}
			$row = $oDboi->table(T_BBS_THREAD)->data($aResultData['thread'])->insert();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}
		}
		return $threadId;
	}

	//修改帖子
	public function setThread($aData){
		$aResultData = $this->_parseDataForThread($aData);
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$rowIndex = $row = 0;
		if($aResultData['thread_index']){
			$rowIndex = $oDboi->table(T_BBS_THREAD_INDEX)->data($aResultData['thread_index'])->where(array('id' => $aData['id']))->update();
			if($rowIndex === false){
				return false;
			}
		}
		if($aResultData['thread']){
			$row = $oDboi->table(T_BBS_THREAD)->data($aResultData['thread'])->where(array('id' => $aData['id']))->update();
			if($row === false){
				$oDboi->rollBack();
				return false;
			}
		}
		if($rowIndex || $row){
			return 1;
		}
		return 0;
	}

	private function _parseDataForThread($aData){
		$aResultData = array(
			'thread_index'	=>	array(),
			'thread'		=>	array(),
		);
		if(isset($aData['content'])){
			$aResultData['thread']['content'] = $aData['content'];
			unset($aData['content']);
		}
		if(isset($aData['resource_list'])){
			$aResultData['thread']['resource_list'] = json_encode($aData['resource_list']);
			unset($aData['resource_list']);
		}
		$aResultData['thread_index'] = $aData;
		return $aResultData;
	}

	//删除帖子---删除帖子下面的所有评论
	public function deleteThreadById($threadId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$rowIndex = $oDboi->table(T_BBS_THREAD_INDEX)->where(array('id' => $threadId))->delete();
		if(!$rowIndex){
			return $rowIndex;
		}
		$row = $oDboi->table(T_BBS_THREAD)->where(array('id' => $threadId))->delete();
		if(!$row){
			$oDboi->rollBack();
			return false;
		}
		$aCommentList = $oDboi->fields('`id`')->table(T_BBS_COMMENT_INDEX)->where('`thread_id`=' . $threadId)->select();
		if($aCommentList === false){
			$oDboi->rollBack();
			return false;
		}elseif($aCommentList){
			$aCommentIds = array();
			foreach($aCommentList as $aComment){
				$aCommentIds[] = $aComment['id'];
			}
			$where = array('id' => array('in', $aCommentIds));
			$row1 = $oDboi->table(T_BBS_COMMENT_INDEX)->where($where)->delete();
			if(!$row1){
				$oDboi->rollBack();
				return false;
			}
			$row2 = $oDboi->table(T_BBS_COMMENT)->where($where)->delete();
			if(!$row2){
				$oDboi->rollBack();
				return false;
			}
		}
		return $rowIndex;
	}

	//得到帖子信息
	public function getThreadInfoById($threadId){
		$oBbsThreadIndex = new Model(T_BBS_THREAD_INDEX);
		$aThreadIndexInfo = $oBbsThreadIndex->get('', array('id' => $threadId));
		if($aThreadIndexInfo){
			$aThreadIndexInfo = $aThreadIndexInfo[0];
			$oBbsThread= new Model(T_BBS_THREAD);
			$aThreadInfo = $oBbsThread->get('', array('id' => $threadId));
			if(!$aThreadInfo){
				return false;
			}
			$aThreadIndexInfo['content'] = $aThreadInfo[0]['content'];
			$aThreadIndexInfo['resource_list'] = json_decode($aThreadInfo[0]['resource_list'], true);
		}
		return $aThreadIndexInfo;
	}

	/*得到帖子列表
	 *$aCondition = array(
			'category_id'	=> 0, 0:全部
	 *		'is_recommend'	=>	-1, -1:全部，0：未推荐，1：推荐
	 *		'is_top'			=>	-1，-1：全部,0：未置顶，1：置顶
	 *		'statu'			=>	0	0:全部，1：草稿，2：已发布
	 *		'user_id'		=>	0	0:全部，用户id
	 *		'get_category_name'	=>	0	0:不显示，1：显示
	 *		'ids'		=>	''	'':全部，逗号分隔的id字符串
	 *		'limit_read_times'	=>	0,	0:全部，其他为大于等于
	 *		'create_time_min'	=>	0,	0:不限制,其他为大于等于这个时间
	 *		'create_time_max'	=>	0,	0:不限制,其他为小于等于这个时间
	 *		'last_reply_time_min'	=>	0,	0:不限制,其他为大于等于这个时间
	 *		'last_reply_time_max'	=>	0,	0:不限制,其他为小于等于这个时间
	 );
	 */
	public function getThreadList($page, $pageSize, $aCondition, $order = ''){
		$where = $this->_parseWhereForThread($aCondition);
		$getCategoryName = 0;
		if((isset($aCondition['user_id']) && $aCondition['user_id']) || (isset($aCondition['get_category_name']) && $aCondition['get_category_name'])){
			$getCategoryName = 1;
		}
		$offect = ($page - 1) * $pageSize;
		$oBbsThreadIndex = new Model(T_BBS_THREAD_INDEX);
		$aThreadIndexList = $oBbsThreadIndex->get('', $where, $order, $offect, $pageSize);
		if(!$aThreadIndexList){
			return $aThreadIndexList;
		}
		$aUserIds = array();
		$aCategoryIds = array();
		foreach($aThreadIndexList as $aThreadIndex){
			$aUserIds[] = $aThreadIndex['user_id'];
			$aCategoryIds[] = $aThreadIndex['category_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds, array('numerical', 'class'));
		if($aUserList === false){
			return $aUserList;
		}
		$aCategoryList = array();
		if($getCategoryName){
			$oCategory = new Model(T_BBS_CATEGORY);
			$aCategoryList = $oCategory->get('`id`,`name`', array('id' => array('in', $aCategoryIds)));
			if($aCategoryList === false){
				return false;
			}
		}
		foreach($aThreadIndexList as $key => $aThreadIndex){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aThreadIndex['user_id']){
					$aThreadIndexList[$key]['user_info'] = $aUser;
					if($aThreadIndex['is_anonymous']){
						$aThreadIndexList[$key]['user_info']['name'] = '匿名用户';
						$aThreadIndexList[$key]['user_info']['profile'] = '';
						$aThreadIndexList[$key]['user_info']['id'] = 0;
					}
					break;
				}
			}
			foreach($aCategoryList as $aCategory){
				if($aCategory['id'] == $aThreadIndex['category_id']){
					$aThreadIndexList[$key]['category_name'] = $aCategory['name'];
					break;
				}
			}
		}
		return $aThreadIndexList;
	}

	public function getThreadCount($aCondition){
		$where = $this->_parseWhereForThread($aCondition);
		$oBbsThread = new Model(T_BBS_THREAD_INDEX);
		return $oBbsThread->count($where);
	}

	/*得到帖子列表
	 *$aCondition = array(
			'category_id'	=> 0, 0:全部
	 *		'is_recommend'	=>	-1, -1:全部，0：未推荐，1：推荐
	 *		'is_top'			=>	-1，-1：全部,0：未置顶，1：置顶
	 *		'statu'			=>	0	0:全部，1：草稿，2：已发布
	 *		'user_id'		=>	0	0:全部，用户id
	 );
	 */
	private function _parseWhereForThread($aCondition){
		$where = '';
		if(isset($aCondition['category_id']) && $aCondition['category_id']){
			$where = '`category_id`=' . $aCondition['category_id'];
		}
		if(isset($aCondition['is_recommend']) && $aCondition['is_recommend'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_recommend`=' . $aCondition['is_recommend'];
		}
		if(isset($aCondition['is_top']) && $aCondition['is_top'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_top`=' . $aCondition['is_top'];
		}
		if(isset($aCondition['is_top']) && $aCondition['is_top'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_top`=' . $aCondition['is_top'];
		}
		if(isset($aCondition['statu']) && $aCondition['statu']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`status`=' . $aCondition['statu'];
		}
		if(isset($aCondition['user_id']) && $aCondition['user_id']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`user_id`=' . $aCondition['user_id'];
		}
		if(isset($aCondition['ids']) && $aCondition['ids']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`id` in (' . $aCondition['ids'] . ')';
		}
		if(isset($aCondition['limit_read_times']) && $aCondition['limit_read_times']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`read_times`>=' . $aCondition['limit_read_times'];
		}
		if(isset($aCondition['limit_support_times']) && $aCondition['limit_support_times']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`support_times`>=' . $aCondition['limit_support_times'];
		}
		if(isset($aCondition['create_time_min']) && $aCondition['create_time_min']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`>=' . $aCondition['create_time_min'];
		}
		if(isset($aCondition['create_time_max']) && $aCondition['create_time_max']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`create_time`<=' . $aCondition['create_time_max'];
		}
		if(isset($aCondition['last_reply_time_min']) && $aCondition['last_reply_time_min']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`last_reply_time`>=' . $aCondition['last_reply_time_min'];
		}
		if(isset($aCondition['last_reply_time_max']) && $aCondition['last_reply_time_max']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`last_reply_time`<=' . $aCondition['last_reply_time_max'];
		}
		return $where;
	}

	//今天发帖数量
	public function getThreadCountInToday($categoryId = 0){
		$beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
		$where = '`create_time`>=' . $beginToday . ' AND `create_time`<=' . time();
		if($categoryId){
			$where .= ' AND `category_id`=' . $categoryId;
		}
		$oBbsThread = new Model(T_BBS_THREAD_INDEX);
		return $oBbsThread->count($where);
	}

		//发表评论
	public function addComment($aData){
		$aCommentData = array();
		$aCommentData['content'] = $aData['content'];
		unset($aData['content']);
		if(isset($aData['resource_list'])){
			$aCommentData['resource_list'] = json_encode($aData['resource_list']);
			unset($aData['resource_list']);
		}else{
			$aCommentData['resource_list'] = json_encode(array());
		}
		$aCommentIndexData = $aData;
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$commentId = $oDboi->table(T_BBS_COMMENT_INDEX)->data($aCommentIndexData)->insert();
		if($commentId){
			$aCommentData['id'] = $commentId;
			$row = $oDboi->table(T_BBS_COMMENT)->data($aCommentData)->insert();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}
		}
		return $commentId;
	}

	//删除评论
	public function deleteComment($commentId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$indexRows = $oDboi->table(T_BBS_COMMENT_INDEX)->where(array('id' => $commentId))->delete();
		if($indexRows){
			$rows = $oDboi->table(T_BBS_COMMENT)->where(array('id' => $commentId))->delete();
			if($rows === false){
				$oDboi->rollBack();
				return false;
			}
		}
		return $indexRows;
	}

	//得到评论列表
	public function getCommentListByThreadId($threadId, $page, $pageSize, $order = '`id` ASC'){
		$oBbsCommentIndex = new Model(T_BBS_COMMENT_INDEX);
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if($threadId){
			$where = '`thread_id`=' . $threadId;
		}
		$aCommentList = $oBbsCommentIndex->get('', $where, '`id` ASC', $offect, $pageSize);
		if(!$aCommentList){
			return $aCommentList;
		}
		$aParentCommentIds = array();
		$aUserIds = array();
		$aFirstCommentIds = array();
		foreach($aCommentList as $aComment){
			if($aComment['parent_id']){
				$aParentCommentIds[] = $aComment['parent_id'];
			}
			$aFirstCommentIds[] = $aComment['id'];
			$aUserIds[] = $aComment['user_id'];
		}
		$aParentCommentIds = array_diff($aParentCommentIds, $aFirstCommentIds);
		$aParentCommentList = array();
		if($aParentCommentIds){
			$aParentCommentList = $oBbsCommentIndex->get('', '`id` in (' . implode(',', $aParentCommentIds) . ')');
			if($aParentCommentList === false){
				return false;
			}
		}
		$aCommentIds = $aFirstCommentIds;
		foreach($aParentCommentList as $aParentComment){
			$aCommentIds[] = $aParentComment['id'];
		}
		$oBbsComment = new Model(T_BBS_COMMENT);
		$aCommentContentList = $oBbsComment->get('', array('id' => array('in', $aCommentIds)));
		if(!$aCommentContentList){
			return $aCommentContentList;
		}

		$aAllCommentList = array_merge($aCommentList, $aParentCommentList);
		$aAllCommentList = $this->_mergeCommentList($aAllCommentList, $aCommentContentList);
		unset($aCommentContentList);
		$aUserList = getUserListByUserIds($aUserIds, array('numerical', 'class'));
		if($aUserList === false){
			return false;
		}
		$aThreadInfo = $this->getThreadInfoById($threadId);
		$aAllCommentReferList = array();
		foreach($aAllCommentList as $key => $aAllComment){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aAllComment['user_id']){
					$aAllComment['user_info'] = $aUser;
					if($aThreadInfo['is_anonymous'] && $aUser['id'] == $aThreadInfo['user_id']){
						$aAllComment['user_info']['name'] = '匿名用户';
						$aAllComment['user_info']['vip'] = 0;
						$aAllComment['user_info']['profile'] = '';
						$aAllComment['user_info']['level'] = '?';
						$aAllComment['user_info']['id'] = 0;
					}
					break;
				}
			}
			$aAllCommentReferList[$aAllComment['id']] = $aAllComment;
		}
		unset($aUserList);
		unset($aAllCommentList);
		foreach($aCommentList as $key => $aComment){
			$aCommentList[$key] = $aAllCommentReferList[$aComment['id']];
			if($aComment['parent_id']){
				$aCommentList[$key]['parent_info'] = array();
				if(isset($aAllCommentReferList[$aComment['parent_id']])){
					$aCommentList[$key]['parent_info'] = $aAllCommentReferList[$aComment['parent_id']];
				}
			}
		}
		return $aCommentList;
	}

	private function _mergeCommentList($aCommentIndexList, $aCommentList){
		foreach($aCommentIndexList as &$aCommentIndex){
			foreach($aCommentList as $aComment){
				if($aComment['id'] == $aCommentIndex['id']){
					$aCommentIndex['content'] = $aComment['content'];
					$aCommentIndex['resource_list'] = json_decode($aComment['resource_list'], true);
					break;
				}
			}
		}
		return $aCommentIndexList;
	}

	public function getCommentCountByThreadId($threadId = 0){
		$where = '';
		if($threadId){
			$where = '`thread_id`=' . $threadId;
		}
		$oBbsCommentIndex = new Model(T_BBS_COMMENT_INDEX);
		return $oBbsCommentIndex->count($where);
	}

	public function getUserCommentList($userId, $page, $pageSize, $categoryId = 0, $order = '`create_time` DESC'){
		$oBbsCommentIndex = new Model(T_BBS_COMMENT_INDEX);
		$offect = ($page - 1) * $pageSize;
		if($categoryId){
			$oDboi = new DBOI();
			$where = '`t1`.`user_id`=' . $userId . ' AND `thread`.`category_id`=' . $categoryId;
			$aCommentList = $oDboi->fields('`t1`.*')->table(T_BBS_COMMENT_INDEX)->leftjoin(T_BBS_THREAD_INDEX, 'as `thread` on `t1`.`thread_id`=`thread`.`id`')->where($where)->select();
		}else{
			$aCommentList = $oBbsCommentIndex->get('', '`user_id`=' . $userId, $order, $offect, $pageSize);
		}
		if(!$aCommentList){
			return $aCommentList;
		}
		$aThreadIds = array();
		$aCommentIds = array();
		foreach($aCommentList as $aComment){
			$aThreadIds[] = $aComment['thread_id'];
			$aCommentIds[] = $aComment['id'];
		}
		$oBbsComment = new Model(T_BBS_COMMENT);
		$aCommentContentList = $oBbsComment->get('', array('id' => array('in', $aCommentIds)));
		if(!$aCommentContentList){
			return $aCommentContentList;
		}
		$aCommentList = $this->_mergeCommentList($aCommentList, $aCommentContentList);
		$oThread = new Model(T_BBS_THREAD_INDEX);
		$aThreadList = $oThread->get('', array('id' => array('in', $aThreadIds)));
		if($aThreadList === false){
			return false;
		}
		$aUserIds = array();
		$aCategoryIds = array();
		foreach($aThreadList as $aThread){
			$aUserIds[] = $aThread['user_id'];
			$aCategoryIds[] = $aThread['category_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if($aUserList === false){
			return false;
		}
		$oCategory = new Model(T_BBS_CATEGORY);
		$aCategoryList = $oCategory->get('`id`,`name`', array('id' => array('in', $aCategoryIds)));
		if($aCategoryList === false){
			return false;
		}
		foreach($aThreadList as $key => $aThread){
			foreach($aCategoryList as $aCategory){
				if($aCategory['id'] == $aThread['category_id']){
					$aThreadList[$key]['category_name'] = $aCategory['name'];
					break;
				}
			}
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aThread['user_id']){
					$aThreadList[$key]['user_info'] = $aUser;
					break;
				}
			}
		}
		foreach($aCommentList as $key => $aComment){
			foreach($aThreadList as $aThread){
				if($aThread['id'] == $aComment['thread_id']){
					$aCommentList[$key]['thread_info'] = $aThread;
					break;
				}
			}
		}
		return $aCommentList;
	}

	public function getUserCommentCount($userId, $categoryId = 0){
		if($categoryId){
			$oDboi = new DBOI();
			$where = '`t1`.`user_id`=' . $userId . ' AND `thread`.`category_id`=' . $categoryId;
			$aCount = $oDboi->fields('count(*) as `nums`')->table(T_BBS_COMMENT_INDEX)->leftjoin(T_BBS_THREAD_INDEX, 'as `thread` on `t1`.`thread_id`=`thread`.`id`')->where($where)->select();
			if($aCount === false){
				return false;
			}
			return $aCount[0]['nums'];
		}else{
			$where = '`user_id`=' . $userId;
			$oBbsCommentIndex = new Model(T_BBS_COMMENT_INDEX);
			return $oBbsCommentIndex->count($where);
		}
	}

	public function setCommentIndex($aData){
		$oBbsCommentIndex = new Model(T_BBS_COMMENT_INDEX);
		return $oBbsCommentIndex->update(array('support_times' => $aData['support_times']), array('id' => $aData['id']));
	}

	public function getCommentById($commentId){
		$oBbsCommentIndex = new Model(T_BBS_COMMENT_INDEX);
		$aCommentInfo = $oBbsCommentIndex->get('', array('id' => $commentId));
		if($aCommentInfo){
			$aCommentInfo = $aCommentInfo[0];
		}
		return $aCommentInfo;
	}

	//-------------话题消息----------
	public function addNotification($aData){
		$oNotification = new Model(T_BBS_NOTIFICATION);
		return $oNotification->add($aData);
	}

	public function setNotification($aData){
		$oNotification = new Model(T_BBS_NOTIFICATION);
		return $oNotification->update(array(
			'is_read' => $aData['is_read']
		), array('id' => $aData['id']));
	}

	public function delNotification($id){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$indexRows = $oDboi->table(T_BBS_NOTIFICATION)->where(array('id' => $id))->delete();
		return $indexRows;
	}

	public function getNotificationById($id){
		$oNotification = new Model(T_BBS_NOTIFICATION);
		$aNotificationInfo = $oNotification->get('', array('id' => $id));
		if($aNotificationInfo){
			return $aNotificationInfo = $aNotificationInfo[0];
		}
		return $aNotificationInfo;
	}

	public function getNotificationList($page, $pageSize, $aCondition){
		$where = '';
		if(isset($aCondition['user_id']) && $aCondition['user_id']){
			$where = '`user_id`=' . $aCondition['user_id'];
		}
		if(isset($aCondition['is_read'])){
			$where .= ' AND `is_read`=' . $aCondition['is_read'];
		}
		$offect = ($page - 1) * $pageSize;

		//获取消息信息
		$oNotification = new Model(T_BBS_NOTIFICATION);
		$aNotificationList = $oNotification->get('', $where, '`is_read` ASC, `id` DESC', $offect, $pageSize);
		if(!$aNotificationList){
			return $aNotificationList;
		}

		$aCommentIds = $aNotificationContentList = array();
		foreach($aNotificationList as $aCommentId){
			$aCommentIds[] = $aCommentId['comment_id'];
		}
		//拿到消息的评论id后开始拿评论基础数据
		$oBbsComment = new Model(T_BBS_COMMENT_INDEX);
		$aCommentIndexList = $oBbsComment->get('id,thread_id,parent_id,user_id,create_time', array('id' => array('in', $aCommentIds)));
		if(!$aCommentIndexList){
			return $aCommentIndexList;
		}

		//获取评论内容
		$oBbsCommentContent = new Model(T_BBS_COMMENT);
		$aCommentContentList = $oBbsCommentContent->get('id,content', array('id' => array('in', $aCommentIds)));
		if(!$aCommentContentList){
			return $aCommentContentList;
		}

		//过滤出需要的内容和拿出主题id
		$aThreadIds = array();
		foreach($aCommentIndexList as $key => $aComment){
			$aThreadIds[$key] = $aComment['thread_id'];

			$aNotificationContentList[$key] = array_merge($aNotificationList[$key], array(
				'comment_user_info' => getUserInfo($aComment['user_id'], array('class')),
				'thread_id' => $aComment['thread_id'],
				'parent_id' => $aComment['parent_id'],
				'create_time' => $aComment['create_time'],
				'user_id' => $aComment['user_id'],
			));
			/*if($aComment['id'] == $aCommentContentList[$key]['id']){
				$aNotificationContentList[$key]['comment_content'] = $aCommentContentList[$key]['content'];
			}*/
			$aNotificationContentList[$key]['comment_content'] = '';
			foreach($aCommentContentList as $aCommentContent){
				if($aCommentContent['id'] == $aComment['id']){
					$aNotificationContentList[$key]['comment_content'] = $aCommentContent['content'];
					break;
				}
			}
		}

		$oThread = new Model(T_BBS_THREAD_INDEX);
		$aThreadList = $oThread->get('`id`, `user_id`, `title`, `is_anonymous`', array('id' => array('in', $aThreadIds)));

		if($aThreadList === false){
			return false;
		}
		foreach($aNotificationContentList as $i => $aNotificationContentListValue){
			foreach($aThreadList as $aVal){
				if($aNotificationContentListValue['thread_id'] == $aVal['id']){
					$aNotificationContentList[$i]['title'] = $aVal['title'];
					if($aVal['is_anonymous'] && $aNotificationContentListValue['user_id'] == $aVal['user_id']){
						$aNotificationContentList[$i]['comment_user_info'] = [
							'id' => 0,
							'name' => '匿名用户',
							'profile' => '',
							'vip' => 0,
						];
					}
				}
			}

		}
		unset($aNotificationList);
		unset($aCommentIndexList);
		unset($aCommentContentList);
		unset($aCommentIds);
		unset($aThreadIds);
		unset($aThreadList);
		return $aNotificationContentList;
	}

	public function getNotificationCount($aCondition){
		$where = '';
		if(isset($aCondition['user_id']) && $aCondition['user_id']){
			$where = '`user_id`=' . $aCondition['user_id'];
		}
		if(isset($aCondition['is_read'])){
			$where .= ' AND `is_read`=' . $aCondition['is_read'];
		}
		$oNotification = new Model(T_BBS_NOTIFICATION);
		return $oNotification->count($where);
	}

	public function getCommentTimeLessThanCount($aCondition){
		$where = '';
		if(isset($aCondition['thread_id']) && $aCondition['thread_id']){
			$where = '`thread_id`=' . $aCondition['thread_id'];
		}
		if(isset($aCondition['create_time']) && $aCondition['create_time']){
			$where .= ' AND `create_time`<' . $aCondition['create_time'];
		}

		$oBbsComment = new Model(T_BBS_COMMENT_INDEX);
		return $oBbsComment->count($where);
	}

	public function ignoreUserNotice($userId){
		$oNotification = new Model(T_BBS_NOTIFICATION);
		return $oNotification->update(array('is_read' => 1), '`user_id`=' . $userId);
	}
}
