<?php
/*
 * 用户行为模型
 */
class UserBehaviorModel{
	public function getInitDataForUserDailyBehavior($userId){
		$aRandomTaskIds = [1, 2, 3, 4, 7, 8];
		$aRandIndexs = array_rand($aRandomTaskIds, 3);
		$firstTask = $aRandomTaskIds[$aRandIndexs[0]];
		$secondTask = $aRandomTaskIds[$aRandIndexs[1]];
		$thirdTask = $aRandomTaskIds[$aRandIndexs[2]];
		$aData = array(
			'id' => $userId,
			'create_time' => time(),
			'add_friend_times' => 0,
			'publish_shuoshuo_times' => 0,
			'publish_wenwen_times' => 0,
			'reply_wenwen_times' => 0,
			'comment_times' => 0,
			'first_task_es_count' => 0,
			'more_task_es_count' => 0,
			'first_mission_es_count' => 0,
			'more_mission_es_count' => 0,
			'task' => array(
				array(
					'task_id' => $firstTask,
					'finish_times' => 0,
					'status' => 1,
				),
				array(
					'task_id' => $secondTask,
					'finish_times' => 0,
					'status' => 1,
				),
				array(
					'task_id' => $thirdTask,
					'finish_times' => 0,
					'status' => 1,
				),
			),
		);
		return  $aData;
	}
	public function addUserDailyBehavior($aData){
		$oUserDailyBehavior = new Model(T_USER_DAILY_BEHAVIOR);
		if(isset($aData['task'])){
			$aData['task'] = json_encode($aData['task']);
		}else{
			$aData['task'] = json_encode(array());
		}
		return $oUserDailyBehavior->add($aData);
	}

	public function setUserDailyBehavior($aData){
		$oUserDailyBehavior = new Model(T_USER_DAILY_BEHAVIOR);
		if(isset($aData['task'])){
			$aData['task'] = json_encode($aData['task']);
		}
		return $oUserDailyBehavior->update($aData, array('id' => $aData['id']));
	}

	public function getUserDailyBehaviorInfo($id){
		$oUserDailyBehavior = new Model(T_USER_DAILY_BEHAVIOR);
		$aUserDailyBehaviorInfo = $oUserDailyBehavior->get('', array('id' => $id));
		if($aUserDailyBehaviorInfo){
			$aUserDailyBehaviorInfo = $aUserDailyBehaviorInfo[0];
			if($aUserDailyBehaviorInfo['task']){
				$aUserDailyBehaviorInfo['task'] = json_decode($aUserDailyBehaviorInfo['task'], true);
			}else{
				$aUserDailyBehaviorInfo['task'] = array();
			}
		}
		return $aUserDailyBehaviorInfo;
	}

	public function addMark($aData){
		$oMark = new Model(T_MARK);
		return $oMark->add($aData);
	}

	public function setMark($aData){
		$oMark = new Model(T_MARK);
		return $oMark->update($aData, array('id' => $aData['id']));
	}

	public function getMarkInfoById($markId){
		$oMark = new Model(T_MARK);
		$aMarkInfo = $oMark->get('', array('id' => $markId));
		if($aMarkInfo){
			$aMarkInfo = $aMarkInfo[0];
		}
		return $aMarkInfo;
	}

	public function getMarkRankingList($page = 1, $pageSize = 10, $aUserIds = array(), $order = '`mark_total` desc'){
		$offect = ($page - 1) * $pageSize;
		$oMark = new Model(T_MARK);
		$where = '';
		if($aUserIds){
			$where = array('id' => array('in', $aUserIds));
		}
		return $oMark->get('', $where, $order, $offect, $pageSize);
	}

	public function getMarkRankingCount($aUserIds = array()){
		$oMark = new Model(T_MARK);
		$where = '';
		if($aUserIds){
			$where = array('id' => array('in', $aUserIds));
		}
		return $oMark->count($where);
	}

	public function getUserMarkRanking($markTotal, $aUserIds = array()){
		$oMark = new Model(T_MARK);
		$where = '`mark_total`>' . $markTotal;
		if($aUserIds){
		//好友排名
			$where .= ' AND `id` in (' . implode(',', $aUserIds) . ')';
		}
		return $oMark->count($where) + 1;
	}
}