<?php
/*
 * UB消费记录模型
 */
class UbUsedModel{
	//ub兑换金币
	public function exchangeUbToGold($userId, $ub){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$gold = $ub * UB_GOLD_RATE;
		$aData = array();
		$aData['user_id'] = $userId;
		$aData['type'] = 2;
		$aData['content'] = $gold;
		$aData['ub'] = $ub;
		$aData['create_time'] = time();
		$ubUsedId = $oDboi->table(T_UB_USED)->data($aData)->insert();
		if($ubUsedId){
			$aUpdateData['gold'] = array('add', $gold);
			$aUpdateData['ub'] = array('sub', $ub);
			$row = $oDboi->table(T_USER_NUMERICAL)->data($aUpdateData)->where(array('id' => $userId))->update();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}
		}
		return $ubUsedId;
	}

	//用户ub消费记录
	public function getUbUsedList($userId, $type = 0, $page = 1, $pageSize = 10, $order = '`create_time` DESC'){
		$oUbUsed = new Model(T_UB_USED);
		$where = '`user_id`=' . $userId;
		if($type){
			$where .= ' AND `type`=' . $type;
		}
		$offect = ($page - 1) * $pageSize;
		$aUbusedList = $oUbUsed->get('', $where, $order, $offect, $pageSize);
		if($aUbusedList){
			foreach($aUbusedList as &$aUbused){
				if(!is_numeric($aUbused['content'])){
					$aUbused['content'] = json_decode($aUbused['content'], true);
				}
			}
		}
		return $aUbusedList;
	}
}