<?php
/*
 * SNS模型
 */
class EventModel{
	//用户动态表配置
	private $_aSnsEvent = array(
		'publish_shuoshuo'	=>	1,	//发表说说
		'retransmission_shuoshuo'	=>	2,	//转发说说
		'become_friends'	=>	3,	//成为好友
		'receive_gift'	=>	4,	//收到礼物
		'birthday_remind'	=>	5,	//生日提醒
		'pass_mission'	=>	6,	//过关
		'finish_task'	=>	7,	//完成修炼
	);

	const IS_SUPPORTED = -1;	//我是否已经赞过
	//获取好友UserIds
	//查看好友信息
	public function getUserFriendInfo($userId){
		$oFriend = new Model(T_USER_FRIEND);
		$aFriendInfo = $oFriend->get('*', '`id` = ' . $userId);
		if($aFriendInfo){
			$aFriendInfo[0]['friends'] = json_decode($aFriendInfo[0]['friends'], true);
			return $aFriendInfo[0];
		}else{
			return $aFriendInfo;
		}
	}

	public function getUserFriendIds($userId){
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo === false){
			return false;
		}elseif(!$aUserFriendInfo){
			return '';
		}else{
			$friendIds = '';
			if($aUserFriendInfo['friends']){
				foreach($aUserFriendInfo['friends'] as $friends){
					if($friends){
						$friendIds .= $friends . ',';
					}
				}
				if($friendIds){
					$friendIds = substr($friendIds, 0, -1);
				}
			}
			return $friendIds;
		}
	}

	public function getUserListByUserIds($aUserIds){
		if(!$aUserIds || !is_array($aUserIds)){
			return array();
		}
		$aUserIds = array_unique($aUserIds);
		$oPersonal = new Model(T_PERSONAL);
		$aUserList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
		return $aUserList;
	}

	public function getShuoshuoListByShuoshuoIds($aShuoshuoIds){
		if(!$aShuoshuoIds || !is_array($aShuoshuoIds)){
			return array();
		}
		//读取说说列表
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoList = $oShuoshuo->get('', array('id' => array('in', $aShuoshuoIds)));
		if(!$aShuoshuoList){
			return $aShuoshuoList;
		}
		$aSourceShuoshuoIds = array();
		foreach($aShuoshuoList as $aShuoshuo){
			if($aShuoshuo['source_id']){
				$aSourceShuoshuoIds[] = $aShuoshuo['source_id'];
			}
			$aUserIds[] = $aShuoshuo['user_id'];
		}
		if($aSourceShuoshuoIds){
			$aSourceShuoshuoIds = array_unique($aSourceShuoshuoIds);
			$aSourceShuoshuoList = $oShuoshuo->get('', array('id' => array('in', $aSourceShuoshuoIds)));
			if($aSourceShuoshuoList === false){
				return false;
			}
			$aUserIds = array();
			foreach($aSourceShuoshuoList as $aSourceShuoshuo){
				$aUserIds[] = $aSourceShuoshuo['user_id'];
			}
			$aUserList = $this->getUserListByUserIds($aUserIds);
			if($aUserList === false){
				return false;
			}
			foreach($aSourceShuoshuoList as &$aSourceShuoshuo){
				$aSourceShuoshuo['user_info'] = array();
				foreach($aUserList as $aUser){
					if($aSourceShuoshuo['user_id'] == $aUser['id']){
						$aSourceShuoshuo['user_info'] = $aUser;
					}
				}
			}
		}
		foreach($aShuoshuoList as &$aShuoshuo){
			if($aShuoshuo['source_id']){
				$aShuoshuo['source'] = array();
				foreach($aSourceShuoshuoList as $aSourceShuoshuo){
					if($aShuoshuo['source_id'] == $aSourceShuoshuo['id']){
						$aShuoshuo['source'] = $aSourceShuoshuo;
					}
				}
			}
		}
		return $aShuoshuoList;
	}

	public function getUserMissionListByUserMissionRelationIds($aUserMissionRelationIds){
		if(!$aUserMissionRelationIds || !is_array($aUserMissionRelationIds)){
			return array();
		}
		$oMissionUserRelation = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserMissionRelationList = $oMissionUserRelation->get('', array('id' => array('in', $aUserMissionRelationIds)));
		if(!$aUserMissionRelationList){
			return $aUserMissionRelationList;
		}
		$aMissionIds = array();
		foreach($aUserMissionRelationList as $aUserMissionRelation){
			$aMissionIds[] = $aUserMissionRelation['mission_id'];
		}
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('', array('id' => array('in', $aMissionIds)));
		if($aMissionList === false){
			return false;
		}
		foreach($aUserMissionRelationList as &$aUserMissionRelation){
			foreach($aMissionList as $aMission){
				if($aUserMissionRelation['mission_id'] == $aMission['id']){
					$aUserMissionRelation['mission_name'] = $aMission['name'];
				}
			}
		}
		return $aUserMissionRelationList;
	}

	public function getFriendsEventListByUserId($userId, $offect = 0, $length = null){
		$friendIds = $this->getUserFriendIds($userId);
		if($friendIds === false){
			return false;
		}elseif(!$friendIds){
			return array();
		}
		$oEvent = new Model(T_SNS_EVENT);
		$aEventList = $oEvent->get('', '`user_id` in (' . $friendIds . ')', '`id` desc', $offect, $length);
		if($aEventList){
			$aUserIds = array();
			$aShuoshuoIds = array();
			$aUserRelationIds = array();
			$aUserMissionRelationIds = array();
			foreach($aEventList as $aEvent){
				if($aEvent['type'] == $this->_aSnsEvent['publish_shuoshuo'] || $aEvent['type'] == $this->_aSnsEvent['retransmission_shuoshuo']){
					$aShuoshuoIds[] = $aEvent['data_id'];
				}elseif($aEvent['type'] == $this->_aSnsEvent['become_friends']){
					$aUserRelationIds[] = $aEvent['data_id'];
				}elseif($aEvent['type'] == $this->_aSnsEvent['pass_mission'] || $aEvent['type'] == $this->_aSnsEvent['finish_task']){
					$aUserMissionRelationIds[] = $aEvent['data_id'];
				}
				$aUserIds[] = $aEvent['user_id'];
			}
			$aShuoshuoList = array();
			if($aShuoshuoIds){
				$aShuoshuoList = $this->getShuoshuoListByShuoshuoIds($aShuoshuoIds);
				if($aShuoshuoList === false){
					return false;
				}
			}
			//用户关卡相关记录
			$aUserMissionList = array();
			if($aUserMissionRelationIds){
				$aUserMissionRelationIds = array_unique($aUserMissionRelationIds);
				$aUserMissionList = $this->getUserMissionListByUserMissionRelationIds($aUserMissionRelationIds);
				if($aUserMissionList === false){
					return false;
				}
			}

			//成为好友动态
			$aUserRelationList = array();
			if($aUserRelationIds){
				$aUserRelationIds = array_unique($aUserRelationIds);
				$oUserRelation = new Model(T_USER_RELATION);
				$aUserRelationList = $oUserRelation->get('', array('id' => array('in', $aUserRelationIds)));
				if($aUserRelationList === false){
					return false;
				}
				foreach($aUserRelationList as $aUserRelation){
					$aUserIds[] = $aUserRelation['user_master_id'];
					$aUserIds[] = $aUserRelation['user_slave_id'];
				}
			}

			$aUserList = $this->getUserListByUserIds($aUserIds);
			foreach($aEventList as &$aEvent){
				$aEvent['data'] = array();
				if($aEvent['type'] == $this->_aSnsEvent['publish_shuoshuo'] || $aEvent['type'] == $this->_aSnsEvent['retransmission_shuoshuo']){
					foreach($aShuoshuoList as $aShuoshuo){
						if($aEvent['data_id'] == $aShuoshuo['id']){
							$aEvent['data'] = $aShuoshuo;
						}
					}
				}elseif($aEvent['type'] == $this->_aSnsEvent['become_friends']){
					foreach($aUserRelationList as $aUserRelation){
						if($aEvent['data_id'] == $aUserRelation['id']){
							if($aUserRelation['user_master_id'] == $aEvent['user_id']){
								$friendId = $aUserRelation['user_slave_id'];
							}else{
								$friendId = $aUserRelation['user_master_id'];
							}
							foreach($aUserList as $aUser){
								if($friendId == $aUser['id']){
									$aUserRelation['friend_info'] = $aUser;
								}
							}
							$aEvent['data'] = $aUserRelation;
						}
					}
				}elseif($aEvent['type'] == $this->_aSnsEvent['pass_mission'] || $aEvent['type'] == $this->_aSnsEvent['finish_task']){
					foreach($aUserMissionList as $aUserMission){
						if($aEvent['data_id'] == $aUserMission['id']){
							$aEvent['data'] = $aUserMission;
						}
					}
				}
				foreach($aUserList as $aUser){
					if($aEvent['user_id'] == $aUser['id']){
						$aEvent['user_info'] = $aUser;
					}
				}
			}
		}
		return $aEventList;
	}
}