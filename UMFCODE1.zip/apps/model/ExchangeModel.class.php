<?php
/**
 * 兑换模型
 */
class ExchangeModel{
	const WAIT_RECEIVE_STATU = 1;	//待收货状态
	const EXCHANGE_EVENT = 32;	//兑换动态
	/*
	 * 添加兑换商品
	 */
	public function addExchangeGoods($aData){
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		return $oExchangeGoods->add($aData);
	}

	/*
	 * 修改兑换商品
	 */
	public function setExchangeGoods($aData){
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		return $oExchangeGoods->update($aData, array('id' => $aData['id']));
	}

	/*
	 * 根据id获取物品信息
	 */
	public function getExchangeGoodsInfoById($id){
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		$aGoodsInfo = $oExchangeGoods->get('', array('id' => $id));
		if($aGoodsInfo){
			$aGoodsInfo = $aGoodsInfo[0];
		}
		return $aGoodsInfo;
	}

	/*
	 * 判断是否兑换过
	 */
	public function checkExchangeRecord($userId, $startTime, $endTime){
		$oExchangeGoods = new Model(T_EXCHANGE_RECORDS);
		$aGoodsList = $oExchangeGoods->get('`id`, `goods_id`, `create_time`', '`user_id`=' . $userId . ' AND `create_time` >=' . $startTime . ' AND `create_time` <= ' . $endTime);
		if($aGoodsList){
			foreach($aGoodsList as $key => $aRecord){
				$aGoodsList[$key]['good_info'] = $this->getExchangeGoodsInfoById($aRecord['goods_id']);
			}
			return $aGoodsList;
		}
		return $aGoodsList;
	}

	/*
	 * 获取物品列表排序的最大值
	 */
	public function getMaxOrdersInExchangeGoods(){
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		$aMaxOrders = $oExchangeGoods->get('max(`orders`) as `orders`', '');
		return $aMaxOrders[0]['orders'];
	}

	/*
	 * 获取物品列表
	 *$aCondition = array(
	 *	'level'		=>
	 *	'release'	=>
	 *  'recommand'	=>	0/1 1:表示查找推荐的
	 * )
	 */
	public function getExchangeGoodsList($aCondition, $page, $pageSize, $order = '`orders` DESC'){
		if(isset($aCondition['recommand']) && $aCondition['recommand']){
			$order = '`recommand_time` DESC';
		}
		$where = $this->_parserWhereForGoodsList($aCondition);
		$offect = ($page - 1) * $pageSize;
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		return $oExchangeGoods->get('', $where, $order, $offect, $pageSize);
	}

	/*
	 * 通过条件得到的物品数量
	 */
	public function getExchangeGoodsCount($aCondition){
		$where = $this->_parserWhereForGoodsList($aCondition);
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		return $oExchangeGoods->count($where);
	}

	/*
	 * 兑换记录
	 */
	public function getExchangRecordsList($userId = 0, $status = 0, $page = 1, $pageSize = 10, $isFromManager = 0, $order = '`id` DESC'){
		$where = $this->_parserWhereForRecordsList($userId, $status);
		$offect = ($page - 1) * $pageSize;
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		$aExchangeRecordsList = $oExchangeRecords->get('', $where, $order, $offect, $pageSize);
		if(!$aExchangeRecordsList){
			return $aExchangeRecordsList;
		}

		return $this->_getExchangeUserAndGoodsByExchangeRecordsList($aExchangeRecordsList, $isFromManager);
	}

	/*
	 * 随机兑换记录
	 */
	public function getRandExchangeRecordsList($length){
		$order = '`id` DESC';
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		$aExchangeRecordsList = $oExchangeRecords->get('', '', $order, 0, 300);
		if(!$aExchangeRecordsList){
			return $aExchangeRecordsList;
		}
		$aRandExchangeRecordsList = array();
		if(count($aExchangeRecordsList) > $length){
			$aKeys = array_rand($aExchangeRecordsList, $length);
			if(is_array($aKeys)){
				foreach($aKeys as $Key){
					$aRandExchangeRecordsList[] = $aExchangeRecordsList[$Key];
				}
			}else{
				$aRandExchangeRecordsList[] = $aExchangeRecordsList[$aKeys];
			}
		}else{
			$aRandExchangeRecordsList = $aExchangeRecordsList;
		}
		if(!$aRandExchangeRecordsList){
			return $aRandExchangeRecordsList;
		}
		return $this->_getExchangeUserAndGoodsByExchangeRecordsList($aRandExchangeRecordsList);
	}

	private function _getExchangeUserAndGoodsByExchangeRecordsList($aExchangeRecordsList, $isFromManager = 0){
		$aUserIds = array();
		$aGoodsIds = array();
		foreach($aExchangeRecordsList as $aExchangeRecords){
			$aUserIds[] = $aExchangeRecords['user_id'];
			$aGoodsIds[] = $aExchangeRecords['goods_id'];
		}
		$aUserList = array();
		if($isFromManager){
			$aUserList = getUserListByUserIds($aUserIds);
			if(!$aUserList){
				return $aUserList;
			}
		}
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		$aGoodsList = $oExchangeGoods->get('`id`,`profile`,`name`,`gold`', array('id' => array('in', $aGoodsIds)));
		if(!$aGoodsList){
			return $aGoodsList;
		}
		foreach($aExchangeRecordsList as &$aExchangeRecords){
			foreach($aGoodsList as $aGoods){
				if($aGoods['id'] == $aExchangeRecords['goods_id']){
					$aExchangeRecords['good_info'] = $aGoods;
					break;
				}
			}
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aExchangeRecords['user_id']){
					$aExchangeRecords['user_info'] = $aUser;
					break;
				}
			}
		}
		return $aExchangeRecordsList;
	}

	/*
	 * 兑换记录数量
	 */
	public function getExchangRecordsCount($userId = 0, $status = 0){
		$where = $this->_parserWhereForRecordsList($userId, $status);
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		return $oExchangeRecords->count($where);
	}

	/*
	 * 兑换商品
	 */
	public function exchangeGoods($userId, $aExchangeGoodsInfo, $address, $mobile, $qq){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//扣除用户金币
		$result = $oDboi->table(T_USER_NUMERICAL)->data(array('gold' => array('sub', $aExchangeGoodsInfo['gold'])))->where(array('id' => $userId))->update();
		if(!$result){
			return $result;
		}
		//写兑换记录
		$aRecordData = array(
			'user_id'	=>	$userId,
			'goods_id'	=>	$aExchangeGoodsInfo['id'],
			'status'	=>	self::WAIT_RECEIVE_STATU,
			'receiver'	=>	$aExchangeGoodsInfo['receiver'],
			'address'	=>	$address,
			'mobile'	=>	$mobile,
			'qq'		=>	$qq,
			'create_time'	=>	time(),
		);
		$recordId = $oDboi->table(T_EXCHANGE_RECORDS)->data($aRecordData)->insert();
		if(!$recordId){
			$oDboi->rollBack();
			return false;
		}
		//给商品加上一次销量和减少库存
		$oDboi->table(T_EXCHANGE_GOODS)->data(array('sales_volume' => array('add', 1), 'stock' => array('sub', 1)))->where(array('id' => $aExchangeGoodsInfo['id']))->update();
		//增加一条兑换动态
		$aEventData = array(
			'user_id'	=>	$userId,
			'type'		=> self::EXCHANGE_EVENT,
			'data_id'	=>	$recordId,
			'data'		=>	array(
				'gold' => $aExchangeGoodsInfo['gold'],
				'exchange_goods_id' => $aExchangeGoodsInfo['id'],
				'create_time' => time()
			)
		);
		//$oDboi->table(T_SNS_EVENT)->data($aEventData)->insert();
		$oSnsEvent = m('SnsEvent');
		$oSnsEvent->addEvent($aEventData);
		
		return $recordId;
	}

	/*
	 * 兑换排行榜
	 */
	public function getExchangeRanking($page = 1, $pageSize = 10){
		$offect = ($page - 1) * $pageSize;
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		$aExchangeRankingList = $oExchangeRecords->get('`user_id`, count(*) as `nums`', '', '`nums` DESC', $offect, $pageSize, '`user_id`');
		if(!$aExchangeRankingList){
			return $aExchangeRankingList;
		}
		$aUserIds = array();
		foreach($aExchangeRankingList as $aExchangeRanking){
			$aUserIds[] = $aExchangeRanking['user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}

		foreach($aExchangeRankingList as &$aExchangeRanking){
			foreach($aUserList as $aUser){
				if($aExchangeRanking['user_id'] == $aUser['id']){
					$aExchangeRanking['user_info'] = $aUser;
					break;
				}
			}
		}
		return $aExchangeRankingList;
	}

	/*
	 * 更新兑换记录
	 */
	public function setExchangRecords($aData){
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		return $oExchangeRecords->update($aData, array('id' => $aData['id']));
	}

	/*
	 * 得到兑换记录信息
	 */
	public function getExchangRecordsInfoById($recordId){
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		$aExchangRecordsInfo = $oExchangeRecords->get('', array('id' => $recordId));
		if($aExchangRecordsInfo){
			$aExchangRecordsInfo = $aExchangRecordsInfo[0];
		}
		return $aExchangRecordsInfo;
	}

	/*
	 * 根据商品id，得到兑换过的好友
	 */
	public function getUserListByGoodsId($goodsId, $aUserIds, $page, $pageSize){
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		if($aUserIds){
			$where = '`goods_id`=' . $goodsId . ' AND `user_id` in (' . implode(',', $aUserIds) . ')';
		}else{
			$where = '`goods_id`=' . $goodsId;
		}
		$offect = ($page - 1) * $pageSize;
		$aExchangRecordList = $oExchangeRecords->get('`user_id`,max(`create_time`) as `create_time`', $where, '`create_time` DESC', $offect, $pageSize, '`user_id`');
		if(!$aExchangRecordList){
			return $aExchangRecordList;
		}
		$aUserIds = array();
		foreach($aExchangRecordList as $aExchangRecord){
			$aUserIds[] = $aExchangRecord['user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		$aReturnData = array();
		foreach($aExchangRecordList as $aExchangRecord){
			foreach($aUserList as $aUser){
				if($aExchangRecord['user_id'] == $aUser['id']){
					$aUser['exchange_time'] = $aExchangRecord['create_time'];
					$aReturnData[] = $aUser;
					break;
				}
			}
		}
		return $aReturnData;
	}

	private function _parserWhereForRecordsList($userId, $status){
		$where = '';
		if($userId){
			$where = '`user_id`=' . $userId;
		}
		if($status){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`status`=' . $status;
		}
		return $where;
	}

	private function _parserWhereForGoodsList($aCondition){
		$where = '';
		if(isset($aCondition['level']) && $aCondition['level']){
			$where .= '`level`=' . $aCondition['level'];
		}
		if(isset($aCondition['release']) && $aCondition['release']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`release`=' . $aCondition['release'];
		}
		if(isset($aCondition['recommand']) && $aCondition['recommand']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`recommand_time`>0';
		}
		return $where;
	}

}