<?php
/**
 * 后台用户模型
 */
class VipModel{
	public function getVipPrivitegeInfo($userId){
		$oVipPrivilege = new Model(T_VIP_PRIVILEGE);
		$aVipPrivilegeInfo = $oVipPrivilege->get('', array('id' => $userId));
		if($aVipPrivilegeInfo === false){
			return false;
		}elseif($aVipPrivilegeInfo){
			return $aVipPrivilegeInfo[0];
		}else{
			$aData = array(
				'id'	=>	$userId,
				'gifts_receive_time'	=>	0,
				'repair_es_count'	=>	0,
				'last_repair_time'	=>	0,
			);
			$row = $oVipPrivilege->add($aData);
			if(!$row){
				return false;
			}
			return $aData;
		}
	}

	public function setVipPrivitege($aData){
		$oVipPrivilege = new Model(T_VIP_PRIVILEGE);
		return $oVipPrivilege->update($aData, array('id' => $aData['id']));
	}

	//修复错题
	public function repairWrongEs($aUserEsWrongInfo, $aVipPrivilegeInfo, $isStudent = 1){
		$oDboi = new DBOI();
		$oDboi->startTrans();

		//删除错题集中该题目
		$result = $oDboi->table(T_USER_ES_WRONG)->where(array('id' => $aUserEsWrongInfo['id']))->delete();
		if(!$result){
			return false;
		}
		//给关卡的正确题数和修复数量加1
		$where = '`user_id`=' . $aUserEsWrongInfo['user_id'] . ' AND `mission_id`=' . $aUserEsWrongInfo['mission_id'];
		$aUpdateData = array(
			'es_correct_count'	=>	array('add', 1),
			'es_repair_count'	=>	array('add', 1),
		);
		$result = $oDboi->table(T_MISSION_USER_RELATION_INDEX)->where($where)->data($aUpdateData)->update();
		if(!$result){
			$oDboi->rollBack();
			return $result;
		}
		//更新vip_privilege表
		if($isStudent){
			if(date('Ymd') == date('Ymd', $aVipPrivilegeInfo['last_repair_time'])){
				$aUpdateData = array(
					'repair_es_count'	=>	array('add', 1),
					'last_repair_time'	=> time(),
				);
			}else{
				$aUpdateData = array(
					'repair_es_count'	=>	1,
					'last_repair_time'	=> time(),
				);
			}
			$result = $oDboi->table(T_VIP_PRIVILEGE)->where(array('id' => $aVipPrivilegeInfo['id']))->data($aUpdateData)->update();
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}

		//给月统计的月修复数加1
		$month = date('Ym', $aUserEsWrongInfo['create_time']);
		$oUserStatisticsIndex = new Model(T_USER_MONTH_STATISTICS_INDEX);
		$aUserMonthStatisticsIndex = $oUserStatisticsIndex->get('', '`month`=' . $month . ' AND `user_id`=' . $aUserEsWrongInfo['user_id']);
		if($aUserMonthStatisticsIndex === false){
			$oDboi->rollBack();
			return false;
		}elseif(!$aUserMonthStatisticsIndex){
			$aUserStatisticsInit = array(
				'es' => array(
					'es_repair_count' => 1,
					'mission' => array(
						1 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
						2 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
						3 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
					),
					'pk' => array(
						1 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
						2 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
						3 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
					),
					'match' => array(
						1 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
						2 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
						3 => array(
							'es_total' => 0,
							'es_wrong' => 0,
						),
					),
				),
				'mission' => array(),
				'match' => array(),
			);
			$aUserInfo = getUserInfo($aUserEsWrongInfo['user_id'], array('class', 'area'));
			if(!$aUserInfo){
				$oDboi->rollBack();
				return false;
			}
			$aUserMonthStatisticsIndexData = array(
				'user_id'	=>	$aUserEsWrongInfo['user_id'],
				'month'		=>	$month,
				'city_id'	=>	$aUserInfo['city_id'],
				'school_id'	=>	$aUserInfo['school_id'],
				'grade'		=>	$aUserInfo['grade'],
				'class'		=>	$aUserInfo['class'],
				'score'		=>	0,
			);
			$statisticsId = $oDboi->table(T_USER_MONTH_STATISTICS_INDEX)->data($aUserMonthStatisticsIndexData)->insert();
			if(!$statisticsId){
				$oDboi->rollBack();
				return false;
			}
			$aUserMonthStatisticsData = array(
				'id'	=>	$statisticsId,
				'statistics'	=> json_encode($aUserStatisticsInit),
			);
			$result = $oDboi->table(T_USER_MONTH_STATISTICS)->data($aUserMonthStatisticsData)->insert();
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}else{
			$aUserMonthStatisticsIndex = $aUserMonthStatisticsIndex[0];
			$oUserStatistics = new Model(T_USER_MONTH_STATISTICS);
			$aUserMonthStatistics = $oUserStatistics->get('', array('id' => $aUserMonthStatisticsIndex['id']));
			if(!$aUserMonthStatistics){
				$oDboi->rollBack();
				return false;
			}
			$aUserMonthStatistics = $aUserMonthStatistics[0];
			$aStatistics = json_decode($aUserMonthStatistics['statistics'], true);
			$aStatistics['es']['es_repair_count'] += 1;
			$aUserMonthStatistics['statistics'] = json_encode($aStatistics);
			$result = $oDboi->table(T_USER_MONTH_STATISTICS)->where(array('id' => $aUserMonthStatistics['id']))->data($aUserMonthStatistics)->update();
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}
		return true;
	}
}