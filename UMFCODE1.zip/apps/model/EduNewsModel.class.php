<?php
/*
 * 教育资讯
 */
class EduNewsModel{
	public function addNewsCategory($aData){
		$oCategory = new Model(T_EDU_NEWS_CATEGORY);
		return $oCategory->add($aData);
	}

	public function getCategoryList(){
		$oCategory = new Model(T_EDU_NEWS_CATEGORY);
		return $oCategory->get('', '');
	}

	public function addNewsContent($aData){
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		return $oContent->add($aData);
	}


	public function setNewsContent($aData){
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		return $oContent->update($aData, array('id' => $aData['id']));
	}

	public function deleteNewsContentById($id){
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		return $oContent->delete(array('id' => $id));
	}

	public function getNewsContentListByCategoryId($categoryId = 0, $page = 1, $pageSize = 0){
		$where = $this->_parseWhereForContentList($categoryId);
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		$offect = ($page - 1) * $pageSize;
		$aContentList = $oContent->get('', $where, '`create_time` desc', $offect, $pageSize);
		if(!$aContentList){
			return $aContentList;
		}
		$aCategoryIds = array();
		foreach($aContentList as $aContent){
			$aCategoryIds[] = $aContent['category_id'];
		}
		$aCategoryIds = array_unique($aCategoryIds);
		$oCategory = new Model(T_EDU_NEWS_CATEGORY);
		$aCategoryList = $oCategory->get('', array('id' => array('in', $aCategoryIds)));
		if($aCategoryList === false){
			return false;
		}
		foreach($aContentList as $key => $aContent){
			$aContentList[$key]['category_name'] = '';
			foreach($aCategoryList as $aCategory){
				if($aCategory['id'] == $aContent['category_id']){
					$aContentList[$key]['category_name'] = $aCategory['name'];
					break;
				}
			}
		}
		return $aContentList;
	}

	public function getNewsContentCountByCategoryId($categoryId = 0){
		$where = $this->_parseWhereForContentList($categoryId);
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		return $oContent->count($where);
	}

	private function _parseWhereForContentList($categoryId){
		$where = '';
		if($categoryId){
			$where = '`category_id`=' . $categoryId;
		}
		return $where;
	}

	public function getNewsContentList($length = 6){
		$oCategory = new Model(T_EDU_NEWS_CATEGORY);
		$aCategoryList = $oCategory->get('', '');
		if(!$aCategoryList){
			return $aCategoryList;
		}
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		$aContentList = $oContent->get('`id`,`category_id`,`title`,`create_time`', '');
		if($aContentList === false){
			return false;
		}
		$aCategoryListRefer = array();
		foreach($aCategoryList as $aCategory){
			$aCategory['content_list'] = array();
			$aCategoryListRefer[$aCategory['id']] = $aCategory;
		}
		foreach($aContentList as $aContent){
			if(isset($aCategoryListRefer[$aContent['category_id']]) && count($aCategoryListRefer[$aContent['category_id']]['content_list']) < $length){
				$aCategoryListRefer[$aContent['category_id']]['content_list'][] = $aContent;
			}
		}
		return $aCategoryListRefer;
	}

	public function getNewsContentInfo($id){
		$oContent = new Model(T_EDU_NEWS_CONTENT);
		$aContentInfo = $oContent->get('', array('id' => $id));
		if($aContentInfo){
			$aContentInfo = $aContentInfo[0];
		}
		return $aContentInfo;
	}

}