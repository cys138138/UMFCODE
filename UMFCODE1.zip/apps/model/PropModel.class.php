<?php
/**
 * 道具模型
 */
class PropModel{
	const BUY_TYPE = 1;							//购买道具操作
	const UNRECEIVE_AWARD_TYPE = 2;				//获得道具奖励但未领取
	const RECEIVE_AWARD_TYPE = 21;				//领取奖励的道具
	const UNRECEIVE_STATU = 1;					//我收到的未领取的状态
	const RECEIVED_STATU = 2;					//我收到的已领取的状态
	const RECEIVED_AWARD_STATU = 21;			//已领取奖励的道具状态
	const RECEIVE_PROP_PERSONAL_MESSAGE = 33;	//收到赠送的道具的个人通知

	//添加道具
	public function addProp($aData){
		$oProp = new Model(T_PROP);
		return $oProp->add($aData);
	}

	//删除道具
	public function deletePropById($id){
		$oProp = new Model(T_PROP);
		return $oProp->delete(array('id' => $id));
	}

	//查找道具信息
	public function getPropInfoById($id){
		$oProp = new Model(T_PROP);
		$aPropInfo = $oProp->get('', array('id' => $id));
		if($aPropInfo){
			$aPropInfo = $aPropInfo[0];
		}
		return $aPropInfo;
	}

	//根据道具id集得到道具列表
	public function getPropListByPropIds($aPropIds){
		$oProp = new Model(T_PROP);
		$aPropList = $oProp->get('', array('id' => array('in', $aPropIds)));
		return $aPropList;
	}

	//查找道具列表
	/*
	 * $aConditon = array(
	 *	'type' => array(
	 *		1-闯关道具，2-通用答题道具，3-PK道具，4-比赛道具，5-积分道具，6-扩容道具，7-装扮类道具，8-道具包,-1-打折
	 *  ) 数组为空-所有
	 *	‘money_type’	=>	0-所有，1-金币，2-UB
	 *	‘is_publish’	=>	-1-所有，0-未上架，1-已上架
	 * )
	 */
	public function getPropList($aCondition, $page, $pageSize, $order = '`create_time` DESC'){
		$where = $this->_parseWhereForPropList($aCondition);
		$offect = ($page - 1) * $pageSize;
		$oProp = new Model(T_PROP);
		$aPropList = $oProp->get('', $where, $order, $offect, $pageSize);
		return $aPropList;
	}

	/*
	 * 道具数量统计
	 */
	public function getPropCount($aCondition){
		$where = $this->_parseWhereForPropList($aCondition);
		$oProp = new Model(T_PROP);
		return $oProp->count($where);
	}

	/*
	 * 修改道具
	 */
	public function setProp($aData){
		$oProp = new Model(T_PROP);
		return $oProp->update($aData, array('id' => $aData['id']));
	}

	private function _parseWhereForPropList($aCondition){
		$where = '';
		if(isset($aCondition['type']) && $aCondition['type']){
			if($aCondition['type'][0] == -1){	//如果是打折的话
				$currentTime = time();
				$where .= '`discount_start_time`<=' . $currentTime . ' AND `discount_end_time`>=' . $currentTime;
			}else{
				$where .= '`type` in (' . implode(',', $aCondition['type']) . ')';
			}
		}
		if(isset($aCondition['money_type']) && $aCondition['money_type']){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`money_type`=' . $aCondition['money_type'];
		}
		if(isset($aCondition['is_publish']) && $aCondition['is_publish'] != -1){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`is_publish`=' . $aCondition['is_publish'];
		}
		return $where;
	}

	public function getUserPropInfo($userId){
		$oPropUserRelation = new Model(T_PROP_USER_RELATION);
		$aUserPropInfo = $oPropUserRelation->get('', array('is_publish' => 1, 'id' => $userId));
		if($aUserPropInfo){
			$aUserPropInfo = $aUserPropInfo[0];
			if($aUserPropInfo['props']){
				$aUserPropInfo['props'] = explode(',', $aUserPropInfo['props']);
			}else{
				$aUserPropInfo['props'] = array();
			}
			if($aUserPropInfo['shopping_cart']){
				$aUserPropInfo['shopping_cart'] = explode(',', $aUserPropInfo['shopping_cart']);
			}else{
				$aUserPropInfo['shopping_cart'] = array();
			}
		}
		return $aUserPropInfo;
	}

	public function addUserProp($aData){
		$oPropUserRelation = new Model(T_PROP_USER_RELATION);
		if(isset($aData['props'])){
			unset($aData['props']);
		}
		if(isset($aData['shopping_cart'])){
			$aData['shopping_cart'] = implode(',', $aData['shopping_cart']);
		}
		return $oPropUserRelation->add($aData);
	}

	public function setUserProp($aData){
		$oPropUserRelation = new Model(T_PROP_USER_RELATION);
		$aData = $this->_beforeUpdatePropUserRelation($aData);
		return $oPropUserRelation->update($aData, array('id' => $aData['id']));
	}

	/*
	 * 得到道具
	 * $aUserPropInfo	如果用户没有记录的话=userId
	 * $aProps = array(
	 *	0	=>	array(
	 *		'id'			=>	道具id
	 *		'number'		=>	数量
	 *		'from'		=>	来源
	 *		'from_comment'		=>	总额
	 *		'money_type'			=>	金钱类型
	 *	),
	 *	1	=>	array(
	 *		'id'			=>	道具id
	 *		'number'		=>	数量
	 *		'from'		=>	来源
	 *		'from_comment'		=>	总额
	 *		'money_type'			=>	金钱类型
	 *	),
	 *	$purchaseRecordId	当领取奖励的道具的时候有用,其余不用填
	 * )
	 */
	public function buyProps($aUserPropInfo, $aProps, $purchaseRecordId = 0){
		$updateUserProp = 0;	//是否需要更新用户道具表
		$firstBuy = 0;	//用户道具表是否有数据
		if(!is_array($aUserPropInfo)){
			$aUserPropInfo['id'] = $aUserPropInfo;
			$aUserPropInfo['props'] = array();
			$firstBuy = 1;
		}
		//是否首次购买道具
		$buyPropCount = (new \umeworld\lib\Query())->from(\common\model\PropPurchaseRecords::tableName())->where(['user_id' => $aUserPropInfo['id'], 'from' => \common\model\PropPurchaseRecords::FROM_BUY])->count();
		if(!$buyPropCount){
			$this->_afterFirstByProp($aUserPropInfo['id']);
		}
		$amount = 0;	//应扣金币
		$aPropPurchaseRecords = array();	//日志数据
		$currentTime = time();
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aUpdatePropData = array();
		$aAddEventList = array();	//新版购买道具写事件列表
		foreach($aProps as $aProp){
			//如果是购买，或获得奖励
			if($aProp['from'] == self::BUY_TYPE || $aProp['from'] == self::UNRECEIVE_AWARD_TYPE){
				//是购买的话
				if($aProp['from'] == self::BUY_TYPE){
					$amount += $aProp['from_comment'];
					//给用户加到道具包中
					for($i = 1; $i <= $aProp['number']; $i++){
						$aUserPropInfo['props'][] = $aProp['id'];
					}
					$aUpdatePropData[] = array('id' => $aProp['id'], 'purchase_total' => array('add', $aProp['number']));
					$updateUserProp = 1;
					//新版购买道具写事件
					$aTemp = array(
						'user_id' => $aUserPropInfo['id'],
						'prop_id' => $aProp['id'],
						'gold' => $aProp['from_comment'],
					);
					array_push($aAddEventList, $aTemp);
				}
				//要写的日志数据
				$aLog = array(
					'user_id'	=>	$aUserPropInfo['id'],
					'prop_id'	=>	$aProp['id'],
					'number'	=>	$aProp['number'],
					'from'		=>	$aProp['from'],
					'from_comment'		=>	$aProp['from_comment'],
					'money_type'		=>	$aProp['money_type'],
					'create_time'		=>	$currentTime,
				);
				$aPropPurchaseRecords[] = $aLog;
			}else{	//如果是领取奖励
				//给用户加到道具包中
				for($i = 1; $i <= $aProp['number']; $i++){
					$aUserPropInfo['props'][] = $aProp['id'];
				}
				$updateUserProp = 1;
				//更新日志的状态
				$result = $oDboi->table(T_PROP_PURCHASE_RECORDS)->data(array('from' => self::RECEIVE_AWARD_TYPE))->where(array('id' => $purchaseRecordId))->update();
				if(!$result){
					return $result;
				}
			}
		}
		if($updateUserProp){
			//更新用户道具表
			$aUserPropInfo = $this->_beforeUpdatePropUserRelation($aUserPropInfo);
			//如果没有记录就增加，如果有记录就更新
			if($firstBuy){
				$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->insert();
			}else{
				$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->where(array('id' => $aUserPropInfo['id']))->update();
			}
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}

		if($aPropPurchaseRecords){
			//写获区日志
			$result = $oDboi->table(T_PROP_PURCHASE_RECORDS)->data($aPropPurchaseRecords)->insert();
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}

		//扣金币
		if($amount){
			$result = $oDboi->table(T_USER_NUMERICAL)->where(array('id' => $aUserPropInfo['id']))->data(array('gold' => array('sub', $amount)))->update();
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}

		//给道具表增加购买次数
		if($aUpdatePropData){
			foreach($aUpdatePropData as $aPropData){
				$oDboi->table(T_PROP)->data($aPropData)->where(array('id' => $aPropData['id']))->update();
			}
		}

		if($aAddEventList){
			$this->_addBuyPropEvent($aAddEventList);
		}

		return $result;
	}

	/*
	 * 使用道具-包括丢弃
	 */
	public function useProp($aUserPropInfo, $propId, $type = 1){
		foreach($aUserPropInfo['props'] as $key => $pId){
			if($propId == $pId){
				unset($aUserPropInfo['props'][$key]);
				break;
			}
		}
		$aUserPropInfo = $this->_beforeUpdatePropUserRelation($aUserPropInfo);
		$oPropUserRelation = new Model(T_PROP_USER_RELATION);
		$result = $oPropUserRelation->update($aUserPropInfo, array('id' => $aUserPropInfo['id']));
		if(!$result){
			return $result;
		}

		$aUseRecord = array(
			'user_id'	=>	$aUserPropInfo['id'],
			'prop_id'	=>	$propId,
			'type'		=>	$type,
			'create_time'	=> time(),
		);
		$oPropUseRecords = new Model(T_PROP_USE_RECORDS);
		$oPropUseRecords->add($aUseRecord);
		if($type == 1){
			$oProp = new Model(T_PROP);
			$oProp->update(array('use_total' => array('add', 1)), array('id' => $propId));
		}
		return $result;
	}

	/*
	 * 赠送道具
	 */
	public function sendProp($aUserPropInfo, $toUserId, $propId, $nums, $message = ''){
		$i = 0;
		foreach($aUserPropInfo['props'] as $key => $pId){
			if($propId == $pId){
				unset($aUserPropInfo['props'][$key]);
				$i++;
				if($i >= $nums){
					break;
				}
			}
		}
		$aUserPropInfo = $this->_beforeUpdatePropUserRelation($aUserPropInfo);
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->where(array('id' => $aUserPropInfo['id']))->update();
		if(!$result){
			return $result;
		}

		$aSendRecord = array(
			'user_id'	=>	$aUserPropInfo['id'],
			'prop_id'	=>	$propId,
			'number'		=>	$nums,
			'to_user_id'	=>	$toUserId,
			'status'			=>	1,
			'message'		=>	$message,
			'create_time'	=> time(),
		);
		$recordId = $oDboi->table(T_PROP_SEND_RECORDS)->data($aSendRecord)->insert();
		if(!$recordId){
			$oDboi->rollBack();
			return false;
		}

		//给收到的人写通知
		$aPersonalMessage = array(
			'user_id'	=>	$toUserId,
			'type'		=> self::RECEIVE_PROP_PERSONAL_MESSAGE,
			'data_id'	=>	$recordId,
		);
		$personalMessageId = $oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessage)->insert();
		if(!$personalMessageId){
			$oDboi->rollBack();
			return false;
		}

		//给收到的人标志红点
		$aPersonalNewFlag = array(
			'new_feed_flag'=>array('add', 1),
		);

		$personalId = $oDboi->table(T_PERSONAL)->where(array('id'=>$toUserId))->data($aPersonalNewFlag)->update();
		if(!$personalId){
			$oDboi->rollBack();
			return false;
		}

		return $result;
	}

	/*
	 * 查看用户赠送的道具列表
	 */
	public function getPropSendRecordList($userId = 0, $toUserId = 0, $statu = 0, $page = 1, $pageSize = 10){
		$where = $this->_parseWhereForPropSendRecord($userId, $toUserId, $statu);
		$offect = ($page - 1) * $pageSize;
		$oPropSendRecords = new Model(T_PROP_SEND_RECORDS);
		$aPropSendRecordList = $oPropSendRecords->get('', $where, '`id` DESC', $offect, $pageSize);
		if(!$aPropSendRecordList){
			return $aPropSendRecordList;
		}
		$aUserIds = array();
		$aPropIds = array();
		foreach($aPropSendRecordList as $aPropSendRecord){
			$aUserIds[] = $aPropSendRecord['user_id'];
			$aUserIds[] = $aPropSendRecord['to_user_id'];
			$aPropIds[] = $aPropSendRecord['prop_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		$aPropList = $this->getPropListByPropIds($aPropIds);
		foreach($aPropSendRecordList as &$aPropSendRecord){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPropSendRecord['user_id']){
					$aPropSendRecord['user_info'] = $aUser;
				}elseif($aUser['id'] == $aPropSendRecord['to_user_id']){
					$aPropSendRecord['to_user_info'] = $aUser;
				}
			}
			foreach($aPropList as $aProp){
				if($aProp['id'] == $aPropSendRecord['prop_id']){
					$aPropSendRecord['prop_info'] = $aProp;
					break;
				}
			}
		}
		return $aPropSendRecordList;
	}

	public function getPropSendRecordCount($userId = 0, $toUserId = 0, $statu = 0, $page = 1, $pageSize = 10){
		$where = $this->_parseWhereForPropSendRecord($userId, $toUserId, $statu);
		$oPropSendRecords = new Model(T_PROP_SEND_RECORDS);
		return $oPropSendRecords->count($where);
	}

	/*
	 * 查询赠送的道具信息
	 */
	public function getPropSendRecordInfoById($sendRecordId){
		$oPropSendRecords = new Model(T_PROP_SEND_RECORDS);
		$aPropSendRecordInfo = $oPropSendRecords->get('', array('id' => $sendRecordId));
		if($aPropSendRecordInfo){
			$aPropSendRecordInfo = $aPropSendRecordInfo[0];
		}
		return $aPropSendRecordInfo;
	}

	/*
	 * 领取别人赠送的道具
	 * $aUserPropInfo	领取人的道具信息，如果用户没有记录的话=userId
	 */
	public function receiveSendProp($aPropSendRecordInfo, $aUserPropInfo){
		$firstBuy = 0;	//用户道具表是否有数据
		if(!is_array($aUserPropInfo)){
			$aUserPropInfo['id'] = $aUserPropInfo;
			$aUserPropInfo['props'] = array();
			$firstBuy = 1;
		}
		for($i = 1; $i <= $aPropSendRecordInfo['number']; $i++){
			$aUserPropInfo['props'][] = $aPropSendRecordInfo['prop_id'];
		}

		$oDboi = new DBOI();
		$oDboi->startTrans();
		//更新用户道具表
		$aUserPropInfo = $this->_beforeUpdatePropUserRelation($aUserPropInfo);
		//如果没有记录就增加，如果有记录就更新
		if($firstBuy){
			$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->insert();
		}else{
			$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->where(array('id' => $aUserPropInfo['id']))->update();
		}
		if(!$result){
			return $result;
		}

		//更新道具赠送记录表
		$result = $oDboi->table(T_PROP_SEND_RECORDS)->where(array('id' => $aPropSendRecordInfo['id']))->data(array('status' => self::RECEIVED_STATU))->update();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		return $result;
	}

	public function getHavePropPurchaseRecordUserList($propId, $aUserIds, $page, $pageSize){
		$oPropPurchaseRecords = new Model(T_PROP_PURCHASE_RECORDS);
		$offect = ($page - 1) * $pageSize;
		if(!$aUserIds){
			return $aUserIds;
		}
		$aPropPurchaseRecordList = $oPropPurchaseRecords->get('DISTINCT `user_id`', '`prop_id`=' . $propId . ' AND `user_id` in (' . implode(',', $aUserIds) . ')', '', $offect, $pageSize);
		if(!$aPropPurchaseRecordList){
			return $aPropPurchaseRecordList;
		}
		$aUserIds = array();
		foreach($aPropPurchaseRecordList as $aPropPurchaseRecord){
			$aUserIds[] = $aPropPurchaseRecord['user_id'];
		}
		return getUserListByUserIds($aUserIds);
	}

	/*
	 * 修改赠送记录状态
	 */
	public function setPropSendRecord($aData){
		if(isset($aData['status'])){
			$aUpdate['status'] = $aData['status'];
		}else{
			return false;
		}
		$oPropSendRecord = new Model(T_PROP_SEND_RECORDS);
		return $oPropSendRecord->update($aUpdate, array('id' => $aData['id']));
	}

	/*
	 * 修改奖励记录状态
	 */
	public function setPropPurchaseRecord($aData){
		if(isset($aData['from'])){
			$aUpdate['from'] = $aData['from'];
		}else{
			return false;
		}
		$oPropPurchaseRecord = new Model(T_PROP_PURCHASE_RECORDS);
		return $oPropPurchaseRecord->update($aUpdate, array('id' => $aData['id']));
	}

	/*
	 * 获得奖励信息
	 */
	public function getPropPurchaseRecordInfo($propPurchaseId){
		$oPropPurchaseRecord = new Model(T_PROP_PURCHASE_RECORDS);
		$aPropPurchaseInfo = $oPropPurchaseRecord->get('', array('id' => $propPurchaseId));
		if($aPropPurchaseInfo){
			$aPropPurchaseInfo = $aPropPurchaseInfo[0];
		}
		return $aPropPurchaseInfo;
	}


	/*
	 * 得到用户的购买/奖励记录
	 * $userId	0：全部人的，其他：指定人的
	 * $aFrom	= array(对应表的from字段)
	 */
	public function getPropPurchaseList($userId, $aFrom, $page, $pageSize){
		$where = $this->_parseWhereForPropPurchase($userId, $aFrom);
		$offect = ($page - 1) * $pageSize;
		$oPropPurchaseRecords = new Model(T_PROP_PURCHASE_RECORDS);
		$aPropPurchaseList = $oPropPurchaseRecords->get('', $where, '`id` DESC', $offect, $pageSize);
		if(!$aPropPurchaseList){
			return $aPropPurchaseList;
		}
		$aPropIds = array();
		foreach($aPropPurchaseList as $aPropPurchase){
			$aPropIds[] = $aPropPurchase['prop_id'];
		}
		$oProp = new Model(T_PROP);
		$aPropList = $oProp->get('`id`,`name`,`ico`,`description`,`type`', array('id' => array('in', $aPropIds)));
		if(!$aPropList){
			return $aPropList;
		}
		foreach($aPropPurchaseList as &$aPropPurchase){
			foreach($aPropList as $aProp){
				if($aProp['id'] == $aPropPurchase['prop_id']){
					$aPropPurchase['prop_info'] = $aProp;
					break;
				}
			}
		}
		return $aPropPurchaseList;
	}

	public function getPropPurchaseCount($userId, $aFrom){
		$where = $this->_parseWhereForPropPurchase($userId, $aFrom);
		$oPropPurchaseRecords = new Model(T_PROP_PURCHASE_RECORDS);
		return $oPropPurchaseRecords->count($where);
	}

	/*
	 * 领取系统奖励的道具
	 * $aUserPropInfo	领取人的道具信息，如果用户没有记录的话=userId
	 */
	public function receiveAwordProp($aPropPurchaseInfo, $aUserPropInfo){
		$firstBuy = 0;	//用户道具表是否有数据
		if(!is_array($aUserPropInfo)){
			$aUserPropInfo['id'] = $aUserPropInfo;
			$aUserPropInfo['props'] = array();
			$firstBuy = 1;
		}
		for($i = 1; $i <= $aPropPurchaseInfo['number']; $i++){
			$aUserPropInfo['props'][] = $aPropPurchaseInfo['prop_id'];
		}

		$oDboi = new DBOI();
		$oDboi->startTrans();
		//更新用户道具表
		$aUserPropInfo = $this->_beforeUpdatePropUserRelation($aUserPropInfo);
		//如果没有记录就增加，如果有记录就更新
		if($firstBuy){
			$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->insert();
		}else{
			$result = $oDboi->table(T_PROP_USER_RELATION)->data($aUserPropInfo)->where(array('id' => $aUserPropInfo['id']))->update();
		}
		if(!$result){
			return $result;
		}

		//更新道购买记录表
		$result = $oDboi->table(T_PROP_PURCHASE_RECORDS)->where(array('id' => $aPropPurchaseInfo['id']))->data(array('status' => self::RECEIVED_AWARD_STATU))->update();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		return $result;
	}

	//随机取得一个道具
	public function getRandomPropInfo(){
		$oProp = new Model(T_PROP);
		$aPropList = $oProp->get('', '`is_publish`=1');
		if(!$aPropList){
			return $aPropList;
		}
		$key = array_rand($aPropList, 1);
		return $aPropList[$key];
	}

	private function _parseWhereForPropPurchase($userId, $aFrom){
		$where = '';
		if($userId){
			$where .= '`user_id`=' . $userId;
		}
		if($aFrom){
			if($where){
				$where .= ' AND ';
			}
			if(count($aFrom) == 1){
				$where .= '`from`=' . $aFrom[0];
			}else{
				$where .= '`from` in (' . implode(',', $aFrom) . ')';
			}
		}
		return $where;
	}

	private function _parseWhereForPropSendRecord($userId, $toUserId, $statu){
		$where = '';
		if($userId){
			$where .= '`user_id`=' . $userId;
		}
		if($toUserId){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`to_user_id`=' . $toUserId;
		}
		if($statu){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`status`=' . $statu;
		}
		return $where;
	}

	private function _beforeUpdatePropUserRelation($aUserPropInfo){
		if(isset($aUserPropInfo['props'])){
			$aUserPropInfo['props'] = implode(',', $aUserPropInfo['props']);
		}
		if(isset($aUserPropInfo['shopping_cart'])){
			$aUserPropInfo['shopping_cart'] = implode(',', $aUserPropInfo['shopping_cart']);
		}
		return $aUserPropInfo;
	}

	/**
	 * 添加新版购买道具事件
	 */
	private function _addBuyPropEvent($aAddEventList = array()){
		$oSnsEvent = m('SnsEvent');
		foreach($aAddEventList as $aAddEvent){
			$aData = array(
				'user_id' => $aAddEvent['user_id'],
				'type' => 31,
				'data_id' => 0,
				'data' => array(
					'gold' => $aAddEvent['gold'],
					'prop_id' => $aAddEvent['prop_id'],
					'create_time' => time()
				)
			);

			$oSnsEvent->addEvent($aData);
		}
	}

	private function _afterFirstByProp($userId){
		$mStudent = common\model\Student::findOne($userId);
		$addMoney = common\model\UserProp::FIRST_BUY_PROP_ADD_GOLD;
		$mStudent->addCurrency($addMoney, \common\model\UserNumerical::CURRENCY_SCENE_FIRST_BUY_PROP);
		//写动态
		$aData = [
			'type' => \common\model\Event::FIRST_BUY_PROP,
			'user_id' => $mStudent->id,
			'data_id' => 0,
			'data' => [
				'get_gold' => $addMoney,
				'create_time' => NOW_TIME,
			]
		];
		\common\model\Event::add($aData);
	}
}


