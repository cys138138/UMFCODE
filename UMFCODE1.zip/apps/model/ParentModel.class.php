<?php
/*
*家长模型
*/

class ParentModel{
	public static function xCrypt($password){
		return md5($password);
	}

	//根据用户手机号查找家长信息
	public function getParentInfoByMobile($mobile = ''){
		if(!$mobile){
			return $mobile;
		}

		$oParent = new Model(T_PARENT);
		$aParentInfo = $oParent->get('','mobile = ' . $mobile);
		if(!$aParentInfo){
			return $aParentInfo;
		}
		$aParentInfo[0]['user_ids'] = explode(',', $aParentInfo[0]['user_ids']);
		return $aParentInfo[0];
	}

	public function getParentInfoById($id){
		if(!$id){
			return $id;
		}

		$oParent = new Model(T_PARENT);
		$aParentInfo = $oParent->get('','id = ' . $id);
		if(!$aParentInfo){
			return $aParentInfo;
		}
		$aParentInfo = $this->_convertDataForParentList($aParentInfo);
		if($aParentInfo[0]['user_ids']){
			$aParentInfo[0]['user_ids'] = explode(',', $aParentInfo[0]['user_ids']);
		}else{
			$aParentInfo[0]['user_ids'] = array();
		}
		return $aParentInfo[0];
	}

	//根据用户id查找家长信息
	public function getParentInfoByUserId($userId = ''){
		if(!$userId){
			return $userId;
		}

		$oParent = new Model(T_PARENT);
		$aParentInfo = $oParent->get('', 'find_in_set('. $userId .', user_ids)');
		if(!$aParentInfo){
			return $aParentInfo;
		}
		$aParentInfo = $this->_convertDataForParentList($aParentInfo);
		$aParentInfo[0]['user_ids'] = explode(',', $aParentInfo[0]['user_ids']);
		return $aParentInfo[0];
	}

	//验证用户是否存在
	public function getParentInfoByExtendCode($extendCode, $extendType){
		$where = "`extend_type`=" . $extendType . " AND `extend_code`='" . $extendCode . "'";
		$oParent = new Model(T_PARENT);
		$aParentInfo = $oParent->get('', $where);
		if($aParentInfo){
			$aParentInfo = $this->_convertDataForParentList($aParentInfo);
			$aParentInfo = $aParentInfo[0];
		}
		return $aParentInfo;
	}

	//增加
	public function addParentInfo($aData){
		$aData['password'] = $this->xCrypt($aData['password']);
		if(isset($aData['xxt_data'])){
			$aData['xxt_data'] = json_encode($aData['xxt_data']);
		}
		$oParent = new Model(T_PARENT);
		return $oParent->add($aData);
	}

	//修改
	public function setParentInfo($aData, $where){
		if(isset($aData['xxt_data'])){
			$aData['xxt_data'] = json_encode($aData['xxt_data']);
		}
		$oParent = new Model(T_PARENT);
		return $oParent->update($aData, $where);
	}

	/*
	 *$aCondition = array(
	 *		'city_id'	=> 'cs'  城市拼音缩写
	 *		'uf_id'		=>
	 *		'name'		=>	'逗比启军'
	 * )
	 *
	 */
	public function getXxtParentList($page, $pageSize, $aCondition = array()){
		$where = $this->_parseWhereForXxtParentList($aCondition);
		$offect = ($page - 1) * $pageSize;
		$oParent = new Model(T_PARENT);
		$aParentList = $oParent->get('', $where, '`id` DESC', $offect, $pageSize);
		return $this->_convertDataForParentList($aParentList);
	}

	public function getXxtParentCount($aCondition = array()){
		$where = $this->_parseWhereForXxtParentList($aCondition);
		$oParent = new Model(T_PARENT);
		return $oParent->count($where);
	}

	private function _parseWhereForXxtParentList($aCondition){
		$where = '';
		if(isset($aCondition['uf_id']) && $aCondition['uf_id']){
			$where = array('id' => $aCondition['uf_id']);
		}else{
			$where = '`extend_code`>0';
			if((isset($aCondition['city_id']) && $aCondition['city_id'])){
				//处理cs 和gz的
				if($aCondition['city_id'] == 'cs'){
					$where .= " AND (`city_id`='" . $aCondition['city_id'] . "' or `city_id` = 'gz')";
				//处理未知城市标志的情况
				}else if($aCondition['city_id'] == 11000000){
					$where .= " AND `city_id`=''";
				}else{
					$where .= " AND `city_id`='" . $aCondition['city_id'] . "'";
				}

			}
			if(isset($aCondition['name']) && $aCondition['name']){
				$where .= " AND `name`='" . $aCondition['name'] . "'";
			}
			if(isset($aCondition['start_time']) && $aCondition['start_time']){
				$where .= " AND `create_time`>='" . $aCondition['start_time'] . "'";
			}
			if(isset($aCondition['end_time']) && $aCondition['end_time']){
				$where .= " AND `create_time`<='" . $aCondition['end_time'] . "'";
			}
		}
		return $where;
	}

	private function _convertDataForParentList($aParentList){
		if(!$aParentList){
			return $aParentList;
		}
		foreach($aParentList as &$aParent){
			if($aParent['xxt_data']){
				$aParent['xxt_data'] = json_decode($aParent['xxt_data'], true);
			}else{
				$aParent['xxt_data'] = array();
			}
		}
		return $aParentList;
	}

	//----------------------------------------------------新版分隔线141022------------------------------------------------------------------
	public function addUserMonthStatistics($aData){
		$aStatisticsIndexFields = array(
			'user_id',
			'month',
			'city_id',
			'school_id',
			'grade',
			'class',
			'score'
		);
		$aStatisticsIndexData = array();
		foreach($aStatisticsIndexFields as $field){
			if(isset($aData[$field])){
				$aStatisticsIndexData[$field] = $aData[$field];
			}
		}
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$id = $oDboi->table(T_USER_MONTH_STATISTICS_INDEX)->data($aStatisticsIndexData)->insert();
		if(!$id){
			return false;
		}
		$aStatisticsData = array();
		$aStatisticsData['id'] = $id;
		if(isset($aData['statistics'])){
			$aStatisticsData['statistics'] = json_encode($aData['statistics']);
		}else{
			$aStatisticsData['statistics'] = json_encode(array());
		}
		$result = $oDboi->table(T_USER_MONTH_STATISTICS)->data($aStatisticsData)->insert();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		return $id;
	}

	public function setUserMonthStatistics($aData){
		$aStatisticsIndexFields = array(
			'user_id',
			'month',
			'city_id',
			'school_id',
			'grade',
			'class',
			'score'
		);
		$aStatisticsIndexData = array();
		foreach($aStatisticsIndexFields as $field){
			if(isset($aData[$field])){
				$aStatisticsIndexData[$field] = $aData[$field];
			}
		}
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$result1 = $result2 = 0;
		if($aStatisticsIndexData){
			$result1 = $oDboi->table(T_USER_MONTH_STATISTICS_INDEX)->where(array('id' => $aData['id']))->data($aStatisticsIndexData)->update();
			if($result1 === false){
				return false;
			}
		}
		if(isset($aData['statistics'])){
			$result2 = $oDboi->table(T_USER_MONTH_STATISTICS)->where(array('id' => $aData['id']))->data(array('statistics' => json_encode($aData['statistics'])))->update();
			if($result1 && $result2 === false){
				$oDboi->rollBack();
				return false;
			}elseif($result2 === false){
				return false;
			}
		}
		if($result1 || $result2){
			return 1;
		}else{
			return 0;
		}
	}

	public function getUserMonthStatisticsInfo($userId, $month){
		$aUserMonthStatisticsList = $this->_getUserMonthStatisticsList($userId, $month);
		if(!$aUserMonthStatisticsList){
			return $aUserMonthStatisticsList;
		}
		return $aUserMonthStatisticsList[0];
	}

	public function getUserMonthStatisticsList($userId){
		return $this->_getUserMonthStatisticsList($userId);
	}

	private function _getUserMonthStatisticsList($userId, $month = 0){
		$oUserMonthStatisticsIndex = new Model(T_USER_MONTH_STATISTICS_INDEX);
		$where = '`user_id`=' . $userId;
		if($month){
			$where .= ' AND `month`=' . $month;
		}
		$aUserMonthStatisticsIndexList = $oUserMonthStatisticsIndex->get('', $where, '`month` DESC');
		if(!$aUserMonthStatisticsIndexList){
			return $aUserMonthStatisticsIndexList;
		}
		$aStatisticsIds = array();
		foreach($aUserMonthStatisticsIndexList as $aUserMonthStatisticsIndex){
			$aStatisticsIds[] = $aUserMonthStatisticsIndex['id'];
		}
		$oUserMonthStatistics = new Model(T_USER_MONTH_STATISTICS);
		$aUserMonthStatisticsList = $oUserMonthStatistics->get('', array('id' => array('in', $aStatisticsIds)));
		if(!$aUserMonthStatisticsList){
			return false;
		}
		foreach($aUserMonthStatisticsIndexList as $key => $aUserMonthStatisticsIndex){
			foreach($aUserMonthStatisticsList as $key2 => $aUserMonthStatistics){
				if($aUserMonthStatisticsIndex['id'] == $aUserMonthStatistics['id']){
					$aUserMonthStatisticsIndexList[$key]['statistics'] = json_decode($aUserMonthStatistics['statistics'], true);
					unset($aUserMonthStatisticsList[$key2]);
					break;
				}
			}
		}
		return $aUserMonthStatisticsIndexList;
	}

	/*
	 * $aCondition = array(
	 *		'month'		=>	201410
	 *		'city_id'	=>	1245
	 *		'school_id'	=>	123456
	 *		'grade'		=>	6
	 *		'class'		=>	'一班'
	 * );
	 */
	public function getUserMonthScoreRankingList($page, $pageSize, $class, $aCondition = array()){
		$where = $this->_parseWhereForScoreRanking($aCondition);
		$oUserMonthStatisticsIndex = new Model(T_USER_MONTH_STATISTICS_INDEX);
		$offect = ($page - 1) * $pageSize;
		if((isset($aCondition['school_id']) && $aCondition['school_id']) || (isset($aCondition['class']) && $aCondition['class'])){
			$aUserMonthStatisticsList = $oUserMonthStatisticsIndex->get('`user_id`,`month`,score', $where, '`score` DESC');
			if($aUserMonthStatisticsList === false){
				return false;
			}
			$aClassUserIds = $this->_getClassUserIds($aCondition['school_id'], $aCondition['grade'], $class);
			if($aClassUserIds === false){
				return false;
			}
			$aInClassUserIds = array();
			foreach($aUserMonthStatisticsList as $aUserMonthStatistics){
				$aInClassUserIds[] = $aUserMonthStatistics['user_id'];
			}
			$aDiffClassUserIds = array_diff($aClassUserIds, $aInClassUserIds);
			foreach($aDiffClassUserIds as $diffClassUserId){
				$aTemp = array();
				$aTemp['user_id'] = $diffClassUserId;
				$aTemp['month'] = $aCondition['month'];
				$aTemp['score'] = 0;
				$aUserMonthStatisticsList[] = $aTemp;
			}
			$i = 0;
			$end = $offect + $pageSize - 1;
			$aReturnData = array();
			foreach($aUserMonthStatisticsList as $aUserMonthStatistics){
				if($i > $end){
					break;
				}elseif($i >= $offect){
					$aReturnData[] = $aUserMonthStatistics;
				}
				$i++;
			}
			return $aReturnData;
		}else{
			return $oUserMonthStatisticsIndex->get('`user_id`,`month`,score', $where, '`score` DESC', $offect, $pageSize);
		}
	}

	private function _getClassUserIds($schoolId, $grade, $class){
		$oClass = new Model(T_USER_CLASS);
		$aClassUserList = $oClass->get('`user_id`', '`school_id`=' . $schoolId . ' AND `grade`=' . $grade . ' AND `class`="' . $class. '" AND `is_active`=1');
		if(!$aClassUserList){
			return $aClassUserList;
		}
		$aClassUserIds = array();
		foreach($aClassUserList as $aClassUser){
			$aClassUserIds[] = $aClassUser['user_id'];
		}
		return $aClassUserIds;
	}

	private function _parseWhereForScoreRanking($aCondition){
		$where = '`month`=' . $aCondition['month'];
		if(isset($aCondition['city_id']) && $aCondition['city_id']){
			$where .= ' AND `city_id`=' . $aCondition['city_id'];
		}
		if(isset($aCondition['school_id']) && $aCondition['school_id']){
			$where .= ' AND `school_id`=' . $aCondition['school_id'];
		}
		if(isset($aCondition['grade']) && $aCondition['grade']){
			$where .= ' AND `grade`=' . $aCondition['grade'];
		}
		if(isset($aCondition['class']) && $aCondition['class']){
			$where .= " AND `class`='" . $aCondition['class'] . "'";
		}
		return $where;
	}

	public function getUserMonthScoreRanking($month, $score, $aCondition = array()){
		$where = '';
		if($aCondition){
			$where = $this->_parseWhereForScoreRanking($aCondition);
		}
		if($where){
			$where .= ' AND `score`>' . $score;
		}else{
			$where = '`score`>' . $score . ' AND `month`=' . $month;
		}
		$oUserMonthStatisticsIndex = new Model(T_USER_MONTH_STATISTICS_INDEX);
		return $oUserMonthStatisticsIndex->count($where) + 1;
	}

	public function getUserMonthScoreCount($month, $aCondition = array()){
		$where = '';
		if($aCondition){
			$where = $this->_parseWhereForScoreRanking($aCondition);
		}
		if($where){
			$where .= ' AND `score`>0';
		}else{
			$where = '`score`>0 AND `month`=' . $month;
		}
		$oUserMonthStatisticsIndex = new Model(T_USER_MONTH_STATISTICS_INDEX);
		return $oUserMonthStatisticsIndex->count($where);
	}
}
