<?php
/*
 * 视频模型
 */
class VideoModel{
	//增加视频目录
	public function addVideoCategory($aData){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		return $oVideoCategory->add($aData);
	}

	//删除视频目录
	public function deleteVideoCategoryById($categoryId){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		return $oVideoCategory->delete(array('id' => $categoryId));
	}

	//查找视屏目录列表
	public function getVideoCategoryList($statu, $page, $pageSize, $order = '`id` DESC'){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		$offect = ($page - 1) * $pageSize;
		if($statu == -1){
			$where = '';
		}else{
			$where = '`status`=' . $statu;
		}
		return $oVideoCategory->get('', $where, $order, $offect, $pageSize);
	}

	public function getVideoCategoryCount($statu){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		if($statu == -1){
			$where = '';
		}else{
			$where = '`status`=' . $statu;
		}
		return $oVideoCategory->count($where);
	}

	//查找某个视频目录
	public function getVideoCategoryInfoById($categoryId){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		$aVideoCategoryInfo = $oVideoCategory->get('', array('id' => $categoryId));
		if($aVideoCategoryInfo){
			$aVideoCategoryInfo = $aVideoCategoryInfo[0];
		}
		return $aVideoCategoryInfo;
	}

	public function getVideoCategoryInfoByName($categoryName){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		$aVideoCategoryInfo = $oVideoCategory->get('', "`name`='" . $categoryName . "'");
		if($aVideoCategoryInfo){
			$aVideoCategoryInfo = $aVideoCategoryInfo[0];
		}
		return $aVideoCategoryInfo;
	}

	//修改视屏目录
	public function setVideoCategory($aData){
		$oVideoCategory = new Model(T_VIDEO_CATEGORY);
		return $oVideoCategory->update($aData, array('id' => $aData['id']));
	}

	//增加视频
	public function addVideo($aData){
		$oVideo = new Model(T_VIDEO);
		return $oVideo->add($aData);
	}

	//删除视频
	public function deleteVideoById($id){
		$oVideo = new Model(T_VIDEO);
		return $oVideo->delete(array('id' => $id));
	}

	//查找视屏列表
	//$aCondition = array(
	//	'statu' => -1 全部/0 不可见/1 可见
	//	'is_trans'	=>	=> -1 全部/0 不可见/1 可见
	//	'is_recommend'	=>	-1 全部/0 不推荐/1 推荐
	//	'category_id' => 0 全部
	//	'is_background'	=> 0 不是/1 是后台查找的
	//)
	public function getVideoList($aCondition = array(), $page = 1, $pageSize = 10){
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if(isset($aCondition['is_background']) && $aCondition['is_background']){
			if(isset($aCondition['statu']) && $aCondition['statu'] != -1){
				$where .= '`status`=' . $aCondition['statu'];
			}
			if(isset($aCondition['is_trans']) && $aCondition['is_trans'] != -1){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`is_trans`=' . $aCondition['is_trans'];
			}
			if(isset($aCondition['is_recommend']) && $aCondition['is_recommend'] != -1){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`is_recommend`=' . $aCondition['is_recommend'];
			}
			if(isset($aCondition['category_id']) && $aCondition['category_id']){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`category_id`=' . $aCondition['category_id'];
			}
			$oVideo = new Model(T_VIDEO);
			return $oVideo->get('', $where, '`id` DESC', $offect, $pageSize);
		}else{
			$where = '`cate`.`status`=1';
			if(isset($aCondition['statu']) && $aCondition['statu'] != -1){
				$where .= ' AND `t1`.`status`=' . $aCondition['statu'];
			}
			if(isset($aCondition['is_trans']) && $aCondition['is_trans'] != -1){
				$where .= ' AND `t1`.`is_trans`=' . $aCondition['is_trans'];
			}
			if(isset($aCondition['is_recommend']) && $aCondition['is_recommend'] != -1){
				$where .= ' AND `t1`.`is_recommend`=' . $aCondition['is_recommend'];
			}
			if(isset($aCondition['category_id']) && $aCondition['category_id']){
				$where .= ' AND `t1`.`category_id`=' . $aCondition['category_id'];
			}
			$oDboi = new DBOI();
			return $oDboi->fields('`t1`.*')->table(T_VIDEO)->leftjoin(T_VIDEO_CATEGORY, 'as `cate` on `t1`.`category_id`=`cate`.`id`')->where($where)->orderby('`id` DESC')->limit($offect, $pageSize)->select();
		}
	}

	public function getVideoCount($aCondition = array()){
		$where = '';
		if(isset($aCondition['is_background']) && $aCondition['is_background']){
			if(isset($aCondition['statu']) && $aCondition['statu'] != -1){
				$where .= '`status`=' . $aCondition['statu'];
			}
			if(isset($aCondition['is_trans']) && $aCondition['is_trans'] != -1){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`is_trans`=' . $aCondition['is_trans'];
			}
			if(isset($aCondition['is_recommend']) && $aCondition['is_recommend'] != -1){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`is_recommend`=' . $aCondition['is_recommend'];
			}
			if(isset($aCondition['category_id']) && $aCondition['category_id']){
				if($where){
					$where .= ' AND ';
				}
				$where .= '`category_id`=' . $aCondition['category_id'];
			}
			$oVideo = new Model(T_VIDEO);
			return $oVideo->count($where);
		}else{
			$where = '`cate`.`status`=1';
			if(isset($aCondition['statu']) && $aCondition['statu'] != -1){
				$where .= ' AND `t1`.`status`=' . $aCondition['statu'];
			}
			if(isset($aCondition['is_trans']) && $aCondition['is_trans'] != -1){
				$where .= ' AND `t1`.`is_trans`=' . $aCondition['is_trans'];
			}
			if(isset($aCondition['is_recommend']) && $aCondition['is_recommend'] != -1){
				$where .= ' AND `t1`.`is_recommend`=' . $aCondition['is_recommend'];
			}
			if(isset($aCondition['category_id']) && $aCondition['category_id']){
				$where .= ' AND `t1`.`category_id`=' . $aCondition['category_id'];
			}
			$oDboi = new DBOI();
			$aVideoCount = $oDboi->fields('count(*) as `nums`')->table(T_VIDEO)->leftjoin(T_VIDEO_CATEGORY, 'as `cate` on `t1`.`category_id`=`cate`.`id`')->where($where)->select();
			if($aVideoCount === false){
				return false;
			}else{
				return $aVideoCount[0]['nums'];
			}
		}
	}

	//查找某个视频
	public function getVideoInfoById($id){
		$oVideo = new Model(T_VIDEO);
		$aVideoInfo = $oVideo->get('', array('id' => $id));
		if($aVideoInfo){
			$aVideoInfo = $aVideoInfo[0];
		}
		return $aVideoInfo;
	}

	//修改视屏
	public function setVideo($aData){
		$oVideo = new Model(T_VIDEO);
		return $oVideo->update($aData, array('id' => $aData['id']));
	}

	public function getVideoInfoByUmelookId($umelookId){
		$oVideo = new Model(T_VIDEO);
		$aVideoInfo = $oVideo->get('', '`umelook_id`=' . $umelookId);
		if($aVideoInfo){
			$aVideoInfo = $aVideoInfo[0];
		}
		return $aVideoInfo;
	}

	public function getVideoInfoByTitle($title){
		$title = str_replace("'", "\\'", $title);
		$oVideo = new Model(T_VIDEO);
		$aVideoInfo = $oVideo->get('', "`title`='" . $title . "'");
		if($aVideoInfo){
			$aVideoInfo = $aVideoInfo[0];
		}
		return $aVideoInfo;
	}

	//查找前面的n条记录
	public function getFrontVideoList($currentVideoId, $length){
		$where = '`t1`.`status`=1 AND `cate`.`status`=1 AND `t1`.`id`<' . $currentVideoId;
		$oDboi = new DBOI();
		$aVideoList = $oDboi->fields('`t1`.*')->table(T_VIDEO)->leftjoin(T_VIDEO_CATEGORY, 'as `cate` on `t1`.`category_id`=`cate`.`id`')->where($where)->orderby('`id` DESC')->limit(0, $length)->select();
		if($aVideoList === false){
			return false;
		}
		$need = $length - count($aVideoList);
		if($need > 0){
			$aVideoIds = array($currentVideoId);
			foreach($aVideoList as $aVideo){
				$aVideoIds[] = $aVideo['id'];
			}
			$where = '`t1`.`status`=1 AND `cate`.`status`=1 AND `t1`.`id` NOT IN (' . implode(',', $aVideoIds) . ')';
			$aNeedVideoList = $oDboi->fields('`t1`.*')->table(T_VIDEO)->leftjoin(T_VIDEO_CATEGORY, 'as `cate` on `t1`.`category_id`=`cate`.`id`')->where($where)->orderby('`id` DESC')->limit(0, $need)->select();
			$aVideoList = array_merge($aVideoList, $aNeedVideoList);
		}
		return $aVideoList;
	}
}