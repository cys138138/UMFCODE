<?php
/**
 * 后台用户模型
 */
class WenwenModel{
	private function getUserListByUserIds($aUserIds){
		$oPersonal = new Model(T_PERSONAL);
		return $oPersonal->get('', array('id' => array('in', $aUserIds)));
	}

	public function addComment($aData){
		$oComment = new Model(T_ES_COMMENT);
		return $oComment->add($aData);
	}

	public function deleteCommentById($commentId){
		$oComment = new Model(T_ES_COMMENT);
		$result = $oComment->delete(array('id' => $commentId));
		if($result){
			$row = $oComment->delete('`parent_id`=' . $commentId);
			if($row === false){
				return false;
			}
		}
		return $result;
	}

	public function setComment($aData){
		$oComment = new Model(T_ES_COMMENT);
		return $oComment->update($aData, array('id' => $aData['id']));
	}

	public function getCommentCount($esId){
		$oComment = new Model(T_ES_COMMENT);
		$where = '`es_id`=' . $esId . ' AND `parent_id`=0';
		return $oComment->count($where);
	}

	public function getQuestionCount($esId){
		$oQuestion = new Model(T_QUESTION);
		return $oQuestion->count('`es_id`=' . $esId);
	}

	public function getCommentListByEsId($esId, $page = 1, $pageSize = null, $order = '`id` desc'){
		$oComment = new Model(T_ES_COMMENT);
		$offect = ($page - 1) * $pageSize;
		$where = '`es_id`=' . $esId . ' AND `parent_id`=0';
		$aCommentList = $oComment->get('', $where, $order, $offect, $pageSize);
		if($aCommentList){
			$aUserIds = array();
			$aCommentIds = array();
			foreach($aCommentList as $aComment){
				if($aComment['is_anonymous'] != 1){
					$aUserIds[] = $aComment['user_id'];
				}
				$aCommentIds[] = $aComment['id'];
			}
			$aChildCommentList = $oComment->get('', '`parent_id` in (' . implode(',', $aCommentIds) . ')', '`id` ASC');
			if($aChildCommentList === false){
				return false;
			}
			foreach($aChildCommentList as $aChildComment){
				$aUserIds[] = $aChildComment['user_id'];
			}
			$aUserIds = array_unique($aUserIds);
			$aUserList = array();
			if($aUserIds){
				$aUserList = $this->getUserListByUserIds($aUserIds);
				if($aUserList === false){
					return false;
				}
			}
			foreach($aChildCommentList as &$aChildComment){
				$aChildComment['user_info'] = array();
				if($aChildComment['is_anonymous'] != 1){
					foreach($aUserList as $aUser){
						if($aChildComment['user_id'] == $aUser['id']){
							$aChildComment['user_info'] = $aUser;
						}
					}
				}
				//$aChildComment['create_time'] = date('Y-m-d H:i:s', $aChildComment['create_time']);
				unset($aChildComment);
			}

			foreach($aCommentList as &$aComment){
				$aComment['user_info'] = array();
				if($aComment['is_anonymous'] != 1){
					foreach($aUserList as $aUser){
						if($aComment['user_id'] == $aUser['id']){
							$aComment['user_info'] = $aUser;
						}
					}
				}
				$aComment['child'] = array();
				foreach($aChildCommentList as $aChildComment){
					if($aChildComment['parent_id'] == $aComment['id']){
						$aComment['child'][] = $aChildComment;
					}
				}
				//$aComment['create_time'] = date('Y-m-d H:i:s', $aComment['create_time']);
			}
		}
		return $aCommentList;
	}

	public function getCommentList($page = 1, $pageSize = 20){
		$oComment = new Model(T_ES_COMMENT);
		$offect = ($page - 1) * $pageSize;
		$where = '`approved`=0';
		$order = '`create_time` asc';
		$aCommentList = $oComment->get('', $where, $order, $offect, $pageSize);
		if($aCommentList === false){
			return false;
		}
		$count = count($aCommentList);
		if($count == $pageSize){
			return $aCommentList;
		}elseif($count){
			$needle = $pageSize - $count;
			$where = '`approved`!=0';
			$offect1 = 0;
		}else{
			$notApprovedCount = $oComment->count($where);
			if($notApprovedCount === false){
				return false;
			}
			$offect1 = $offect - $notApprovedCount;
			$needle = $pageSize;
			$where = '`approved`!=0';
		}
		$aApprovedCommetList = $oComment->get('', $where, $order, $offect1, $needle);
		if($aApprovedCommetList === false){
			return false;
		}
		return array_merge($aCommentList, $aApprovedCommetList);
	}

	public function getAllCommentCount(){
		$oComment = new Model(T_ES_COMMENT);
		return $oComment->count('');
	}

	public function addQuestion($aData){
		$oQuestion = new Model(T_QUESTION);
		return $oQuestion->add($aData);
	}

	public function getQuestionListByEsId($esId, $page = 1, $pageSize = null, $order = '`id` desc'){
		$oQuestion = new Model(T_QUESTION);
		$offect = ($page - 1) * $pageSize;
		$aQuestionList = $oQuestion->get('', '`es_id`=' . $esId, $order, $offect, $pageSize);
		if($aQuestionList){
			$aAnswerIds = array();
			$aQuestionIds = array();
			$aUserIds = array();
			foreach($aQuestionList as $aQuestion){
				if($aQuestion['answer_id']){
					$aAnswerIds[] = $aQuestion['answer_id'];
				}else{
					$aQuestionIds[] = $aQuestion['id'];
				}
				if($aQuestion['is_anonymous'] != 1){
					$aUserIds[] = $aQuestion['user_id'];
				}
			}
			$oAnswer = new Model(T_ANSWER);
			if(!$aQuestionIds && $aAnswerIds){
				$aAnswerList = $oAnswer->get('', array('id' => array('in', $aAnswerIds)));
			}else{
				$where = '';
				if($aAnswerIds){
					$where .= '`id` in (' . implode(',', $aAnswerIds) . ')';
				}
				if($aQuestionIds){
					if($where){
						$where .= ' OR ';
					}
					$where .= '`question_id` in (' . implode(',', $aQuestionIds) . ')';
				}
				$aAnswerList = $oAnswer->get('', $where);
			}
			if($aAnswerList === false){
				return false;
			}elseif($aAnswerList){
				foreach($aAnswerList as $aAnswer){
					if($aAnswer['is_anonymous'] != 1){
						$aUserIds[] = $aAnswer['user_id'];
					}
				}
			}
			$aUserIds = array_unique($aUserIds);
			$aUserList = array();
			if($aUserIds){
				$aUserList = $this->getUserListByUserIds($aUserIds);
				if($aUserList === false){
					return false;
				}
			}
			foreach($aAnswerList as &$aAnswer){
				$aAnswer['user_info'] = array();
				if($aAnswer['is_anonymous'] != 1){
					foreach($aUserList as $aUser){
						if($aAnswer['user_id'] == $aUser['id']){
							$aAnswer['user_info'] = $aUser;
						}
					}
				}
				unset($aAnswer);
			}
			foreach($aQuestionList as &$aQuestion){
				$aQuestion['answer_list'] = array();
				if($aQuestion['answer_id']){
					foreach($aAnswerList as $aAnswer){
						if($aQuestion['answer_id'] == $aAnswer['id']){
							$aQuestion['answer_list'][] = $aAnswer;
						}
					}
				}else{
					$i = 0;
					foreach($aAnswerList as $aAnswer){
						if($i > 2){
							break;
						}
						if($aAnswer['question_id'] == $aQuestion['id']){
							$aQuestion['answer_list'][] = $aAnswer;
							$i++;
						}
					}
				}
				$aQuestion['user_info'] = array();
				if($aQuestion['is_anonymous'] != 1){
					foreach($aUserList as $aUser){
						if($aQuestion['user_id'] == $aUser['id']){
							$aQuestion['user_info'] = $aUser;
						}
					}
				}
			}
		}
		return $aQuestionList;
	}

	public function addAnswer($aData){
		$oAnswer = new Model(T_ANSWER);
		return $oAnswer->add($aData);
	}

	public function getAnswerListByQuestionId($questionId, $page = 1, $pageSize = null, $order = '`id` desc'){
		$oAnswer = new Model(T_ANSWER);
		$offect = ($page - 1) * $pageSize;
		return $oAnswer->get('', '`question_id`=' . $questionId, $order, $offect, $pageSize);
	}
}