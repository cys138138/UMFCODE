<?php
/*
 * 前台拓展模型
 */
class UserExtendModel{
	public function addUserExtend($aData){
		$oUserExtend = new Model(T_USER_EXTEND);
		return $oUserExtend->add($aData);
	}

	public function getUserExtendInfoById($id){
		$oUserExtend = new Model(T_USER_EXTEND);
		$aUserExtendInfo = $oUserExtend->get('', array('id' => $id));
		if($aUserExtendInfo){
			$aUserExtendInfo = $aUserExtendInfo[0];
		}
		return $aUserExtendInfo;
	}

	public function getUserExtendInfoByQq($qq){
		$oUserExtend = new Model(T_USER_EXTEND);
		$aUserExtendInfo = $oUserExtend->get('', '`qq`=' . $qq);
		if($aUserExtendInfo){
			$aUserExtendInfo = $aUserExtendInfo[0];
		}
		return $aUserExtendInfo;
	}

	public function getUserExtendList($page, $pageSize){
		$oUserExtend = new Model(T_USER_EXTEND);
		$offect = ($page - 1) * $pageSize;
		$aUserExtendList = $oUserExtend->get('', '', '', $offect, $pageSize);
		if($aUserExtendList){
			$aUserIds = array();
			foreach($aUserExtendList as $aUserExtend){
				$aUserIds[] = $aUserExtend['id'];
			}
			$aUserList = $this->_getUserListByIds($aUserIds);
			foreach($aUserExtendList as &$aUserExtend){
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aUserExtend['id']){
						$aUserExtend['name'] = $aUser['name'];
						break;
					}
				}
			}
		}
		return $aUserExtendList;
	}

	public function getUserExtendCount(){
		$oUserExtend = new Model(T_USER_EXTEND);
		return $oUserExtend->count('');
	}

	public function getTodayUserExtendCount(){
		$oUserExtend = new Model(T_USER_EXTEND);
		$todayDate = date('Y-m-d', time());
		$starTime = strtotime($todayDate . ' 00:00:00');
		return $oUserExtend->count('`create_time`>=' . $starTime);
	}

	private function _getUserListByIds($aUserIds){
		$oPersonal = new Model(T_PERSONAL);
		$aUserList = $oPersonal->get('', array('id' => array('in', $aUserIds)));
		return $aUserList;
	}

	//添加用户物品
	public function addUserGoods($aData){
		$oUserGoods = new Model(T_USER_GOODS);
		if(isset($aData['cards'])){
			$aData['cards'] = implode(',', $aData['cards']);
		}
		return $oUserGoods->add($aData);
	}

	//更新用户物品表
	public function setUserGoods($aData){
		$oUserGoods = new Model(T_USER_GOODS);
		if(isset($aData['cards'])){
			$aData['cards'] = implode(',', $aData['cards']);
		}
		return $oUserGoods->update($aData, array('id' => $aData['id']));
	}

	//得到用户物品信息
	public function getUserGoodsInfo($id){
		$oUserGoods = new Model(T_USER_GOODS);
		$aUserGoodsInfo = $oUserGoods->get('', array('id' => $id));
		if($aUserGoodsInfo){
			$aUserGoodsInfo = $aUserGoodsInfo[0];
			if($aUserGoodsInfo['cards']){
				$aUserGoodsInfo['cards'] = explode(',', $aUserGoodsInfo['cards']);
			}else{
				$aUserGoodsInfo['cards'] = array();
			}
		}
		return $aUserGoodsInfo;
	}

}