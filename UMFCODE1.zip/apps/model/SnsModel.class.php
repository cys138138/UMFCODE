<?php
use common\model\UserFriend;

/*
 * SNS模型
 */
class SnsModel{
	//用户个人消息表配置
	private $_aPesonalType = array(
		'ait'	=>	1,
		'comment_ait' =>100,
		'retransmission'	=>	2,
		'comment'	=>	3,
		'reply_comment'	=>	4,
		'public_message'	=>	8,
		'reply_public_message'	=>	9,
		'match_result' =>  20,
		'sponsor_pk' =>  30,
		'refuse_pk' =>  31,
		'pk_result' =>  32,
	);
	//用户动态表配置
	private $_aSnsEvent = array(
		'publish_shuoshuo'	=>	1,	//发表说说
		'become_friends'	=>	3,	//成为好友
		'pass_mission'	=>	6,	//过关
		'finish_task'	=>	7,	//完成修炼
		'break_self_record' => 90, //破自己的记录
		'break_world_record' => 91, //破世界记录
		'medal_process'	=>	8,	//勋章升级及获得
		'registration_match'	=>	9,	//报名参赛
		'finish_match'	=>	11,	//完成比赛
		'join_match_again'	=>	17,	//再次参赛
		'win_match'	=>	12,	//比赛中获奖
		'pk_result'	=>	16,	//分享PK结果
		'match_result' => 80, //分享比赛结果
	);

	private $_aGradeList = array(
		1	=>	'一年级',
		2	=>	'二年级',
		3	=>	'三年级',
		4	=>	'四年级',
		5	=>	'五年级',
		6	=>	'六年级',
		7	=>	'七年级',
		8	=>	'八年级',
		9	=>	'九年级',
	);

	const IS_SUPPORTED = -1;	//我是否已经赞过
	const PROBABLY_FRIEND_COUNT = 50;	//计算可能认识的人的数量
	const PROBABLY_FRIEND_LIMIT_COUNT = 40;	//计算可能认识的人的触发数量
	const PROBABLY_FRIEND_LIMIT_TIME = 7200;	//计算可能认识的人的触发时间段
	const ACTIVE_CLASS_FLAG = 1;	//计算可能认识的人的数量
	const REPLY_COUNT = 20; //回复的数量

	public function addEvent($aData){
		$oEvent = new Model(T_SNS_EVENT);
		return $oEvent->add($aData);
	}

	//获取好友UserIds
	public function getUserFriendIds($userId){
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo === false){
			return false;
		}elseif(!$aUserFriendInfo){
			return '';
		}else{
			$friendIds = '';
			if($aUserFriendInfo['friends']){
				foreach($aUserFriendInfo['friends'] as $friends){
					if($friends){
						$friendIds .= $friends . ',';
					}
				}
				if($friendIds){
					$friendIds = substr($friendIds, 0, -1);
				}
			}
			return $friendIds;
		}
	}

	//获取好友id列表的数组
	public function getUserFriendIdList($userId, $page = false, $pageSize = false){
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo === false){
			return false;
		}elseif(!$aUserFriendInfo){
			return array();
		}else{
			$aFriendIds = array();
			if($aUserFriendInfo['friends']){
				foreach($aUserFriendInfo['friends'] as $friends){
					if($friends){
						$aUserIds = explode(',', $friends);
						$aFriendIds = array_merge($aFriendIds, $aUserIds);
					}
				}
			}
			if($page !== false && $pageSize !== false){
				$aSomeFriendIds = array();
				$start = ($page - 1) * $pageSize;
				$end = $start + $pageSize;
				$i = 0;
				foreach($aFriendIds as $friendId){
					if($i >= $end){
						break;
					}elseif($i >= $start){
						$aSomeFriendIds[] = $friendId;
					}
					$i++;
				}
				return $aSomeFriendIds;
			}
			return $aFriendIds;
		}
	}

	//==============================小纸条===================================
	public function getSnsPrivateMessagesByUserIds($friendUserId, $myUserId, $offSet = '', $length = '', $order = 'id desc'){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		return $oPrivateMessage->get('*', '(`sender_user_id`=' . $friendUserId . ' AND `receiver_user_id`=' . $myUserId . ' AND `status`!=2) OR (`sender_user_id`=' . $myUserId . ' AND `receiver_user_id`=' . $friendUserId . ' AND `status`!=1)', $order, $offSet, $length);
	}

	public function getSnsPrivateMessageById($privateMessageId){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$aPrivateMessageInfo = $oPrivateMessage->get('', array('id' => $privateMessageId));
		if($aPrivateMessageInfo){
			return $aPrivateMessageInfo[0];
		}
		return $aPrivateMessageInfo;
	}

	public function getSnsPrivateMessageDialogCount($userId){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$where = '`sender_user_id`=' . $userId . ' AND `status`!=1';
		$aSendUserList = $oPrivateMessage->get('DISTINCT `receiver_user_id`', $where);
		if($aSendUserList === false){
			return false;
		}
		$aUserIds = array();
		foreach($aSendUserList as $aSendUser){
			$aUserIds[] = $aSendUser['receiver_user_id'];
		}
		$where = '`receiver_user_id`=' . $userId . ' AND `status`!=2';
		$aReceiveUserList = $oPrivateMessage->get('DISTINCT `sender_user_id`', $where);
		if($aReceiveUserList === false){
			return false;
		}
		foreach($aReceiveUserList as $aReceiveUser){
			$aUserIds[] = $aReceiveUser['sender_user_id'];
		}
		$aUserIds = array_unique($aUserIds);
		return count($aUserIds);
	}

	public function getSnsPrivateMessageCount($userId){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		return $oPrivateMessage->count('`receiver_user_id`=' . $userId . ' AND `status`!=2');
	}

	//写小纸条
	public function addSnsPrivateMessage($aData){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		return $oPrivateMessage->add($aData);
	}

	public function editSnsPrivateMessage($aData, $where){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		return $oPrivateMessage->update($aData, $where);
	}

	//删除小纸条
	public function deleteSnsPrivateMessage($id){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		return $oPrivateMessage->delete('`id` = ' . $id);
	}

	public function getPrivateMessageFriendList($userId){
		$aFriendTopMessageList = $this->_getSnsPrivateMessageListByUserId($userId);
		if(!$aFriendTopMessageList){
			return $aFriendTopMessageList;
		}
		$aFriendUserIds = array();
		foreach($aFriendTopMessageList as $aFriendTopMessage){
			if($aFriendTopMessage['sender_user_id'] == $userId){
				$aFriendUserIds[] = $aFriendTopMessage['receiver_user_id'];
			}else{
				$aFriendUserIds[] = $aFriendTopMessage['sender_user_id'];
			}
		}
		$aUserList = getUserListByUserIds($aFriendUserIds);
		if($aUserList === false){
			return false;
		}
		//好友的未读小纸条数量
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$where = '`receiver_user_id`=' . $userId . ' AND `is_read`!=1 AND `status`!=2';
		$aFriendUnreadCountList = $oPrivateMessage->get('`sender_user_id`,count(*) as `nums`', $where, '', '', '', '`sender_user_id`');
		if($aFriendUnreadCountList === false){
			return false;
		}
		foreach($aUserList as $key => $aUser){
			$aUserList[$key]['unread_count'] = 0;
			foreach($aFriendUnreadCountList as $aFriendUnreadCount){
				if($aUser['id'] == $aFriendUnreadCount['sender_user_id']){
					$aUserList[$key]['unread_count'] = $aFriendUnreadCount['nums'];
					break;
				}
			}
		}
		return $aUserList;
	}

	private function _getSnsPrivateMessageListByUserId($userId, $order = '`id` desc'){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$fields = 'max(`id`) as `id`';
		$where = '(`receiver_user_id`=' . $userId . ' AND `status`!=2) OR (`sender_user_id`=' . $userId . ' AND `status`!=1)';
		$groupBy = '`sender_user_id`,`receiver_user_id`';
		//我接收的前N条记录
		$aMessageIds = $oPrivateMessage->get($fields, $where, '', '', '', $groupBy);
		if(!$aMessageIds){
			return $aMessageIds;
		}
		$messageIds = '';
		foreach($aMessageIds as $aMessageId){
			$messageIds .= $aMessageId['id'] . ',';
		}
		$messageIds = substr($messageIds, 0, -1);
		$aPrivateMessageList = $oPrivateMessage->get('', array('id' => array('in', $messageIds)), $order);
		if($aPrivateMessageList){
			$count = count($aPrivateMessageList);
			for($i = 0; $i < $count - 1; $i++){
				if(isset($aPrivateMessageList[$i])){
					for($j = $i + 1; $j < $count; $j++){
						if(isset($aPrivateMessageList[$j])){
							if($aPrivateMessageList[$j]['sender_user_id'] == $aPrivateMessageList[$i]['receiver_user_id'] && $aPrivateMessageList[$j]['receiver_user_id'] == $aPrivateMessageList[$i]['sender_user_id']){
								unset($aPrivateMessageList[$j]);
							}
						}
					}
				}
			}
		}
		return $aPrivateMessageList;
	}

	//===============================留言板========================================
	public function getSnsPublicMessageListByUserId($userId, $page = 1, $pageSize = 10, $order = 'create_time desc'){
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		$offect = ($page - 1) * $pageSize;
		$aPublicMessageList = $oPublicMessage->get('*', '`user_id` = ' . $userId . ' AND `parent_id` = 0', $order, $offect, $pageSize);
		if($aPublicMessageList){
			$oPersonal = new Model(T_PERSONAL);
			foreach($aPublicMessageList as &$aPublicMessage){
				$aSenderUserInfo = $oPersonal->get('', array('id' => $aPublicMessage['sender_user_id']));
				if($aSenderUserInfo){
					$aPublicMessage['sender_user_name'] = $aSenderUserInfo[0]['name'];
					$aPublicMessage['sender_user_profile'] = $aSenderUserInfo[0]['profile'];
					$aPublicMessage['signature'] = $aSenderUserInfo[0]['signature'];
				}elseif($aSenderUserInfo === false){
					return false;
				}else{
					$aPublicMessage['sender_user_name'] = '不存在的用户';
					myLog('在留言板表中ID为：' . $aPublicMessage['id'] . '中，用户ID为：' . $aPublicMessage['sender_user_id'] . '的用户不存在');
				}
				$aPublicMessage['create_time'] = date('Y-m-d H:i', $aPublicMessage['create_time']);
				$aChildPublicMessageList = $oPublicMessage->get('', '`parent_id`=' . $aPublicMessage['id']);
				if($aChildPublicMessageList === false){
					return false;
				}elseif($aChildPublicMessageList){
					foreach($aChildPublicMessageList as &$aChildPublicMessage){
						$aSenderUserInfo = $oPersonal->get('`profile`,`name`', array('id' => $aChildPublicMessage['sender_user_id']));
						if($aSenderUserInfo === false){
							return false;
						}elseif($aSenderUserInfo){
							$aChildPublicMessage['sender_user_name'] = $aSenderUserInfo[0]['name'];
							$aChildPublicMessage['sender_user_profile'] = $aSenderUserInfo[0]['profile'];
						}else{
							$aChildPublicMessage['sender_user_name'] = '不存在的用户';
							myLog('在留言板表中ID为：' . $aChildPublicMessage['id'] . '中，用户ID为：' . $aChildPublicMessage['sender_user_id'] . '的用户不存在');
						}
						$aChildPublicMessage['create_time'] = date('Y-m-d H:i', $aChildPublicMessage['create_time']);
					}
					$aPublicMessage['child'] = $aChildPublicMessageList;
				}else{
					$aPublicMessage['child'] = array();
				}
			}
		}
		return $aPublicMessageList;
	}

	public function getSnsPublicMessageCount($userId){
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		return $oPublicMessage->count('`user_id` = ' . $userId . ' AND `parent_id` = 0');
	}

	public function getSnsPublicMessageInfoById($id){
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		$aPublicMessageInfo = $oPublicMessage->get('', array('id' => $id));
		if($aPublicMessageInfo){
			return $aPublicMessageInfo[0];
		}else{
			return $aPublicMessageInfo;
		}
	}

	//添加留言
	public function addSnsPublicMessage($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$publicMessageId = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->data($aData)->insert();
		if($publicMessageId && ($aData['user_id'] != $aData['sender_user_id'])){
			if(!isset($aData['parent_id']) || !$aData['parent_id']){
				$aPersonalMessage['type'] = $this->_aPesonalType['public_message'];
			}else{
				$aPersonalMessage['type'] = $this->_aPesonalType['reply_public_message'];
			}
			$aPersonalMessage['user_id'] = $aData['user_id'];
			$aPersonalMessage['data_id'] = $publicMessageId;
			$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
			$aPublicMessage = $oPublicMessage->get('`parent_id`,`user_id`',array('id'=>$aPersonalMessage['data_id']));
			if($aPublicMessage[0]['parent_id'] > 0){
				$where = '(`parent_id`='.$aPublicMessage[0]['parent_id'].' OR `id`='.$aPublicMessage[0]['parent_id'] .') AND user_id='.$aPublicMessage[0]['user_id'];
				$aPublicMessage2 = $oPublicMessage->get('`id`,`parent_id`', $where, 'id DESC');
				if(isset($aPublicMessage2[1]['id']) && $aPublicMessage2[1]['id']){
					$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
					if($aPublicMessage2[1]['parent_id'] == 0){
						$where = '`user_id`='.$aPublicMessage[0]['user_id'].' AND `type`='.$this->_aPesonalType['public_message'].' AND data_id='.$aPublicMessage2[1]['id'];
					}else{
						$where = '`user_id`='.$aPublicMessage[0]['user_id'].' AND `type`='.$this->_aPesonalType['reply_public_message'].' AND data_id='.$aPublicMessage2[1]['id'];
					}
					$oPersonalMessage->delete($where);
				}
			}
			$pesonalMessageId = $oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessage)->insert();
			if(!$pesonalMessageId){
				$oDboi->rollBack();
				return false;
			}
			//更新通知
			$oPersonal = new Model(T_PERSONAL);
			$oPersonal->update(array('new_feed_flag'=>array('add', 1)), array('id'=>$aPersonalMessage['user_id']));
		}
		return $publicMessageId;
	}

	//删除留言
	public function deleteSnsPublicMessage($id, $isReply = 0){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//如果是回复的话，就要把回复和回复相关的personalMessage删除
		if($isReply){
			//删除回复
			$result = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->where(array('id' => $id))->delete();
			if(!$result){
				return $result;
			}
			//删除回复相关personalMessage
			$rows = $oDboi->table(T_PERSONAL_MESSAGE)->where('`type`=' . $this->_aPesonalType['reply_public_message'] . ' AND `data_id`=' . $id)->delete();
			if($rows === false){
				return false;
			}
		}else{	//如果是留言的话，就要把留言及留言相关的personalMessage删除 AND 留言下的回复和回复相关的personalMessage删除
			$aReplyPublicMessageList = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->fields('`id`')->where('`parent_id`=' . $id)->select();
			if($aReplyPublicMessageList === false){
				return false;
			}elseif($aReplyPublicMessageList){
				$aReplyPublicMessageIds = array();
				foreach($aReplyPublicMessageList as $aReplyPublicMessage){
					$aReplyPublicMessageIds[] = $aReplyPublicMessage['id'];
				}
				//删除留言相关回复
				$result = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->where(array('id' => array('in', $aReplyPublicMessageIds)))->delete();
				if(!$result){
					return $result;
				}

				//删除回复相关personalMessage
				$result = $oDboi->table(T_PERSONAL_MESSAGE)->where('`type`=' . $this->_aPesonalType['reply_public_message'] . ' AND `data_id` in (' . implode(',', $aReplyPublicMessageIds) . ')')->delete();

				if($result === false){
					$oDboi->rollBack();
					return false;
				}
			}
			//删除留言本身
			$result = $oDboi->table(T_SNS_PUBLIC_MESSAGE)->where(array('id' => $id))->delete();
			if(!$result){
				$oDboi->rollBack();
				return $result;
			}
			//删除留言相关personalMessage
			$row = $oDboi->table(T_PERSONAL_MESSAGE)->where('`type`=' . $this->_aPesonalType['public_message'] . ' AND `data_id`=' . $id)->delete();
			if($row === false){
				$oDboi->rollBack();
				return false;
			}
		}
		return $result;
	}

	//=================================好友管理=================================
	//查看好友信息
	public function getUserFriendInfo($userId){
		$oFriend = new Model(T_USER_FRIEND);
		$aFriendInfo = $oFriend->get('*', '`id` = ' . $userId);
		if($aFriendInfo){
			$aFriendInfo[0]['friends'] = json_decode($aFriendInfo[0]['friends'], true);
			return $aFriendInfo[0];
		}else{
			return $aFriendInfo;
		}
	}

	//添加
	public function addUserFriend($aData){
		$oFriend = new Model(T_USER_FRIEND);
		if(isset($aData['friends'])){
			$aData['friends'] = json_encode($aData['friends']);
		}else{
			$aData['friends'] = json_encode(array('-1' => ''));
		}
		return $oFriend->add($aData);
	}

	//修改
	public function setUserFriend($aData){
		$oFriend = new Model(T_USER_FRIEND);
		if(isset($aData['friends'])){
			$aData['friends'] = json_encode($aData['friends']);
		}
		return $oFriend->update($aData, array('id' => $aData['id']));
	}

	//得到好友列表的好友信息
	public function getUserListByUserIds($userIds, $offset, $length, $order){
		$oUser = new Model(T_USER);
		$aUserList = $oUser->get('', array('id' => array('in', $userIds)), $order, $offset, $length);
		if(!$aUserList){
			return $aUserList;
		}
		$personalIds = '';
		foreach($aUserList as $aUser){
			$personalIds .= $aUser['id'] . ',';
		}
		$personalIds = substr($personalIds, 0, -1);
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalList = $oPersonal->get('`id`,`name`,`profile`,`gender`', array('id' => array('in', $personalIds)));
		if($aPersonalList === false){
			return false;
		}
		$oClass = new Model(T_USER_CLASS);
		$aClassList = $oClass->get('*', ' `user_id` in(' . $personalIds . ') and `is_active`=1 ');
		if($aClassList === false){
			return false;
		}
		foreach($aUserList as &$aUser){
			$aUser['name'] = '';
			$aUser['profile'] = '';
			$aUser['gender'] = 0;
			$aUser['year'] = '';
			$aUser['province_id'] = 0;
			$aUser['city_id'] = 0;
			$aUser['area_id'] = 0;
			$aUser['school_id'] = '';
			$aUser['grade'] = '';
			$aUser['class'] = '';
			foreach($aPersonalList as $aPersonal){
				if($aPersonal['id'] == $aUser['id']){
					$aUser['name'] = $aPersonal['name'];
					$aUser['profile'] = $aPersonal['profile'];
					$aUser['gender'] = $aPersonal['gender'];
				}
			}
			foreach($aClassList as $aClass){
				if($aClass['user_id'] == $aUser['id']){
					$aUser['year'] = $aClass['year'];
					$aUser['province_id'] = $aClass['province_id'];
					$aUser['city_id'] = $aClass['city_id'];
					$aUser['area_id'] = $aClass['area_id'];
					$aUser['school_id'] = $aClass['school_id'];
					$aUser['grade'] = $aClass['grade'];
					$aUser['class'] = $aClass['class'];
				}
			}
		}
		return $aUserList;
	}

	//好友数量
	public function getUserFriendCount($userId, $groupId = 0){
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo){
			if($groupId){
				if(isset($aUserFriendInfo['friends'][$groupId])){
					$friendIds = $aUserFriendInfo['friends'][$groupId];
				}else{
					return 0;
				}
			}else{
				$friendIds = '';
				foreach($aUserFriendInfo['friends'] as $groupFriendIds){
					if($groupFriendIds){
						$friendIds .= $groupFriendIds . ',';
					}
				}
				if($friendIds){
					$friendIds = substr($friendIds, 0, -1);
				}
			}
			if($friendIds){
				return substr_count($friendIds, ',') + 1;
			}else{
				return 0;
			}
		}elseif($aUserFriendInfo === false){
			return false;
		}else{
			return 0;
		}
	}

	public function getUserGroupList($userId){
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo === false){
			return false;
		}elseif(!$aUserFriendInfo){
			$this->cheakProbablyFriends($userId);
			return ;
		}
		$aGroupIds = array();
		$aGroupDetailList = array();
		foreach($aUserFriendInfo['friends'] as $key => $value){
			$aGroupIds[] = $key;
			if($value){
				$aGroupUsers[$key] = explode(',', $value);
			}else{
				$aGroupUsers[$key] = array();
			}
			$aGroupInfo['id'] = $key;
			$aGroupInfo['nums'] = count($aGroupUsers[$key]);
			$aGroupDetailList[] = $aGroupInfo;
		}
		$searchKey = array_keys($aGroupIds, -1);
		if($searchKey){
			unset($aGroupIds[$searchKey[0]]);
		}else{
			//如果没有默认分组，就给加上
			$aUserFriendInfo['friends']['-1'] = '';
			$oUserFriend = new Model(T_USER_FRIEND);
			$oUserFriend->update(array('friends' => json_encode($aUserFriendInfo['friends'])), array('id' => $aUserFriendInfo['id']));
		}
		$aGroupList = array();
		if($aGroupIds){
			$oUserGroup = new Model(T_USER_GROUP);
			$aGroupList = $oUserGroup->get('', array('id' => array('in', implode(',', $aGroupIds))));
		}
		array_unshift($aGroupList, array('id' => -1, 'group_name' => '未分组', 'create_time' => ''));
		foreach($aGroupList as &$aGroup){
			foreach($aGroupDetailList as $aGroupDetail){
				if($aGroup['id'] == $aGroupDetail['id']){
					$aGroup['nums'] = $aGroupDetail['nums'];
				}
			}
		}
		return $aGroupList;
	}

	public function getUserGroupIds($userId){
		$aUserFriendInfo = $this->_getUserFriendInfo($userId, 1);
		if(!$aUserFriendInfo){
			return $aUserFriendInfo;
		}
		$aGroupIds = [];
		foreach($aUserFriendInfo['friends'] as $groupId => $aGroupUserIds){
			$aGroupIds[] = $groupId;
		}
		return $aGroupIds;
	}

	//显示好友管理,可分组
	public function getUserFriendList($userId, $page, $pageSize = 0, $groupId = 0){
		$mUserFriend = UserFriend::findOne($userId);
		$aUserFriendInfo = $mUserFriend->toArray(['friends']);
		if(!$aUserFriendInfo){
			return $aUserFriendInfo;
		}
		$aUserIds = [];
		if($groupId){
			if(isset($aUserFriendInfo['friends'][$groupId])){
				$aUserIds = $aUserFriendInfo['friends'][$groupId];
			}
		}else{
			foreach($aUserFriendInfo['friends'] as $aGroupUserIds){
				$aUserIds = array_merge($aUserIds, $aGroupUserIds);
			}
		}
		if($aUserIds){
			$aAimUserIds = [];
			if($pageSize){
				$offect = ($page - 1) * $pageSize;
				$end = $offect + $pageSize - 1;
				$i = 0;
				foreach($aUserIds as $friendUserId){
					if($i > $end){
						break;
					}if($i >= $offect){
						$aAimUserIds[] = $friendUserId;
					}
					$i++;
				}
			}else{
				$aAimUserIds = $aUserIds;
			}
			$aUserList = getUserListByUserIds($aAimUserIds, array('personal','numerical', 'area', 'class'));
			if(!$aUserList){
				return $aUserList;
			}
			foreach($aUserList as $key => $aUser){
				if($groupId){
					$aUserList[$key]['group_id'] = $groupId;
				}else{
					foreach($aUserFriendInfo['friends'] as $gid => $aGroupUserIds){
						if(in_array($aUser['id'], $aGroupUserIds)){
							$aUserList[$key]['group_id'] = $gid;
							break;
						}
					}
				}
			}
			return $aUserList;
		}else{
			return array();
		}
	}

	public function getUserProbalyFriendCount($userId){
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo === false){
			return false;
		}elseif(!$aUserFriendInfo){
			return 0;
		}else{
			if($aUserFriendInfo['probably']){
				return substr_count($aUserFriendInfo['probably'], ',') + 1;
			}else{
				return 0;
			}
		}
	}

	//随机显示可能认识的人
	public function getUserRandProbablyList($userId, $length = 8, $aCondition = array(), $aExceptUserIds = array()){
		$aUserFriendInfo = $this->_getUserFriendInfo($userId, 2);
		if(!$aUserFriendInfo){
			return $aUserFriendInfo;
		}
		$aUserFriendInfo['probably'] = array_diff($aUserFriendInfo['probably'], $aExceptUserIds);
		$aUserFriendInfo['probably'] = array_unique($aUserFriendInfo['probably']);
		if(count($aUserFriendInfo['probably']) < $length){
			return array();
		}
		$aKeys = array_rand($aUserFriendInfo['probably'], $length);
		$aUserIds = array();
		if(is_array($aKeys)){
			foreach($aKeys as $key){
				$aUserIds[] = $aUserFriendInfo['probably'][$key];
			}
		}else{
			$aUserIds[] = $aUserFriendInfo['probably'][$aKeys];
		}
		$aUserList = getUserListByUserIds($aUserIds, $aCondition);
		if($aUserList){
			$oUser = new Model(T_USER);
			$aUserCreateTimeList = $oUser->get('`id`,`create_time`', array('id' => array('in', $aUserIds)));
			foreach($aUserList as &$aUser){
				foreach($aUserCreateTimeList as $aUserCreateTime){
					if($aUser['id'] == $aUserCreateTime['id']){
						$aUser['create_time'] = $aUserCreateTime['create_time'];
						break;
					}
				}
			}
		}
		return $aUserList;
	}

	//显示可能认识的人
	public function getUserProbalyFriendList($userId, $offset = 0, $length = ''){
		$aUserFriendInfo = $this->_getUserFriendInfo($userId, 2);
		if(!$aUserFriendInfo){
			return $aUserFriendInfo;
		}
		if(!$offset){
			$offset = 0;
		}
		$aUserFriendInfo['probably'] = array_unique($aUserFriendInfo['probably']);
		if($length){
			$aUserIds = array_slice($aUserFriendInfo['probably'], $offset, $length);
		}else{
			$aUserIds = $aUserFriendInfo['probably'];
		}
		if(count($aUserIds) == 1 && $aUserIds[0] == 0){
			return [];
		}
		return getUserListByUserIds($aUserIds, array('personal', 'area'));
	}

	//得到好友关系记录
	public function getUserRelationInfo($where){
		$oUserRelation = new Model(T_USER_RELATION);
		return $oUserRelation->get('', $where);
	}

	//删除好友
	public function deleteFriend($userId, $friendId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//从我的好友列表中删除
		$aUserFriendInfo = $this->_getUserFriendInfo($userId, 1);
		if(!$aUserFriendInfo){
			return false;
		}
		foreach($aUserFriendInfo['friends'] as $groupId => $groupUserIds){
			$key = array_search($friendId, $groupUserIds);
			if($key !== false){
				unset($aUserFriendInfo['friends'][$groupId][$key]);
			}
			$aUserFriendInfo['friends'][$groupId] = implode(',', $aUserFriendInfo['friends'][$groupId]);
		}
		$aFriendInfo['friends'] = json_encode($aUserFriendInfo['friends']);
		$result = $oDboi->table(T_USER_FRIEND)->data($aFriendInfo)->where(array('id' => $userId))->update();
		if(!$result){
			return $result;
		}
		//将自己从对方好友列表中删除
		$aFriendFriendInfo = $this->_getUserFriendInfo($friendId, 1);
		if(!$aFriendFriendInfo){
			$oDboi->rollBack();
			return false;
		}
		foreach($aFriendFriendInfo['friends'] as $groupId => $groupUserIds){
			$key = array_search($userId, $groupUserIds);
			if($key !== false){
				unset($aFriendFriendInfo['friends'][$groupId][$key]);
			}
			$aFriendFriendInfo['friends'][$groupId] = implode(',', $aFriendFriendInfo['friends'][$groupId]);
		}
		$aFriendInfo['friends'] = json_encode($aFriendFriendInfo['friends']);
		$result2 = $oDboi->table(T_USER_FRIEND)->data($aFriendInfo)->where(array('id' => $friendId))->update();
		if(!$result2){
			$oDboi->rollBack();
			return $result2;
		}
		//将关系表中记录删除
		$where = '(`user_master_id`=' . $userId . ' AND `user_slave_id`=' . $friendId . ') OR (`user_master_id`=' . $friendId . ' AND `user_slave_id`=' . $userId . ')';
		$row = $oDboi->table(T_USER_RELATION)->where($where)->delete();
		if(!$row){
			$oDboi->rollBack();
			return false;
		}
		return $row;
	}

	//忽略好友请求
	public function ignoreFriendApply($relationId){
		$oUserRelation = new Model(T_USER_RELATION);
		return $oUserRelation->delete(array('id' => $relationId));
	}

	//添加分组
	public function addFriendGroup($userId, $groupName){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$groupId = $oDboi->table(T_USER_GROUP)->data(array('group_name' => $groupName, 'create_time' => time()))->insert();
		if($groupId){
			$aFriendInfo = $oDboi->table(T_USER_FRIEND)->fields('`friends`')->where(array('id' => $userId))->select();
			if($aFriendInfo === false){
				$oDboi->rollBack();
				return false;
			}elseif($aFriendInfo){
				$aFriendInfo = json_decode($aFriendInfo[0]['friends'], true);
				$aFriendInfo[$groupId] = '';
				$reuslt = $oDboi->table(T_USER_FRIEND)->where(array('id' => $userId))->data(array('friends' => json_encode($aFriendInfo)))->update();
				if(!$reuslt){
					$oDboi->rollBack();
					return false;
				}
			}else{
				$aFriendInfo = array($groupId => '', '-1' => '');
				$aData['id'] = $userId;
				$aData['friends'] = json_encode($aFriendInfo);
				$aData['probably'] = $this->getMyProbablyFriends($userId);
				$aData['probably_calc_time'] = time();
				$reuslt = $oDboi->table(T_USER_FRIEND)->data($aData)->insert();
				if($reuslt === false){
					$oDboi->rollBack();
					return false;
				}
			}
		}
		return $groupId;
	}

	//删除分组
	public function deleteFriendGroup($userId, $groupId){
		//先到我的好友字段中删除该分组，并把该组的好友移动到默认分组中
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aUserFriendInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendInfo){
			foreach($aUserFriendInfo['friends'] as $key => $value){
				if($key == $groupId){
					if($value){
						if($aUserFriendInfo['friends']['-1']){
							$aUserFriendInfo['friends']['-1'] .= ',' . $value;
						}else{
							$aUserFriendInfo['friends']['-1'] = $value;
						}
					}
					unset($aUserFriendInfo['friends'][$groupId]);
				}
			}
			$aFriendInfo['friends'] = json_encode($aUserFriendInfo['friends']);
			$result = $oDboi->table(T_USER_FRIEND)->where(array('id' => $userId))->data($aFriendInfo)->update();
			if($result){
				//在分组表中删除该分组
				$row = $oDboi->table(T_USER_GROUP)->where(array('id' => $groupId))->delete();
				if(!$row){
					$oDboi->rollBack();
					return false;
				}
			}
			return $result;
		}else{
			return false;
		}
	}

	//移动分组
	public function moveUserToGroup($userId, $friendUserId, $newGroupId){
		$userFriendInfo = $this->getUserFriendInfo($userId);
		//先在旧的分组中干掉这个用户
		foreach($userFriendInfo['friends'] as &$groupUserIds){
			if($groupUserIds){
				$aGroupUserIds = explode(',', $groupUserIds);
				if(in_array($friendUserId, $aGroupUserIds)){
					$searchKey = array_keys($aGroupUserIds, $friendUserId);
					unset($aGroupUserIds[$searchKey[0]]);
					$groupUserIds = implode(',', $aGroupUserIds);
				}
			}
		}
		//在新的分组中加上这个用户
		if($userFriendInfo['friends'][$newGroupId]){
			$userFriendInfo['friends'][$newGroupId] .= ',' . $friendUserId;
		}else{
			$userFriendInfo['friends'][$newGroupId] = $friendUserId;
		}
		$aData['friends'] = json_encode($userFriendInfo['friends']);
		$oUserFriend = new Model(T_USER_FRIEND);
		$result = $oUserFriend->update($aData, array('id' => $userId));
		return $result;
	}

	//编辑分组名
	public function editUserGroup($groupId, $newGroupName){
		$oUserGroup = new Model(T_USER_GROUP);
		return $oUserGroup->update(array('group_name' => $newGroupName), array('id' => $groupId));
	}

	//添加个人通知
	public function addPersonalMessage($aData){
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		return $oPersonalMessage->add($aData);
	}

	//删除个人通知
	public function deletePersonalMessageById($messageId){
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$aPersonalMessageInfo = $oPersonalMessage->get('', array('id' => $messageId));
		if($aPersonalMessageInfo === false){
			return false;
		}elseif(!$aPersonalMessageInfo){
			return 0;
		}
		$aPersonalMessageInfo = $aPersonalMessageInfo[0];
		if(!in_array($aPersonalMessageInfo['type'], array(5,6,7,11,12))){
			$oPersonalMessageBak = new Model(T_PERSONAL_MESSAGE_BAK);
			$oPersonalMessageBak->add($aPersonalMessageInfo);
		}
		return $oPersonalMessage->delete(array('id' => $messageId));
	}

	//删除个人通知
	public function deletePersonalMessage($where){
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$aPersonalMessageList = $oPersonalMessage->get('', $where);
		if($aPersonalMessageList === false){
			return false;
		}elseif(!$aPersonalMessageList){
			return 0;
		}
		$aInsertData = array();
		foreach($aPersonalMessageList as $aPersonalMessage){
			if(!in_array($aPersonalMessage['type'], array(5,6,7,11,12))){
				$aInsertData[] = $aPersonalMessage;
			}
		}
		if($aInsertData){
			$oPersonalMessageBak = new Model(T_PERSONAL_MESSAGE_BAK);
			$oPersonalMessageBak->add($aInsertData);
		}
		return $oPersonalMessage->delete($where);
	}

	/*//删除留言通知
	public function deletePublicMessageNotice($userId, $guestBookUserId){
		if($userId == $guestBookUserId){
			$this->deletePersonalMessage('`user_id`=' . $userId . ' AND `type`=8');	//删除留言通知
		}
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$aPersonalMessageList = $oPersonalMessage->get('', '`user_id`=' . $userId . ' AND `type`=' . $this->_aPesonalType['reply_public_message']);
		//有留言回复的通知
		if($aPersonalMessageList){
			$aPublicMessageIds = array();	//留言回复的id列表
			foreach($aPersonalMessageList as $aPersonalMessage){
				$aPublicMessageIds[] = $aPersonalMessage['data_id'];
			}
			$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
			$aPublicMessageList = $oPublicMessage->get('', '`id` in (' . implode(',', $aPublicMessageIds) . ')');
			$aParentIds = array();	//留言的id列表
			foreach($aPublicMessageList as $aPublicMessage){
				$aParentIds[] = $aPublicMessage['parent_id'];
			}
			if($aParentIds){
				//在访问的留言列表
				$aTrueParentList = $oPublicMessage->get('','`id` in (' . implode(',', $aParentIds) . ') AND `user_id`=' . $guestBookUserId);
				if($aTrueParentList){
					$aTrueParentIds = array();
					foreach($aTrueParentList as $aTrueParent){
						$aTrueParentIds[] = $aTrueParent['id'];
					}
					//在访问的留言板的回复列表
					$aTruePublicMessageList = $oPublicMessage->get('', '`parent_id` in (' . implode(',', $aTrueParentIds) . ') AND `id` in (' . implode(',', $aPublicMessageIds) . ')');
					if($aTruePublicMessageList){
						$aTruePublicMessageIds = array();
						foreach($aTruePublicMessageList as $aTruePublicMessage){
							$aTruePublicMessageIds[] = $aTruePublicMessage['id'];
						}
						$this->deletePersonalMessage('`user_id`=' . $userId . ' AND `type`=' . $this->_aPesonalType['reply_public_message'] . ' AND `data_id` in (' . implode(',', $aTruePublicMessageIds) . ')');
					}
				}
			}
		}
	}*/

	//=================================说说相关=================================
	//发表/转发说说
	public function addSnsShuoshuo($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		if(isset($aData['images'])){
			if($aData['images']){
				$aData['images'] = implode(',', $aData['images']);
			}else{
				$aData['images'] = '';
			}
		}
		$shuoshuoId = $oDboi->table(T_SNS_SHUOSHUO)->data($aData)->insert();
		if($shuoshuoId){
			$aEventData['user_id'] = $aData['user_id'];
			if($aData['source_type'] == 2){
				$aEventData['type'] = $this->_aSnsEvent['pk_result'];
			}elseif($aData['source_type'] == 3){
				$aEventData['type'] = $this->_aSnsEvent['match_result'];
			}else{
				$aEventData['type'] = $this->_aSnsEvent['publish_shuoshuo'];
			}

			if(isset($aData['source_id']) && $aData['source_id'] && $aData['source_type'] == 1){
				//转发说说
				$aShuoshuoInfo = $oDboi->table(T_SNS_SHUOSHUO)->fields('`id`,`user_id`,`transmit_times`')->where(array('id' => $aData['source_id']))->select();
				if(!$aShuoshuoInfo){
					$oDboi->rollBack();
					return false;
				}elseif($aShuoshuoInfo){
					//为原始的说说的转发次数+1
					$aTransmitTimes['transmit_times'] = $aShuoshuoInfo[0]['transmit_times'] + 1;
					$result = $oDboi->table(T_SNS_SHUOSHUO)->where(array('id' => $aShuoshuoInfo[0]['id']))->data($aTransmitTimes)->update();
					if(!$result){
						$oDboi->rollBack();
						return false;
					}
					$aPersonalMessageData['user_id'] = $aShuoshuoInfo[0]['user_id'];
					$aPersonalMessageData['type'] = $this->_aPesonalType['retransmission'];
					$aPersonalMessageData['data_id'] = $shuoshuoId;
					$result = $oDboi->table(T_PERSONAL_MESSAGE)->data($aPersonalMessageData)->insert();
					if(!$result){
						$oDboi->rollBack();
						return false;
					}
					//更新通知
					$oPersonal = new Model(T_PERSONAL);
					$personal = $oPersonal->update(array('new_feed_flag'=>array('add', 1)),array('id'=>$aPersonalMessageData['user_id']));
				}
			}
			$aEventData['data_id'] = $shuoshuoId;
			$eventId = $oDboi->table(T_SNS_EVENT)->data($aEventData)->insert();
			if(!$eventId){
				$oDboi->rollBack();
				return false;
			}
		}
		return $shuoshuoId;
	}

	//====================================pipeline标识 版本号:1752======================================

	//评论或回复说说----自己评论自己是不会显示的
	public function commentShuoshuo($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aShuoshuoInfo = $oDboi->table(T_SNS_SHUOSHUO)->where(array('id' => $aData['shuoshuo_id']))->select();
		if(!$aShuoshuoInfo){
			return false;
		}
		$commentId = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->data($aData)->insert();
		if(!$commentId){
			return $commentId;
		}

		$aMessageData = array();
		//写通知消息
		if(!isset($aData['parent_id']) || !$aData['parent_id']){	//如果是评论
			if($aData['user_id'] != $aShuoshuoInfo[0]['user_id']){	//如果不是自己评论自己
				//向说说主人发通知
				$aMessageData['user_id'] = $aShuoshuoInfo[0]['user_id'];
				$aMessageData['type'] = $this->_aPesonalType['comment'];
				$aMessageData['data_id'] = $commentId;
				$messageId = $oDboi->table(T_PERSONAL_MESSAGE)->data($aMessageData)->insert();
				if(!$messageId){
					$oDboi->rollBack();
					return false;
				}
			}
		}else{	//如果是回复
			//向被回复人发通知---如果不是自己回复自己
			if($aData['user_id'] != $aData['replyed_user_id']){
				$aMessageData['user_id'] = $aData['replyed_user_id'];
				$aMessageData['type'] = $this->_aPesonalType['reply_comment'];
				$aMessageData['data_id'] = $commentId;
				$messageId = $oDboi->table(T_PERSONAL_MESSAGE)->data($aMessageData)->insert();
				if(!$messageId){
					$oDboi->rollBack();
					return false;
				}
			}
			//向说说主人发通知---如果回复人不是主人，被回复人不是主人
			if($aData['user_id'] != $aShuoshuoInfo[0]['user_id'] && $aData['replyed_user_id'] != $aShuoshuoInfo[0]['user_id']){
				$aMessageData['user_id'] = $aShuoshuoInfo[0]['user_id'];
				$aMessageData['type'] = $this->_aPesonalType['reply_comment'];
				$aMessageData['data_id'] = $commentId;
				$messageId = $oDboi->table(T_PERSONAL_MESSAGE)->data($aMessageData)->insert();
				if(!$messageId){
					$oDboi->rollBack();
					return false;
				}
			}
		}

		if($aMessageData){
			//更新通知
			$oPersonal = new Model(T_PERSONAL);
			$oPersonal->update(array('new_feed_flag'=>array('add', 1)), array('id'=>$aMessageData['user_id']));
		}

		return $commentId;
	}

	/*//显示shuoshuo首页
	public function getFriendsShuoshuoListByUserId($userId, $page = 1, $pageSize = 20, $order = '`id` desc'){
		//得到我的好友列表
		$aFriendsInfo = $this->getUserFriendInfo($userId);
		if($aFriendsInfo === false){
			return false;
		}
		$friendsUserIds = '';
		foreach($aFriendsInfo['friends'] as $groupUsers){
			if($groupUsers){
				$friendsUserIds .= $groupUsers . ',';
			}
		}
		$friendsUserIds .= $friendsUserIds . $userId;
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$offect = ($page - 1) * $pageSize;
		$aShuoshuoList = $oShuoshuo->get('', '`user_id` in (' . $friendsUserIds . ')', $order, $offect, $pageSize);
		//增加说说的浏览次数
		$today = date('Ymd', time());
		foreach($aShuoshuoList as $aShuoshuo){
			$aData = array();	//清空数组
			//先查看上次浏览用户Id的刷新时间
			if($today == $aShuoshuo['current_date']){
				//查看我今天是否已经有了浏览记录
				if($aShuoshuo['viewed_user']){
					$viewedUser = ',' . $aShuoshuo['viewed_user'] . ',';
					if(strpos($viewedUser, ',' . $userId . ',') === false){
						$aData['viewed_user'] = $aShuoshuo['viewed_user'] . ',' . $userId;
						$aData['views'] = $aShuoshuo['views'] + 1;
					}else{
						continue;
					}
				}else{
					$aData['viewed_user'] = $userId;
					$aData['views'] = $aShuoshuo['views'] + 1;
				}
			}else{
				$aData['current_date'] = $today;
				$aData['viewed_user'] = $userId;
				$aData['views'] = $aShuoshuo['views'] + 1;
			}
			$result = $oShuoshuo->update($aData, array('id' => $aShuoshuo['id']));
			if($result === false){
				return false;
			}
		}
		$aShuoshuoList = $this->_getShuoshuoDetailList($aShuoshuoList);
		return $aShuoshuoList;
	}*/

	/*//我的说说页面
	public function getShuoshuoListByUserId($userId, $page = 1, $pageSize = 20, $order = '`id` desc'){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$offect = ($page - 1) * $pageSize;
		$aShuoshuoList = $oShuoshuo->get('', '`user_id`=' . $userId, $order, $offect, $pageSize);
		$aShuoshuoList = $this->_getShuoshuoDetailList($aShuoshuoList);
		return $aShuoshuoList;
	}*/

	/*public function getShuoshuoDetailInfo($shuoshuoId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoInfo = $oShuoshuo->get('', array('id' => $shuoshuoId));
		if($aShuoshuoInfo){
			$aShuoshuoInfo = $this->_getShuoshuoDetailList($aShuoshuoInfo);
			return $aShuoshuoInfo[0];
		}
		return $aShuoshuoInfo;
	}*/

	/*//我的说说条数
	public function getShuoshuoCountByUserId($userId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoCountInfo = $oShuoshuo->get('count(*) as `nums`', '`user_id`=' . $userId);
		if($aShuoshuoCountInfo){
			return $aShuoshuoCountInfo[0]['nums'];
		}
		return $aShuoshuoCountInfo;
	}*/

	/*//给说说补充评论及用户信息
	private function _getShuoshuoDetailList($aShuoshuoList){
		if($aShuoshuoList === false){
			return false;
		}elseif(!$aShuoshuoList){
			return $aShuoshuoList;
		}else{
			$shuoshuoIds = '';
			$userIds = '';
			$shuoshuoSourceIds = '';
			foreach($aShuoshuoList as $aShuoshuo){
				if($aShuoshuo['source_id']){
					$shuoshuoSourceIds .= $aShuoshuo['source_id'] . ',';
				}
				$shuoshuoIds .= $aShuoshuo['id'] . ',';
				$userIds .= $aShuoshuo['user_id'] . ',';
				if($aShuoshuo['support']){
					$userIds .= $aShuoshuo['support'] . ',';
				}
			}
			$shuoshuoIds = substr($shuoshuoIds, 0, -1);
			$aSourceShuoshuoList = array();
			if($shuoshuoSourceIds){
				$shuoshuoSourceIds = substr($shuoshuoSourceIds, 0, -1);
				$aShuoshuoSourceIds = explode(',', $shuoshuoSourceIds);
				$aShuoshuoSourceIds = array_unique($aShuoshuoSourceIds);
				if($aShuoshuoSourceIds){
					$oShuoshuo = new Model(T_SNS_SHUOSHUO);
					$aSourceShuoshuoList = $oShuoshuo->get('', array('id' => array('in', $aShuoshuoSourceIds)));
					foreach($aSourceShuoshuoList as $aSourceShuoshuo){
						$userIds .= $aSourceShuoshuo['user_id'] . ',';
					}
					if($aSourceShuoshuoList === false){
						return false;
					}
				}
			}

			//查出当前说说的所有评论
			$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
			$aShuoshuoCommentList = $oShuoshuoComment->get('', '`shuoshuo_id` in (' . $shuoshuoIds . ')', '`id` ASC');
			if($aShuoshuoCommentList === false){
				return false;
			}elseif($aShuoshuoCommentList){
				foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
					$userIds .= $aShuoshuoComment['user_id'] . ',';
					if($aShuoshuoComment['replyed_user_id']){
						$userIds .= $aShuoshuoComment['replyed_user_id'] . ',';
					}
					$aShuoshuoCommentList[$key]['create_time'] = date('Y-m-d H:i:s', $aShuoshuoComment['create_time']);
					$aCommentRefer[$aShuoshuoComment['id']] = &$aShuoshuoCommentList[$key];
				}
			}

			//查出当前页面的所有的用户名
			$userIds = substr($userIds, 0, -1);
			$aUserIds = explode(',', $userIds);
			$aUserIds = array_unique($aUserIds);
			$oUser = new Model(T_PERSONAL);
			$aUserList = $oUser->get('`id`,`name`,`profile`', array('id' => array('in', $aUserIds)));
			foreach($aUserList as $key => $value){
				$aUserRefer[$value['id']] = &$aUserList[$key];
			}
			$aCommentTree = array();
			//组装评论结构
			if($aShuoshuoCommentList){
				foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
					//找出评论的用户名
					$aShuoshuoCommentList[$key]['user_info'] = $aUserRefer[$aShuoshuoComment['user_id']];
					if($aShuoshuoComment['replyed_user_id']){
						$aShuoshuoCommentList[$key]['replyed_user_info'] = $aUserRefer[$aShuoshuoComment['replyed_user_id']];
					}
					if(!$aShuoshuoComment['parent_id']){
						$aCommentTree[] = &$aShuoshuoCommentList[$key];
					}else{
						$parentId = $aShuoshuoComment['parent_id'];
						if(isset($aCommentRefer[$parentId])){
							$aParent = &$aCommentRefer[$parentId];
							$aParent['child'][] = &$aShuoshuoCommentList[$key];
						}
					}
				}
			}
			//找出被转发的说说的用户名
			foreach($aSourceShuoshuoList as &$aSourceShuoshuo){
				//找出说说的用户名
				$aSourceShuoshuo['user_info'] = $aUserRefer[$aSourceShuoshuo['user_id']];
			}
			unset($aSourceShuoshuo);
			//组装数据
			foreach($aShuoshuoList as &$aShuoshuo){
				//找出说说的用户名
				$aShuoshuo['user_info'] = $aUserRefer[$aShuoshuo['user_id']];
				//如果有转发的说说，找出原来的说说
				if($aShuoshuo['source_id']){
					foreach($aSourceShuoshuoList as $aSourceShuoshuo){
						if($aShuoshuo['source_id'] == $aSourceShuoshuo['id']){
							$aShuoshuo['source_shuoshuo'] = $aSourceShuoshuo;
							break;
						}
					}
				}
				//拼装说说的评论
				foreach($aCommentTree as $aComment){
					if($aComment['shuoshuo_id'] == $aShuoshuo['id']){
						$aShuoshuo['comment'][] = $aComment;
					}
				}
				//顶的次数
				if($aShuoshuo['support']){
					$aSupportUser = explode(',', $aShuoshuo['support']);
					$aShuoshuo['support_times'] = count($aSupportUser);
					foreach($aSupportUser as $userId){
						$aShuoshuo['support_user'][] = $aUserRefer[$userId];
					}
				}else{
					$aShuoshuo['support_times'] = 0;
				}
			}
			return $aShuoshuoList;
		}
	}*/

	//点击赞
	public function supportShuoshuo($userId, $shuoshuoId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoInfo = $oShuoshuo->get('`support`', array('id' => $shuoshuoId));
		if(!$aShuoshuoInfo){
			return $aShuoshuoInfo;
		}else{
			if($aShuoshuoInfo[0]['support']){
				$supports = ',' . $aShuoshuoInfo[0]['support'] . ',';
				if(strpos($supports, ',' . $userId . ',') === false){
					$aData['support'] = $userId . ',' . $aShuoshuoInfo[0]['support'];
				}else{
					return self::IS_SUPPORTED;
				}
			}else{
				$aData['support'] = $userId;
			}
		}
		return $oShuoshuo->update($aData, array('id' => $shuoshuoId));
	}

	//根据说说id查找
	public function getShuoshuoInfoById($shuoshuoId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoInfo = $oShuoshuo->get('', array('id' => $shuoshuoId));
		if($aShuoshuoInfo){
			return $aShuoshuoInfo[0];
		}
		return $aShuoshuoInfo;
	}

	//删除说说
	public function deleteShuoshuo($shuoshuoId){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$aShuoshuoCommentList = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where('`shuoshuo_id`=' . $shuoshuoId)->select();
		if($aShuoshuoCommentList === false){
			return false;
		}
		//删除说说下面的评论
		$row = $oDboi->table(T_SNS_SHUOSHUO_COMMENT)->where('`shuoshuo_id`=' . $shuoshuoId)->delete();
		if($row === false){
			return false;
		}
		//删除说说
		$result = $oDboi->table(T_SNS_SHUOSHUO)->where(array('id' => $shuoshuoId))->delete();
		if($result === false){
			$oDboi->rollBack();
			return false;
		}elseif($result){
			//删除动态表中数据
			$where = '`data_id`=' . $shuoshuoId . ' AND `type`=' . $this->_aSnsEvent['publish_shuoshuo'];
			$row = $oDboi->table(T_SNS_EVENT)->where($where)->delete();
			if($row === false){
				$oDboi->rollBack();
				return false;
			}
			//删除通知表中的通知
			$where = '`data_id`=' . $shuoshuoId . ' AND `type` in (' . $this->_aPesonalType['ait'] . ',' . $this->_aPesonalType['retransmission']  .')';
			if($aShuoshuoCommentList){
				$aShuoshuoCommentIds = array();
				foreach($aShuoshuoCommentList as $aShuoshuoComment){
					$aShuoshuoCommentIds[] = $aShuoshuoComment['id'];
				}
				$where = '(' . $where . ')' . ' OR (`data_id` in (' . implode(',', $aShuoshuoCommentIds) . ') AND `type` in (' . $this->_aPesonalType['comment'] . ',' . $this->_aPesonalType['reply_comment']  .'))';
			}
			$row = $oDboi->table(T_PERSONAL_MESSAGE)->where($where)->delete();
			if($row === false){
				$oDboi->rollBack();
				return false;
			}
		}
		return $result;
	}

	//删除说说评论
	public function deleteShuoshuoComment($commentId){
		$oComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		//删除通知
		$aCommentList = $oComment->get('', '`parent_id`=' . $commentId);
		if($aCommentList === false){
			return false;
		}
		$aCommentIds = array();
		foreach($aCommentList as $aComment){
			$aCommentIds[] = $aComment['id'];
		}
		$aCommentIds[] = $commentId;
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		$where = '`data_id` in (' . implode(',', $aCommentIds) . ') AND `type` in (' . $this->_aPesonalType['comment'] . ',' . $this->_aPesonalType['reply_comment']  .')';
		$oPersonalMessage->delete($where);
		//$oPersonalMessageBak = new Model(T_PERSONAL_MESSAGE_BAK);
		//$oPersonalMessageBak->delete($where);
		return $oComment->delete('`id`=' . $commentId . ' OR `parent_id`=' . $commentId);
	}

	//@时写通知
	public function aitPersonalMesssage($aUserIds, $shuoshuoId){
		$aData = array();
		foreach($aUserIds as $userId){
			$aMessageData['user_id'] = $userId;
			$aMessageData['type'] = $this->_aPesonalType['ait'];
			$aMessageData['data_id'] = $shuoshuoId;
			$aData[] = $aMessageData;
		}
		$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
		return $oPersonalMessage->add($aData);
	}

	//生日通知

	//得到可能认识的人
	public function getMyProbablyFriends($userId){
		//$aUserFriends = $this->getUserFriendInfo($userId);
		$aUserFriends = $this->getUserFriendIdList($userId);
		if($aUserFriends === false){
			return $aUserFriends;
		}
		$friendUserIds = implode(',', $aUserFriends);
		//先找出现在的同班同学--和以往的同班同学
		$oDboi = new DBOI();
		$aUserClassList = $oDboi->table(T_USER_CLASS)->where('`user_id`=' . $userId)->select();
		$classCondition = '';
		$activeGradeCondition = '';
		$gradeCondition = '';
		$aSchoolCondition = array();
		foreach($aUserClassList as $aUserClass){
			if($classCondition){
				$classCondition .= ' OR ';
			}
			$classCondition .= '(`school_id`=' . $aUserClass['school_id'] . ' AND `grade`=' . $aUserClass['grade'] . " AND `class`='" . $aUserClass['class'] . "')";
			if($aUserClass['is_active'] == self::ACTIVE_CLASS_FLAG){
				$activeGradeCondition = '`school_id`=' . $aUserClass['school_id'] . ' AND `grade`=' . $aUserClass['grade'] . ' AND `is_active`=' . self::ACTIVE_CLASS_FLAG;
			}else{
				if($gradeCondition){
					$gradeCondition .= ' OR ';
				}
				$gradeCondition .= '(`school_id`=' . $aUserClass['school_id'] . ' AND `grade`=' . $aUserClass['grade'] . ')';
			}
			$aSchoolCondition[] = $aUserClass['school_id'];
		}
		$probablyUserIds = '';
		$specialUserIds = $userId;
		//排除我申请了的好友
		$aUserRelationList = $oDboi->table(T_USER_RELATION)->fields('`user_slave_id`')->where('`is_handed`!=1 AND `user_master_id`=' . $userId)->select();
		if($aUserRelationList === false){
			return false;
		}elseif($aUserRelationList){
			$aUserApplyUserIds = array();
			foreach($aUserRelationList as $aUserRelation){
				$aUserApplyUserIds[] = $aUserRelation['user_slave_id'];
			}
			$specialUserIds .= ',' . implode(',', $aUserApplyUserIds);
		}
		if($friendUserIds){
			$specialUserIds .= ',' . $friendUserIds;
		}
		if($classCondition){
			$where = '';
			$where = '`user_id` not in (' . $specialUserIds . ')';
			$where .= ' AND (' . $classCondition . ')';
			$aUserList = $oDboi->fields('`user_id`')->table(T_USER_CLASS)->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$aUserIds = array_unique($aUserIds);
				foreach($aUserIds as $oneUserId){
					$probablyUserIds .= $oneUserId . ',';
				}
				if($probablyUserIds){
					$probablyUserIds = substr($probablyUserIds, 0, -1);
				}
				$sameClassUserCount = count($aUserIds);
				if($sameClassUserCount >= self::PROBABLY_FRIEND_COUNT){
					array_slice($aUserIds, 0, self::PROBABLY_FRIEND_COUNT);
					return $probablyUserIds;
				}
			}
		}

		//再找出目前同校同年级的同学
		if($activeGradeCondition){
			$where = '';
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			$where = '`user_id` not in (' . $exceptUserIds . ')';
			$where .= ' AND ' . $activeGradeCondition;
			$aUserList = $oDboi->fields('`user_id`')->table(T_USER_CLASS)->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$sameActiveGradeUserCount = count($aUserList);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $sameActiveGradeUserCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $sameActiveGradeUserCount;
				}
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserList[$i])){
						$probablyUserIds .= $aUserList[$i]['user_id'] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $sameActiveGradeUserCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}

		//再找出以前同年级的人
		if($gradeCondition){
			$where = '';
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			$where = '`user_id` not in (' . $exceptUserIds . ')';
			if($where){
				$where .= ' AND ';
			}
			$where .= '(' . $gradeCondition . ')';
			$aUserList = $oDboi->fields('`user_id`')->table(T_USER_CLASS)->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$aUserIds = array_unique($aUserIds);
				$sameGradeUserCount = count($aUserIds);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $sameGradeUserCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $sameGradeUserCount;
				}
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserIds[$i])){
						$probablyUserIds .= $aUserIds[$i] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $sameGradeUserCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}

		//找出有共同好友的人
		if($friendUserIds){
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			if(count($aUserFriends) > 50){
				$aKeys = array_rand($aUserFriends, 50);
				$aRandFriendIds = array();
				foreach($aKeys as $key){
					$aRandFriendIds[] = $aUserFriends[$key];
				}
				$randFiendIds = implode(',', $aRandFriendIds);
			}else{
				$randFiendIds = $friendUserIds;
			}
			$where = '`user_master_id` in (' . $randFiendIds . ') AND `user_slave_id` not in (' . $exceptUserIds . ') AND `is_handed`=1';
			$aSlaveUserList = $oDboi->fields('`user_slave_id` as `user_id`')->table(T_USER_RELATION)->where($where)->select();
			if($aSlaveUserList === false){
				return false;
			}
			$where = '`user_slave_id` in (' . $randFiendIds . ') AND `user_master_id` not in (' . $exceptUserIds . ') AND `is_handed`=1';
			$aMasterUserList = $oDboi->fields('`user_master_id` as `user_id`')->table(T_USER_RELATION)->where($where)->select();
			if($aMasterUserList === false){
				return false;
			}
			if($aSlaveUserList || $aMasterUserList){
				$aUserList = array_merge($aSlaveUserList, $aMasterUserList);
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$aUserIds = array_unique($aUserIds);
				$commonFriendsCount = count($aUserIds);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $commonFriendsCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $commonFriendsCount;
				}
				sort($aUserIds);
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserIds[$i])){
						$probablyUserIds .= $aUserIds[$i] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $commonFriendsCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}

		//再找出同校过的人
		if($aSchoolCondition){
			$where = '';
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			$where = '`user_id` not in (' . $exceptUserIds . ')';
			$aSchoolCondition = array_unique($aSchoolCondition);
			$where .= ' AND `school_id` in (' . implode(',', $aSchoolCondition) . ')';
			$aUserList = $oDboi->fields('`user_id`')->table(T_USER_CLASS)->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$aUserIds = array_unique($aUserIds);
				$sameSchoolUserCount = count($aUserIds);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $sameSchoolUserCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $sameSchoolUserCount;
				}
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserIds[$i])){
						$probablyUserIds .= $aUserIds[$i] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $sameSchoolUserCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}

		//同区
		$aClassInfo = $oDboi->table(T_USER_CLASS)->where('`is_active` = 1 AND `user_id` = ' . $userId)->select();
		if(!$aClassInfo){
			return false;
		}
		$aClassInfo = $aClassInfo[0];
		if($aClassInfo['area_id']){
			$where = '';
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			$where = '`is_active` = 1 AND `area_id`=' . $aClassInfo['area_id'] . ' AND `user_id` not in (' . $exceptUserIds . ')';
			$aUserList = $oDboi->table(T_USER_CLASS)->fields('`user_id`')->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$sameAreaUserCount = count($aUserIds);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $sameAreaUserCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $sameAreaUserCount;
				}
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserIds[$i])){
						$probablyUserIds .= $aUserIds[$i] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $sameAreaUserCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}
		//找同城
		if($aClassInfo['city_id']){
			$where = '';
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			$where = '`is_active` = 1 AND `city_id`=' . $aClassInfo['city_id'] . ' AND `user_id` not in (' . $exceptUserIds . ')';
			$aUserList = $oDboi->table(T_USER_CLASS)->fields('`user_id`')->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$sameCityUserCount = count($aUserIds);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $sameCityUserCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $sameCityUserCount;
				}
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserIds[$i])){
						$probablyUserIds .= $aUserIds[$i] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $sameCityUserCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}
		//同省
		if($aClassInfo['province_id']){
			$where = '';
			$exceptUserIds = $specialUserIds;
			if($probablyUserIds){
				$exceptUserIds .= ',' . $probablyUserIds;
			}
			$where = '`is_active` = 1 AND `province_id`=' . $aClassInfo['province_id'] . ' AND `user_id` not in (' . $exceptUserIds . ')';
			$aUserList = $oDboi->table(T_USER_CLASS)->fields('`user_id`')->where($where)->orderby('id desc')->select();
			if($aUserList === false){
				return false;
			}elseif($aUserList){
				$aUserIds = array();
				foreach($aUserList as $aUser){
					$aUserIds[] = $aUser['user_id'];
				}
				$sameProvinceUserCount = count($aUserIds);
				if($probablyUserIds){
					$probablyUserIds .= ',';
				}
				$userCount = substr_count($probablyUserIds, ',');
				if($userCount + $sameProvinceUserCount >= self::PROBABLY_FRIEND_COUNT){
					$maxCount = self::PROBABLY_FRIEND_COUNT - $userCount;
				}else{
					$maxCount = $sameProvinceUserCount;
				}
				for($i = 0; $i < $maxCount; $i++){
					if(isset($aUserIds[$i])){
						$probablyUserIds .= $aUserIds[$i] . ',';
					}
				}
				$probablyUserIds = substr($probablyUserIds, 0, -1);
				if($userCount + $sameProvinceUserCount >= self::PROBABLY_FRIEND_COUNT){
					return $probablyUserIds;
				}
			}
		}
		//全国
		$exceptUserIds = $specialUserIds;
		if($probablyUserIds){
			$exceptUserIds .= ',' . $probablyUserIds;
		}
		$userCount = substr_count($probablyUserIds, ',');
		$needCount = self::PROBABLY_FRIEND_COUNT - $userCount;
		$where = '`id` not in (' . $exceptUserIds . ') ';
		$aUserList = $oDboi->table(T_USER)->fields('`id`')->where($where)->orderby('id desc')->limit(0, $needCount)->select();
		if($aUserList === false){
			return false;
		}elseif($aUserList){
			if($probablyUserIds){
				$probablyUserIds = $probablyUserIds . ',';
			}
			foreach($aUserList as $aUser){
				$probablyUserIds .= $aUser['id'] . ',';
			}
			$probablyUserIds = substr($probablyUserIds, 0, -1);
		}

		return $this->filterEmptyUserName(explode(',', $probablyUserIds));
	}

	public function getMissionEventList($userId = 0, $page = 0, $pageSize = 10){
		if($userId){
			$friendIds = $this->getUserFriendIds($userId);
			if($friendIds === false){
				return false;
			}elseif(!$friendIds){
				return array();
			}
			$where = '`user_id` in (' . $friendIds . ') AND `type` in (' . $this->_aSnsEvent['finish_task'] . ',' . $this->_aSnsEvent['pass_mission'] . ')';
		}else{
			$where = '`type` in (' . $this->_aSnsEvent['finish_task'] . ',' . $this->_aSnsEvent['pass_mission'] . ')';
		}
		$offect = ($page - 1) * $pageSize;
		$oEvent = new Model(T_SNS_EVENT);
		$aEventList = $oEvent->get('', $where, '`id` desc', $offect, $pageSize);
		if($aEventList){
			$aUserMissionIds = array();
			foreach($aEventList as $aEvent){
				$aUserMissionIds[] = $aEvent['data_id'];
			}
			$aUserMissionIds = array_unique($aUserMissionIds);
			$aUserMissionList = $this->_getUserMissionList($aUserMissionIds);
			foreach($aEventList as &$aEvent){
				foreach($aUserMissionList as $aUserMission){
					if($aEvent['data_id'] == $aUserMission['id']){
						$aEvent['data'] = $aUserMission;
					}
				}
			}
		}
		return $aEventList;
	}

	private function _getUserMissionList($aUserMissionIds){
		$oMissionUserIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserMissionList = $oMissionUserIndex->get('', array('id' => array('in', $aUserMissionIds)));
		if($aUserMissionList){
			foreach($aUserMissionList as $aUserMission){
				$aMissionIds[] = $aUserMission['mission_id'];
				$aUserIds[] = $aUserMission['user_id'];
			}
			$oMission = new Model(T_MISSION);
			$aMissionList = $oMission->get('', array('id' => array('in', $aMissionIds)));
			if($aMissionList === false){
				return false;
			}
			$oUser = new Model(T_PERSONAL);
			$aUserList = $oUser->get('', array('id' => array('in', $aUserIds)));
			if($aUserList === false){
				return false;
			}
			//组装返回数据
			$aReturnData = array();
			foreach($aUserMissionList as $aUserMission){
				$aData = array();
				$aData['id'] = $aUserMission['id'];
				$aData['mission_id'] = $aUserMission['mission_id'];
				$aData['user_id'] = $aUserMission['user_id'];
				$aData['task_finish_time'] = date('Y-m-d H:i:s', $aUserMission['task_finish_time']);
				$aData['pass_time'] = date('Y-m-d H:i:s', $aUserMission['pass_time']);
				$aData['mission_name'] = '关卡不存在';
				foreach($aMissionList as $aMission){
					if($aMission['id'] == $aUserMission['mission_id']){
						$aData['mission_name'] = $aMission['name'];
					}
				}
				foreach($aUserList as $aUser){
					if($aUser['id'] == $aUserMission['user_id']){
						$aData['user_name'] = $aUser['name'];
					}
				}
				$aReturnData[] = $aData;
			}
			return $aReturnData;
		}
		return $aUserMissionList;
	}

	public function cheakProbablyFriends($userId){
		$aUserFriendsInfo = $this->getUserFriendInfo($userId);
		if($aUserFriendsInfo === false){
			return false;
		}elseif(!$aUserFriendsInfo){
			$probablyFriends = $this->getMyProbablyFriends($userId);
			if(!$probablyFriends){
				$probablyFriends = '';
			}
			$aData = array();
			$aData['id'] = $userId;
			$aData['probably'] = $probablyFriends;
			$aData['probably_calc_time'] = time();
			return $this->addUserFriend($aData);
		}else{
			$probablyFriendsCount = substr_count($aUserFriendsInfo['probably'], ',');
			if($probablyFriendsCount < self::PROBABLY_FRIEND_LIMIT_COUNT || time() - $aUserFriendsInfo['probably_calc_time'] > self::PROBABLY_FRIEND_LIMIT_TIME){
				$probablyFriends = $this->getMyProbablyFriends($userId);
				if(!$probablyFriends){
					$probablyFriends = '';
				}
				$aData = array();
				$aData['id'] = $userId;
				$aData['probably'] = $probablyFriends;
				$aData['probably_calc_time'] = time();
				return $this->setUserFriend($aData);
			}
		}
	}

	public function getUserFriendsIdList($userId, $groupId = 0){
		$aUserFriendsInfo = $this->getUserFriendInfo($userId);
		if(!$aUserFriendsInfo){
			return $aUserFriendsInfo;
		}
		if($groupId){
			if(isset($aUserFriendsInfo['friends'][$groupId])){
				if($aUserFriendsInfo['friends'][$groupId]){
					return explode(',', $aUserFriendsInfo['friends'][$groupId]);
				}else{
					return array();
				}
			}else{
				return array();
			}
		}else{
			$aUserIdList = array();
			foreach($aUserFriendsInfo['friends'] as $groupFriends){
				if($groupFriends){
					$aGroupFriends = explode(',', $groupFriends);
					$aUserIdList = array_merge($aUserIdList, $aGroupFriends);
				}
			}
			return $aUserIdList;
		}
	}

	/*--------------------------------2014/1/9林云龙添加以下方法--------------------------------------------*/
	//根据评论Id获取一条评论
	public function getShuoShuoCommentByCommentId($commentId){
		if(!$commentId){
			return false;
		}
		$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aShuoshuoComment = $oShuoshuoComment->get('',array('id'=>$commentId));
		if(!$aShuoshuoComment){
			return $aShuoshuoComment;
		}else{
			return $aShuoshuoComment[0];
		}
	}

	//根据说说Id获取说说的全部评论
	public function getAllShuoShuoComment($shuoshuoId){
		if(!$shuoshuoId){
			return false;
		}
		$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aShuoshuoCommentList = $oShuoshuoComment->get('','shuoshuo_id='.$shuoshuoId,'id ASC');
		if(!$aShuoshuoCommentList){
			return $aShuoshuoCommentList;
		}

		$aCommentRefer = array();
		foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
			$aCommentRefer[$aShuoshuoComment['id']] = &$aShuoshuoCommentList[$key];
		}

		//组装评论结构
		$aCommentTree = array();
		if($aShuoshuoCommentList){
			foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
				//没有回复信息
				if(!$aShuoshuoComment['parent_id']){
					$aShuoshuoCommentList[$key]['reply'] = array();
					$aCommentTree[] = &$aShuoshuoCommentList[$key];
				}else{
					//回复评论信息组装结构
					$parentId = $aShuoshuoComment['parent_id'];
					if(isset($aCommentRefer[$parentId])){
						$aParent = &$aCommentRefer[$parentId];
						$aParent['reply'][] = &$aShuoshuoCommentList[$key];
					}
				}
			}
		}

		//限制回复数量
		foreach($aCommentTree as $key=>$aComment){
			if($aComment['reply']){
				$aCommentTree[$key]['reply_count'] = count($aComment['reply']);
				if($aCommentTree[$key]['reply_count'] > self::REPLY_COUNT){
					$length = $aCommentTree[$key]['reply_count'] - self::REPLY_COUNT;
					array_splice($aCommentTree[$key]['reply'],0,$length);
				}
			}else{
				$aCommentTree[$key]['reply_count'] = 0;
				continue;
			}
		}
		unset($aShuoshuoCommentList);
		return $aCommentTree;
	}

	//根据评论id获取说说评论的全部回复
	public function getAllShuoshuoCommentReply($commentId){
		if(!$commentId){
			return false;
		}
		$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aShuoshuoCommentReplyList = $oShuoshuoComment->get('','parent_id='.$commentId,'id ASC');
		return $aShuoshuoCommentReplyList;
	}

	//根据留言id获取全部留言信息
	public function getAllPublicMessage($publicMessageId){
		if(!$publicMessageId){
			return false;
		}
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		$aPublicMessageList = $oPublicMessage -> get('','parent_id='.$publicMessageId,'id ASC');
		return $aPublicMessageList;
	}

	//======================================好友20140109================================
	//查看好友申请
	public function getApplyFriendList($userId, $page, $pageSize){
		$oUserRelation = new Model(T_USER_RELATION);
		$offect = ($page - 1) * $pageSize;
		$aApplyFriendList = $oUserRelation->get('`id`,`user_master_id`,`create_time`,`confirm_message`', '`user_slave_id`=' . $userId . ' AND `is_handed`!=1', '`create_time` DESC', $offect, $pageSize);
		if($aApplyFriendList){
			$aUserIds = array();
			foreach($aApplyFriendList as $aApplyFriend){
				$aUserIds[] = $aApplyFriend['user_master_id'];
			}
			$aUserList = getUserListByUserIds($aUserIds, array('area', 'class', 'numerical'));
			foreach($aApplyFriendList as &$aApplyFriend){
				foreach($aUserList as $aUser){
					if($aApplyFriend['user_master_id'] == $aUser['id']){
						$aApplyFriend['user_master_info'] = $aUser;
					}
				}
			}
		}
		return $aApplyFriendList;
	}

	//有没有好友申请
	public function getApplyFriendCount($userId){
		$oUserRelation = new Model(T_USER_RELATION);
		return $oUserRelation->count('`user_slave_id`=' . $userId . ' AND `is_handed`!=1');
	}

	//查看同意我的好友
	public function getAgreeUserApplyFriendList($userId, $page, $pageSize){
		$oUserRelation = new Model(T_USER_RELATION);
		$offect = ($page - 1) * $pageSize;
		$aUserRelationList = $oUserRelation->get('`user_slave_id`', '`is_handed`=1 AND `user_master_id`=' . $userId, '`create_time` DESC', $offect, $pageSize);
		if(!$aUserRelationList){
			return $aUserRelationList;
		}
		$aUserIds = array();
		foreach($aUserRelationList as $aUserRelation){
			$aUserIds[] = $aUserRelation['user_slave_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds, array('area', 'class'));
		$aUserFriendInfo = $this->_getUserFriendInfo($userId, 1);
		foreach($aUserList as &$aUser){
			foreach($aUserFriendInfo['friends'] as $groupId => $aGoupUserIds){
				if(in_array($aUser['id'], $aGoupUserIds)){
					$aUser['group_id'] = $groupId;
					break;
				}
			}
		}
		return $aUserList;
	}

	//请求加好友
	public function applyFriend($aData){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//删除旧的申请
		$where = '`user_master_id`=' . $aData['user_master_id'] . ' AND `user_slave_id`=' . $aData['user_slave_id'];
		$result = $oDboi->table(T_USER_RELATION)->where($where)->delete();
		if($result === false){
			return false;
		}
		//添加一条请求消息
		$result = $oDboi->table(T_USER_RELATION)->data($aData)->insert();
		if(!$result){
			$oDboi->rollBack();
		}
		//从申请人的可能认识的人列表中移除
		$aUserFriendInfo = $this->_getUserFriendInfo($aData['user_master_id'], 2);
		if($aUserFriendInfo === false){
			return false;
		}
		$aKey = array_keys($aUserFriendInfo['probably'], $aData['user_slave_id']);
		if($aKey){
			unset($aUserFriendInfo['probably'][$aKey[0]]);
			if(count($aUserFriendInfo['probably']) < self::PROBABLY_FRIEND_LIMIT_COUNT){
				//从新计算可能认识的人
				$this->cheakProbablyFriends($aData['user_master_id']);
			}else{
				$aUpdateData['probably'] = implode(',', $aUserFriendInfo['probably']);
				$oDboi->table(T_USER_FRIEND)->where(array('id' => $aData['user_master_id']))->data($aUpdateData)->update();
			}
		}
		return $result;
	}

	//同意好友请求
	public function agreeFriendApply($userId, $friendUserId, $groupId = -1){
		$oDboi = new DBOI();
		$oDboi->startTrans();
		$currentTime = time();
		$where = '`user_master_id`=' . $friendUserId . ' AND `user_slave_id`=' . $userId;
		$result = $oDboi->table(T_USER_RELATION)->where($where)->data(array('is_handed' => 1, 'create_time' => $currentTime))->update();
		if($result){
			//给自己加上好友
			$aUserFriendInfo = $this->_getUserFriendInfo($userId);
			if(!$aUserFriendInfo){
				$oDboi->rollBack();
				return false;
			}
			$aUserFriendInfo['friends'][$groupId][] = $friendUserId;
			foreach($aUserFriendInfo['friends'] as $grouKey => $aGroupUserIds){
				$aUserFriendInfo['friends'][$grouKey] = implode(',', $aGroupUserIds);
			}
			$aUpdateData = array();
			$aUpdateData['friends'] = json_encode($aUserFriendInfo['friends']);
			//是否在可能认识的人里面
			$key = array_search($friendUserId, $aUserFriendInfo['probably']);
			if($key !== false){
				unset($aUserFriendInfo['probably'][$key]);
				$aUpdateData['probably'] = implode(',', $aUserFriendInfo['probably']);
			}
			$row = $oDboi->table(T_USER_FRIEND)->where(array('id' => $userId))->data($aUpdateData)->update();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}

			//给对方加上好友
			$aUserFriendInfo = $this->_getUserFriendInfo($friendUserId);
			if(!$aUserFriendInfo){
				$oDboi->rollBack();
				return false;
			}
			$aUserFriendInfo['friends'][-1][] = $userId;
			foreach($aUserFriendInfo['friends'] as $grouKey => $aGroupUserIds){
				$aUserFriendInfo['friends'][$grouKey] = implode(',', $aGroupUserIds);
			}
			$aUpdateData = array();
			$aUpdateData['friends'] = json_encode($aUserFriendInfo['friends']);
			//是否在可能认识的人里面
			$key = array_search($userId, $aUserFriendInfo['probably']);
			if($key !== false){
				unset($aUserFriendInfo['probably'][$key]);
				$aUpdateData['probably'] = implode(',', $aUserFriendInfo['probably']);
			}
			$row = $oDboi->table(T_USER_FRIEND)->where(array('id' => $friendUserId))->data($aUpdateData)->update();
			if(!$row){
				$oDboi->rollBack();
				return false;
			}

			//删除旧的加好友动态
			$where = '`user_id` in (' . $userId . ',' . $friendUserId . ') AND `type`=' . $this->_aSnsEvent['become_friends'];
			$oDboi->table(T_SNS_EVENT)->where($where)->delete();

			//写用户的好友动态
			/*$aEvent1['user_id'] = $userId;
			$aEvent1['type'] = $this->_aSnsEvent['become_friends'];
			$aEvent1['data_id'] = $currentTime;
			$aEvent2['user_id'] = $friendUserId;
			$aEvent2['type'] = $this->_aSnsEvent['become_friends'];
			$aEvent2['data_id'] = $currentTime;
			$oDboi->table(T_SNS_EVENT)->data(array($aEvent1, $aEvent2))->insert();*/
			//新版写用户的好友动态事件
			$aEventData1 = array(
				'user_id'	=>	$userId,
				'type'		=> 37,
				'data_id'	=>	0,
				'data'		=>	array(
					'friend_user_id' => $friendUserId,
					'create_time' => time()
				)
			);
			$aEventData2 = array(
				'user_id'	=>	$friendUserId,
				'type'		=> 37,
				'data_id'	=>	0,
				'data'		=>	array(
					'friend_user_id' => $userId,
					'create_time' => time()
				)
			);
			$oSnsEvent = m('SnsEvent');
			$oSnsEvent->addEvent($aEventData1);
			$oSnsEvent->addEvent($aEventData2);

			//给申请人新好友标记加1
			$oDboi->table(T_PERSONAL)->where(array('id' => $friendUserId))->data(array('new_friend_flag' => array('add', 1)))->update();
		}
		return $result;
	}

	//和一批人成为好友-------------注册流程用到
	public function autoBecomeFriendWithUsers($userId, $aBeFriendUserIds){
		if(!is_array($aBeFriendUserIds)){
			return false;
		}
		if(!$aBeFriendUserIds){
			return 0;
		}
		$oDboi = new DBOI();
		$oDboi->startTrans();
		//给用户自己加上好友
		$aUserFriendData = array(
			'id'	=>	$userId,
			'friends'	=> array(
				'-1'	=> $aBeFriendUserIds
			),
			'probably'	=>	array(),
			'probably_calc_time'	=>	0
		);
		$aUserFriendData = $this->_parseNormalDataToDbForUserFriend(array($aUserFriendData));
		$aUserFriendData = $aUserFriendData[0];
		$result = $oDboi->table(T_USER_FRIEND)->data($aUserFriendData)->insert();
		if(!$result){
			return $result;
		}
		//分别给好友加上自己
		$aUserFriendList = $oDboi->fields('`id`,`friends`')->table(T_USER_FRIEND)->where(array('id' => array('in', $aBeFriendUserIds)))->select();	//查出好友目前的好友
		if(!$aUserFriendList){
			$oDboi->rollBack();
			return false;
		}
		$aUserFriendList = $this->_parseDbDataToNormalForUserFriend($aUserFriendList);
		foreach($aUserFriendList as $key => $aUserFriend){
			$aUserFriendList[$key]['friends']['-1'][] = $userId;
		}
		$aUserFriendList = $this->_parseNormalDataToDbForUserFriend($aUserFriendList);
		foreach($aUserFriendList as $key => $aUserFriend){
			$result = $oDboi->table(T_USER_FRIEND)->where(array('id' => $aUserFriend['id']))->data($aUserFriend)->update();
			if(!$result){
				$oDboi->rollBack();
				return false;
			}
		}
		//在好友关系表建立关系
		$aUserRelationList = array();
		foreach($aUserFriendList as $aUserFriend){
			$aUserRelation = array();
			$aUserRelation['user_master_id'] = $userId;
			$aUserRelation['user_slave_id'] = $aUserFriend['id'];
			$aUserRelation['is_handed'] = 1;
			$aUserRelation['create_time'] = time();
			$aUserRelation['confirm_message'] = '';
			$aUserRelationList[] = $aUserRelation;
		}
		$result = $oDboi->table(T_USER_RELATION)->data($aUserRelationList)->insert();
		if(!$result){
			$oDboi->rollBack();
			return false;
		}
		return true;
	}

	private function _parseDbDataToNormalForUserFriend($aUserFriendList){
		foreach($aUserFriendList as $key => $aUserFriend){
			if(isset($aUserFriend['friends'])){
				$aGroupFriendList = json_decode($aUserFriend['friends'], true);
				foreach($aGroupFriendList as $groupId => $groupFriends){
					if($groupFriends){
						$aGroupFriendList[$groupId] = explode(',', $groupFriends);
					}else{
						$aGroupFriendList[$groupId] = array();
					}
				}
				$aUserFriendList[$key]['friends'] = $aGroupFriendList;
			}
			if(isset($aUserFriend['probably'])){
				if($aUserFriend['probably']){
					$memory = Debug::getUseMemory('login_children_start', 'here');
					if(268435456 - $memory > 40960){
						$aUserFriendList[$key]['probably'] = explode(',', $aUserFriend['probably']);
					}else{
						$aUserFriendList[$key]['probably'] = array();
					}
				}else{
					$aUserFriendList[$key]['probably'] = array();
				}
			}
		}
		return $aUserFriendList;
	}

	private function _parseNormalDataToDbForUserFriend($aUserFriendList){
		foreach($aUserFriendList as $key => $aUserFriend){
			if(isset($aUserFriend['friends'])){
				$aGroupFriendList = $aUserFriend['friends'];
				foreach($aGroupFriendList as $groupId => $aGroupFriends){
					$aGroupFriendList[$groupId] = implode(',', $aGroupFriends);
				}
				$aUserFriendList[$key]['friends'] = json_encode($aGroupFriendList);
			}
			if(isset($aUserFriend['probably'])){
				$aUserFriendList[$key]['probably'] = implode(',', $aUserFriend['probably']);
			}
		}
		return $aUserFriendList;
	}

	//$flag	0:全部	1:好友	2：可能认识的人
	private function _getUserFriendInfo($userId, $flag = 0){
		if($flag == 1){
			$fields = '`friends`';
		}elseif($flag == 2){
			$fields = '`probably`,`probably_calc_time`';
		}else{
			$fields = '';
		}
		$oUserFriend = new Model(T_USER_FRIEND);
		$aUserFriendInfo = $oUserFriend->get($fields, array('id' => $userId));
		if($aUserFriendInfo){
			$aUserFriendInfo = $aUserFriendInfo[0];
			if(isset($aUserFriendInfo['friends'])){
				$aUserFriendInfo['friends'] = json_decode($aUserFriendInfo['friends'], true);
				foreach($aUserFriendInfo['friends'] as $key => $val){
					if($val){
						$aUserFriendInfo['friends'][$key] = explode(',', $val);
					}else{
						$aUserFriendInfo['friends'][$key] = array();
					}
				}
			}
			if(isset($aUserFriendInfo['probably'])){
				$aUserFriendInfo['probably'] = explode(',', $aUserFriendInfo['probably']);
			}
		}
		return $aUserFriendInfo;
	}

	//是否有未读的小纸条
	public function getUnreadPrivateMessageCount($userId){
		$oSnsPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$where = '`receiver_user_id`=' . $userId . ' AND `is_read`!=1 AND `status`!=2';
		return $oSnsPrivateMessage->count($where);
	}

	//未读小纸条列表
	public function getUnreadPrivateMessageList($userId, $friendId){
		$oSnsPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$where = '`sender_user_id`=' . $friendId . ' AND `receiver_user_id`=' . $userId . ' AND `is_read`!=1';
		$aOldestUnreadMessageInfo = $oSnsPrivateMessage->get('`id`', $where, '`id` ASC', 0, 1);
		if(!$aOldestUnreadMessageInfo){
			return $aOldestUnreadMessageInfo;
		}
		$where = '`id`>=' . $aOldestUnreadMessageInfo[0]['id'] . ' AND ((`sender_user_id`=' . $friendId . ' AND `status`!=2 AND `receiver_user_id`=' . $userId . ') OR (`sender_user_id`=' . $userId . ' AND `status`!=1 AND `receiver_user_id`=' . $friendId . '))';
		$aUnreadMessageList = $oSnsPrivateMessage->get('', $where, '`id` DESC');
		return $aUnreadMessageList;
	}

	//获取最近的留言人
	public function getLatestSendPublicMessgeUserList($userId){
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		$aPublicMessageList = $oPublicMessage->get('max(`id`) as `id`,`sender_user_id`', '`parent_id`=0 AND `user_id`=' . $userId . ' AND `sender_user_id`!=' . $userId, '`id` desc', 0, 12, '`sender_user_id`');
		if(!$aPublicMessageList){
			return $aPublicMessageList;
		}
		$aUserIds = array();
		foreach($aPublicMessageList as $aPublicMessage){
			$aUserIds[] = $aPublicMessage['sender_user_id'];
		}
		return getUserListByUserIds($aUserIds);
	}

	//留言板最近回复
	public function getLatestPublicMessgeCommentList($userId){
		$oPublicMessage = new Model(T_SNS_PUBLIC_MESSAGE);
		$aPublicMessageList = $oPublicMessage->get('`id`', '`parent_id`=0 AND `user_id`=' . $userId);
		if(!$aPublicMessageList){
			return $aPublicMessageList;
		}
		$aPublicMessageIds = array();
		foreach($aPublicMessageList as $aPublicMessage){
			$aPublicMessageIds[] = $aPublicMessage['id'];
		}
		$aPublicMessageCommentList = $oPublicMessage->get('', '`parent_id` in (' . implode(',', $aPublicMessageIds) . ')', '`create_time` DESC', 0, 9);
		if(!$aPublicMessageCommentList){
			return $aPublicMessageCommentList;
		}
		$aUserIds = array();
		foreach($aPublicMessageCommentList as $aPublicMessageComment){
			$aUserIds[] =  $aPublicMessageComment['user_id'];
			$aUserIds[] =  $aPublicMessageComment['sender_user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if($aUserList === false){
			return false;
		}
		foreach($aPublicMessageCommentList as &$aPublicMessageComment){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPublicMessageComment['user_id']){
					$aPublicMessageComment['user_info'] = $aUser;
				}
				if($aUser['id'] == $aPublicMessageComment['sender_user_id']){
					$aPublicMessageComment['sender_user_info'] = $aUser;
				}
			}
		}
		return $aPublicMessageCommentList;
	}

	//我查看好友页面时，他的好友在我可能认识的人中有谁
	public function getUserFriendInMyProbably($myUserId, $aUserFriendIds){
		$aUserFriendInfo = $this->_getUserFriendInfo($myUserId);
		if($aUserFriendInfo === false){
			return false;
		}
		$aProbablyUserIds = array_intersect($aUserFriendIds, $aUserFriendInfo['probably']);
		//如果一个都没有的话，则任意展示4个
		if(!$aProbablyUserIds){
			$aMyFriendIds = array();
			foreach($aUserFriendInfo['friends'] as $aGoupUserIds){
				$aMyFriendIds = array_merge($aMyFriendIds, $aGoupUserIds);
			}
			$aMyFriendIds[] = $myUserId;
			//取ta的好友和我的好友(包括我)的差集
			$aProbablyUserIdList = array_diff($aUserFriendIds, $aMyFriendIds);
			//在差集中任意取4个
			if(count($aProbablyUserIdList) <= 4){
				$aProbablyUserIds = $aProbablyUserIdList;
			}else{
				$aUserIdKeys = array_rand($aProbablyUserIdList, 4);
				foreach($aUserIdKeys as $key){
					$aProbablyUserIds[] = $aProbablyUserIdList[$key];
				}
			}
		}
		if($aProbablyUserIds){
			if(count($aProbablyUserIds) > 20){
				$aProbablyUserIds = array_slice($aProbablyUserIds, 0, 20);
			}
			return getUserListByUserIds($aProbablyUserIds);
		}else{
			return array();
		}
	}

	//查找我的小纸条最近的回复wo的
	public function getLatestReplyPrivateMessageList($userId, $page, $pageSize){
		$oPrivateMessage = new Model(T_SNS_PRIVATE_MESSAGE);
		$offect = ($page - 1) * $pageSize;
		$aPrivateMessageList = $oPrivateMessage->get('`id`,`sender_user_id`,`content`,`create_time`', '`status`!=2 AND `receiver_user_id`=' . $userId, '`create_time` DESC', $offect, $pageSize);
		if(!$aPrivateMessageList){
			return $aPrivateMessageList;
		}
		$aUserIds = array();
		foreach($aPrivateMessageList as $aPrivateMessage){
			$aUserIds[] = $aPrivateMessage['sender_user_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aPrivateMessageList as &$aPrivateMessage){
			$aPrivateMessage['sender_user_info'] = array();
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aPrivateMessage['sender_user_id']){
					$aPrivateMessage['sender_user_info'] = $aUser;
					break;
				}
			}
		}
		return $aPrivateMessageList;
	}

	public function getUserShuoshuoCount($userId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		return $oShuoshuo->count('`user_id`=' . $userId);
	}

	//过滤掉用户名为空的用户----林云龙
	private function filterEmptyUserName($aUserIds = array()){
		if(!$aUserIds){
			return $aUserIds;
		}
		$oPersonal = new Model(T_PERSONAL);
		$aPersonalList = $oPersonal->get('`id`,`name`',array('id'=>array('in', $aUserIds)));
		if($aPersonalList === false){
			return false;
		}elseif(!$aPersonalList){
			return $aUserIds;
		}

		foreach($aPersonalList as $aPersonal){
			if(!$aPersonal['name']){
				foreach($aUserIds as $key=>$aUser){
					if($aPersonal['id'] == $aUser){
						unset($aUserIds[$key]);
						break;
					}
				}
			}
		}
		unset($aPersonalList);
		return implode(',', $aUserIds);
	}
}