<?php
/**
 * 后台用户模型
 */
class NoticeModel{
	/*
	 * 添加数据来源统计信息
	 */
	public function addPushInfoSourceCount($aData){
		$oSourceInfo = new Model(T_PUSH_INFO_SOURCE_COUNT);
		return $oSourceInfo->add($aData);
	}

}