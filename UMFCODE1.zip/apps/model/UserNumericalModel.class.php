<?php
/*
 * 前台用户模型
 */
class UserNumericalModel{
	public function addUserNumerical($aData){
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		return $oUserNumerical->add($aData);
	}

	public function setUserNumerical($aData){
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		return $oUserNumerical->update($aData, array('id' => $aData['id']));
	}

	public function getUserNumericalInfoById($id){
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		$aUserNumericalInfo = $oUserNumerical->get('', array('id' => $id));
		if($aUserNumericalInfo){
			if($aUserNumericalInfo[0]['vip_expiration_time'] < time()){
				$aUserNumericalInfo[0]['vip'] = 0;
			}
			return $aUserNumericalInfo[0];
		}
		return $aUserNumericalInfo;
	}

	public function getUserNumericalRankingList($page = 1, $pageSize = 10, $aPointUserIds = array(), $order = '`accumulate_points` desc'){
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if($aPointUserIds){
			$where = '`id` in (' . implode(',', $aPointUserIds) . ')';
		}
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		$aUserNumericalList = $oUserNumerical->get('', $where, $order, $offect, $pageSize);
		if(!$aUserNumericalList){
			return $aUserNumericalList;
		}
		$aUserIds = array();
		foreach($aUserNumericalList as $aUserNumerical){
			$aUserIds[] = $aUserNumerical['id'];
		}
		$aUserList = $this->_getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		$aReturnData = array();
		foreach($aUserNumericalList as $aUserNumerical){
			$aData = array();
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aUserNumerical['id']){
					$aData['id'] = $aUser['id'];
					$aData['name'] = $aUser['name'];
					$aData['profile'] = $aUser['profile'];
					$aData['vip'] = $aUser['vip'];
					$aData['accumulate_points'] = $aUserNumerical['accumulate_points'];
					$aData['gold'] = $aUserNumerical['gold'];
				}
			}
			$aReturnData[] = $aData;
		}
		return $aReturnData;
	}

	private function _getUserListByUserIds($aUserIds){
		return getUserListByUserIds($aUserIds);
	}

	public function getDefeatedPercent($accumulatePoints){
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		//总人数
		$allCount = $oUserNumerical->count('');
		//比特定积分高的人数
		$where = '`accumulate_points`>' . $accumulatePoints;
		$higherCount = $oUserNumerical->count($where);
		//击败的百分比
		return round((1 - $higherCount/$allCount) * 100);
	}

	public function getTopAccumulatePointsUserListByUserIds($aUserIds, $order = '`accumulate_points` desc'){
		$oUserNumerical = new Model(T_USER_NUMERICAL);
		$where = '`id` in (' . implode(',', $aUserIds) . ')';
		$aUserAccumulatePointsList = $oUserNumerical->get('', $where, $order);
		if(!$aUserAccumulatePointsList){
			return $aUserAccumulatePointsList;
		}
		$aUserList = $this->_getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		$aReturnData = array();
		foreach($aUserAccumulatePointsList as $aUserAccumulatePoints){
			$aData = $aUserAccumulatePoints;
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aData['id']){
					$aData['user_info'] = $aUser;
				}
			}
			$aReturnData[] = $aData;
		}
		return $aReturnData;
	}

	public function addMedal($aData){
		if(isset($aData['medal_process'])){
			$aData['medal_process'] = json_encode($aData['medal_process']);
		}else{
			$aData['medal_process'] = json_encode(array());
		}
		$oMedal = new Model(T_MEDAL);
		return $oMedal->add($aData);
	}

	public function setMedal($aData){
		if(isset($aData['medal_process'])){
			$aData['medal_process'] = json_encode($aData['medal_process']);
		}
		$oMedal = new Model(T_MEDAL);
		return $oMedal->update($aData, array('id' => $aData['id']));
	}

	public function getMedalInfoById($medalId){
		$oMedal = new Model(T_MEDAL);
		$aMedalInfo = $oMedal->get('', array('id' => $medalId));
		if($aMedalInfo){
			$aMedalInfo = $aMedalInfo[0];
			$aMedalInfo['medal_process'] = json_decode($aMedalInfo['medal_process'], true);
		}
		return $aMedalInfo;
	}

	public function getMedalListByUserIds($aUserIds){
		$oMedal = new Model(T_MEDAL);
		$aMedalList = $oMedal->get('', array('id' => array('in', $aUserIds)));
		if($aMedalList){
			$aUserList = $this->_getUserListByUserIds($aUserIds);
			if(!$aUserList){
				return $aUserList;
			}
			foreach($aMedalList as &$aMedal){
				$aMedal['medal_process'] = json_decode($aMedal['medal_process'], true);
				foreach($aUserList as $aUser){
					if($aMedal['id'] == $aUser['id']){
						$aMedal['user_info'] = $aUser;
					}
				}
			}
		}
		return $aMedalList;
	}

	public function getMedalOrderList($aMedalList, $orderKey){
		$count = count($aMedalList);
		for($i = 0; $i < $count - 1; $i++){
			for($j = $i + 1; $j < $count; $j++){
				if($aMedalList[$i][$orderKey] < $aMedalList[$j][$orderKey]){
					$aTemp = $aMedalList[$i];
					$aMedalList[$i] = $aMedalList[$j];
					$aMedalList[$j] = $aTemp;
				}
			}
		}
		return $aMedalList;
	}

	public function getMedalRankingList($medalType, $limitAccumulatePoints, $page, $pageSize, $aUserIds = array()){
		$offect = ($page - 1) * $pageSize;
		$oMedal = new Model(T_MEDAL);
		$where = $medalType . '>=' . $limitAccumulatePoints;
		if($aUserIds){
			$where .= ' AND `id` in (' . implode(',', $aUserIds) . ')';
		}
		$aMedalList = $oMedal->get('`id`,' . $medalType . ' as `accumulate_points`', $where, $medalType . ' DESC', $offect, $pageSize);
		if(!$aMedalList){
			return $aMedalList;
		}
		$aUserIds = array();
		$order = $offect + 1;
		foreach($aMedalList as $key => $aMedal){
			$aUserIds[] = $aMedal['id'];
			$aMedalList[$key]['order'] = $order;
			$order++;
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return false;
		}
		foreach($aMedalList as &$aMedal){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aMedal['id']){
					$aMedal['name'] = $aUser['name'];
					$aMedal['profile'] = $aUser['profile'];
					break;
				}
			}
		}
		return $aMedalList;
	}

	public function getUserRankingCount($userId, $medalType, $aUserIds = array()){
		$oMedal = new Model(T_MEDAL);
		//我的经验点
		$aMedalInfo = $oMedal->get($medalType, array('id' => $userId));
		if(!$aMedalInfo){
			return $aMedalInfo;
		}
		$where = $medalType . '>' . $aMedalInfo[0][$medalType];
		if($aUserIds){
			$where .= ' AND `id` in (' . implode(',', $aUserIds) . ')';
		}
		$beforeCount = $oMedal->count($where);
		if($beforeCount === false){
			return false;
		}
		return array(
			'ranking'			=>	$beforeCount + 1,
			'accumulate_points'	=>	$aMedalInfo[0][$medalType],
		);
	}

	public function getUserMedalRankingListForMatch($page, $pageSize, $order = '', $aPointUserIds = array()){
		if(!$order){
			$order = '`all_medal` DESC';
		}
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if($aPointUserIds){
			$where = '`id` in (' . implode(',', $aPointUserIds) . ')';
		}
		$oMedal = new Model(T_MEDAL);
		$aMedalList = $oMedal->get('`id`,`gold_medal`,`silver_medal`,`cuprum_medal`,`gold_medal`+`silver_medal`+`cuprum_medal` as `all_medal`', $where, $order, $offect, $pageSize);
		if(!$aMedalList){
			return $aMedalList;
		}
		$aUserIds = array();
		foreach($aMedalList as $aMedal){
			$aUserIds[] = $aMedal['id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		if(!$aUserList){
			return $aUserList;
		}
		foreach($aMedalList as &$aMedal){
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aMedal['id']){
					$aMedal['name'] = $aUser['name'];
					$aMedal['profile'] = $aUser['profile'];
					break;
				}
			}
		}
		return $aMedalList;
	}

	public function addUserGoldRecord($aData){
		$oUserGoldRecord = new Model(T_USER_GOLD_RECORD);
		return $oUserGoldRecord->add($aData);
	}

	public function getUserGoldRecordList($page, $pageSize, $userId){
		$oUserGoldRecord = new Model(T_USER_GOLD_RECORD);
		$where = '`user_id`=' . $userId;
		$offect = ($page - 1) * $pageSize;
		return $oUserGoldRecord->get('', $where, '`id` desc', $offect, $pageSize);
	}

	public function getUserGoldRecordCount($userId){
		$oUserGoldRecord = new Model(T_USER_GOLD_RECORD);
		$where = '`user_id`=' . $userId;
		return $oUserGoldRecord->count($where);
	}
}