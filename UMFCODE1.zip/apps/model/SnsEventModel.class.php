<?php
class SnsEventModel{

	//用户动态表配置
	private $_aSnsEvent = array(
		'publish_shuoshuo'	=>	1,	//发表说说
		'become_friends'	=>	3,	//成为好友
		'pass_mission'	=>	6,	//过关
		'finish_task'	=>	7,	//完成修炼
		'break_self_record' => 90, //破自己的记录
		'break_world_record' => 91, //破世界记录
		'medal_process'	=>	8,	//勋章升级及获得
		'registration_match'	=>	9,	//报名参赛
		'finish_match'	=>	11,	//完成比赛
		'join_match_again'	=>	17,	//再次参赛
		'win_match'	=>	12,	//比赛中获奖
		'pk_result'	=>	16,	//分享PK结果
		'match_result' => 80, //分享比赛结果
		'exchange_goods' => 20, //兑换商品
	);

	const TRANSMIT_SHUOSHUO = 1;//转发说说
	const SHARE_PK_RESULT = 2;//分享pk结果
	const SHARE_MATCH_RESULT = 3; //分享比赛结果
	const SUPPORT_COUNT = 11; //赞的用户数量
	const REPLY_COUNT = 20;	//回复的数量
	const COMMENT_COUNT = 10; //评论的数量
	const MATCH_COUNT = 11; //比赛的用户数量
	const USER_COUNT = 50;//取更多用户的数量

	public function addEvent($aData){
		$oSnsEvent = new model(T_SNS_EVENT);
		//覆盖操作
		if($aData['type'] == $this->_aSnsEvent['become_friends']){
			$this->deleteEvent('',$aData['user_id'],$this->_aSnsEvent['become_friends']);
		}elseif($aData['type'] == $this->_aSnsEvent['pass_mission']){
			$this->deleteEvent($aData['user_id'],$this->_aSnsEvent['finish_task'],$aData['data_id']);
		}elseif($aData['type'] == $this->_aSnsEvent['break_world_record']){
			$this->deleteEvent('',$aData['user_id'],array($this->_aSnsEvent['pass_mission'],$this->_aSnsEvent['break_self_record']),$aData['data_id']);
		}elseif($aData['type'] == $this->_aSnsEvent['break_self_record']){
			$this->deleteEvent('',$aData['user_id'],$this->_aSnsEvent['pass_mission'],$aData['data_id']);
		}elseif($aData['type'] == $this->_aSnsEvent['finish_match']){
			$this->deleteEvent('',$aData['user_id'],$this->_aSnsEvent['registration_match'],$aData['data_id']);
		}elseif($aData['type'] == $this->_aSnsEvent['join_match_again']){
			$this->deleteEvent('',$aData['user_id'],$this->_aSnsEvent['finish_match'],$aData['data_id']);
			$joinMatchAgainCount = $oSnsEvent -> count('user_id='.$aData['user_id'].'type='.$this->_aSnsEvent['join_match_again'].'data_id='.$aData['data_id']);
			if($joinMatchAgainCount){
				$this->deleteEvent('',$aData['user_id'],$this->_aSnsEvent['join_match_again'],$aData['data_id']);
			}
		}elseif($aData['type'] == $this->_aSnsEvent['win_match']){
			$this->deleteEvent('',$aData['user_id'],$this->_aSnsEvent['join_match_again'],$aData['data_id']);
		}

		$id = $oSnsEvent->add($aData);
		if(isset($aData['data']) && is_array($aData['data'])){
			$aEvenData['id'] = $id;
			$aEvenData['data'] = json_encode($aData['data']);
			$oSnsEventData = new model(T_SNS_EVENT_DATA);
			$oSnsEventData->add($aEvenData);
		}

		return $id;
	}


	public function deleteEvent($id = '', $userId = '', $type = '', $dataId = ''){
		$where = '';
		if($id){
			if(!$userId && !$type && !$dataId){
				$where = array('id'=>$id);
			}else{
				$where .= '`id`='.$id;
			}

			//检测是否为发表说说（转发说说），如果是则执行连续的删除操作
			$oSnsEvent = new Model(T_SNS_EVENT);
			$aSnsEvent = $oSnsEvent -> get('`type`,`data_id`',$where);
			if(!$aSnsEvent){
				return 0;
			}
			if($aSnsEvent[0]['type'] == $this->_aSnsEvent['publish_shuoshuo'] || $aSnsEvent[0]['type'] == $this->_aSnsEvent['pk_result'] || $aSnsEvent[0]['type'] == $this->_aSnsEvent['match_result']){
				$oSnsShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
				$aCommentList = $oSnsShuoshuoComment->get('id','shuoshuo_id='.$aSnsEvent[0]['data_id']);
				$aCommentIds = array();
				$where2 = '';
				if($aCommentList){
					foreach($aCommentList as $aComment){
						$aCommentIds[] = $aComment['id'];
					}
					if($aCommentIds){
						if(count($aCommentIds) == 1){
							$where2 .= '(type=3 OR type=100) AND data_id ='.$aCommentIds[0];
						}else{
							$where2 .= '(type=3 OR type=100) AND data_id in('.implode(',',$aCommentIds).')';
						}
					}
				}

				if($where2){
					$where2 = '('.$where2.') OR (type=1 AND data_id='.$aSnsEvent[0]['data_id'].')';
				}else{
					$where2 .= 'type=1 AND data_id='.$aSnsEvent[0]['data_id'];
				}
				$oPersonalMessage = new Model(T_PERSONAL_MESSAGE);
				$oPersonalMessage->delete($where2);
			}
		}
		if($userId){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`user_id`='.$userId;
		}
		if($type){
			if($where){
				$where .= ' AND ';
			}
			if(is_array($type)){
				$type = implode(',',$type);
				$where .= '`type` in('.$type.')';
			}else{
				$where .= '`type`='.$type;
			}
		}
		if($dataId){
			if($where){
				$where .= ' AND ';
			}
			$where .= '`data_id`='.$dataId;
		}
		if(!$where){
			return false;
		}

		$oSnsEvent = new model(T_SNS_EVENT);
		return $oSnsEvent->delete($where);
	}

	public function getEventList($aUserIds = array(), $aFriendsIds = array(), $aEventTypes = array(), $page = 1, $pageSize = 20, $matchId = 0){
		$offect = ($page - 1) * $pageSize;
		$where = '';
		if($matchId){
			$order = '`id` desc';
			$fields = '`t1`.*';
			$where = '`t1`.`type` in (' . implode(',', $aEventTypes) . ')';
			if($aUserIds){
				$where .= ' AND ';
				if(count($aUserIds) == 1){
					$where .= '`t1`.`user_id`=' . $aUserIds[0];
				}else{
					$where .= '`t1`.`user_id` in (' . implode(',', $aUserIds) . ')';
				}
			}
			$where .= ' AND `match_relation`.`match_id`=' . $matchId;
			$oDboi = new DBOI();
			$aEventList = $oDboi->fields($fields)->table(T_SNS_EVENT)->leftjoin(T_MATCH_USER_RELATION, 'as `match_relation` on `t1`.`data_id`=`match_relation`.`id`')->where($where)->orderby($order)->select();
			if($aEventList === false){
				return false;
			}
			$aEventList = array_slice($aEventList, $offect, $pageSize);
		}else{
			if($aUserIds){
				if(count($aUserIds) == 1){
					$where = '`user_id`=' . $aUserIds[0];
				}else{
					$where = '`user_id` in (' . implode(',', $aUserIds) . ')';
				}
			}
			if($aEventTypes){
				if($where){
					$where .= ' AND ';
				}
				if(count($aEventTypes) == 1){
					$where .= '`type`=' . $aEventTypes[0];
				}else{
					$where .= '`type` in (' . implode(',', $aEventTypes) . ')';
				}
			}
			$aEventList = $this->_getSingleEventList($where, $offect, $pageSize);
		}

		return $this->_getDetailEventList($aEventList, $aFriendsIds);
	}

	private function _getSingleEventList($where, $offect, $pageSize, $aBeforeEventList = array()){
		$oSnsEvent = new model(T_SNS_EVENT);
		$aEventList = $oSnsEvent->get('', $where, '`id` DESC', $offect, $pageSize);
		if($aEventList === false){
			return false;
		}elseif(!$aEventList){
			return $aBeforeEventList;
		}

		if($aBeforeEventList){
			$aEventList = array_merge($aBeforeEventList, $aEventList);
		}
		$aEventList = $this->_mergeUserMissionEventList($aEventList);

		if(count($aEventList) < 12 && $pageSize > 12){
			$offect += $pageSize;
			$aEventList = $this->_getSingleEventList($where, $offect, $pageSize, $aEventList);
		}
		return $aEventList;
	}

	private function _mergeUserMissionEventList($aEventList){
		//合并同一个人的修炼和闯关记录
		$aFinishTaskList = array();
		$aPassMissionList = array();
		foreach($aEventList as $key => $aEvent){
			if($aEvent['type'] == $this->_aSnsEvent['finish_task']){
				if(!isset($aFinishTaskList[$aEvent['user_id']])){
					$aFinishTaskList[$aEvent['user_id']]['key'] = $key;
					if(is_array($aEvent['data_id'])){
						$aFinishTaskList[$aEvent['user_id']]['data_id'] = $aEvent['data_id'];
					}else{
						$aFinishTaskList[$aEvent['user_id']]['data_id'][] = $aEvent['data_id'];
					}
				}else{
					$aFinishTaskList[$aEvent['user_id']]['data_id'][] = $aEvent['data_id'];
					unset($aEventList[$key]);
				}
			}elseif($aEvent['type'] == $this->_aSnsEvent['pass_mission']){
				if(!isset($aPassMissionList[$aEvent['user_id']])){
					$aPassMissionList[$aEvent['user_id']]['key'] = $key;
					if(is_array($aEvent['data_id'])){
						$aPassMissionList[$aEvent['user_id']]['data_id'] = $aEvent['data_id'];
					}else{
						$aPassMissionList[$aEvent['user_id']]['data_id'][] = $aEvent['data_id'];
					}
				}else{
					$aPassMissionList[$aEvent['user_id']]['data_id'][] = $aEvent['data_id'];
					unset($aEventList[$key]);
				}
			}
		}
		if($aFinishTaskList){
			foreach($aFinishTaskList as $aFinishTask){
				$aEventList[$aFinishTask['key']]['data_id'] = $aFinishTask['data_id'];
			}
		}
		if($aPassMissionList){
			foreach($aPassMissionList as $aPassMission){
				$aEventList[$aPassMission['key']]['data_id'] = $aPassMission['data_id'];
			}
		}
		return $aEventList;
	}

	private function _getDetailEventList($aEventList, $aFriendsIds){
		if(!$aEventList){
			return $aEventList;
		}

		//初始化必要数据
		$aShuoshuoIds = array();
		$aBecomeFriendUserIds = array();
		$aUserMissionRelationIds = array();
		$aUserChallengeMissionRelationIds = array();
		$aMedalUserIds = array();
		$aMatchUserRelationIds = array();
		$aExchangeIds = array();
		$aUserIds = array();
		$aMissionIds = array();
		//收集必要数据
		foreach($aEventList as $key => $aEvent){
			if($aEvent['type'] == $this->_aSnsEvent['publish_shuoshuo'] || $aEvent['type'] == $this->_aSnsEvent['pk_result'] || $aEvent['type'] == $this->_aSnsEvent['match_result']){
				$aShuoshuoIds[] = $aEvent['data_id'];
			}elseif($aEvent['type'] == $this->_aSnsEvent['become_friends']){
				$aBecomeFriendUserIds[] = $aEvent['user_id'];
			}elseif($aEvent['type'] == $this->_aSnsEvent['pass_mission'] || $aEvent['type'] == $this->_aSnsEvent['finish_task']){
				if(is_array($aEvent['data_id'])){
					$aUserMissionRelationIds = array_merge($aUserMissionRelationIds, $aEvent['data_id']);
				}else{
					$aUserMissionRelationIds[] = $aEvent['data_id'];
				}
			}elseif($aEvent['type'] == $this->_aSnsEvent['break_self_record'] || $aEvent['type'] == $this->_aSnsEvent['break_world_record']){
				$aUserChallengeMissionRelationIds[] = $aEvent['data_id'];
			}elseif($aEvent['type'] == $this->_aSnsEvent['medal_process']){
				$aMedalUserIds[] = $aEvent['user_id'];
			}elseif($aEvent['type'] == $this->_aSnsEvent['registration_match'] || $aEvent['type'] == $this->_aSnsEvent['finish_match'] || $aEvent['type'] == $this->_aSnsEvent['join_match_again'] || $aEvent['type'] == $this->_aSnsEvent['win_match']){
				$aMatchUserRelationIds[] = $aEvent['data_id'];
			}elseif($aEvent['type'] == $this->_aSnsEvent['exchange_goods']){
				$aExchangeIds[] = $aEvent['data_id'];
			}
			$aUserIds[] = $aEvent['user_id'];
		}

		//得到说说详细
		$aShuoshuoList = array();
		if($aShuoshuoIds){
			$aShuoshuoList = $this->_getShuoshuoList($aShuoshuoIds);
			if($aShuoshuoList === false){
				return false;
			}

			//收集出现的userId
			foreach($aShuoshuoList as $aShuoshuo){
				if($aShuoshuo['source_info']){
					if(isset($aShuoshuo['source_info']['user_id']) && $aShuoshuo['source_info']['user_id']){
						$aUserIds[] = $aShuoshuo['source_info']['user_id'];
					}elseif(isset($aShuoshuo['source_info']['sender_user_id']) && $aShuoshuo['source_info']['sender_user_id']){
						$aUserIds[] = $aShuoshuo['source_info']['sender_user_id'];
						$aUserIds[] = $aShuoshuo['source_info']['receiver_user_id'];
					}elseif(isset($aShuoshuo['source_info']['users']) && $aShuoshuo['source_info']['users']){
						foreach($aShuoshuo['source_info']['users'] as $aUser){
							$aUserIds[] = $aUser['user_id'];
						}
					}
					if(isset($aShuoshuo['source_info']['mission_id']) && $aShuoshuo['source_info']['mission_id']){
						//收集分享pk时的关卡Id
						$aMissionIds[] = $aShuoshuo['source_info']['mission_id'];
					}
					if(isset($aShuoshuo['source_info']['support']) && $aShuoshuo['source_info']['support']){
						$aUserIds = array_merge($aUserIds,explode(',',$aShuoshuo['source_info']['support']));
					}
				}
				if($aShuoshuo['support']){
					$aUserIds = array_merge($aUserIds,explode(',',$aShuoshuo['support']));
				}
				if($aShuoshuo['comment']){
					foreach($aShuoshuo['comment'] as $aComment){
						$aUserIds[] = $aComment['user_id'];
						if($aComment['replyed_user_id']){
							$aUserIds[] = $aComment['replyed_user_id'];
						}
						if(isset($aComment['reply']) && $aComment['reply']){
							foreach($aComment['reply'] as $aReply){
								$aUserIds[]= $aReply['user_id'];
								if( $aReply['replyed_user_id']){
									$aUserIds[] = $aReply['replyed_user_id'];
								}
							}
						}
					}
				}
			}
		}

		//得到最近4个好友的id
		$aUserLastFourFriendIdList = array();
		if($aBecomeFriendUserIds){
			$aUserLastFourFriendIdList = $this->_getUserLastSixFriendIdList($aBecomeFriendUserIds);
			if($aUserLastFourFriendIdList === false){
				return false;
			}
			if($aUserLastFourFriendIdList){
				foreach($aUserLastFourFriendIdList as $aUserLastFourFriendId){
					if($aUserLastFourFriendId){
						$aUserIds = array_merge($aUserIds, $aUserLastFourFriendId);
					}
				}
			}
		}

		//得到关卡动态信息
		$aUserMissionRelationList = array();
		if($aUserMissionRelationIds || $aUserChallengeMissionRelationIds){
			$aUserMissionRelationList = $this->_getMissionUserRelationList($aUserMissionRelationIds,$aUserChallengeMissionRelationIds);
			if($aUserMissionRelationList === false){
				return false;
			}
			//收集出现的missionId
			foreach($aUserMissionRelationList as $key=>$aUserMission){
				$aMissionIds[] = $aUserMission['mission_id'];
			}
		}

		//得到勋章升级动态消息
		if($aMedalUserIds){
			$aMedalList = $this->_getMedalList($aMedalUserIds);
			if($aMedalList === false){
				return false;
			}
		}

		$aMatchList = array();
		//得到比赛动态消息
		if($aMatchUserRelationIds){
			$aMatchList = $this->_getMatchList($aMatchUserRelationIds);
			if($aMatchList === false){
				return false;
			}

			//收集出现的user_id
			foreach($aMatchList as $aMatch){
				if($aMatch['users']){
					foreach($aMatch['users'] as $aMatchTop){
						$aUserIds[] = $aMatchTop['user_id'];
					}
				}
			}
		}

		if($aExchangeIds){
			$aExchangeList = $this->_getExchangeGoodsList($aExchangeIds);

			//收集用户Id
			foreach($aExchangeList as $aExchange){
				$aUserIds[] = $aExchange['user_id'];
			}
		}

		//查出所有用户信息
		if($aUserIds){
			//去掉数组中为空的值
			//$aUserIds = array_filter($aUserIds,create_function('$v','return !empty($v);'));
			$aUserList = $this -> _getUserList($aUserIds);
			if($aUserList === false){
				return false;
			}
			$aUserReferList = array();
			foreach($aUserList as $key => $value){
				$aUserReferList[$value['id']] = &$aUserList[$key];
			}
			unset($aUserList);
		}

		//给说说组装用户信息以及赞
		foreach($aShuoshuoList as $key => $aShuoshuo){
			$aShuoshuoList[$key]['support_count'] = 0;
			//分享比赛结果的时候，组装比赛得奖用户信息
			if($aShuoshuo['source_type'] == self::SHARE_MATCH_RESULT){
				if(isset($aShuoshuo['source_info']['users']) && $aShuoshuo['source_info']['users']){
					foreach($aShuoshuoList[$key]['source_info']['users'] as $key2 => $aMatchWinnerTop){
						$aShuoshuoList[$key]['source_info']['users'][$key2]['user_info'] = $aUserReferList[$aMatchWinnerTop['user_id']];
					}
				}
			}

			//把转发说说的源说说的赞扔给说说的赞进行处理
			/* if(isset($aShuoshuo['source_info']['support']) && $aShuoshuo['source_info']['support'] && $aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				$aShuoshuoList[$key]['support'] = '';
				$aShuoshuoList[$key]['support'] = $aShuoshuoList[$key]['source_info']['support'];
			}elseif(isset($aShuoshuo['source_info']['support']) && !$aShuoshuo['source_info']['support'] && $aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				$aShuoshuoList[$key]['support'] = '';
			} */
			if($aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				if($aShuoshuo['source_info'] && $aShuoshuo['source_info']['support']){
					if($aShuoshuo['source_info']['support']){
						$aShuoshuoList[$key]['support'] = '';
						$aShuoshuoList[$key]['support'] = $aShuoshuoList[$key]['source_info']['support'];
					}else{
						$aShuoshuoList[$key]['support'] = '';
					}
				}else{
					$aShuoshuoList[$key]['support'] = '';
				}
				unset($aShuoshuoList[$key]['source_info']['support']);
			}

			if($aShuoshuoList[$key]['support']){
				$aShuoshuoList[$key]['support'] = explode(',',$aShuoshuoList[$key]['support']);
				$aShuoshuoList[$key]['support_count'] = count($aShuoshuoList[$key]['support']);
				$aShuoshuoSupport = $aShuoshuoList[$key]['support'];
				if($aFriendsIds){
					$aShuoshuoList[$key]['support'] = array_intersect($aShuoshuoList[$key]['support'], $aFriendsIds);
					sort($aShuoshuoList[$key]['support']);
					$aUserLocation = array_keys($aShuoshuoList[$key]['support'],$aFriendsIds[0]);
					if($aUserLocation && ($aUserLocation[0] != 0)){
						list($aShuoshuoList[$key]['support'][0],$aShuoshuoList[$key]['support'][$aUserLocation[0]]) = array($aShuoshuoList[$key]['support'][$aUserLocation[0]],$aShuoshuoList[$key]['support'][0]);
					}
				}
				if(count($aShuoshuoList[$key]['support']) > self::SUPPORT_COUNT){
					array_splice($aShuoshuoList[$key]['support'],self::SUPPORT_COUNT);
				}elseif(count($aShuoshuoList[$key]['support']) < self::SUPPORT_COUNT){
					$aShuoshuoSupport = array_diff($aShuoshuoSupport, $aShuoshuoList[$key]['support']);
					$aShuoshuoList[$key]['support'] = array_merge($aShuoshuoList[$key]['support'], $aShuoshuoSupport);
					array_splice($aShuoshuoList[$key]['support'],self::SUPPORT_COUNT);
				}
				//给赞组装用户信息
				foreach($aShuoshuoList[$key]['support'] as $key2 => $aSupport){
					$aShuoshuoList[$key]['support'][$key2] = $aUserReferList[$aSupport];
				}
			}else{
				$aShuoshuoList[$key]['support'] = array();
			}
			if($aShuoshuo['source_info']){
				if(isset($aShuoshuo['source_info']['user_id']) && $aShuoshuo['source_info']['user_id']){
					$aShuoshuoList[$key]['source_info']['user_info'] = $aUserReferList[$aShuoshuo['source_info']['user_id']];
				}elseif(isset($aShuoshuo['source_info']['sender_user_id']) && $aShuoshuo['source_info']['sender_user_id']){
					$aShuoshuoList[$key]['source_info']['sender_user_info'] = $aUserReferList[$aShuoshuo['source_info']['sender_user_id']];
					$aShuoshuoList[$key]['source_info']['receiver_user_info'] = $aUserReferList[$aShuoshuo['source_info']['receiver_user_id']];
				}
			}
			if($aShuoshuo['comment']){
				foreach($aShuoshuo['comment'] as $key2 => $aComment){
					$aShuoshuoList[$key]['comment'][$key2]['user_info'] = $aUserReferList[$aComment['user_id']];
					if($aComment['reply']){
						foreach($aComment['reply'] as $key3 => $aReply){
							$aShuoshuoList[$key]['comment'][$key2]['reply'][$key3]['user_info'] = $aUserReferList[$aReply['user_id']];
							$aShuoshuoList[$key]['comment'][$key2]['reply'][$key3]['reply_user_info'] = $aUserReferList[$aReply['replyed_user_id']];
						}
					}
				}
			}
		}
		//给成为好友组装用户信息
		foreach($aUserLastFourFriendIdList as $key => $aBecomeFriend){
			foreach($aBecomeFriend as $key2 => $aBecome){
				$aUserLastFourFriendIdList[$key][$key2] = array();
				if(isset($aUserReferList[$aBecome])){
					$aUserLastFourFriendIdList[$key][$key2] = $aUserReferList[$aBecome];
				}else{
					unset($aUserLastFourFriendIdList[$key][$key2]);
				}
			}
		}

		//给比赛组装赢家的用户信息
		foreach($aMatchList as $key => $aMatch){
			foreach($aMatch['users'] as $key2 => $aMatchWinnerTop){
				$aMatchList[$key]['users'][$key2]['user_info'] = $aUserReferList[$aMatchWinnerTop['user_id']];
			}
		}

		//合并数据结构
		foreach($aEventList as $key => $aEvent){
			$aEventList[$key]['data'] = array();
			//说说数据结构
			if($aEvent['type'] == $this->_aSnsEvent['publish_shuoshuo'] || $aEvent['type'] == $this->_aSnsEvent['pk_result'] || $aEvent['type'] == $this->_aSnsEvent['match_result']){
				foreach($aShuoshuoList as $aShuoshuo){
					if($aEvent['data_id'] == $aShuoshuo['id']){
						$aEventList[$key]['data'] = $aShuoshuo;
						break;
					}
				}

			//成为好友数据结构
			}elseif($aEvent['type'] == $this->_aSnsEvent['become_friends']){
				if(in_array($aEvent['user_id'], $aBecomeFriendUserIds)){
					foreach($aUserLastFourFriendIdList as $key2=>$aBecomeFriend){
						if($aEvent['user_id'] == $key2){
							$aEventList[$key]['user_info'] = $aUserReferList[$aEvent['user_id']];
							$aEventList[$key]['data'] = $aBecomeFriend;
							break;
						}
					}
				}

			//关卡数据结构
			}elseif($aEvent['type'] == $this->_aSnsEvent['pass_mission'] || $aEvent['type'] == $this->_aSnsEvent['finish_task'] || $aEvent['type'] == $this->_aSnsEvent['break_self_record'] || $aEvent['type'] == $this->_aSnsEvent['break_world_record']){
				if(is_array($aEvent['data_id'])){
					foreach($aEvent['data_id'] as $dataId){
						foreach($aUserMissionRelationList as $key2 => $aUserMissionList){
							if($aUserMissionList['user_id'] == $aEvent['user_id'] && $dataId==$aUserMissionList['id']){
								$aEventList[$key]['data'][] = $aUserMissionList;
								unset($aEventList[$key]['data'][$key2]['challenge_info']);
								break;
							}
						}
					}
				}else{
					foreach($aUserMissionRelationList as $aUserMissionList){
						if($aUserMissionList['user_id'] == $aEvent['user_id'] && $aEvent['data_id'] == $aUserMissionList['id']){
							$aEventList[$key]['data'] = $aUserMissionList;
							break;
						}
					}
				}

			//勋章升级数据结构
			}elseif($aEvent['type'] == $this->_aSnsEvent['medal_process']){
				$aTempData = array();
				$aTempData['medal_type'] = substr($aEvent['data_id'], 0, 1);
				$aTempData['index'] = substr($aEvent['data_id'], 1);
				if($aTempData['medal_type'] == 1){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['challenge_times'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 2){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['passed_missions'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 3){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['excellent_missions'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 4){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['perfect_missions'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 5){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['pk_times'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 6){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['pk_win_times'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 7){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['match_times'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 8){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['match_win_times'][$aTempData['index']];
							break;
						}
					}
				}elseif($aTempData['medal_type'] == 9){
					foreach($aMedalList as $aMedal){
						if($aEvent['user_id'] == $aMedal['id']){
							$aTempData['medal_info'][$aTempData['index']] = $aMedal['medal_process']['comment_support_times'][$aTempData['index']];
							break;
						}
					}
				}

				unset($aTempData['index']);
				$aEventList[$key]['data'] = $aTempData;
				unset($aTempData);

			//比赛数据结构
			}elseif($aEvent['type'] == $this->_aSnsEvent['registration_match'] || $aEvent['type'] == $this->_aSnsEvent['finish_match'] || $aEvent['type'] == $this->_aSnsEvent['join_match_again'] || $aEvent['type'] == $this->_aSnsEvent['win_match']){
				foreach($aMatchList as $aMatch){
					if($aEvent['data_id'] == $aMatch['id']){
						$aEventList[$key]['data'] = $aMatch;
						break;
					}
				}
			}elseif($aEvent['type'] == $this->_aSnsEvent['exchange_goods']){
				foreach($aExchangeList as $aExchange){
					if($aEvent['data_id'] == $aExchange['id']){
						$aEventList[$key]['data'] = $aExchange;
						break;
					}
				}
			}else{
				unset($aEventList[$key]);
			}
		}

		if($aMissionIds){
			//获取关卡信息
			$aMissionList = $this->_getUserMissionInfo($aMissionIds);
			if($aMissionList === false){
				return false;
			}
			$aMisssionReferList = array();
			foreach($aMissionList as $aMission){
				$aMisssionReferList[$aMission['id']] = $aMission['name'];
			}
			unset($aMissionList);
		}
		//给动态列表组装用户信息以及关卡信息
		foreach($aEventList as $key => $aEvent){
			$aEventList[$key]['user_info'] = $aUserReferList[$aEvent['user_id']];
			if($aEvent['type'] == $this->_aSnsEvent['pass_mission'] || $aEvent['type'] == $this->_aSnsEvent['finish_task']){
				foreach($aEvent['data'] as $key2 => $aEventInfo){
					$aEventList[$key]['data'][$key2]['mission_name'] = $aMisssionReferList[$aEventInfo['mission_id']];
					//组装上闯关超越对手的比重
					if($aEvent['type'] == $this->_aSnsEvent['pass_mission']){
						if($aEventInfo['score'] > 0){
						$aEventList[$key]['data'][$key2]['over_percent'] = $this->_countMissionScale($aEventInfo['mission_id'], $aEventInfo['score']);
						}else{
							$aEventList[$key]['data'][$key2]['over_percent'] = 0;
						}
					}else{
						$aEventList[$key]['data'][$key2]['over_percent'] = 0;
					}
				}


			}elseif($aEvent['type'] == $this->_aSnsEvent['break_self_record'] || $aEvent['type'] == $this->_aSnsEvent['break_world_record']){
				$aEventList[$key]['data']['mission_name'] = $aMisssionReferList[$aEventList[$key]['data']['mission_id']];
				if($aEvent['type'] == $this->_aSnsEvent['break_self_record']){
					$aEventList[$key]['data']['over_percent'] = $this->_countMissionScale($aEventList[$key]['data']['mission_id'], $aEventList[$key]['data']['score']);
				}
			}elseif($aEvent['type'] == $this->_aSnsEvent['pk_result']){
				$aEventList[$key]['data']['source_info']['mission_name'] = $aMisssionReferList[$aEvent['data']['source_info']['mission_id']];
			}
		}

		return $aEventList;

	}

	//最新评论
	public function getUserCommentList($userId, $page = 1, $pageSize = 12){
		if(!$userId){
			return false;
		}
		$offect = ($page-1) * $pageSize;

		//查出所有评论
		$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aCommentList = $oShuoshuoComment->get('max(`id`) as `id`', 'replyed_user_id=' . $userId . ' AND parent_id=0', '`id` DESC', $offect, $pageSize, '`shuoshuo_id`');
		if(!$aCommentList){
			return $aCommentList;
		}
		$aCommentIds = array();
		foreach($aCommentList as $aComment){
			$aCommentIds[] = $aComment['id'];
		}
		$aShuoshuoCommentList = $oShuoshuoComment->get('`id`,`user_id`,`content`,`create_time`', array('id' => array('in', $aCommentIds)));

		if(!$aShuoshuoCommentList){
			return $aShuoshuoCommentList;
		}
		$aUserId = array();
		foreach($aShuoshuoCommentList as $aShuoshuoComment){
			$aUserId[] = $aShuoshuoComment['user_id'];
		}

		//查出所有用户信息
		$aUserList = $this->_getUserList($aUserId);
		if($aUserList === false){
			return false;
		}
		$aUserReferList = array();
		foreach($aUserList as $key => $value){
			$aUserReferList[$value['id']] = &$aUserList[$key];
		}
		unset($aUserList);

		//组装数据
		foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
				$aShuoshuoCommentList[$key]['user_info'] = $aUserReferList[$aShuoshuoComment['user_id']];
		}
		return $aShuoshuoCommentList;
	}


	//得到说说列表
	public function getShuoshuoList($userId = 0, $type = 0, $page = 1, $pageSize = 20){
		$where = '';
		if(!$userId){
			return false;
		}
		$aFriendsIds = $this->_getUserFriendsId($userId);

		if($aFriendsIds === false){
			return false;
		}elseif(!$aFriendsIds){
			$aFriendsIds[] = $userId;
		}else{
			array_unshift($aFriendsIds, $userId);
		}
		$aUserIds = $aFriendsIds;
		if(!$type){
			$where = '`user_id` in (' . implode(',', $aFriendsIds) . ')';
		}else{
			$where = '`user_id`=' . $userId;
		}

		$offect = ($page - 1) * $pageSize;
		$oSnsShuoshuo = new model(T_SNS_SHUOSHUO);
		$aSnsShuoshuoList = $oSnsShuoshuo->get('`id`', $where, '`id` DESC', $offect, $pageSize);

		if(!$aSnsShuoshuoList){
			return $aSnsShuoshuoList;
		}

		//收集说说id
		$aShuoshuoIds = array();
		foreach($aSnsShuoshuoList as $aShuoshuo){
			$aShuoshuoIds[] = $aShuoshuo['id'];
		}

		$aShuoshuoList = $this->_getShuoshuoList($aShuoshuoIds);
		if($aShuoshuoList === false){
			return false;
		}

		//收集出现的userId
		$aMissionIds = array();
		foreach($aShuoshuoList as $aShuoshuo){
			if($aShuoshuo['source_type'] == 3){
				//收集出现的user_id
				if(isset($aShuoshuo['source_info']['users']) && $aShuoshuo['source_info']['users']){
					foreach($aShuoshuo['source_info']['users'] as $aMatchTop){
						$aUserIds[] = $aMatchTop['user_id'];
					}
				}
			}
			if($aShuoshuo['source_type'] == 2){
				$aMissionIds[] = $aShuoshuo['source_info']['mission_id'];
			}
			if($aShuoshuo['source_info']){
				if(isset($aShuoshuo['source_info']['user_id']) && $aShuoshuo['source_info']['user_id']){
					$aUserIds[] = $aShuoshuo['source_info']['user_id'];
				}elseif(isset($aShuoshuo['source_info']['sender_user_id']) && $aShuoshuo['source_info']['sender_user_id']){
					$aUserIds[] = $aShuoshuo['source_info']['sender_user_id'];
					$aUserIds[] = $aShuoshuo['source_info']['receiver_user_id'];
				}
				if(isset($aShuoshuo['source_info']['support']) && $aShuoshuo['source_info']['support']){
					$aUserIds = array_merge($aUserIds,explode(',',$aShuoshuo['source_info']['support']));
				}
			}
			if($aShuoshuo['support']){
				$aUserIds = array_merge($aUserIds,explode(',',$aShuoshuo['support']));
			}
			if($aShuoshuo['comment']){
				foreach($aShuoshuo['comment'] as $aComment){
					$aUserIds[] = $aComment['user_id'];
					if($aComment['replyed_user_id']){
						$aUserIds[] = $aComment['replyed_user_id'];
					}
					if(isset($aComment['reply']) && $aComment['reply']){
						foreach($aComment['reply'] as $aReply){
							$aUserIds[]= $aReply['user_id'];
							if( $aReply['replyed_user_id']){
								$aUserIds[] = $aReply['replyed_user_id'];
							}
						}
					}
				}
			}
		}

		//查出所有用户信息
		if($aUserIds){
			$aUserList = $this -> _getUserList($aUserIds);
			if($aUserList === false){
				return false;
			}
			$aUserReferList = array();
			foreach($aUserList as $key => $value){
				$aUserReferList[$value['id']] = &$aUserList[$key];
			}
			unset($aUserList);
		}

		//获取关卡信息
		if($aMissionIds){
			$aMissionList = $this->_getUserMissionInfo($aMissionIds);
			if($aMissionList === false){
				return false;
			}
			$aMisssionReferList = array();
			foreach($aMissionList as $aMission){
				$aMisssionReferList[$aMission['id']] = $aMission['name'];
			}
			unset($aMissionList);
		}

		//给说说组装用户信息以及赞
		foreach($aShuoshuoList as $key => $aShuoshuo){
			//给说说组装用户信息
			$aShuoshuoList[$key]['user_info'] = $aUserReferList[$aShuoshuo['user_id']];

			//分享比赛结果的时候，组装比赛得奖用户信息
			if($aShuoshuo['source_type'] == self::SHARE_MATCH_RESULT){
				if(isset($aShuoshuo['source_info']['users']) && $aShuoshuo['source_info']['users']){
					foreach($aShuoshuoList[$key]['source_info']['users'] as $key2 => $aMatchWinnerTop){
						$aShuoshuoList[$key]['source_info']['users'][$key2]['user_info'] = $aUserReferList[$aMatchWinnerTop['user_id']];
					}
				}
			}

			//分享pk
			if($aShuoshuo['source_type'] == self::SHARE_PK_RESULT){
				$aShuoshuoList[$key]['source_info']['mission_name'] = $aMisssionReferList[$aShuoshuo['source_info']['mission_id']];
			}
			$aShuoshuoList[$key]['support_count'] = 0;
			//先把转发的源说说的赞扔给说说的赞进行处理
			// if(isset($aShuoshuo['source_info']['support']) && $aShuoshuo['source_info']['support'] && $aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				// $aShuoshuoList[$key]['support'] = '';
				// $aShuoshuoList[$key]['support'] = $aShuoshuoList[$key]['source_info']['support'];

			// }elseif(isset($aShuoshuo['source_info']['support']) && !$aShuoshuo['source_info']['support'] && $aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				// $aShuoshuoList[$key]['support'] = '';
			// }
			if($aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
				if($aShuoshuo['source_info'] && $aShuoshuo['source_info']['support']){
					if($aShuoshuo['source_info']['support']){
						$aShuoshuoList[$key]['support'] = '';
						$aShuoshuoList[$key]['support'] = $aShuoshuoList[$key]['source_info']['support'];
					}else{
						$aShuoshuoList[$key]['support'] = '';
					}
				}else{
					$aShuoshuoList[$key]['support'] = '';
				}
				unset($aShuoshuoList[$key]['source_info']['support']);
			}


			if($aShuoshuoList[$key]['support']){
				$aShuoshuoList[$key]['support'] = explode(',', $aShuoshuoList[$key]['support']);
				$aShuoshuoList[$key]['support_count'] = count($aShuoshuoList[$key]['support']);
				$aShuoshuoSupport = $aShuoshuoList[$key]['support'];
				if($aFriendsIds){
					$aShuoshuoList[$key]['support'] = array_intersect($aShuoshuoList[$key]['support'], $aFriendsIds);
					sort($aShuoshuoList[$key]['support']);
					$aUserLocation = array_keys($aShuoshuoList[$key]['support'],$aFriendsIds[0]);
					if($aUserLocation && ($aUserLocation[0] != 0)){
						list($aShuoshuoList[$key]['support'][0],$aShuoshuoList[$key]['support'][$aUserLocation[0]]) = array($aShuoshuoList[$key]['support'][$aUserLocation[0]], $aShuoshuoList[$key]['support'][0]);
					}
				}

				if(count($aShuoshuoList[$key]['support']) > self::SUPPORT_COUNT){
					array_splice($aShuoshuoList[$key]['support'],self::SUPPORT_COUNT);
				}elseif(count($aShuoshuoList[$key]['support']) < self::SUPPORT_COUNT){
					$aShuoshuoSupport = array_diff($aShuoshuoSupport, $aShuoshuoList[$key]['support']);
					$aShuoshuoList[$key]['support'] = array_merge($aShuoshuoList[$key]['support'], $aShuoshuoSupport);
					array_splice($aShuoshuoList[$key]['support'],self::SUPPORT_COUNT);
				}

				//给赞组装用户信息
				foreach($aShuoshuoList[$key]['support'] as $key2 => $aSupport){
					$aShuoshuoList[$key]['support'][$key2] = $aUserReferList[$aSupport];
				}
			}else{
				$aShuoshuoList[$key]['support'] = array();
			}
			if($aShuoshuo['source_info']){
				if(isset($aShuoshuo['source_info']['user_id']) && $aShuoshuo['source_info']['user_id']){
					$aShuoshuoList[$key]['source_info']['user_info'] = $aUserReferList[$aShuoshuo['source_info']['user_id']];
				}elseif(isset($aShuoshuo['source_info']['sender_user_id']) && $aShuoshuo['source_info']['sender_user_id']){
					$aShuoshuoList[$key]['source_info']['sender_user_info'] = $aUserReferList[$aShuoshuo['source_info']['sender_user_id']];
					$aShuoshuoList[$key]['source_info']['receiver_user_info'] = $aUserReferList[$aShuoshuo['source_info']['receiver_user_id']];
				}
			}

			if($aShuoshuo['comment']){
				foreach($aShuoshuo['comment'] as $key2 => $aComment){
					$aShuoshuoList[$key]['comment'][$key2]['user_info'] = $aUserReferList[$aComment['user_id']];
					if($aComment['reply']){
						foreach($aComment['reply'] as $key3 => $aReply){
							$aShuoshuoList[$key]['comment'][$key2]['reply'][$key3]['user_info'] = $aUserReferList[$aReply['user_id']];
							$aShuoshuoList[$key]['comment'][$key2]['reply'][$key3]['reply_user_info'] = $aUserReferList[$aReply['replyed_user_id']];
						}
					}
				}
			}
		}

		return $aShuoshuoList;
	}

	//获取更多各种类型的用户信息
	public function getMoreUserList($type = 0 , $id = 0 , $aDiffUserId = array()){
		if(!$type || !$id || !$aDiffUserId){
			return false;
		}

		$aUserId = array();
		$order = '';
		//说说赞用户的id
		if($type == 1){
			$oShuoshuo = new Model(T_SNS_SHUOSHUO);
			$aShuoshuoSupport = $oShuoshuo->get('`support`', array('id' => $id));
			if(!$aShuoshuoSupport){
				return $aShuoshuoSupport;
			}
			$aUserId = explode(',', $aShuoshuoSupport[0]['support']);
		}

		//报名比赛的条件
		if($type == 2){
			$order = 'create_time DESC';
		}

		//完成比赛的条件
		if($type == 3){
			$order = 'first_finish_time DESC';
		}
		//再次报名比赛的条件
		if($type == 4){
			$order = 'last_rejoin_time DESC';
		}

		//比赛得奖的条件
		if($type == 5){
			$oMatch = new Model(T_MATCH);
			$aMatch = $oMatch->get('winners',array('id' => $id));
			if(!$aMatch){
				return $aMatch;
			}
			$aMatch[0]['winners'] = json_decode($aMatch[0]['winners'],true);
			foreach($aMatch[0]['winners']['top'] as $aTop){
				$aUserId[] = $aTop['user_id'];
			}

			if($aMatch[0]['winners']['rand']){
				foreach($aMatch[0]['winners']['rand'] as $aRand){
					$aUserId[] = $aRand['user_id'];
				}
			}
		}

		//比赛的用户id
		if($order){
			$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
			$aMatchUser = $oMatchUserRelation->get('`user_id`', 'match_id=' . $id, $order);
			if(!$aMatchUser){
				return $aMatchUser;
			}else{
				foreach($aMatchUser as $aUser){
					$aUserId[] = $aUser['user_id'];
				}
			}
		}

		if(!$aUserId){
			return $aUserId;
		}
		//限制50个
		$aUserId = array_diff($aUserId , $aDiffUserId);
		if(!$aUserId){
			return $aUserId;
		}
		if(count($aUserId) > self::USER_COUNT){
			$length = count($aUserId) - self::USER_COUNT;
			array_splice($aUserId, $length);
		}

		//查出所有的用户信息
		$oPersonal = new Model(T_PERSONAL);
		$aUserList = $oPersonal->get('`id`,`name`,`profile`,`gender`,`birth_date`,`area_id`', 'id in(' . implode(',', $aUserId) . ')');
		if($aUserList === false){
			return false;
		}

		$oArea = new Model(T_AREA);
		foreach($aUserList as $key => $aUser){
			//计算年龄
			$aUserList[$key]['age'] = date('Y',time()) - date('Y',$aUser['birth_date']);
			//加上地区
			$aCity = $oArea->get('', array('id' => $aUser['area_id']));
			if(!$aCity){
				$aUserList[$key]['province'] = '';
				$aUserList[$key]['city'] = '';
			}
			$aUserList[$key]['city'] = $aCity[0]['name'];
			$aProvince = $oArea->get('', 'pid=' . $aCity[0]['pid']);
			$aUserList[$key]['province'] = $aProvince[0]['name'];
		}

		return $aUserList;
	}



	//获得最近好友列表
	private function _getUserLastSixFriendIdList($aBecomeFriendUserIds){
		$becomeFriendUserIds = implode(',', $aBecomeFriendUserIds);
		$oUserRelation = new Model(T_USER_RELATION);
		$aUserRelationList = $oUserRelation->get('', '(`user_master_id` in (' . $becomeFriendUserIds . ') OR `user_slave_id` in (' . $becomeFriendUserIds . '))' . ' AND `is_handed`>0', '`create_time` desc');
		$aBecomeFriendUserList = array();
		foreach($aBecomeFriendUserIds as $becomeFriendUserId){
			$aBecomeFriendUserList[$becomeFriendUserId] = array();
			foreach($aUserRelationList as $aUserRelation){
				if($becomeFriendUserId == $aUserRelation['user_master_id']){
					$aBecomeFriendUserList[$becomeFriendUserId][] = $aUserRelation['user_slave_id'];
				}elseif($becomeFriendUserId == $aUserRelation['user_slave_id']){
					$aBecomeFriendUserList[$becomeFriendUserId][] = $aUserRelation['user_master_id'];
				}
				if(count($aBecomeFriendUserList[$becomeFriendUserId]) >= 4){
					break;
				}
			}
		}
		return $aBecomeFriendUserList;
	}

	//获取说说动态列表
	private function _getShuoshuoList($aShuoshuoIds){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoList = $oShuoshuo->get('`id`,`user_id`,`content`,`images`,`create_time`,`source_type`,`source_id`,`transmit_times`,`support`,`views`', array('id' => array('in', $aShuoshuoIds)),'`create_time` DESC');
		if(!$aShuoshuoList){
			return $aShuoshuoList;
		}

		//收集说说id,以及说说源id，pk源id,比赛源Id
		$aShuoshuoIds = array();
		$aShuoshuoSourceIds = array();
		$aPkSourceIds = array();
		$aMatchSourceIds = array();
		foreach($aShuoshuoList as $aShuoshuo){
			if($aShuoshuo['source_id']){
				if($aShuoshuo['source_type'] == self::TRANSMIT_SHUOSHUO){
					$aShuoshuoSourceIds[] = $aShuoshuo['source_id'];
				}elseif($aShuoshuo['source_type'] == self::SHARE_PK_RESULT){
					$aPkSourceIds[] = $aShuoshuo['source_id'];
				}elseif($aShuoshuo['source_type'] == self::SHARE_MATCH_RESULT){
					$aMatchSourceIds[] = $aShuoshuo['source_id'];
				}
			}
			$aShuoshuoIds[] = $aShuoshuo['id'];
		}

		/*----转发与分享模块-------*/
		//获得说说源信息
		$aSourceShuoshuoList = array();
		if($aShuoshuoSourceIds){
			$aSourceShuoshuoList = $oShuoshuo->get('', array('id' => array('in', $aShuoshuoSourceIds)));
			if($aSourceShuoshuoList === false){
				return false;
			}
		}

		//获得pk源信息
		$aSourcePkList = array();
		if($aPkSourceIds){
			$oPkIndex = new Model(T_PK_INDEX);
			$aSourcePkList = $oPkIndex->get('', array('id' => array('in', $aPkSourceIds)));
			if($aSourcePkList === false){
				return false;
			}
		}

		//获得比赛源信息
		$aSourceMatchList = array();
		if($aMatchSourceIds){
			$aSourceMatchList = $this -> _getMatchList($aMatchSourceIds);
		}

		/*--------评论模块---------*/
		//查出当前说说的所有评论
		$shuoshuoIds = implode(',',$aShuoshuoIds);
		$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
		$aShuoshuoCommentList = $oShuoshuoComment->get('', '`shuoshuo_id` in (' . $shuoshuoIds . ')', '`id` ASC');
		if($aShuoshuoCommentList === false){
			return false;
		}

		$aCommentRefer = array();
		foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
			$aCommentRefer[$aShuoshuoComment['id']] = &$aShuoshuoCommentList[$key];
		}

		//组装评论结构
		$aCommentTree = array();
		if($aShuoshuoCommentList){
			foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
				//没有回复信息
				if(!$aShuoshuoComment['parent_id']){
					$aShuoshuoCommentList[$key]['reply'] = array();
					$aCommentTree[] = &$aShuoshuoCommentList[$key];
				}else{
					//回复评论信息组装结构
					$parentId = $aShuoshuoComment['parent_id'];
					if(isset($aCommentRefer[$parentId]) && $aCommentRefer[$parentId]){
						$aParent = &$aCommentRefer[$parentId];
						$aParent['reply'][] = &$aShuoshuoCommentList[$key];
					}
				}
			}
		}

		//给转发源说说组装说说图片
		if($aSourceShuoshuoList){
			foreach($aSourceShuoshuoList as $key=>$aSourceShuoshuo){
				//组装源说说图片
				if(isset($aSourceShuoshuo['images']) && $aSourceShuoshuo['images']){
					$aSourceShuoshuoList[$key]['images'] = explode(',', $aSourceShuoshuo['images']);
				}else{
					$aSourceShuoshuoList[$key]['images'] = array();
				}
			}
		}

		//组装数据
		foreach($aShuoshuoList as &$aShuoshuo){
			//组装转发说说以及分享说说
			$aShuoshuo['source_info'] = array();
			if($aShuoshuo['source_id']){
				$aShuoshuo['images'] = array();
				if($aSourceShuoshuoList){
					foreach($aSourceShuoshuoList as $aSourceShuoshuo){
						if($aSourceShuoshuo['id'] == $aShuoshuo['source_id']){
							$aShuoshuo['source_info'] = $aSourceShuoshuo;
							break;
						}else{
							$aShuoshuo['source_info'] = array();
						}
					}
				}
				if($aSourcePkList){
					foreach($aSourcePkList as $aSourcePk){
						if($aSourcePk['id'] == $aShuoshuo['source_id']){
							$aShuoshuo['source_info'] = $aSourcePk;
							break;
						}
					}

				}
				if($aSourceMatchList){
					foreach($aSourceMatchList as $aSourceMatch){
						if($aSourceMatch['id'] == $aShuoshuo['source_id']){
							$aShuoshuo['source_info'] = $aSourceMatch;
							break;
						}
					}
				}
			}else{
				//组装说说图片
				if($aShuoshuo['images']){
					$aShuoshuo['images'] = explode(',', $aShuoshuo['images']);
				}else{
					$aShuoshuo['images'] = array();
				}
			}
			$aShuoshuo['comment'] = array();
			//组装评论和回复
			foreach($aCommentTree as $aComment){
				if($aComment['shuoshuo_id'] == $aShuoshuo['id']){
					$aShuoshuo['comment'][] = $aComment;
				}
			}
		}
		unset($aShuoshuo);
		//限制10条评论以及20条回复
		foreach($aShuoshuoList as $key => $aShuoshuo){
			$aShuoshuoList[$key]['comment_count'] = count($aShuoshuo['comment']);
			if($aShuoshuoList[$key]['comment_count'] > self::COMMENT_COUNT){
				$length = $aShuoshuoList[$key]['comment_count'] - self::COMMENT_COUNT;
				array_splice($aShuoshuoList[$key]['comment'],0,$length);
			}
			foreach($aShuoshuoList[$key]['comment'] as $key2 => $aComment){
				if(isset($aComment['reply']) && $aComment['reply']){
					$aShuoshuoList[$key]['comment'][$key2]['reply_count'] = count($aComment['reply']);
				}else{
					$aShuoshuoList[$key]['comment'][$key2]['reply_count'] = 0;
				}
				if($aShuoshuoList[$key]['comment'][$key2]['reply_count'] > self::REPLY_COUNT){
					$length = $aShuoshuoList[$key]['comment'][$key2]['reply_count'] - self::REPLY_COUNT;
					array_splice($aShuoshuoList[$key]['comment'][$key2]['reply'],0,$length);
				}
			}
		}
		return $aShuoshuoList;
	}

	//获取关卡列表
	private function _getMissionUserRelationList($aUserMissionRelationIds, $aUserChallengeMissionRelationIds = array()){

		//再次挑战破记录
		if($aUserChallengeMissionRelationIds){
			$aUserMissionRelationIds = array_merge($aUserMissionRelationIds,$aUserChallengeMissionRelationIds);
		}

		$oMissionUserRelationIndex = new Model(T_MISSION_USER_RELATION_INDEX);
		$aUserMissionList = $oMissionUserRelationIndex->get('`id`,`user_id`,`mission_id`,`task_finish_time`,`score`,`pass_time`,`best_score_time`', array('id' => array('in', $aUserMissionRelationIds)));
		if(!$aUserMissionList){
			return $aUserMissionList;
		}

		//如果有再次挑战破记录
		if($aUserChallengeMissionRelationIds){
			$oMissionUserRelation = new Model(T_MISSION_USER_RELATION);
			$aUserChallengeMissionList = $oMissionUserRelation -> get('`id`,`break_record`',array('id' => array('in', $aUserChallengeMissionRelationIds)));
			if(!$aUserChallengeMissionList){
				return $aUserChallengeMissionList;
			}
		}
		//return $aUserMissionList;
		//组装数据
		foreach($aUserMissionList as $key => $aUserMission){
			if($aUserMissionRelationIds){
				$aUserMissionList[] = $aUserMission;
			}
			if(isset($aUserChallengeMissionList) && $aUserChallengeMissionList){
				foreach($aUserChallengeMissionList as $aUserChallengeMission){
					if($aUserMission['id'] == $aUserChallengeMission['id']){
						$aUserMissionList[$key]['challenge_info'] = json_decode($aUserChallengeMission['break_record'],true);
					}
				}
			}
		}

		return $aUserMissionList;
	}

	//计算闯关用户超越其它用户的比例
	private function _countMissionScale($missionId, $score){
		$oMissionUserRelation = new Model(T_MISSION_USER_RELATION_INDEX);
		$countAllUser =  $oMissionUserRelation->count('mission_id=' . $missionId);
		if($countAllUser === false){
			return false;
		}
		$countUser =  $oMissionUserRelation->count('mission_id=' . $missionId . ' AND score > ' . $score);
		if($countUser === false){
			return false;
		}
		return round((1-($countUser/$countAllUser)) * 100);
	}


	//获取勋章升级列表
	private function _getMedalList($aMedalUserIds){
		$oMedal = new Model(T_MEDAL);
		$aMedalList = $oMedal->get('', array('id' => array('in', $aMedalUserIds)));
		if(!$aMedalList){
			return $aMedalList;
		}
		foreach($aMedalList as &$aMedal){
			$aMedal['medal_process'] = json_decode($aMedal['medal_process'], true);
		}
		return $aMedalList;
	}

	//获取比赛列表
	private function _getMatchList($aMatchUserRelationIds){
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$where = '';

		$where = array('id' => array('in', $aMatchUserRelationIds));
		//$where = '`id` in(' . implode(',',array_unique($aMatchUserRelationIds)) . ') AND `match_id` = ' . $matchId;

		$aMatchUserRelationList = $oMatchUserRelation->get('`id`,`user_id`,`match_id`,`best_score`,`create_time`,`first_join_time`,`first_finish_time`,`last_rejoin_time`', $where);
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}

		$aMatchIds = array();
		//得到赛事Id
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aMatchIds[] = $aMatchUserRelation['match_id'];
		}
		$aMatchIds = array_unique($aMatchIds);

		//得到赛事详细列表
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`name`,`profile`,`description`,`match_start_time`,`match_end_time`,`awards`,`winners`,`grade_id`,`subject_id`', array('id' => array('in', $aMatchIds)));
		if($aMatchList === false){
			return false;
		}

		foreach($aMatchUserRelationList as &$aMatchUserRelation){
			foreach($aMatchList as $aMatch){
				if($aMatch['id'] == $aMatchUserRelation['match_id']){
					$aMatchUserRelation['match_name'] = $aMatch['name'];
					$aMatchUserRelation['match_profile'] = $aMatch['profile'];
					$aMatchUserRelation['match_end_time'] = $aMatch['match_end_time'];
					$aMatchUserRelation['match_winners'] = json_decode($aMatch['winners'],true);
					$aMatchUserRelation['match_awards'] = json_decode($aMatch['awards'],true);
					$aMatchUserRelation['description'] = $aMatch['description'];
					$aMatchUserRelation['match_start_time'] = $aMatch['match_start_time'];
					$aMatchUserRelation['grade_id'] = $aMatch['grade_id'];
					$aMatchUserRelation['subject_id'] = $aMatch['subject_id'];
				}
			}
		}

		//给比赛组装比赛结果信息以及奖品信息以及赢家的用户信息
		foreach($aMatchUserRelationList as $key => $aMatch){
			$aMatchUserRankingList = array();
			$aMatchUserRankingList = $oMatchUserRelation->get('`user_id`,`match_id`,`best_score`','match_id ='.$aMatch['match_id'],'best_score DESC');
			//参赛人数统计以及冠军得分
			if(!$aMatchUserRankingList){
				$aMatchUserRelationList[$key]['member_count'] = 0;
				$aMatchUserRelationList[$key]['champion_score'] = 0;
			}else{
				$aMatchUserRelationList[$key]['champion_score'] = $aMatchUserRankingList[0]['best_score'];
				$aMatchUserRelationList[$key]['member_count'] = count($aMatchUserRankingList);
				//组装排名
				if($aMatch['best_score'] != 0 && $aMatchUserRankingList){
					foreach($aMatchUserRankingList as $key4 => $aMatchUserRanking){
						if($aMatch['user_id'] == $aMatchUserRanking['user_id']){
							$aMatchUserRelationList[$key]['ranking'] = $key4+1;
							break;
						}
					}
				}else{
					$aMatchUserRelationList[$key]['ranking'] = 0;
				}
			}
			if($aMatch['match_winners']){
				foreach($aMatch['match_winners']['top'] as $key2 => $aMatchWinnerTop){
					if($aMatch['user_id'] == $aMatchWinnerTop['user_id']){
						$aMatchUserRelationList[$key]['win_info']['type'] = 1;
						$aMatchUserRelationList[$key]['win_info']['ranking'] = $key2;
						$aMatchUserRelationList[$key]['win_info']['creare_time'] = $aMatchWinnerTop['receive_time'];
						foreach($aMatch['match_awards']['top'] as $key3 => $aAwardsTop ){
							if($key2 == $key3){
								if(isset($aAwardsTop['accumulate_points']) && $aAwardsTop['accumulate_points']){
									$aMatchUserRelationList[$key]['win_info']['awards_info']['accumulate_points'] = $aAwardsTop['accumulate_points'];
								}elseif(isset($aAwardsTop['gold']) && $aAwardsTop['gold']){
									$aMatchUserRelationList[$key]['win_info']['awards_info']['gold'] = $aAwardsTop['gold'];
								}elseif(isset($aAwardsTop['prize']) && $aAwardsTop['prize']){
									$aMatchUserRelationList[$key]['win_info']['awards_info']['prize'] = $aAwardsTop['prize'];
								}else{
									$aMatchUserRelationList[$key]['win_info']['awards_info'] = array();
								}
							}
						}
						break;
					}else{
						foreach($aMatch['match_winners']['rand'] as $aMatchWinnerRand){
							if($aMatch['user_id'] == $aMatchWinnerRand['user_id']){
								$aMatchUserRelationList[$key]['win_info']['type'] = 2;
								$aMatchUserRelationList[$key]['win_info']['creare_time'] = $aMatchWinnerRand['receive_time'];
								if($aMatch['match_awards']['rand']){
									if(isset($aMatchWinnerRand['accumulate_points'])){
										$aMatchUserRelationList[$key]['win_info']['awards_info']['accumulate_points'] = $aMatch['match_awards']['rand']['accumulate_points'];
									}elseif(isset($aMatchWinnerRand['gold'])){
										$aMatchUserRelationList[$key]['win_info']['awards_info']['gold'] = $aMatch['match_awards']['rand']['gold'];
									}elseif(isset($aMatchWinnerRand['prize'])){
										$aMatchUserRelationList[$key]['win_info']['awards_info']['prize'] = $aMatch['match_awards']['rand']['prize'];
									}else{
										$aMatchUserRelationList[$key]['win_info']['awards_info'] = array();
									}
								}else{
									$aMatchUserRelationList[$key]['win_info']['awards_info'] = array();
								}
							}else{
								$aMatchUserRelationList[$key]['win_info'] = array();
							}
						}
					}
				}
			}else{
				$aMatchUserRelationList[$key]['win_info'] = array();
			}
			unset($aMatchUserRelationList[$key]['user_id'],$aMatchUserRelationList[$key]['match_awards']);
		}


		//限制比赛赢家用户信息为11个
		foreach($aMatchUserRelationList as $key => $aMatch){
			if($aMatch['match_winners']){
				$aMatchUserRelationList[$key]['match_winner_top_count'] = count($aMatch['match_winners']['top']);
				if($aMatchUserRelationList[$key]['match_winner_top_count'] > self::MATCH_COUNT){
					if($aMatchUserRelationList[$key]['match_winner_top_count'] > self::MATCH_COUNT){
						array_splice($aMatchUserRelationList[$key]['match_winners']['top'],self::MATCH_COUNT + 1);
					}
				}elseif($aMatchUserRelationList[$key]['match_winner_top_count'] < self::MATCH_COUNT){
					$length = self::MATCH_COUNT - $aMatchUserRelationList[$key]['match_winner_top_count'];
					$number = $aMatchUserRelationList[$key]['match_winner_top_count'];
					array_splice($aMatchUserRelationList[$key]['match_winners']['rand'],$length);
					foreach($aMatchUserRelationList[$key]['match_winners']['rand'] as $key3 => $aMatchWinnerRand){
						$aMatchUserRelationList[$key]['match_winners']['top'][++$number] = $aMatchUserRelationList[$key]['match_winners']['rand'][$key3];
					}
				}

				$aMatchUserRelationList[$key]['users'] = $aMatchUserRelationList[$key]['match_winners']['top'];

			}else{
				$order = '';
				if($aMatch['last_rejoin_time'] > 0){
					$order = 'last_rejoin_time DESC';
				}elseif($aMatch['first_finish_time'] > 0){
					$order = 'first_finish_time DESC';
				}elseif($aMatch['create_time'] > 0){
					$order = 'create_time DESC';
				}

				if($order){
					$aMatchUserList = $oMatchUserRelation->get('`user_id`', 'match_id='. $aMatch['match_id'], $order, self::MATCH_COUNT);

					if(!$aMatchUserList){
						$aMatchUserRelationList[$key]['users'] = array();
					}
					foreach($aMatchUserList as $key2 => $aMatchUser){
						$aMatchUserRelationList[$key]['users'][$key2]['user_id'] = $aMatchUser['user_id'];
					}

				}else{
					$aMatchUserRelationList[$key]['users'] = array();
				}
			}
			unset($aMatchUserRelationList[$key]['match_winners']);
		}

		return $aMatchUserRelationList;

	}

	//得到详细的兑换商品记录
	private function _getExchangeGoodsList($aExchangeIds){
		$oExchangeRecords = new Model(T_EXCHANGE_RECORDS);
		$aExchangeGoodsList = $oExchangeRecords->get('',array('id'=>array('in',$aExchangeIds)));
		if(!$aExchangeGoodsList){
			return $aExchangeGoodsList;
		}
		$aGoodsIds = array();
		foreach($aExchangeGoodsList as $aExchangeGoods){
			$aGoodsIds[] = $aExchangeGoods['goods_id'];
		}
		$oExchangeGoods = new Model(T_EXCHANGE_GOODS);
		$aGoodsList = $oExchangeGoods->get('`id`,`name`,`support`,`gold`,`level`,`stock`', array('id'=>array('in',$aGoodsIds)));
		if(!$aGoodsList){
			return $aGoodsList;
		}

		$aGoodsRefer = array();
		foreach($aGoodsList as $aGoods){
			$aGoodsRefer[$aGoods['id']] = $aGoods;
			unset($aGoodsRefer[$aGoods['id']]['id']);
		}
		unset($aGoodsList);

		//合并数据
		foreach($aExchangeGoodsList as &$aExchangeGoods){
			$aExchangeGoods = array_merge($aExchangeGoods, $aGoodsRefer[$aExchangeGoods['goods_id']]);
		}

		unset($aExchangeGoods);
		return $aExchangeGoodsList;
	}


	//查出用户信息
	private function _getUserList($aUserIds){
		//$oUser = new Model(T_PERSONAL);
		//$aUserList = $oUser->get('`id`,`name`,`profile`', 'id in (' . implode(',', $aUserIds) . ')');
		//return $aUserList;
		return getUserListByUserIds($aUserIds);
	}

	//查出所有关卡信息
	private function _getUserMissionInfo($aMissionIds){
		$oMission = new Model(T_MISSION);
		$aMissionList = $oMission->get('`id`,`name`,`grade`', array('id' => array('in', $aMissionIds)));
		$aMissionList = Mission::convertMissionList($aMissionList);
		return $aMissionList;
	}

	//得到用户好友
	private function _getUserFriendsId($userId){
		$oUserFriend = new Model(T_USER_FRIEND);
		$aUserFriendInfo = $oUserFriend -> get('',array('id'=>$userId));
		if(!$aUserFriendInfo){
			return $aUserFriendInfo;
		}else{
			$aUserFriendInfo[0]['friends'] = json_decode($aUserFriendInfo[0]['friends'],true);
			$friendIds = '';
			if($aUserFriendInfo[0]['friends']){
				foreach($aUserFriendInfo[0]['friends'] as $friends){
					if($friends){
						$friendIds .= $friends . ',';
					}
				}
				if($friendIds){
					$friendIds = substr($friendIds, 0, -1);
				}
			}
			if($friendIds){
				return explode(',',$friendIds);
			}else{
				return $friendIds;
			}
		}
	}

	/*========================从sns模型转过来的说说方法===============================*/

	public function getShuoshuoDetailInfo($shuoshuoId){
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoInfo = $oShuoshuo->get('', array('id' => $shuoshuoId));
		if($aShuoshuoInfo){
			$aShuoshuoInfo = $this->_getShuoshuoDetailList($aShuoshuoInfo);
			return $aShuoshuoInfo[0];
		}
		return $aShuoshuoInfo;
	}

	//给说说补充评论及用户信息
	private function _getShuoshuoDetailList($aShuoshuoList){
		if($aShuoshuoList === false){
			return false;
		}elseif(!$aShuoshuoList){
			return $aShuoshuoList;
		}else{
			$shuoshuoIds = '';
			$userIds = '';
			$shuoshuoSourceIds = '';
			foreach($aShuoshuoList as $aShuoshuo){
				if($aShuoshuo['source_id']){
					$shuoshuoSourceIds .= $aShuoshuo['source_id'] . ',';
				}
				$shuoshuoIds .= $aShuoshuo['id'] . ',';
				$userIds .= $aShuoshuo['user_id'] . ',';
				if($aShuoshuo['support']){
					$userIds .= $aShuoshuo['support'] . ',';
				}
			}
			$shuoshuoIds = substr($shuoshuoIds, 0, -1);
			$aSourceShuoshuoList = array();
			if($shuoshuoSourceIds){
				$shuoshuoSourceIds = substr($shuoshuoSourceIds, 0, -1);
				$aShuoshuoSourceIds = explode(',', $shuoshuoSourceIds);
				$aShuoshuoSourceIds = array_unique($aShuoshuoSourceIds);
				if($aShuoshuoSourceIds){
					$oShuoshuo = new Model(T_SNS_SHUOSHUO);
					$aSourceShuoshuoList = $oShuoshuo->get('', array('id' => array('in', $aShuoshuoSourceIds)));
					foreach($aSourceShuoshuoList as $aSourceShuoshuo){
						$userIds .= $aSourceShuoshuo['user_id'] . ',';
					}
					if($aSourceShuoshuoList === false){
						return false;
					}
				}
			}

			//查出当前说说的所有评论
			$oShuoshuoComment = new Model(T_SNS_SHUOSHUO_COMMENT);
			$aShuoshuoCommentList = $oShuoshuoComment->get('', '`shuoshuo_id` in (' . $shuoshuoIds . ')', '`id` ASC');
			if($aShuoshuoCommentList === false){
				return false;
			}elseif($aShuoshuoCommentList){
				foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
					$userIds .= $aShuoshuoComment['user_id'] . ',';
					if($aShuoshuoComment['replyed_user_id']){
						$userIds .= $aShuoshuoComment['replyed_user_id'] . ',';
					}
					$aShuoshuoCommentList[$key]['create_time'] = date('Y-m-d H:i:s', $aShuoshuoComment['create_time']);
					$aCommentRefer[$aShuoshuoComment['id']] = &$aShuoshuoCommentList[$key];
				}
			}

			//查出当前页面的所有的用户名
			$userIds = substr($userIds, 0, -1);
			$aUserIds = explode(',', $userIds);
			$aUserIds = array_unique($aUserIds);
			$oUser = new Model(T_PERSONAL);
			$aUserList = $oUser->get('`id`,`name`,`profile`', array('id' => array('in', $aUserIds)));
			foreach($aUserList as $key => $value){
				$aUserRefer[$value['id']] = &$aUserList[$key];
			}
			$aCommentTree = array();
			//组装评论结构
			if($aShuoshuoCommentList){
				foreach($aShuoshuoCommentList as $key => $aShuoshuoComment){
					//找出评论的用户名
					$aShuoshuoCommentList[$key]['user_info'] = $aUserRefer[$aShuoshuoComment['user_id']];
					if($aShuoshuoComment['replyed_user_id']){
						$aShuoshuoCommentList[$key]['replyed_user_info'] = $aUserRefer[$aShuoshuoComment['replyed_user_id']];
					}
					if(!$aShuoshuoComment['parent_id']){
						$aCommentTree[] = &$aShuoshuoCommentList[$key];
					}else{
						$parentId = $aShuoshuoComment['parent_id'];
						if(isset($aCommentRefer[$parentId])){
							$aParent = &$aCommentRefer[$parentId];
							$aParent['child'][] = &$aShuoshuoCommentList[$key];
						}
					}
				}
			}
			//找出被转发的说说的用户名
			foreach($aSourceShuoshuoList as &$aSourceShuoshuo){
				//找出说说的用户名
				$aSourceShuoshuo['user_info'] = $aUserRefer[$aSourceShuoshuo['user_id']];
			}
			unset($aSourceShuoshuo);
			//组装数据
			foreach($aShuoshuoList as &$aShuoshuo){
				//找出说说的用户名
				$aShuoshuo['user_info'] = $aUserRefer[$aShuoshuo['user_id']];
				//如果有转发的说说，找出原来的说说
				if($aShuoshuo['source_id']){
					foreach($aSourceShuoshuoList as $aSourceShuoshuo){
						if($aShuoshuo['source_id'] == $aSourceShuoshuo['id']){
							$aShuoshuo['source_shuoshuo'] = $aSourceShuoshuo;
							break;
						}
					}
				}
				//拼装说说的评论
				foreach($aCommentTree as $aComment){
					if($aComment['shuoshuo_id'] == $aShuoshuo['id']){
						$aShuoshuo['comment'][] = $aComment;
					}
				}
				//顶的次数
				if($aShuoshuo['support']){
					$aSupportUser = explode(',', $aShuoshuo['support']);
					$aShuoshuo['support_times'] = count($aSupportUser);
					foreach($aSupportUser as $userId){
						$aShuoshuo['support_user'][] = $aUserRefer[$userId];
					}
				}else{
					$aShuoshuo['support_times'] = 0;
				}
			}
			return $aShuoshuoList;
		}
	}

	//我的说说条数
	public function getShuoshuoCountByUserId($userId, $type=0){
		if($type){
			$where = '`user_id`=' . $userId . ' AND `create_time`<=' . time() .' AND `create_time`>' . strtotime(date('Y-m-d'));
		}else{
			$where = '`user_id`=' . $userId;
		}
		$oShuoshuo = new Model(T_SNS_SHUOSHUO);
		$aShuoshuoCountInfo = $oShuoshuo->get('count(*) as `nums`', $where);
		if($aShuoshuoCountInfo){
			return $aShuoshuoCountInfo[0]['nums'];
		}
		return $aShuoshuoCountInfo;
	}

	//赛事动态---右侧栏用
	public function getEventListForMatch($aUserIdList = array(), $eventType = array(9, 11, 12, 17), $page = 1, $pageSize = 10, $matchId = 0){
		if(!is_array($aUserIdList)){
			return false;
		}
		if(!is_array($eventType) || !$eventType){
			return false;
		}
		$offect = ($page - 1) * $pageSize;
		$oEvent = new Model(T_SNS_EVENT);
		$order = '`id` desc';
		if($matchId){
			$fields = '`t1`.*';
			$where = '`t1`.`type` in (' . implode(',', $eventType) . ')';
			if($aUserIdList){
				$where .= ' AND ';
				if(count($aUserIdList) == 1){
					$where .= '`t1`.`user_id`=' . $aUserIdList[0];
				}else{
					$where .= '`t1`.`user_id` in (' . implode(',', $aUserIdList) . ')';
				}
			}
			$where .= ' AND `match_relation`.`match_id`=' . $matchId;
			$oDboi = new DBOI();
			$aEventList = $oDboi->fields($fields)->table(T_SNS_EVENT)->leftjoin(T_MATCH_USER_RELATION, 'as `match_relation` on `t1`.`data_id`=`match_relation`.`id`')->where($where)->orderby($order)->select();
			if($aEventList === false){
				return false;
			}
			$eventLength = count($aEventList);
			$aEventList = array_slice($aEventList, $offect, $pageSize);
			if($eventLength < $page * $pageSize && $page < 11){
				$length = count($aEventList);
				$where = '`type` in (' . implode(',', $eventType) . ')';
				if($aUserIdList){
					$where .= ' AND ';
					if(count($aUserIdList) == 1){
						$where .= '`user_id`=' . $aUserIdList[0];
					}else{
						$where .= '`user_id` in (' . implode(',', $aUserIdList) . ')';
					}
				}
				$aDataIds = array();
				foreach($aEventList as $aEvent){
					$aDataIds[] = $aEvent['data_id'];
				}
				if($aDataIds){
					$where .= ' AND `data_id` not in (' . implode(',', $aDataIds) . ')';
				}
				$offect2 = $page * $pageSize - $eventLength;
				$aAllEventList = $oEvent->get('', $where, $order, $offect2, $pageSize - $length);
				$aEventList = array_merge($aEventList, $aAllEventList);
			}
		}else{
			$where = '`type` in (' . implode(',', $eventType) . ')';
			if($aUserIdList){
				$where .= ' AND ';
				if(count($aUserIdList) == 1){
					$where .= '`user_id`=' . $aUserIdList[0];
				}else{
					$where .= '`user_id` in (' . implode(',', $aUserIdList) . ')';
				}
			}
			$aEventList = $oEvent->get('', $where, $order, $offect, $pageSize);
		}
		if(!$aEventList){
			return $aEventList;
		}
		$aMatchUserRelationIds = array();
		$aUserIds = array();
		foreach($aEventList as $aEvent){
			$aUserIds[] = $aEvent['user_id'];
			$aMatchUserRelationIds[] = $aEvent['data_id'];
		}
		$oMatchUserRelation = new Model(T_MATCH_USER_RELATION);
		$aMatchUserRelationList = $oMatchUserRelation->get('`id`,`match_id`,`create_time`,`first_join_time`,`first_finish_time`,`last_rejoin_time`', array('id' => array('in', $aMatchUserRelationIds)));
		if(!$aMatchUserRelationList){
			return $aMatchUserRelationList;
		}
		$aMatchIds = array();
		foreach($aMatchUserRelationList as $aMatchUserRelation){
			$aMatchIds[] = $aMatchUserRelation['match_id'];
		}
		$aUserList = getUserListByUserIds($aUserIds);
		$oMatch = new Model(T_MATCH);
		$aMatchList = $oMatch->get('`id`,`name`,`grade_id`,`subject_id`', array('id' => array('in', $aMatchIds)));
		foreach($aEventList as &$aEvent){
			foreach($aMatchUserRelationList as $aMatchUserRelation){
				if($aMatchUserRelation['id'] == $aEvent['data_id']){
					foreach($aMatchList as $aMatch){
						if($aMatch['id'] == $aMatchUserRelation['match_id']){
							$aMatchUserRelation['match_name'] = $aMatch['name'];
							$aMatchUserRelation['grade_id'] = $aMatch['grade_id'];
							$aMatchUserRelation['subject_id'] = $aMatch['subject_id'];
							break;
						}
					}
					$aEvent['data'] = $aMatchUserRelation;
					break;
				}
			}
			foreach($aUserList as $aUser){
				if($aUser['id'] == $aEvent['user_id']){
					$aEvent['user_info'] = $aUser;
					break;
				}
			}
		}
		return $aEventList;
	}

}