<?php
class RechargeModel{
	/**
	 * 支付类型
	 */
	const PAY_TYPE_UB_CARD = 1;	//U币卡
	const PAY_TYPE_MONTH_CARD = 2;	//月费卡
	const PAY_TYPE_EXPERIENCE_CARD = 3;	//体验卡
	const PAY_TYPE_UB = 4;	//UB
	const PAY_TYPE_ALIPAY = 5;	//支付宝

	/**
	 * 充值卡类型
	 */
	const CARD_UB = 1;	//U币卡
	const CARD_MONTH = 2;	//月费卡
	const CARD_EXPERIENCE = 3;	//体验卡

	/**
	 * 充值产品
	 */
	const PRODUCT_UB = 1;	//U币
	const PRODUCT_TIME = 2;	//使用时长
	const PRODUCT_VIP1 = 3;	//普通会员
	const PRODUCT_VIP2 = 4;	//钻石会员
	const PRODUCT_VIP3 = 5;	//白金会员


	private function setCardResourceByCardId($cardId){
		$oCardResource = new Model(T_CARD_RESOURCE);
		$aData = array('is_used' => 1);
		$result = $oCardResource->update($aData, '`card_id`="' . $cardId . '"');
		return $result;
	}

	private  function getCardResource($total){
		$oCardResource = new Model(T_CARD_RESOURCE);
		$where = '`is_used`=2';
		$count = $this->getResourceCount();
		if(!$count || $count < $total){
			return false;
		}
		$aCardList = $oCardResource->get('', $where, 'id', 0, $total);
		if($aCardList){
			$firstId = $aCardList[0]['id'];
			$lastId = $aCardList[$total-1]['id'];
			$where = '`id` >= '. $firstId . ' AND `id` <=' . $lastId;
			$oCardResource->delete($where);
		}
		return $aCardList;
	}

	public function getResourceCount(){
		$oCardResource = new Model(T_CARD_RESOURCE);
		$where = '`is_used`=2';
		$aCardCount = $oCardResource->get('count(*) as `nums`', $where);
		if($aCardCount){
			return $aCardCount[0]['nums'];
		}
		return $aCardCount;
	}

	public function addRecharge($aData){
		$oUbRecharge = new Model(T_RECHARGE);
		$rechargeId = $oUbRecharge->add($aData);
		return $rechargeId;
	}

	public function deleteRechargeById($rechargeId){
		$oUbRecharge = new Model(T_RECHARGE);
		$result = $oUbRecharge->delete(array('id' => $rechargeId));
		return $result;
	}

	public function getRechargeInfoById($rechargeId){
		$oUbRecharge = new Model(T_RECHARGE);
		$aRechargeInfo = $oUbRecharge->get('', array('id' => $rechargeId));
		if($aRechargeInfo){
			return $aRechargeInfo[0];
		}else{
			return $aRechargeInfo;
		}
	}

	public function getRechargeInfoByUserIdAndPayType($userId, $payType){
		$oUbRecharge = new Model(T_RECHARGE);
		$aRechargeInfo = $oUbRecharge->get('', '`user_id` = ' . $userId . ' AND `pay_type` = ' . $payType);
		if($aRechargeInfo){
			return $aRechargeInfo[0];
		}else{
			return $aRechargeInfo;
		}
	}

	public function getRechargeList($page, $pageSize, $oreder = '`id` desc', $id = 0, $serialNumber = '', $userId = '', $quantity = 0, $payMoney = 0, $createTime = 0, $proxyId = 0, $byProxyId, $payType = 0, $type = 0, $payFinish = ''){
		$where = $this->_getRechargeStatisticsWhere($id, $serialNumber, $userId, $quantity, $payMoney, $createTime, $proxyId, $byProxyId, $payType, $type, $payFinish);
		$oUbRecharge = new Model(T_RECHARGE);
		$offect = ($page - 1) * $pageSize;
		$aRechargeList = $oUbRecharge->get('', $where, $oreder, $offect, $pageSize);
		return $aRechargeList;
	}

	public function setRechargeById($aData){
		$oUbRecharge = new Model(T_RECHARGE);
		$result = $oUbRecharge->update($aData, array('id' => $aData['id']));
		return $result;
	}

	private function _getRechargeStatisticsWhere($id = 0, $serialNumber = '', $userId = '', $quantity = 0, $payMoney = 0, $createTime = 0, $proxyId = 0, $byProxyId = 0, $payType = 0, $type = 0, $payFinish = ''){
		$where = '';
		if($id > 0){
			$where .= ' `id`=' . $id;
		}

		if($serialNumber){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `serial_number`="' . $serialNumber . '"';
		}


		if($userId !== ''){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `user_id`=' . intval($userId);
		}

		if($quantity > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `quantity`=' . $quantity;
		}

		if($payMoney > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `pay_money`=' . $payMoney;
		}

		if($createTime > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `create_time`=' . $createTime;
		}

		if($proxyId > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `proxy_user_id`=' . $proxyId;
		}

		if($byProxyId > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `by_proxy_user_id`=' . $byProxyId;
		}

		if($payType > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `pay_type`=' . $payType;
		}

		if($type > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `type`=' . $type;
		}

		if($payFinish == '0' || $payFinish == '1'){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `pay_finish`=' . $payFinish;
		}

		return $where;

	}

	public function getRechargeStatistics($id = 0, $serialNumber = '', $userId = '', $quantity = 0, $payMoney = 0, $createTime = 0, $proxyId = 0, $byProxyId = 0, $payType = 0, $type = 0, $payFinish = '' ){
		$where = $this->_getRechargeStatisticsWhere($id, $serialNumber, $userId, $quantity, $payMoney, $createTime, $proxyId, $byProxyId, $payType, $type, $payFinish);
		$oRecharge = new Model(T_RECHARGE);
		$aCount = $oRecharge->get('count(*) as `nums`', $where);
		if($aCount){
			return $aCount[0]['nums'];
		}
		return $aCount;
	}

	public function getProxyRechargeStatistics($type = 0, $proxyId = 0, $byProxyId = 0){
		$where = '';
		if($type == 0){
			$where = ' `proxy_user_id`=' . $proxyId . ' OR `by_proxy_user_id`=' . $byProxyId;
		}

		if($type == 1){
			$where = ' `by_proxy_user_id`=' . $byProxyId;
		}

		if($type == 2){
			$where = ' `proxy_user_id`=' . $proxyId;
		}

		$oRecharge = new Model(T_RECHARGE);
		$aCount = $oRecharge->get('count(*) as `nums`', $where);
		if($aCount){
			return $aCount[0]['nums'];
		}
		return $aCount;
	}

	public function getProxyRechargeList($page, $pageSize, $oreder = '`id` desc', $type = 0, $proxyId = 0, $byProxyId = 0 ){
		//$where = $this->_getRechargeStatisticsWhere($id, $serialNumber, $userId, $quantity, $payMoney, $createTime, $proxyId, $payType, $type, $payFinish);
		$where = '';
		if($type == 0){
			$where = ' `proxy_user_id`=' . $proxyId . ' OR `by_proxy_user_id`=' . $byProxyId;
		}

		if($type == 1){
			$where = ' `by_proxy_user_id`=' . $byProxyId;
		}

		if($type == 2){
			$where = ' `proxy_user_id`=' . $proxyId;
		}
		$oUbRecharge = new Model(T_RECHARGE);
		$offect = ($page - 1) * $pageSize;
		$aRechargeList = $oUbRecharge->get('', $where, $oreder, $offect, $pageSize);
		return $aRechargeList;
	}

	public function getUbOrMothCountByUserId($userId, $type = 1){
		$oRecharge = new Model(T_RECHARGE);
		$aCount = $oRecharge->get('sum(quantity) as `nums`', ' `pay_finish`=1 AND `user_id`=' . $userId . ' AND `type`=' . $type);
		if($aCount){
			if($aCount[0]['nums'] == NULL){
				return 0;
			}else{
				return $aCount[0]['nums'];
			}

		}
		return $aCount;
	}

	public function getUbOrMothUsedCountByUserId($userId){
		$oUsed = new Model(T_UB_USED);
		$aCount = $oUsed->get('sum(ub) as `nums`', ' `user_id`=' . $userId);
		if($aCount){
			if($aCount[0]['nums'] == NULL){
				return 0;
			}else{
				return $aCount[0]['nums'];
			}

		}
		return $aCount;
	}

	private function _parseBatchListCondition($batchId = 0, $money = 0, $overTime = '', $createTime = '', $cardType = 0, $isRelease='', $isRecycle = '', $proxyId = 0){
		$where = '';
		if(preg_match('/^\d{10}$/', $batchId)){
			$where .= ' `batch_id` = ' . $batchId;
		}

		if($money > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `card_money`=' . $money;
		}

		if($overTime){
			$tmpOverTime = strtotime($overTime);
			if(date('Y-m-d',$tmpOverTime) == $overTime){
				if($where){
					$where .= ' AND ';
				}
				$where .= ' `over_time`=' . $tmpOverTime;
			}
		}

		if($createTime){
			$tmpCreateTime = strtotime($createTime);
			if(date('Y-m-d',$tmpCreateTime)){
				if($where){
					$where .= ' AND ';
				}
				$where .= ' `create_time`=' . $tmpCreateTime;
			}
		}

		if($cardType == 1 || $cardType == 2 || $cardType == 3){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `card_type`=' . $cardType;
		}

		if($isRelease == '0' || $isRelease == '1'){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `is_release`=' . intval($isRelease);
		}


		if($isRecycle == '0' || $isRecycle == '1'){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `is_recycle`=' . intval($isRecycle);
		}
		if($proxyId >0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `proxy_id`=' . $proxyId;
		}
		return $where;
	}

	public function getBatchList($batchId = 0, $money = 0, $overTime = '', $createTime = '', $cardType = 0, $isRelease='', $isRecycle = '', $proxyId = 0, $page, $pageSize, $oreder = '`id` desc'){
		$where = $this->_parseBatchListCondition($batchId, $money, $overTime, $createTime, $cardType, $isRelease, $isRecycle, $proxyId);
		$oBatch = new Model(T_BATCH);
		$offect = ($page - 1) * $pageSize;
		$aBatchList = $oBatch->get('', $where, $oreder, $offect, $pageSize);
		return $aBatchList;
	}

	public function getBatchCount($batchId = 0, $money = 0, $overTime = '', $createTime = '', $cardType = 0, $isRelease='',  $isRecycle = '', $proxyId = 0){
		$where = $this->_parseBatchListCondition($batchId, $money, $overTime, $createTime, $cardType, $isRelease, $isRecycle, $proxyId);

		$oBatch = new Model(T_BATCH);
		$aBatchCountInfo = $oBatch->get('count(*) as `nums`', $where);
		if($aBatchCountInfo){
			return $aBatchCountInfo[0]['nums'];
		}
		return $aBatchCountInfo;
	}

	public function getBatchInfoById($Id){
		$oBatch = new Model(T_BATCH);
		$aBatchInfo = $oBatch->get('', array('id' => $Id));
		if($aBatchInfo){
			return $aBatchInfo[0];
		}else{
			return $aBatchInfo;
		}

	}

	public function getBatchInfoByBatchId($batchId){
		$oBatch = new Model(T_BATCH);
		$aBatchInfo = $oBatch->get('', '`batch_id`=' . $batchId);
		if($aBatchInfo){
			return $aBatchInfo[0];
		}else{
			return $aBatchInfo;
		}

	}

	public function addBatch($aData){
		$oBatch = new Model(T_BATCH);
		return $oBatch->add($aData);
	}

	public function setBatch($aData){
		$oUbRecharge = new Model(T_BATCH);
		$result = $oUbRecharge->update($aData, array('id' => $aData['id']));
		return $result;
	}

	private function _parseUbRechargeCardListCondition($cardId, $batchId, $isPayed){
		$where = '';
		if(preg_match('/^[A-Z0-9]{20}$/', $cardId)){
			$cardRealId = substr($cardId, 0, 9);
			$cardPwd = substr($cardId, 9, 20);
			$where .= " `card_id` = '" . $cardRealId."' AND `password`='" . $cardPwd . "'";
		}
		if(preg_match('/^\d{10}$/', $batchId)){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `batch_id`=' . $batchId;
		}
		if($isPayed !== ''){
			if($isPayed == 0 || $isPayed == 1){
				if($where){
					$where .= ' AND ';
				}
				$where .= ' `is_payed` = ' . $isPayed;
			}
		}
		return $where;
	}

	/**
	 * 添加一批U币充值卡
	 * @param type $aBatch 批次的信息
	 * @return int 添加的卡片张数
	 */
	public function addUbRechargeCard($aBatch){
		return $this->_addCardFromCardResource($aBatch, self::PRODUCT_UB);
	}

	private function _addCardFromCardResource($aBatch, $type){
		//从充值卡资源表中读出可分配的充值卡
		$oDb = new DBOI();
		$aResourceCardList = $oDb->table(T_CARD_RESOURCE)->where('`is_used` = 2')->limit($aBatch['card_quantity'])->select();
		if(!$aResourceCardList){
			return $aResourceCardList;
		}

		//判断读出来实际可用的充值卡数量
		$cardNums = count($aResourceCardList);
		if($cardNums < $aBatch['card_quantity']){
			//比要求的数量少就取这个数量
			$aBatch['card_quantity'] = $cardNums;
		}
		//创建批次信息
		$id = $oDb->table(T_BATCH)->data($aBatch)->insert();
		if(!$id){
			myLog('添加U币充值时创建批次信息失败');
			return $id;
		}

		//组装充值卡数据列表,由于SQL语句长度限制,所以每100张卡片数据分为一组
		$aCardGroupList = array();
		$aData = array(
			'batch_id' => $aBatch['batch_id'],
			'is_payed' => 0,
			'payed_time' => 0,
		);
		$i = 0;
		$aCardIdGroupList = array();	//该组卡片的ID集
		foreach($aResourceCardList as $key => $aCard){
			$aCardGroupList[$i][] = array_merge(array(
				'card_id' => $aCard['card_id'],
				'password' => $aCard['password'],
			), $aData);
			$aCardIdGroupList[$i][] = $aCard['id'];
			if($key % 99 == 0){
				//达到100条,分组号步进1
				$i++;
			}
		}

		//遍历每一组卡片数据开始添加
		$cardTable = '';
		if($type == self::PRODUCT_UB){
			$cardTable = T_UB_RECHARGE_CARD;
		}elseif($type == self::PRODUCT_TIME){
			$cardTable = T_MONTHLY_FEE_RECHARGE_CARD;
		}
		foreach($aCardGroupList as $key => $aCardList){
			$id = $oDb->table($cardTable)->data($aCardList)->insert();
			if($id){
				$rows = $oDb->table(T_CARD_RESOURCE)->where(array( 'id' => array('in', $aCardIdGroupList[$key])))->delete();	//删除资源表的可分配卡片
				if(!$rows){
					$oDb->rollBack();
					myLog('添加U币充值卡后删除卡片资源失败');
					return false;
				}
			}
		}

		return $cardNums;
	}

	private function _getBatchList($money = 0, $createTime = '', $overTime = '', $isRelease = '', $isRecycle = '', $proxyId = 0, $cardType){
		$where = '';
		if($money > 0 && $money < 10000){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `card_money`=' . $money;
		}

		if($overTime){
			$tmpOverTime = strtotime($overTime);

			if(date('Y-m-d', $tmpOverTime) == $overTime){
				if($where){
					$where .= ' AND ';
				}
				$where .= ' `over_time`=' . $tmpOverTime;
			}
		}
		if($createTime){
			$tmpCreateTime = strtotime($createTime);
			if(date('Y-m-d', $tmpCreateTime)){
				if($where){
					$where .= ' AND ';
				}
				$where .= ' `create_time`=' . $tmpCreateTime;
			}
		}
		if($isRelease == '0' || $isRelease == '1'){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `is_release`=' . intval($isRelease);
		}
		if($isRecycle == '0' || $isRecycle == '1'){
			if($where){
				$where .= ' AND ';
			}

			$where .= ' `is_recycle`=' . intval($isRecycle);
		}

		if($proxyId > 0){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `proxy_id`=' . $proxyId;
		}
		if($cardType == 1 || $cardType == 2 || $cardType == 3){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `card_type`=' . $cardType;

		}
		$oBatch = new Model(T_BATCH);
		$aBatchList = $oBatch->get('', $where);
		return $aBatchList;
	}

	public function getUbRechargeCardList($cardId = '', $batchId = 0, $isPayed = '', $money = 0, $createTime = '', $overTime = '', $isRelease = 0, $isRecycle = 0, $proxyId = '', $page = 1, $pageSize = 10, $oreder = '`id` desc'){
		$where = $this->_parseUbRechargeCardListCondition($cardId, $batchId, $isPayed);
		$aBatchList = $this->_getBatchList($money, $createTime, $overTime, $isRelease, $isRecycle, $proxyId, $cardType = 1);
		if($aBatchList){
			$aBatchIds = array();
			foreach($aBatchList as $aBatch){
				$aBatchIds[] = $aBatch['batch_id'];
			}
			if($where){
				$where .= ' AND ';
			}
			$where .= '`batch_id` in(' . implode(',', $aBatchIds) . ')';
			$oUbRechargeCard = new Model(T_UB_RECHARGE_CARD);
			$offect = ($page - 1) * $pageSize;
			$aCardList = $oUbRechargeCard->get('', $where, $oreder, $offect, $pageSize);
			$aProxy = m('Proxy');
			foreach($aCardList as $cardKey => &$aCard){
				foreach($aBatchList as $batchKey => $aBatch){
					if($aCard['batch_id'] == $aBatch['batch_id']){
						$aCard = array_merge($aCard, array(
							'money' => $aBatch['card_money'],
							'proxy_id' => $aBatch['proxy_id'],
							'is_release' => $aBatch['is_release'],
							'is_recycle' => $aBatch['is_recycle'],
							'over_time' => $aBatch['over_time'],
							'create_time' => $aBatch['create_time'])
						);
						if($aCard['proxy_id']){
							$aProxyInfo = $aProxy->getProxyUserInfoById($aCard['proxy_id']);
							if($aProxyInfo){
								$aCardList[$cardKey]['proxyName'] = $aProxyInfo['name'];
							}
						}else{
							$aCardList[$cardKey]['proxyName'] = '未指定';
						}
					}
				}
			}
		}else{
			$aCardList = array();
		}
		return $aCardList;
	}

	public function getUbRechargeCardCount($cardId = '', $batchId = 0, $isPayed = '', $money = 0, $createTime = '', $overTime = '', $isRelease = 0, $isRecycle = 0, $proxyId = ''){
		$where = $this->_parseUbRechargeCardListCondition($cardId, $batchId, $isPayed);
		$aBatchList = $this->_getBatchList($money, $createTime, $overTime, $isRelease, $isRecycle, $proxyId, $cardType = 1);
		if($aBatchList){
			$aBatchIds = array();
			foreach($aBatchList as $aBatch){
				$aBatchIds[] = $aBatch['batch_id'];
			}
			if($where){
				$where .= ' AND ';
			}
			$where .= '`batch_id` in(' . implode(',', $aBatchIds) . ')';
			$oUbRechargeCard = new Model(T_UB_RECHARGE_CARD);
			$aUbRechargeCardCountInfo = $oUbRechargeCard->get('count(*) as `nums`', $where);
			if($aUbRechargeCardCountInfo){
				return $aUbRechargeCardCountInfo[0]['nums'];
			}
			return $aUbRechargeCardCountInfo;
		}else{
			return 0;
		}
	}

	public function getUbRechargeCardInfoById($Id){
		$oUbRecharge = new Model(T_UB_RECHARGE_CARD);
		$aUbRechargeCardInfo = $oUbRecharge->get('', array('id' => $Id));
		if($aUbRechargeCardInfo){
			return $aUbRechargeCardInfo[0];
		}else{
			return $aUbRechargeCardInfo;
		}
	}

	public function getUbRechargeCardInfoByCardId($cardId){
		$aCardId = $this->parseCardId($cardId);
		$oUbRecharge = new Model(T_UB_RECHARGE_CARD);
		$aUbRechargeCardInfo = $oUbRecharge->get('', "`card_id` = '" . $aCardId['id'] . "' AND `password` = '" . $aCardId['password'] . "'");
		if($aUbRechargeCardInfo){
			return $aUbRechargeCardInfo[0];
		}else{
			return $aUbRechargeCardInfo;
		}
	}

	public function setUbRechargeCardById($aData){
		$oUbRecharge = new Model(T_UB_RECHARGE_CARD);
		$result = $oUbRecharge->update($aData, array('id' => $aData['id']));
		return $result;
	}

	public function setUbRechargeCardByBatchId($aData, $batchId){
		$oUbRecharge = new Model(T_UB_RECHARGE_CARD);
		$result = $oUbRecharge->update($aData, '`batch_id`=' . $batchId);
		return $result;
	}

	/**
	 * 添加一批月费充值卡
	 * @param type $aBatch 批次的信息
	 * @return int 添加的卡片张数
	 */
	public function addMonthlyFeeRechargeCard($aBatch){
		return $this->_addCardFromCardResource($aBatch, self::PRODUCT_TIME);
	}

	private function _parseMonthlyFeeRechargeCardListCondition($cardId = '', $batchId = 0, $month=0, $isPayed = ''){
		$where = '';
		if(preg_match('/^[A-Z0-9]{20}$/', $cardId)){
			$cardRealId = substr($cardId, 0, 9);
			$cardPwd = substr($cardId, 9, 20);
			$where .= " `card_id` = '" . $cardRealId."' AND `password`='" . $cardPwd . "'";
		}

		if(preg_match('/^\d{10}$/', $batchId)){
			if($where){
				$where .= ' AND ';
			}
			$where .= ' `batch_id`=' . $batchId;
		}


		if($isPayed == '0' || $isPayed == '1'){

			if($where){
				$where .= ' AND ';
			}
			$where .= ' `is_payed`=' . intval($isPayed);
		}
		return $where;
	}

	public function getMonthlyFeeRechargeCardCount($cardId = '', $batchId = 0, $isPayed = '', $month = 0, $createTime = '', $overTime = '', $cardType = 2, $isRelease = 0, $isRecycle = 0, $proxyId = ''){

		$where = $this->_parseMonthlyFeeRechargeCardListCondition($cardId, $batchId, $month, $isPayed);
		$aBatchList = $this->_getBatchList($month, $createTime, $overTime, $isRelease, $isRecycle, $proxyId, $cardType);
		if($aBatchList){
			$aBatchIds = array();
			foreach($aBatchList as $aBatch){
				$aBatchIds[] = $aBatch['batch_id'];
			}
			if($where){
				$where .= ' AND ';
			}
			$where .= '`batch_id` in(' . implode(',', $aBatchIds) . ')';
			$oMonthlyFeeRechargeCard = new Model(T_MONTHLY_FEE_RECHARGE_CARD);
			$aMonthlyFeeRechargeCardCountInfo = $oMonthlyFeeRechargeCard->get('count(*) as `nums`', $where);
			if($aMonthlyFeeRechargeCardCountInfo){
				return $aMonthlyFeeRechargeCardCountInfo[0]['nums'];
			}else{
				return $aMonthlyFeeRechargeCardCountInfo;
			}
		}else{
			return 0;
		}
	}

	public function getMonthlyFeeRechargeCardList($cardId = '', $batchId = 0, $isPayed = '', $month = 0, $createTime = '', $overTime = '', $cardType = 2, $isRelease = 0, $isRecycle = 0, $proxyId = '', $page = 1, $pageSize = 10, $oreder = '`id` desc'){
		$where = $this->_parseMonthlyFeeRechargeCardListCondition($cardId, $batchId, $isPayed);
		$aBatchList = $this->_getBatchList($month, $createTime, $overTime, $isRelease, $isRecycle, $proxyId, $cardType);
		if($aBatchList){
			$aBatchIds = array();
			foreach($aBatchList as $aBatch){
				$aBatchIds[] = $aBatch['batch_id'];
			}
			if($where){
				$where .= ' AND ';
			}
			$where .= '`batch_id` in(' . implode(',', $aBatchIds) . ')';
			$oMonthlyFeeRechargeCard = new Model(T_MONTHLY_FEE_RECHARGE_CARD);
			$offect = ($page - 1) * $pageSize;
			$aMonthCardList = $oMonthlyFeeRechargeCard->get('', $where, $oreder, $offect, $pageSize);
			$aProxy = m('Proxy');
			foreach($aMonthCardList as $cardKey => &$aCard){
				foreach($aBatchList as $batchKey => $aBatch){
					if($aCard['batch_id'] == $aBatch['batch_id']){
						$aCard = array_merge($aCard, array(
							'month' => $aBatch['card_money'],
							'card_type' => $aBatch['card_type'],
							'proxy_id' => $aBatch['proxy_id'],
							'is_release' => $aBatch['is_release'],
							'is_recycle' => $aBatch['is_recycle'],
							'over_time' => $aBatch['over_time'],
							'create_time' => $aBatch['create_time'])
						);
						if($aCard['proxy_id']){
							$aProxyInfo = $aProxy->getProxyUserInfoById($aCard['proxy_id']);
							if($aProxyInfo){
								$aMonthCardList[$cardKey]['proxyName'] = $aProxyInfo['name'];
							}
						}else{
							$aMonthCardList[$cardKey]['proxyName'] = '未指定';
						}
					}
				}
			}
		}else{
			$aMonthCardList = array();
		}
		return $aMonthCardList;
	}

	public function setMonthlyFeeRechargeCardById($aData){
		$oMonthlyFeeRechargeCard = new Model(T_MONTHLY_FEE_RECHARGE_CARD);
		return $oMonthlyFeeRechargeCard->update($aData, array('id' => $aData['id']));
	}

	public function getMonthlyFeeRechargeCardInfoById($Id){
		$oMonthlyFeeRechargeCard = new Model(T_MONTHLY_FEE_RECHARGE_CARD);
		$aMonthlyFeeRechargeCardInfo = $oMonthlyFeeRechargeCard->get('', array('id' => $Id));
		if($aMonthlyFeeRechargeCardInfo){
			return $aMonthlyFeeRechargeCardInfo[0];
		}else{
			return $aMonthlyFeeRechargeCardInfo;
		}
	}

	public function setMonthlyFeeRechargeCardByBatchId($aData, $batchId){
		$oMonthlyFeeRechargeCard = new Model(T_MONTHLY_FEE_RECHARGE_CARD);
		$result = $oMonthlyFeeRechargeCard->update($aData, '`batch_id`=' . $batchId);
		return $result;
	}

	public function getMonthlyFeeRechargeCardInfoByCardId($cardId){
		$aCardId = $this->parseCardId($cardId);
		$oMonthlyFeeRechargeCard = new Model(T_MONTHLY_FEE_RECHARGE_CARD);
		$aMonthlyFeeRechargeCardInfo = $oMonthlyFeeRechargeCard->get('', "`card_id` = '" . $aCardId['id'] . "' AND `password` = '" . $aCardId['password'] . "'");
		if($aMonthlyFeeRechargeCardInfo){
			return $aMonthlyFeeRechargeCardInfo[0];
		}else{
			return $aMonthlyFeeRechargeCardInfo;
		}
	}

	/**
	 * 增加用户使用期限
	 * @param int $userId 用户ID
	 * @param int $time　延长的时间
	 * @param string $unit　延长的单位  1=日　　2＝月　 3=年
	 * @return int 到期日的时间戳
	 */
	public function addUserLimitTime($userId, $time, $unit = 1){
		//读出用户信息
		$oUser = m('User');

		$aUser = $oUser->getUserInfoByUserId($userId);
		if($aUser === false){
			return false;
		}elseif(!$aUser){
			return array();
		}

		//计算终止时间
		$aUnit = array('days', 'month', 'year');
		if(!array_key_exists($unit - 1, $aUnit)){
			return false;
		}
		if($aUser['expiration_time'] > 0){
			$aUser['expiration_time'] = strtotime('+' . $time . ' ' . $aUnit[$unit - 1], $aUser['expiration_time']);
		}else{
			$aUser['expiration_time'] = strtotime('+' . $time . ' ' . $aUnit[$unit - 1], time());
		}

		//入库
		$row = $oUser->setUserIndexInfo($aUser);
		if(!$row){
			return false;
		}else{
			return $aUser['expiration_time'];
		}
	}

	public function parseCardId($cardNo){
		return array(
			'id' => substr($cardNo, 0, 9),
			'password' => substr($cardNo, -11),
		);
	}
}