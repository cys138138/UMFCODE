<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-7-23
 */
class EsSingleChoice{

	private $_error = '';
	private $_aShowType = array(
		1,	// '添加题目'
		2,	// '编辑题目'
		3,	//'显示完整题目'
		4,	// '显示问题部分'
		5, 	//'题目回顾'
		6,	//列表显示
		7	//批量添加
	);

	public function __construct(){}

	/**
	 *分解题目数据，返回视图
	 * @param type $type 需要显示的类型
	 * @param type $esData 题目数据，JSON结构
	 * @return String 页面数据
	 */
	public function resolve($encodeEs){
		return $this->_decode($encodeEs);
	}

	/**
	 * 构建JSON数据
	 * @param type $aSource 数据源
	 */
	public function build($aSource = null){
		if(!$aSource){
			$aSource = $_POST;
		}
		if(!$aSource = $this->_checkSource($aSource)){
			return null;
		}

		$aEsData = array(
			'content' => $this->_blockLine2InLine($aSource['content']),
			'answer' => $aSource['answer'],
			'option' => array(),
		);

		$esText = $aEsData['content'];
		if(isset($aSource['image']) && $aSource['image']){
			$aEsData['image'] = $aSource['image'];
			//$esText .= ' ' . implode(' ', $aEsData['image']);
		}

		foreach($aSource['option'] as $key => &$aOption){
			$aEsData['option'][$key]['content'] = $this->_blockLine2InLine($aOption['content']);
			$esText .= ' ' . $aEsData['option'][$key]['content'];
			if(isset($aOption['image'])){
				$aEsData['option'][$key]['image'] = $aOption['image'];
				//$esText .= ' ' . implode(' ', $aOption['image']);
			}
		}

		return array(
			'content_json' => json_encode($aEsData),
			'content_text' => $esText
		);
	}

	/**
	* 转换字符\[ \] 为 \( \)
	* $param 包含\[ \] 的字符串
	*/
	private function _blockLine2InLine($param){
		if(false !== strpos($param, '\[') && false !== strpos($param, '\]')){
			$param = str_replace(array('\[', '\]'), array('\(', '\)'), $param);
		}
		return $param;
	}

	/**
	 * 检查数据源结构是否合法
	 * @param array $aSource 要检查的数据源
	 * @return bool 是否合法的数据源
	 */
	private function _checkSource($aSource){
		if(!is_array($aSource)){
			//如果不是数组
			$this->_error = '非法的题目数据';
			return false;
		}

		//检查题干是否一个字符串
		if(!isset($aSource['content']) || !is_string($aSource['content'])){
			$this->_error = '题干格式错误';
			return false;
		}
		$aSource['content'] = str_replace('<', '&lt;', $aSource['content']);
		$aSource['content'] = str_replace('>', '&gt;', $aSource['content']);
		$aSource['content'] = str_replace('&lt;u&gt;', '<u>', $aSource['content']);
		$aSource['content'] = str_replace('&lt;/u&gt;', '</u>', $aSource['content']);

		//检查题干图片
		if(isset($aSource['image'])){
			//如果有图片键
			if(!is_array($aSource['image'])){
				//但不是数组
				$this->_error = '题干图片格式错误';
				return false;
			}

			//检查图片每一个元素是否一个字符串,并且文件存在
			foreach($aSource['image'] as $image){
				if(!is_string($image)){
					$this->_error = '题干图片格式错误';
					return false;
				}

				if(!file_exists(SYSTEM_RESOURCE_PATH . '/' . $image)){
					$this->_error = '题干图片不存在';
					return false;
				}
			}
		}

		//检查每个答案选项是否为数组,并且带有content属性
		if(!isset($aSource['option'])){
			$this->_error = '答案选项不存在';
			return false;
		}elseif(!is_array($aSource['option'])){
			$this->_error = '答案选项格式错误';
			return false;
		}else{
			foreach($aSource['option'] as $key => $option){
				if(!is_array($option) || !isset($option['content'])){
					$this->_error = '答案选项格式错误';
					return false;
				}elseif(isset($option['image'])){
					//是否数组
					if(!is_array($option['image'])){
						$this->_error = '选项' . ($key + 1) . '的图片格式错误';
						return false;
					}

					//是否存在
					foreach($option['image'] as $image){
						if(!is_string($image)){
							$this->_error = '选项' . ($key + 1) . '的图片格式错误';
							return false;
						}

						if(!file_exists(SYSTEM_RESOURCE_PATH . '/' . $image)){
							$this->_error = '选项' . ($key + 1) . '的图片不存在';
							return false;
						}
					}
				}
				$aSource['option'][$key]['content'] = str_replace('<', '&lt;', $aSource['option'][$key]['content']);
				$aSource['option'][$key]['content'] = str_replace('>', '&gt;', $aSource['option'][$key]['content']);
				$aSource['option'][$key]['content'] = str_replace('&lt;u&gt;', '<u>', $aSource['option'][$key]['content']);
				$aSource['option'][$key]['content'] = str_replace('&lt;/u&gt;', '</u>', $aSource['option'][$key]['content']);
			}
		}

		//检查答案
		if(!isset($aSource['answer']) || !is_numeric($aSource['answer'])){
			//如果没有正确答案
			$this->_error = '答案格式错误';
			return false;
		}
		if(!array_key_exists($aSource['answer'], $aSource['option'])){
			$this->_error = '答案不存在';
			return false;
		}

		return $aSource;
	}

	/**
	 * 获取判断题的答案
	 * @param type $esData
	 * @return type
	 */
	public function getAnswer($esData, $aAnswerIndex = array()){
		//检查题目数据
		if(is_string($esData)){
			$esData = json_decode($esData, true);
		}
		$aEsData = $esData;
		if($this->_error){
			return null;
		}
		return intval($aEsData['answer']);
	}

	/**
	 * 移除题目的答案
	 */
	public function removeAnswer($aEs){
		unset($aEs['answer']);
		return $aEs;
	}

	/**
	 * 判断一个答案的正确性
	 * @param type $esData
	 * @param type $userAnswer
	 * @return type
	 */
	public function getCorrectness($esData, $userAnswer){
		//检查题目数据
		if(!$aEsData = $this->_decode($esData)){
			return null;
		}

		if(!is_string($userAnswer) && !is_numeric($userAnswer)){
			$this->_error = '用户回答格式有错';
			return null;
		}
		$aCorrectness = array();
		if($aEsData['answer'] == $userAnswer){
			$aCorrectness['pass'] = 1;
			$aCorrectness['scale'] = '1/1';
			return $aCorrectness;
		}else{
			$aCorrectness['pass'] = 0;
			$aCorrectness['scale'] = '0/1';
			return $aCorrectness;
		}
	}

	/**
	 * 获取错误信息
	 */
	public function getError(){
		return $this->_error;
	}

	/**
	 * 判断是否含有内联字符
	 * $aEsContent 解析后的结构内容
	 */
	public function hasBlockLine($aEsContent){
		if(strstr($aEsContent['content'], '\[')){
			return true;
		}
		foreach($aEsContent['option'] as $aEsOption){
			if(strstr($aEsOption['content'], '\[')){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 验证一个答案是否合法
	 * @param type $answer 答案下标
	 * @return type
	 */
	public function validateAnswer($answer){
		return is_numeric($answer);
	}

	/**
	 * 解析题目数据
	 * @param type $esData
	 */
	protected function _decode($esData){
		$aEsData = json_decode($esData, true);
		if(json_last_error() != JSON_ERROR_NONE){
			$this->_error = '题目数据非法';
			return null;
		}

		return $aEsData;
	}
}