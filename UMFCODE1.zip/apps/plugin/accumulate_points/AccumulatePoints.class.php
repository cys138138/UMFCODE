<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-9-27
 */
class AccumulatePoints{
	private $_aActionType = array(
		1,	//登录*
		2,	//推荐好友注册*
		3,	//加好友*
		4,	//说说*
		5,	//发表问问*
		6,	//回答问问*
		7,	//评论即凑热闹*
		8,	//第一次修炼成功*
		9,	//第一次挑战成功*
		10,	//挑战成功后继续挑战成功*
		11,	//第一次修炼做对题目*
		12,	//修炼成功后继续修炼做对题目*
		13, //第一次挑战做对题目*
		14,	//挑战成功后做对题目*
		15,	//被好友推荐注册
	);
	
	/**
	 * 添加用户的经验
	 * @param $userId
	 * @param $action
	 * @param $esCount
	 */
	public function addAccumulatePoints($userId, $action, $esCount = 0){
		if(!in_array($action, $this->_aActionType)){
			return false;
		}
		$aUserNumeric = array();
		$aUserNumeric['id'] = $userId;
		$oUserNumerical = m('UserNumerical');
		$aCurrentNumeric = $oUserNumerical->getUserNumericalInfoById($userId);
		if($aCurrentNumeric){
			$aUserNumeric['accumulate_points'] = $aCurrentNumeric['accumulate_points'];
			$currentPoints = $aCurrentNumeric['accumulate_points'];
		}else{
			$aUserNumeric['accumulate_points'] = 0;
			$currentPoints = 0;
		}
		
		$oUserBehavior = m('UserBehavior');
		$aUserBehavior = $oUserBehavior->getUserDailyBehaviorInfo($userId);
		if(!$aUserBehavior){
			$aTodayPoints = array();
			$aTodayPoints['id'] = $userId;
			$aTodayPoints['add_friend_times'] = 0;
			$aTodayPoints['publish_shuoshuo_times'] = 0;
			$aTodayPoints['publish_wenwen_times'] = 0;
			$aTodayPoints['reply_wenwen_times'] = 0;
			$aTodayPoints['comment_times'] = 0;
			$aTodayPoints['first_task_es_count'] = 0;
			$aTodayPoints['more_task_es_count'] = 0;
			$aTodayPoints['first_mission_es_count'] = 0;
			$aTodayPoints['more_mission_es_count'] = 0;
			$aTodayPoints['create_time'] = time();
			if(!$oUserBehavior->addUserDailyBehavior($aTodayPoints)){
				return false;
			}
			$aUserBehavior = $aTodayPoints;
		}
		
		$now = date('Ymd');
		$lastAddPoins = date('Ymd', $aUserBehavior['create_time']);
	
		if($now > $lastAddPoins){
			$aUpdateBehavior = array();
			$aUpdateBehavior['id'] = $userId;
			$aUpdateBehavior['add_friend_times'] = 0;
			$aUpdateBehavior['publish_shuoshuo_times'] = 0;
			$aUpdateBehavior['publish_wenwen_times'] = 0;
			$aUpdateBehavior['reply_wenwen_times'] = 0;
			$aUpdateBehavior['comment_times'] = 0;
			$aUpdateBehavior['first_task_es_count'] = 0;
			$aUpdateBehavior['more_task_es_count'] = 0;
			$aUpdateBehavior['first_mission_es_count'] = 0;
			$aUpdateBehavior['more_mission_es_count'] = 0;
			$aUpdateBehavior['create_time'] = time();
			if($oUserBehavior->setUserDailyBehavior($aUpdateBehavior) === false){
				return false;
			}
			$aUserBehavior = $aUpdateBehavior;
		}

		if($action == 1){
			if($now > $lastAddPoins){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['login'];
			}
		}elseif($action == 2){
			$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['recommend_register'];
		}elseif($action == 3){
			if($aUserBehavior['add_friend_times'] < $GLOBALS['INTEGRATION']['add_friend_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['add_friend'];
				$aUserBehavior['add_friend_times']++;
			}
		}elseif($action == 4){
			if($aUserBehavior['publish_shuoshuo_times'] < $GLOBALS['INTEGRATION']['publish_shuoshuo_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['publish_shuoshuo'];
				$aUserBehavior['publish_shuoshuo_times']++;
			}
		}elseif($action == 5){
			if($aUserBehavior['publish_wenwen_times'] < $GLOBALS['INTEGRATION']['publish_question_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['publish_question'];
				$aUserBehavior['publish_wenwen_times']++;
			}
		}elseif($action == 6){
			if($aUserBehavior['reply_wenwen_times'] < $GLOBALS['INTEGRATION']['answer_question_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['answer_question'];
				$aUserBehavior['reply_wenwen_times']++;
			}
		}elseif($action == 7){
			if($aUserBehavior['comment_times'] < $GLOBALS['INTEGRATION']['comment_es_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['comment_es'];
				$aUserBehavior['comment_times']++;
			}
		}elseif($action == 8){
			if($aUserBehavior['first_task_es_count'] < $GLOBALS['INTEGRATION']['first_finish_task_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['first_finish_task_add'] + $GLOBALS['INTEGRATION']['first_finish_task'];
				$aUserBehavior['first_task_es_count']++;
			}
		}elseif($action == 9){
			if($aUserBehavior['first_mission_es_count'] < $GLOBALS['INTEGRATION']['first_finish_challenge_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['first_finish_challenge'] * $esCount + $GLOBALS['INTEGRATION']['first_finish_challenge_add'];
				$aUserBehavior['first_mission_es_count']++;
			}
		}elseif($action == 10){
			if($aUserBehavior['more_mission_es_count'] < $GLOBALS['INTEGRATION']['after_first_finish_challenge_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['after_first_finish_challenge'] * $esCount + $GLOBALS['INTEGRATION']['after_first_finish_challenge_add'];
				$aUserBehavior['more_mission_es_count']++;
			}
		}elseif($action == 11){
			if($aUserBehavior['first_task_es_count'] < $GLOBALS['INTEGRATION']['first_finish_task_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['first_finish_task'];
				$aUserBehavior['first_task_es_count']++;
			}
		}elseif($action == 12){
			if($aUserBehavior['more_task_es_count'] < $GLOBALS['INTEGRATION']['after_first_finish_task_limit']){
				$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['after_first_finish_task'];
				$aUserBehavior['more_task_es_count']++;
			}
		}elseif($action == 13){
			$aUserBehavior['first_mission_es_count']++;
		}elseif($action == 14){
			$aUserBehavior['more_mission_es_count']++;
		}elseif($action == 15){
			$aUserNumeric['accumulate_points'] = $aUserNumeric['accumulate_points'] + $GLOBALS['INTEGRATION']['register_by_invite'];
		}
		
		
		if($now > $lastAddPoins){
			$aUserBehavior['create_time'] = time();
			
		}
		if($oUserBehavior->setUserDailyBehavior($aUserBehavior) === false){
			return false;
		}
		
		$aResult = array();
		$aResult['add_accumulate_points'] = $aUserNumeric['accumulate_points'] - $currentPoints;
		$aResult['accumulate_points'] = $aUserNumeric['accumulate_points'];
		$aResult['level'] = isset($aCurrentNumeric['level']) ? $aCurrentNumeric['level'] : 1;
		if($aUserNumeric['accumulate_points'] > $currentPoints){
			$aResult['level'] = $this->_updateUserLevel($aUserNumeric['accumulate_points']);
			$aUserNumeric['level'] = $aResult['level'];
			if($oUserNumerical->setUserNumerical($aUserNumeric) === false){
				return false;
			}
			return $aResult;
		}
		return $aResult;
		
	}
	
	/**
	 * 计算用户等级
	 * @param $userId
	 */
	private function _updateUserLevel($points){
		$count = count($GLOBALS['LEVEL']);
		for($i = $count - 1; $i >= 0; $i--){
			if($points >= $GLOBALS['LEVEL'][$i]){
				return $i + 1;
			}
		}
	}
}