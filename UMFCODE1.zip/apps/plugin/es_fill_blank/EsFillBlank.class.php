<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-8-6
 */
class EsFillBlank{

	private $_error = '';
	private $_aShowType = array(
		1,	// '添加题目'
		2,	// '编辑题目'
		3,	//'显示完整题目'
		4,	// '显示问题部分'
		5, 	//'题目回顾'
		6,	//列表显示
		7	//批量添加
	);
	public function __construct(){}

	/**
	 *分解题目数据，返回视图
	 * @param type $type 需要显示的类型
	 * @param type $esData 题目数据，JSON结构
	 * @return String 页面数据
	 */
	public function resolve($encodeEs){
		return $this->_decode($encodeEs);
	}

	/**
	 * 构建JSON数据
	 * @param type $post
	 */
	public function build($aSource = null){
		if(!$aSource){
			$aSource = $_POST;
		}
		if(!$aSource = $this->_checkSource($aSource)){
			return null;
		}

		$aEsData = array(
			'content' => $this->_blockLine2InLine(trim($aSource['content'])),
			'answer' => array(),
		);
		$esText = $aEsData['content'];
		foreach($aSource['answer'] as $i => $aAnswer){
			$aEsData['answer'][$i] = array();
			foreach($aAnswer as $answer){
				$answer = $this->_blockLine2InLine(trim($answer));
				$aEsData['answer'][$i][] = $answer;
				$esText .= ' ' . $answer;
			}
		}
		if(isset($aSource['image']) && $aSource['image']){
			$aEsData['image'] = $aSource['image'];
			//$esText .= ' ' . implode(' ', $aEsData['image']);
		}

		if(isset($aSource['answer_group']) && $aSource['answer_group']){
			$aEsData['answer_group'] = $aSource['answer_group'];
		}

		return array(
			'content_json' => json_encode($aEsData),
			'content_text' => $esText
		);
	}

	/**
	* 转换字符\[ \] 为 \( \)
	* $param 包含\[ \] 的字符串
	*/
	private function _blockLine2InLine($param){
		if(false !== strpos($param, '\[') && false !== strpos($param, '\]')){
			$param = str_replace(array('\[', '\]'), array('\(', '\)'), $param);
		}
		return $param;
	}

	/**
	 * 检查数据源结构是否合法
	 * @param array $aSource 要检查的数据源
	 * @return bool 是否合法的数据源
	 */
	private function _checkSource($aSource){
		//如果不是数组
		if(!is_array($aSource)){
			$this->_error = '非法的题目数据';
			return false;
		}

		//检查题干是否一个字符串
		if(!isset($aSource['content'])){
			$this->_error = '题干内容不存在';
			return false;
		}elseif(!is_string($aSource['content'])){
			$this->_error = '题干内容格式错误';
			return false;
		}
		$aSource['content'] = str_replace('<', '&lt;', $aSource['content']);
		$aSource['content'] = str_replace('>', '&gt;', $aSource['content']);
		$aSource['content'] = str_replace('&lt;u&gt;', '<u>', $aSource['content']);
		$aSource['content'] = str_replace('&lt;/u&gt;', '</u>', $aSource['content']);

		//检查题干图片
		if(isset($aSource['image'])){
			//如果有图片键
			if(!is_array($aSource['image'])){
				//但不是数组
				$this->_error = '题干图片格式错误';
				return false;
			}

			//检查图片每一个元素是否一个字符串,并且文件存在
			foreach($aSource['image'] as $image){
				if(!is_string($image)){
					$this->_error = '题干图片格式错误';
					return false;
				}

				if(!file_exists(SYSTEM_RESOURCE_PATH . '/' . $image)){
					$this->_error = '题干图片不存在';
					return false;
				}
			}
		}

		//检查答案
		if(!isset($aSource['answer'])){
			$this->_error = '答案不存在';
			return false;
		}else{
			if(!is_array($aSource['answer'])){
				$this->_error = '答案格式错误';
				return false;
			}

			foreach($aSource['answer'] as $key => $answer){
				if(!is_array($answer)){
					$this->_error = '第 ' . ($key + 1) . ' 个答案格式错误'.$answer;
					return false;
				}
				foreach($answer as $contentKey => $answerContent){
					if(!is_string($answerContent) && !is_numeric($answerContent)){
						$this->_error = '第 ' . ($key + 1) . ' 个答案格式错误';
						return false;
					}
					$aSource['answer'][$key][$contentKey] = str_replace('<', '&lt;', $aSource['answer'][$key][$contentKey]);
					$aSource['answer'][$key][$contentKey] = str_replace('>', '&gt;', $aSource['answer'][$key][$contentKey]);
					$aSource['answer'][$key][$contentKey] = str_replace('&lt;u&gt;', '<u>', $aSource['answer'][$key][$contentKey]);
					$aSource['answer'][$key][$contentKey] = str_replace('&lt;/u&gt;', '</u>', $aSource['answer'][$key][$contentKey]);
				}
			}
		}

		//检查答案组
		if(isset($aSource['answer_group'])){
			if(!is_array($aSource['answer_group'])){
				$this->_error = '答案组格式错误';
				return false;
			}

			$aExistsGroupAnswer = array();	//已经存在在答案组的答案
			foreach($aSource['answer_group'] as $key => $answerGroup){
				if(!is_array($answerGroup)){
					$this->_error = '第 ' . ($key + 1) . ' 个答案组格式错误';
					return false;
				}elseif(!(count($answerGroup) >= 2)){
					$this->_error = '第 ' . ($key + 1) . ' 个答案组的答案个数必须为 2 个以上';
					return false;
				}
				if(array_unique($answerGroup) === $answerGroup){
					foreach($answerGroup as $answer){
						if(!is_numeric($answer)){
							$this->_error = '第 ' . ($key + 1) . ' 个答案组格式错误';
							return false;
						}
						if(!array_key_exists($answer, $aSource['answer'])){
							$this->_error = '第 ' . ($key + 1) . ' 个答案组中有不存在的答案';
							return false;
						}
						if(in_array($answer, $aExistsGroupAnswer)){
							$this->_error = '第 ' . ($answer + 1) . ' 个答案重复出现在不同的答案组中';
							return false;
						}
						$aExistsGroupAnswer[] = $answer;
					}
				}else{
					$this->_error = '第 ' . ($key + 1) . ' 个答案组出现重复的答案';
					return false;
				}
			}
		}

		return $aSource;
	}

	/**
	 * 获取答案
	 * @param type $esData
	 * @return type
	 */
	public function getAnswer($esData, $aAnswerIndex = array()){
		if(is_string($esData)){
			$esData = json_decode($esData, true);
		}
		$aEsData = $esData;
		if($this->_error){
			return null;
		}
		return $aEsData['answer'];
	}

	/**
	 * 判断一个答案的正确性
	 * @param type $esData
	 * @param type $userAnswer
	 * @return array
	 */
	public function getCorrectness($esData, $aUserAnswer){
		//检查题目数据
		if(!$aEsData = $this->_decode($esData)){
			return null;
		}

		//检查用户作答格式
		if(!is_array($aUserAnswer)){
			$this->_error = '回答格式错误';
			return null;
		}

		$find = array("，", "；", "。", "“", "”", "、", "？", "‘", "’", "！", "（", "）", "＝");
		$replace = array(",", ";", ".", '"', '"', "\\", "?", "'", "'", "!", "(", ")", "=");
		foreach($aUserAnswer as $key => $userAnswer){
			if(!is_numeric($userAnswer) && !is_string($userAnswer)){
				$this->_error = '第 ' . ($key + 1) . ' 个回答格式错误';
				return null;
			}
			$aUserAnswer[$key] = str_replace($find, $replace, $aUserAnswer[$key]);
			$aEsData['answer'][$key] = str_replace($find, $replace, $aEsData['answer'][$key]);
		}

		//获取用户的每个作答的正确性
		$aCorrectness = array();
		foreach($aEsData['answer'] as $key => $answer){
			if(isset($aEsData['answer_group'])){
				$aIsInAnswerGroup = $this->_isInAnswerGroup($key, $aEsData['answer_group']);
				if($aIsInAnswerGroup){
					$aRightGroup = array();	//记录改答案组已经正确的答案
					foreach($aIsInAnswerGroup as $groupAnswerKey){
						if(in_array($aUserAnswer[$groupAnswerKey], $aEsData['answer'][$groupAnswerKey]) && !in_array($aUserAnswer[$groupAnswerKey], $aRightGroup)){
							$aCorrectness[$groupAnswerKey] = true;
							$aRightGroup[] = $aUserAnswer[$groupAnswerKey];
						}else{
							$aCorrectness[$groupAnswerKey] = false;
						}
					}
				}else{
					if(in_array($aUserAnswer[$key], $answer)){
						$aCorrectness[$key] = true;
					}else{
						$aCorrectness[$key] = false;
					}
				}
			}else{
				if(in_array($aUserAnswer[$key], $answer)){
					$aCorrectness[$key] = true;
				}else{
					$aCorrectness[$key] = false;
				}
			}
		}


		$rightNums = 0;
		$wrongNums = 0;
		foreach($aCorrectness as $key => $isRight){
			if($isRight == true){
				$rightNums++;
			}else{
				$wrongNums++;
			}
		}
		$aCorrect = array();
		$aCorrect['pass'] = $wrongNums == 0 ? 1 : 0;
		$aCorrect['scale'] = $rightNums . '/' . ($rightNums + $wrongNums);
		return $aCorrect;
	}

	/**
	 * 移除题目的答案
	 */
	public function removeAnswer($aEs){
		unset($aEs['answer']);
		if(isset($aEs['answer_group'])){
			unset($aEs['answer_group']);
		}
		return $aEs;
	}

	/**
	 * 获取错误信息
	 */
	public function getError(){
		return $this->_error;
	}

	/**
	 * 判断是否含有内联字符
	 * $aEsContent 解析后的结构内容
	 */
	public function hasBlockLine($aEsContent){
		if(strstr($aEsContent['content'], '\[')){
			return true;
		}
		return false;
	}
	
	/**
	 * 验证一个答案是否合法
	 * @param type $aAnswerList 答案组列表
	 * @return type
	 */
	public function validateAnswer($aAnswerList){
		if(!is_array($aAnswerList)){
			return false;
		}
		foreach($aAnswerList as $answer){
			if(!is_scalar($answer)){
				return false;
			}
		}
		return true;
	}

	/**
	 * 解析题目数据
	 * @param type $esData
	 */
	protected function _decode($esData){
		$aEsData = json_decode($esData, true);
		if(json_last_error() != JSON_ERROR_NONE){
			$this->_error = '题目数据非法';
			return null;
		}

		return $aEsData;
	}

	/**
	 * 判断答案是否在答案组中
	 * @param type $esData
	 */
	protected function _isInAnswerGroup($answer, $aAnswerGroup){
		foreach($aAnswerGroup as $answerGroup){
			if(in_array($answer, $answerGroup)){
				return $answerGroup;
			}
		}
		return false;
	}
}