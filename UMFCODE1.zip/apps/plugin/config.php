<?php
//各题型对应的解析器 配置
$GLOBALS['TYPE_RESOLVER'] = array(
	1 => 'es_single_choice',
	2 => 'es_multiple_choice',
	3 => 'es_judgment',
	4 => 'es_fill_blank',
	5 => 'es_fill_blank',
	6 => 'es_complex',
	7 => 'es_complex'
);

//各解析器的类 配置
$GLOBALS['RESOLVER_CLASS'] = array(
	'es_single_choice' => 'EsSingleChoice',
	'es_multiple_choice' => 'EsMultipleChoice',
	'es_fill_blank' => 'EsFillBlank',
	'es_judgment' => 'EsJudgment',
	'es_complex' => 'EsComplex',
);

$GLOBALS['PROP_TYPE_NAME'] = array(
	1 => '闯关道具',
	2 => '通用答题道具',
	3 => 'PK道具',
	4 => 'PK道具',
	5 => '经验道具',
	6 => '扩容道具',
	7 => '装扮类道具',
	8 => '道具包',
);

$GLOBALS['PROP_FUNCTION_RELATION'] = array(
	'qnrs' => 'useQnrs',
	'wnrs' => 'useWnrs',
	'mtgh' => 'useMtgh',
	'slyz' => 'useSlyz',
	'sjyz' => 'useSjyz',
	'slzy' => 'useSlzy',
	'sgnj' => 'useSgnj',
	'sgdl' => 'useSgdl',
	'hhlf' => 'useHhlf',
	'hhqjl' => 'useHhqjl',
	'scjd' => 'useScjd',
	'mhcg' => 'useMhcg',
	'tgys' => 'useTgys',
	'mzjp' => 'useMzjp',
	'sbjf1' => 'useSbjf1',
	'sbjf3' => 'useSbjf3',
	'sbjf7' => 'useSbjf7',
	'djbkr' => 'useDjbkr',
);
