<?php
/**
 * @author 罗启军 <lqjdjj@yahoo.cn>
 * @date 2013-7-23
 */
class EsComplex{

	private $_error = '';
	private $_aShowType = array(
		1,	// '添加题目'
		2,	// '编辑题目'
		3,	//'显示完整题目'
		4,	// '显示问题部分'
		5, 	//'题目回顾'
		6,	//列表显示
		7	//批量添加
	);

	public function __construct(){}

	/**
	 *分解题目数据，返回视图
	 * @param type $type 需要显示的类型
	 * @param type $esData 题目数据，JSON结构
	 * @return String 页面数据
	 */
	public function resolve($encodeEs){
		return $this->_decode($encodeEs);
	}

	/**
	 * 构建JSON数据
	 */
	public function build($aSource = null){
		if(!$aSource){
			$aSource = $_POST;
		}
		$aKeys = array('content', 'es_item');
		foreach($aKeys as $key){
			if(!key_exists($key, $aSource)){
				$this->_error = '数据源缺少' . $key . '字段';
				return false;
			}
		}

		$aEs = array(
			'content' => $aSource['content'],
			'es_item' => $aSource['es_item'],
		);

		if(!$this->_checkStruct($aEs)){
			return null;
		}

		$aEs['content'] = $this->_blockLine2InLine($aEs['content']);
		$esText = $aEs['content'];

		if(isset($aSource['image']) && $aSource['image']){
			$aEs['image'] = $aSource['image'];
			//$esText .=  ' ' . implode(' ', $aEs['image']);
		}
		//组装题目内容
		$oaEsPlugin = array();
		foreach($aEs['es_item'] as &$aEsItem){
			if(!isset($oaEsPlugin[$aEsItem['type']])){
				$oaEsPlugin[$aEsItem['type']] = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsItem['type']]);
			}
			$aEsItemResult = $oaEsPlugin[$aEsItem['type']]->build($aEsItem['content']);
			$esText .= ' ' . $aEsItemResult['content_text'];
			$aEsItem['content'] = json_decode($aEsItemResult['content_json'], 1);
		}

		return array(
			'content_json' => json_encode($aEs),
			'content_text' => $esText,
		);
	}

	/**
	* 转换字符\[ \] 为 \( \)
	* $param 包含\[ \] 的字符串
	*/
	private function _blockLine2InLine($param){
		if(false !== strpos($param, '\[') && false !== strpos($param, '\]')){
			$param = str_replace(array('\[', '\]'), array('\(', '\)'), $param);
		}
		return $param;
	}

	/**
	 * 检查数据源结构是否合法
	 * @param array $aSource 要检查的数据源
	 * @return bool 是否合法的数据源
	 */
	private function _checkStruct($aEs){
		if(!is_array($aEs)){
			//如果不是数组
			$this->_error = '非法的题目数据,必须为一个数组';
			return false;
		}

		//检查题干是否一个字符串
		if(!isset($aEs['content']) || !is_string($aEs['content'])){
			$this->_error = '题干内容非法';
			return false;
		}

		//检查题干图片
		if(isset($aEs['image'])){
			//如果有图片键
			if(!is_array($aEs['image'])){
				//但不是数组
				$this->_error = '题干图片数据不正确';
				return false;
			}

			//检查图片每一个元素是否一个字符串,并且文件存在
			foreach($aEs['image'] as $image){
				if(!is_string($image)){
					$this->_error = '题干图片数据不正确';
					return false;
				}

				if(!file_exists(SYSTEM_RESOURCE_PATH . '/' . $image)){
					$this->_error = '题干图片不存在';
					return false;
				}
			}
		}
		//检查每个子题
		if(!isset($aEs['es_item']) || !is_array($aEs['es_item'])){
			$this->_error = '缺少子题';
			return false;
		}else{
			$oaEsPlugin = array();
			foreach($aEs['es_item'] as $i => $aEsItem){
				if(!isset($oaEsPlugin[$aEsItem['type']])){
					$oaEsPlugin[$aEsItem['type']] = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsItem['type']]);
				}

				$aEsItemResult = $oaEsPlugin[$aEsItem['type']]->build($aEsItem['content']);
				if(!$aEsItemResult){
					$this->_error = '第' . ($i + 1) . '小题题解析失败:' . $oaEsPlugin[$aEsItem['type']]->getError();
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * 获取判断题的答案
	 * @param type $esData
	 * @return type
	 */
	public function getAnswer($esData, $aAnswerIndex){
		//检查题目数据
		if(is_string($esData)){
			$esData = json_decode($esData, true);
		}
		$aEsData = $esData;
		if($this->_error){
			return null;
		}
		$aResult = array();
		foreach($aAnswerIndex as $key){
			if(!isset($aEsData['es_item'][$key])){
				continue;
			}

			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsData['es_item'][$key]['type']]);
			$content = $aEsData['es_item'][$key]['content'];
			//$content = json_decode(json_encode($aEsData['es_item'][$key]['content']), 1);
			$aResult[$key]['index'] = $key;
			$aResult[$key]['type'] = $aEsData['es_item'][$key]['type'];
			$aResult[$key]['content'] = $oEsPlugin->getAnswer($content);
		}
		return $aResult;
	}


	/**
	 * 获取错误信息
	 */
	public function getError(){
		return $this->_error;
	}

	/**
	 * 判断是否含有内联字符
	 * $aEsContent 解析后的结构内容
	 */
	public function hasBlockLine($aEsContent){
		if(strstr($aEsContent['content'], '\[')){
			return true;
		}
		foreach($aEsContent['es_item'] as $aEsItem){
			$aContent = $aEsItem['content'];
			if(strstr($aContent['content'], '\[')){
				return true;
			}
			if(!isset($aContent['option'])){
				continue;
			}
			foreach($aContent['option'] as $aEsOption){
				if(strstr($aEsOption['content'], '\[')){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 移除子题的答案
	 * @param type $aEs
	 * @return type
	 */
	public function removeAnswer($aEs){
		$aRand = array();
		$esNums = count($aEs['es_item']);
		for($i = 0; $i < ES_REMOVE_ANSWER_BY_COMPLEX_ES_ITEM_COUNT; $i++){
			if($esNums > count($aRand)){
				$rand = rand(0, $esNums - 1);
				while(in_array($rand, $aRand)){
					$rand = rand(0, $esNums - 1);
				}
				$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['es_item'][$rand]['type']]);
				$aEs['es_item'][$rand]['content'] = $oEsPlugin->removeAnswer($aEs['es_item'][$rand]['content']);
				$aRand[] = $rand;
			}else{
				break;
			}
		}
		return $aEs;
	}

	/**
	 * 判断一个答案的正确性
	 */
	public function getCorrectness($esData, $userAnswer){
		//检查题目数据
		if(!$aEsData = $this->_decode($esData)){
			return null;
		}

		$rightNums = 0;
		$wrongNums = 0;
		foreach($userAnswer as $key => $aAnswer){
			if(!array_key_exists($aAnswer['index'], $aEsData['es_item'])){
				$this->_error = '第' . $aAnswer['index'] . '小题不存在';
				return null;
			}
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsData['es_item'][$aAnswer['index']]['type']]);
			$content = json_encode($aEsData['es_item'][$aAnswer['index']]['content']);
			$aEsResult = $oEsPlugin->getCorrectness($content, $aAnswer['answer']);
			if($aEsResult['pass']){
				$rightNums++;
			}else{
				$wrongNums++;
			}
		}
		$aResult = array();
		if($rightNums == count($userAnswer)){
			$aResult['pass'] = 1;
		}else{
			$aResult['pass'] = 0;
		}
		$aResult['scale'] = $rightNums . '/' . count($userAnswer);
		return $aResult;
	}

	/**
	 * 验证一个答案是否合法
	 * @param type $aItemAnswerList 答案组列表
	 * @return type
	 */
	public function validateAnswer($aItemAnswerList){
		if(!is_array($aItemAnswerList)){
			return false;
		}
		$oaEsPlugin = array();
		foreach($aItemAnswerList as $aItemAnswer){
			if(!is_array($aItemAnswer) || !isset($aItemAnswer['index']) || !isset($aItemAnswer['type'])){
				return false;
			}
			if(!isset($oaEsPlugin[$aItemAnswer['type']])){
				$oaEsPlugin[$aItemAnswer['type']] = esPlugin($GLOBALS['TYPE_RESOLVER'][$aItemAnswer['type']]);
			}
			if(!$oaEsPlugin[$aItemAnswer['type']]->validateAnswer($aItemAnswer['answer'])){
				return false;
			}
		}
		return true;
	}

	/**
	 * 解析题目数据
	 * @param type $esData
	 */
	protected function _decode($esData){
		$aEsData = json_decode($esData, true);
		if(json_last_error() != JSON_ERROR_NONE){
			$this->_error = '非法的题目数据';
			return null;
		}
		/*
		foreach($aEsData['es_item'] as &$aEsItem){
			if(is_string($aEsItem['content'])){
				$aEsItem['content'] = json_decode($aEsItem['content'], 1);
				if(json_last_error() != JSON_ERROR_NONE){
					$this->_error = '非法的子题数据';
					return null;
				}
			}
		}*/

		return $aEsData;
	}
}