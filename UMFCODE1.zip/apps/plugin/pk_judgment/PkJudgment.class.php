<?php
/**
 * @author 黄标彬 <jayhbb@gmail.com>
 * @date 2013-12-02
 */
class PkJudgment{

	private $_oPk;
	private $_oSns;
	private $_oDboi;

	public function __construct(){
		$this->_oPk = m('Pk');
		$this->_oSns = m('personalMessage');
		$this->_oDboi = new DBOI();
	}

	/**
	 *	裁决所有已超时结束的PK
	 * 	@param integer $pkId 需要裁决的PK记录id
	 * 	@return array 裁决后的PK记录 or false
	 */
	public function execOverTimePkJudgment($pkId = 0){
		$aPkList = array();
		if($pkId){
			//根据PK记录id查询PK记录
			$aPk = $this->_oPk->getPkInfoById($pkId);
			if(!$aPk){
				return 0;
			}
			$aPkList[] = $aPk;
		}else{
			//查询所有符合裁决的PK记录, 查询条件是没有胜利者且PK超时的记录
			$aPkList = $this->_oPk->getOverTimePkList();
			if($aPkList === false){
				return 0;
			}
		}

		$nowTime = time();
		//遍历PK记录
		foreach($aPkList as $key => $aPk){
			$isOverTime = !$aPk['winner_user_id'] && $aPk['over_time'] < $nowTime;
			$isReceiverEnd = $aPk['sender_user_end_time'] && $aPk['receiver_user_start_time'] && !$aPk['receiver_user_end_time'] && $aPk['receiver_user_start_time'] + $aPk['duration'] * 60 < $nowTime;
			$isSenderEnd = $aPk['receiver_user_end_time'] && $aPk['sender_user_start_time'] && !$aPk['sender_user_end_time'] && $aPk['sender_user_start_time'] + $aPk['duration'] * 60 < $nowTime;
			if($isOverTime || $isReceiverEnd || $isSenderEnd){
				$updateResult = $this->_updatePkResult($aPk);
				if($updateResult){
					$aPkList[$key] = $updateResult;
				}
			}
		}
		//清除过期的pk场没人应战的数据
		$this->_oPk->deleteOverTimePkArenaPkList();

		return 1;
	}

	/**
	 *	裁决并更新PK胜负结果
	 * 	@param array $aPk PK记录
	 * 	@return array 裁决后的PK记录 or false
	 */
	private function _updatePkResult($aPk){
		//裁决胜利者
		$aPk['winner_user_id'] = $aPk['sender_score'] >= $aPk['receiver_score'] ? $aPk['sender_user_id'] : $aPk['receiver_user_id'];
		$aNewPkData = array(
			'id' => $aPk['id'],
			'winner_user_id' => $aPk['winner_user_id']
		);
		//更新裁决PK记录
		$isUpdateSuccess = $this->_oPk->setPk($aNewPkData);
		if(!$isUpdateSuccess){
			return false;
		}
		//推送事件
		$isSendNoticSuccess = $this->_sendNotices($aPk);
		if(!$isSendNoticSuccess){
			return false;
		}
		$oGame = new Game();
		$oGame->afterPKEnd($aPk['sender_user_id'], $aPk['receiver_user_id'], $aPk['winner_user_id']);
		return $aPk;
	}

	/**
	 *	根据PK胜负推送私信和好友动态事件
	 * 	@param array $aPk PK记录
	 * 	@return bool true or false
	 */
	private function _sendNotices($aPk){
		//删除31和30
		$isDeleteSuccess = $this->_oSns->deletePersonalMessage(0, 0, 30, $aPk['id']);
		if(!$isDeleteSuccess){
			return false;
		}
		$isDeleteSuccess = $this->_oSns->deletePersonalMessage(0, 0, 31, $aPk['id']);
		if(!$isDeleteSuccess){
			return false;
		}

		$aData = array(
			'data_id' => $aPk['id'],
			'user_id' => $aPk['sender_user_id'],
			'type' => 32
		);
		$isaddPersonalMessageSuccess = $this->_oSns->addPersonalMessage($aData);
		if($isaddPersonalMessageSuccess === false || !$isaddPersonalMessageSuccess){
			return false;
		}
		$aData['user_id'] = $aPk['receiver_user_id'];
		$isaddPersonalMessageSuccess = $this->_oSns->addPersonalMessage($aData);
		if($isaddPersonalMessageSuccess === false || !$isaddPersonalMessageSuccess){
			return false;
		}
		///////////
		$oUser = m('User');
		$aUser = array(
			'id' => $aPk['winner_user_id'],
			'new_feed_flag' => array('add', 1),
		);
		$isSetSuccess = $oUser->setUserInfo($aUser);
		if(!$isSetSuccess){
			return false;
		}

		//根据胜利者推送好友动态事件
		/*$this->_oDboi->startTrans();
		$aEventData = array(
			'user_id' => $aPk['winner_user_id'],
			'type' => 13,
			'data_id' => $aPk['id']
		);
		$eventId = $this->_oDboi->table(T_SNS_EVENT)->data($aEventData)->insert();
		if(!$eventId){
			$this->_oDboi->rollBack();
			return false;
		}*/
		return true;
	}
}