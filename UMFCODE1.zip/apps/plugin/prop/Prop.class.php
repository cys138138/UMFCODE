<?php
/**
 * @author 罗启军 <455538375@qq.com>
 * @date 2014-3-13
 */
class Prop{
	protected $_aFailMsg = array(
		1 => '道具不存在',
		2 => '道具已下架',
		3 => '道具包容量不足',
		4 => '购物车为空',
		5 => '金币不足',
		6 => 'U币不足',
		7 => '操作失败',
	);
	protected $_expansionId = 0;	//扩道具包容量道具ID
	
	protected function _getUserPropInfo($userId){
		$oProp = m('Prop');
		$aPacket = $oProp->getUserPropInfo($userId);
		if(!$aPacket){
			$aPacket = array(
				'id' => $userId,
				'prop_package' => 15,
				'shopping_cart' => array(),
			);
			$oProp->addUserProp($aPacket);
		}
		return $aPacket;
	}
	
	public function purchase($userId, $propId, $nums){
		$oProp = m('Prop');
		$aProp = $oProp->getPropInfoById($propId);
		if(!$aProp){
			return $this->_aFailMsg[1];
		}
		if($aProp['is_publish'] != 1){
			return $this->_aFailMsg[2];
		}
		$aPacket = $this->_getUserPropInfo($userId);
		$propNums = count($aPacket['props']) + $nums;
		if($propNums > $aPacket['prop_package']){
			return $this->_aFailMsg[3];
		}
		
		$oNum = m('UserNumerical');
		$aNum = $oNum->getUserNumericalInfoById($userId);
		$now = time();
		if($aProp['discount_start_time'] <= $now && $now <= $aProp['discount_end_time']){
			$aProp['price'] = floor($aProp['price'] * ($aProp['discount'] / 100));
		}
		if($aNum['vip'] && $aNum['vip_expiration_time'] > time()){
			$aProp['price'] = floor($aProp['price'] * ($GLOBALS['VIP'][$aNum['vip']]['prop_price'] / 10));
		}
		$aProp['price'] = $aProp['price'] * $nums;
		if($aProp['money_type'] == 1){
			if($aNum['gold'] < $aProp['price']){
				return $this->_aFailMsg[5];
			}
		}elseif($aProp['money_type'] == 2){
			//暂时不用U币结算
		}
		$aProps = array(
			array(
				'id' =>	$propId,
				'number' =>	$nums,
				'from' => 1,
				'from_comment' => $aProp['price'],
				'money_type' => $aProp['money_type'],
			)
		);
		if($oProp->buyProps($aPacket, $aProps)){
			$GLOBALS['UPDATE']['numerical_data']['gold'] = $aNum['gold'] - $aProp['price'];
			$GLOBALS['UPDATE']['numerical_data']['toy'] = $propNums;
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function getCartPropList($userId){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		$aCart = $aPacket['shopping_cart'];
		$aDifPropId = array_unique($aCart);
		if($aDifPropId){
			$aCartPropList = $oProp->getPropListByPropIds($aDifPropId);
		}else{
			$aCartPropList = array();
		}
		foreach($aCartPropList as $key => $aProp){
			$thisNums = 0;
			foreach($aPacket['shopping_cart'] as $id){
				if($id == $aProp['id']){
					$thisNums++;
				}
			}
			$aCartPropList[$key]['nums'] = $thisNums;
		}
		return $aCartPropList;
	}
	
	public function getMyPropList($userId){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		$aPropIds = $aPacket['props'];
		$aDifPropId = array_unique($aPropIds);
		if($aDifPropId){
			$aPropList = $oProp->getPropListByPropIds($aDifPropId);
		}else{
			$aPropList = array();
		}
		foreach($aPropList as $key => $aProp){
			$thisNums = 0;
			foreach($aPacket['props'] as $id){
				if($id == $aProp['id']){
					$thisNums++;
				}
			}
			$aUserIds = getUserFriendIds($userId);
			$aPropList[$key]['have_list'] = $oProp->getHavePropPurchaseRecordUserList($aProp['id'], $aUserIds, 1, 8);
			$aPropList[$key]['nums'] = $thisNums;
			$aDecript = explode('---', $aProp['description']);
			$aPropList[$key]['range'] = $aDecript[0];
			$aPropList[$key]['effect'] = $aDecript[1];
		}
		
		$oSns = m('Sns');
		$aGroupList = $oSns->getUserGroupList($userId);
		$aFriendList = $oSns->getUserFriendList($userId, 1);
		$aResult = array(
			'prop_list' => $aPropList,
			'group_list' => $aGroupList,
			'friend_list' => $aFriendList,
			'prop_count' => $aPacket['prop_package'],
		);
		return $aResult;
	}
	
	public function getPropToolBar($userId, $type){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		$aPropIds = $aPacket['props'];
		if($aPropIds){
			$aDifPropId = array_unique($aPropIds);
		}else{
			$aDifPropId = array();
		}
		if($aDifPropId){
			$aPropList = $oProp->getPropListByPropIds($aDifPropId);
		}else{
			$aPropList = array();
		}
		$aEnabled = array();
		$aDisabled = array();
		$aCondition = array(
			'type' => array(1, 2, 3, 4, 5, 6, 7),
			'money_type' => 1,
			'is_publish' => 1,
		);
		
		$aNothing = $oProp->getPropList($aCondition, 1, 7);
		foreach($aPropList as $key => $aProp){
			$thisNums = 0;
			foreach($aPacket['props'] as $id){
				if($id == $aProp['id']){
					$thisNums++;
				}
			}
			$aPropList[$key]['nums'] = $thisNums;
			
			$aPropList[$key]['fun'] = $GLOBALS['PROP_FUNCTION_RELATION'][$aPropList[$key]['prop_code']];
			if(in_array($aPropList[$key]['type'], array($type, 2, 5, 6, 7))){
				$aDecript = explode('---', $aPropList[$key]['description']);
				$aPropList[$key]['range'] = $aDecript[0];
				$aPropList[$key]['effect'] = $aDecript[1];
				$aEnabled[] = $aPropList[$key];
			}else{
				$aDisabled[] = $aPropList[$key];
			}
		}
		$aResult = array(
			'enable' => $aEnabled,
			'disable' => $aDisabled,
			'nothing' => $aNothing,
		);
		return $aResult;
	}
	
	public function purchaseFromCart($userId, $aPropIds){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		foreach($aPropIds as $propId){
			if(!is_numeric($propId)){
				return $this->_aFailMsg[1];
			}
		}
		
		$propNums = count($aPropIds);
		$aDifPropId = array_unique($aPropIds);
		if($aDifPropId){
			$aCartPropList = $oProp->getPropListByPropIds($aDifPropId);
		}else{
			$aCartPropList = array();
		}
		if(count($aCartPropList) < count($aDifPropId)){
			return $this->_aFailMsg[1];
		}
		$leaveNums = $aPacket['prop_package'] - count($aPacket['props']);
		if($propNums > $leaveNums){
			return $this->_aFailMsg[3];
		}
		
		$price = 0;
		$oNum = m('UserNumerical');
		$aNum = $oNum->getUserNumericalInfoById($userId);
		$now = time();
		$aBuyRecord = array();
		foreach($aCartPropList as $aCartProp){
			if($aCartProp['is_publish'] != 1){
				return 'ID：' . $aCartProp['id'] . '的道具已下架';
			}
			$aRecord = array(
				'id' => $aCartProp['id'],
				'from' => 1,
				'money_type' => $aCartProp['money_type'],
			);
			
			if($aCartProp['discount_start_time'] <= $now && $now <= $aCartProp['discount_end_time']){
				$aCartProp['price'] = floor($aCartProp['price'] * ($aCartProp['discount'] / 100));
			}
			if($aNum['vip'] && $aNum['vip_expiration_time'] > $now){
				$aCartProp['price'] = floor($aCartProp['price'] * ($GLOBALS['VIP'][$aNum['vip']]['prop_price'] / 10));
			}
			$kindNums = 0; //某种道具的数量
			foreach($aPropIds as $thisId){
				if($thisId == $aCartProp['id']){
					$kindNums++;
				}
			}
			$aRecord['number'] = $kindNums;
			$aRecord['from_comment'] = $aCartProp['price'] * $kindNums;
			$price += $aRecord['from_comment'];
			$aBuyRecord[] = $aRecord;
		}
		
		if($aNum['gold'] < $price){
			return $this->_aFailMsg[5];
		}
		
		if($oProp->buyProps($aPacket, $aBuyRecord)){
			foreach($aPropIds as $thisId){
				foreach($aPacket['shopping_cart'] as $key => $thisPropId){
					if($thisId == $thisPropId){
						unset($aPacket['shopping_cart'][$key]);
					}
				}
			}
			$aData = array(
				'id' => $userId,
				'shopping_cart' => $aPacket['shopping_cart'],
			);
			$oProp->setUserProp($aData);
			$GLOBALS['UPDATE']['numerical_data']['gold'] = $aNum['gold'] - $price;
			$GLOBALS['UPDATE']['numerical_data']['toy'] = count($aPropIds) + count($aPacket['props']);
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	
	public function putCart($userId, $propId, $nums){
		$oProp = m('Prop');
		$aProp = $oProp->getPropInfoById($propId);
		if(!$aProp){
			return $this->_aFailMsg[1];
		}
		if($aProp['is_publish'] != 1){
			return $this->_aFailMsg[2];
		}
		
		$aPacket = $this->_getUserPropInfo($userId);
		for($i = 0; $i < $nums; $i++){
			array_push($aPacket['shopping_cart'], $propId);
		}
		$aData = array(
			'id' => $userId,
			'shopping_cart' => $aPacket['shopping_cart'],
		);
		if($oProp->setUserProp($aData)){
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function cancelCart($userId, $aPropIds){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		foreach($aPropIds as $propId){
			$aProp = $oProp->getPropInfoById($propId);
			if(!$aProp){
				return $this->_aFailMsg[1];
			}
			foreach($aPacket['shopping_cart'] as $key => $thisId){
				if($thisId == $propId){
					unset($aPacket['shopping_cart'][$key]);
					break;
				}
			}
		}
		$aData = array(
			'id' => $userId,
			'shopping_cart' => $aPacket['shopping_cart'],
		);
		if($oProp->setUserProp($aData)){
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function useProp($userId, $propId, $type){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		if(!in_array($propId, $aPacket['props'])){
			return $this->_aFailMsg[1];
		}
		if($oProp->useProp($aPacket, $propId, $type)){
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function sendProp($userId, $toUserId, $propId, $message){
		$oProp = m('Prop');
		$aMyPacket = $this->_getUserPropInfo($userId);
		if(!in_array($propId, $aMyPacket['props'])){
			return $this->_aFailMsg[1];
		}
		$aFriendPacket = $this->_getUserPropInfo($toUserId);
		
		if($oProp->sendProp($aMyPacket, $toUserId, $propId, 1, $message)){
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function getSendProp($userId, $type){
		$oProp = m('Prop');
		if($type == 1){
			$aPropList = $oProp->getPropSendRecordList(0, $userId, 1, 1, 50);
		}elseif($type == 2){
			$aPropList = $oProp->getPropPurchaseList($userId, array(2), 1, 50);
		}
		foreach($aPropList as $key => $aProp){
			$aDecript = explode('---', $aProp['prop_info']['description']);
			$aPropList[$key]['prop_info']['range'] = $aDecript[0];
			$aPropList[$key]['prop_info']['effect'] = $aDecript[1];
			$aPropList[$key]['create_time'] = date('Y-m-d H:i:s', $aPropList[$key]['create_time']);
		}
		return $aPropList;
	}
	
	public function getProp($userId, $sendId, $type){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		$propNums = count($aPacket['props']) + 1;
		if($propNums > $aPacket['prop_package']){
			return $this->_aFailMsg[3];
		}
		if($type == 1){
			$aSendRecord = $oProp->getPropSendRecordInfoById($sendId);
			if(!$aSendRecord){
				return $this->_aFailMsg[1];
			}
			if($aSendRecord['to_user_id'] != $userId || $aSendRecord['status'] != 1){
				return $this->_aFailMsg[1];
			}
			$result = $oProp->receiveSendProp($aSendRecord, $aPacket);
		}elseif($type == 2){
			$aAwardRecord = $oProp->getPXX($sendId);
			if(!$aAwardRecord){
				return $this->_aFailMsg[1];
			}
			if($aAwardRecord['user_id'] != $userId || $aAwardRecord['from'] != 2){
				return $this->_aFailMsg[1];
			}
			$result = $oProp->receiveAwordProp($aAwardRecord, $aPacket);
		}
		if($result){
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function ignoreProp($userId, $sendId, $type){
		$oProp = m('Prop');
		if($type == 1){
			$aSendRecord = $oProp->getPropSendRecordInfoById($sendId);
			if(!$aSendRecord){
				return $this->_aFailMsg[1];
			}
			if($aSendRecord['to_user_id'] != $userId || $aSendRecord['status'] != 1){
				return $this->_aFailMsg[1];
			}
			$aData = array(
				'id' => $sendId,
				'status' => 3,
			);
			$result = $oProp->setPropSendRecord($aData);
		}else{
			$aAwardRecord = $oProp->getPropPurchaseRecordInfo($sendId);
			if(!$aAwardRecord){
				return $this->_aFailMsg[1];
			}
			if($aAwardRecord['user_id'] != $userId || $aAwardRecord['from'] != 2){
				return $this->_aFailMsg[1];
			}
			$aData = array(
				'id' => $sendId,
				'from' => 22,
			);
			$result = $oProp->setPropPurchaseRecord($aData);
		}
		if($result){
			return true;
		}else{
			return $this->_aFailMsg[7];
		}
	}
	
	public function getVipProp($userId, $nums){
		$oProp = m('Prop');
		$aPacket = $this->_getUserPropInfo($userId);
		
		$propNums = count($aPacket['props']) + $nums;
		if($propNums > $aPacket['prop_package']){
			return $this->_aFailMsg[3];
		}
		$aCondition = array(
			'type' => array(1, 2, 3, 4, 5, 6, 7, 8),
			'money_type' => 1,
			'is_publish' => 1,
		);
		$randPage = rand(1, 3);
		$aPropList = $oProp->getPropList($aCondition, $randPage, 4);
		for($i = 0; $i < $nums; $i++){
			array_push($aPacket['props'], $aPropList[$i]['id']);
		}
		if($oProp->setUserProp($aPacket)){
			return true;
		}else{
			return false;
		}
	}
	
}