<?php
/**
 * @author 罗启军 <455538375@qq.com>
 * @date 2014-3-13
 */
class UseProp extends Prop{

	public function __construct($userId){
		$this->_getUserPropInfo($userId);
	}


	public function useQnrs($userId, $missionId, $propId){
		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $userId);
		if(!$aMyMission){
			return false;
		}

		$aMission = $oMission->getMissionInfoById($missionId);
		$aMyEsList = $aMyMission['current_challenge_process'];
		if($aMyEsList['life'] >= $aMission['challenge_limit_blood']){
			return false;
		}
		$aMyEsList['life'] = $aMyEsList['life'] + 1;
		$aData = array(
			'id' => $aMyMission['id'],
			'current_challenge_process' => $aMyEsList,
		);
		if($this->useProp($userId, $propId, 1)){
			$result = $oMission->setUserMission($aData);
			if($result || $result === 0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function useWnrs($userId, $missionId, $propId){
		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $userId);
		$aMyEsList = $aMyMission['current_challenge_process'];
		$aMission = $oMission->getMissionInfoById($missionId);
		if($aMyEsList['life'] >= $aMission['challenge_limit_blood']){
			return false;
		}
		$aMyEsList['life'] = 3;
		$aData = array(
			'id' => $aMyMission['id'],
			'current_challenge_process' => $aMyEsList,
		);
		if($this->useProp($userId, $propId, 1)){
			$result = $oMission->setUserMission($aData);
			if($result || $result === 0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function useSlyz($userId, $esId, $propId){
		$oEs = m('Es');
		$aEs = $oEs->getOfficialEsInfoById($esId);
		if(!$aEs){
			return false;
		}
		if($aEs['type_id'] != 1 && $aEs['type_id'] != 2){
			return false;
		}

		$aEsData = json_decode($aEs['content_json'], true);
		foreach($aEsData['option'] as $index => $answer){
			if($aEs['type_id'] == 1 && $aEsData['answer'] == $index){
				continue;
			}
			if($aEs['type_id'] == 2 && in_array($index, $aEsData['answer'])){
				continue;
			}
			if($this->useProp($userId, $propId, 1)){
				return $index;
			}else{
				return false;
			}
		}
		return false;
	}

	public function useSjyz($userId, $esId, $propId){
		$oEs = m('Es');
		$aEs = $oEs->getOfficialEsInfoById($esId);
		if(!$aEs){
			return false;
		}
		if($aEs['type_id'] != 1 && $aEs['type_id'] != 2){
			return false;
		}

		$aWrongIndex = array();
		$aEsData = json_decode($aEs['content_json'], true);
		foreach($aEsData['option'] as $index => $answer){
			if(count($aWrongIndex) < 2){
				if($aEs['type_id'] == 1 && $aEsData['answer'] != $index){
					$aWrongIndex[] = $index;
				}elseif($aEs['type_id'] == 2 && !in_array($index, $aEsData['answer'])){
					$aWrongIndex[] = $index;
				}
			}
			if(count($aWrongIndex) == 2 || (count($aWrongIndex) == 1 && count($aEsData['option']) <= 2)){
				if($this->useProp($userId, $propId, 1)){
					return $aWrongIndex;
				}else{
					return false;
				}
			}
		}
		return false;
	}

	public function useSlzy($userId, $esId, $propId){
		$oEs = m('Es');
		$aEs = $oEs->getOfficialEsInfoById($esId);
		if(!$aEs){
			return false;
		}
		if($this->useProp($userId, $propId, 1)){
			$aEsData = json_decode($aEs['content_json'], true);
			if($aEs['type_id'] == 6 || $aEs['type_id'] == 7){
				$aItemAnswer = array();
				foreach($aEsData['es_item'] as $key => $aItem){
					$itemContent = json_decode($aItem['content'], true);
					$aItemAnswer[] = array(
						'type_id' => $aItem['type'],
						'answer' => $itemContent['answer'],
					);
				}
				return $aItemAnswer;
			}else{
				return $aEsData['answer'];
			}
		}else{
			return false;
		}
	}

	public function useSgnj($userId, $propId, $dataId){
		if($this->useProp($userId, $propId, 1)){
			$cookie = Xxtea::encrypt($userId . '---' . 'sgnj' . '---' . $dataId);
			//Cookie::set('sgnj', $cookie, time() + 3600);
			setcookie('sgnj', $cookie, time() + 3600, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
		}else{
			return false;
		}
	}

	public function checkSgnj($userId, $dataId){
		if(isset($_COOKIE['sgnj']) && $_COOKIE['sgnj']){
			$cookie = Xxtea::decrypt($_COOKIE['sgnj']);
			$aCookie = explode('---', $cookie);
			if(isset($aCookie[0]) && isset($aCookie[1]) && isset($aCookie[2])){
				if($aCookie[0] == $userId && $aCookie[1] == 'sgnj' && $aCookie[2] == $dataId){
					setcookie('sgnj', '', time() - 3600, DEFAULT_COOKIE_PATH, DEFAULT_COOKIE_DOMAIN);
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function useHhlf($userId, $missionId, $propId){
		return $this->_resurrect($userId, $missionId, $propId, 1);
	}

	public function useHhqjl($userId, $missionId, $propId){
		return $this->_resurrect($userId, $missionId, $propId, 2);
	}

	public function useScjd($userId, $missionId, $propId){
		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $userId);
		if(!$aMyMission){
			return false;
		}
		if($aMyMission['es_correct_count'] < 5){
			return 1;
		}
		if($aMyMission['is_task_finish']){
			return 2;
		}

		if($this->useProp($userId, $propId, 1)){
			$oGame = new Game();
			$aTaskEvent = array(
				'user_id' => $userId,
				'type' => 7,
				'data_id' => $aMyMission['id'],
			);
			$rightRate = $aMyMission['es_correct_count'] / $aMyMission['es_count'];
			if(!$oGame->firstFinishPractice($aTaskEvent, $rightRate)){	//首次修炼完成
				return false;
			}

			$now = time();
			$aMission = $oMission->getMissionInfoById($missionId);
			$aMissionCount = array(
				'id' => $aMyMission['id'],
				'task_finish_time' => $now,
				'task_process' => $aMission['task_content']['correct_counts'],
				'is_task_finish' => 1,
				'lottery_draw_status' => 1,
			);
			if(!$oMission->setUserMission($aMissionCount)){
				return false;
			}
			$aThisResult = array();
			$aThisResult['show_type'] = 'TASKCOMPLETE';
			$aThisResult['custom_data']['time'] = $now;
			$aThisResult['custom_data']['correct_rate'] = intval($rightRate  * 100);
			$oGame->setResult($aThisResult);
			return true;
		}else{
			return false;
		}
	}

	public function useTgys($userId, $missionId, $propId){
		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $userId);
		if(!$aMyMission){
			return false;
		}
		if($aMyMission['is_pass']){
			return 1;
		}

		if($this->useProp($userId, $propId, 1)){
			$aMissoinInfo = $oMission->getMissionInfoById($missionId);
			$topScore = $oMission->getMissionRecordScore($missionId);
			$passMissionNum = $oMission->getPassMissionUserCount($missionId);
			$challengeEs = 0;
			foreach($aMissoinInfo['challenge_es_count'] as $aThisEsType){
				$challengeEs = $challengeEs + $aThisEsType['es_count'];
			}
			$aMyEsList = $aMyMission['current_challenge_process'];
			$thisCorrcetRate = $aMyEsList['rightEsCount'] / $challengeEs;
			$totalTime = $aMissoinInfo['challenge_limit_duration'] * 60;
			$leftTime = $aMissoinInfo['challenge_limit_duration'] * 60 - $aMyEsList['time'];
			$thisScore = intval($leftTime / $totalTime * 2000 + 8000 * $thisCorrcetRate);

			//系统关卡数据
			$aSysMissionCount = array();
			$aSysMissionCount['id'] = $aMissoinInfo['id'];
			$aSysMissionCount['challenge_success_count'] = $aMissoinInfo['challenge_success_count'] + 1;
			$aPassRecored = array(
				'user_id' => $userId,
				'pass_time' => time(),
				'score' => $thisScore
			);

			$isExistsMe = false;
			$recordNums = count($aMissoinInfo['recent_record']);
			foreach($aMissoinInfo['recent_record'] as $key => $aRecord){
				if($aRecord['user_id'] == $userId){
					$isExistsMe = $key;
					break;
				}
			}
			if($isExistsMe !== false){
				if($thisScore > $aMissoinInfo['recent_record'][$isExistsMe]['score']){
					$aMissoinInfo['recent_record'][$isExistsMe] = $aPassRecored;
				}
			}elseif($recordNums < 10){
				array_unshift($aMissoinInfo['recent_record'], $aPassRecored);
			}elseif($recordNums >= 10){
				$minRecord = 0;
				for($j = 1; $j <= ($recordNums - 1); $j++){
					if($aMissoinInfo['recent_record'][$minRecord]['score'] > $aMissoinInfo['recent_record'][$j]['score']){
						$minRecord = $j;
					}
				}
				if($thisScore > $aMissoinInfo['recent_record'][$minRecord]['score']){
					unset($aMissoinInfo['recent_record'][$minRecord]);
					array_unshift($aMissoinInfo['recent_record'], $aPassRecored);
				}
			}
			$aSysMissionCount['recent_record'] = $aMissoinInfo['recent_record'];
			if(!$oMission->setMission($aSysMissionCount)){
				return false;
			}

			//个人关卡
			$now = time();
			$aMissionCount = array(
				'id' => $aMyMission['id'],
				'is_pass' => 1,
				'pass_time' => $now,
				'best_score_time' => $now,
				'score' => $thisScore,
				'lottery_draw_status' => 1,
			);

			$aChistory = array(
				'pass_time' => $now,
				'duration' => $aMyEsList['time'],
				'use_blood' => $aMissoinInfo['challenge_limit_blood'] - $aMyEsList['life'],
				'score' => $thisScore,
			);
			array_unshift($aMyMission['challenge_history'], $aChistory);
			$aMissionCount['challenge_history'] = $aMyMission['challenge_history'];
			if(!$oMission->setUserMission($aMissionCount)){
				return false;
			}

			//成功挑战之后
			$oGame = new Game();
			if(!$oGame->successChallenge($aMyMission, $aMissoinInfo, 6, $aMyEsList['time'], $aMyEsList['rightEsCount'], 1, $thisScore, $topScore, $passMissionNum)){
				return false;
			}

			//自动开启下一关
			$aNextMission = $oMission->getNextMissionInfo($aMissoinInfo['subject_id'], $aMissoinInfo['orders']);
			if($aNextMission){
				if(!$oMission->getUserMissionInfo($aNextMission['id'], $userId)){
					$aNewMission = array(
						'user_id' => $userId,
						'mission_id' =>  $aNextMission['id'],
						'is_task_finish' => 0,
						'is_pass' => 0,
						'es_count' => 0,
						'es_correct_count' => 0,
						'score' => 0,
						'create_time' => $now,
						'pass_time' => 0,
						'best_score_time' => 0,
						'last_es_id' => 0,
						'task_process' => 0,
						'current_challenge_process' => array(),
						'challenge_history' => array(),
					);
					if(!$oMission->addUserMission($aNewMission)){
						return false;
					}
				}
			}
			//我在好友中的排名
			$oSns = m('Sns');
			$userIds = $oSns->getUserFriendIds($userId);
			if($userIds){
				$userIds .= ',' . $userId;
			}else{
				$userIds = $userId;
			}
			$aFriendRanking = $oMission->getTopScoreUserListByMissionIdAndUserIds($aMyMission['mission_id'], explode(',', $userIds));
			foreach($aFriendRanking as $key => $aFriend){
				if($userId == $aFriend['user_id']){
					$friendRanking = $key + 1;
					break;
				}
			}

			//返回结果

			$corrcetRate = intval($aMyEsList['rightEsCount'] / $challengeEs * 100);
			$aThisResult = array();
			$aThisResult['show_type'] = 'MISSIONSUCCESS';
			$aThisResult['custom_data']['time'] = time();
			$aThisResult['custom_data']['correct_rate'] = $corrcetRate;
			$aThisResult['custom_data']['score'] = $thisScore / 100;
			$aThisResult['custom_data']['wrong_es_count'] = $aMissoinInfo['challenge_limit_blood'] - $aMyEsList['life'];
			$aThisResult['custom_data']['spand_time'] = $aMyEsList['time'];
			$aThisResult['custom_data']['best_score'] = $thisScore / 100;
			$aThisResult['custom_data']['mission_correct_rate'] = intval($aMyMission['es_correct_count'] / $aMyMission['es_count'] * 100);
			$aThisResult['custom_data']['lottery_draw'] = 1;
			$aThisResult['custom_data']['in_friend_ranking'] = $friendRanking;
			$oGame->setResult($aThisResult);
			return true;
		}else{
			return false;
		}
	}

	private function _countEsNum($aStatus, $aEsList){
		$nums = 0;
		foreach($aEsList as $esStatus){
			if(in_array($esStatus, $aStatus)){
				$nums++;
			}
		}
		return $nums;
	}

	/**
	 *	计算PK的状态
	 */
	private function _getPkStatus($aPk){
		$pkStatus = 0;
		$nowTime = time();
		$overTime = $aPk['over_time'];
		$senderStartTime = $aPk['sender_user_start_time'];
		$senderEndTime = $aPk['sender_user_end_time'];
		$receiverStartTime = $aPk['receiver_user_start_time'];
		$receiverEndTime = $aPk['receiver_user_end_time'];
		$duration = $aPk['duration'] * 60;
		$senderOverTime = $senderStartTime + $duration;
		$receiverOverTime = $receiverStartTime + $duration;
		$isSenderOverTime = $nowTime > $senderOverTime;
		$isReceiverOverTime = $nowTime > $receiverOverTime;
		$isSenderEndPk = $isSenderOverTime || $senderEndTime;
		$isReceiverEndPk = $isReceiverOverTime || $receiverEndTime;

		if($overTime > $nowTime){
			if(!$senderStartTime && !$receiverStartTime){
				$pkStatus = 1;	//双方还没开始做题
			}elseif(($senderStartTime && !$senderEndTime && !$isSenderOverTime) && !$receiverStartTime){
				$pkStatus = 2;	//发起者正在做题，接受者还没开始做题
			}elseif(($receiverStartTime && !$receiverEndTime && !$isReceiverOverTime) && !$senderStartTime){
				$pkStatus = 3;	//接受者正在做题，发起者还没开始做题
			}elseif(($senderStartTime && !$senderEndTime && !$isSenderOverTime) && ($receiverStartTime && !$receiverEndTime && !$isReceiverOverTime)){
				$pkStatus = 4;	//双方已开始做题，但还没完成
			}elseif(($isSenderEndPk || $isSenderOverTime) && !$receiverStartTime){
				$pkStatus = 5;	//发起者完成了PK，接受者还没开始做题
			}elseif(($isSenderEndPk || $isSenderOverTime) && !$isReceiverEndPk){
				$pkStatus = 6;	//发起者完成了PK，接受者正在做题
			}elseif(($isReceiverEndPk || $isReceiverOverTime) && !$senderStartTime){
				$pkStatus = 7;	//接受者完成了PK，发起者还没开始做题
			}elseif(($isReceiverEndPk || $isReceiverOverTime) && !$isSenderEndPk){
				$pkStatus = 8;	//接受者完成了PK，发起者正在做题
			}elseif($isSenderEndPk && $isReceiverEndPk){
				$pkStatus = 9;	//PK结束
			}
		}else{
			$pkStatus = 9;		//PK结束
		}

		return $pkStatus;
	}

	public function useMtgh($userId, $pkId, $esId, $propId){
		$oPk = m('Pk');
		$aPk = $oPk->getDetailPkInfo($pkId);
		if(!$aPk){
			return false;
		}

		$statusCode = $this->_getPkStatus($aPk);
		if($userId == $aPk['sender_user_id']){
			$role = 'sender';
		}elseif($userId == $aPk['receiver_user_id']){
			$role = 'receiver';
		}else{
			return false;
		}

		$found = false;
		foreach($aPk['content'][$role . '_es_list'] as $id => $status){
			if($esId == $id && $status == 2){
				$aPk['content'][$role . '_es_list'][$id] = 1;
				$found = true;
				break;
			}
		}
		if(!$found){
			return false;
		}

		if($this->useProp($userId, $propId, 1)){
			$aUpdatePk = array(
				'id' => $aPk['id'],
				'content' => $aPk['content'],
			);

			$remainEsNums = $this->_countEsNum(array(2), $aPk['content'][$role . '_es_list']);
			if($remainEsNums == 0){
				//计算得分
				$aUpdatePk[$role . '_user_end_time'] = time();

				$oProp = propPlugin($userId);
				//时光凝结道具
				if($oProp->checkSgnj($userId, $aPk['id'])){
					$aUpdatePk[$role . '_user_end_time'] = $aUpdatePk[$role . '_user_end_time'] - 30;
					if($aUpdatePk[$role . '_user_end_time'] < $aPk[$role . '_user_start_time']){
						$aUpdatePk[$role . '_user_end_time'] = $aPk[$role . '_user_start_time'];
					}
				}
				$aPk[$role . '_user_end_time'] = $aUpdatePk[$role . '_user_end_time'];
				$rightEsNums = $this->_countEsNum(array(1), $aPk['content'][$role . '_es_list']);

				if($rightEsNums){
					$totalTime = $aPk['duration'] * 60;
					$score = intval(($totalTime - ($aUpdatePk[$role . '_user_end_time'] - $aPk[$role . '_user_start_time'])) / $totalTime * 2000 + 8000 * $rightEsNums / $aPk['es_counts']);
				}else{
					$score = 0;
				}

				//得到对方的角色
				if($role == 'sender'){
					$anotherRole = 'receiver';
					$duifangStatus = 8;

					$senderScore = $score / 100;
					$receiverScore = $aPk['receiver_score'] / 100;
					$senderSpandTime = $aUpdatePk['sender_user_end_time'] - $aPk['sender_user_start_time'];
					$ReceiverSpandTime = $aPk['receiver_user_end_time'] - $aPk['receiver_user_start_time'];
					if($aPk['sender_user_end_time'] == 0){
						$senderSpandTime = 0;
					}
					if($aPk['receiver_user_end_time'] == 0){
						$ReceiverSpandTime = 0;
					}
					$anotherId = $aPk['receiver_user_id'];
				}else{
					$anotherRole = 'sender';
					$duifangStatus = 6;

					$senderScore = $aPk['sender_score'] / 100;
					$receiverScore = $score / 100;
					$senderSpandTime = $aPk['sender_user_end_time'] - $aPk['sender_user_start_time'];
					$ReceiverSpandTime = $aUpdatePk['receiver_user_end_time'] - $aPk['receiver_user_start_time'];
					if($aPk['receiver_user_end_time'] == 0){
						$ReceiverSpandTime = 0;
					}
					if($aPk['sender_user_end_time'] == 0){
						$senderSpandTime = 0;
					}
					$anotherId = $aPk['sender_user_id'];
				}
				
				if($statusCode == $duifangStatus){
					//结果事件
					$aData = array(
						'data_id' => $aPk['id'],
						'user_id' => $aPk['sender_user_id'],
						'type' => 32,
					);
					addPersonalMessage($aData);
					$aData['user_id'] = $aPk['receiver_user_id'];
					addPersonalMessage($aData);

					//如果对方已经做完确定胜者
					if($score > $aPk[$anotherRole . '_score']){
						$aUpdatePk['winner_user_id'] = $userId;
					}elseif($score < $aPk[$anotherRole . '_score']){
						$aUpdatePk['winner_user_id'] = $aPk[$anotherRole . '_user_id'];
					}else{
						$myUserTime = $aUpdatePk[$role . '_user_end_time'] - $aPk[$role . '_user_start_time'];
						$anotherUseTime = $aPk[$anotherRole . '_user_end_time'] - $aPk[$anotherRole . '_user_start_time'];
						if($myUserTime < $anotherUseTime){
							$score++;
							$aUpdatePk['winner_user_id'] = $userId;
						}elseif($myUserTime > $anotherUseTime){
							$aPk[$anotherRole . '_score']++;
							$aUpdatePk[$anotherRole . '_score'] = $aPk[$anotherRole . '_score'];
							$aUpdatePk['winner_user_id'] = $anotherId;
						}else{
							$aUpdatePk[$role . '_user_end_time']--;
							$score++;
							$aUpdatePk['winner_user_id'] = $userId;
						}
					}

					//勋章
					$oGame = new Game();
					if(!$oGame ->afterPKEnd($aPk['sender_user_id'], $aPk['receiver_user_id'], $aUpdatePk['winner_user_id'])){
						alert('出错啦啦啦', 0);
					}

					$aThisResult = array();


					$oUser = m('User');
					$aSenderInfo = $oUser->getPersonalInfoByUserId($aPk['sender_user_id'], 'name');
					$aReceiverInfo = $oUser->getPersonalInfoByUserId($aPk['receiver_user_id'], 'name');
					$senderRightCount = $this->_countEsNum(array(1), $aPk['content']['sender_es_list']);
					$ReceiverRightCount = $this->_countEsNum(array(1), $aPk['content']['receiver_es_list']);
					$aThisResult['custom_data']['time'] = $aPk['create_time'];
					$aThisResult['custom_data']['sender'] = $aSenderInfo['name'];
					$aThisResult['custom_data']['receiver'] = $aReceiverInfo['name'];
					$aThisResult['custom_data']['sender_finished_time'] = date('n月d日 H:i:s', $aPk['sender_user_end_time']);
					$aThisResult['custom_data']['receiver_finished_time'] = date('n月d日 H:i:s', $aPk['receiver_user_end_time']);
					$aThisResult['custom_data']['sender_score'] = $senderScore;
					$aThisResult['custom_data']['receiver_score'] = $receiverScore;
					$aThisResult['custom_data']['sender_correct_count'] = $senderRightCount;
					$aThisResult['custom_data']['receiver_correct_count'] = $ReceiverRightCount;
					$aThisResult['custom_data']['sender_spand_time'] = $senderSpandTime;
					$aThisResult['custom_data']['receiver_spand_time'] = $ReceiverSpandTime;
					if($aPk['is_receive_attachment'] == 0){
						$aThisResult['custom_data']['gold'] = 0;
					}else{
						$aThisResult['custom_data']['gold'] = $aPk['attachment_gold'];
					}
					if($userId == $aUpdatePk['winner_user_id']){
						$aThisResult['show_type'] = 'PKWIN';
						$aThisResult['custom_data']['add_accumulate_points'] = $senderRightCount + $ReceiverRightCount;
					}else{
						$aThisResult['show_type'] = 'PKLOST';
					}
					$oGame->setResult($aThisResult);
				}
				$aUpdatePk[$role . '_score'] = $score;
			}
			if(!$oPk->setPk($aUpdatePk)){
				return false;
			}
			if($remainEsNums == 0){
				//PK完成
				$aResult['result']['score'] = $score / 100;
				$aResult['result']['correct_rate'] = intval($rightEsNums / $aPk['es_counts'] * 100);
				$aResult['result']['use_time'] = $aUpdatePk[$role . '_user_end_time'] - $aPk[$role . '_user_start_time'];
			}else{
				$aResult = array('next_es' => $this->_nextEs($aPk['content'][$role . '_es_list']));
			}
			return $aResult;
		}else{
			return false;
		}
	}

	public function useDjbkr($userId, $propId){
		if($this->useProp($userId, $propId, 1)){
			$oProp = m('Prop');
			$aPacket = $this->_getUserPropInfo($userId);
			$aData = array(
				'id' => $aPacket['id'],
				'prop_package' => $aPacket['prop_package'] + 10
			);
			if($oProp = $oProp->setUserProp($aData)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function useSbjf1($userId, $propId){
		return $this->_doublePoints($userId, $propId, 1);
	}

	public function useSbjf3($userId, $propId){
		return $this->_doublePoints($userId, $propId, 3);
	}

	public function useSbjf7($userId, $propId){
		return $this->_doublePoints($userId, $propId, 7);
	}

	private function _doublePoints($userId, $propId, $days){
		$oUser = m('UserNumerical');
		$aUser = $oUser->getUserNumericalInfoById($userId);
		if(!$aUser){
			return false;
		}
		$overTime = $aUser['integral_card_expiration_time'];
		if(!$overTime || $overTime < time()){
			$overTime = time();
		}
		$overTime += 86400 * $days;
		if($this->useProp($userId, $propId, 1)){
			$aData = array(
				'id' => $aUser['id'],
				'integral_card_expiration_time' => $overTime,
			);
			if($oUser->setUserNumerical($aData)){
				return $overTime;
			}else{
				return false;
			}
		}else{
			return false;
		}

	}

	private function _nextEs($aEsList){
		if(!is_array($aEsList)){
			alert('网络可能有点慢啦啦', 0);
		}

		$nextEsId = 0;
		foreach($aEsList as $esId => $esStatus){
			if($esStatus == 2){
				$nextEsId = $esId;
				break;
			}
		}
		if($nextEsId == 0){
			return false;
		}

		$oEs = m('Es');
		$aNextEs = $oEs->getOfficialEsInfoById($nextEsId);
		if(!$aNextEs){
			alert('获取ID为 <b>' . $nextEsId . '</b> 的下一题时出错啦啦啦', 0);
		}
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aNextEs['type_id']]);
		$aNextEs['es_content'] = $oEsPlugin->resolve($aNextEs['content_json']);
		$aNextEs['es_content'] = $oEsPlugin->removeAnswer($aNextEs['es_content']);
		$aNextEs['id'] = Xxtea::encrypt($aNextEs['id']);
		$now = time();
		$aNextEs['get_time'] = Xxtea::encrypt($now);
		Cookie::set('pkt', md5($now));
		return $aNextEs;
	}

	private function _resurrect($userId, $missionId, $propId, $life){
		$oMission = m('Mission');
		$aMyMission = $oMission->getUserMissionInfo($missionId, $userId);
		$aMyEsList = $aMyMission['current_challenge_process'];
		$aMyEsList['life'] = $life;
		header('life:' . $life);
		$aData = array(
			'id' => $aMyMission['id'],
			'current_challenge_process' => $aMyEsList,
		);

		if($this->useProp($userId, $propId, 1)){
			$result = $oMission->setUserMission($aData);
			if($result  !== false){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}


}