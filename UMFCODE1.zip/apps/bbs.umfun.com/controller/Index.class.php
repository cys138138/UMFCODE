<?php
class IndexController{

	public function __construct(){}

	public function index(){
		echo '<a href="/?m=thread&a=index">点击我跳转到话题模型</a>';
	}

}