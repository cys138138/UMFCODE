<?php
define('APP_LOGIN_URL', url('m=Login&a=showLogin', 'reference=' . base64_encode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']), APP_LOGIN));
define('TITLE', '  中国最大中小学生在线游戏化学习平台！');
header("Content-type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
$GLOBALS['VIEW'] = new View(APP_VIEW_PATH);

function displayHeader($title = ''){
	if($title){
		$title = $title . ' - ';
	}
	echo getHeader($title);
}

function getHeader($title = ''){
	$title .= TITLE;
	assign('title', $title);
	return fetch('header.html.php');
}

function displayFooter(){
	echo getFooter();
}

function getFooter(){
	return fetch('footer.html.php');
}