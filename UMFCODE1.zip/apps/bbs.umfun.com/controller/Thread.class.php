<?php
class ThreadController{
	private $_userId = 0;
	private $_aUser = array();

	public function __construct(){
		if($this->_checkActionIsLogin(get('a')) || isLogin()){
			$this->_aUser = checkUserLogin();
			$this->_userId = $this->_aUser['id'];
		}
		assign('user_ids', $this->_userId);
	}

	/**
	 *检查当前方法是否需要登录
	 * @param  string $action 当前方法
	 * @return boolean	存在需要登录
	 **/
	private function _checkActionIsLogin($action = ''){
		$aNoAccess = array(
			'myArticle',
			'myComment',
			'addComment',
			'myNotification',
			'setNotification',
			'delNotification',
			'readNotification',
			'getUserInfo',
			'apply',
			'support',
			'showAdd',
			'showEdit',
			'articleDo',
			'uploadFile',
			'deleteFile'
		);
		return in_array($action, $aNoAccess) ? true : false;
	}

	/**
	 *帖子列表
	 **/
	public function index(){
		$oBbs = m('Bbs');
		$page = intval(get('page', 0)) ? intval(get('page')) : 1;
		$pageSize = 20;
		$categoryId = intval(get('categoryId', 0)) ? intval(get('categoryId')) : $GLOBALS['BBS']['defult_channel'];
		$recommend = intval(get('recommend', -1));
		$top = intval(get('top', 0));
		$order = intval(get('order', 2)) ;

		//当前板块的信息
		$aCategory = $oBbs->getCategoryInfoById($categoryId);
		if($aCategory === false){
			alert('系统错误', 0);
		}else if(!$aCategory){
			alert('不存在的板块', -1);
		}
		assign('aCategory', $aCategory);

		//帖子统计
		$aThreadCondition = array(
			'category_id'	=> $categoryId,
			'is_recommend'	=> $recommend,
			'is_top'		=> $top,
			'statu'			=> 2,
			'user_id'		=> 0
		);
		$threadCount = $oBbs->getThreadCount($aThreadCondition);
		if($page > ceil($threadCount / $pageSize)){
			$page = 1;
		}

		$aFormatOrder = array(
			0 => '',
			1 => '`create_time` DESC',
			2 => '`last_reply_time` DESC',
			3 => '`read_times` DESC'
		);
		if(!array_key_exists($order, $aFormatOrder)){
			alert('请勿随意修改', 0);
		}

		//帖子列表
		$aMyThreadList = $this->_getThreadList($page, $pageSize, $categoryId, $recommend, $top, 2, $aFormatOrder[$order]);
		assign('aThread', $aMyThreadList);

		//帖子列表分页
		$url = 'http://' . APP_BBS . $_SERVER['REQUEST_URI'];
		$url = preg_replace('/&page\=\d+/', '', $url);

		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $threadCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		assign('pageHtml', page($aPageInfo));

		//今日发帖
		assign('todayPost', $oBbs->getThreadCountInToday($categoryId));

		//板块列表
		assign('aCategoryList', $this->_category());

		//置顶帖子
		assign('aThreadIsTop', $this->_istop($categoryId, 5));

		//推荐帖子
		assign('aRecommend', $this->_recommend());

		//最近赛事
		assign('aNewMatch', $this->_newMatch());

		assign('myUserInfo', $this->_aUser);
		assign('page', $page);
		displayHeader($aCategory['name'] . ' -');
		display('thread/index.html.php');
		displayFooter();
	}

	/**
	 *我的帖子列表
	 **/
	public function myArticle(){
		$page = intval(get('page', 0)) ? intval(get('page')) : 1;
		$pageSize = 20;
		$categoryId = intval(get('categoryId', 0));
		$statu = intval(get('statu', 0));

		$oBbs = m('Bbs');

		//帖子统计
		$aThreadCondition = array(
			'category_id'	=> $categoryId,
			'is_recommend'	=> -1,
			'is_top'		=> -1,
			'statu'			=> $statu,
			'user_id'		=> $this->_userId
		);

		$aMyThreadCount = $oBbs->getThreadCount($aThreadCondition);
		assign('aMyThreadCount', $aMyThreadCount);

		//当前板块的信息
		$aCategory = $oBbs->getCategoryInfoById(intval(get('categoryId', $GLOBALS['BBS']['defult_channel'])));
		if($aCategory === false){
			alert('系统错误', 0);
		}else if(!$aCategory){
			alert('不存在的板块', -1);
		}
		assign('aCategory', $aCategory);

		if($page > ceil($aMyThreadCount / $pageSize)){
			$page = 1;
		}

		$aMyThreadList = $this->_getThreadList($page, $pageSize, $categoryId, -1, -1, $statu, '', $this->_userId);
		if($aMyThreadList === false){
			alert('系统错误', 0);
		}
		foreach($aMyThreadList as $key => $value){
			$aMyThreadList[$key]['count_comment'] = $oBbs->getCommentCountByThreadId($value['id']);
		}
		assign('aMyThreadList', $aMyThreadList);

		//帖子分页
		$url = 'http://' . APP_BBS . $_SERVER['REQUEST_URI'];
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aMyThreadCount,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		assign('pageHtml', page($aPageInfo));


		//推荐帖子
		assign('aRecommend', $this->_recommend());

		//板块列表
		assign('aCategoryList', $this->_category());

		//最近赛事
		assign('aNewMatch', $this->_newMatch());

		assign('myUserInfo', $this->_aUser);
		echo getHeader('我发布的话题 -');
		assign('typeContent', $typeContent = 1);
		display('thread/my_article.html.php');
		displayFooter();
	}

	/**
	 *我的回复列表
	 **/
	public function myComment(){
		$page = intval(get('page', 0)) ? intval(get('page')) : 1;
		$pageSize = 20;
		$categoryId = intval(get('categoryId', 0)) ? intval(get('categoryId')) : $GLOBALS['BBS']['defult_channel'];

		$oBbs = m('Bbs');

		//当前板块的信息
		$aCategory = $oBbs->getCategoryInfoById($categoryId);
		if($aCategory === false){
			alert('系统错误', 0);
		}else if(!$aCategory){
			alert('不存在的板块', -1);
		}
		assign('aCategory', $aCategory);

		$countComment = $oBbs->getUserCommentCount($this->_userId);
		if($page > ceil($countComment / $pageSize)){
			$page = 1;
		}

		$aMyCommentList = $oBbs->getUserCommentList($this->_userId, $page, $pageSize);
		assign('aMyCommentList', $aMyCommentList);

		//板块列表
		assign('aCategoryList', $this->_category());

		//帖子分页
		$url = 'http://' . APP_BBS . $_SERVER['REQUEST_URI'];
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $countComment,
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		assign('pageHtml', page($aPageInfo));

		//推荐帖子
		assign('aRecommend', $this->_recommend());
		//最近赛事
		assign('aNewMatch', $this->_newMatch());

		assign('myUserInfo', $this->_aUser);
		displayHeader('我的回复列表 -');
		assign('typeContent', $typeContent = 2);
		display('thread/my_article.html.php');
		displayFooter();
	}

	/**
	 *我的消息中心
	 **/
	public function myNotification(){
		$page = intval(get('page', 0)) ? intval(get('page')) : 1;
		$pageSize = 20;
		$categoryId = intval(get('categoryId', 0)) ? intval(get('categoryId')) : $GLOBALS['BBS']['defult_channel'];

		$oBbs = m('Bbs');

		//当前板块的信息
		$aCategory = $oBbs->getCategoryInfoById($categoryId);
		if($aCategory === false){
			alert('系统错误', 0);
		}else if(!$aCategory){
			alert('不存在的板块', -1);
		}
		assign('aCategory', $aCategory);


		$aNoReadNotificationList = $this->readNotification(1, $page, $pageSize);
		if($page > ceil($aNoReadNotificationList['count'] / $pageSize)){
			$page = 1;
		}

		assign('aNoReadNotificationList', $aNoReadNotificationList['list']);

		//帖子分页
		$url = 'http://' . APP_BBS . $_SERVER['REQUEST_URI'];
		$url = preg_replace('/&page\=\d+/', '', $url);
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $aNoReadNotificationList['count'],
			'size'	=> $pageSize,
			'page'	=> $page,
		);
		assign('pageHtml', page($aPageInfo));

		//板块列表
		assign('aCategoryList', $this->_category());

		//推荐帖子
		assign('aRecommend', $this->_recommend());
		//最近赛事
		assign('aNewMatch', $this->_newMatch());

		assign('myUserInfo', $this->_aUser);
		displayHeader('我的消息中心 -');
		assign('typeContent', $typeContent = 3);
		display('thread/my_article.html.php');
		displayFooter();
	}

	/**
	 * 读取我的消息
	 */
	public function readNotification($type = 0, $page = 0, $pageSize = 0){
		if(!$this->_userId){
			exit;
		}
		$page = $page ? $page : intval(get('page', 1));
		$pageSize = $type ? $pageSize : 5;
		$aOption['user_id'] = $this->_userId;
		if(!$type){
			$aOption['is_read'] = 0;
		}

		$mBbs = m('Bbs');
		$aNoReadNotificationList = $mBbs->getNotificationList($page, $pageSize, $aOption);
		if($aNoReadNotificationList === false){
			alert('系统错误', 0);
		}

		foreach($aNoReadNotificationList as $key => $aVal){
			$aNoReadNotificationList[$key]['in_page'] = $this->_getNotificationPage($aVal['thread_id'], $aVal['create_time']);
		}
		$aContent = array(
			'list' => $aNoReadNotificationList,
			'count' => $mBbs->getNotificationCount($aOption)
		);
		unset($aNoReadNotificationList);

		if($type){
			return $aContent;
			exit;
		}
		alert('消息读取成功', 1, $aContent);
	}

	//更新消息状态
	public function setNotification(){
		$id = intval(post('id', 0));
		$type = intval(post('type', 1));
		if(!$id || !$type || $type != 1){
			alert('参数非法', 0);
		}
		$mBbs = m('Bbs');
		$aInfo = $mBbs->getNotificationById($id);
		if($aInfo === false){
			alert('系统错误', 0);
		}else if($aInfo && $aInfo['user_id'] != $this->_userId){
			alert('嘿！别乱操作', 0);
		}elseif(!$aInfo) {
			alert('不知道怎么的，数据找不到了', -1);
		}

		$aResult = $mBbs->setNotification(array(
			'id' => $id,
			'is_read' => 1
		));
		if($aResult){
			alert('修改成功', 1);
		}else{
			alert('已经阅读', -1, $aResult);
		}
	}

	//删除消息
	public function delNotification(){
		$id = intval(post('id', 0));
		if(!$id){
			alert('参数非法', 0);
		}
		$mBbs = m('Bbs');
		$aInfo = $mBbs->getNotificationById($id);
		if($aInfo === false){
			alert('系统错误', 0);
		}else if($aInfo && $aInfo['user_id'] != $this->_userId){
			alert('嘿！别乱操作', 0);
		}else if(!$aInfo){
			alert('天!我明明放这里可是数据却没找到', -1);
		}

		if($mBbs->delNotification($id)){
			alert('删除成功', 1);
		}else{
			alert('删除失败', -1);
		}
	}



	/**
	 *显示帖子内容页
	 **/
	public function article(){
		$id = intval(get('id', 0));
		if(!Yii::$app->client->isComputer){
			$gotoUrl = Yii::$app->urlManagerMobileHome->createUrl(['bbs/thread/show-simple-topic', 'topicId' => $id]);
			header('location:' . $gotoUrl);
			exit();
		}
		$page = intval(get('page', 0)) ? intval(get('page')) : 1;
		$pageSize = 20;
		$oBbs = m('Bbs');

		if(!$id){
			alert('请勿非法操作', 0);
		}

		$aArticle = $oBbs->getThreadInfoById($id);
		if($aArticle === false){
			alert('很抱歉，系统出错了', 0);
		}
		if(!$aArticle){
			alert('您访问到了一个不存在的话题, 请返回首页', 0);
		}
		if($aArticle['status'] == 1 && $aArticle['user_id'] != $this->_userId){
			alert('非法操作', 0);
		}

		$countComment = $oBbs->getCommentCountByThreadId($id);
		if($page > ceil($countComment / $pageSize)){
			$page = 1;
		}

		$aUserInfo = getUserInfo($aArticle['user_id'], array('numerical'));
		if($aUserInfo === false){
			alert('很抱歉，系统出错了', 0);
		}
		$aArticleComment = $this->_comment($id, $page, $pageSize);
		if($aArticleComment === false){
			alert('很抱歉，系统出错了', 0);
		}
		$aMyNewArticle = [];
		if($aArticle['is_anonymous']){
			$aUserInfo['id'] = 0;
			$aUserInfo['name'] = '匿名用户';
			$aUserInfo['profile'] = '';
			$aUserInfo['level'] = '?';
			$aUserInfo['vip'] = 0;
		}else{

			$aMyNewArticle = $this->_myNewArticle(5, $aArticle['category_id'], $aArticle['user_id']);
			if($aMyNewArticle === false){
				alert('很抱歉，系统出错了', 0);
			}
		}

		//推荐帖子
		assign('aRecommend', $this->_recommend());

		//当前板块的信息
		$aCategory = $oBbs->getCategoryInfoById($aArticle['category_id']);
		if($aCategory === false){
			alert('系统错误', 0);
		}else if(!$aCategory){
			alert('不存在的板块', -1);
		}
		$aCategory['keywords'] = $aArticle['title'] . ',' . TITLE;
		$aCategory['descript'] = mb_substr(strip_tags($aArticle['content']), 0, 80);
		assign('aCategory', $aCategory);

		//板块列表
		assign('aCategoryList', $this->_category());

		//评论分页
		$url = url('m=Thread&a=article&id=' . $id );
		$aPageInfo = array(
			'url'	=> $url . '&page=_PAGE_',
			'total' => $countComment,
			'size'	=> $pageSize,
			'page'	=> $page,
		);

		assign('pageHtml', page($aPageInfo));
		assign('countComment', $countComment);
		assign('aMyNewArticle', $aMyNewArticle);
		assign('aCurrentUser', getUserInfo($this->_userId, array('numerical')));
		assign('aArticleComment', $aArticleComment);
		assign('aUserInfo', $aUserInfo);
		assign('aArticle', $aArticle);
		displayHeader($aArticle['title'] . ' -');
		display('thread/article.html.php');
		displayFooter();
	}

	/**
	 *获取评论列表
	 * @return  array  评论列表集
	 **/
	private function _comment($threadId = 0, $page = 1, $pageSize = 20){
		$oBbs = m('Bbs');
		$aCommentTemp = $oBbs->getCommentListByThreadId($threadId, $page, $pageSize);
		if($aCommentTemp === false){
			return false;
		}

		$aComment = array();

		foreach($aCommentTemp as $key => $aCommentValue){
			$aParentInfo = $aCommentValue['parent_id'] ? $aCommentValue['parent_info'] : array();
			$aComment[$key] = array(
				'id' => $aCommentValue['id'],
				'thread_id' => $aCommentValue['id'],
				'parent_id' => $aCommentValue['parent_id'],
				'user_id' => $aCommentValue['user_id'],
				'user_info' => $aCommentValue['user_info'],
				'support_times' => $aCommentValue['support_times'],
				'create_time' => $aCommentValue['create_time'],
				'content' => $aCommentValue['content'],
				'resource_list' => $aCommentValue['resource_list'],
				'parent_info' => $aParentInfo
			);
		}
		unset($aCommentTemp);
		return $aComment;
	}

	/**
	 *更新阅读
	 **/
	public function upArticleCount(){
		$aArticle = array(
			'id' => intval(get('id', 0)),
			'read_times' => array('add', 1)
		);
		if(!$aArticle['id']){
			alert('ID错误', 0);
		}
		$oBbs = m('Bbs');
		if(!$oBbs->getThreadInfoById($aArticle['id'])){
			alert('不存在帖子', 0);
		}

		$status = $oBbs->setThread($aArticle);
		if($status){
			alert('成功', 1, $status);
		}else{
			alert('失败', 0, $status);
		}

	}

	/**
	 *增加评论保存操作
	 **/
	public function addComment(){
		$content = isset($_POST['content']) ? $_POST['content'] : '';
		$aComment = array(
			'thread_id'		=> intval(post('threadId', 0)),
			'parent_id'		=> intval(post('parentId', 0)),
			'user_id'		=> $this->_userId,
			'content'		=> $this->_delHtml($content),
			'create_time'	=> time()
		);

		if(!$aComment['thread_id'] || !$aComment['user_id'] || !$aComment['content']){
			alert('请勿非法操作以博取我们同情', 0);
		}
		$postContent = trim($aComment['content']);
		$postContent = str_replace('&nbsp; ', '', $postContent);
		$postContent = str_replace('&nbsp;', '', $postContent);
		if(strlen(strip_tags($postContent)) < 5){
			alert('回复内容至少5个字符', 0);
		}else if(strlen(strip_tags($postContent)) > 10000){
			alert('回复内容太长', 0);
		}

		$oBbs = m('Bbs');
		$aParentInfo = $oBbs->getCommentById($aComment['parent_id']);
		if($aComment['parent_id'] != 0 && !$aParentInfo){
			alert('您没法回复不存在的评论', 0);
		}

		$aThreadInfo = $oBbs->getThreadInfoById($aComment['thread_id']);
		if(!$aThreadInfo){
			alert('不存在帖子', 0);
		}

		if(!$oBbs->setThread(array('id' => $aComment['thread_id'], 'last_reply_time' => time()))){
			alert('增加回复失败', 0);
		}

		$aGetFileAndContent = $this->_getRemoveFileAndUpdateContent($aComment['content']);
		if(!$aGetFileAndContent){
			alert('内容保存时出错了', -1);
		}

		$aComment['resource_list'] = $aGetFileAndContent['files'];
		$aComment['content'] = $aGetFileAndContent['content'];
		if(!$aComment['content']){
			Yii::error((string)Yii::$app->buildError('空的回复内容', false, $aComment['content']));
		}
		$status = $oBbs->addComment($aComment);
		if(!$status){
			alert('发表失败', -1, $status);

		}

		$countComment = $oBbs->getCommentCountByThreadId($aComment['thread_id']);
		if($countComment === false){
			alert('系统出错', 0);
		}

		if(!($this->_userId == $aThreadInfo['user_id']) || !($this->_userId == $aThreadInfo['user_id'])){
			$aData = array(
				'user_id' => $aComment['parent_id'] ? $aParentInfo['user_id'] : $aThreadInfo['user_id'],
				'comment_id' => $status,
				'is_read' => 0
			);
			if(!$oBbs->addNotification($aData)){
				alert('通知用户时失败', -1);
			}
		}
		alert('发表成功', 1, $countComment);
	}

	/**
	 *点赞
	 **/
	public function support(){
		$type = intval(post('type', 0));
		$id = intval(post('id', 0));
		$oBbs = m('Bbs');
		$statu = null;
		if($type == 1){
			$statu = $oBbs->setThread(array(
				'id' => $id,
				'support_times' => array('add', 1)
			));
		}else if($type == 2){
			$statu = $oBbs->setCommentIndex(array(
				'id' => $id,
				'support_times' => array('add', 1)
			));
		}else{
			alert('我知道你肯定很无聊', -1);
		}
		alert('操作成功', $statu);
	}

	/**
	 *增加文章视图
	 **/
	public function showAdd(){

		//板块列表
		assign('aCategoryList', $this->_category());
		assign('myUserInfo', $this->_aUser);
		assign('currentCategory', (int)get('categoryId'));
		displayHeader('发布话题');
		display('thread/add.html.php');
		displayFooter();
	}

	/**
	 *编辑内容视图
	 **/
	public function showEdit(){
		$threadId = intval(get('id', 0));

		$aArticleInfo = m('Bbs')->getThreadInfoById($threadId);
		if($aArticleInfo === false){
			alert('总觉得系统出错了', -1);
		}else if(!$aArticleInfo){
			alert('找不到这个话题', -1);
		}
		assign('aArticleInfo', $aArticleInfo);
		//板块列表
		assign('aCategoryList', $this->_category());
		assign('threadId', $threadId);
		displayHeader('编辑话题 -');
		display('thread/edit.html.php');
		displayFooter();
	}

	/**
	 *增加、保存修改的操作
	 * @param  integer $type 修改类型 1增加话题 2修改话题
	 * @return boolean	增加、修改 成功、失败
	 **/
	public function articleDo(){
		Yii::info('帖子操作记录','bbs_commit_data');
		$type = intval(post('type', 0));
		$content = isset($_POST['content']) ? $_POST['content'] : '';
		$aArticle = array(
			'title'				=> post('title', ''),
			'user_id'			=> $this->_userId,
			'content'			=> $this->_delHtml($content),
			'create_time'		=> time(),
			'last_reply_time'	=> time()
		);

		if(!$aArticle['title'] || $aArticle['user_id'] != $this->_userId){
			alert('你确定你没逗我笑？', -1);
		}

		if(strlen(strip_tags($aArticle['title'])) < 5){
			alert('标题必须在5个字符以上', -1);
		}else if(strlen(strip_tags($aArticle['title'])) > 90){
			alert('标题太长', -1);
		}

		$postContent = trim($aArticle['content']);
		$postContent = str_replace('&nbsp; ', '', $postContent);
		$postContent = str_replace('&nbsp;', '', $postContent);
		if(strlen(strip_tags($postContent)) < 5){
			alert('内容必须在5个字符以上', -1);
		}else if(strlen(strip_tags($postContent)) > 18000){
			alert('内容太长', -1);
		}

		$status = 0;
		$aArticle['status'] = intval(post('status', 0));
		if($aArticle['status'] != 1 && $aArticle['status'] != 2){
			alert('请确认你的发布状态', -1);
		}

		$oBbs = m('Bbs');
		if($type == 1){
			//发表帖子
			$aArticle['category_id'] = intval(post('categoryId', 0));
			if(!$aArticle['category_id']){
				alert('你又在逗我了', -1);
			}

			$aCategory = $oBbs->getCategoryInfoById($aArticle['category_id']);
			if($aCategory === false){
				alert('系统出错了', 0);
			}else if(!$aCategory){
				alert('没有这个板块', 0);
			}

			$aGetFileAndContent = $this->_getRemoveFileAndUpdateContent($aArticle['content']);
			if(!$aGetFileAndContent){
				alert('内容保存时出错了', -1);
			}
			$aArticle['resource_list'] = $aGetFileAndContent['files'];
			$aArticle['content'] = $aGetFileAndContent['content'];
			if(!$aArticle['title'] || !$aArticle['content']){
				throw Yii::$app->buildError('发布空帖子内容', true, $_POST);
			}
			$status = $oBbs->addThread(array_merge(array(
				'category_id' => $aArticle['category_id'],
				'status' => $aArticle['status'],
			), $aArticle));

		}else if($type == 2){
			//编辑帖子
			$id = intval(post('id', 0));
			if(!$id){
				alert('别那么牛逼,没这ID', -1);
			}

			$aArticleInfo = $oBbs->getThreadInfoById($id);
			if($aArticleInfo === false){
				alert('总觉得系统出错了', -1);
			}else if(!$aArticleInfo){
				alert('找不到这个话题', -1);
			}
			if($aArticle['status'] == 1 && $aArticleInfo['status'] == 2){
				alert('已经发布的话题无法修改为草稿', -1);
			}

			$aGetFileAndContent = $this->_getRemoveFileAndUpdateContent($aArticle['content'], $aArticleInfo['resource_list']);
			if(!$aGetFileAndContent){
				alert('内容保存时出错了', -1);
			}
			$aArticle['resource_list'] = $aGetFileAndContent['files'];
			$aArticle['content'] = $aGetFileAndContent['content'];
			if(!$aArticle['title'] || !$aArticle['content']){
				throw Yii::$app->buildError('发布空帖子内容', true, $_POST);
			}
			$status = $oBbs->setThread(array_merge(array(
				'id' => $id,
				'status' => $aArticle['status'],
			), $aArticle));
			$status ? alert('成功', 1, $status) : alert('失败', -1, $status);
		}else{
			alert('Why are you So Diao?', -1);
		}
		$status ? alert('成功', 1, $status) : alert('失败', -1, $status);
	}

	/**
	 *百度编辑器上传文件
	 **/
	public function uploadFile(){
		$editorId = get('editorid');
		$profileName = md5(str_replace('.', '',  microtime(true)) . $this->_userId);
		$twoNumberId = substr($this->_userId, -2) . '/';
		$oUploader = new UploadFile(512000, 'jpg,png,gif', '', SYSTEM_RESOURCE_PATH . USER_TMP_PATH . $twoNumberId,  $profileName);
		$oUploader->uploadReplace = true;
		$uploadFileInfo = $oUploader->upload();
		if(!$uploadFileInfo){
			exit("<script>parent.UM.getEditor('". $editorId ."').getWidgetCallback('image')('', '" . $oUploader->getErrorMsg() . "')</script>");
		}
		$uploadFileInfo =  $oUploader->getUploadFileInfo();
		$uploadFileInfo = $uploadFileInfo[0];
		$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty($_POST['ajax']) || !empty($_GET['ajax']);
		if($isAjax){
			exit($twoNumberId . $uploadFileInfo['savename']);
		}else{
			exit("<script>parent.UM.getEditor('". $editorId ."').getWidgetCallback('image')('" . $twoNumberId . $uploadFileInfo['savename'] . "','" . 'SUCCESS' . "')</script>");
		}
	}

	/**
	 * 获取用户信息
	 * 表单参数：userId（可选，默认为当前登陆用户）
	 */
	public function getUserInfo(){
		User::getUserInfo();
	}

	public function apply(){
		User::apply(post('verify_text_info'), post('user_id'), $this->_userId);
	}

	public function ignoreNotice(){
		$oBbs = m('bbs');
		$result = $oBbs->ignoreUserNotice($this->_userId);
		alert('', 1, $result);
	}

	/**
	 * 用户的论坛卡片信息
	 * @param  integer $userId 用户ID
	 * @return array 当前用户的论坛卡片基本信息
	 */
	public function getMyMedalAndUserInfo(){
		$userId = intval(post('userId', 0));
		if(!$userId){
			alert('非法用户', 0);
		}
		$oNumerical = m('UserNumerical');
		$aMedalList = $oNumerical->getMedalListByUserIds(array($userId));
		if($aMedalList === false || !$aMedalList){
			return $aMedalList;
		}

		$oUserNumerical = m('UserNumerical');
		$aUserMedal = $oUserNumerical->getMedalInfoById($userId);
		if(!$aUserMedal){
			$aUserMedal = array();
			$aUserMedal['id'] = $userId;
			$aUserMedal['passed_missions'] = 0;
			$aUserMedal['excellent_missions'] = 0;
			$aUserMedal['pk_win_times'] = 0;
			$aUserMedal['gold_medal'] = 0;
			$aUserMedal['silver_medal'] = 0;
			$aUserMedal['cuprum_medal'] = 0;
			$aUserMedal['medal_process'] = array();
			if(!$oUserNumerical->addMedal($aUserMedal)){
				alert('系统错误', 0);
			}
		}

		$aMedal = array();
		$aNgetMedal = array();
		$oNum = new Numerical();
		foreach(Numerical::$aIdMedalRelation as $medalId => $aSysMedal){
			if($aUserMedal[$aSysMedal['db_field']] >= $GLOBALS[$aSysMedal['config_key']][1]['nums']){
				$aMedal[$aSysMedal['db_field']] = array();
				$aMedal[$aSysMedal['db_field']]['name'] = $GLOBALS['MEDAL_EVENT'][$medalId];
				$aMedal[$aSysMedal['db_field']]['level'] = $oNum->countLevel($medalId, $aUserMedal[$aSysMedal['db_field']]);
				$aMedal[$aSysMedal['db_field']]['point'] = $aUserMedal[$aSysMedal['db_field']];
				$aMedal[$aSysMedal['db_field']]['top_level'] = count($GLOBALS[$aSysMedal['config_key']]);
				if($aMedal[$aSysMedal['db_field']]['level'] < $aMedal[$aSysMedal['db_field']]['top_level']){
					$nextLevel = $aMedal[$aSysMedal['db_field']]['level'] + 1;
					$aMedal[$aSysMedal['db_field']]['next_left_point'] = $GLOBALS[$aSysMedal['config_key']][$nextLevel]['nums'] - $aMedal[$aSysMedal['db_field']]['point'];
				}
				$aMedal[$aSysMedal['db_field']]['img'] = $GLOBALS['MEDAL_IMG'][$medalId];

			}else{
				$aNgetMedal[$aSysMedal['db_field']] = array();
				$aNgetMedal[$aSysMedal['db_field']]['name'] = $GLOBALS['MEDAL_EVENT'][$medalId];
				$aNgetMedal[$aSysMedal['db_field']]['img'] = $GLOBALS['MEDAL_IMG'][$medalId];
			}
		}

		//帖子统计
		$aThreadCondition = array(
			'statu'		=> 2,
			'user_id'	=> $userId
		);
		$threadCount = m('Bbs')->getThreadCount($aThreadCondition);
		if($threadCount === false){
			alert('系统错误', 0);
		}

		//好友统计
		$aFriendCount = m('Sns')->getUserFriendCount($userId);
		if($aFriendCount === false){
			alert('系统错误', 0);
		}

		$aMedalInfo = array_merge($aMedalList[0], array(
			'user_info' => getUserInfo($userId, array('numerical', 'class')),
			'friend_count' => $aFriendCount,
			'thread_count' => $threadCount,
			'aMedal' => $aMedal,
			'aNgetMedal' => $aNgetMedal,
			'isMeFriend' => 0
		));
		if($this->_userId){
			$aMyFriendIdsList = array_merge(getUserFriendIds($this->_userId), array($this->_userId));
			if(in_array($aMedalInfo['id'], $aMyFriendIdsList)){
				$aMedalInfo['isMeFriend'] = 1;
			}
		}

		unset($aMedalList);
		unset($aMedal);
		unset($aNgetMedal);
		unset($aMedalInfo['medal_process']);
		alert('加载成功', 1, $aMedalInfo);

	}

	/**
	 *保存正式上传的图片同时更新文章内的图片
	 * @return array array('files','content')
	 **/
	private function _getRemoveFileAndUpdateContent($content = '', $aArticleFiles = array()){
		if(!$content){
			return;
		}

		$aRexpGetFile = $aUmfunTempFile = $aUmfunTemp = $aResultFile = $tmps = array();
		//先拿出所有地址地址
		preg_match_all('/ src="(.+?)"/i', $content, $aRexpGetFile, PREG_PATTERN_ORDER);
		foreach($aRexpGetFile[1] as $aFile){
			if(strpos($aFile, 'umfun')){
				//拿出优满分的图片
				$aUmfunTempFile = $aUmfunTemp[] = str_replace(SYSTEM_RESOURCE_URL , '/' ,$aFile);
				$fileHash = substr($aUmfunTempFile,-36,-4);
				//地址移动处理
				if(!file_exists(SYSTEM_RESOURCE_PATH . ltrim($aUmfunTempFile, '/'))){
					return false;
				}else{
					$randKey = substr(rand(time(),99), -2);
					$newFile = str_replace(USER_TMP_PATH, PRODUCT_BBS_IMAGE_PATH, '/' . PRODUCT_BBS_IMAGE_PATH . $randKey . '/' .substr($aUmfunTempFile,-36));

					//计算交集
					if(isset($aArticleFiles) && array_key_exists($fileHash, $aArticleFiles)){
						$tmps[$fileHash] = $aArticleFiles[$fileHash];
						unset($aArticleFiles[$fileHash]);
					}

					if(!array_key_exists($fileHash, $tmps)){
						//移动函数
						if(rename(SYSTEM_RESOURCE_PATH . ltrim($aUmfunTempFile, '/'), SYSTEM_RESOURCE_PATH . ltrim($newFile, '/'))){
							$aResultFile[$fileHash] = $newFile;
							$content = str_replace($aUmfunTempFile, $newFile, $content);
						}
					}
				}
			}
		}
		//删除沉淀数据
		if(isset($aArticleFiles)){
			foreach($aArticleFiles as $hash => $file){
				if(!unlink(SYSTEM_RESOURCE_PATH . ltrim($file, '/'))){
					myLog('话题图片删除失败，路径是：' . SYSTEM_RESOURCE_PATH . ltrim($file, '/'));
				}
			}
		}
		return array('files' => array_merge($aResultFile, $tmps), 'content' => $content);
	}

	/**
	 *板块列表
	 * @return array
	 **/
	private function _category(){
		$aCategoryList = array();
		$aCategoryCondition = array(
			 'statu' => 1,
			 'order' => '`order` ASC'
		 );
		$aCategoryList = m('Bbs')->getCategoryList(1, 0, $aCategoryCondition);
		if($aCategoryList === false){
			return false;
		}
		return $aCategoryList;
	}

	/**
	 *我的最新主题
	 * @return array	我的最新主题
	 **/
	private function _myNewArticle($pageSize = 5, $categoryId = 0, $userId = 0){
		$aMyNewArticle = $this->_getThreadList(1, $pageSize, $categoryId, -1, -1 , 2, '', $userId);
		if($aMyNewArticle === false){
			return false;
		}
		return $aMyNewArticle;
	}

	/**
	 *获取帖子列表
	 * @return array	获取帖子列表
	 **/
	private function _getThreadList($page = 1, $pageSize = 10, $categoryId = 0, $recommend = -1, $top = -1, $statu = 2, $order = '', $userId = 0){
	//帖子列表
		$aThread = array();
		$aThreadCondition = array(
			'category_id'	=> $categoryId,
			'is_recommend'	=> $recommend,
			'is_top'		=> $top,
			'statu'			=> $statu,
			'user_id'		=> $userId
		);

		$aThread = m('Bbs')->getThreadList($page, $pageSize, $aThreadCondition, $order);
		if($aThread === false){
			return false;
		}
		return $aThread;
	}

	/**
	 *推荐话题
	 * @return array	最新推荐话题
	 **/
	private function _recommend(){
		$aIsRecommendOption = array(
			'category_id'	=> 0,
			'is_recommend'	=> 1,
			'is_top'		=> -1,
			'statu'			=> 2
		);
		$aIsRecommend = m('Bbs')->getThreadList(1, 10, $aIsRecommendOption, '`create_time` DESC');
		if($aIsRecommend === false){
			return false;
		}

		return $aIsRecommend;
	}

	/**
	 *置顶话题
	 * @return array	置顶话题
	 **/
	private function _istop($categoryId = 0, $pageSize = 5){
		$aIsTopOption = array(
			'category_id'	=> $categoryId,
			'is_recommend'	=> -1,
			'is_top'		=> 1,
			'statu'			=> 2
		);
		$aThreadIsTop = m('Bbs')->getThreadList(1, $pageSize, $aIsTopOption);
		if($aThreadIsTop === false){
			return false;
		}

		return $aThreadIsTop;
	}

	/**
	 *最近比赛
	 * @return array	最新推荐话题
	 **/
	private function _newMatch(){
		$oMatch = m('Match');
		$aCondition['status'] = 8;
		$order = '`match_start_time` ASC';
		$aNewMatch = $oMatch->getMatchList($aCondition, 1, 10, $order);

		if($aNewMatch === false){
			return false;
		}

		return $aNewMatch;
	}

	//
	private function _delHtml($str){
		$farr = array(
			"/\s+|\n|\r\n/", //过滤多余空白
			 //过滤 <script>等可能引入恶意内容或恶意改变显示布局的代码,如果不需要插入flash等,还可以加入<object>的过滤
			"/<(\/?)(script|i?frame|style|html|body|title|link|meta|\?|\%)([^>]*?)>/isU",
			"/(<[^>]*)on[a-zA-Z]+\s*=([^>]*>)/isU",//过滤javascript的on事件
		);
		$tarr = array(
			" ",
			"＜\1\2\3＞",//如果要直接清除不安全的标签，这里可以留空
			"\1\2",
		);
		$str = preg_replace($farr, $tarr, $str);
		return $str;
	}

	private function _getNotificationPage($threadId = 0, $commentTime = 0){
		if(!$threadId || !$commentTime){
			return false;
		}
		$aOption = array(
			'thread_id' => $threadId,
			'create_time' => $commentTime
		);
		$countLessThanCommentTime = m('Bbs')->getCommentTimeLessThanCount($aOption);
		if($countLessThanCommentTime === false){
			return false;
		}
		return ceil($countLessThanCommentTime / 20);
	}
}
