<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
if(!empty($aCategory['keywords'])){
	 echo '<meta name="keywords" content="' . $aCategory['keywords'] . '">' . PHP_EOL;
}
if(!empty($aCategory['descript'])){
	 echo '<meta name="description" content="' . $aCategory['descript'] . '">' . PHP_EOL;
}
?>

<link rel="shortcut icon" href="<?php echo $GLOBALS['RESOURCE']['favicon']; ?>" />
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_global2']; ?>" />
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_topic']; ?>" />


<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_global2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['library']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery_cookie']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_topic']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['script_ualert']; ?>"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ubox']['path'] . $GLOBALS['RESOURCE']['ubox']['js']; ?>"></script>
<title><?php echo $title;?></title>
</head>
<body>
<!--工具条 [-->
<div class="toolbar">
	<div class="column c">
		<div class="login_menu c">
			<em id="text">欢迎来到UMFun，请</em>
			<a id="link1" target="_parent" href="<?php echo APP_LOGIN_URL; ?>">登陆</a>&nbsp;
			<span id="msg"></span>&nbsp;
			<a id="link2" target="_parent" href="<?php echo url('m=Login&a=showLogin', '', APP_LOGIN); ?>">注册</a>
		</div>

		<div class="quick_menu c">
			<a href="<?php echo url('m=Index&a=index', '', APP_HOME); ?>" class="hightlight" target="_blank">UMFun首页</a>
			<a href="<?php echo url('m=Match&a=showNewCenter', '', APP_HOME); ?>" target="_blank">游戏中心</a>
			<a href="<?php echo url('m=Exchange&a=index', '', APP_HOME); ?>" target="_blank">兑换商城</a>
			<?php if(!(isset($gXxtUserId) && $gXxtUserId)){ ?>
			<a href="<?php echo url('m=Index&a=index', '', APP_VIP); ?>" target="_blank">会员中心</a>
			<a href="<?php echo url('m=Pay&a=showVipPay', '', APP_PAY); ?>" target="_blank">充值中心</a>
			<?php } ?>
		</div>
	</div>
</div>




<!--工具条 ]-->
<script type="text/javascript">
		function getQueryString(name) {
			var result = location.search.match(new RegExp('[\?\&]' + name + '=([^\&]+)', 'i'));
			if (result == null || result.length < 1) {
				return '';
			}
			return result[1];
		}
<?php
	$aUserInfo = array(
		'profile' => '',
		'level' => 0
	);
	if($user_ids){
		$aUserInfo = getUserInfo($user_ids, array('numerical'));
	}
?>
		$(function(){
			ajax({
				url : '<?php echo url('m=Account&a=getLoginInformation', 'ajax=1&jsoncallback=_var', APP_HOME); ?>'.replace('_var', '?')
				,type : 'get'
				,crossdomain : true
				,success : function(aResult){
					if(aResult.status == 1){
						$('#text').html('你好,<a href="<?php echo url('m=Index&a=index', '', APP_HOME); ?>"><img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php echo SYSTEM_RESOURCE_URL . $aUserInfo['profile'] ?>" onload="h(this)" />'  + aResult.data.name +'(' + aResult.data.id + ')' + '！</a>');
						$('#msg').html('<a href="<?php echo url('m=Thread&a=myArticle');?>" class="lh">我的话题</a>  <span class="message"> <a href="<?php echo url('m=Thread&a=myNotification'); ?>">消息</a><em class="tags" id="messageNumber">0</em><div class="message-center" id="message"></div></span><script>readNotification();<\/script>')
						$('#link1').html('LV(<?php echo $aUserInfo['level'] ?>)');
						$('#link1').attr('href', '<?php echo url('m=Index&a=index', '', APP_HOME); ?>');
						$('#link2').html('[退出]');
						$('#link2').attr('href', '<?php echo url('m=Account&a=logout', 'jump=' . base64_encode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']), APP_HOME); ?>');
					}
				}
			});

			var sf = getQueryString('sf');
			if(sf){
				$.cookie('sf', sf, {expires:30, path:'/', domain:'<?php echo DOMAIN_EXTEND; ?>'});
			}

			toolbarPop(); //全局
			newsIsRead(); //全局
		});


// 全局
function newsIsRead(){
	$('.msg-center-content .post,.tp_news_list .topic').click(function(){
		$(this).css('color','#666');
	});
}


// 全局
function toolbarPop(){
	$(document).on({
		mouseover: function(event){
			var event = window.event||event;
			var eTarget = event.srcElement?event.srcElement:event.target;
			if($(eTarget).is('.message')){
				$('.message-center').fadeIn();
			}
		},
		mouseout: function(event){
			var event = window.event||event;
			var eTarget = event.srcElement?event.srcElement:event.target;
			if($(eTarget).closest('.message').length==0){
				$('.message-center').fadeOut();
			}
		}
	})
}


function readNotification(){
	var notificationHtml = '';
	$.get(
		'/?m=Thread&a=readNotification',
		function(aResult){
			if(aResult.status == 1){
				var aData = aResult.data.list;
				if(aData.length < 1){
					$('.message .tags').addClass('disabled');
					return;
				}

				var liHtml = '',
					contentHtml= '';

				for(var i in aData){
					if(aData[i].parent_id > 0){
						contentHtml = '回复了你的评论<a href="/?m=Thread&a=article&id=' +  aData[i].thread_id + '&notify=' +  aData[i].id + '&page=' +  aData[i].in_page + '#notify' +  aData[i].comment_id + '" class="post">' + aData[i].comment_content + '</a>';
					}else{
						contentHtml = '评论了你的话题<a href="/?m=Thread&a=article&id=' +  aData[i].thread_id + '&notify=' +  aData[i].id + '&page=' +  aData[i].in_page + '#notify' +  aData[i].comment_id + '" class="post">' + aData[i].title + '</a>';
					}
					liHtml += '<li>\
						<a href="#" class="name">' + aData[i].comment_user_info.name + '</a>\
							' + contentHtml + '\
					</li>';
				}
				notificationHtml += '<div class="msg-center-title">全部消息</div>\
				<div class="msg-center-content">\
					<ul>\
						' + liHtml + '\
					</ul>\
				</div>\
				<div class="msg-center-footer">\
						<a style="float:left;" href="javascript:void(0);" onclick="ignoreNotice()">忽略全部</a>\
					<a href="<?php echo url('m=Thread&a=myNotification'); ?>">查看更多</a>\
				</div>';
				$('#message').html(notificationHtml);
				$('#messageNumber').text(aResult.data.count);

			}else{
				$('.message .tags').addClass('disabled');
			}
		}
	);
}

function ignoreNotice(){
	ajax({
		url : '<?php echo url('m=Thread&a=ignoreNotice'); ?>',
		data : {},
		success : function(result){

		}
	});
	$('.message .tags').addClass('disabled');
	$('#messageNumber').html(0);
	$('#message').html('');
}
</script>
