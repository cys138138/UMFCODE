<div id="scrolltop2" style="display:none;"></div>

<!-- tp_uesr_popinfo -->
<div class="tp_user_pop" id="userPop" style="width:245px"></div>

<script>
var systemResourceUrl = '<?php echo SYSTEM_RESOURCE_URL; ?>',
	userHomeUrl = '<?php echo url('m=Zone&a=showHome&userId=_userId', '', APP_HOME); ?>',
	aCachePopUserInfo = [],
	DEFAULT_HEAD_IMG = '<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>';

function getUserPopInfo(userId){
	if(!userId){
		$('#userPop').html('匿名的');
		return;
	}
	if(aCachePopUserInfo[userId]){
		buildPopInfoHtml(aCachePopUserInfo[userId]);
		return;
	}
	ajax({
		url : '/?m=Thread&a=getMyMedalAndUserInfo',
		data : {userId : userId},
		success : function(aResult){
			if(aResult.status == 1){
				aCachePopUserInfo[userId] = aResult.data;
				buildPopInfoHtml(aResult.data);
			}
		}
	});
}
function buildPopInfoHtml(aData){
	var btnAddFriend = '',
		popInfoHtml = ''
		medalHtml = ''
		brandHtml = '',
		aVipInfo = <?php
		echo '{' ;
		foreach($GLOBALS['VIP'] as $vip => $aName){
				echo $vip . ' : \'' . $aName['name'] . '\',' . PHP_EOL;
		}
		echo '}';
		?>;
	if(aData.isMeFriend == 0){
		btnAddFriend = '<button id="popBtn" class="pop-btn" onclick="showApplyFriend(' + aData.user_info.id + ');">加好友</button>';
	}

	if(aData.aMedal.passed_missions){
		medalHtml += '<li>\
					<span class="icon_medal medal1"></span>\
					<div class="title">' + aData.aMedal.passed_missions.name + '</div>\
					<div class="lv">(<em>LV' + aData.aMedal.passed_missions.level + '</em>)</div>\
				</li>';
	}
	if(aData.aMedal.excellent_missions){
		medalHtml += '<li>\
					<span class="icon_medal medal2"></span>\
					<div class="title">' + aData.aMedal.excellent_missions.name + '</div>\
					<div class="lv">(<em>LV' + aData.aMedal.excellent_missions.level + '</em>)</div>\
				</li>';
	}
	if(aData.aMedal.pk_win_times){
		medalHtml += '<li>\
					<span class="icon_medal medal3"></span>\
					<div class="title">' + aData.aMedal.pk_win_times.name + '</div>\
					<div class="lv">(<em>LV' + aData.aMedal.pk_win_times.level + '</em>)</div>\
				</li>';
	}

	if(aData.gold_medal){
		brandHtml += '<li>\
					<span class="ico_brand ico_brand_gold_b"></span>\
					<div class="lv">(<em>' + aData.gold_medal + '枚</em>)</div>\
				</li>';
	}
	if(aData.silver_medal){
		brandHtml += '<li>\
					<span class="ico_brand ico_brand_silver_b"></span>\
					<div class="lv">(<em>' + aData.silver_medal + '枚</em>)</div>\
				</li>';
	}
	if(aData.cuprum_medal){
		brandHtml += '<li>\
					<span class="ico_brand ico_brand_copper_b"></span>\
					<div class="lv">(<em>' + aData.cuprum_medal + '枚</em>)</div>\
				</li>';
	}

	popInfoHtml += '<div class="user c">\
		<a href="' + userHomeUrl.replace('_userId', aData.user_info.id) + '">\
			<img alt="" src="' + DEFAULT_HEAD_IMG + '" real="' + systemResourceUrl + aData.user_info.profile + '" onload="h(this)"/>\
		</a>\
		<div class="tp_user_info">\
			<div class="tp_user_info_title vip0">\
				 <span class="tp_page_name">\
					 <a target="_blank" href="' + userHomeUrl.replace('_userId', aData.user_info.id) + '">\
						' + getVipName( aData.user_info.name , aData.user_info.vip) + '\
					 </a>\
				 </span>\
				 <span class="tp_page_vip"><i class="ico_v3 ico_v3_rank_' + (parseInt(aData.user_info.vip) + 1) + '" title="' + aVipInfo[parseInt(aData.user_info.vip)] + '"></i></span>\
				 <span class="tp_page_lv">LV(' + aData.user_info.level + ')</span>\
			</div>\
			<div class="tp_user_info_school">\
				 ' + aData.user_info.school_name + '\
			</div>\
			<div class="tp_user_info_txt">\
				 <span class="topic">话题：<em>' + aData.thread_count + '</em></span><span class="friend">好友：<em>' + aData.friend_count + '</em></span>\
			</div>' + btnAddFriend + '</div>\
		</div>\
		<div class="medal_1">\
			<ul class="c">\
				' + medalHtml + '\
			</ul>\
		</div>\
		<div class="medal_2">\
			<ul class="c">\
				' + brandHtml + '\
			</ul>\
		</div>';
	$('#userPop').html(popInfoHtml);
}
//局部
!(function(){
	function newsHoverPop(){
		var avatar = $('[data-imgPop]');
		var pop = $('.tp_user_pop');
		var avatarWidth = avatar.width();
		var avatarHeight = avatar.height();
		var popWidth = pop.width();
		var popHalfWidth = (popWidth - avatarWidth) / 2;
		var timer;

		avatar.each(function(){
			var avatarTop = Math.floor($(this).offset().top);
			var avatarLeft = Math.floor($(this).offset().left);
			$(this).hover(function(){
				getUserPopInfo($(this).data('id'));
				clearTimeout(timer);
				pop.fadeIn();
				pop.css({
					top : avatarTop + avatarHeight + 10,
					left : avatarLeft - popHalfWidth
				});
			},function(){
				clearTimeout(timer);
				timer = setTimeout(function(){
					pop.fadeOut();
				},300);
			});
		});

		pop.hover(function(){
			clearTimeout(timer);
		},function(){
			clearTimeout(timer);
			timer = setTimeout(function(){
				pop.fadeOut();
			},300);
		});

		$(document).on('click',function(event){
			var event = event || window.event;
			($(event.target).closest('.tp_user_pop').length==0)?pop.fadeOut(): '';
		})
	}
	newsHoverPop()
})();

function showApplyFriend(userId){
	UAlert.config({
		user_id : userId,
		sys_resource_url : systemResourceUrl,
		user_info_url:'<?php echo url('m=Thread&a=getUserInfo'); ?>',
		user_home_url:'<?php echo url('m=Zone&a=showHome&userId=_userId', '', APP_HOME); ?>',
		apply_friend_url:'<?php echo url('m=Thread&a=apply'); ?>'
	});
	UAlert.alertApplyFriend();
}

function setNotification(id){
	ajax({
		url : '/?m=Thread&a=setNotification',
		data : {
			id : id,
			type : 1
		},
		success : function(aResult){
			if(aResult.status == 1){
				UBox.show('阅读该消息', 1);
			}
		}
	});
}

$(function(){
	var scrolltop_obj = new goto_top();
	scrolltop_obj.init();
	<?php
	$notifyId = intval(get('notify', 0));
	if($notifyId){
		echo 'setNotification(' . $notifyId . ')';
	}
	?>
});
</script>

<!--底部 [-->
<div class="footer">
	<div class="column">
		<div class="copyright">
			<p>
				<a href="http://<?php echo APP_HOME; ?>">首页</a>|
				<?php if(!(isset($gXxtUserId) && $gXxtUserId)){ ?>
				<a href="http://<?php echo APP_PAY; ?>">充值中心</a>|
				<a href="http://<?php echo APP_VIP; ?>">会员中心</a>|
				<?php } ?>
				<a href="http://<?php echo APP_ABOUT; ?>/contract.html">服务条款</a>|
				<a href="http://<?php echo APP_ABOUT; ?>/statement.html">法律声明</a>|
				<a href="http://<?php echo APP_ABOUT; ?>/contact.html">联系我们</a>|
				<a href="http://<?php echo APP_ABOUT; ?>/contact.html">商务合作</a>
			</p>
			<p>Copyright &copy; 优满分(UMFun.com) 2013 All Rights Reserved 工信部ICP备案号：粤ICP备13000602号</p>
		</div>
	</div>
</div>
<!--底部 ]-->
</div>
<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>
<!--umfun