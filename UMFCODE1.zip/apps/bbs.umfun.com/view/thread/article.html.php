<!-- 头部 -->
<div class="tp_header" id="tpHeader">
    <div class="column">
        <a href="http://<?php echo APP_BBS; ?>">
			<div class="tp_logo"><i class="tp_icon tp_icon_logo"></i><span class="hidetxt_2">UMFun话题专区</span></div>
		</a>
    </div>
</div>

<!-- 主体 -->
<div class="tp_container" id="tpContainer">
    <div class="column">
        <!-- nav -->
        <div class="tp_nav">    
            <div class="tp_search" >　
                <!--<input type="text" id="tp_search" class="tp_search_bar" placeholder="请输入搜索内容" />
                <button class="tp_search_btn"><i class="tp_icon tp_icon_search"></i></button>-->
            </div>
            <?php 
				foreach($aCategoryList as $key => $category){
                    $changeClass = $category['id'] == $aCategory['id'] ? ' class="current"' : '';
                    echo '<a href="' . url('m=Thread&a=index&categoryId=' . $category['id']) . '" ' . $changeClass . '>' . $category['name'] . '</a>';
                }
            ?>
        </div>
        <!-- main -->
        <div class="tp_main c"> 
            <div class="tp_main_warp">
                <div class="tp_page_warp c">
                    <div class="tp_page_warp_avatar">
                        <img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php echo SYSTEM_RESOURCE_URL . $aUserInfo['profile'] ?>" onload="h(this)"  data-id="<?php echo $aUserInfo['id']; ?>" data-imgPop/>
                    </div>
                    <div class="tp_page_warp_info">
                        <h2>
                            <?php if($aArticle['status'] == 1){
								echo '<i class="tp_page_time">[草稿]</i>';
                        	}
	                        echo $aArticle['title']; ?>
                        </h2>
                        <div class="tp_page_submenu">
                            <div class="fl vip0">
                                <span class="tp_page_name">
									<a target="_blank" href="<?php echo url('m=Zone&a=showHome&userId=' . $aUserInfo['id'], '', APP_HOME); ?>">
                                    <?php echo getVipName($aUserInfo['name'], $aUserInfo['vip']); ?>
									</a>
								</span>
                                <span class="tp_page_vip"><i class="ico_v3 ico_v3_rank_<?php echo $aUserInfo['vip'] + 1; ?>" title="<?php echo $GLOBALS['VIP'][$aUserInfo['vip']]['name']; ?>"></i></span>
                                <span class="tp_page_lv">LV(<?php echo $aUserInfo['level']; ?>)</span>
                            </div>
                            <div class="fr opts">
                                <span class="tp_page_time">
                                    <script>document.write(transTime(<?php echo $aArticle['create_time']; ?>))</script>
                                    </span>
                                <span class="tp_page_view"><i class="tp_icon tp_icon_view"></i><?php echo $aArticle['read_times']; ?></span>
                                <span class="tp_page_comment"><i class="tp_icon tp_icon_comment"></i><?php echo $countComment; ?></span>
                            </div>
                        </div>
                    </div>
                    <!-- end tp_page_warp_info -->
                </div>
                <!-- end tp_page_warp -->
                <div class="tp_page_p c"><?php echo $aArticle['content']; ?></div>
                <div class="tp_page_opts fr">
                    <a href="javascript:;" onclick="support(this)" data-articleId='<?php echo $aArticle['id']; ?>' class="tp_article_support"><i class="tp_icon tp_icon_good_normal"></i>(<span class="count"><?php echo $aArticle['support_times']; ?></span>)</a>
                    <!-- .tp_icon.tp_icon_good_active 选中状态-->
                    <?php if($aCurrentUser && $aUserInfo['id'] == $aCurrentUser['id']){ ?>
                        <a href="<?php echo url('m=Thread&a=showEdit&id=' . $aArticle['id']); ?>" data-typeid="1" class="tp_btn tp_btn_grey">编辑</a>
                    <?php } ?>
                    <a href="javascript:;" onclick="showReply(this)" data-typeid="1" data-articleid="1" class="tp_btn tp_btn_blue">回复</a>
                </div>
            </div>
            <!-- end tp_main_warp -->

			<div class="tp_comment_warp c" id="replyList">
				<div class="tp_comment_title"><span><?php echo $countComment; ?></span>条回复</div>
			<?php 
			$page = intval(get('page'));
			if($page < 1){
				$page = 1;
			}
			$pageSize = 20;
			$floorStart = ($page - 1) * $pageSize;
			foreach($aArticleComment as $key => $aComment){ ?>
				<div class="tp_comment_list"><a name="notify<?php echo $aComment['id']; ?>"></a>
					<div class="tp_comment_avatar">
						<img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php echo SYSTEM_RESOURCE_URL . $aComment['user_info']['profile'] ?>" onload="h(this)" data-id="<?php echo $aComment['user_info']['id']; ?>" data-imgPop/>
					</div>
					<div class="tp_comment_content">
						<div class="tp_comment_pinfo c">
							<div class="fl vip0">
								<span class="tp_page_name">
									<a target="_blank" href="<?php echo url('m=Zone&a=showHome&userId=' . $aComment['user_info']['id'], '', APP_HOME); ?>"><?php echo getVipName($aComment['user_info']['name'], $aComment['user_info']['vip']); ?></a>
								</span>
								<span class="tp_page_vip"><i class="ico_v3 ico_v3_rank_<?php echo $aComment['user_info']['vip'] + 1 ; ?>" title="<?php echo $GLOBALS['VIP'][$aComment['user_info']['vip']]['name']; ?>"></i></span>
								<span class="tp_page_lv">LV(<?php echo $aComment['user_info']['level']; ?>)</span>
								<span class="tp_page_time" data-time="<?php echo $aComment['create_time']; ?>"><?php echo date('n月j号', $aComment['create_time']); ?></span>
							</div>
							<div class="fr opts">
								<span class="tp_btn_comment"><?php echo ++$floorStart; ?>楼</span>
							</div>
						</div>
						
						<?php if($aComment['parent_id'] && isset($aComment['parent_info']['user_info'])){ ?>
						<div class="tp_comment_quote">
							<div class="tp_quote_source"><?php echo $aComment['parent_info']['user_info']['name']; ?> 发表于 <?php echo date('Y-m-d H:i', $aComment['parent_info']['create_time']); ?></div>
							<div class="tp_comment_quote_content"><i class="tp_icon tp_icon_quoteL tp_icon_quoteL_pos"></i><?php echo $aComment['parent_info']['content']; ?><i class="tp_icon tp_icon_quoteR tp_icon_quoteR_pos"></i></div>
						</div>
						<?php } ?>
						
						<div class="tp_comment_p"><?php echo $aComment['content']; ?></div>
						<div class="tp_comment_opts">
							<a href="javascript:;" onclick="support(this)" data-typeid="2" data-comment_id="<?php echo $aComment['id']; ?>" class="tp_comment_support">
								<i class="tp_icon tp_icon_good_normal"></i>
								(<span class="count"><?php echo $aComment['support_times']; ?></span>)
							</a>
							<a href="javascript:;" onclick="showReply(this)" data-comment_id="<?php echo $aComment['id']; ?>" data-typeid="2" class="tp_comment_reply">
								<i class="tp_icon tp_icon_reply"></i>回复
							</a>
						</div>
					</div>
				</div>
			   <?php } ?>
			</div>

			<div class="tp_pagination c"><?php echo $pageHtml; ?></div>


			<div class="tp_editor_warp c" id="tpEditorWarp">
				<div id="tagsReply"></div>
				<script id="umContainer" name="umContent" type="text/plain"></script>
				<!-- 配置文件 -->
				<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
				<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
				<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
				<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>
				 <br/>
				 <a href="javascript:;" id="editorSubmit" class="tp_btn tp_btn_blue fr ">回复</a>
				<!--  <a href="javascript:;" id="editorDraft" class="tp_btn tp_btn_grey fr mr">保存草稿</a>-->            </div>
        </div>


        <!-- side -->
        <div class="tp_side c">
            <a href="<?php echo url('m=Thread&a=showAdd&categoryId=' . $aCategory['id']);?>" class="tp_btn tp_btn_release"><i class="tp_icon tp_icon_release"></i>发布新话题</a>
            <div class="tp_side_warp">
                <div class="tp_side_list">
                    <div class="tp_side_head"><span class="sidevip"><?php echo getVipName($aUserInfo['name'], $aUserInfo['vip']) ?></span>的最新主题</div>
                    <div class="tp_side_content">
                        <div class="tp_side_common_list">
                            <ul>
                                <?php
                                    if($aMyNewArticle){
                                        foreach($aMyNewArticle as $key => $category){
                                            echo '<li><a href="' . url('m=Thread&a=article&id=' .  $category['id']) . '" target="_blank">' . $category['title'] . '</a></li>';
                                        }
                                    }else{
                                        echo ' <li>暂无新话题</li>';
                                    }  
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>                <!-- end tp_side_list -->
                <div class="tp_side_list">
                    <div class="tp_side_head">推荐阅读</div>
                    <div class="tp_side_content">
                        <div class="tp_side_common_list">
                            <div class="tp_side_common_list_img">
                            </div>
                            <ul>
                            <?php if($aRecommend){
                                foreach($aRecommend as $aRecommendVal){
                                    echo ' <li>
										<a href="' . url('m=Thread&a=article&id=' . $aRecommendVal['id']) . '" target="_blank">
											' . $aRecommendVal['title'] . '
										</a>
									</li>';
                                }
                            }else{
                                echo ' <li>暂无推荐阅读</li>';
                            } ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- end tp_side_list --> 
            </div>
            <!-- end tp_side_warp -->
        </div>
    </div>
</div>

<script>
	//点赞核心
	function supportFun(obj, typeId, id){
		var supportIco = $(obj).find('.tp_icon'); 
		if(supportIco.hasClass('tp_icon_good_active')){
			UBox.show('亲，你已经点过赞了哦！', -1);
			return false;
		}else{
			supportIco.removeClass("tp_icon_good_normal").addClass("tp_icon_good_active");
			var txt = $(obj).find('.count').text();  
			//后端执行点赞
			ajax({
				url : '<?php echo url('m=Thread&a=support'); ?>',
				data : {type : typeId, id : id},
				success : function(aResult){
					if(aResult.status == 1){  
						//创建cookie
						$.cookie('bbs_support_' + typeId + '_' + id,'true',{expires : 7, path:'/'}); 
						var dtxt = parseInt(txt) + 1;
						$(obj).find('.count').html(dtxt);
					}else{
						//删除cookie
						$.cookie('bbs_support_' + typeId + '_' + id,{expires : null}); 
						supportIco.removeClass("tp_icon_good_active").addClass("tp_icon_good_normal");
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		}
	}

	//点赞入口
	function support(obj){
		obj.typeId = null;
		if($(obj).hasClass('tp_article_support')){
			obj.typeId = 1;
			var aID = $(obj).attr('data-articleid');
			supportFun(obj,obj.typeId,aID); 
		}
		if($(obj).hasClass('tp_comment_support')){
			obj.typeId = 2;
			var cID = $(obj).attr('data-comment_id');
			supportFun(obj,obj.typeId,cID);
		}
	}

	//show回复
	function showReply(obj){
		if($(obj).data('typeid') == 1){
			parentId = 0;

			// 回复标签操作
			var tpPageName = $(obj).parent().parent().find('.tp_page_name a').text();
			var tagsReplyItem = $('<span class="tags-reply">回复&nbsp;楼主<a href="javascript:;" class="tabs-close">&times;</a> </span>')
			$('#tagsReply').empty();
			$('#tagsReply').append(tagsReplyItem);
			$('.tabs-close').click(function(){
				$('.tags-reply').slideUp('fast');
			});
		}else{
			parentId = $(obj).data('comment_id');
			replyCreateTime = $(obj).parent().parent().find('.tp_create_time').text();

			// 回复标签操作
			var tpPageName = $(obj).parent().parent().find('.tp_page_name a').text();
			var tagsReplyItem = $('<span class="tags-reply">回复&nbsp;'+ tpPageName +'<a href="javascript:;" class="tabs-close">&times;</a> </span>')
			var tagsReplyHtml = $('#tagsReply').html();
			$('#tagsReply').empty();
			$('#tagsReply').hide().append(tagsReplyItem).slideDown('fast');;
			$('.tabs-close').click(function(){
				$('.tags-reply').slideUp('fast');
				parentId = 0;
			});
		}

		setFocus('#umContainer');
	}

	//使编辑器获得焦点
	function setFocus(){
		$('body,html').animate({
			scrollTop : $('#umContainer').offset().top
		}, 300);
		oEditor.focus();
	}
	
	function reply(){
		var content = oEditor.getContent();
		if(isReply){
			return;
		}
		
		if(oEditor.getContentLength() < 5){
			UBox.show('回复内容最少5个字以上哦！');
			return;
		}

		ajax({
			url : '<?php echo url('m=Thread&a=addComment'); ?>'
			,data : {
				threadId : <?php echo $aArticle['id']; ?>
				,parentId : parentId
				,content : oEditor.getContent()
				,files : []
			},
			beforeSend : function(){
				$('#editorSubmit').text("提交中...");
				isReply = true;
			},
			success : function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status == 1){
					var parentContent = (function(){
						var aArticleComment = <?php echo json_encode($aArticleComment); ?>;
						for(var key in aArticleComment){
							if(aArticleComment[key].id == parentId){
								return {
									content : aArticleComment[key].content,
									name : aArticleComment[key]['user_info'].name,
									time : aArticleComment[key].create_time,
									vip : aArticleComment[key]['user_info'].vip
								};
							}
						}
					})();

					//动态增加DOM
					<?php if($aCurrentUser){ ?>
					var commentHTML = '<div class="tp_comment_list">\
						<div class="tp_comment_avatar">\
							<img src="<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>" real="<?php $aCurrentUser && print(SYSTEM_RESOURCE_URL . $aCurrentUser['profile']); ?>" onload="h(this)" />\
						</div>\
						<div class="tp_comment_content">\
							<div class="tp_comment_pinfo c">\
								<div class="fl vip0">\
									<span class="tp_page_name"><a href="">' + getVipName(<?php echo "'" . $aCurrentUser['name'] . '\',' . $aCurrentUser['vip']; ?>) + '</a></span>\
									<span class="tp_page_vip"><i class="ico_v3 ico_v3_rank_<?php echo $aCurrentUser['vip'] + 1; ?>"></i></span>\
									<span class="tp_page_lv">LV(' + <?php echo $aCurrentUser['level']; ?> + ')</span>\
									<span class="tp_page_time">' + date('n月j号') + '</span>\
								</div>\
								<div class="fr opts">\
									<span class="tp_btn_comment">' + (++replyfloor) + '楼</span>\
								</div>\
							</div>\
							<div id="tp_comment_quote_warp' + (++replyQuoteId) + '"></div>\
							<div class="tp_comment_p">' + content + '</div>\
						</div>\
					</div>';
					<?php }else{
						echo 'var commentHTML = "";';
					}
					?>

					$(commentHTML).appendTo('#replyList');
					$('#tagsReply').empty();

					if(parentId > 0){
						var quoteHTML = '<div class="tp_comment_quote">\
							<div class="tp_quote_source">' + parentContent.name + ' 发表于 ' + date('Y-m-d H:i', parentContent.time) + '</div>\
							<div class="tp_comment_quote_content">\
								<i class="tp_icon tp_icon_quoteL tp_icon_quoteL_pos"></i>' + parentContent.content + '<i class="tp_icon tp_icon_quoteR tp_icon_quoteR_pos"></i>\
								</div>\
						</div>';

						$(quoteHTML).appendTo('#tp_comment_quote_warp' + replyQuoteId);
					};
					oEditor.execCommand('cleardoc');

					var tempTxt = $('.tp_comment_title').find('span').text();
					var addTempTxt = parseInt(tempTxt) + 1;
					$('.tp_comment_title').find('span').text(addTempTxt);

					parentId = 0;
				}
				$('#editorSubmit').text("回复");
				isReply = false;
			}
		});

	}

	var oEditor = UM.getEditor('umContainer', {
		toolbar:[
			'source | emotion image insertvideo | bold italic underline strikethrough | forecolor backcolor | removeformat |',
			'link unlink'
		],
		minFrameWidth : 500,
		minFrameHeight : 100,
		initialFrameWidth : 665,
		initialFrameHeight : 150,

		imageUrl : '<?php echo url('m=Thread&a=uploadFile'); ?>',
		imagePath : '<?php echo SYSTEM_RESOURCE_URL . USER_TMP_PATH; ?>'
	 });

	var parentId = 0
	,replyQuoteId = 0
	,replyfloor = <?php echo $countComment; ?>
	,isReply = false;
	
	$(function(){
		//点赞功能初始化
		(function(){
			var aCookie = document.cookie.split(';');
			for(var i = 0; i < aCookie.length; i++){
				var aCookieKeyVal = aCookie[i].split('=');
				var aCookieKeyValL = aCookieKeyVal[0].split('_');
				var keyId = aCookieKeyValL[2];
				var valId = aCookieKeyValL[3];
				if(keyId == 1){
					$('[data-articleId=' + valId + ']').find('.tp_icon').removeClass('tp_icon_good_normal').addClass('tp_icon_good_active');
				}
				if(keyId == 2){
					$('[data-comment_id=' + valId + ']').find('.tp_icon').removeClass('tp_icon_good_normal').addClass('tp_icon_good_active');
				}
			}
		})();
		setTimeout(function(){
			$.get('<?php echo url('m=Thread&a=upArticleCount&id=' . $aArticle['id']); ?>');
		}, 3500);
		//监听回复按钮
		$('#editorSubmit').click(reply);
	});
</script>