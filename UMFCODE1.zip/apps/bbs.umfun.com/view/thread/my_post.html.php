 <div class="tp_table_title c">
	<ul>
		<li class="big">
			<div class="group_sort">状态<a href="javascript:void(0);" id="status">全部</a>
				<div class="sub_group_sort">
					<a href="javascript:void(0);" onclick="location.href='<?php echo url('m=Thread&a=myArticle', '&statu=0');?>'">全部</a>
					<a href="javascript:void(0);" onclick="location.href='<?php echo url('m=Thread&a=myArticle&categoryId=' . $aCategory['id'], '&statu=2');?>'">已发表</a>
					<a href="javascript:void(0);" onclick="location.href='<?php echo url('m=Thread&a=myArticle&categoryId=' . $aCategory['id'], '&statu=1');?>'">草稿</a>
				</div>
			</div>
			<div class="group_sort">选择板块<a href="javascript:void(0);" id="category">选择</a>
				<div class="sub_group_sort">
					<?php 
						foreach($aCategoryList as $key => $aCategory){
							echo '<a href="javascript:void(0);" onclick="location.href=\'' . url('m=Thread&a=myArticle&categoryId=' . $aCategory['id']) . '\'">' . $aCategory['name'] . '</a>';
						}
					?>
				</div>
			</div>
		</li>
		<li>板块</li>
		<li>作者</li>
		<li>回复/查看</li>
		<li>发表时间</li>
	</ul>
</div>

<!-- end tp_table_title -->

<div class="tp_table_list c">
	<ul>
	<?php
	if(empty($aMyThreadList)){
		echo '<li class="c">很抱歉，您目前还没数据</li>';
	}else{
		foreach($aMyThreadList as $key => $aThreadValue){
			echo '<li class="c">
			<ul>
				<li class="big">
					<a href="' . url('m=Thread&a=article&id=' . $aThreadValue['id']) . '">
					' . $aThreadValue['title']. '
					</a></li>
				<li>
					<a href="' . url('m=Thread&a=index&categoryId=' . $aThreadValue['category_id']) . '">
						' . $aThreadValue['category_name'] . '
					</a>
				</li>
				<li>
					<a href="' . url('m=Zone&a=showHome&userId=' . $aThreadValue['user_info']['id'], '' , APP_HOME) . '">
						' . $aThreadValue['user_info']['name']. '
					</a>
				</li>
				<li><span>' . $aThreadValue['count_comment'] . '</span>/' . $aThreadValue['read_times'] . '</li>
				<li><script>document.write(transTime(' . $aThreadValue['create_time'] . '));</script></li>
				
			</ul>
		</li>';
		}
	}
	?>
	</ul>
</div>
<!-- end tp_table_list -->

<div class="tp_pagination center">
	<ul>
		<?php echo $pageHtml; ?>
	</ul>
</div>
<script type="text/javascript">
	var aStatusText = {0 : '全部', 1 : '草稿', 2 : '已发'},
		aCategoryText = {<?php 
							foreach($aCategoryList as $key => $aCategory){
								echo $aCategory['id'] . ' : \'' . $aCategory['name'] .'\', ';
							}
						?>};
	$('#status').text(aStatusText[<?php echo get('statu', 0); ?>]);
	$('#category').text(aCategoryText[<?php echo get('categoryId', 1); ?>]);
</script>