<div class="tp_table_list c">
	<style type="text/css" media="screen" id="test">
		.read{color:#999 !important;}
		.no-read{color:#06F !important;}
	</style>
	<ul>
		<?php 
			if(!empty($aNoReadNotificationList)){
				foreach($aNoReadNotificationList as $key => $aInfo){
					$readCss = $aInfo['is_read'] > 0 ? ' read' : '';
					if($aInfo['parent_id'] > 0){
						if(!isset($aInfo['comment_content'])){
							$aInfo['comment_content'] = '';
						}
						$contentHtml = '回复了你的评论<a href="' . url('m=Thread&a=article&id=' . $aInfo['thread_id'] . '&notify=' . $aInfo['id'] . '&page=' . $aInfo['in_page']) . '#notify' . $aInfo['comment_id'] . '" class="topic' . $readCss . '">' . mb_substr(strip_tags($aInfo['comment_content']), 0, 25) . '</a>';
					}else{
						$contentHtml = '评论了你的话题<a href="' . url('m=Thread&a=article&id=' . $aInfo['thread_id'] . '&notify=' . $aInfo['id'] . '&page=' . $aInfo['in_page'] ) . '#notify' . $aInfo['comment_id'] . '" class="topic' . $readCss . '">' . $aInfo['title'] . '</a>';
					}
					echo '<li class="c" id="notify_' . $aInfo['id'] . '">
							<a name="notify' . $aInfo['id'] . '"></a>
							<ul class="tp_news_list c" >
								<li class="big">
									<div class="tp_news_avatar">
									   <img data-imgPop  src="'  . $GLOBALS['RESOURCE']['profile_error'] . '" real="' . SYSTEM_RESOURCE_URL . $aInfo['comment_user_info']['profile'] . '" onload="h(this)"  data-id="' . $aInfo['comment_user_info']['id'] . '" data-imgPop/>
									</div>
									
									<a href="' . url('m=Zone&a=showHome&userId=' . $aInfo['comment_user_info']['id'], '' , APP_HOME) . '" class="name">' . $aInfo['comment_user_info']['name'] . '</a>
									' . $contentHtml . '
								</li>
								
								<li><script>document.write(transTime(' . $aInfo['create_time'] . '));</script></li>
								<li>
									<a href="javascript:void(0);" onclick="deleteNotification(' . $aInfo['id'] . ');">删除</a>
								</li>
							</ul> 
						</li>';
				}
			}else{
				
				echo '<li>很抱歉,目前暂时没有数据</li>';
			}
		?>

	</ul>
</div>
<!-- end tp_table_list -->

<div class="tp_pagination center">
	<ul>
		<?php echo $pageHtml; ?>
	</ul>
</div>
<script>
// 全局
function newsIsRead(){
	$('.msg-center-content .post,.tp_news_list .topic').click(function(){
		$(this).css('color','#666');
	});
}


function deleteNotification(id){
	ajax({
		url : '/?m=Thread&a=delNotification',
		data : {id : id},
		success : function(aResult){
			if(aResult.status == 1){
				$('#notify_' + id).hide('fast', function(){
					$(this).remove();
				});
			}
		}
	});
}

$(function(){
	newsIsRead(); //全局
});
</script>