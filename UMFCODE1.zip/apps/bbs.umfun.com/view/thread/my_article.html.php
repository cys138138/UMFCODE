<!-- 头部 -->
<div class="tp_header" id="tpHeader">
	<div class="column">
		<a href="http://<?php echo APP_BBS; ?>">
			<div class="tp_logo"><i class="tp_icon tp_icon_logo"></i><span class="hidetxt_2">UMFun话题专区</span></div>
		</a>
	</div>
</div>

<!-- 主体 -->
<div class="tp_container" id="tpContainer">
	<div class="column">
		<!-- nav -->
		<div class="tp_nav">
			<?php 
				foreach($aCategoryList as $key => $category){
					$changeClass = $category['id'] == $aCategory['id'] ? ' class="current"' : '';
					echo '<a href="' . url('m=Thread&a=index&categoryId=' . $category['id']) . '" ' . $changeClass . '>' . $category['name'] . '</a> |';
				}
			?>
			<div class="tp_search">　
				<!--<input type="text" id="tp_search" class="tp_search_bar" placeholder="请输入搜索内容">
				<button class="tp_search_btn"><i class="tp_icon tp_icon_search"></i></button>-->
			</div>
		</div>

		
		<!-- main -->
		<div class="tp_main c"> 
			<div class="tp_main_warp">
				<div class="tp_group_tabs c">
					<ul>
						<li><a href="<?php echo url('m=Thread&a=myArticle'); ?>" <?php if(get('a') == 'myArticle'){ echo 'class="active"'; }?>>主题</a></li>
						<li><a href="<?php echo url('m=Thread&a=myComment'); ?>" <?php if(get('a') == 'myComment'){ echo 'class="active"'; }?>>回复</a></li>
						<li><a href="<?php echo url('m=Thread&a=myNotification'); ?>" <?php if(get('a') == 'myNotification'){ echo 'class="active"'; }?>>消息</a></li>
					</ul>
				</div>
				<!-- end tp_group_tabs -->

			   <?php
					if($typeContent == 1){
						display('thread/my_post.html.php');
					}else if($typeContent == 2){
						display('thread/my_comment.html.php');
					}else if($typeContent == 3){
						display('thread/my_notification.html.php');
					}
			   ?>

			</div>
			<!-- end tp_main_warp -->
		</div>
		<!-- side -->
		<div class="tp_side c">
			<a href="<?php echo url('m=Thread&a=showAdd');?>" class="tp_btn tp_btn_release"><i class="tp_icon tp_icon_release"></i>发布新话题</a>
			<div class="tp_side_warp">
				<div class="tp_side_list">
					<div class="tp_side_head">推荐话题</div>
					<div class="tp_side_content">
						<div class="tp_side_common_list">
						   <ul>
							<?php 
							if($aRecommend){
								foreach($aRecommend as $k => $aRecommendVal){
									echo ' <li>
											<a href="' . url('m=Thread&a=article&id=' . $aRecommendVal['id']) . '">
												' . $aRecommendVal['title'] . '
											</a>
										</li>';
								}
							}else{
								echo ' <li>暂无精彩话题</li>';
							}
							?>
							</ul>
						</div>
					</div>
				</div>
				<!-- end tp_side_list -->


				<div class="tp_side_list">
					<div class="tp_side_head">最新比赛</div>
					<div class="tp_side_content">
						<div class="tp_side_thumb_list">
							<ul>
							<?php
							if($aNewMatch){
								foreach($aNewMatch as $kMatch => $aNewMatchVal){
									echo '<li>
											<a class="tp_side_thumb_img" href="' . url('m=Match&a=showDetail&match_id=' . $aNewMatchVal['id'], '', APP_HOME) . '">
											   <img src="' . $GLOBALS['RESOURCE']['image_error'] . '" onload="h(this)" real="' . SYSTEM_RESOURCE_URL . $aNewMatchVal['profile'] . '" alt="">
											</a>
											<div class="tp_side_thumb_info">
												<div class="tp_side_thumb_info_title">
													<a href="' . url('m=Match&a=showDetail&match_id=' . $aNewMatchVal['id'], '', APP_HOME) . '">
												   	 ' . $aNewMatchVal['name'] . '
													</a>
												</div>
												<div class="tp_side_thumb_info_txt">
													' . $aNewMatchVal['description'] . '
												</div>
											</div>
										</li>';
								}
							}else{
								echo ' <li>暂无比赛信息</li>';
							}
							?>
							</ul>
						</div>
						<!-- end tp_side_thumb_list -->
					</div>
					<!-- end tp_side_content -->
				</div>
				<!-- end tp_side_list -->
			</div>
			<!-- end tp_side_warp -->
		</div>
	</div>
</div>
