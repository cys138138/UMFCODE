
<!-- 头部 -->
<div class="tp_header" id="tpHeader">
	<div class="column">
		<a href="http://<?php echo APP_BBS; ?>">
			<div class="tp_logo"><i class="tp_icon tp_icon_logo"></i><span class="hidetxt_2">UMFun话题专区</span></div>
		</a>
	</div>
</div>

<!-- 主体 -->
<div class="tp_container" id="tpContainer">
	<div class="column">
		<!-- nav -->
		<div class="tp_nav">
			<?php 
				foreach($aCategoryList as $key => $category){
					$changeClass = $category['id'] == $aCategory['id'] ? ' class="current"' : '';
					echo '<a href="' . url('m=Thread&a=index&categoryId=' . $category['id']) . '" ' . $changeClass . '>' . $category['name'] . '</a>';
				}
			?>
			<div class="tp_search">　
				<!--<input type="text" id="tp_search" class="tp_search_bar" placeholder="请输入搜索内容">
				<button class="tp_search_btn"><i class="tp_icon tp_icon_search"></i></button>-->
			</div>
		</div>

		
		<!-- main -->
		<div class="tp_main c"> 
			<div class="tp_main_warp">
				<div class="tp_group_list">
					<?php
						$recommend = intval(get('recommend', 0));
						$top = intval(get('top', 0));
						$order = intval(get('order', 0));
						$aFormatTypeClass = array(
							'all' => !$recommend && !$top ? 'tp_active' : '',
							'recommend' => $recommend ? 'tp_active' : '',
							'top' => $top ? 'tp_active' : ''
						);
						$urlOption = '';
						if($recommend && $recommend == 1){
							$urlOption .= '&recommend=1';
						}
						if($top && $top == 1){
							$urlOption .= '&top=1';
						}
						$url = url('m=Thread&a=index&categoryId=' . $aCategory['id'], $urlOption);
					?>
					<ul>
						<li>
							<a href="<?php echo  url('m=Thread&a=index&categoryId=' . $aCategory['id']);?>" class="<?php echo $aFormatTypeClass['all']; ?>">全部</a>|
						</li>
						<li><a href="<?php echo url('m=Thread&a=index&categoryId=' . $aCategory['id'], '&recommend=1');?>" class="<?php echo $aFormatTypeClass['recommend']; ?>">推荐</a>|</li>
						<li><a href="<?php echo url('m=Thread&a=index&categoryId=' . $aCategory['id'], '&top=1');?>" class="<?php echo $aFormatTypeClass['top']; ?>">热门</a>|</li>
						<li class="group_sort">
							<a href="javascript:void(0);" id="status">排序方式</a>
							<div class="sub_group_sort">
								<!-- 在A标签里添加class="tp_active" 就是选中状态 -->
								<?php
									$orderClass = 'class="tp_active"';
								?>
								<a href="javascript:void(0);" onclick="location.href='<?php echo $url . '&order=0'; ?>'" >默认排序</a>
								<a href="javascript:void(0);" onclick="location.href='<?php echo $url . '&order=1'; ?>'" <?php echo $order == 1 ? $orderClass : ''; ?>>发帖时间</a>
								<a href="javascript:void(0);" onclick="location.href='<?php echo $url . '&order=2'; ?>'" <?php echo $order == 2 || $order == 0 ? $orderClass : ''; ?>>最新回复</a>
								<a href="javascript:void(0);" onclick="location.href='<?php echo $url . '&order=3'; ?>'" <?php echo $order == 3 ? $orderClass : ''; ?>>阅读数</a>
							</div>
						</li>
					</ul>
				</div>

					<?php
					if($aThreadIsTop && $page == 1){
						echo '<div class="tp_main_list">
								<ul>';
						foreach($aThreadIsTop as $kTop => $aIsTopVal){
							echo '<li> 
									<div class="tp_main_list_left">
										<a href="' . url('m=Zone&a=showHome&userId=' . $aIsTopVal['user_info']['id'], '' , APP_HOME) . '">
										  <img src="' . $GLOBALS['RESOURCE']['profile_error'] . '" onload="h(this)" real="' . SYSTEM_RESOURCE_URL . $aIsTopVal['user_info']['profile'] . '" data-id="' . $aIsTopVal['user_info']['id'] . '" data-imgPop>
										</a>
										<div class="tp_main_list_title">
												<a href="' . url('m=Thread&a=article&id=' . $aIsTopVal['id']) . '" class="tp_top_blue" target="_blank">
												 ' . mb_substr($aIsTopVal['title'], 0, 30) . '
												</a>
											 ' . _formatIcon($aIsTopVal['is_top'], $aIsTopVal['is_recommend'], $aIsTopVal['support_times'], $aIsTopVal['read_times']) . '
											<div class="tp_inset_pagination">
											</div>
										</div>
									</div>
									<div class="tp_main_list_info">
										<div class="tp_main_list_info_name">' . $aIsTopVal['user_info']['name']. '</div>
										<div class="tp_main_list_info_time">
											<script>document.write(transTime(' . $aIsTopVal['last_reply_time'] . '));</script>
										</div>
									</div>
								</li>';
						}
						echo '</ul>
							</div>
						 <div class="tp_main_title">板块话题</div>';
					}
					?>
						
					
				<!-- end tp_main_list -->
				
					<?php
					if(isset($aThreadIsTop)){
						echo '<div class="tp_main_list">
								<ul>';
						foreach($aThread as $key => &$aThreadValue){
							echo '<li>
									<div class="tp_main_list_left">
										<a href="' . url('m=Zone&a=showHome&userId=' . $aThreadValue['user_info']['id'], '' , APP_HOME) . '">
											<img src="' . $GLOBALS['RESOURCE']['profile_error'] . '" onload="h(this)" real="' . SYSTEM_RESOURCE_URL . $aThreadValue['user_info']['profile'] . '"  data-id="' . $aThreadValue['user_info']['id'] . '" data-imgPop>
										</a>';
							
										echo '<div class="tp_main_list_title">
											<a href="' . url('m=Thread&a=article&id=' . $aThreadValue['id']) . '" target="_blank">
											' . mb_substr($aThreadValue['title'], 0, 30) . '
											</a>
											' . _formatIcon(0, $aThreadValue['is_recommend'], $aThreadValue['support_times'], $aThreadValue['read_times']) . '
											<div class="tp_inset_pagination"></div>
										</div>
									</div>
									<div class="tp_main_list_info">
										<div class="tp_main_list_info_name">' . $aThreadValue['user_info']['name']. '</div>
										<div class="tp_main_list_info_time">
											<script>document.write(transTime(' . $aThreadValue['last_reply_time']. '));</script>
										</div>
									</div>
								</li>';
						}
						echo '</ul>
						</div>';
					}
					?>
					
				<!-- end tp_main_list -->

				<div class="index_tp_pagination c">
					<ul>
						<?php echo $pageHtml; ?>
					</ul>
					<a href="<?php echo url('m=Thread&a=showAdd&categoryId=' . $aCategory['id']);?>" class="tp_btn tp_btn_blue fr">发布话题</a>

				</div>

			</div>
			<!-- end tp_main_warp -->
		</div>
		<!-- side -->
		<div class="tp_side c">
			<a href="<?php echo url('m=Thread&a=showAdd&categoryId=' . $aCategory['id']);?>" class="tp_btn tp_btn_release">
				<i class="tp_icon tp_icon_release"></i>发布新话题</a>
			<div class="tp_side_warp">
				<div class="tp_side_list">
					<div class="tp_side_head">板块信息<span class="head_r">今日发帖: <?php echo $todayPost; ?></span></div>
					<div class="tp_side_content">
						<div class="tp_side_common_list">
							<?php echo $aCategory['description']; ?>
						</div>
					</div>
				</div>
				<!-- end tp_side_list -->

				<div class="tp_side_list">
					<div class="tp_side_head">精彩话题</div>
					<div class="tp_side_content">
						<div class="tp_side_common_list">
							<ul>
							<?php 
							if($aRecommend){
								foreach($aRecommend as $k => $aRecommendVal){
									echo ' <li>
											<a href="' . url('m=Thread&a=article&id=' . $aRecommendVal['id']) . '" target="_blank">
												' . $aRecommendVal['title'] . '
											</a>
										</li>';
								}
							}else{
								echo ' <li>暂无精彩话题</li>';
							}
							?>
							</ul>
						</div>
					</div>
				</div>
				<!-- end tp_side_list -->

				<div class="tp_side_list">
					<div class="tp_side_head">最新比赛</div>
					<div class="tp_side_content">
						<div class="tp_side_thumb_list">
							<ul>
							<?php
							if($aNewMatch){
								foreach($aNewMatch as $kMatch => $aNewMatchVal){
									echo '<li>
											<a class="tp_side_thumb_img" href="' . url('m=Match&a=showDetail&match_id=' . $aNewMatchVal['id'], '', APP_HOME) . '">
											   <img src="' . $GLOBALS['RESOURCE']['image_error'] . '" onload="h(this)" real="' . SYSTEM_RESOURCE_URL . $aNewMatchVal['profile'] . '" alt="">
											</a>
											<div class="tp_side_thumb_info">
												<div class="tp_side_thumb_info_title">
													<a href="' . url('m=Match&a=showDetail&match_id=' . $aNewMatchVal['id'], '', APP_HOME) . '" target="_blank">
												   	 ' . $aNewMatchVal['name'] . '
													</a>
												</div>
												<div class="tp_side_thumb_info_txt">
													' . $aNewMatchVal['description'] . '
												</div>
											</div>
										</li>';
								}
							}else{
								echo ' <li>暂无比赛信息</li>';
							}
							?>
							</ul>
						</div>
						<!-- end tp_side_thumb_list -->
					</div>
					<!-- end tp_side_content -->
				</div>
				<!-- end tp_side_list -->
			</div>
			<!-- end tp_side_warp -->
		</div>
	</div>
</div>
<script type="text/javascript">
	
	var aStatusText = {0 : '默认', 1 : '发帖时间', 2 : '最新回复', 3 : '阅读量'};
	$('#status').text(aStatusText[<?php echo intval(get('order', 2)); ?>]);

</script>
<?php
function _formatIcon($top = 0, $recommend = 0, $good = 0,$hot = 0){
	$returnHtml = '';
	if($top){
		$returnHtml .= '<i class="tp_icon tp_icon_top"></i>';
	}
	if($recommend){
		$returnHtml .= '<i class="tp_icon tp_icon_star"></i>';
	}
	if($good > 20){
		$returnHtml .= '<i class="tp_icon tp_icon_good_active"></i>';
	}
	if($hot > $GLOBALS['BBS']['hot']){
		$returnHtml .= '<i class="tp_icon tp_icon_hot"></i>';
	}
	return $returnHtml;
}
?>