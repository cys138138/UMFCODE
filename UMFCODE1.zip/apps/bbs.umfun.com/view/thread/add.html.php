<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>

<!-- 头部 -->
<div class="tp_header" id="tpHeader">
	<div class="column">
		<a href="http://<?php echo APP_BBS; ?>">
			<div class="tp_logo"><i class="tp_icon tp_icon_logo"></i><span class="hidetxt_2">UMFun话题专区</span></div>
		</a>
	</div>
</div>

<!-- 主体 -->
<div class="tp_container" id="tpContainer">
	<div class="column">
		<!-- nav -->
		<div class="tp_nav c">
			<div class="tp_search" style="visibility:hidden;">
				<input type="text" id="tp_search" class="tp_search_bar" placeholder="请输入搜索内容" />
				<button class="tp_search_btn"><i class="tp_icon tp_icon_search"></i></button>
			</div>
			<?php foreach($aCategoryList as $aCategory){
					$changeClass = $aCategory['id'] == $currentCategory ? ' class="current"' : '';
					echo '<a href="' . url('m=Thread&a=index&categoryId=' . $aCategory['id']) . '" ' . $changeClass . '>' . $aCategory['name'] . '</a>';
			} ?>
		</div>
		<!-- main -->
		<div class="tp_new c">
			<div class="tp_new_warp">
				<div class="tp_editor_btn">

					<!-- 模拟select下拉 -->
					<div class="select_box" id="selectBox">
					   <a class="selet_open"><span class="select_txt" id="selectText">请选择板块</span><i class="triangle_down"></i></a>
					   <div class="option">
							<?php foreach($aCategoryList as $aCategory){
								echo '<a href="javascript:;" data-select="' . ($aCategory['id'] == $currentCategory ? '1' : '0') . '" data-id="' . $aCategory['id'] . '">' . $aCategory['name'] . '</a>';
							} ?>
							<input type="hidden" value="0" id="categoryId"/>
					   </div>
				   </div>

					<a href="javascript:;" onclick="publish(1);" class="tp_btn tp_btn_blue">发布话题</a>
				</div>

				<div class="tp_editor_title">
					<input type="text" class="tp_editor_title_input" id="title" />
				</div>

				<div class="tp_editor_warp_new c">
					<script id="umContainer" name="umContent" type="text/plain"></script>
				</div>

				<a href="javascript:;" onclick="publish(2);" class="tp_btn tp_btn_blue fr ml10">发布话题</a>
				<a href="javascript:;" id="saveDraft" onclick="saveDraft(1);" class="tp_btn tp_btn_grey fr ml10">保存草稿</a>


			</div>
			<!-- end tp_new_warp -->
		</div>
	</div>
</div>

<script type="text/javascript">
	function publish(publishType){
		var $oTitle = $('#title')
		,title = $.trim($oTitle.val());

		if(title.length < 5 || title.length > 30){
			UBox.show('标题长度必须在5到30字之间', -1);
			$oTitle.focus();
			return;
		}

		var contentLength = oEditor.getContentLength();
		if(contentLength < 5 || contentLength > 18000){
			UBox.show('内容长度必须在5到18000字之间', -1);
			oEditor.focus();
			return;
		}

		ajax({
			url : '<?php echo url('m=Thread&a=articleDo'); ?>'
			,data : {
				type : 1
				,title : title
				,content : oEditor.getContent()
				,categoryId : $('#categoryId').val()
				,status : publishType
			}
			,success : function(aResult){
				if(aResult.status == 1){
					UBox.show('发表成功！2秒后跳转到该文章预览', aResult.status, '<?php echo url('m=Thread&a=article&id=__ID__'); ?>'.replace('__ID__', aResult.data));
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			}
		});
	}

	function saveDraft(status){
		var $oTitle = $('#title'),
			title = $.trim($oTitle.val());

		if(title.length < 5 || title.length > 30){
			UBox.show('标题长度必须在5到30字之间', -1);
			$oTitle.focus();
			return;
		}

		var contentLength = oEditor.getContentLength();
		if(contentLength < 5 || contentLength > 18000){
			UBox.show('内容长度必须在5到18000字之间', -1);
			oEditor.focus();
			return;
		}

		ajax({
			url : '<?php echo url('m=Thread&a=articleDo'); ?>',
			data : {
				type : 1,
				title : title,
				content : oEditor.getContent(),
				categoryId : $('#categoryId').val(),
				status : status

			},
			beforeSend : function(){
				$('#saveDraft').html('正在保存草稿中...');
			},
			success : function(aResult){
				if(aResult.status == 1){
					$('#saveDraft').html('保存草稿');
					UBox.show('保存草稿成功,正在转跳链接', 1, '<?php echo url('m=Thread&a=article&id=__ID__'); ?>'.replace('__ID__', aResult.data));
				}else{
					UBox.show(aResult.msg, aResult.status);
				}

			}

		})

	}

	function addSelectDown(){
		var $oSelectCategory = $('#selectBox a[data-select="1"]'),
			categoryIsFalseText = '',
			isShow = false;
		if($oSelectCategory.data('select') == null){
			categoryIsFalseText = $('#selectBox a[data-id="<?php echo $GLOBALS['BBS']['defult_channel']; ?>"]').text();
		}else{
			categoryIsFalseText = $oSelectCategory.text();
		}
		$('#selectText').text(categoryIsFalseText);
		$('#categoryId').val($oSelectCategory.data('id'));
		$('.selet_open').click(function(){
			if(!isShow){
				$('.option').slideDown(100);
				isShow = true;
			}else{
				$('.option').slideUp(100);
				isShow = false;
			}

			return false;
		});
		$('.select_box').on('click', '.option a',  function(){
			var optxt = $(this).text();
			$('.select_txt').text(optxt);
			$('.option').slideUp(100);
			$('#title').focus();

			$('#categoryId').val($(this).attr('data-id'));
		})
		$(document).click(function(){
			$('.option').slideUp(100);
			isShow = false;
		})
	}

	var oEditor = null;
	$(function(){
		addSelectDown();
		oEditor = UM.getEditor('umContainer', {
			toolbar:[
				'source | emotion image insertvideo | bold italic underline strikethrough | forecolor backcolor |',
				'link unlink | insertorderedlist insertunorderedlist justifyleft justifycenter justifyright justifyjustify |',
				'removeformat | paragraph fontfamily fontsize'
			],
			minFrameWidth : 500,
			minFrameHeight : 100,
			initialFrameWidth : 880,
			initialFrameHeight : 200,
			imageUrl : '<?php echo url('m=Thread&a=uploadFile'); ?>',
			imagePath : '<?php echo SYSTEM_RESOURCE_URL . USER_TMP_PATH; ?>'
		});
	});
</script>