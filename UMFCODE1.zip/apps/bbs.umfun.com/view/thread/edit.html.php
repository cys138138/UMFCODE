<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['css']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['config']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['min']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['ueditor']['path'] . $GLOBALS['RESOURCE']['ueditor']['zh-cn']; ?>"></script>

<!-- 头部 -->
<div class="tp_header" id="tpHeader">
    <div class="column">
        <div class="tp_logo"><a href="http://<?php echo APP_BBS; ?>"><i class="tp_icon tp_icon_logo"></i></a><span class="hidetxt_2">UMFun话题专区</span></div>
    </div>
</div>

<script>
    // 全局变量

    var CategoryListArr = [];
    var oEditor = null;
    var id = <?php echo $aArticleInfo['id']; ?>; //帖子的数据ID
    var categoryId = <?php echo $aArticleInfo['category_id']; ?>; //帖子的分类
    var title = '<?php echo $aArticleInfo['title']; ?>';
    var content = '<?php echo $aArticleInfo['content']; ?>';
    var status = <?php echo $aArticleInfo['status']; ?>; //1=草稿状态,2=发布状态
    var articleListUrl = '<?php echo url('m=Thread&a=index&category=_category'); ?>';


    // End 全局变量
</script>
<!-- 主体 -->
<div class="tp_container" id="tpContainer">
    <div class="column">
        <!-- nav -->
        <div class="tp_nav">
	        <?php
	        	foreach($aCategoryList as $key => $category){
		        	$changeClass = $category['id'] == $aArticleInfo['category_id'] ? ' class="current"' : '';
	        		echo '<a href="' . url('m=Thread&a=index&categoryId=' . $category['id']) . '" ' . $changeClass . '>' . $category['name'] . '</a>';
	        	}
	        ?>
        </div>
        <!-- main -->
        <div class="tp_new c">
            <div class="tp_new_warp">
                <div class="tp_editor_title">
                    <input type="text" class="tp_editor_title_input" id="title" />
                </div>

                <div class="tp_editor_warp_new c">
                    <script id="umContainer" name="umContent" type="text/plain"></script>
                </div>

                <div id="btnOpts"></div>
                <script>

                    var btnEditor = '';
                    if(status == 2){
                        btnEditor = '<a href="javascript:publish(2);" class="tp_btn tp_btn_blue fr ml10" id="confirmFix">保存修改</a>'
                        $('#btnOpts').append(btnEditor);
                    }else if(status == 1){
                        btnEditor = '<a href="javascript:publish(2);" class="tp_btn tp_btn_blue fr ml10" id="confirmFix">正式发布</a>' + '<a href="javascript:saveDraft();" class="tp_btn tp_btn_grey fr ml10" id="saveDraft">保存草稿</a>'
                        $('#btnOpts').append(btnEditor);
                    }


                </script>
            </div>
            <!-- end tp_new_warp -->
        </div>
    </div>
</div>

<script type="text/javascript">
    function loadSourceData(){
    	$('#title').val(title);
    	$('#umContainer').html(content);
    }


    function saveDraft(){
        var $oTitle = $('#title'),
            title = $.trim($oTitle.val());

        ajax({
            url : '<?php echo url('m=Thread&a=articleDo'); ?>',
            data : {
                title : title,
                content : oEditor.getContent(),
                categoryId : categoryId,
                status : status,
                type : 2,
                id : id
            },
            beforeSend : function(){
                $('#saveDraft').html('正在保存草稿中...');
            },
            success : function(aResult){
                if(aResult.status == 1){
					$('#saveDraft').html('保存草稿');
					UBox.show('保存草稿成功,正在转跳链接', 1, '<?php echo url('m=Thread&a=article'); ?>' + '&id=' + id);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
            }

        })

    }

    function publish(publishType){
        var $oTitle = $('#title')
        ,title = $.trim($oTitle.val());

        if(title.length < 5 || title.length > 30){
			UBox.show('标题长度必须在5到30字之间', -1);
			$oTitle.focus();
			return;
		}

		var contentLength = oEditor.getContentLength();
		if(contentLength < 5 || contentLength > 18000){
			UBox.show('内容长度必须在5到18000字之间', -1);
			oEditor.focus();
			return;
		}

        ajax({
            url : '<?php echo url('m=Thread&a=articleDo'); ?>'
            ,data : {
                type : 2
                ,id : id
                ,title : title
                ,content : oEditor.getContent()
                ,categoryId : categoryId
                ,status : publishType
            }
            ,success : function(aResult){
	            if(aResult.status == 1){
					UBox.show('操作成功！2秒后跳转到该文章预览', aResult.status, '<?php echo url('m=Thread&a=article'); ?>' + '&id=' + id);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
            }
        });
    }



    $(function(){
        loadSourceData();
        oEditor = UM.getEditor('umContainer', {
            toolbar:[
                'source | emotion image insertvideo | bold italic underline strikethrough | forecolor backcolor |',
				'link unlink | insertorderedlist insertunorderedlist justifyleft justifycenter justifyright justifyjustify |',
				'removeformat | paragraph fontfamily fontsize'
            ],
            minFrameWidth : 500,
            minFrameHeight : 100,
            initialFrameWidth : 880,
            initialFrameHeight : 200,

			imageUrl : '?m=Thread&a=uploadFile',
			imagePath : '<?php echo SYSTEM_RESOURCE_URL . USER_TMP_PATH; ?>'
        });
    });
</script>