<div class="tp_table_title c">
	<ul>
		<li class="big"> 　</li>
		<li>板块</li>
		<li>作者</li>
		<li>回复/查看</li>
		<li>发表时间</li>
		
	</ul>
</div>
<!-- end tp_table_title -->

<div class="tp_table_list c">
	<ul>
	<?php
	if(empty($aMyCommentList)){
		echo '<li class="c">很抱歉，您目前还没数据</li>';
	}else{
		foreach($aMyCommentList as $key => $aMyComment){
			echo '<li class="c">
					<ul class="c">
						<li class="big">
							<a href="' . url('m=Thread&a=article&id=' . $aMyComment['thread_info']['id']) . '">
							' . $aMyComment['thread_info']['title']. '
							</a></li>
						<li>
							<a href="' . url('m=Thread&a=index&categoryId=' . $aMyComment['thread_info']['category_id']) . '">
								' . $aMyComment['thread_info']['category_name'] . '
							</a>
						</li>
						<li>
							<a href="' . url('m=Zone&a=showHome&userId=' . $aMyComment['thread_info']['user_info']['id'], '' , APP_HOME) . '">
								' . $aMyComment['thread_info']['user_info']['name']. '
							</a>
						</li>
						<li><span>' . $aMyComment['thread_info']['support_times'] . '</span>/' . $aMyComment['thread_info']['read_times'] . '</li>
						<li><script>document.write(transTime(' . $aMyComment['thread_info']['create_time'] . '));</script></li>
					</ul>
					<div class="tp_table_list_reply">
						<i class="trangle"></i>
						<span>回复主题：</span>
						' . strip_tags($aMyComment['content']). '
					</div>
				</li>';
		}
	}
	?>
	</ul>
</div>
<!-- end tp_table_list -->

<div class="tp_pagination center">
	<ul>
		<?php echo $pageHtml; ?>
	</ul>
</div>