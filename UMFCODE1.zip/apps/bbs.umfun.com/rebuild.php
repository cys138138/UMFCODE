<?php
require '../../rebuild/apps/bbs/web/index.php';