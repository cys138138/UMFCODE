<?php
class StatisticController{
	private $_userId = 0;
	private $_isAnalogAccount = 0;
	private $_parentId = 0;
	//96977300 93157395  15947559 测试ID
	public function __construct(){
		$aParentUserInfo = checkParentLogin();
		if(isset($aParentUserInfo['user_ids'][0])){
			$this->_userId = $aParentUserInfo['user_ids'][0];
		}
		//$this->_userId = 15947559;
		$this->_parentId = $aParentUserInfo['id'];
		$this->_isAnalogAccount = Cookie::isSetted('analogAccount');
		if($this->_parentId == 12 && !$this->_isAnalogAccount){
			Cookie::set('analogAccount', 1);
			$this->_isAnalogAccount = 1;
		}
	}

	public function enterAnalogAccount(){
		$type = intval(get('type', 0));
		if($type > 2){
			$type = 0;
		}
		Cookie::set('analogAccount', 1);
		if($type == 0){
			header('location:' . '?/m=Index&a=showNewIndex');
		}elseif($type == 1){
			header('location:' . '?/m=Index&a=showNewIndex#report');
		}elseif($type == 2){
			header('location:' . '?/m=Index&a=showNewIndex#tutorial');
		}
	}

	public function exitAnalogAccount(){
		Cookie::delete('analogAccount');
		header('location:' . url('m=Index&a=showNewIndex'));
	}

	public function userFeed(){
		display('parents/header.html.php');
		display('index/user_feed.html.php');
		display('parents/footer.html.php');
	}

	public function feedback(){
		$feedbackType = post('feedbackType');
		$content = post('description');
		$userName = post('userName');
		$phone = post('phone');
		$contact = post('contact',0);
		if($contact){
			$contactRex = preg_match("/(^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$)|(^1\d{10}$)|([1-9][0-9]{4,})/",$contact);
			if(!$contactRex){
				alert('请核对联系方式格式',0);
			}
		}else{
			$contact = 0;
		}
		if(strlen($phone) < 7 || strlen($content) < 5 || $feedbackType != '和教育家长'){
			alert('参数不合法', 0);
		}

		$aFeedBackTypeTextToInt = array('和教育家长' => 7);

		//底层传输数据
		$oCurl = curl_init();
		curl_setopt($oCurl, CURLOPT_URL, 'http://' . APP_HOME . '/?m=Account&a=feedback');
		curl_setopt($oCurl, CURLOPT_HEADER, 0);
		curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($oCurl, CURLOPT_POST, 1);
		curl_setopt($oCurl, CURLOPT_POSTFIELDS, array(
			'type' => $aFeedBackTypeTextToInt[$feedbackType],
			'user_type'	=>	3,
			'user_agent'	=>	$_SERVER['HTTP_USER_AGENT'],
			'userId' => isset($_COOKIE['id']) ? $_COOKIE['id'] : 0,
			'autoLogin' => isset($_COOKIE['parentAutoLogin']) ? $_COOKIE['parentAutoLogin'] : 0,
			'descript' => $content ,
			'name' => $userName,
			'contact' => $contact,
			'client_ip' => empty($_SERVER['HTTP_CLIENT_IP']) ? null : $_SERVER['HTTP_CLIENT_IP'],
			'remote_ip' => empty($_SERVER['REMOTE_ADDR']) ? null : $_SERVER['REMOTE_ADDR'],
			'for_ip' => empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? null : $_SERVER['HTTP_X_FORWARDED_FOR'],
			'ajax' => 1
		));

		$aResult = curl_exec($oCurl);
		curl_close($oCurl);
		header('Content-type: application/json');
		echo $aResult;

	}

	// ---------------------------福--------------------------------------------------------------------------------
	public function getTutorial(){
		$page = intval(post('page', 1));
		$subjectId = intval(post('subjectId', 1));
		if($page < 1 || ($subjectId < 0 || $subjectId > 4)){
			alert('数据错误', 0);
		}

		$pageSize = 10;
		$pageCount = 0;
		if($this->_isAnalogAccount){
			$aStatistics = ParentImitate::getUserEsWrongMissionStatistics($this->_parentId, $subjectId, $page, $pageSize);
			if($aStatistics === false){
				alert('系统错误', 0);
			}
			$aMissionList = $aStatistics['mission_list'];
			$pageCount = ceil($aStatistics['all_count'] / $pageSize);
			foreach($aMissionList as $key => $aMission){
				$aMissionList[$key]['id'] = $aMission['mission_id'];
				$aMissionList[$key]['name'] = $aMission['mission_name'];
			}
		}else{
			$aMissionList = $aIds = array();
			$aData = array(
				'pageCount' => 0,
				'aMissionList' => 0
			);
			$oEs = m('Es');
			$missionCount = $oEs->getEsWrongMissionCount($this->_userId, $subjectId);
			if($missionCount === false){
				alert('系统错误', 0);
			}
			if($missionCount > 0){
				$pageCount = ceil($missionCount / $pageSize);
				$aMissionList = $oEs->getEsWrongMissionList($this->_userId, $page, $pageSize, $subjectId);
			}
			if($aMissionList === false){
				alert('系统错误', 0);
			}else if(!$aMissionList){
				alert('您目前没有数据', 1, $aData);
			}

			//数组合并
			foreach($aMissionList as $aVal){
				$aIds[] = $aVal['id'];
			}

			$aWongFixend = m('Es')->getMissionWrongEsCountByMissionIds($this->_userId, join(',', $aIds));
			$aRelationIndexList = m('mission')->getMissionUserRelationIndexList($this->_userId, $aIds);
			unset($aIds);

			$aTemp = array();
			foreach($aWongFixend as $key => $val){
				$aTemp[$val['mission_id']] = $val['nums'];
			};

			foreach($aRelationIndexList as $key => $value) {
				$aIntersect = array_key_exists($value['mission_id'], $aTemp);
				$aRelationIndexList[$value['mission_id']] = $aIntersect ? array_merge($aRelationIndexList[$key], array('nums' => $aTemp[$value['mission_id']])) : '';
				unset($value['mission_id']);
			}
			unset($aTemp);

			foreach($aMissionList as $vak => $aVal){
				$tempFlag = array_key_exists($aVal['id'], $aRelationIndexList);
				if(!is_array($aRelationIndexList[$aVal['id']])){
					$aRelationIndexList[$aVal['id']] = array();
				}
				$aMissionList[$vak] = $tempFlag ? array_merge($aMissionList[$vak], $aRelationIndexList[$aVal['id']]) : array();
			}
			unset($aRelationIndexList);
		}
		//数组合并结束

		$aData['pageCount'] = $pageCount;
		$aData['aMissionList'] = $aMissionList;
		alert('', 1, $aData);
	}

	//辅导月份列表获取
	public function getMonthTutorial(){
		if($this->_isAnalogAccount){
			$aUserMonthStatisticsList = ParentImitate::getUserEsWrongMonthStatistics($this->_parentId);
			if($aUserMonthStatisticsList === false){
				return false;
			}elseif(!$aUserMonthStatisticsList){
				alert('', 1, array());
			}
			foreach($aUserMonthStatisticsList as $key => $aUserMonthStatistics){
				$aUserMonthStatisticsList[$key]['es_wrong_count'] = $aUserMonthStatistics['num'];
				$aUserMonthStatisticsList[$key]['cnMonth'] = $this->_enMonthToCnMont($aUserMonthStatistics['month']);
			}
			alert('', 1, $aUserMonthStatisticsList);
		}
		$mEs = m('Es');
		$aWrongMonthList = $mEs->getUserWrongEsMonthStatistics($this->_userId);
		if($aWrongMonthList === false){
			alert('系统错误', 0);
		}elseif(!$aWrongMonthList){
			alert('', 1, array());
		}
		$aWrongMonthStatisticsList = array();
		foreach($aWrongMonthList as $month => $wrongEs){
			$aTemp = array();
			$aTemp['month'] = $month;
			$aTemp['es_wrong_count'] = $wrongEs;
			$aWrongMonthStatisticsList[] = $aTemp;
		}

		$aUserMonthList = m('Parent')->getUserMonthStatisticsList($this->_userId);
		if($aUserMonthList === false){
			alert('系统错误', 0);
		}
		foreach($aWrongMonthStatisticsList as $key => $aWrongMonthStatistics){
			$aWrongMonthStatisticsList[$key]['es_repair_count'] = 0;
			foreach($aUserMonthList as $aUserMonth){
				if($aUserMonth['month'] == $aWrongMonthStatistics['month']){
					$aWrongMonthStatisticsList[$key]['es_repair_count'] = $aUserMonth['statistics']['es']['es_repair_count'];
					break;
				}
			}
			$aWrongMonthStatisticsList[$key]['cnMonth'] = $this->_enMonthToCnMont($aWrongMonthStatistics['month']);
		}
		alert('', 1, $aWrongMonthStatisticsList);
	}

	//根据月份获取题目
	public function getMonthWongLisyByMonth(){
		$month = intval(post('month'));
		$esSubject = intval(post('subject'));
		$page = intval(post('page'));
		if(!$month || !$month < 0 || !$esSubject || $esSubject < 0 || !$page || $page < 0){
			alert('参数错误', 0);
		}
		$aSubjectType = array(
			1,
			2,
			3
		);
		if(!in_array($esSubject, $aSubjectType)){
			alert('科目错误');
		}
		if($this->_isAnalogAccount){
			$aUserEsWrongMonthStatistics = ParentImitate::getUserEsWrongMonthStatistics($this->_parentId);
			$esCount = 0;
			foreach($aUserEsWrongMonthStatistics as $aUserEsWrongMonth){
				if($aUserEsWrongMonth['month'] == $month){
					$esCount = $aUserEsWrongMonth['num'];
					break;
				}
			}
			$aEsIdInfo = ParentImitate::getUserEsWrongInfo($this->_parentId, 'month', $month, $page - 1);
			if($aEsIdInfo === false){
				return false;
			}elseif(!$aEsIdInfo){
				alert('获取题目失败', 0);
			}
			//$aRedisEs = ParentImitate::getUserEsWrongInfo($this->_parentId, 'mission', $missionId, $page - 1);
			$oEs = m('es');
			$aEs = $oEs->getEsInfoByEsId($aEsIdInfo['es_id']);
			if(!$aEs){
				alert('获取题目失败', 0);
			}
			$aEs['es_id'] = Xxtea::encrypt($aEs['id']);
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
			$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
			$aEs['es_content'] = $oEsPlugin->removeAnswer($aEs['es_content']);
			alert('', 1, array('aEsInfo' => $aEs, 'esCount' => $esCount));
		}
		$aReturnMonthTime = $this->_getMonthRange($month . '01');
		$startTime = $aReturnMonthTime['startDate'];
		$endTime = $aReturnMonthTime['endDate'];

		$aEsListAndCount = $this->_getWongEsList(0, $page, 1, $esSubject, 0, $startTime, $endTime, '`create_time` desc');
		if($aEsListAndCount === false){
			alert('系统错误', 0);
		}
		foreach($aEsListAndCount['aEsList'] as &$aMissionList){
			unset($aMissionList['es_answer']);
			unset($aMissionList['es_content']['answer']);
			unset($aMissionList['recent_record']);
		}
		if(empty($aEsListAndCount['aEsList'])){
			alert('没有题目了喔', 0);
		}
		$aEsListAndCount['aEsInfo'] = $aEsListAndCount['aEsList'][0];
		unset($aEsListAndCount['aEsList']);
		//echo json_encode($aEsListAndCount);die;
		alert('加载成功', 1, $aEsListAndCount);
	}

	private function _getMonthRange($date){
		$aRet = array();
		$timestamp = strtotime($date);
		$mdays = date('t',$timestamp);
		$aRet['startDate'] = strtotime(date('Y-m-1 00:00:00',$timestamp));
		$aRet['endDate'] = strtotime(date('Y-m-'.$mdays.' 23:59:59',$timestamp));
		return $aRet;
	}

	//获取当前修复总基础数据
	public function getWongAndFinxed(){
		$isAnalogAccount = $this->_isAnalogAccount;
		if($isAnalogAccount){
			$aAllStatistics = ParentImitate::getUserEsWrongStatistics($this->_parentId);
			$fixedWrongEsCount = $aAllStatistics['es_repair_count'];
			$wrongEsCount = $aAllStatistics['es_repair_count'] + $aAllStatistics['wrong_es_count'];
		}else{
			$aWrongEsStatisticList = m('Es')->getUserSubjectWrongEsStatistic($this->_userId);
			if($aWrongEsStatisticList === false){
				alert('系统错误' , 0);
			}

			$wrongEsCount = $fixedWrongEsCount = 0;
			foreach($aWrongEsStatisticList as $aWrongEsStatistic){
				$fixedWrongEsCount += $aWrongEsStatistic['repair_es_count'];
				$wrongEsCount += $aWrongEsStatistic['wrong_es_count'] + $aWrongEsStatistic['repair_es_count'];
			}
		}
		alert('' , 1, array(
			'count_wrong' => $wrongEsCount,
			'count_finxed' => $fixedWrongEsCount
		));
	}

	public function showEsInfo(){
		display('parents/header.html.php');
		display('parents/tutorial-detail.html.php');
		display('parents/footer.html.php');
	}

	public function showRanking(){
		$thisMonthStartTime = mktime(0, 0, 0, date('m'), 1, date('Y'));
		$lastMonth = date('Ym', $thisMonthStartTime - 1);
		$thisYear = date('Y');
		$thisMonth = date('m');
		$aLastThreeMonth = array();
		$selectMonth = intval(get('month', $lastMonth));
		if($selectMonth > $lastMonth){
			$selectMonth = $lastMonth;
		}elseif($selectMonth < 201310){
			$selectMonth = 201310;
		}
		for($i = 1; $i <= 3; $i++){
			if($thisMonth - $i <= 0){
				$tempYear = $thisYear - 1;
				$tempMonth = 12 + $thisMonth - $i;
			}else{
				$tempYear = $thisYear;
				$tempMonth = $thisMonth - $i;
			}
			if($tempMonth < 10){
				$tempMonth = '0' . $tempMonth;
			}
			$aTemp = array();
			$aTemp['month'] = $tempMonth;
			$aTemp['year_month'] = $tempYear . $tempMonth;
			$aTemp['is_active'] = 0;
			if($aTemp['year_month'] == $selectMonth){
				$aTemp['is_active'] = 1;
			}
			$aLastThreeMonth[] = $aTemp;
		}
		assign('aLastThreeMonth', $aLastThreeMonth);
		assign('month', $selectMonth);
		assign('selectYear', substr($selectMonth, 0, 4));
		assign('cnMonth', $this->getCnDate($selectMonth));
		display('parents/header.html.php');
		display('parents/rank.html.php');
		display('parents/footer.html.php');
	}

	public function getRankList(){
		$thisMonthStartTime = mktime(0, 0, 0, date('m'), 1, date('Y'));
		$lastMonth = date('Ym', $thisMonthStartTime - 1);
		$nowMonth = intval(post('month', $lastMonth));
		if($nowMonth > $lastMonth){
			$nowMonth = $lastMonth;
		}
		$type = intval(post('type', 1));
		$aType = array(
			1 => '本市',
			2 => '本校',
			3 => '本班'
		);
		if(!$type || !array_key_exists($type, $aType)){
			alert('错误参数', 0);
		}
		$userId = $this->_userId;
		if($this->_isAnalogAccount){
			$userId = ParentImitate::USER_ID;
		}
		$page = 1;
		$pageSize = 20;
		$aUserRankList = array(
			'rank_list' => array(),
			'my_child' => array()
		);
		$aUserInfo = getUserInfo($userId, array('personal', 'area', 'class'));
		if($aUserInfo === false){
			alert('系统错误', 0);
		}elseif(!$aUserInfo){
			alert('没有数据', 1, array());
		}

		//$nowMonth = date('Ym');
		//$nowMonth = 201406;
		$aOption =  array(
			1 => array(
				'month'		=>	$nowMonth,
				'city_id'	=>	$aUserInfo['city_id'],
				'school_id'	=>	0,
				'grade'		=>	$aUserInfo['grade'],
				'class'		=>	'',
			),
			2 => array(
				'month'		=>	$nowMonth,
				'city_id'	=>	0,
				'school_id'	=>	$aUserInfo['school_id'],
				'grade'		=>	$aUserInfo['grade'],
				'class'		=>	'',
			),
			3 => array(
				'month'		=>	$nowMonth,
				'city_id'	=>	0,
				'school_id'	=>	$aUserInfo['school_id'],
				'grade'		=>	$aUserInfo['grade'],
				'class'		=>	$aUserInfo['class'],
			)
		);
		$mParent = m('Parent');

		$aMeMonthInfo = $mParent->getUserMonthStatisticsInfo($userId, $nowMonth);
		if($aMeMonthInfo === false){
			alert('系统错误', 0);
		}else if(!$aMeMonthInfo){
			alert('没有数据', 1, array());
		}

		$beatUser = 0;
		if($aMeMonthInfo['score'] != 0){
			$aMeRankInfo = $mParent->getUserMonthScoreRanking($nowMonth, $aMeMonthInfo['score'], $aOption[$type]);
			$aAllUserRankInfo = $mParent->getUserMonthScoreCount($nowMonth, $aOption[$type]);
			if($aAllUserRankInfo){
				$beatUser = intval(($aAllUserRankInfo - $aMeRankInfo) / $aAllUserRankInfo * 100);
			}
		}
		$aTempRankList = $mParent->getUserMonthScoreRankingList($page, $pageSize, $aUserInfo['class'], $aOption[$type]);
		if($aTempRankList === false){
			alert('系统错误', 0);
		}elseif(!$aTempRankList){
			alert('没有数据', 1, array());
		}

		foreach($aTempRankList as $key => &$aUsersInfo){
			$aUserRankList['rank_list'][$key] = array_merge($aUsersInfo, getUserInfo($aUsersInfo['user_id'], array('personal', 'area', 'class')));
			unset($aUserRankList['rank_list'][$key]['id']);
			unset($aUserRankList['rank_list'][$key]['xxt_data']);
		}
		unset($aTempRankList);
		$aUserRankList['my_child'] = array_merge(array('beat' => $beatUser, 'rankType' => $aType[$type]), $aUserInfo);
		alert('排行榜获取成功', 1, $aUserRankList);
	}

	public function showProduct(){
		display('parents/header.html.php');
		display('parents/intro.html.php');
		display('parents/footer.html.php');
	}



	/**
	 * 批阅修复做题并且返回下一题的题目和评论继续做
	 */
	public function markingFixEs(){
		//验证参数
		$wrongId = intval(post('wrong_id'));
		$mAnswer = post('answer');

		$oEs = m('Es');
		$aUserWrongEs = $oEs->getUserEsWrongById($wrongId);
		if(!$aUserWrongEs){
			alert('非法的错题查询', 0);
		}

		$aFixEs = $oEs->getEsInfoByEsId($aUserWrongEs['es_id']);
		if(!$aFixEs){
			alert('找不到该题目', 0);
		}

		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aFixEs['type_id']]);
		if(!$oEsPlugin->validateAnswer($mAnswer)){
			alert('无效的答案', 0);
		}

		//批阅题目
		$aAnswerResult = $oEsPlugin->getCorrectness($aFixEs['content_json'], $mAnswer);
		$isPass = $aAnswerResult['pass'];
		if($isPass){
			alert('抱歉，系统出错，修复题目失败！', 1, $isPass);
		}

		//获取下一条题目
		$page = intval(post('page'));
		$subjectId = intval(post('subject'));
		$missionId = intval(post('mission'));
		$aNextEs = $this->_getNextFixEs($page, $subjectId, $missionId);

		alert('批阅完毕', 1, array(
			'is_finish' => $aNextEs ? 0 : 1,
			'is_pass' => $isPass,
			'next_es_data' => $aNextEs,
		));
	}

	/**
	 * 重新搜索题目
	 */
	public function researchEs(){
		$subjectId = intval(post('subject'));
		$missionId = intval(post('mission'));
		$page = intval(post('page'));
		if(!$subjectId || !$missionId){
			alert('错误参数', 0);
		}
		$aEs = $this->_getNextFixEs($page, $subjectId, $missionId);
		if(!$aEs){
			alert('该目录下没有题目', 0);
		}
		alert('', 1, $aEs);
	}

	private function _getNextFixEs($page, $subjectId, $missionId){
		if($page < 1){
			$page = 1;
		}

		if($subjectId && $subjectId != 4 && !array_key_exists($subjectId, $GLOBALS['SUBJECT'])){
			alert('非法的查询科目', 0);
		}

		$filter = 2;
		if($missionId){
			$oMission = m('Mission');
			$aMission = $oMission->getMissionInfoById($missionId);
			if(!$aMission){
				alert('非法的查询关卡', 0);
			}
			$filter = 1;
		}
		if($this->_isAnalogAccount){
			$aRedisEs = ParentImitate::getUserEsWrongInfo($this->_parentId, 'mission', $missionId, $page - 1);
			if(!$aRedisEs){
				alert('获取题目失败', 0);
			}
			$oEs = m('es');
			$aEs = $oEs->getEsInfoByEsId($aRedisEs['es_id']);
			if(!$aEs){
				alert('获取题目失败', 0);
			}
			$aEs['es_id'] = Xxtea::encrypt($aEs['id']);
			$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
			$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
			$aEs['es_content'] = $oEsPlugin->removeAnswer($aEs['es_content']);
			return $aEs;
		}

		$oEs = m('Es');
		$aEs = $oEs->getUserWrongEsList($this->_userId, $page, 1, $subjectId, 0, $filter, $missionId, 0, 0);
		//alert('', 0, $aEs);
		if($aEs === false){
			alert('获取题目失败', 0);
		}elseif(!$aEs){
			return $aEs;
		}
		$aEs = $aEs[0];
		$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEs['type_id']]);
		$aEs['wrong_id'] = $aEs['id'];
		$aEs['es_id'] = Xxtea::encrypt($aEs['es_id']);
		$aEs['es_content'] = $oEsPlugin->resolve($aEs['content_json']);
		return $aEs;
	}

	//月份转换
	private function _enMonthToCnMont($month){
		$month = intval(substr($month, -2));
		$aChinaMont = array(
			'一月',
			'二月',
			'三月',
			'四月',
			'五月',
			'六月',
			'七月',
			'八月',
			'九月',
			'十月',
			'十一月',
			'十二月',
		);
		return $aChinaMont[$month - 1];
	}

	//目前没用
	public function getWrongEsListByCondition($callType = 0, $getType = 2, $page = 1, $missionId = 0, $esSubject = 1){
		if(!$callType){
			$getType = intval(post('getType'));
			$page = intval(post('page'));
			$missionId = intval(post('missionId'));
			$esSubject = intval(post('esSubject'));
		}

		if($getType != 1 && $getType != 2 || $page < 1 || $missionId < 0){
			alert('数据错误', 0);
		}
		$aEsListAndCount = array();
		if($getType == 1){
			$aEsListAndCount = $this->_getWongEsList($missionId, $page);
		}else{
			if($esSubject != 0 && !isset($GLOBALS['SUBJECT'][$esSubject])){
				alert('数据错误', 0);
			}
			$startTime = strtotime(date('y-m-d',strtotime("-1 month")));
			$endTime = strtotime(date('Y-m-d'));

			$aEsListAndCount = $this->_getWongEsList($missionId, $page, 10, $esSubject, 0, $startTime, $endTime, '`create_time` desc');
		}

		if($aEsListAndCount === false){
			alert('系统错误', 0);
		}

		if($callType){
			return $aEsListAndCount;
		}else{
			alert('', 1, $aEsListAndCount);
		}
	}

	//根据条件反回错题列表
	private function _getWongEsList($missionId = 0, $page = 1, $pageSize = 10, $subjectId = 0, $typeId = 0, $startTime = 0, $endTime = 0, $order = '`create_time` desc'){
		$filter = 2;
		if($missionId > 0){
			$filter = 1;
		}
		$oEs = m('Es');
		$aData = array(
			'esCount' 	=> 0,
			'aEsList'	=> array()
		);
		$esCount = $oEs->getUserWrongEsCount($this->_userId, $subjectId, $typeId, $filter, $missionId, $startTime, $endTime);
		$aEsList = $oEs->getUserWrongEsList($this->_userId, $page, $pageSize, $subjectId, $typeId, $filter, $missionId, $startTime, $endTime, $order);

		if($esCount === false || $aEsList === false){
			return false;
		}

		if($aEsList){
			foreach($aEsList as $key => $aEsInfo){
				$oEsPlugin = esPlugin($GLOBALS['TYPE_RESOLVER'][$aEsInfo['type_id']]);
				$aEsList[$key]['es_content'] = $oEsPlugin->resolve($aEsInfo['content_json']);
				if($aEsInfo['type_id'] == 6 || $aEsInfo['type_id'] == 7){
					$esIds = array();
					if($aEsInfo['answer_last']){
						foreach($aEsInfo['answer_last'] as $esLastInfo){
							$esIds[] = $esLastInfo['index'];
						}
					}
					$aEsList[$key]['es_answer'] = $oEsPlugin->getAnswer($aEsList[$key]['es_content'], $esIds);
				}else{
					$aEsList[$key]['es_answer'] = $oEsPlugin->getAnswer($aEsList[$key]['es_content'], array());
				}
				$aEsList[$key]['es_id'] = Xxtea::encrypt($aEsInfo['es_id']);
			}
		}
		$aData['esCount'] = $esCount;
		$aData['aEsList'] = $aEsList;
		unset($esCount);
		unset($aEsList);
		return $aData;
	}
	//--------------------永尚-----------------------------------------------------------------------------------------

	//获取用户最新月份信息概况
	public function getUserMonthList() {
		$oParent = m('Parent');
		$userId = $this->_userId;
		$isAnalogAccount = $this->_isAnalogAccount; //模拟标志
		//获取月份详细信息
		if ($isAnalogAccount) {
			$aMonthStatisticsList = ParentImitate::getUserMonthStatisticsList();
		} else {
			$aMonthStatisticsList = $oParent->getUserMonthStatisticsList($userId);
		}
		if($aMonthStatisticsList === false){
			alert('网络可能有点慢', 0);
		}
		$aMonthStatisticsList = $this->_converMonthStatisticsList($aMonthStatisticsList);
		//获取击败全部百分百
		if(count($aMonthStatisticsList) > 1){
			if ($aMonthStatisticsList[1]['score'] != '0') {
				$month = $aMonthStatisticsList[1]['month'];
				//计算击败人数百分比
				$meRadin = $oParent->getUserMonthScoreRanking($month, $aMonthStatisticsList[1]['score']);
				if($meRadin === false){
					alert('网络可能有点慢', 0);
				}
				$allRanding = $oParent->getUserMonthScoreCount($month);
				if($allRanding === false){
					alert('网络可能有点慢', 0);
				}
				if($allRanding){
					$aMonthStatisticsList[1]['randing'] = intval(($allRanding - $meRadin) / $allRanding * 100);
				}else{
					$aMonthStatisticsList[1]['randing'] = 0;
				}
			} else {
				$aMonthStatisticsList[1]['randing'] = 0;
			}
		}


//		p($result);
		foreach ($aMonthStatisticsList as $k => $aMonthStatistics) {
			$missionTotal = 0;	//闯关总题数
			$pkTotal = 0;		//PK总题数
			$matchTotal = 0;	//闯关总题数
			$missionEsWrong = 0;
			$pkEsWrong = 0;
			$mathEsWrong = 0;
			$allCore = 0;	//闯关总分
			//中文显示月份
			$aMonthStatisticsList[$k]['cnMonth'] = $this->getCnDate($aMonthStatistics['month']);

			if($aMonthStatistics['statistics']['es']['mission'] && is_array($aMonthStatistics['statistics']['es']['mission'])){
				foreach ($aMonthStatistics['statistics']['es']['mission'] as $aMission) {
					$missionTotal += $aMission['es_total'];
					$missionEsWrong += $aMission['es_wrong'];
				}
			}
			foreach ($aMonthStatistics['statistics']['es']['pk'] as $aPk) {
				$pkTotal += $aPk['es_total'];
				$pkEsWrong += $aPk['es_wrong'];
			}
			foreach ($aMonthStatistics['statistics']['es']['match'] as $aMatch) {
				$matchTotal += $aMatch['es_total'];
				$mathEsWrong += $aMatch['es_wrong'];
			}
			$len = count($aMonthStatistics['statistics']['mission']);
			foreach ($aMonthStatistics['statistics']['mission'] as $aMission) {
				$allCore += $aMission['score'];
			}
			//每月答题总数
			$aMonthStatisticsList[$k]['answerTotal'] = $missionTotal + $pkTotal + $matchTotal;
			$aMonthStatisticsList[$k]['missionLeng'] = $len;
			$aMonthStatisticsList[$k]['errorTotal'] = $missionEsWrong + $pkEsWrong + $mathEsWrong;
			if($len == 0){
				$aMonthStatisticsList[$k]['avaCore'] = 0;
			}else{
				$aMonthStatisticsList[$k]['avaCore'] = intval($allCore / $len / 100);
			}
			//正确率
			if ($aMonthStatisticsList[$k]['answerTotal'] == '0') {
				$aMonthStatisticsList[$k]['correctTotal'] = '0';
			} else {
				$aMonthStatisticsList[$k]['correctTotal'] = intval((($aMonthStatisticsList[$k]['answerTotal'] - $aMonthStatisticsList[$k]['errorTotal']) / $aMonthStatisticsList[$k]['answerTotal']) * '100');
			}
		}
		alert('', 1, $aMonthStatisticsList);
	}

	public function getUserMonthDetail(){
		$userId = $this->_userId;
		$month = get('month', date('Ym', time()));
		//$month = '201406';
		$isAnalogAccount = $this->_isAnalogAccount;
		$oParent = m('Parent');
		if ($isAnalogAccount) {
			$aUserInfo = ParentImitate::getUserInfo(array('class'));
			$aUserMonthStatisticsInfo = ParentImitate::getUserMonthStatisticsInfo($month);
		} else {
			$aUserInfo = getUserInfo($userId, array('class'));
			//获取月份详细信息
			$aUserMonthStatisticsInfo = $oParent->getUserMonthStatisticsInfo($userId, $month);
		}
		if($aUserInfo === false || $aUserMonthStatisticsInfo === false){
			alert('网络可能有点慢', 0);
		}
		if (empty($aUserMonthStatisticsInfo)){
			if($month != date('Ym')){
				display('parents/header.html.php');
				display('parents/report-nodata.html.php');
				display('parents/footer.html.php');
				return;
			}
			$aUserMonthStatisticsInfo = $this->_getInitMonthStatistics();
			$aUserMonthStatisticsInfo['month'] = date('Ym');
		}
		$aUserMonthStatisticsInfo['cnMonth'] = $this->getCnDate($aUserMonthStatisticsInfo['month']);
		if ($aUserMonthStatisticsInfo['score'] != '0') {
			//计算击败人数百分百
			$meRadin = $oParent->getUserMonthScoreRanking($month, $aUserMonthStatisticsInfo['score']);
			if($meRadin === false){
				alert('网络可能有点慢', 0);
			}
			$allRanding = $oParent->getUserMonthScoreCount($month);
			if($allRanding === false){
				alert('网络可能有点慢', 0);
			}
			if(!$allRanding){
				$aUserMonthStatisticsInfo['randing'] = 0;
			}else{
				$aUserMonthStatisticsInfo['randing'] = intval(($allRanding - $meRadin) / $allRanding * 100);
			}
		}else{
			$aUserMonthStatisticsInfo['randing'] = 0;
		}

		//各科数量
		$aUserMonthStatisticsInfo['yuwenTotal'] = $aUserMonthStatisticsInfo['statistics']['es']['mission'][1]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][1]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][1]['es_total'];
		$aUserMonthStatisticsInfo['shuxueTotal'] = $aUserMonthStatisticsInfo['statistics']['es']['mission'][2]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][2]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][2]['es_total'];
		$aUserMonthStatisticsInfo['yingyuTotal'] = $aUserMonthStatisticsInfo['statistics']['es']['mission'][3]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][3]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][3]['es_total'];
		//总条数
		$aUserMonthStatisticsInfo['allTotal'] = $aUserMonthStatisticsInfo['yuwenTotal'] + $aUserMonthStatisticsInfo['shuxueTotal'] + $aUserMonthStatisticsInfo['yingyuTotal'];
		//正确数
		$chineseWrong = ($aUserMonthStatisticsInfo['statistics']['es']['mission'][1]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][1]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][1]['es_wrong']);
		$chineseCorrect = $aUserMonthStatisticsInfo['yuwenTotal'] - $chineseWrong;
		$matchWrong = ($aUserMonthStatisticsInfo['statistics']['es']['mission'][2]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][2]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][2]['es_wrong']);
		$matchCorrent = $aUserMonthStatisticsInfo['shuxueTotal'] - $matchWrong;
		$englishWrong = ($aUserMonthStatisticsInfo['statistics']['es']['mission'][3]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][3]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][3]['es_wrong']);
		$englishCorrect = $aUserMonthStatisticsInfo['yingyuTotal'] - $englishWrong;
		$aUserMonthStatisticsInfo['ywerror'] = $chineseWrong;
		$aUserMonthStatisticsInfo['matchWrong'] = $matchWrong;
		$aUserMonthStatisticsInfo['englishWrong'] = $englishWrong;

		//正确率
		$chineseCorrect ? $aUserMonthStatisticsInfo['yuwenzql'] = floor($chineseCorrect / $aUserMonthStatisticsInfo['yuwenTotal'] * 100) : $aUserMonthStatisticsInfo['yuwenzql'] = '0';
		$matchCorrent ? $aUserMonthStatisticsInfo['matchCorrentl'] = floor($matchCorrent / $aUserMonthStatisticsInfo['shuxueTotal'] * 100) : $aUserMonthStatisticsInfo['matchCorrentl'] = '0';
		$englishCorrect ? $aUserMonthStatisticsInfo['englishCorrectl'] = floor($englishCorrect / $aUserMonthStatisticsInfo['yingyuTotal'] * 100) : $aUserMonthStatisticsInfo['englishCorrectl'] = '0';

		//总计正确率
		if($aUserMonthStatisticsInfo['allTotal']){
			$aUserMonthStatisticsInfo['totalzql'] = floor(($chineseCorrect + $matchCorrent + $englishCorrect) / $aUserMonthStatisticsInfo['allTotal'] * 100);
		}else{
			$aUserMonthStatisticsInfo['totalzql'] = 0;
		}

		//闯关平均分
		$avaCore = 0;
		$oMissionList = m('mission');
		$len = count($aUserMonthStatisticsInfo['statistics']['mission']);
		$missions = array();
		$missionIds = array();
		foreach ($aUserMonthStatisticsInfo['statistics']['mission'] as $k => $v) {
//			$aUserMonthStatisticsInfo['statistics']['mission'][$k]['missionTitle'] = $oMissionList->getMissionListByIds($v['mission_id']);
			$missionIds[] = $v['mission_id'];
			$missions[$v['mission_id']] = $v['score'];
			$avaCore+=$v['score'];
		}
		$missionList = $oMissionList->getMissionListByIds($missionIds);
		foreach ($missionList as $kk => $val) {
			foreach ($missions as $k => $v) {
				if ($k == $val['id']) {
					if ($v == '0') {
						$temp = 0;
					} else {
						$temp = intval($v / 100);
					}
					$missionList[$kk]['score'] = $temp;
					continue;
				}
			}
		}
		$aUserMonthStatisticsInfo['missionList'] = json_encode($missionList);
		if ($avaCore > 1) {
			$aUserMonthStatisticsInfo['avaCore'] = intval($avaCore / $len / 100);
		} else {
			$aUserMonthStatisticsInfo['avaCore'] = '0';
		}

		$aUserMonthStatisticsInfo['statistics']['match'] = array(
//			0	=>	array(
//				'match_id'		=>	39,
//				'subject_id'	=>	2,
//				'ranking'		=>	1,
//				'create_time'	=>	13875451125,
//			),
//			1	=>	array(
//				'match_id'		=>	30,
//				'subject_id'	=>	2,
//				'ranking'		=>	3,
//				'create_time'	=>	13875451125,
//			),
//			2	=>	array(
//				'match_id'		=>	37,
//				'subject_id'	=>	2,
//				'ranking'		=>	100,
//				'create_time'	=>	13875451125,
//			),
		);
		$oMatch = new Model(T_MATCH);
		foreach ($aUserMonthStatisticsInfo['statistics']['match'] as $km => $vm) {
			$temp = $oMatch->get('name', 'id =' . $vm['match_id']);
			$aUserMonthStatisticsInfo['statistics']['match'][$km]['name'] = $temp[0]['name'];
		}

		assign('detailData', $aUserMonthStatisticsInfo);
		display('parents/header.html.php');
		display('parents/report-detail.html.php');
		display('parents/footer.html.php');
	}

	public function repairEs(){
		$esId = post('esId', '');
		$esId = Xxtea::decrypt($esId);
		if($this->_isAnalogAccount){
			$result = ParentImitate::repairUserEsWrong($this->_parentId, $esId);
			if($result === false){
				alert('网络可能有点慢', 0);
			}elseif(!$result){
				alert('不存在这个错题', 0);
			}
			alert('修复成功', 1);
		}
		$oEs = m('Es');
		if(!$esId){
			alert('不存在这个错题', 0);
		}
		$aUserWrongEs = $oEs->getUserWrongEsByUserIdAndEsId($this->_userId, $esId);
		if($aUserWrongEs === false){
			alert('网络可能有点慢', 0);
		}elseif(!$aUserWrongEs){
			alert('不存在这个错题', 0);
		}
		$result = m('Vip')->repairWrongEs($aUserWrongEs, array(), 0);
		if(!$result){
			alert('修复题目失败', 0);
		}
		alert('修复成功', 1);
	}

	public function ajaxGetMonthInfoDetail() {
		$userId = $this->_userId;
		$month = get('month', date('Ym', time()));
//		$month = '201406';
		$isAnalogAccount = $this->_isAnalogAccount;
		$oParent = m('Parent');
		if ($isAnalogAccount) {
			$aUserInfo = ParentImitate::getUserInfo();
			$aUserMonthStatisticsInfo = ParentImitate::getUserMonthStatisticsInfo($month);
		}else{
			if($userId){
				$aUserInfo = getUserInfo($userId);
			}else{
				//请求和教育拿名字
				$aUserInfo = array();
			}
			//获取月份详细信息
			$aUserMonthStatisticsInfo = $oParent->getUserMonthStatisticsInfo($userId, $month);
		}
		if($aUserInfo === false || $aUserMonthStatisticsInfo === false){
			alert('网络可能有点慢', 0);
		}
		$userName = '';
		if($aUserInfo){
			$userName = $aUserInfo['name'];
		}
		if (empty($aUserMonthStatisticsInfo)) {
			$aUserMonthStatisticsInfo['username'] = $userName;
			alert('数据为空', 0, $aUserMonthStatisticsInfo);
		}
		$aUserMonthStatisticsInfo['cnMonth'] = $this->getCnDate($aUserMonthStatisticsInfo['month']);
		if ($aUserMonthStatisticsInfo['score'] != '0') {
			//计算击败人数百分百
			$meRadin = $oParent->getUserMonthScoreRanking($month, $aUserMonthStatisticsInfo['score']);
			if($meRadin === false){
				alert('网络可能有点慢', 0);
			}
			$allRanding = $oParent->getUserMonthScoreCount($month);
			if($allRanding === false){
				alert('网络可能有点慢', 0);
			}
			if(!$allRanding){
				$aUserMonthStatisticsInfo['randing'] = 0;
			}
			$aUserMonthStatisticsInfo['randing'] = intval(($allRanding - $meRadin) / $allRanding * 100);
		} else {
			$aUserMonthStatisticsInfo['randing'] = 0;
		}

		//各科数量
		$aUserMonthStatisticsInfo['yuwenTotal'] = $aUserMonthStatisticsInfo['statistics']['es']['mission'][1]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][1]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][1]['es_total'];
		$aUserMonthStatisticsInfo['shuxueTotal'] = $aUserMonthStatisticsInfo['statistics']['es']['mission'][2]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][2]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][2]['es_total'];
		$aUserMonthStatisticsInfo['yingyuTotal'] = $aUserMonthStatisticsInfo['statistics']['es']['mission'][3]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][3]['es_total'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][3]['es_total'];
		//总条数
		$aUserMonthStatisticsInfo['allTotal'] = $aUserMonthStatisticsInfo['yuwenTotal'] + $aUserMonthStatisticsInfo['shuxueTotal'] + $aUserMonthStatisticsInfo['yingyuTotal'];
		//正确数
		$chineseWrong = ($aUserMonthStatisticsInfo['statistics']['es']['mission'][1]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][1]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][1]['es_wrong']);
		$chineseCorrect = $aUserMonthStatisticsInfo['yuwenTotal'] - $chineseWrong;
		$matchWrong = ($aUserMonthStatisticsInfo['statistics']['es']['mission'][2]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][2]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][2]['es_wrong']);
		$matchCorrent = $aUserMonthStatisticsInfo['shuxueTotal'] - $matchWrong;
		$englishWrong = ($aUserMonthStatisticsInfo['statistics']['es']['mission'][3]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['pk'][3]['es_wrong'] + $aUserMonthStatisticsInfo['statistics']['es']['match'][3]['es_wrong']);
		$englishCorrect = $aUserMonthStatisticsInfo['yingyuTotal'] - $englishWrong;
		$aUserMonthStatisticsInfo['ywerror'] = $chineseWrong;
		$aUserMonthStatisticsInfo['matchWrong'] = $matchWrong;
		$aUserMonthStatisticsInfo['englishWrong'] = $englishWrong;

		//正确率
		$chineseCorrect ? $aUserMonthStatisticsInfo['yuwenzql'] = floor($chineseCorrect / $aUserMonthStatisticsInfo['yuwenTotal'] * 100) : $aUserMonthStatisticsInfo['yuwenzql'] = '0';
		$matchCorrent ? $aUserMonthStatisticsInfo['matchCorrentl'] = floor($matchCorrent / $aUserMonthStatisticsInfo['shuxueTotal'] * 100) : $aUserMonthStatisticsInfo['matchCorrentl'] = '0';
		$englishCorrect ? $aUserMonthStatisticsInfo['englishCorrectl'] = floor($englishCorrect / $aUserMonthStatisticsInfo['yingyuTotal'] * 100) : $aUserMonthStatisticsInfo['englishCorrectl'] = '0';

		//总计正确率
		if($aUserMonthStatisticsInfo['allTotal']){
			$aUserMonthStatisticsInfo['totalzql'] = floor(($chineseCorrect + $matchCorrent + $englishCorrect) / $aUserMonthStatisticsInfo['allTotal'] * 100);
		}else{
			$aUserMonthStatisticsInfo['totalzql'] = 0;
		}
		//闯关平均分
		$avaCore = 0;
		$oMissionList = m('mission');
		$len = count($aUserMonthStatisticsInfo['statistics']['mission']);
		$missions = array();
		$missionIds = array();
		if($aUserMonthStatisticsInfo['statistics']['mission'] && is_array($aUserMonthStatisticsInfo['statistics']['mission'])){
			foreach ($aUserMonthStatisticsInfo['statistics']['mission'] as $k => $v) {
				$missionIds[] = $v['mission_id'];
				$missions[$v['mission_id']] = $v['score'];
				$avaCore+=$v['score'];
			}
		}
		$missionList = $oMissionList->getMissionListByIds($missionIds);
		foreach ($missionList as $kk => $val) {
			foreach ($missions as $k => $v) {
				if ($k == $val['id']) {
					if ($v == '0') {
						$temp = 0;
					} else {
						$temp = floor($v / 100);
					}
					$missionList[$kk]['score'] = $temp;
					continue;
				}
			}
		}
		$aUserMonthStatisticsInfo['missionList'] = json_encode($missionList);
		if ($avaCore > 1) {
			$aUserMonthStatisticsInfo['avaCore'] = floor($avaCore / $len / 100);
		} else {
			$aUserMonthStatisticsInfo['avaCore'] = '0';
		}

		$aUserMonthStatisticsInfo['statistics']['match'] = array(
//			0	=>	array(
//				'match_id'		=>	39,
//				'subject_id'	=>	2,
//				'ranking'		=>	1,
//				'create_time'	=>	13875451125,
//			),
//			1	=>	array(
//				'match_id'		=>	30,
//				'subject_id'	=>	2,
//				'ranking'		=>	3,
//				'create_time'	=>	13875451125,
//			),
//			2	=>	array(
//				'match_id'		=>	37,
//				'subject_id'	=>	2,
//				'ranking'		=>	100,
//				'create_time'	=>	13875451125,
//			),
		);
		$oMatch = new Model(T_MATCH);
		foreach ($aUserMonthStatisticsInfo['statistics']['match'] as $km => $vm) {
			$temp = $oMatch->get('name', 'id =' . $vm['match_id']);
			$aUserMonthStatisticsInfo['statistics']['match'][$km]['name'] = $temp[0]['name'];
		}
		$aUserMonthStatisticsInfo['missionLength'] = count($aUserMonthStatisticsInfo['statistics']['mission']);
		$aUserMonthStatisticsInfo['username'] = $userName;
//		p($result);
		alert('', 1, $aUserMonthStatisticsInfo);
	}
	public function noMonthData(){
		display('parents/header.html.php');
		display('parents/report-nodata.html.php');
		display('parents/footer.html.php');
	}

	/**
	 * 传入日期返回中文月份
	 * @param type $time 201409
	 * @return string
	 */
	public function getCnDate($time) {
		$month = intval(substr($time, -2));
		$cnMonth = array("一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二");
		return $cnMonth[$month - 1];
	}

	private function _converMonthStatisticsList($aMonthStatisticsList){
		$aUserMonthStatisticsInit = $this->_getInitMonthStatistics();
		$currentMonth = date('Ym');
		if($aMonthStatisticsList){
			if($aMonthStatisticsList[0]['month'] != $currentMonth){
				$aUserMonthStatisticsInit['month'] = $currentMonth;
				array_unshift($aMonthStatisticsList, $aUserMonthStatisticsInit);
			}
		}else{
			$aUserMonthStatisticsInit['month'] = $currentMonth;
			array_unshift($aMonthStatisticsList, $aUserMonthStatisticsInit);
		}
		return $aMonthStatisticsList;
		$aFirstMonth = array_pop($aMonthStatisticsList);
		$aMonthStatisticsList[] = $aFirstMonth;
		$aMonthList = array();
		$aMonthStatisticsListRefer = array();
		foreach ($aMonthStatisticsList as $aMonthStatistics) {
			$aMonthList[] = $aMonthStatistics['month'];
			$aMonthStatisticsListRefer[$aMonthStatistics['month']] = $aMonthStatistics;
		}
		$firstYear = substr($aFirstMonth['month'], 0, 4);
		$firstMonth = substr($aFirstMonth['month'], 4);
		$thisYear = date('Y');
		$thisMonth = date('m');
		for ($i = $firstYear; $i <= $thisYear; $i++) {
			if ($i < $thisYear) {
				for ($j = 1; $j <= 12; $j++) {
					if ($j < 10) {
						$yearMonth = $i . '0' . $j;
					} else {
						$yearMonth = $i . $j;
					}
					if (in_array($yearMonth, $aMonthList)) {
						continue;
					}
					$aTemp = $aUserMonthStatisticsInit;
					$aTemp['month'] = $yearMonth;
					$aMonthStatisticsListRefer[$yearMonth] = $aTemp;
				}
			} else {
				for ($j = 1; $j <= $thisMonth; $j++) {
					if ($j < 10) {
						$yearMonth = $i . '0' . $j;
					} else {
						$yearMonth = $i . $j;
					}
					if (in_array($yearMonth, $aMonthList)) {
						continue;
					}
					$aTemp = $aUserMonthStatisticsInit;
					$aTemp['month'] = $yearMonth;
					$aMonthStatisticsListRefer[$yearMonth] = $aTemp;
				}
			}
		}
		$aReturnData = array();
		ksort($aMonthStatisticsListRefer);
		foreach ($aMonthStatisticsListRefer as $aMonthStatistics) {
			array_unshift($aReturnData, $aMonthStatistics);
		}
		return $aReturnData;
	}

	private function _getInitMonthStatistics(){
		$aUserStatisticsInit = array(
			'es' => array(
				'es_repair_count' => 0,
				'mission' => array(
					1 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
					2 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
					3 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
				),
				'pk' => array(
					1 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
					2 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
					3 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
				),
				'match' => array(
					1 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
					2 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
					3 => array(
						'es_total' => 0,
						'es_wrong' => 0,
					),
				),
			),
			'mission' => array(),
			'match' => array(),
		);
		$aUserMonthStatisticsInit = array(
			'month' => 0,
			'score' => 0,
			'statistics' => $aUserStatisticsInit,
		);
		return $aUserMonthStatisticsInit;
	}

	public function showSuperClass(){
		display('parents/header.html.php');
		display('parents/super-class.html.php');
		display('parents/footer.html.php');
	}
}