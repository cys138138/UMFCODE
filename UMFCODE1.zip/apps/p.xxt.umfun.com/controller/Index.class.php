<?php
class IndexController{

	private $_userId = 0;
	private $_userIds = 15947559;
	public function __construct(){
//		if($_GET['a'] != 'notice' && $_GET['a'] != 'parentIntro' && $_GET['a'] != 'educationInformation' && $_GET['a'] != 'educationInformationDetail'){
//			$aUser = checkParentLogin();
//			//echo json_encode($aUser);
//			$this->_userId = $aUser['id'];
//			$this->_userIds = $aUser['user_ids'][0];
//		}
	}

	public function showNewIndex(){
		$aParentUserInfo = checkParentLogin();
		$userId = isset($aParentUserInfo['user_ids'][0]) ? $aParentUserInfo['user_ids'][0] : 0;
		//$userId = $this->_userIds;
		$aMonthUserInfo = m('Parent')->getUserMonthStatisticsInfo($userId, date('Ym'));
		if($aMonthUserInfo === false){
			alert('系统错误', 0);
		}

		assign('aMonthUserInfo', $aMonthUserInfo);
		assign('aParentUserInfo', $aParentUserInfo);
		display('parents/header.html.php');
		display('parents/index.html.php');
		display('parents/footer.html.php');
	}

	public function index(){
		$aParentUserInfo = isParentLogin();
		if(!$aParentUserInfo){
			$isComputer = isComputer();
			if($isComputer){
				header('location:' . PC_API_LOGIN_URL);
			}else{
				header('location:' . url('m=Index&a=showNewIndex'));
			}
			exit;
		}
		header('location:' . url('m=Index&a=showNewIndex'));
		exit();

		$userId = isset($aParentUserInfo['user_ids'][0]) ? $aParentUserInfo['user_ids'][0] : 0;
		if(intval(get('userId'))){
			$aChildren = getUserInfo(intval(get('userId')), array('numerical'));
			if($aChildren && in_array(intval(get('userId')), $aParentUserInfo['user_ids'])){
				$userId = $aChildren['id'];
			}
		}
		//$userId=96977300;
		if(!$userId){
			header('location:' . url('m=Index&a=notice', '', APP_P_XXT));
			exit;
		}
		$aUserInfo = getUserInfo($userId, array('numerical'));
		$oUserNumerical = m('UserNumerical');
		$aUserNumerical = $oUserNumerical->getUserNumericalInfoById($userId);
		if($aUserNumerical === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aUserInfo = array_merge($aUserInfo, $aUserNumerical);
		$oMission = m('Mission');
		$aAllMissionStatistics = $oMission->getAllMissionStatisticsByUserId($userId);
		if(!$aAllMissionStatistics){
			$aAllMissionStatistics = array(
				'pass_mission_count' => 0,
				'es_count' => 0,
				'es_correct_count' => 0,
				'subject_count' => array(),
				'last_12_month_count' => array()
			);
			$aAllMissionStatistics['subject_count'][1] = array(
				'es_count' => 0,
				'es_correct_count' => 0,
				'pass_mission_count' => 0,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aAllMissionStatistics['subject_count'][2] = array(
				'es_count' => 0,
				'es_correct_count' => 0,
				'pass_mission_count' => 0,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aAllMissionStatistics['subject_count'][3] = array(
				'es_count' => 0,
				'es_correct_count' => 0,
				'pass_mission_count' => 0,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aAllMissionStatistics['subject_count'][4] = array(
				'es_count' => 1,
				'es_correct_count' => 0,
				'pass_mission_count' => 1,
				'percent' => 0,
				'mission_rate' => 0
			);
			$aLast12MonthList = array();
			$thisYear = date('Y');
			$thisMonth = date('m');
			for($i = 11; $i >= 0; $i --){
				if($thisMonth - $i > 0){
					$year = $thisYear;
					$month = $thisMonth - $i;
				}else{
					$year = $thisYear - 1;
					$month = 12 - ($i - $thisMonth);
				}
				if($month < 10){
					$month = 0 . $month;
				}
				$monthStartTime = mktime(0, 0, 0, $month, 1, $year);
				if($month < 12){
					$monthEndTime = mktime(0, 0, 0, $month + 1, 1, $year) - 1;
				}else{
					$monthEndTime = mktime(0, 0, 0, 1, 1, $year + 1) - 1;
				}
				$aLast12MonthList[$year . $month] = array(
					'start_time' => $monthStartTime,
					'end_time' => $monthEndTime,
					'pass_mission_count' => 0,
					'es_count'	=> 0,
					'sum_score'	=> 0,
				);
			}
			$aAllMissionStatistics['last_12_month_count'] = $aLast12MonthList;
		}
		$aAllMissionStatistics['subject_count'][1]['percent'] = $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][1]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][2]['percent'] = $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][2]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][3]['percent'] = $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][3]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : '00.00';

		$aAllMissionStatistics['subject_count'][1]['mission_rate'] = $aAllMissionStatistics['pass_mission_count'] ? intval(($aAllMissionStatistics['subject_count'][1]['pass_mission_count'] / $aAllMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][2]['mission_rate'] = $aAllMissionStatistics['pass_mission_count'] ? intval(($aAllMissionStatistics['subject_count'][2]['pass_mission_count'] / $aAllMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aAllMissionStatistics['subject_count'][3]['mission_rate'] = $aAllMissionStatistics['pass_mission_count'] ? intval(($aAllMissionStatistics['subject_count'][3]['pass_mission_count'] / $aAllMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';

		$aEsMonthStats = array();
		$aMissionMonthStats = array();
		$aScoreMonthStats = array();
		$i = 0;
		foreach($aAllMissionStatistics['last_12_month_count'] as $key => $aStats){
			$aEsMonthStats[$i] = array();
			$aMissionMonthStats[$i] = array();
			$aScoreMonthStats[$i] = array();
			$aEsMonthStats[$i][0] = $key;
			$aEsMonthStats[$i][1] = $aStats['es_count'];
			$aMissionMonthStats[$i][0] = $key;
			$aMissionMonthStats[$i][1] = $aStats['pass_mission_count'];
			$aScoreMonthStats[$i][0] = $key;
			$aScoreMonthStats[$i][1] = $aStats['pass_mission_count'] ? intval((($aStats['sum_score'] / 100) / $aStats['pass_mission_count']) * 100) / 100 : 0;
			$i++;
		}
		$aMonthStats = array($aEsMonthStats, $aMissionMonthStats, $aScoreMonthStats);

		$oNumerical = m('UserNumerical');
		$aMedalList = $oNumerical->getMedalListByUserIds(array($userId));
		if($aMedalList === false){
			$aMedalList = array();
		}elseif($aMedalList){
			$aMedalList = $aMedalList[0]['medal_process'];
		}
		$oPk = m('Pk');
		$aUserPkStat = $oPk->getUserPkCountListByUserIds(array($userId));
		if($aUserPkStat === false){
			alert('读取学生PK统计信息失败', 0);
		}
		$oMatch = m('Match');
		$matchCount = $oMatch->getUserRegisterMatchCount($userId);
		if($matchCount === false){
			alert('读取学生参赛数量失败', 0);
		}
		$matchWinPrizeCount = $oMatch->getUserWinPrizeCount($userId);
		if($matchWinPrizeCount === false){
			alert('读取学生比赛次获奖数失败', 0);
		}
		$oUser = m('User');
		$aMonthList = $oUser->getUserMonthList($userId);
		if(!$aMonthList){
			alert('读取学生的成绩周期失败', 0);
		}

		if($aUserInfo['vip'] >= 2 && $aUserInfo['vip_expiration_time'] > time()){
			assign('isVip', 1);
		}else{
			assign('isVip', 0);
		}
		assign('aMonthList', $aMonthList);
		assign('matchWinPrizeCount', $matchWinPrizeCount);
		assign('matchCount', $matchCount);
		assign('aUserPkStat', $aUserPkStat[0]);
		assign('aMedalList', $aMedalList);
		assign('aMonthStats', $aMonthStats);
		assign('aUserInfo', $aUserInfo);
		assign('aAllMissionStatistics', $aAllMissionStatistics);
		assign('isLink', 0);
		assign('userId', $userId);
		assign('aParentUserInfo', $aParentUserInfo);
		displayHeader();
		display('index/index.html.php');
		displayFooter();
	}

	public function getUserMonthGradeList(){
		$userId = intval(post('userId'));
		$year = intval(post('year'));
		$month = intval(post('month'));
		$aUser = getUserInfo($userId);
		if(!$aUser || $year > 2100 || $year < 2012 || $month > 12 || $month < 1){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$oMission = m('Mission');
		$aMonthMissionStatistics = $oMission->getUserMonthStatistics($userId, $year, $month);
		if(!$aMonthMissionStatistics){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['subject_count'][1]['percent'] = $aMonthMissionStatistics['es_count'] ? intval(($aMonthMissionStatistics['subject_count'][1]['es_count'] / $aMonthMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][2]['percent'] = $aMonthMissionStatistics['es_count'] ? intval(($aMonthMissionStatistics['subject_count'][2]['es_count'] / $aMonthMissionStatistics['es_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][3]['percent'] = $aMonthMissionStatistics['es_count'] ? intval(($aMonthMissionStatistics['subject_count'][3]['es_count'] / $aMonthMissionStatistics['es_count']) * 10000) / 100 : '00.00';

		$aMonthMissionStatistics['subject_count'][1]['mission_rate'] = $aMonthMissionStatistics['pass_mission_count'] ? intval(($aMonthMissionStatistics['subject_count'][1]['pass_mission_count'] / $aMonthMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][2]['mission_rate'] = $aMonthMissionStatistics['pass_mission_count'] ? intval(($aMonthMissionStatistics['subject_count'][2]['pass_mission_count'] / $aMonthMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';
		$aMonthMissionStatistics['subject_count'][3]['mission_rate'] = $aMonthMissionStatistics['pass_mission_count'] ? intval(($aMonthMissionStatistics['subject_count'][3]['pass_mission_count'] / $aMonthMissionStatistics['pass_mission_count']) * 10000) / 100 : '00.00';

		if(!$aMonthMissionStatistics['pass_mission_count']){
			$aMonthMissionStatistics['subject_count'][4]['es_count'] = 1;
			$aMonthMissionStatistics['subject_count'][4]['pass_mission_count'] = 1;
		}
		$oPk = m('Pk');
		$startTime = $month < 10 ? strtotime($year . '-0' . $month) : strtotime($year . '-' . $month);
		if($month == 12){
			$endTime = strtotime(($year + 1) . '-01');
		}else{
			$endTime = ($month + 1) < 10 ? strtotime($year . '-0' . ($month + 1)) : strtotime($year . '-' . ($month + 1));
		}
		$aPkStats = $oPk->getUserPkCountListByUserIds(array($userId), $startTime, $endTime);
		if($aPkStats === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['aMonthPkStats'] = $aPkStats[0];
		$oMatch = m('Match');
		$matchCount = $oMatch->getUserRegisterMatchCount($userId, $startTime, $endTime);
		if($matchCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['matchCount'] = $matchCount;
		$winPrizeCount = $oMatch->getUserWinPrizeCount($userId, $startTime, $endTime);
		if($winPrizeCount === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}
		$aMonthMissionStatistics['winPrizeCount'] = $winPrizeCount;
		for($i = 1; $i <= 3; $i++){
			if($aMonthMissionStatistics['subject_count'][$i]['pass_mission_list']){
				foreach($aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'] as $key => $value){
					$aTempStatics = $oPk->getUserMissionPkStatistics($userId, $value['mission_id']);
					$pkWinRate = $aTempStatics['pk_count'] ? intval(($aTempStatics['win_count'] / $aTempStatics['pk_count']) * 10000) / 100 : 0.00;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['pk_win_rate'] = $pkWinRate;
					$defeatPercent = $oMission->getDefeatedPercent($value['mission_id'], $value['score']);
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['defeat_percent'] = $defeatPercent;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['pk_count'] = $aTempStatics['pk_count'];
					$esCountCommentStr = '';
					$missionScoreCommentStr = '';
					$pkWinRateCommentStr = '';
					$esCount = $aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['es_count'];
					$score = $aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['score'] / 100;
					if($esCount > 40){
						$esCountCommentStr = '好勤奋哟！去和其他小伙 <a href="javascript:;">PK</a> 吧！';
						if($score < 80){
							$missionScoreCommentStr = '<a href="' . url('m=Mission&a=showMissionChallenge&id=' . $value['mission_id'], '', APP_HOME) . '">去继续修炼此关卡 ！</a>';
						}else{
							if($pkWinRate < 60){
								$pkWinRateCommentStr = '<a href="' . url('m=Mission&a=showMissionChallenge&id=' . $value['mission_id'], '', APP_HOME) . '">去继续修炼此关卡 ！</a>';
							}
						}
					}else{
						$esCountCommentStr = '<a href="' . url('m=Mission&a=showMissionChallenge&id=' . $value['mission_id'], '', APP_HOME) . '">去继续修炼此关卡 ！</a>';
						if($score > 80){
							$missionScoreCommentStr = '去和其他小伙 <a href="javascript:;">PK</a> 吧！';
						}else{
							if($pkWinRate >= 60 && $pkWinRate < 80){
								$pkWinRateCommentStr = '去和其他小伙 <a href="javascript:;">PK</a> 吧！';
							}
						}
					}

					if($pkWinRate >= 80){
						$pkWinRateCommentStr = 'PK之王当之无愧！';
					}
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['esCountCommentStr'] = $esCountCommentStr;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['missionScoreCommentStr'] = $missionScoreCommentStr;
					$aMonthMissionStatistics['subject_count'][$i]['pass_mission_list'][$key]['pkWinRateCommentStr'] = $pkWinRateCommentStr;
				}
			}
		}

		alert('月战绩！', 1, $aMonthMissionStatistics);
	}

	public function notice(){
		/*$code = get('code');
		$cs = get('cs');
		$childrenName = '';
		if($code){
			$childrenName = Xxtea::decrypt($code);
		}

		assign('childrenName', $childrenName);
		assign('cs', $cs);*/
		displayHeader();
		//display('index/notice.html.php');
		display('index/notice_home.html.php');
		displayFooter();
	}

	public function doXxtAccountRegister(){
		User::doXxtAccountRegister();
	}

	public function parentIntro(){
		display('index/parent_intro.html.php');
	}

	public function educationInformation(){
		$oEduNews = m('EduNews');
		$aEduNewsList = $oEduNews->getNewsContentList();
		if($aEduNewsList === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		assign('aEduNewsList', $aEduNewsList);
		displayHeader();
		display('index/education_information.html.php');
		displayFooter();
	}

	public function educationInformationDetail(){
		$id = intval(get('id'));
		if(!$id){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		$oEduNews = m('EduNews');
		$aEduNews = $oEduNews->getNewsContentInfo($id);
		if($aEduNews === false){
			alert('抱歉，系统出错，请稍后再试！', 0);
		}

		assign('aEduNews', $aEduNews);
		displayHeader();
		display('index/education_information_detail.html.php');
		displayFooter();
	}

	public function loginChildren(){
		Debug::mark('login_children_start');
		Parents::loginChildren();

		header('location:' . url('m=Account&a=showHome', '', APP_XXT));
	}

}