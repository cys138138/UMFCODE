<?php
define('TITLE', '优满分(UMFun) - 中国最大中小学生在线游戏化学习平台！');
header("Content-type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
$GLOBALS['VIEW']= new View(APP_VIEW_PATH);

function displayHeader($title = ''){
	if($title){
		$title = $title . ' - ';
	}
	$title = $title . TITLE;
	echo getHeader($title);
}

function getHeader($title = ''){
	$title .= TITLE;
	$aCurrentUserInfo = isParentLogin();
	if(!$aCurrentUserInfo){
		assign('isLogin', 0);
	}else{
		$aChildren = getUserListByUserIds($aCurrentUserInfo['user_ids']);
		$aCurrentUserInfo['children'] = $aChildren;
		assign('isLogin', 1);
		assign('aCurrentUserInfo', $aCurrentUserInfo);
	}
	assign('title', $title);
	return fetch('header.html.php');
}


function displayFooter(){
	echo getFooter();
}

function getFooter(){
	return fetch('footer.html.php');
}