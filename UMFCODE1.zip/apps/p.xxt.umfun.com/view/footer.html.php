<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>
<!--umfun