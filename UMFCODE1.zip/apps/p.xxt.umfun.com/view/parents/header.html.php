<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>优满分</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <!-- <link rel="icon" type="image/png" href="assets/i/favicon.png">
  <link rel="apple-touch-icon-precomposed" href="assets/i/app-icon72x72@2x.png"> -->
  <meta name="apple-mobile-web-app-title" content="umfun" />
  <link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['m_new_parents_amazeui_min_css']; ?>">
  <script src="<?php echo $GLOBALS['RESOURCE']['zepto.min']; ?>"></script>
  <script src="<?php echo $GLOBALS['RESOURCE']['chart.min']; ?>"></script>
</head>
<body>