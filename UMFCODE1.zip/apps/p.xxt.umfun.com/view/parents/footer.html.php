<!-- nav-bar -->
<!-- ============================================================================= -->

<div class="am-topbar-fixed-bottom" id="navBars">
  <div class="am-navbar am-cf um-navbar-default" id="">
	<ul class="am-navbar-nav am-cf sm-block-grid-4">

		<li id="navbar-goback"  <?php echo get('m') != 'Index' ? 'onclick="showlink(url)"' : ''; ?>>
		<a href="javascript:;" id="btn-back" onclick="window.location.href=document.referrer;">
			<span class="navbars-icon um-icon-goback am-active"></span>
			<span class="am-navbar-label" <?php if(get('m') == 'Index'){ echo 'style="color: #999;"'; } ?>>返回</span>
		</a>
		</li>

		<li id="navbar-report" <?php echo get('m') != 'Index' ? 'onclick="showlink(\'/?m=Index&a=showNewIndex#report\');"' : 'onclick="showDialog(1);"'; ?>>
		<a href="javascript:;" data-rel="report">
			<span class="navbars-icon um-icon-report"></span>
			<span class="am-navbar-label">报告</span>
		</a>
		</li>

		<li class="am-active" id="navbar-home" <?php echo get('m') != 'Index' ? 'onclick="showlink(\'/?m=Index&a=showNewIndex\');"' : ''; ?>>
		<a href="javascript:;" data-rel="home">
			<span class="navbars-icon um-icon-home"></span>
			<span class="am-navbar-label">首页</span>
		</a>
		</li>

		<li id="navbar-tutorial" <?php echo get('m') != 'Index' ? 'onclick="showlink(\'/?m=Index&a=showNewIndex#tutorial\');"' : 'onclick="showDialog(2);"'; ?>>
		<a href="javascript:;" data-rel="tutorial" >
			<span class="navbars-icon um-icon-tutorial"></span>
			<span class="am-navbar-label">辅导</span>
		</a>
		</li>

		<li id="navbar-more" id="navbar-more">
		<a href="javascript:;" data-rel="more" >
			<span class="navbars-icon um-icon-more"></span>
			<span class="am-navbar-label">更多</span>
		</a>
		</li>

	</ul>
	<ul class="more-list">
		<!-- 通过showlink来调用链接 -->
		<li><a href="javascript:;" onclick="showlink('<?php echo url('m=Index&a=loginChildren', '', APP_LOGIN); ?>')">进入学生版</a></li>
		<li><a href="javascript:;" data-alert="report">[报告]功能演示</a></li>
		<li><a href="javascript:;" data-alert="tutorial">[辅导]功能演示</a></li>
		<li><a href="javascript:;" onclick="showlink('/?m=Statistic&a=showRanking'+'#more')">排行榜</a></li>
		<li><a href="javascript:;" onclick="showlink('/?m=Statistic&a=showProduct'+'#more')">了解优满分</a></li>
		<li><a href="javascript:;" onclick="showlink('/?m=Statistic&a=userFeed'+'#more')">家长反馈</a></li>
	</ul>
  </div>
</div>

<!-- alert -->
<div class="am-modal am-modal-confirm" tabindex="-1" id="um-confirm">
  <div class="am-modal-dialog">
    <div class="am-modal-hd um-alert-hd">提示</div>
    <div class="am-modal-bd am-text-center um-alert-bd">
      现在进入功能演示
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn" data-am-modal-confirm>确定</span>
      <span class="am-modal-btn" data-am-modal-cancel>取消</span>
    </div>
  </div>
</div>
<script src="<?php echo $GLOBALS['RESOURCE']['amazeui']; ?>"></script>
<script src="<?php echo $GLOBALS['RESOURCE']['m_new_parents_app']; ?>"></script>
<script>
	var isIndex = '<?php echo get('m'); ?>';
$(function(){
	var isAnalogAccount = <?php echo Cookie::isSetted('analogAccount') ? 1:0;  ?>;
	if(isAnalogAccount){
		$('.simulate').prepend('<div class="um-title-info" id="simulation"  style="color:#FFFFFF; background-color:#E76969;"><b>请注意：您正在演示账号中！</b><button type="button" class="am-btn um-btn-blue am-fr am-btn-xs" style="color:#E76969; background-color: #FFFFFF;" onclick="showlink(\'/?m=Statistic&a=exitAnalogAccount\')">退出演示账号</button><br/>该页面显示的数据并非您孩子的数据！</div>');
		$('#simulation').show();
	}

	//$('#mobile-home').height(screen.height - $('#navBars').height());
});

Zepto(function(){
	if(isIndex != 'Index'){
		// 返回按钮点击事件
		$('#btn-back').on('click', function(e) {
		  e.preventDefault();
		  //window.history.go(-1);
		  window.location.href=document.referrer;
		});
	}
});

function showDialog(type){
	var cok = Zepto.fn.cookie('readTips_' + type);
	if(cok){
		return false;
	}
	if(type == 3){
		Zepto('#isSetCookies_3').show();
	}
	Zepto('#tutorialDialog_' + type).trigger('click');
}

function setCookies(type){
	if(Zepto('#isSetCookies_' + type).attr('checked')){
		Zepto.fn.cookie('readTips_' + type, '1', { expires: 3600 });
	}
}
</script>
<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>
