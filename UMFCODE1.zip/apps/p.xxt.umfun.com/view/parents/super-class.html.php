<style>
    body{
        margin: 0;
    }
    .um-activity-super-class{
        background-color: #c1e4ff;
    }
    .item-block {
        background-size: 100% 100%;
        background-repeat: no-repeat;
    }
    .item-block:nth-child(2n-1) {
        background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/border1.jpg);
    }
    .item-block:nth-child(2n) {
        background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/border2.jpg);
    }
    .item-block .title{
        text-align: center;
        margin: auto;
        background: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/title.jpg) no-repeat;
        background-size: 100% 100%;
    }
    .item-block > div > .submit-button{
        display: block;
        border: 0;
        margin: auto;
        background: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/submit.jpg) no-repeat;
    }
    .item-block > div > .slogan{
        border: 0;
        background-color: #ffeba3;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .item-block .notice{
        position: relative;
        color: #ff4800;
    }
    .item-block .notice:before{
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        display: block;
        width: 81px;
        height: 81px;
        background: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/notice.png) no-repeat;
    }
    .reward-list{
        font-size: 0;
    }
    .reward-list > .reward-item{
        display: inline-block;
        background: no-repeat center bottom;
        background-size: contain;
    }
    .reward-list > .reward-item:nth-child(1){
        background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/reward1.jpg);
    }
    .reward-list > .reward-item:nth-child(2){
        background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/reward2.jpg);
    }
    .reward-list > .reward-item:nth-child(3){
        background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/reward3.jpg);
    }
    .reward-list > .reward-item:nth-child(4){
        background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/reward4.jpg);
    }
    .rule-list > div{
        position: relative;
    }
    .rule-list > div > .rule-order{
        display: inline-block;
        position: absolute;
        text-align: center;
        top: 0;
        left: 0;
        border: 1px solid white;
        background-color: #ffc800;
    }
    /*mobile*/
    @media screen and (max-width: 640px){
        html {
            font-size: 62.5%;
        }
        body ._framePageContainer {
            padding-bottom: 55px;
        }
        .top-block{
            padding: 24% 0;
            background: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/top_app.jpg) center top no-repeat;
            background-size: 100%;
        }
        .um-activity-super-class > .container{
            padding: 0 5% 1px;
        }
        .item-block{
            padding: 20px;
            margin: 20px 0;
        }
        .item-block:nth-child(3) {
            background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/border3.jpg);
        }
        .item-block:nth-child(4) {
            background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/border4.jpg);
        }
        .item-block .title{
            width: 80%;
            padding: 4% 0;
            margin: 20px auto;
            font-size: 1.4rem;
        }
        .item-block > div > .slogan{
            width: 100%;
            height: 150px;
            border-radius: 10px;
            padding: 10px;
            font-size: 1.2rem;
            margin-bottom: 20px;
        }
        .item-block > div > .submit-button{
            width: 297px;
            height: 85px;
            margin: 60px auto 20px;
            zoom: 0.5;
        }
        .desc{
            margin: 25px 0 20px;
        }
        .desc > .info{
            font-size: 1.4rem;
        }
        .desc > .message{
            font-size: 1.3rem;
        }
        .item-block .status-notice{
            text-align: center;
            font-size: 1.4rem;
            margin-bottom: -20px;
        }
        .item-block .notice{
            font-size: 1.3rem;
            padding: 10px 0 0 40px;
            margin: 20px 0 10px;
        }
        .item-block .notice:before{
            zoom: 0.5;
        }
        .reward-list > .reward-item{
            width: 40%;
            height: 200px;
            margin: 0 5% 20px;
        }
        .rule-list{
            font-size: 1.2rem;
            line-height: 1.5;
        }
        .rule-list > div{
            padding-left: 25px;
            margin: 5px;
        }
        .rule-list > div > .rule-order {
            width: 18px;
            height: 18px;
            line-height: 18px;
            border-radius: 10px;
        }
    }
    /*pc*/
    @media screen and (min-width: 641px){
        .um-activity-super-class{
            margin-top: -15px;
            padding-bottom: 85px;
        }
        .um-activity-super-class > .container{
            max-width: 1000px;
            margin: -150px auto 0;
        }
        .top-block{
            height: 814px;
            background-image: url(<?php echo SYSTEM_RESOURCE_URL; ?>view2/app/parents/super-class/img/top_pc.jpg);
            background-position: center;
        }
        .item-block{
            padding: 40px 80px;
            margin: 40px 0;
        }
        .item-block .title{
            width: 664px;
            height: 66px;
            line-height: 66px;
            margin: 20px auto;
            font-size: 26px;
        }
        .item-block > div > .slogan{
            width: 833px;
            height: 177px;
            border-radius: 10px;
            margin: 50px auto 20px;
            padding: 10px;
            font-size: 24px;
        }
        .item-block > div > .submit-button{
            width: 297px;
            height: 85px;
            cursor: pointer;
            margin: 60px auto 20px;
        }
        .desc{
            margin: 50px 0 40px;
        }
        .desc > .info{
            font-size: 28px;
        }
        .desc > .message{
            font-size: 26px;
        }
        .item-block .status-notice{
            text-align: center;
            font-size: 28px;
            margin-bottom: -40px;
        }
        .item-block .notice{
            font-size: 26px;
            padding: 20px 0 0 80px;
            margin: 40px 0 20px;
        }
        .reward-list{
            padding-top: 70px;
        }
        .reward-list > .reward-item{
            width: 25%;
            height: 330px;
        }
        .rule-list{
            font-size: 24px;
            line-height: 1.5;
            padding-top: 10px;
        }
        .rule-list > div{
            padding-left: 45px;
            margin: 5px;
        }
        .rule-list > div > .rule-order {
            width: 36px;
            height: 36px;
            line-height: 36px;
            border-radius: 19px;
        }
    }
</style>
<div class="um-activity-super-class">
    <div class="top-block"></div>
    <div class="container">
        <div class="item-block">
            <div class="desc">
                <div class="info">优满分超级班级，为你的班级报名，参与活动，最终决选人气班级获得大奖！</div>
                <div class="message">
                    报名时间：9月7日-10月15日<br/>
                    投票时间：10月19日-11月18日<br/>
                    投票人气最高的班级里每一位参与了活动的用户都能获奖！
                </div>
            </div>
            <div class="notice">参与活动时系统会以优满分帐号中的学校班级信息报名,报名前务必确认系统中的班级信息是否正确，否则将有可能无法获奖！</div>
        </div>
        <!--<div class="item-block">-->
            <!--<div class="J-status-initial">-->
                <!--<div class="title">为你的班级说一句话</div>-->
                <!--<textarea class="J-slogan slogan" placeholder="告诉大家你的班级的厉害之处"></textarea>-->
                <!--<div class="status-notice">你现在所在班级“<span class="J-school-name">&lt;!&ndash;data:学校班级信息&ndash;&gt;</span>”如信息不符，请在<a class="J-school-link">“学校信息”</a>中修改正确的信息</div>-->
                <!--<button class="J-submit-button submit-button"></button>-->
            <!--</div>-->
            <!--<div class="J-status-finish">-->
                <!--<div class="J-school-name title">&lt;!&ndash;data:学校班级信息&ndash;&gt;</div>-->
                <!--<div class="J-class-id title">&lt;!&ndash;班级名称&ndash;&gt;</div>-->
                <!--<div class="status-notice">已报名成功，投票相关信息会在近期发布，请密切关注！</div>-->
                <!--<div class="notice">别忘记告诉你的同学，让大家都来参与。班级越多同学参与，获奖机会越大哦！</div>-->
            <!--</div>-->
        <!--</div>-->
        <div class="item-block">
            <div class="title">丰富大奖</div>
            <div class="reward-list">
                <span class="reward-item"></span>
                <span class="reward-item"></span>
                <span class="reward-item"></span>
                <span class="reward-item"></span>
            </div>
            <div class="notice">获奖班级每一位参与了活动的同学都能得到一份奖品哦！</div>
        </div>
        <div class="item-block">
            <div class="title">活动规则</div>
            <div class="rule-list">
                <div><span class="rule-order">1</span>本活动面向优满分学生会员用户</div>
                <div>
                    <span class="rule-order">2</span>本活动分为两部份；<br/>
                    报名期：用户需在报名期报名参与活动，用户确认参与活动代表用户为当前所在班级报名；<br/>
                    投票期：活动通过投票点赞数量评选人气班级（投票形式稍后公布）。<br/>
                </div>
                <div><span class="rule-order">3</span>参与活动时系统会以优满分帐号中的学校班级信息报名，报名前务必确认系统中的班级信息是否正确</div>
                <div><span class="rule-order">4</span>投票人气最高的班级里每一位参与了活动的用户都会获得奖品</div>
                <div><span class="rule-order">5</span>本活动最终解释权归“优满分”所有，如有其它疑问联系官方QQ2025928896</div>
            </div>
        </div>
    </div>
    <div class="bottom-block"></div>
</div>