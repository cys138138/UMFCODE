<script src="<?php echo $GLOBALS['RESOURCE']['zepto.cookie.min']; ?>"></script>
<!-- home -->
<!-- ============================================================================= -->
<div class="am-g am-page simulate" id="mobile-home">
	<?php if(0){ ?>
		<section class="um-mod um-green am-cf">
			<a>
				<img src="xxxxxxxxx" />
			</a>
			<a href="xxxxxxxxx" >
				<img src="xxxxxxxxx" />
			</a>
		</section>
	<?php }else{ ?>
		<section class="um-mod um-green am-cf am-pagination-centered">
			<a href="http://h5i.umfun.com/article/simple-topic/12270.html">
				<img alt="" style="width:100%" src="<?php echo $GLOBALS['RESOURCE']['parents_pbj_banner']; ?>" />
			</a>
		</section>
	<?php } ?>

	<section class="um-mod um-green am-cf">
		<div class="um-mod-title">欢迎来到优满分家长版</div>
		<div class="col-sm-12 um-bd">
			<p>优满分向家长提供孩子每月学习分析报告和家庭辅导两个服务，帮助家长随时随地了解孩子学习情况，及时解决学习问题，以此提高孩子成绩！
快请您的孩子进入学生版畅游吧！
</p>
		</div>
		<div class="am-text-center um-green" style="margin-bottom: 15px;">
		  <a class="am-btn um-btn-ghost"  onclick="showlink('<?php echo url('m=Index&a=loginChildren', '', APP_LOGIN); ?>');">进入学生版<i class="am-icon-chevron-circle-right um-icon-chevron-circle-right"></i></a>
		</div>
    </section>

	<section class="um-mod am-cf">
		<div class="um-mod-title-simple">本月学生做题报告</div>
		<div class="col-sm-12">
			<table class="am-table am-table-bd um-table">
				<thead>
					<tr>
						<th class="um-table-green"><span class="am-icon-tag"></span></th>
						<th class="um-table-yellow">语文</th>
						<th class="um-table-yellow">数学</th>
						<th class="um-table-yellow">英语</th>
						<th class="um-table-yellow">总结</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="um-table-green">答题数</td>
						<td id='indexYuwentotal'>0</td>
						<td id='indexshuxuetotal'>0</td>
						<td id='indexyingyutotal'>0</td>
						<td id='indexAlltotal'>0</td>
					</tr>
					<tr>
						<td class="um-table-green">正确率</td>
						<td id='indexYuwenzql'>0</td>
						<td id='indexshuxuezql'>0</td>
						<td id='indexyingyuzql'>0</td>
						<td id='indexAllzql'>0</td>
					</tr>
				</tbody>
			</table>
		</div>
    <!--
	</section>

    section class="um-mod um-orange am-cf" id='indexAnswerList1'>
		<div class="um-mod-title-simple">本月答题情况</div>
		<div class="col-sm-12 um-bd">
			<p><strong xid='indexUserName'> </strong>还没有答题信息，请让您的孩子登录<a href='#' onclick="showlink('/?m=Statistic&a=showProduct&show=students')">优满分学生版</a>答题，即可产生数据。</p>
		</div>
    </section

    <section class="um-mod um-orange am-cf">
	-->

		<div class="um-mod-title-simple">本月错题概况信息</div>
		<div class="col-sm-12 um-bd" style="padding-top: 0px;">
			<ul class="am-list am-list-static">
				<li class="am-cf">语文 : <strong id='indexYuwenError'>0</strong>次
					<button type="button" class="am-btn um-btn-orange am-fr am-btn-sm" id='indexYuwenCi' onclick="showlink('/?m=Index&a=showNewIndex#tutorial')">进入辅导</button>
				</li>
				<li>数学 : <strong id='indexShuxueError'>0</strong>次
					<button type="button" class="am-btn um-btn-orange am-fr am-btn-sm" id='indexShuxueCi' onclick="showlink('/?m=Index&a=showNewIndex#tutorial')">进入辅导</button>
				</li>
				<li>英语 : <strong id='indexYingyuError'>0</strong>次<button type="button" class="am-btn um-btn-orange am-fr am-btn-sm" id='indexYingyuCi' onclick="showlink('/?m=Index&a=showNewIndex#tutorial')">进入辅导</button></li>
			</ul>
		</div>

		 <div class="am-text-center" style="margin-bottom:15px;"><a href="###" onclick="showlink('/?m=Statistic&a=getUserMonthDetail&month=<?php echo date('Ym') ?>')">查看本月报告详情</a></div>

		<div class="am-text-center um-green" style="margin-bottom: 15px;">
			<!--<a class="am-btn um-btn-ghost" onclick="showlink('<?php echo url('m=Index&a=loginChildren', '', APP_LOGIN); ?>');">进入学生版<i class="am-icon-chevron-circle-right um-icon-chevron-circle-right"></i></a>-->
		</div>
    </section>

	<?php if(!Cookie::isSetted('noShowAnalogAccount')){ ?>
    <section class="um-mod um-orange am-cf"  id='indexFirstShow'>
		<div class="um-mod-title"><i class="am-icon-exclamation-circle"></i>体验优满分家长版</div>
		<div class="col-sm-12 um-bd">
			<p>首次登录可能没有孩子的答题数据，导致您无法体验家长版功能，<br>您可以使用优满分<strong>演示账户</strong>进行体验！
</p>
			<div class="um-btn-group am-text-center">
			  <a class="am-btn um-btn-ghost am-btn-block" data-alert="report"><i class="um-icon-arrow1"></i>进入[报告]功能演示</a>
			  <a class="am-btn um-btn-ghost am-btn-block" data-alert="tutorial"><i class="um-icon-arrow1"></i>进入[辅导]功能演示</a>
			</div>
			<small class="am-text-center am-block am-margin-vertical-sm">温馨提示：底部更多按钮也可进入演示账户！</small>
			<a class="am-btn um-btn-notice" data-alert="noShowAnalogAccount">已体验，以后不再显示</a>
		</div>
    </section>
	<?php } ?>
</div>


<!-- end am-page -->




<!-- report -->
<!-- ============================================================================= -->
<div class="am-g am-page am-page-hidden simulate" id="mobile-report">
	<!---没有数据的时候显示--->
<div class="am-g am-page" style="background:#fff; display:none;" id="monthList">
	<section class="am-cf" style="margin-top:1em">
		<img alt="" src="<?php echo $GLOBALS['RESOURCE']['m_new_parents_no_data_bg']; ?>" />
	</section>
	<section class="am-accordion am-accordion-gapped m0 mt0">
		<div class="am-text-center no-data">
			<div class="am-block">没有更多数据了，<br>推荐你点击<a href="###">功能演示</a>体验</div>
			<a class="am-btn um-btn-taste am-block" data-alert="report">进入[报告]功能演示</a>
			<div class="am-block">您的孩子还没有在优满分答题，<br>请他在<a href="###" onclick="showlink('/?m=Statistic&a=showProduct&show=students')">优满分学生版</a>答题即可查看数据</div>
		</div>
	</section>
</div>
	<section class="am-accordion am-accordion-gapped m0" id='reports' style="display:none;">
		<dl class="am-accordion-item um-accordion-item am-active">
			<dt class="um-accordion-title am-" id="firstMonthData">
			<span class="text-center um-font-gray-dark"><span class="am-icon-bar-chart um-font-orange"></span><span id="firstMonth"></span></span>
			<!--<button type="button" class="am-btn um-btn-orange am-fr am-btn-xs">进入辅导</button>-->
			<button type="button" class="am-btn um-btn-orange am-fr am-btn-xs" onclick="tiaozhuan(this)" id='firstMonthUrl'>查看详情</button>
			</dt>
			<dd class="am-accordion-content am-collapse am-in um-accordion-content" id="lastMonthBox" style="display:none;">
				<div class="um-accordion-hd">
					<span class="am-fl"><strong id="twoMonth">上月</strong>能力值</span>
					<span class="am-fr" onclick="showlink('/?m=Statistic&a=showProduct&show=Ability');"><span class="am-icon-question-circle"></span>了解能力值</span>
				</div>

				<div class="um-accordion-bd" onclick="tiaozhuan(this)"  id="twoMonthUrl">
					<div class="um-accordion-bd-scroe" id="ability">0</div>
					<div class="um-accordion-bd-text">
						<table class="am-fr um-accordion-bd-table">
							<tbody>
								<tr>
									<td>答题数：</td>
									<td><strong id="answerNum">0</strong></td>
									<td>闯关数：</td>
									<td><strong id="confirmNum">0</strong></td>
								</tr>
								<tr>
									<td>正确率：</td>
									<td><strong id="correctNum">0</strong></td>
									<td>平均分：</td>
									<td><strong id="averageNum">0</strong></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>

				<div class="um-accordion-ft" id='jibairenshu'>击败了全国<strong id="lrandings">0%</strong>学生，点击<em onclick="showlink('/?m=Statistic&a=showRanking');">排行榜</em>查看孩子的排名</div>
			</dd>
		</dl>

		<dl class="am-accordion-item" id="monthTotalList">

		</dl>
		<dl id="pageMore" style='display:none;'>
			<center id='clickPageMore'>【点击加载更多】</center>
		</dl>

		<!--    <div class="am-text-center no-data" id="reportNodata">
				<span class="um-icon um-icon-moji-fail am-icon-lg"></span>
				没有更多数据了，<br>推荐你今日<a href="javascript:;">模拟用户</a>体验
			</div>-->

	</section>
	<input type="hidden" id="tutorialDialog_1" data-am-modal="{target: '#doc-modal-1'}"/>
	<input type="hidden" id="p_page" value="1" name="p_page"/>
</div>


<!-- end am-page -->




<!-- tutorial -->
<!-- ============================================================================= -->
<div class="am-g am-page am-page-hidden simulate" id="mobile-tutorial">
	<section class="am-accordion am-accordion-gapped m0">
		<dl class="am-accordion-item um-accordion-item am-active mt0">
			<!-- 修改um-fixed-bg1/um-fixed-bg2 两种颜色 -->
			<dd class="am-accordion-content am-collapse am-in um-fixed-content um-fixed-bg1" id="tutorialStyle">
				<div class="um-accordion-hd am-text-center">
					辅导修复概览
				</div>

				<div class="um-accordion-bd">
					<div class="am-btn-group  am-btn-group-xs">
						<button type="button" class="am-btn am-btn-default" onclick="listType(2);" id="btnGroupMission">关卡</button>
						<button type="button" class="am-btn am-btn-default" onclick="listType(1);" id="btnGroupTime">时间</button>
					</div>
					<div class="am-btn-group  am-btn-group-xs am-fr">
						<button type="button" class="am-btn am-btn-default btn-subject" onclick="getTutoriaMission(1, 1, this);">语文</button>
						<button type="button" class="am-btn am-btn-default btn-subject" onclick="getTutoriaMission(2, 1, this);">数学</button>
						<button type="button" class="am-btn am-btn-default btn-subject" onclick="getTutoriaMission(3, 1, this);">英语</button>
					</div>
				</div>

				<div class="um-accordion-ft">
					<span>总错题数：<strong id="wong">0</strong></span>
					<span>待修复：<strong id="waitFinxed">0</strong></span>
					<span>已修复：<strong id="finxed">0</strong></span>
				</div>
			</dd>
		</dl>


		<div id="tutorialBox"></div>

	</section>

	<input type="hidden" id="tutorialDialog_2" data-am-modal="{target: '#doc-modal-2'}"/>
</div>

<!-- modal -->
<div class="am-modal am-modal-no-btn um-modal-guide" tabindex="-1" id="doc-modal-1">
	<div class="am-modal-dialog">
		<div class="am-modal-hd">欢迎进入[报告]功能！
			<!-- <a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a> -->
		</div>
		<div class="am-modal-bd">
			优满分每月为家长生成孩子的答题报告，通过报告可以让您更加直观的了解孩子学习情况及轨迹变化！
			<form class="am-form">
				<div class="am-form-group">
					<label class="am-checkbox-inline">
						<input type="checkbox" value="option1" id="isSetCookies_1">下次不再显示
					</label>
				</div>
			</form>
		</div>
		<a class="am-btn um-btn-taste um-bg-orange" onclick="setCookies(1);" data-am-modal-close>知道了</a>
	</div>
</div>
<div class="am-modal am-modal-no-btn um-modal-guide" tabindex="-1" id="doc-modal-2">
	<div class="am-modal-dialog">
		<div class="am-modal-hd">欢迎进入[辅导]功能
			<!-- <a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a> -->
		</div>
		<div class="am-modal-bd">
			辅导功能为您列出孩子曾经做错的习题，您可以利用碎片时间，随时随地辅导孩子，直接帮助孩子解决难题！
			<form class="am-form">
				<div class="am-form-group">
					<label class="am-checkbox-inline">
						<input type="checkbox" value="option1" id="isSetCookies_2">下次不再显示
					</label>
				</div>
			</form>
		</div>
		<a class="am-btn um-btn-taste um-bg-orange" onclick="setCookies(2);" data-am-modal-close>知道了</a>
	</div>
</div>


<script type="text/javascript">

	var aOption = {
		subjectId: 1
	},
	monthList = {},
			aCache = [],
			url = '/?m=Index&a=showNewIndex',
			readTutoriaType = <?php echo intval(get('tutoriaType', 2)); ?>;


	$(function () {
		getWongAndFinxed();
		listType(readTutoriaType);
	});


	function listType(type) {
		if (type == 1) {
			getTutoriaMonth(1);
		} else {
			getTutoriaMission(1, 1, null);
		}
	}

	function getTutoriaMonth(page, obj) {
		var tutorialListHtml = '',
				$thisObj = $(obj),
				$attrOnClick = $thisObj.attr('onclick');

		$thisObj.removeAttr('onclick');
		$('#tutorialStyle').removeClass('um-fixed-bg1').addClass('um-fixed-bg2');
		$('#btnGroupMission, .btn-subject').removeClass('am-active');
		$('#btnGroupTime').addClass('am-active');

		//valUrl = '/?m=Statistic&a=enterAnalogAccount&type=2';
		$.ajax({
			url: '/?m=Statistic&a=getMonthTutorial',
			data: {page: page},
			type: 'post',
			success: function (aResult) {
				if (aResult.status == 1) {
					var aData = aResult.data;
					if (!aData || aData.length < 1) {
						tutorialListHtml += '<div class="am-text-center no-data">\
						<span class="um-icon um-icon-moji-fail am-icon-lg"></span>\
						<div class="am-block">没有找到数据T_T，<br>推荐你点击<a href="javascript:;" >功能演示</a>体验</div>\
						<a class="am-btn um-btn-taste am-block" onclick="showDialogConfirm(2)">进入[辅导]功能演示</a>\
					</div>';
					} else {
						for (var i in aData) {
							tutorialListHtml += '<dt class="am-accordion-title" onclick="showlink(\'/?m=Statistic&a=showEsInfo&tutoriaType=1&subjectId=' + aOption.subjectId + '&month=' + aData[i].month + '&count=' + aData[i].es_wrong_count + '\');">\
						<a href="###">\
						  <span class="um-font-gray-dark">' + aData[i].cnMonth + '&nbsp;&nbsp;</span>\
						  <small class="um-font-gray-light">答错次数：' + aData[i].es_wrong_count + '&nbsp;</small>\
						  <small class="um-font-gray-light">已修复：' + aData[i].es_repair_count + '&nbsp;</small>\
						</a>\
					  </dt>';
						}
					}
					$('#tutorialBox').html(tutorialListHtml);

					$thisObj.attr('onclick', $attrOnClick);
				} else {
					alert(aResult.msg);
				}
			}
		});


	}

	function getTutoriaMission(subjectId, page, obj) {
		var tutorialListHtml = '',
				pageHtml = '',
				tempSubjectId = aOption.subjectId,
				$thisObj = $(obj),
				$attrOnClick = $thisObj.attr('onclick');

		$thisObj.removeAttr('onclick');
		$('#btnGroupTime, .btn-subject').removeClass('am-active');
		$('#btnGroupMission').addClass('am-active');
		$('#tutorialStyle').removeClass('um-fixed-bg2').addClass('um-fixed-bg1');
		if (obj != null) {
			$thisObj.addClass('am-active');
		} else {
			$('.btn-subject:first').addClass('am-active');
		}


		if (aOption.subjectId != subjectId) {
			aOption.subjectId = subjectId;
		}
		if (aCache[aOption.subjectId + '-' + page]) {
			$('#tutorialBox').html(aCache[aOption.subjectId + '-' + page]);
			$thisObj.attr('onclick', $attrOnClick);
			return;
		}
		//valUrl = '/?m=Statistic&a=enterAnalogAccount&type=2';
		$.ajax({
			url: '/?m=Statistic&a=getTutorial',
			data: {
				subjectId: aOption.subjectId,
				page: page
			},
			type: 'post',
			success: function (aResult) {
				if (aResult.status == 1) {
					var aData = aResult.data.aMissionList;
					if (!aData){
						tutorialListHtml += '<div class="am-text-center no-data">\
						<span class="um-icon um-icon-moji-fail am-icon-lg"></span>\
						<div class="am-block">没有找到数据T_T，<br>推荐你点击<a href="javascript:;">功能演示</a>体验</div>\
						<a class="am-btn um-btn-taste am-block" onclick="showDialogConfirm(2)">进入[辅导]功能演示</a>\
					</div>';
					} else {
						for (var i in aData) {
							tutorialListHtml += '<dl class="am-accordion-item">\
							<dt href="javascript:;" class="am-accordion-title">\
								<a href="/?m=Statistic&a=showEsInfo&tutoriaType=2&subjectId=' + aOption.subjectId + '&missionId=' + aData[i].id + '&count=' + aData[i].nums + '">\
									<span class="um-font-gray-dark am-block um-class-title">' + aData[i].name + '</span>\
									<small class="um-font-gray-light am-block">待修复：' + aData[i].nums + '&nbsp;&nbsp;&nbsp;已修复：' + aData[i].es_repair_count + '&nbsp;&nbsp;&nbsp;</small>\
								</a>\
							</dt>\
						</dl>';
						}
					}
					if (tempSubjectId != subjectId) {
						$('#tutorialBox').html(tutorialListHtml);
					} else {
						$('#tutorialBox center').remove();
						if ($('#tutorialBox').html().length > 0 && aResult.data.pageCount && readTutoriaType == 2) {
							$(tutorialListHtml).appendTo('#tutorialBox');
						} else {
							$('#tutorialBox').html(tutorialListHtml);
						}

					}
					if (page != aResult.data.pageCount && aResult.data.pageCount) {
						pageHtml += '<center onclick="getTutoriaMission(' + subjectId + ',' + (page + 1) + ');">【点击加载更多】</center>';
					}
					$(pageHtml).appendTo('#tutorialBox');
					$thisObj.attr('onclick', $attrOnClick);
					aCache[aOption.subjectId + '-' + page] = $('#tutorialBox').html();
				} else {
					alert(aResult.msg);
				}
			},
			error: function (aResult) {
				alert(aResult.msg);
			}
		});
	}


	function getWongAndFinxed() {
		$.get(
				'/?m=Statistic&a=getWongAndFinxed',
				function (aResult) {
					if (aResult.status == 1) {
						$('#wong').text(aResult.data.count_wrong);
						$('#waitFinxed').text(aResult.data.count_wrong - aResult.data.count_finxed);
						$('#finxed').text(aResult.data.count_finxed);
					} else {
						alert(aResult.msg);
					}
				}
		);
	}


	Zepto(function ($) {
		//$('#indexAnswerList').hide();
		//$('#indexAnswerList1').hide();
		//首页js开始
		$.post('<?php echo url('m=Statistic&a=ajaxGetMonthInfoDetail'); ?>', {}, function (aResult) {
			var indexData = aResult.data;
			if (indexData.username) {
				$('strong[xid=indexUserName]').html(indexData.username);
			}/* else {
				$('strong[xid=indexUserName]').parent('p').html('您的小孩还没有登录过优满分,请点击体验学生版登录学生版体验或点击家长版模拟体验体验家长版功能');
			}*/
			//$('strong[xid=indexUserName]').html(indexData.username);
			/*if (!aResult.status) {
				//$('#indexAnswerList').hide();
				//$('#indexAnswerList1').show();
			} else {
				//$('#indexAnswerList').show();
				//$('#indexAnswerList1').hide();
			}*/
			//判断是否是多数据如果是则隐藏指引
			/*if (indexData.missionLength > 50) {
				$('#indexFirstShow').hide();
			}*/


//			本月答题情况
			if (indexData.yuwenTotal) {
				$('#indexYuwentotal').html(indexData.yuwenTotal);
			} else {
				$('#indexYuwentotal').html('0');
			}

			if (indexData.shuxueTotal) {
				$('#indexshuxuetotal').html(indexData.shuxueTotal);
			} else {
				$('#indexshuxuetotal').html('0');
			}

			if (indexData.yingyuTotal) {
				$('#indexyingyutotal').html(indexData.yingyuTotal);
			} else {
				$('#indexyingyutotal').html('0');
			}

			if (indexData.allTotal) {
				$('#indexAlltotal').html(indexData.allTotal);
			} else {
				$('#indexAlltotal').html('0');
			}


			//本月正确率
			if (indexData.yuwenzql) {
				$('#indexYuwenzql').html(indexData.yuwenzql + '%');
			} else {
				$('#indexYuwenzql').html('0%');
			}

			if (indexData.matchCorrentl) {
				$('#indexshuxuezql').html(indexData.matchCorrentl + '%');
			} else {
				$('#indexshuxuezql').html('0%');
			}

			if (indexData.englishCorrectl) {
				$('#indexyingyuzql').html(indexData.englishCorrectl + '%');
			} else {
				$('#indexyingyuzql').html('0%');
			}

			if (indexData.totalzql) {
				$('#indexAllzql').html(indexData.totalzql + '%');
			} else {
				$('#indexAllzql').html('0%');
			}

			//错题
			var indexYuwenError = indexData.ywerror ? indexData.ywerror : '0';
			var indexShuxueError = indexData.matchWrong ? indexData.matchWrong : '0';
			var indexYingyuError = indexData.englishWrong ? indexData.englishWrong : '0';
			$('#indexYuwenError').html(indexYuwenError);
			$('#indexShuxueError').html(indexShuxueError);
			$('#indexYingyuError').html(indexYingyuError);
			//改变按钮状态
			if (indexData.ywerror == '0' || !indexData.ywerror) {
				$('#indexYuwenCi').addClass('am-disabled');
			}
			if (indexData.sxerror == '0' || !indexData.matchWrong) {
				$('#indexShuxueCi').addClass('am-disabled');
			}
			if (indexData.yyerror == '0' || !indexData.englishWrong) {
				$('#indexYingyuCi').addClass('am-disabled');
			}

		}, 'json');
		//首页js结束
		$('#clickPageMore').click(function () {
			var page = Number($('#p_page').val()) + 1;
			pages(page);
		});
		function pages(page) {
			//每页显示条数
			var pagesize = 6;
			//总数
			var count = monthList.length - 2;
			//总页数
			var tatolpage = Math.ceil(count / pagesize);
			//上一页
			var limit = ((page - 1) * pagesize) + 2;
			var end = limit + pagesize + 1;
			var html = '';
			for (var i in monthList) {
				if ((i >= limit) && (i < end - 1)) {
					var oMonth = monthList[i];
					if (oMonth.answerTotal != '0') {
						var answerTotal = oMonth.answerTotal;
					} else {
						var answerTotal = '--';
					}
					if (oMonth.correctTotal != '0') {
						var correctTotal = oMonth.correctTotal + '%';
					} else {
						var correctTotal = '--';
					}
					if (oMonth.score != '0') {
						var score = oMonth.score;
						var reStyle = 'um-font-orange';
					} else {
						var score = '--';
						var reStyle = 'um-font-gray';
					}
					var html = '<dt href="javascript:;" onclick="tiaozhuan(this)" class="am-accordion-title" rel="<?php echo url('m=Statistic&a=getUserMonthDetail') ?>&month=' + oMonth.month + '">';
					html += '<a href="javascript:;">';
					html += '<span class="um-font-gray-dark">' + oMonth.cnMonth + '月份&nbsp;&nbsp;</span>';
					html += '<small class="um-font-gray-light">答题数：' + answerTotal + '&nbsp;</small> ';
					html += '<small class="um-font-gray-light">正确率：' + correctTotal + '&nbsp;</small>';
					html += '<span class="' + reStyle + ' am-fr b">' + score + '</span></a></dt>';
					$('#monthTotalList').append(html);
					$('#p_page').val(page);
				}

			}
			//显示加载更多
			if (tatolpage > 1 && page < tatolpage) {
				$('#pageMore').show();
			} else {
				$('#pageMore').hide();
			}
		}
		//月报js处理开始
		$.post("<?php echo url('m=Statistic&a=getUserMonthList'); ?>", {}, function (result) {
			if (result.status != 1) {
				//window.location.href = '<?php echo url('m=Statistic&a=noMonthData'); ?>';
			}
			if (result.data.length == 0) {
				$('#monthList').show();
				$('#reports').hide();
				return;
			} else {
				$('#reports').show();
			}
			//最新一个月数据
			$('#firstMonth').html(result.data[0].cnMonth + '月份数据');
			$('#firstMonthUrl').attr('rel', '<?php echo url('m=Statistic&a=getUserMonthDetail') ?>&month=' + result.data[0].month);

			if (result.data.length > 1) {
				//上一个月数据详细
				$('#twoMonthUrl').attr('rel', '<?php echo url('m=Statistic&a=getUserMonthDetail') ?>&month=' + result.data[1].month);
				$('#twoMonth').html(result.data[1].cnMonth + '月份数据');
				if (result.data[1].score != '0') {
					var ability = result.data[1].score;
				} else {
					var ability = '---';
				}

				if (result.data[1].randing != '0') {
					$('#lrandings').html(result.data[1].randing + '%');
				} else {
					$('#jibairenshu').html("能力值无法计算<a href='/?m=Statistic&a=showProduct&show=Ability' class='um-font-orange '>为什么？</a>");
				}

				if (result.data[1].answerTotal != '0') {
					var answerNum = result.data[1].answerTotal + '题';
				} else {
					var answerNum = '--';
				}
				if (result.data[1].missionLeng != '0') {
					var confirmNum = result.data[1].missionLeng + '次';
				} else {
					var confirmNum = '--';
				}

				if (result.data[1].correctTotal != '0') {
					var correctTotal = result.data[1].correctTotal + '%';
				} else {
					var correctTotal = '--';
				}

				if (result.data[1].avaCore != '0') {
					var avaCore = result.data[1].avaCore + '分';
				} else {
					var avaCore = '--';
				}
				//能力值
				$('#ability').html(ability);
				//答题数
				$('#answerNum').html(answerNum);
				//闯关数
				$('#confirmNum').html(confirmNum);
				//正确率
				$('#correctNum').html(correctTotal);
				//平均分
				$('#averageNum').html(avaCore);
				$('#lastMonthBox').show();
			}

			monthList = result.data;
			pages(1);
			//设定数据小于多少就显示数据不足
			if (result.data.length < 5) {
				var htmlx = '<div class="am-text-center no-data" id="reportNodata">';
				htmlx += '<span class="um-icon um-icon-moji-fail am-icon-lg"></span>';
				htmlx += '没有更多数据了，<br>推荐你点击<a href="javascript:;" onclick="showDialogConfirm(1)">功能演示</a>体验</div>';
				$('#reports').append(htmlx);
				//dialogConfirm();
			}
		}, 'json');
		//月报js结束

	});

	function tiaozhuan(obj) {
		var hashNmae = $(obj).parents('[id^="mobile-"]').attr('id').split('-')[1];
		window.location.href = $(obj).attr('rel') + '#' + hashNmae;
	}
	function noShowAnalogAccount(){
		Zepto.fn.cookie('noShowAnalogAccount', '1', { expires: 3600 * 24 * 365 });
		$('#indexFirstShow').hide();
	}

</script>
<!-- end am-page -->

