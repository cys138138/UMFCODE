<!-- report -->
<!-- ============================================================================= -->
<div class="am-g um-maxwidth simulate">
  <section class="um-mod am-cf">
      <div class="col-sm-12">
        <div class="um-mod-hd am-cf">
          <span class="am-fl"><?php echo $detailData['cnMonth']?>月份做题概况</span>
          <small class="am-fr um-tip" onclick="showlink('/?m=Statistic&a=showProduct&show=Ability')"><span class="am-icon-question-circle"></span >了解能力值</small>
        </div>


		<div class="um-chart am-text-center">
			<canvas id="scoreChart" width="250" height="250"></canvas>
			<div class="info">
				<div class="num">
					<?php
					if($detailData['score'] == '0' || $detailData['month'] == date('Ym')){
						echo '---';
					}else{
						echo $detailData['score'];
					}
					?>
				</div>
				<div class="text">能力值</div>
			</div>
		</div>
		  <script>
			var score = <?php echo $detailData['score']; ?>,
				data = [];
			if(score){
				data = [
					{
					  value : parseInt(score),
					  color : "#189381"
					},
					{
					  value : 100 -  parseInt(score),
					  color : "#1fbba6"
					}
				  ];
			}else{
				data = [
					{
					  value: 100,
					  color:"#999999"
					}
				  ];
			}

			//Get the context of the canvas element we want to select
			var ctx = document.getElementById("scoreChart").getContext("2d");
			var myNewChart = new Chart(ctx).Doughnut(data,{
			  animationEasing : "ease-out",
			  animationSteps : 80,
			});
		  </script>

		<?php if($detailData['month'] == date('Ym')){?>
			<div class="um-user-info am-center am-cf">
				<span class="um-icon um-icon-moji-fail am-icon-lg um-user-info-img am-fl"></span>
				<div class="um-user-info-text">本月还没有结束，本月的能力值要下月才能计算和显示</div>
			</div>
		<?php }elseif($detailData['randing']){?>
          <div class="um-user-info am-center am-cf">
            <!--img alt="" src="http://placehold.it/64x64/0eafff/ffffff.png" class="um-user-info-img am-fl"/-->
            <div class="um-user-info-text" style="text-align:center;">击败了全国<strong><?php echo $detailData['randing'];?>%</strong>学生，<br>点击<em onclick="showlink('/?m=Statistic&a=showRanking&month=<?php echo $detailData['month']; ?>')">排行榜</em>查看孩子的排名</div>
          </div>
		  <?php }else{?>
			<div class="um-user-info am-center am-cf">
			  <span class="um-icon um-icon-moji-fail am-icon-lg um-user-info-img am-fl"></span>
			  <div class="um-user-info-text">你的数据太少，无法计算能力值<br>推荐你点击<em>功能演示</em>进行体验</div>
			</div>
		  <?php }?>
        <table class="am-table am-table-bd um-table">
            <thead>
                <tr>
                    <th class="um-table-green"><span class="am-icon-tag"></span></th>
                    <th class="um-table-yellow">语文</th>
                    <th class="um-table-yellow">数学</th>
                    <th class="um-table-yellow">英语</th>
                    <th class="um-table-yellow">全部</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="um-table-green">答题数</td>
                    <td><?php echo $detailData['yuwenTotal'];?></td>
                    <td><?php echo $detailData['shuxueTotal'];?></td>
                    <td><?php echo $detailData['yingyuTotal'];?></td>
                    <td><?php echo $detailData['allTotal'];?></td>
                </tr>
                <tr>
                    <td class="um-table-green">正确率</td>
                    <td><?php echo $detailData['yuwenzql'];?>%</td>
                    <td><?php echo $detailData['matchCorrentl'];?>%</td>
                    <td><?php echo $detailData['englishCorrectl'];?>%</td>
                    <td><?php echo $detailData['totalzql'];?>%</td>
                </tr>
            </tbody>
        </table>
      </div>
  </section>
<?php if(!empty($detailData['statistics']['match'])){?>
  <section class="um-mod am-cf">
    <div class="col-sm-12">

      <div class="um-mod-hd am-cf">
        <span class="am-fl"><?php echo $detailData['cnMonth'];?>月份比赛信息</span>
      </div>

      <div class="um-match-info am-cf">
        <span class="um-icon um-icon-1 am-icon-lg am-fl"></span>
        <div class="um-match-list">
          <ul>
			<?php foreach($detailData['statistics']['match'] as $v){?>
			  <li>
				<div>在<b><?php echo $v['name'];?></b>中</div>
				<div>拿到了第<strong><?php echo $v['ranking'];?></strong>名</div>
			  </li>
			<?php }?>
          </ul>
        </div>
      </div>

    </div>
  </section>
<?php }?>

  <section class="um-mod am-cf">
    <div class="col-sm-12">

      <div class="um-mod-hd am-cf">
        <span class="am-fl"><?php echo $detailData['cnMonth']?>月份闯关信息</span>
      </div>

      <div class="um-excute-info am-cf">
        <div class="um-excute-hd">
          闯关数：<strong><?php
		  $aMissionLista = empty($detailData['statistics']['mission']) ? $aMissionLista='0' : count($aMissionLista=$detailData['statistics']['mission']);
		  echo $aMissionLista;
		  ?>
		  </strong>平均分：<strong><?php $detailData['avaCore']=isset($detailData['avaCore']) ? $detailData['avaCore'] : 0; echo $detailData['avaCore'];?></strong>
        </div>
        <div class="um-excute-bd">
          <ul id='pagelist'>
          </ul>

        </div>
        <div class="um-excute-ft am-text-center">
			<ul class="am-pagination am-inline-block" id="pagenation">
            <li><a href="javascript:;" type='pre'><span class="am-icon-angle-double-left"></span></a></li>
            <li><span id="pagenation"><i id='p_page'>1</i>/<i id='p_tatolData'>20</i></span></li>
            <li ><a href="javascript:;" type='next'><span class="am-icon-angle-double-right"></span></a></li>
          </ul>
        </div>
      </div>

    </div>
  </section>

  <section class="um-mod um-orange am-cf">
      <div class="col-sm-12 um-bd">
         <div class="um-mod-hd am-cf">
            <span class="am-fl"><?php echo $detailData['cnMonth']?>月份错题统计</span>
          </div>
        <ul class="am-list am-list-static">
          <li class="am-cf">语文 : <strong><?php echo $detailData['ywerror'];?></strong>次
            <button type="button" class="am-btn um-btn-orange am-fr am-btn-sm <?php if($detailData['ywerror'] =='0') echo 'am-disabled';?>" onclick="showlink('/?m=Index&a=showNewIndex#tutorial')">进入辅导</button>
          </li>
          <li>数学 : <strong><?php echo $detailData['matchWrong'];?></strong>次
            <button type="button" class="am-btn um-btn-orange am-fr am-btn-sm <?php if($detailData['matchWrong'] =='0') echo 'am-disabled';?>" onclick="showlink('/?m=Index&a=showNewIndex#tutorial')">进入辅导</button>
          </li>
          <li>英语 : <strong><?php echo $detailData['englishWrong'];?></strong>次<button type="button" class="am-btn um-btn-orange am-fr am-btn-sm <?php if($detailData['englishWrong'] =='0') echo 'am-disabled';?>" onclick="showlink('/?m=Index&a=showNewIndex#tutorial')">进入辅导</button></li>
        </ul>
      </div>
    </section>

</div>

<!-- end am-page -->
<script>
Zepto(function($) {
	var data=eval(<?php echo $detailData["missionList"]?>);
	$('#pagenation a').click(function(){
		if(data.length < 1){
				var html='<li><span class="um-excute-scroe am-disabled">0</span>暂时没有闯关信息</li>';
				$('#pagenation').html("");
				$('#pagelist').html(html);
				return;
			}
		var type=$(this).attr('type');
		//当前页数
		var page=Number($('#p_page').html());
		//每页显示条数
		var pagesize = 10;
		//总数
		var count=data.length;
		//总页数
		var tatolpage=Math.ceil(count/pagesize);

		//上一页
		if(type == 'pre'){
			if(page > 1){
				page=page-1;
			}else{
				page=1;
			}
		}else{
			if(page >= tatolpage){
				page=tatolpage;
				return;
			}else{
				page=page+1;
			}
		}
		var limit= (page - 1)* pagesize;
		var end=limit+pagesize+1;
		var html='';
		for(var i in data){
				if((i >= limit) && (i < end - 1)){
					html += '<li><span class="um-excute-scroe ';
					if(data[i].score == '0') {
						html+='am-disabled'
					}
					if(data[i].score == '0') {
						html+='">--</span>暂时没有闯关信息</li>';
					} else {
						html+='">'+data[i].score;
						html += '</span>'+data[i].name+'</li>';
					}

				}
			}

			$('#p_page').html(page);
			$('#p_tatolData').html(tatolpage);
			$('#pagelist').html(html);
	});
	$('a[type=pre]').click();
});

var url = '/?m=Index&a=showNewIndex#report';
</script>