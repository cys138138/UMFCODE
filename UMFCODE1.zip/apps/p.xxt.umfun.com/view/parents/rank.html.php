<!-- rank -->
<!-- ============================================================================= -->
<script src="<?php echo $GLOBALS['RESOURCE']['library']; ?>"></script>
<div class="am-g am-page am-cf simulate">
	<div id="doc-dropdown-justify">
		<div class="am-dropdown am-block" data-am-dropdown="{justify: '#doc-dropdown-justify'}">
		  <div class="am-text-center am-dropdown-toggle um-dropdown-title"><?php echo $selectYear ?>年<?php echo $cnMonth ?>月排行<span class="am-icon-caret-down"></span></div>
		  <div class="am-dropdown-content">
			<ul class="um-dropdown-list">
				<!-- 默认三个 -->
				 <?php foreach($aLastThreeMonth as $aMonth){ ?>
					 <li class="col-sm-4"><a href="javascript:;" <?php if($aMonth['is_active']){ ?>class="am-active"<?php }?> onclick="showlink('/?m=Statistic&a=showRanking&month=<?php echo $aMonth['year_month']; ?>')"><?php echo $aMonth['month']; ?>月排行</a></li>
				<?php } ?>
			 </ul>

		  </div>
		</div>
	</div>

  <div data-um-widget="tabs" class="am-tabs am-tabs-default m0">
	<ul class="am-tabs-nav am-cf um-tabs-nav">
	  <li class="am-active">
		<a xid="data-tab-panel-0" onclick="changeTypes(1);">本市</a>
	  </li>
	  <li class="">
		<a xid="data-tab-panel-1" onclick="changeTypes(2);">本校</a>
	  </li>
	  <li class="">
		<a xid="data-tab-panel-2" onclick="changeTypes(3);">本班</a>
	  </li>
	</ul>

	<div class="um-rank-info" id="babyRank"></div>

	<div class="am-tabs-bd">
	  <div data-tab-panel-0 class="am-tab-panel am-active p0" id="rankList_1">
	  </div>

	  <div data-tab-panel-1 class="am-tab-panel p0" id="rankList_2">
	  </div>

	  <div data-tab-panel-2 class="am-tab-panel p0" id="rankList_3">
	  </div>


	</div>
  </div>

</div>
<!-- end am-page -->
<script type="text/javascript">
var noImg = '<?php echo $GLOBALS['RESOURCE']['profile_error']; ?>',
	systemResourceUrl = '<?php echo SYSTEM_RESOURCE_URL; ?>',
	url = '/?m=Index&a=showNewIndex';


var month = <?php echo $month; ?>,types = 1;
$(function(){
	selectRankList();

	Zepto('.am-tabs-nav').find('li').on('click',function(){
		var xid = $(this).find('a').attr('xid');
		Zepto('.am-tabs-nav li').removeClass('am-active');
		Zepto(this).addClass('am-active')
		Zepto('.am-tab-panel').removeClass('am-active');
		Zepto('['+xid+']').addClass('am-active');
	})
});

	function changeTypes(type){
		types = type;
		selectRankList();
	}

	function h(o){
		var $o = $(o);

		var imgUrl = $o.attr('real');
		$('<img src="' + imgUrl + '">').appendTo('body').hide().on('load',function(){
			$o.attr('onload', '').attr('src', imgUrl).attr('real', '');
			$(this).remove();
		});
	}

	function selectRankList(){
		var aRankListHtml = '';
		$.ajax({
			type : 'post',
			url : '/?m=Statistic&a=getRankList',
			data : {type : types, month : month},
			success : function(aResult){
				if(aResult.status == 1){
					var aData = aResult.data;
					if(aData.length == 0){
						aRankListHtml += '<div class="am-text-center no-data">\
							<span class="um-icon um-icon-moji-fail am-icon-lg"></span>\
							<div class="am-block">找不到数据了，<br>推荐你使用<a>功能演示</a>体验</div>\
							<a class="am-btn um-btn-taste am-block" onclick="showDialogConfirm(0)">进入功能演示</a>\
						</div>';
						$('#rankList_' + types).html(aRankListHtml);
						return;
					}

					aData = aData.rank_list;
					aRankListHtml += '<table class="am-table am-table-bd am-table-striped um-rank-table">\
						<thead>\
							<tr>\
								<th>排名</th>\
								<th>能力值</th>\
								<th>学生信息</th>\
							</tr>\
						</thead>\
						<tbody>';
					for(var i in aData){
						aRankListHtml += '<tr>\
							<td>' + ( parseInt(i) + 1) + '</td>\
							<td>' + aData[i].score + '</td>\
							<td>\
								<img alt="" src="' + noImg + '" real="' + systemResourceUrl + aData[i].profile + '" onload="h(this);"/>\
								<div class="um-studen-info">\
									<div class="name">' + aData[i].name + '</div>\
									<div class="school">' + aData[i].school_name + '</div>\
							  </div>\
							</td>\
						</tr>';
					}
					aRankListHtml += '</tbody>\
					</table>';
					if(aResult.data.my_child.beat){
						$('#babyRank').html(aResult.data.my_child.name + '同学已在' + aResult.data.my_child.rankType + '超过<strong>' + aResult.data.my_child.beat  + '%</strong>的同级学生');
					}else{
						$('#babyRank').html('');
					}
					aRankListHtml += '<div style="height:40px"></div>';
					$('#rankList_' + types).html(aRankListHtml);
				}else{
					alert(aResult.msg);
				}
			}
		});

	}


</script>