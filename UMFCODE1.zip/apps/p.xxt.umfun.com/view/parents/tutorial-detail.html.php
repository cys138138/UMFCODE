<!-- report -->
<!-- ============================================================================= -->
<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['style_es']; ?>" />
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['es']; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['js_mathjax']; ?>"></script>
<script src="<?php echo $GLOBALS['RESOURCE']['zepto.cookie.min']; ?>"></script>
<style type="text/css" media="screen">
	.right-answer {display: none;}
	input[type=radio], input[type=checkbox] {display: none;}
	input:not([type=radio]):not([type=checkbox]) {border-top: none;border-left: none;border-right: none;border-bottom: 1px solid;}
</style>
<div class="am-g um-maxwidth am-page simulate">
  <section class="um-excute-content am-cf">
	<div class="col-sm-12">
	  <div class="execute-warp por">
		<div class="execute-warp-count"><span id="fixedCount">0</span>/<b id="wrongEsCount">0</b></div>

		  <div id="wrapEs" class="wrapEs wrapEsQuestion choose topic"> </div>

	  </div>

	  <!-- 清楚浮动 -->
	  <div class="am-cf"></div>
	  <!-- 答案 -->
	  <div class="right-answer am-cf" id="answer"></div>
	</div>

  </section>

</div>

<!-- end am-page -->

<!-- um-excute-options -->
<div class="um-excute-options" id="umExcuteOptions">
  <button type="button" class="am-btn um-btn-answer am-btn-xs am-fl" onclick="$('#answer').slideDown('normal');">查看答案</button>
  <button type="button" class="am-btn um-btn-next am-btn-xs am-fr" id="repairEsButton" onclick="repairEs()"><!---doNext();--->已掌握</button>
  <button type="button" class="am-btn um-btn-skip am-btn-xs am-fr" onclick="resetEs(<?php echo intval(get('tutoriaType')); ?>)">跳过</button>

</div>

<!-- modal -->

<div class="am-modal am-modal-no-btn um-modal-guide" tabindex="-1" id="doc-modal-3">
  <div class="am-modal-dialog">
	<div class="am-modal-hd">开始辅导啦
	  <!-- <a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a> -->
	</div>
	<div class="am-modal-bd">
	  请你的孩子来答一答，答对了可点击[已掌握]，答错了就给孩子辅导一下吧！核对答案请点击[查看答案]。
	  <form class="am-form">
		   <div class="am-form-group">
			<label class="am-checkbox-inline">
			  <input type="checkbox" value="option1" id="isSetCookies_3">下次不再显示
			</label>
		  </div>
	  </form>
	</div>
	<a class="am-btn um-btn-taste um-bg-orange" onclick="setCookies(3);" data-am-modal-close>知道了</a>
  </div>
</div>
<input type="hidden" id="tutorialDialog_3" data-am-modal="{target: '#doc-modal-3'}"/>

<script type="text/javascript">
	var $oQuestion = null,
		page = 0,
		aSearchCondition = {
			subject : <?php echo intval(get('subjectId', 1));?>,
			mission : <?php echo intval(get('missionId', 0));?>,
			month : <?php echo intval(get('month', 0));?>
		},
		wrongEsCount = <?php echo intval(get('count')); ?>,
		fixedWrongEsCount = 0,
		loadEsType = <?php echo intval(get('tutoriaType')); ?>,
		url = '/?m=Index&a=showNewIndex&tutoriaType=' + loadEsType + '#tutorial',
		currentEsId = 0;

Zepto(function($){

	resetEs(loadEsType);
	$('#wrongEsCount').html(wrongEsCount);
	showDialog(3);
});

function resetEs(type){
	if(type == 1){
		readMonthEsInfo();
	}else{
		researchEs();
	}
}

function repairEs(){
	$("#repairEsButton").attr('disabled', 'disabled');
	//alert(currentEsId);
	$.ajax({
		type : 'post',
		url : '/?m=Statistic&a=repairEs'
		,data : {
			esId : currentEsId
		}
		,success : function(aResult){
			if(aResult.status != 1){
				alert(aResult.msg);
				return;
			}
			wrongEsCount--;
			if(wrongEsCount == 0){
				alert('您已修复该目录下所有的题目啦');
				showlink('/?m=Index&a=showNewIndex#tutorial');
				return;
			}
			$('#wrongEsCount').html(wrongEsCount);
			fixedWrongEsCount--;
			if(loadEsType == 1){
				page--;
				readMonthEsInfo();
			}else{
				page--;
				researchEs();
			}
		}
	});
}

/**
 * 重新搜索题目
 * @returns {undefined}
 */
function researchEs(){
	$('#answer').hide();
	$.ajax({
		type : 'post',
		url : '/?m=Statistic&a=researchEs'
		,data : {
			subject : aSearchCondition.subject
			,page : page + 1
			,mission : aSearchCondition.mission
		}
		,success : function(aResult){
			if(aResult.status != 1){
				alert(aResult.msg);
				return;
			}
			currentEsId = aResult.data.es_id;
			buildEs(aResult.data);
			fixedWrongEsCount++;
			page++;
			if(page == wrongEsCount){
				page = 0;
			}
			if(fixedWrongEsCount > wrongEsCount){
				if(wrongEsCount > 3){
					alert('您已经查看了一轮，我们重新开始查看！');
				}
				fixedWrongEsCount = 1;
				$('#fixedCount').text(fixedWrongEsCount);
				return;
			}
			$('#fixedCount').text(fixedWrongEsCount);
			location.hash = 'cont';
			$("#repairEsButton").attr('disabled', false);
		}
	});
}

function readMonthEsInfo(){
	$('#answer').hide();
	$.ajax({
		type : 'post',
		url : '/?m=Statistic&a=getMonthWongLisyByMonth'
		,data : {
			subject : aSearchCondition.subject,
			page : page + 1,
			month : aSearchCondition.month
		}
		,success : function(aResult){
			if(aResult.status != 1){
				alert(aResult.msg);
				return;
			}
			currentEsId = aResult.data.aEsInfo.es_id;
			buildEs(aResult.data.aEsInfo);
			wrongEsCount = aResult.data.esCount;
			$('#wrongEsCount').html(wrongEsCount);
			fixedWrongEsCount++;
			page++;
			if(page == wrongEsCount){
				page = 0;
			}
			if(fixedWrongEsCount > wrongEsCount){
				if(wrongEsCount > 3){
					alert('您已经查看了一轮，我们重新开始查看！');
				}
				fixedWrongEsCount = 1;
				$('#fixedCount').text(fixedWrongEsCount);
				return;
			}
			$('#fixedCount').text(fixedWrongEsCount);
			$("#repairEsButton").attr('disabled', false);
		}
	})
}

/**
 * 请求做下一题
 */
function doNext(){
	$('#answer').hide();
	var mAnswer = $oQuestion.buildAnswer();
	if(ES.isEmptyAnswer(mAnswer)){
		alert('请先作答');
		return;
	}
	return false;
	$.ajax({
		type : 'post',
		url : '/?m=Statistic&a=markingFixEs'
		,data : {
			wrong_id : $oQuestion.data('wrong_id')
			,answer : mAnswer.answer
			,page : page + 1
			,subject : aSearchCondition.subject
			,mission : aSearchCondition.mission
		}
		,success : function(aResult){
			if(aResult.status != 1){
				alert(aResult.msg);
				return;
			}
			page++;
			if(aResult.data.is_pass){
				fixedWrongEsCount++;
				if(fixedWrongEsCount == wrongEsCount){
					alert('您已经查看了一轮，我们重新开始查看！');
					fixedWrongEsCount = 1;
					page = 0;
					$('#fixedCount').text(fixedWrongEsCount);
					return;
				}else{
					alert('恭喜你答对了，消灭一条错题！');
					$('#fixedCount').text(fixedWrongEsCount);
				}
			}else{
				alert('答错了，加油哦！');
			}
		}
	});
}

//显示题目
function buildEs(aEs){
	$oQuestion = ES.buildQuestion(aEs);
	$oQuestion.data('wrong_id', aEs.wrong_id);
	$('#wrapEs').empty().append($oQuestion);
	var answerHtml = buildAnswerHtml(aEs.type_id, aEs);

	$('#answer').html('答案是【' + answerHtml + '】');

}
function buildAnswerHtml(type, aEs){
	var answerHtml = '',
		esItemIndex = aEs.index || '',
		answerJson = eval("(" + aEs.content_json + ")"),
		answer = answerJson.answer,
		funAnswerType_1 = function(str){
			if(str == 0){
				return 'A';
			}else if(str == 1){
				return 'B';
			}else if(str == 2){
				return 'C';
			}else if(str == 3){
				return 'D';
			}else if(str == 4){
				return 'E';
			}else if(str == 5){
				return 'F';
			}
		};

	if(type == 1){
		answerHtml = $('#esAnswerIndex' + aEs.id + answer).attr('data-index');
	}else if(type == 2){
		//多选题
		for(var i in answer){
			answerHtml += String.fromCharCode(65 + parseInt(answer[i])) + ', ';
		}
	}else if(type == 3){
		answerHtml = answer == 1 ? '是(正确)' : '否(错误)';
	}else if(type == 4 || type == 5){
		//填空题 || 选词(项)填空题
		for(var i in answer){
			answerHtml += '<span class="blankAnswer"> 第' + (parseInt(i) + 1) + '空:' + answerJson.answer[i] + ' </span>';
		}
	}else if(type == 6 || type == 7){
		for(var i in answer){
			answerHtml += '<div class="answerItem"><span>第' + (parseInt(answer[i].index) + 1) + '小题：</span>' + buildAnswerHtml(answer[i].type, {id : aEs.id, answer_last : answer[i].answer, content_json : aEs.content, index : answer[i].index}) + '</div>';
		}
	}
	return answerHtml;
}


</script>