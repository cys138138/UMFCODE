<!-- report -->
<!-- ============================================================================= -->

<div class="am-g am-page simulate" style="background:#fff">
  <section class="am-cf" style="margin-top:1em">
    <img alt="" src="<?php echo $GLOBALS['RESOURCE']['m_new_parents_no_data_bg']; ?>" />
  </section>
  <section class="am-accordion am-accordion-gapped m0 mt0">

    <div class="am-text-center no-data">
        <div class="am-block">没有更多数据了，<br>推荐你点击<a href="###">功能演示</a>体验</div>
        <a class="am-btn um-btn-taste am-block" data-alert="report">进入[报告]功能演示</a>
        <div class="am-block">您的孩子还没有在优满分答题，<br>请他在<a href="###" onclick="showlink('/?m=Statistic&a=showProduct&show=students')">优满分学生版</a>答题即可查看数据</div>
    </div>

  </section>

</div>

<!-- end am-page -->
