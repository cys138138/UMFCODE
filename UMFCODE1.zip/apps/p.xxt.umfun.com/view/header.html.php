<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">
	<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['m_style_parent']; ?>">
	<script type="text/javascript" src="<?php echo $GLOBALS['RESOURCE']['jquery2']; ?>"></script>
	<script src="<?php echo $GLOBALS['RESOURCE']['m_zepto']; ?>"></script>
	<script src="<?php echo $GLOBALS['RESOURCE']['m_global_parent_js']; ?>"></script>
	<script src="<?php echo $GLOBALS['RESOURCE']['m_xxt_global']; ?>"></script>
	<script src="<?php echo $GLOBALS['RESOURCE']['m_global_js']; ?>"></script>
	<title><?php echo strip_tags($title); ?></title>
</head>
<body>
<script>
	var DEFAULT_IMG = '<?php echo $GLOBALS['RESOURCE']['image_error']; ?>';
</script>
