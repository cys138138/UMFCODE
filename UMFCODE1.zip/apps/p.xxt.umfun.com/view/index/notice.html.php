<div id="parentsIntro" class="por">
	<div class="header-home" id="headerHome">
		<div class="logo">
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_logo']; ?>">
		</div>
	</div>
	<div class="content-intro" id="contentIntro">
		<div class="intro-top">
			<span>您的孩子<em><?php echo $childrenName; ?></em>还未开通使用<em>优满分</em>，</span>
<span>您暂时无法查看到您的孩子的<em>学习战绩</em>！</span>
		</div>
		<div class="intro-middle">
<p><span>点击 <em style="color:#fe8310;cursor:pointer;" onclick="goRegister(this);">马上注册</em>，帮您的孩子开通账号，免费赠送一个月价值50元的钻石会员。。。</span></p>
			<p>
开通后，您可以随时随地看到孩子的每一
次进步和努力！</p>
<div class="intro-links">
	<a href="###">&gt;&gt;<em>总战绩</em>查看</a>
	<a href="###">&gt;&gt;<em>每月战绩</em>查看</a>
	<a href="###">&gt;&gt;<em>每章节薄弱点</em>分析</a>
</div>
		</div>
		<div class="intro-bottom">
			<p><i class="icon icon-tip"></i>优满分专注于为中小学生提供游戏化的学习方式，
旨在提高学生学习兴趣，同时通过云端数据记录学习轨
迹，提供个性化的数据分析，并引导孩子主动修复薄弱
环节！</p>
		</div>
	</div>
</div>
<script type="text/javascript">
	function goRegister(o){
		$(o).html('注册中...');
		$(o).removeAttr('onclick');
		ajax({
			url: '<?php echo url('m=Index&a=doXxtAccountRegister'); ?>',
			data: {
				cs: '<?php echo $cs; ?>'
			},
			success: function(oResult){
				if(oResult.status == 1){
					location.href = oResult.data;
				}else{
					alert(oResult.msg);
					$(o).html('马上注册');
					$(o).attr('onclick', 'goRegister(this);');
				}
			}
		});
	}
</script>