<style type="text/css">
/*2014教师节*/
.active-teacher-s{
	position: absolute;
	z-index: 999;
	right: 15px;
	top: 20%;
}

.active-teacher-s img{
	max-width: 100%;
	width:auto;
}

.active-teacher-b{
	display: none;
	position: absolute;
	z-index: 1001;
	right: 50%;
	margin-right: -142px;
	top: 35%;
}

.active-teacher-b img{
	max-width: 100%;
	width:auto;
}

.active-b-close{
	display: block;
	width: 76px;
	height: 76px;
	position: absolute;
	z-index: 1002;
	top: 0;
	right: 0;
}

</style>
<div id="parentsHome" class="por">
	<div class="header-home" id="headerHome">
		<div class="logo">
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_logo']; ?>">
		</div>
	</div>
	<div class="content-home" id="contentHome">
		<div class="home-img">
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_home_img']; ?>">
		</div>
		<div class="home-btn-group">
			<a id="educationInformation" onclick="location.href='<?php echo url('m=Index&a=educationInformation'); ?>';" class="home-btn home-btn-lh">教育资讯</a>
			<a href="javascript:;" class="home-btn" onclick="showGrade('totalScore');">总战绩</a>
			<a href="javascript:;" class="home-btn" onclick="showGrade('monthScore');">月战绩</a>
			<a href="javascript:;" class="home-btn" onclick="showGrade('detailScore');">详细战绩</a>
			<a href="javascript:;" class="home-btn" onclick="location.href='<?php echo url('m=Index&a=loginChildren', '', APP_LOGIN); ?>';">切换到学生账号</a>
			<a href="javascript:;" onclick="location.href='<?php echo url('m=Index&a=parentIntro'); ?>';" class="t-link">浏览UMFUN的介绍</a>
			<br>
			<br>
			<br>
		</div>
	</div>
</div>

<div class="active-teacher-s">
	<a href="##" onclick="jump();"><img src="<?php echo $GLOBALS['RESOURCE']['active-s']; ?>" alt=""></a>
</div>


<script type="text/javascript">
	function showGrade(){
		alert('优满分可以帮助家长随时随地地观察孩子的学习情况和详细数据！\n\
系统还没有检测到您孩子的学习数据，您可以引导孩子登录优满分应用开启学习之旅！');
	}

	function jump(){
		location.href = '<?php echo url('m=Activity&a=showMission', '', APP_XXT);?>';
	}

	// function activeTeacher(){
	// 	$('.active-teacher-s').click(function(){
	// 		$('.active-teacher-b').fadeIn('fast');
	// 		$(this).fadeOut('fast');
	// 	});
	// 	$('.active-b-close').click(function(){
	// 		$('.active-teacher-b').fadeOut('fast');
	// 		$('.active-teacher-s').fadeIn();
	// 	});
	// }

	$(function(){
		// activeTeacher();
	});
</script>