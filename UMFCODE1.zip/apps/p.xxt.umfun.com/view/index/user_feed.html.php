<!-- @userFeed
==================================== -->
<!--div id="userFeed" class="por">
	<div class="common-header plr">
		<a href="/"><i class="icon-back"></i></a>
		<h2>意见反馈</h2>
	</div>
	<div class="common-content plr">
		<p class="user-feed-p">请写下您对我们系统的意见和建议,有助于我们更加完善系统，为您提供更贴心的服务。</p>

	<div class="user-feed-txt">
		<textarea class="user-feed-ta" name="description" id="description" cols="30" rows="10"> </textarea>
		<div class="user-feed-count" id="countLength">-150</div>
	</div>
	<div class="tc"><input type="submit" value="确定" id="submit" class="common-btn"></div>
	</div>
</div-->
<div class="am-g am-page am-cf">
  <div class="col-sm-12">
    <h3 class="am-text-center am-margin-top-sm">意见反馈</h3>
    <p class="am-text-sm am-text-center">请写下您对我们系统的意见和建议,有助于我们更加完善系统，为您提供更贴心的服务。</p>
    <form class="am-form">
      <div class="am-form-group am-form-icon">
        <textarea class="" rows="5" id="description"></textarea>
        <div class="um-user-count" id="countLength">-150</div>
      </div>
		<div class="contact col-sm-12" style="margin-bottom: 20px;height: 30px;">
			<div class="col-sm-12">
				<div class="col-sm-3" style="padding:0px;">联系方式:</div>
				<div class="col-sm-9"><input type="text" id="contact" style="height: 30px;" name="contact" placeholder="手机号码/邮箱/QQ号码"/></div>				
			</div>
		</div>
      <div class="am-text-center">
          <a class="am-btn um-btn-taste am-block" id="submit">提交</a>
      </div>
    </form>
  </div>
</div>
<style type="text/css">
.am-text-center {
    text-align: left!important;
}
</style>
<script type="text/javascript">
	$(function(){
		$('#description').on('input propertychange', function() {
			var $oFontHtml = $('#countLength'),
				$this = $(this),
				fontCount = 150 - $this.val().length;
			if(fontCount < 1){
				$oFontHtml.html('不能再写了');
				$this.val($this.val().substr(0, 150));
				return false;
			}
			$oFontHtml.html('-' + fontCount);
		});

		$('#submit').on('click', function(){
			var description = $('#description').val().replace(/(^\s*)|(\s*$)/g, '');
			if(description.length < 5){
				alert('请您详细描述您的问题，这样有助于我们提供更好的服务');
				$('#description').focus();
				return;
			}
			var contact = $('#contact').val();
			//正则判断是否符合联系人格式
			var pattern = /(^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$)|(^1\d{10}$)|([1-9][0-9]{4,})/;
			if(contact != ''){
				if(!pattern.test(contact)){
					$('#contact').val('').focus();
					alert('请填入正确的联系方式格式');
					return;
				}				
			}
			$.ajax({
				url : '/?m=Statistic&a=feedback',
				type : 'post',
				data : {
					feedbackType : '和教育家长',
					description : description,
					userName : '和教育家长',
					phone : '13800138000',
					contact : contact
				},
				success : function(aResult){
					if(aResult.status == 1){
						$('#description').val('');
						$('#contact').val('');
						$('#countLength').html('-150');
						alert('感谢您的反馈，我们将立即跟进');
					}else{
						alert(aResult.msg);
					}
				}
			});
		});
	})

</script>