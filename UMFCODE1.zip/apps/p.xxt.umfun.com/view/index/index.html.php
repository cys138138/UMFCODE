<style type="text/css">
/*2014教师节*/
.active-teacher-s{
	position: absolute;
	z-index: 999;
	right: 15px;
	top: 20%;
}

.active-teacher-s img{
	max-width: 100%;
	width:auto;
}

.active-teacher-b{
	display: none;
	position: absolute;
	z-index: 1001;
	right: 50%;
	margin-right: -142px;
	top: 35%;
}

.active-teacher-b img{
	max-width: 100%;
	width:auto;
}

.active-b-close{
	display: block;
	width: 76px;
	height: 76px;
	position: absolute;
	z-index: 1002;
	top: 0;
	right: 0;
}

</style>
<div id="parentsHome" class="por">
	<div class="header-home" id="headerHome">
		<div class="logo">
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_logo']; ?>">
		</div>
	</div>
	<div class="content-home" id="contentHome">
		<div class="home-img">
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_home_img']; ?>">
		</div>
		<div class="home-btn-group">
			<a id="educationInformation" onclick="location.href='<?php echo url('m=Index&a=educationInformation'); ?>';" class="home-btn home-btn-lh">教育资讯</a>
			<a href="javascript:;" class="home-btn" onclick="showGrade('totalScore');">总战绩</a>
			<a href="javascript:;" class="home-btn" onclick="showGrade('monthScore');">月战绩</a>
			<a href="javascript:;" class="home-btn" onclick="showGrade('detailScore');">详细战绩</a>
			<a href="javascript:;" class="home-btn" onclick="location.href='<?php echo url('m=Index&a=loginChildren', '', APP_LOGIN); ?>';">切换到学生账号</a>
			<a href="javascript:;" onclick="location.href='<?php echo url('m=Index&a=parentIntro'); ?>';" class="t-link">浏览UMFUN的介绍</a>
			<br>
			<br>
			<br>
		</div>
	</div>
</div>

<!--all-->
<div id="totalScore" class="por">
	<div class="common-header plr fixed t0">
		<i class="icon-back" onclick="showHome('totalScore');"></i>
		<h2><?php echo $aUserInfo['name']; ?>的总战绩</h2>
	</div>
	<div class="common-content parents-pt" id="commonContent">

		<div class="total-info plr">
			<div class="total-info-img">
				<img alt="" src="<?php echo SYSTEM_RESOURCE_URL . $aUserInfo['profile']; ?>" width="95" height="95" />
			</div>
			<div class="total-info-txt">
				<div class="info-txt-1"><span class="total-level">等级：LV<?php echo $aUserInfo['level']; ?></span><span class="total-score">经验：(<?php echo $aUserInfo['accumulate_points']; ?>)</span></div>
				<div class="info-txt-1"><span class="total-join">参赛：<?php echo $matchCount; ?>次</span><span class="total-prize">获奖：(<?php echo $matchWinPrizeCount; ?>次)</span></div>
			</div>
		</div>

		<!-- 模块信息展示 -->
		<div class="data-show ">
			<div class="data-show-title"><span class="plr">总答题：<em><?php echo $aAllMissionStatistics['es_count']; ?></em><i>(<?php echo $aAllMissionStatistics['es_count'] - $aAllMissionStatistics['es_correct_count']; ?>错题)</i></span></div>
			<div class="data-show-content">
				<div class="data-show-item data-show-c">
					<div class="name"><span>语文</span></div>
					<div class="bar"><span class="bar-process bar-process-c" style="width:<?php echo $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][1]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : 0; ?>%"></span></div>
					<div class="precent"><span><?php echo $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][1]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : 0; ?>%</span></div>
					<div class="count"><span><?php echo $aAllMissionStatistics['subject_count'][1]['es_count']; ?></span></div>
				</div>

				<div class="data-show-item data-show-m">
					<div class="name"><span>数学</span></div>
					<div class="bar"><span class="bar-process bar-process-m" style="width:<?php echo $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][2]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : 0; ?>%"></span></div>
					<div class="precent"><span><?php echo  $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][2]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : 0; ?>%</span></div>
					<div class="count"><span><?php echo $aAllMissionStatistics['subject_count'][2]['es_count']; ?></span></div>
				</div>

				<div class="data-show-item data-show-e">
					<div class="name"><span>英语</span></div>
					<div class="bar"><span class="bar-process bar-process-e" style="width:<?php echo $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][3]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 : 0; ?>%"></span></div>
					<div class="precent"><span><?php echo $aAllMissionStatistics['es_count'] ? intval(($aAllMissionStatistics['subject_count'][3]['es_count'] / $aAllMissionStatistics['es_count']) * 10000) / 100 :0; ?>%</span></div>
					<div class="count"><span><?php echo $aAllMissionStatistics['subject_count'][3]['es_count']; ?></span></div>
				</div>
			</div>
		</div>
		<!-- data-show -->

		<div class="data-show">
			<div class="data-show-title"><span class="plr">总闯关：<em><?php echo $aAllMissionStatistics['pass_mission_count']; ?></em></span></div>
			<div class="data-show-content">
				<div class="data-show-item data-show-c">
					<div class="name"><span>语文</span></div>
					<div class="bar"><span class="bar-process" style="width:<?php echo $aAllMissionStatistics['subject_count'][1]['mission_rate']; ?>%"></span></div>
					<div class="precent"><span><?php echo $aAllMissionStatistics['subject_count'][1]['mission_rate']; ?>%</span></div>
					<div class="count"><span><?php echo $aAllMissionStatistics['subject_count'][1]['pass_mission_count']; ?></span></div>
				</div>

				<div class="data-show-item data-show-m">
					<div class="name"><span>数学</span></div>
					<div class="bar"><span class="bar-process" style="width:<?php echo $aAllMissionStatistics['subject_count'][2]['mission_rate']; ?>%"></span></div>
					<div class="precent"><span><?php echo $aAllMissionStatistics['subject_count'][2]['mission_rate']; ?>%</span></div>
					<div class="count"><span><?php echo $aAllMissionStatistics['subject_count'][2]['pass_mission_count']; ?></span></div>
				</div>

				<div class="data-show-item data-show-e">
					<div class="name"><span>英语</span></div>
					<div class="bar"><span class="bar-process" style="width:<?php echo $aAllMissionStatistics['subject_count'][3]['mission_rate']; ?>%"></span></div>
					<div class="precent"><span><?php echo $aAllMissionStatistics['subject_count'][3]['mission_rate']; ?>%</span></div>
					<div class="count"><span><?php echo $aAllMissionStatistics['subject_count'][3]['pass_mission_count']; ?></span></div>
				</div>
			</div>
		</div>
		<!-- data-show -->

		<!-- 切换模块 -->
		<div class="data-tabs" id="dataTabs">
			<div class="data-tabs-title">
				<a href="javascript:;" class="current">每月答题走势</a>
				<a href="javascript:;">每月闯关走势</a>
				<a href="javascript:;">每月平均分走势</a>
			</div>
			<div class="data-tabs-content" id="dataTabsContent">
				<div class="pane" style="display:table">
				<?php
					$max = 0;
					foreach($aMonthStats[0] as $key => $aValue){
						if($aValue[1] > $max){
							$max = $aValue[1];
						}
					}
					foreach($aMonthStats[0] as $key => $aValue){
						if($max){
							$aMonthStats[0][$key][3] = intval(($aValue[1] / $max) * 10000) / 100;
						}else{
							$aMonthStats[0][$key][3] = 0;
						}
					}
				?>
				<?php for($i = count($aMonthStats[0]) - 1; $i >= 0; $i--){ $aValue = $aMonthStats[0][$i]; ?>
					<div class="pane-item">
						<div class="name"><span><?php echo $aValue[0]; ?></span></div>
						<div class="bar"><span class="bar-process" style="width:<?php echo $aValue[3]; ?>%"></span></div>
						<div class="count"><span><?php echo $aValue[1]; ?>题</span></div>
					</div>
				<?php } ?>
				</div>
				<!-- pane -->

				<div class="pane">
					<?php
						$max = 0;
						foreach($aMonthStats[1] as $key => $aValue){
							if($aValue[1] > $max){
								$max = $aValue[1];
							}
						}
						foreach($aMonthStats[1] as $key => $aValue){
							if($max){
								$aMonthStats[1][$key][3] = intval(($aValue[1] / $max) * 10000) / 100;
							}else{
								$aMonthStats[1][$key][3] = 0;
							}
						}
					?>
					<?php for($i = count($aMonthStats[1]) - 1; $i >= 0; $i--){ $aValue = $aMonthStats[1][$i]; ?>
						<div class="pane-item">
							<div class="name"><span><?php echo $aValue[0]; ?></span></div>
							<div class="bar"><span class="bar-process" style="width:<?php echo $aValue[3]; ?>%"></span></div>
							<div class="count"><span><?php echo $aValue[1]; ?>关</span></div>
						</div>
					<?php } ?>
				</div>
				<!-- pane -->

				<div class="pane">
					<?php
						$max = 0;
						foreach($aMonthStats[2] as $key => $aValue){
							if($aValue[1] > $max){
								$max = $aValue[1];
							}
						}
						foreach($aMonthStats[2] as $key => $aValue){
							if($max){
								$aMonthStats[2][$key][3] = intval(($aValue[1] / $max) * 10000) / 100;
							}else{
								$aMonthStats[2][$key][3] = 0;
							}
						}
					?>
					<?php for($i = count($aMonthStats[2]) - 1; $i >= 0; $i--){ $aValue = $aMonthStats[2][$i]; ?>
						<div class="pane-item">
							<div class="name"><span><?php echo $aValue[0]; ?></span></div>
							<div class="bar"><span class="bar-process" style="width:<?php echo $aValue[1]; ?>%"></span></div>
							<div class="count"><span><?php echo $aValue[1]; ?>分</span></div>
						</div>
					<?php } ?>
				</div>
				<!-- pane -->
			</div>
		</div>

	</div>
</div>
<!--all-->

<!--month-->
<div id="monthScore" class="por">
	<div class="common-header plr fixed t0">
		<i class="icon-back" onclick="showHome('monthScore');"></i>
		<h2>月战绩</h2>
	</div>
	<div class="common-content parents-pt" id="commonContent">

		<!-- 模拟select下拉 -->
		<div class="select-box" id="selectBox">
           <a class="selet-open"><span class="select-txt"><?php echo date('Y', strtotime('-1 month')); ?>年<?php echo date('n', strtotime('-1 month')); ?>月</span><i class="triangle-down"></i></a>
           <div class="option">
				<?php for($i = count($aMonthList) - 1; $i >= 0; $i--){ ?>
               <a href="javascript:;" onclick="selectMonth(<?php echo $aMonthList[$i]['year']; ?>, <?php echo $aMonthList[$i]['month']; ?>);"><?php echo $aMonthList[$i]['year']; ?>年<?php echo $aMonthList[$i]['month']; ?>月</a>
			   <?php } ?>
           </div>
       </div>


		<div class="data-show-title-single"><span class="plr">参赛数：<em id="monthMatchCount">0</em><i id="monthMatchWinCount">(0场获奖)</i></span></div>

		<!-- 模块信息展示 -->
		<div class="data-show ">
			<div class="data-show-title"><span class="plr">总答题：<em id="monthEsCount">0</em><i id="monthEsWrongCount">(0错题)</i></span></div>
			<div id="monthEsList" class="data-show-content"></div>
		</div>
		<!-- data-show -->

		<div class="data-show">
			<div class="data-show-title"><span class="plr">总闯关：<em id="monthMissionCount">0</em></span></div>
			<div id="monthMissionList" class="data-show-content"></div>
		</div>
		<!-- data-show -->

		<div class="data-show">
			<div class="data-show-title"><span class="plr">月均分：<em id="monthAvgScore">0</em></span></div>
			<div id="monthAvgScoreList" class="data-show-content"></div>
		</div>
		<!-- data-show -->

	</div>
</div>
<!--month-->

<!--detail-->
<div id="detailScore" class="por">
	<div class="common-header plr fixed t0">
		<i class="icon-back" onclick="showHome('detailScore');"></i>
		<h2>详细战绩</h2>
	</div>
	<div class="common-content parents-pt" id="commonContent">

		<!-- 模拟select下拉 -->
		<div class="select-box" id="selectBox1">
           <a class="selet-open"><span class="select-txt"><?php echo date('Y', strtotime('-1 month')); ?>年<?php echo date('n', strtotime('-1 month')); ?>月</span><i class="triangle-down"></i></a>
           <div class="option">
				<?php for($i = count($aMonthList) - 1; $i >= 0; $i--){ ?>
               <a href="javascript:;" onclick="selectMonth(<?php echo $aMonthList[$i]['year']; ?>, <?php echo $aMonthList[$i]['month']; ?>);"><?php echo $aMonthList[$i]['year']; ?>年<?php echo $aMonthList[$i]['month']; ?>月</a>
			   <?php } ?>
           </div>
       </div>
		<!-- 切换模块 -->
		<div class="data-tabs" id="dataTabs1">
			<div class="data-tabs-title">
				<a href="javascript:;" class="current">语文</a>
				<a href="javascript:;">数学</a>
				<a href="javascript:;">英语</a>
			</div>
			<div class="data-tabs-content ds-bgc" id="dataTabsContent1">
				<div id="chineseList" class="pane" style="display:table"></div>
				<!-- pane -->

				<div id="mathList" class="pane"></div>
				<!-- pane -->

				<div id="englishList" class="pane"></div>
				<!-- pane -->
			</div>
		</div>
		<!-- 切换模块 -->
	</div>
</div>
<!--detail-->
<div class="active-teacher-s">
	<a href="##" onclick="jump();"><img src="<?php echo $GLOBALS['RESOURCE']['active-s']; ?>" alt=""></a>
</div>
<!-- <div class="active-teacher-b">
	<a onclick="jump();" href="##"><img src="" alt=""></a>
	<a href="#" class="active-b-close"></a>
</div> -->
<script type="text/javascript">
var monthStatisticsCache = [];
var aMonthStats = <?php echo json_encode($aMonthStats); ?>;
var currentUserId = <?php echo $userId; ?>;
function jump(){
	location.href = '<?php echo url('m=Activity&a=showMission', '', APP_XXT);?>';
}

function detailClickSlide(){
	$('.pane-item-title').each(function(){
		var $this = $(this);
		var content = $(this).next('.pane-item-content');
		$(this).click(function(){

			if(content.is(':hidden')){
				content.fadeIn().css('display','table');
				$this.find('.s-btn').text('收起');
			}else{
				content.fadeOut();
				$this.find('.s-btn').text('展开');
			}

		});

		if(content.is(':hidden')){
			$this.find('.s-btn').text('展开');
		}else{
			$this.find('.s-btn').text('收起');
		}
	});
}

function showGrade(id){
	$('#parentsHome, .active-teacher-s, .active-teacher-b, #educationInformation').hide();
	$('#' + id).show();
}

function showHome(id){
	$('#' + id).hide();
	$('#parentsHome, .active-teacher-s, #educationInformation').show();
	scroll(0, 0);
}

function appendMonthStatistics(aData){
	$('#monthMatchCount').html(aData.matchCount);
	$('#monthMatchWinCount').html('(' + aData.winPrizeCount + '场获奖)');
	$('#monthEsCount').html(aData.es_count);
	$('#monthEsWrongCount').html('('  + (aData.es_count - aData.es_correct_count) + '错题)');
	$('#monthMissionCount').html(aData.pass_mission_count);
	//$('#monthAvgScore').html(getMonthAvg());
	$('#monthEsList').html(getMonthEsHtml(aData.subject_count, aData.es_count));
	$('#monthMissionList').html(getMonthMissionHtml(aData.subject_count));
	$('#monthAvgScoreList').html(getMonthAvgScoreHtml(aData.subject_count));
	detailClickSlide();
}

function getSubjectStaticHtml(arr){
	var htmlStr = '';
	htmlStr += '<div class="pane-item">';
	htmlStr += '<div class="pane-item-title">';
	htmlStr += '<span>' + arr.mission_name + '</span>';
	htmlStr += '<button class="s-btn fr">收起</button>';
	htmlStr += '</div>';
	htmlStr += '<div class="pane-item-content" style="/*display:table*/">';
	htmlStr += '<div class="content-row">';
	htmlStr += '<span>得分：<em>' + parseInt(arr.score) / 100 + '</em></span>';
	htmlStr += '<span>排名：超越<em>' + arr.defeat_percent + '</em>%的人</span>';
	htmlStr += '</div>';
	htmlStr += '<div class="content-row">';
	htmlStr += '<span>答题：<em>' + arr.es_count + '</em></span>';
	htmlStr += '<span>正确率：<em>' + (parseInt((parseInt(arr.es_correct_count) / parseInt(arr.es_count)) * 10000) / 100) + '</em>%</span>';
	htmlStr += '</div>';
	htmlStr += '<div class="content-row">';
	htmlStr += '<span>过关时间：<em>' + date('Y-m-d', arr.pass_time) + '</em></span>';
	htmlStr += '</div>';
	htmlStr += '</div>';
	htmlStr += '</div>';

	return htmlStr;
}

function getMonthAvgScoreHtml(data){
	var chineseMissionList = data[1].pass_mission_list,
	mathMissionList = data[2].pass_mission_list,
	englistMissionList = data[3].pass_mission_list,
	chineseAvgScore = 0,
	mathAvgScore = 0,
	englistAvgScore = 0;
	$('#chineseList').html('');
	$('#mathList').html('');
	$('#englishList').html('');
	if(chineseMissionList.length != 0){
		var chineseHtml = '';
		for(var i = 0; i < chineseMissionList.length; i++){
			var arr = chineseMissionList;
			chineseAvgScore += parseInt(arr[i].score) / 100;
			chineseHtml += getSubjectStaticHtml(arr[i]);
		}
		$('#chineseList').html(chineseHtml);
		chineseAvgScore = parseInt((chineseAvgScore / chineseMissionList.length) * 100) / 100;
	}else{
		$('#chineseList').html('<center>暂无数据</center>');
	}
	if(mathMissionList.length != 0){
		var mathHtml = '';
		for(var i = 0; i < mathMissionList.length; i++){
			var arr = mathMissionList;
			mathAvgScore += parseInt(mathMissionList[i].score) / 100;
			mathHtml += getSubjectStaticHtml(arr[i]);
		}
		$('#mathList').html(mathHtml);

		mathAvgScore = parseInt((mathAvgScore / mathMissionList.length) * 100) / 100;
	}else{
		$('#mathList').html('<center>暂无数据</center>');
	}
	if(englistMissionList.length != 0){
		var englishHtml = '';
		for(var i = 0; i < englistMissionList.length; i++){
			var arr = englistMissionList;
			englistAvgScore += parseInt(englistMissionList[i].score) / 100;
			englishHtml += getSubjectStaticHtml(arr[i]);
		}
		$('#englishList').html(englishHtml);
		englistAvgScore = parseInt((englistAvgScore / englistMissionList.length) * 100) / 100;
	}else{
		$('#englishList').html('<center>暂无数据</center>');
	}
	var htmlStr = '';
	htmlStr += '<div class="data-show-item data-show-c">';
	htmlStr += '<div class="name"><span>语文</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + chineseAvgScore + '%"></span></div>';
	htmlStr += '<div class="precent"><span></span></div>';
	htmlStr += '<div class="count"><span>' + chineseAvgScore + '</span></div>';
	htmlStr += '</div>';
	htmlStr += '<div class="data-show-item data-show-m">';
	htmlStr += '<div class="name"><span>数学</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + mathAvgScore + '%"></span></div>';
	htmlStr += '<div class="precent"><span></span></div>';
	htmlStr += '<div class="count"><span>' + mathAvgScore + '</span></div>';
	htmlStr += '</div>';
	htmlStr += '<div class="data-show-item data-show-e">';
	htmlStr += '<div class="name"><span>英语</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + englistAvgScore + '%"></span></div>';
	htmlStr += '<div class="precent"><span></span></div>';
	htmlStr += '<div class="count"><span>' + englistAvgScore + '</span></div>';
	htmlStr += '</div>';

	return htmlStr;
}

function getMonthMissionHtml(data){
	var htmlStr = '';
	htmlStr += '<div class="data-show-item data-show-c">';
	htmlStr += '<div class="name"><span>语文</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + data[1].mission_rate + '%"></span></div>';
	htmlStr += '<div class="precent"><span>' + data[1].mission_rate + '</span></div>';
	htmlStr += '<div class="count"><span>' + data[1].pass_mission_count + '</span></div>';
	htmlStr += '</div>';
	htmlStr += '<div class="data-show-item data-show-m">';
	htmlStr += '<div class="name"><span>数学</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + data[2].mission_rate + '%"></span></div>';
	htmlStr += '<div class="precent"><span>' + data[2].mission_rate + '</span></div>';
	htmlStr += '<div class="count"><span>' + data[2].pass_mission_count + '</span></div>';
	htmlStr += '</div>';
	htmlStr += '<div class="data-show-item data-show-e">';
	htmlStr += '<div class="name"><span>英语</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + data[3].mission_rate + '%"></span></div>';
	htmlStr += '<div class="precent"><span>' + data[3].mission_rate + '</span></div>';
	htmlStr += '<div class="count"><span>' + data[3].pass_mission_count + '</span></div>';
	htmlStr += '</div>';

	return htmlStr;
}

function getMonthEsHtml(data, esCount){
	var htmlStr = '';
	htmlStr += '<div class="data-show-item data-show-c">';
	htmlStr += '<div class="name"><span>语文</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + data[1].percent + '%"></span></div>';
	htmlStr += '<div class="precent"><span>' + data[1].percent + '%</span></div>';
	htmlStr += '<div class="count"><span>' + data[1].es_count + '</span></div>';
	htmlStr += '</div>';
	htmlStr += '<div class="data-show-item data-show-m">';
	htmlStr += '<div class="name"><span>数学</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + data[2].percent + '%"></span></div>';
	htmlStr += '<div class="precent"><span>' + data[2].percent + '%</span></div>';
	htmlStr += '<div class="count"><span>' + data[2].es_count + '</span></div>';
	htmlStr += '</div>';
	htmlStr += '<div class="data-show-item data-show-e">';
	htmlStr += '<div class="name"><span>英语</span></div>';
	htmlStr += '<div class="bar"><span class="bar-process" style="width:' + data[3].percent + '%"></span></div>';
	htmlStr += '<div class="precent"><span>' + data[3].percent + '%</span></div>';
	htmlStr += '<div class="count"><span>' + data[3].es_count + '</span></div>';
	htmlStr += '</div>';

	return htmlStr;
}

function selectMonth(year, month){
	getMonthStatistics(currentUserId, year, month);
}

function getMonthAvg(date){
	var score = 0;
	for(var i = 0; aMonthStats[2].length; i++){
		if(aMonthStats[2][i][0] == date){
			score = aMonthStats[2][i][1];
			$('#monthAvgScore').html(score);
			break;
		}
	}
}

function getMonthStatistics(userId, year, month){
	var keyStr = 'key_' + userId + '_' + year + '_' + month;
	var d = 0;
	if(parseInt(month) < 10){
		d = year + '' + '0' + month;
	}else{
		d = year + '' + month;
	}
	if(typeof(monthStatisticsCache[keyStr]) != 'undefined'){
		appendMonthStatistics(monthStatisticsCache[keyStr]);
		getMonthAvg(d);
		return;
	}
	ajax({
		url : '<?php echo url("m=Index&a=getUserMonthGradeList"); ?>',
		data : {
			userId : userId,
			year : year,
			month : month
		},
		success : function(aResult){
			if(aResult.status == 1){
				monthStatisticsCache[keyStr] = aResult.data;
				appendMonthStatistics(aResult.data);
				getMonthAvg(d);
			}else{
				alert(aResult.msg);
			}
		}
	});
}

// function activeTeacher(){
// 	$('.active-teacher-s').click(function(){
// 		$('.active-teacher-b').fadeIn('fast');
// 		$(this).fadeOut('fast');
// 	});
// 	$('.active-b-close').click(function(){
// 		$('.active-teacher-b').fadeOut('fast');
// 		$('.active-teacher-s').fadeIn();
// 	});
// }

$(function(){
	// activeTeacher();
	$('#totalScore, #monthScore, #detailScore').hide();
	selectBox();
	totalScoreTabs(); //切换
	detailClickSlide(); //点击展示内容
	getMonthStatistics(currentUserId, <?php echo date('Y', strtotime('-1 month')); ?>, <?php echo date('n', strtotime('-1 month')); ?>);
	getMonthAvg(<?php echo date('Y', strtotime('-1 month')) . date('m', strtotime('-1 month')); ?>);
});
</script>