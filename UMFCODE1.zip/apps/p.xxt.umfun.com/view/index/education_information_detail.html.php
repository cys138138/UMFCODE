<div id="teachInfoDetail" class="por">
	<div class="common-header plr fixed">
		<i class="icon-back" onclick="javascript:history.go(-1);"></i>
		<h2>教育资讯</h2>
	</div>
	<div class="common-content parents-pt" id="commonContent">
		<div class="teachInfo-detail-mod">
			<div class="teachInfo-detail-hd">
				<div class="teachInfo-detail-title"><?php echo $aEduNews['title']; ?></div>
				<div class="teachInfo-detail-info">
					<span class="teachInfo-info-source">来源：工人日报</span>|
					<span class="teachInfo-info-time"><?php echo date('Y-m-d', $aEduNews['create_time']); ?></span>
				</div>
			</div>
			<div class="teachInfo-detail-bd">
				<?php echo $aEduNews['content']; ?>
			</div>
		</div>

	</div>
</div>