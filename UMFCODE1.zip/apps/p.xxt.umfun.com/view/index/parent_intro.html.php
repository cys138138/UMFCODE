<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">
	<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['m_style_parent']; ?>">
	<link rel="stylesheet" href="<?php echo $GLOBALS['RESOURCE']['m_style_parent_intro']; ?>">
	<title>UMFun(优满分)-中国创新教育领导品牌,做国内最优秀的中小学生游戏化学习网站</title>
</head>
<body>
	<div class="common-header plr fixed">
		<i class="icon-back" onclick="javascript:history.go(-1);"></i>
		<h2>UMFUN介绍</h2>
	</div>
	<div class="intro-section section-bg1">
		<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_1']; ?>" alt="">
		<div class="intro-txt section-txt1">
			<h2 class="first-head">UMFun(优满分)——中国创新教育领导品牌<br/>做国内最优秀的中小学生游戏化学习网站</h2>
			<p>优满分自主研发最具创新的游戏化学习，目前覆盖五至九年级语数英三科目目前正在努力聚集其他科目及年级的优秀资源优满分一直秉持专注、专业、创新、规范共享的研发理念，以互联网技术为核心，通过孩子们最喜欢的游戏方式来最大程度激发学习兴趣，通过数据跟踪每一个孩子的学习轨迹帮助孩子快速修复薄弱点并提高学习成绩，以全新的模式和方式进行全新的学习！</p>
		</div>
	</div>

	<div class="intro-section">
		<div class="intro-txt">
			<h2>最先进的游戏化学习模式</h2>
				<p>通过游戏增加趣味性并激发学习兴趣，再
		根据游戏产生的学习数据来进行跟踪分析，
		对薄弱的环节提供修复，完全颠覆传统学
		习的“灌输”模式。</p>
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_2']; ?>" alt="">
		</div>
	</div>

	<div class="intro-section">
		<div class="intro-txt">
			<h2>互联网时代的学习利器</h2>
				<p>80年代我们的学习主要是买各种字典工具
	书，90年代我们的学习主要是订购各种学
	习杂志，00年代我们的学习主要是买各种
	习题，上各种培训班，买学习机。但是：
	书包越来越重、学习压力越来越大、睡眠
	时间越来越少！
	</p>
			<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_3']; ?>" alt="">
			<p>时代已经在悄悄的发生巨大变化，在比尔
				盖茨都已经落后的今天，互联网占据了我
				们生活的重要位置，今天的孩子们就是明
				天的希望，互联网是他们最基本的生活方
				式，也是他们改变未来的途径。互联网游
				戏化的学习方式将成为这个时代最先进的
				学习方式之一。</p>
		</div>
	</div>
	<div class="intro-section">
		<div class="bq">
			<div class="bg-img">
				<i class="ico1"></i>
				<img alt="" src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_bq_1']; ?>" />
				
			</div>
			<p>孩子不是不用功，更不是不聪明，关键就
	在于缺乏学习环境。孩子不开窍，成绩不
	好孩子自己也很痛苦，做家长怎么能不闻
	不问？朋友介绍用了优满分后，家里的电
	脑就派上用场了，以前我反对孩子玩电脑。
	怕孩子玩游戏，时代总是要进步的，电脑
	可以帮助孩子提高学习成绩，现在孩子的
	学习兴趣非常高涨，这次考试成绩上升了
	很多，做家长的我也很开心！</p>
		</div>

		<div class="bq">
			<div class="bg-img">
				<i class="ico2"></i>
				<img alt="" src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_bq_2']; ?>" />
				
			</div>
			<p>我很喜欢优满分，我喜欢优满分里的比赛，
	有很多奖品奖励，为了得到更多的奖品我会
	继续努力！不知不觉的感觉以前比我成绩好
	的同学都已经排名在我后面了，还是挺激动
	的，我一有空就会和同学PK，我现在已经
	PK达人了，很少遇到对手哦。</p>
		</div>
	</div>
	<div class="intro-section">
		<div class="intro-txt">
			<h2>不用请家教，不用去培训班</h2>
				<p>有了优满分，不用请家教，不再去上
	培训班，不用再买乱七八糟的教辅，一年
	节省 2 万课外培训费。
	</p>
	<p>优满分让孩子们学习兴趣激增，学习也
	变得有趣味更加轻松，学习效率得到提高，
	并形成自主学习的良性循环，在实现游戏
	目标的同时，成绩也在不知不觉中飞速前
	进。相比孩子比较抵触的家教和培训班，
	新的游戏化学习方式会帮助孩子形成更加
	独立自主的学习能力。</p>
		<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_4']; ?>" alt="">	
		</div>
	</div>

	<div class="intro-section">
		<div class="bq">
			<div class="bg-img">
				<i class="ico1"></i>
				<img alt="" src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_bq_3']; ?>" />
				
			</div>
			<p>要真想让孩子学习成绩好，学习环境最重要，
	作为家长不可能一切都懂，也很难给孩子辅
	导，孩子上培训班要花很多费用效果还不一
	定好，有了优满分游戏化学习，我就买了台
	电脑，现在孩子每天都会花时间玩优满分，
	学习劲头还挺大，我觉得游戏化学习一定会
	成为今后教育的主流。</p>
		</div>

		<div class="bq">
			<div class="bg-img">
				<i class="ico"></i>
				<img alt="" src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_bq_4']; ?>" />
				
			</div>
			<p>超过王俊，我要是考到第一名就能够实现去
	攀登珠穆朗玛峰的梦想了，而且我希望能考
	上省重点高中。</p>
		</div>
	</div>

	<div class="intro-section">
		<div class="intro-txt">
		<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_5']; ?>" alt="">	
		</div>
	</div>

	<div class="intro-section nomb">
		<div class="intro-txt">
			<h2>专注游戏化体验，值得信赖</h2>
				<p>我们的使命是要用创新思维去研发最
	适合中国学生使用的游戏化学习产品，并
	使之成为21世纪最高效的学习方式，做最
	优秀的中小学生游戏化学习产品！近60名
	专业游戏开发工程师、游戏化学习研究专
	家耗费3年时间倾力研发。因为专业专注，
	所以值得信赖！</p>
		<img src="<?php echo $GLOBALS['RESOURCE']['m_parent_intro_6']; ?>" alt="">	
		</div>
	</div>
	<?php echo SYSTEM_STATISTICS_CODE; ?>
</body>
</html>