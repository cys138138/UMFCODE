<div id="teachInfo" class="por">
	<div class="common-header plr fixed">
		<i class="icon-back" onclick="javascript:history.go(-1);"></i>
		<h2>教育资讯</h2>
	</div>
	<div class="common-content parents-pt" id="commonContent">
	<?php foreach($aEduNewsList as $key => $aEduNews){ ?>
		<div class="teachInfo-list-mod">
			<div class="teachInfo-mod-hd"><?php echo $aEduNews['name']; ?></div>			
			<ul class="teachInfo-mod-list clearfix">
			<?php foreach($aEduNews['content_list'] as $k => $aContentList){ ?>
				<li>
					<a href="<?php echo url('m=Index&a=educationInformationDetail', 'id=' . $aContentList['id']); ?>">
						<span class="title"><?php echo $aContentList['title']; ?></span>
						<span class="time"><?php echo date('Y-m-d', $aContentList['create_time']); ?></span>
					</a>
				</li>
			<?php } ?>
			</ul>
		</div>
	<?php } ?>
	</div>
</div>