<?php
define('AUTO_COMPILER', 0);
define('IS_URL_REWRITE', 1);
define('IS_CHINESE_SIMPLIFIED', 1);
define('APP_NAME', substr(str_replace(dirname(dirname(__FILE__)), '', dirname(__FILE__)), 1));
define('APP_DOMAIN', APP_P_XXT);
define('APP_PATH', SYSTEM_ROOT_PATH . 'apps/' . APP_NAME . '/');
define('APP_CONTROLLER_PATH', APP_PATH . 'controller/');
define('APP_VIEW_PATH', APP_PATH . 'view/');
define('APP_CACHE_PATH', APP_PATH . 'cache/');
define('APP_COMPILER_PATH', APP_PATH . 'compiler/');
define('APP_LOG_FILE', SYSTEM_LOG_PATH . APP_NAME . '/' . date('Y-m-d') . '.log');