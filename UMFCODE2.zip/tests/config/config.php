<?php
codecept_debug('run ' . __FILE__);
/**
 * Application configuration shared by all applications and test types
 */
return [
    'components' => [
        'mailer' => [
            'useFileTransport' => true,
        ],
        'urlManager' => [
            'showScriptName' => true,
        ],
		'test' => [
			'class' => 'umtest\TestHelper',
			'commonStudent' => [
				'class' => 'umtest\CommonStudent',
				'id' => 19577027,
				'password' => '121212',
				'email' => '86868057@qq.com',
				'tel' => '123',
				'xxtId' => 79097,
				'xxtPlatform' => \common\xxt\InterfaceManager::PLATFORM_GD,
			],
			'commonTeacher' => [
				'class' => 'umtest\CommonTeacher',
				'id' => 22367,
				'xxtId' => 3718899,
				'xxtPlatform' => \common\xxt\InterfaceManager::PLATFORM_GD,
			],
			'commonMissionRelationId' => 2,

			'aParams' => [
				'area' => [
					'province_id' => 440000,
					'city_id' => 440100,
					'area_id' => 440105,
				],
			'commonEs' =>[
				'es_id' => 88,
				],
			],
		],
    ],
];
