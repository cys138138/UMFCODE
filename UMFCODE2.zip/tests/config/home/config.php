<?php
codecept_debug('run ' . __FILE__);
/**
 * Application configuration for all backend test types
 */
return [
];