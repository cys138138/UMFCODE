<?php
codecept_debug('run ' . __FILE__ . PHP_EOL);
return \yii\helpers\ArrayHelper::merge(
    require(dirname(__DIR__) . '/config.php'),
    require(dirname(__DIR__) . '/unit.php'),
    require(__DIR__ . '/config.php'),
    [
    ]
);