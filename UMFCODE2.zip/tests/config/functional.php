<?php
codecept_debug('run ' . __FILE__);
/**
 * Application configuration shared by all applications functional tests
 */
return [

];