<?php
codecept_debug('run ' . __FILE__);
/**
 * Application configuration shared by all applications acceptance tests
 */
return [

];