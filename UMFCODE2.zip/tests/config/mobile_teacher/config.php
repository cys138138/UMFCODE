<?php
codecept_debug('run ' . __FILE__);
/**
 * Application configuration for all backend test types
 */
return [
	'params' => \yii\helpers\ArrayHelper::merge(require(Yii::getAlias('@mobile_teacher/config/params.php')), [

	]),
];