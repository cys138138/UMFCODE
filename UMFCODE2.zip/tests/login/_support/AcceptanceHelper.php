<?php
namespace Codeception\Module;

/**
 * 页面测试助手
 */
class AcceptanceHelper extends \Codeception\Module
{
	use \umtest\AcceptanceHelperTrait;
}
