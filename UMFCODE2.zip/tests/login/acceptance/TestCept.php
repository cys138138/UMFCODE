<?php use tests\login\AcceptanceTester;
$I = new AcceptanceTester($scenario);
$I->wantTo('perform actions and see result');
$I->amOnPage('/');
$I->see('登陆');
