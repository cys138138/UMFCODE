<?php
codecept_debug('run ' . __FILE__);
require(YII_APP_BASE_PATH . '/../config-local.php');

new umeworld\lib\Application(require(dirname(dirname(__DIR__)) . '/config/login/acceptance.php'));