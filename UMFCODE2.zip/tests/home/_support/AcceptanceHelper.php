<?php
namespace Codeception\Module;

class AcceptanceHelper extends \Codeception\Module{
	//use \umtest\AcceptanceHelperTrait;
	public function loginStudent($account, $password) {
		$oBrowser = $this->getModule('WebDriver');
		$oBrowser->amOnPage('/');	//控制浏览器跳到这个地址
		$oBrowser->see('忘记密码');	//认为这个页面应该有这四个文字
		$oBrowser->fillField('email', $account);	//填充name=email的input,值是test组件里配置的值
		$oBrowser->fillField('password', $password);	//填充密码
		$oBrowser->click('#loginButton');	//点击登陆按钮
		$oBrowser->waitForElement('body', 10);	//等待这个DOM元素的出现,如果不等待就马上执行下一句的话一般会失败,因为页面要加载时间,所以要声明等待下一个页面的什么元素,浏览器就会一直等待这个元素的出现才继续跑后面的代码
	}
}