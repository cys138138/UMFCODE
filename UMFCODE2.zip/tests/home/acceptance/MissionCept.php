<?php use tests\home\AcceptanceTester;
use umeworld\lib\Xxtea;
use umeworld\lib\Url;
use common\model\Es;
use common\model\Mission;
use umeworld\lib\Query;

$I = new AcceptanceTester($scenario);
$I->wantTo('登进网站进行修炼挑战查看战绩');
$I->loginStudent(Yii::$app->test->commonStudent->email, Yii::$app->test->commonStudent->password);
$I->waitforElement('#mainContent');
$I->see('正在闯关');
$I->see('闯关游戏获得经验升级');

$I->amGoingTo('看看闯关');
$I->click('.v3-mission');
$I->waitForElement('.um-header');
$I->waitforElement('#commonTopSlideBanner .ufSlider');
$I->waitforElement('#mCard', 10);
$I->see('卡牌');

$I->amGoingTo('去修炼');
//通过执行页面的JS获取可以修
//炼的关卡
$I->waitForElement('#missionListStyle .J-mission-list-pane .unstyled li');
$practiceNums = (int)$I->executeJs('return $(".J-mission-list-pane .unstyled li").length;');
$I->assertGreaterThan(0, $practiceNums, '关卡数量大于0');

//获取关卡的名称
$missionName =  $I->grabAttributeFrom('#missionListStyle  .J-mission-list-pane .unstyled li:first-child .item-hd', 'title');
codecept_debug('关卡名称: ' . $missionName);
$missionInfo = Mission::findOne(['name' => $missionName]);
codecept_debug('关卡id名称: ' . $missionInfo['id']);

//两种方法获取某个DOM的href属性
$practiceUrl = $I->grabAttributeFrom('#missionListStyle  .J-mission-list-pane .unstyled li:first-child .item-ft a', 'href');
codecept_debug('要测试的修炼地址: ' . $practiceUrl);

//跳转到修炼的地址
$I->amOnPage($practiceUrl);
$I->waitForElement('.contain #titleBar');
$I->amGoingTo('作答题目');
$I->wait(3);
for($i = 0; $i < 15; $i++){
$encodeEsId = (string)$I->executeJS(<<<JS
	if(!Esp.oLastQuestion){
		return '';
	}
 	return  Esp.oLastQuestion.data('es').id;
JS
);	//获取Esp插件处理的最后一条题目对象的id,就是页面上显示的那条题目了
codecept_debug('xxxxxxxxxxxxxxxxxx地址为:'.$encodeEsId);
if(!$encodeEsId){
	//停止测试
	return;
}

$I->assertNotEquals('', $encodeEsId, '题目ID应该不为空的');
$decodeEsId = (int)Xxtea::decrypt($encodeEsId);
$mEs = Es::findOne($decodeEsId);	//从本地数据库读出这一题的模型
if(!$mEs){
	//由于本地没有这条题目,退出测试
	return;
}

$oUnitTester = new \Codeception\TestCase\Test();	//由于 $I 是一个页面测试器,无法执行 assertInstanceOf ,所以new这个单元测试器来借方法用一下
$oUnitTester->assertInstanceOf('common\model\Es', $mEs, '应该是一个题目模型实例');

$xAnswer = $mEs->getAnswer();	//获取可填充的答案
if(!is_scalar($xAnswer)){
	$xAnswer = json_encode($xAnswer);
}
codecept_debug('=======题目' . $mEs->id . '答案start' . PHP_EOL);
codecept_debug($xAnswer);
codecept_debug('=======题目答案end' . PHP_EOL);

$I->executeJS('Esp.oLastQuestion.writeAnswer(' .  $xAnswer . ');');	//填写答案
$I->waitForElement('#wrapAnswer .J-submit .J-btnAnswer');
$I->executeJS(<<<JS
$('#wrapAnswer .J-submit .J-btnAnswer').click();
JS
);	//通过注入脚本来实现点击出招也可以
if($i < 14){
$I->waitForElement('.result-warp .result .description');
$I->wait(1);
$I->executeJS(<<<JS
$('#wrapAnswer .J-submit .J-btnAnswer').click();
JS
);	//通过注入脚本来实现点击出招也可以
$I->wait(1);
}
}
$I->wait(1);
$gurl = $I->grabAttributeFrom('.J-dialogBox .um-mcommon .bd .opts a:last-child', 'href');
$I->amOnPage($gurl);
//$I->waitForElement('.J-dialogBox .um-mcommon .bd .opts a:last-child');
//$I->click('.J-dialogBox .um-mcommon .bd .opts a:last-child');
//$I->waitForElement('.J-dialogBox .um-mcommon .bd .opts a:last-child');//答完题目后等待一下子 J-dialogBox
$I->wait(1);

//挑战页面测试
$I->amGoingTo('去挑战');
//开始挑战连续挑战十道题目
for($i = 0; $i <= 9; $i++){
	$encodeEsId = (string)$I->executeJS(<<<JS
	if(!Esp.oLastQuestion){
		return '';
	}
 	return  Esp.oLastQuestion.data('es').id;
JS
);	//获取Esp插件处理的最后一条题目对象的id,就是页面上显示的那条题目了
codecept_debug('xxxxxxxxxxxxxxxxxx地址为:'.$encodeEsId);
if(!$encodeEsId){
	//停止测试
	return;
}

$I->assertNotEquals('', $encodeEsId, '题目ID应该不为空的');
$decodeEsId = (int)Xxtea::decrypt($encodeEsId);
$mEs = Es::findOne($decodeEsId);	//从本地数据库读出这一题的模型
if(!$mEs){
	//由于本地没有这条题目,退出测试
	return;
}

$oUnitTester = new \Codeception\TestCase\Test();	//由于 $I 是一个页面测试器,无法执行 assertInstanceOf ,所以new这个单元测试器来借方法用一下
$oUnitTester->assertInstanceOf('common\model\Es', $mEs, '应该是一个题目模型实例');

$xAnswer = $mEs->getAnswer();	//获取可填充的答案
if(!is_scalar($xAnswer)){
	$xAnswer = json_encode($xAnswer);
}
codecept_debug('=======题目' . $mEs->id . '答案start' . PHP_EOL);
codecept_debug($xAnswer);
codecept_debug('=======题目答案end' . PHP_EOL);

$I->executeJS('Esp.oLastQuestion.writeAnswer(' .  $xAnswer . ');');	//填写答案
$I->wait(1);	//暂停运行2秒
$I->executeJS(<<<JS
$('#wrapAnswer .J-submit .J-btnAnswer').click();
JS
);	//通过注入脚本来实现点击出招也可以
//下一题um-btn um-btn-default um-btn-xlg J-btnAnswer
if($i < 9){
$I->wait(2);
$I->executeJS(<<<JS
$('#wrapAnswer .J-submit .J-btnAnswer').click();
JS
);	//通过注入脚本来实现点击出招也可以
$I->wait(1);
}
}
//每次答题完成后要判断成功和不成功如果出现成功要删除成功后的答案以及删除经验和等级。失败的话也要删除答案.
$I->wait(3);
$I->executeJS('$(".J-dialogBox .card li:first-child a").click()');

//返回查看成绩
$I->wait(3);
$I->executeJS('$(".J-dialogBox .J-mcard .bd .J-opts .um-btn-xlg:last-child").click()');
//返回查看战绩页面
$I->wait(3);

//清除本次关卡的挑战修炼操作
$missionRecordId = (new Query())->select(['id'])->from('_@mission_user_relation_index') ->where(['mission_id' => $missionInfo['id'], 'user_id' => Yii::$app->test->commonStudent->id])->one();
$I->assertNotEmpty($missionRecordId['id'], '删除的挑战关卡成功的记录id');
//删除本关卡挑战的记录
$missionRelation = (new Query())->createCommand()->delete(Yii::$app->db->parseTable('_@mission_user_relation'), ['id' => $missionRecordId['id']])->execute();
$I->assertNotEquals(0, $missionRelation);
$missionRelationIndex = (new Query())->createCommand()->delete(Yii::$app->db->parseTable('_@mission_user_relation_index'), ['mission_id' => $missionInfo['id'], 'user_id' => Yii::$app->test->commonStudent->id])->execute();
$I->assertNotEquals(0, $missionRelationIndex);
return;
