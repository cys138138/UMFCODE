<?php use tests\home\AcceptanceTester;
use umeworld\lib\Xxtea;
use umeworld\lib\Url;
use umeworld\lib\Query;


$I = new AcceptanceTester($scenario);
$I->wantTo('登进网站');	//声明想测试什么
$I->loginStudent(Yii::$app->test->commonStudent->email, Yii::$app->test->commonStudent->password);
$I->wait(5);
$I->waitForElement('.um-header');

$I->waitForElement('#mainContent');
$I->see('闯关游戏获得经验升级');	//认为登陆后的页面会有这些文字

//学生积分兑换
$I->amGoingTo('积分兑换');
$I->amGoingTo('兑换');
$I->click('.v3-exchange');
$I->waitForElement('.um-header');
$I->see('兑换首页');
$I->see('我的兑换');
$I->waitForElement('.exchange-main .bd .product-list ul li:first-child a');
$praticeUrl = $I->grabAttributeFrom('.exchange-main .bd .product-list ul li:first-child a', 'href');
$I->amOnPage($praticeUrl);
$I->waitForElement('.um-header');
$I->waitForElement('.um-container');

//查看学生的金币
$I->moveMouseOver('.um-opts-account');
$I->waitForElement('#subAccount .um-opts-subaccount-bd');
$myGolds = $I->executeJS('return $("#subAccount .p1 ul li:eq(2) em").text();');
codecept_debug('兑换前的积分总额：' . $myGolds);

//执行兑换操作
$I->seeElement('#exchangeMain .product-info .product-price strong');
//执行兑换查看要兑换的金币
$goldAccount = $I->executeJS('return $("#exchangeMain .product-info .product-price strong").text();');
codecept_debug('兑换所需的金币：' . $goldAccount);
//兑换量
$exchangeAccount = $I->executeJS('return $("#exchangeMain .product-info .product-amount ul li:eq(0) .exchange_num").text();');
codecept_debug('兑换前的兑换量：' . $exchangeAccount);
//库存量
$stockAccount= $I->executeJS('return $("#exchangeMain .product-info .product-amount ul li:eq(1) .storage_num").text();');
codecept_debug('兑换前的库存量：' . $stockAccount);
//查找商品Id
$goodsId = $I->grabAttributeFrom('#exchangeMain .product-info .product-price a', 'data-id');
$I->assertNotEquals('', $goodsId, '兑换的商品ID不为空');
//执行兑换
$I->click('#exchangeMain .J-exchangeNow');
if($goldAccount > $myGolds){
 	$I->see('金币不足');
}else if($stockAccount <= 0){
  	$I->see('库存不足');
}else{
	$I->see('确认兑换');
	$I->assertNotEmpty($goodsId, '要兑换的商品ID');
	$I->fillField(['class' => 'J-name'], '张小军');
	$I->fillField(['class' => 'J-phone'], '15665856565');
	$I->fillField(['class' => 'J-qq'], '907057241');
	$I->selectOption('.J-province', '440000');
 	$I->selectOption('.J-city', '440100');
 	$I->selectOption('.J-area', '440105');
 	$I->fillField(['class' => 'address-detail'], '黄埔村环秀里1号1011');
	$I->click('.exchange-confirm .ft .opts a');
	$I->wait(3);
	//兑换量
	$I->waitForElement('.exchange-success');
	$I->waitForElement('#exchangeMain .product-info .product-amount');
	$exchangeAccountAfter = $I->executeJS('return $("#exchangeMain .product-info .product-amount ul li:eq(0) .exchange_num").text();');
	codecept_debug('兑换后的兑换量：' . $exchangeAccountAfter);
	$I->assertEquals($exchangeAccountAfter-1, $exchangeAccount);

	//库存量
	$stockAccountAfter = $I->executeJS('return $("#exchangeMain .product-info .product-amount ul li:eq(1) .storage_num").text();');
	codecept_debug('兑换后的库存量：'.$stockAccountAfter);
	$I->assertEquals($stockAccountAfter+1, $stockAccount);
	//比较积分兑换前后值得变化

	$successUrl = $I->grabAttributeFrom('.exchange-success .ft .opts a', 'href');
	$I->amOnPage($successUrl);
	$I->see('我的兑换');
	$I->wait(3);
	$I->moveMouseOver('.um-opts-account');
	$I->waitForElement('#subAccount .um-opts-subaccount-bd');
	$myGoldsAfter = $I->executeJS('return $("#subAccount .p1 ul li:eq(2) em").text();');
	codecept_debug('兑换后的积分总额：' . $myGoldsAfter);
	$I->assertEquals($myGoldsAfter+$goldAccount, $myGolds);

	//删除兑换记录
    $exchangeId = (new Query())->select(['id'])->from('_@exchange_records') ->where(['goods_id' => $goodsId, 'user_id' => Yii::$app->test->commonStudent->id])->orderBy(['create_time' => SORT_DESC])->limit(1)->one();
	$I->assertNotEmpty($exchangeId, '用户最新积分兑换记录的id');
	$deleteId = (new Query())->createCommand()->delete(Yii::$app->db->parseTable('_@exchange_records'), ['id' => $exchangeId])->execute();
    $I->assertNotEquals(0, $deleteId);

    //将兑换数据还原包括金币和兑换数量和库存量
	$aData = [
	    'stock' => $stockAccount,
	    'sales_volume' => $exchangeAccount,
	    'gold' =>  $myGolds,
	];

	$updateId =(new Query())->createCommand()->update(Yii::$app->db->parseTable('_@exchange_goods'), $aData, ['id' => $goodsId])->execute();
	$I->assertNotEquals(0, $updateId);
}


$I->amGoingTo('退出登陆');
$I->moveMouseOver('.um-opts-set');	//鼠标移动到这个元素上,使它触发hover事件出现另一个DOM
$I->click('#header .unstyled .um-opts-set .um-msubset .um-opts-subset-ft a');	//退出登陆的按钮,这是hover后才出来的,不可见元素不可点击

