<?php use tests\home\AcceptanceTester;
$I = new AcceptanceTester($scenario);
$I->wantTo('perform actions and see result');

//全站概览测试一下关键按钮
$I->wantTo('登进网站进行修炼挑战查看战绩');
$I->loginStudent(Yii::$app->test->commonStudent->email, Yii::$app->test->commonStudent->password);
$I->waitforElement('#mainContent');
$I->wait(5);
$I->see('正在闯关');
$I->see('闯关游戏获得经验升级');

//首页测试
$I->amGoingTo('首页');
$I->click('.v3-home');
$I->waitforElement('#mainContent');
$I->see('精彩比赛');
$I->see('激烈PK');

//查看错题
$I->amGoingTo('查看错题');
$I->click('查看错题');	//跳到查看错题页面
$I->wait(5);
$I->dontSee('闯关游戏获得经验升级');		//认为这个页面不应该出现这些首页的文字
$I->see('我的错题');

$I->click('错题统计');
$I->waitForElement('#pie1', 10);
$I->see('错题次数');

//查看闯关页面
$I->amGoingTo('查看闯关');
//导航栏进入闯关页面
$I->click('.v3-mission');
$I->waitForElement('.um-header');
$I->see('卡牌');

//比赛页面
$I->amGoingTo('比赛');
$I->click('.v3-match');
$I->waitForElement('.um-header');
$I->seeElement('.home-mods .match-nav');
$I->see('全部比赛');
$I->see('比赛之星');
$I->see('我的比赛');


//PK页面
$I->amGoingTo('PK页面');
$I->click('.v3-pk');
$I->waitForElement('.um-header');
$I->seeElement('.pk_wrap');
$I->see('PK场');
$I->see('我的PK');
//兑换
$I->amGoingTo('兑换');
$I->click('.v3-exchange');
$I->waitForElement('.um-header');
$I->seeElement('#exchangeMain');
$I->see('兑换首页');
$I->see('我的兑换');

//话题
$I->amGoingTo('话题');
$I->click('.v3-topic');
$I->waitForElement('.um-header');
$I->seeElement('.mtopic-nav');
$I->see('全部');
$I->see('玩转优满分');
$I->see('七嘴八舌');
$I->see('脑力大挑战');
//今日任务
$I->amGoingTo('今日任务');
$I->click('.v3-topic');
$I->waitForElement('.um-header');
$I->seeElement('.hd');

//退出系统
$I->amGoingTo('退出登陆');
$I->moveMouseOver('.um-opts-set');	//鼠标移动到这个元素上,使它触发hover事件出现另一个DOM
$I->waitForElement('.um-opts-set .um-msubset .um-opts-subset-ft a');
$I->click('#header .unstyled .um-opts-set .um-msubset .um-opts-subset-ft a');	//退出登陆的按钮,这是hover后才出来的,不可见元素不可点击
