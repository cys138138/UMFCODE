<?php use tests\home\AcceptanceTester;
use umeworld\lib\Xxtea;
use umeworld\lib\Url;
use common\model\Es;
use common\model\Mission;
use umeworld\lib\Query;

$I = new AcceptanceTester($scenario);
$I->wantTo('登进网站进行活动测试');
$I->loginStudent(Yii::$app->test->commonStudent->email, Yii::$app->test->commonStudent->password);
$I->waitforElement('#mainContent');
$I->see('正在闯关');
$I->see('闯关游戏获得经验升级');

$I->amGoingTo('主页面');
$I->click('.v3-match');
$I->waitForElement('.match-main .match-nav');
$I->wait(3);
$I->seeElement('.match-main .match-nav a:nth-child(2)');
$I->click('.match-main .match-nav a:nth-child(2)');
$I->waitForElement('.match-star-cont');
$I->seeElement('.match-star-1');
$I->seeElement('.match-star-2');
$I->seeElement('.match-star-3');
$I->seeElement('.match-main .match-nav a:nth-child(3)');
$I->click('.match-main .match-nav a:nth-child(3)');
$I->waitForElement('.match-sort-wrap');
$I->seeElement('.J-MatchOrder .sort-h');
$I->click('.J-MatchOrder a:nth-child(2)');
$I->wait(2);
$I->click('.J-MatchOrder a:nth-child(3)');
$I->wait(2);
$I->click('.J-MatchOrder a:nth-child(4)');
$I->wait(2);
$I->seeElement('.match-main .match-nav a:nth-child(1)');
$I->click('.match-main .match-nav a:nth-child(1)');
$I->waitForElement('.matchsp');
$I->waitForElement('.matchdate');
$I->see('大赛');
$I->see('日常比赛');

$I->amGoingTo('参加大赛');
$I->seeElement('.J-bigMatchList');
$I->wait(5);
$isMatch = $I->executeJS('var isVisible = $(".J-bigMatchList .nodata").is(":visible");return isVisible;');
if($isMatch){
	codecept_debug('暂无比赛数据测试');
}else{
$I->click('.J-bigMatchList li:first-child .J-bigMatchUrl');
//第四个p标签是参赛,第六个p是报名人数
$isEndMatch = $I->executeJS('var isVisible = $(".p2 p:nth-child(4) .J-confirmMatch").is(":visible");return isVisible;');
if($isEndMatch){
$I->click('.p2 p:nth-child(4) .J-confirmMatch');
$I->wait(2);
$isMember = $I->executeJS('var isVisible = $(".uBoxWrapConfirm .wrapControl button:nth-child(1)").is(":visible");return isVisible;');
if($isMember){
$I->click('.uBoxWrapConfirm .wrapControl button:nth-child(1)');
$I->waitForElement('.match-confirm .ft .opts .J-startMatch');
$I->click('.match-confirm .ft .opts .J-startMatch');
$I->waitForElement('.um-manswer-feedback .submit .J-startPractic');//开始战斗标签
$I->click('.um-manswer-feedback .submit .J-startPractic');
$I->wait(5);
$I->amGoingTo('作答一下看看');
for($i = 0; $i < 10; $i++){
$encodeEsId = (string)$I->executeJS(<<<JS
	if(!Esp.oLastQuestion){
		return '';
	}
	return Esp.oLastQuestion.data('es').id;
JS
);
if(!$encodeEsId){
	//停止测试
	return;
}

$I->assertNotEquals('', $encodeEsId, '题目ID应该不为空的');
$decodeEsId = (int)Xxtea::decrypt($encodeEsId);
$mEs = Es::findOne($decodeEsId);	//从本地数据库读出这一题的模型
if(!$mEs){
	//由于本地没有这条题目,退出测试
	return;
}
$I->see('出招');
$oUnitTester = new \Codeception\TestCase\Test();	//由于 $I 是一个页面测试器,无法执行 assertInstanceOf ,所以new这个单元测试器来借方法用一下
$oUnitTester->assertInstanceOf('common\model\Es', $mEs, '应该是一个题目模型实例');

$xAnswer = $mEs->getAnswer();	//获取可填充的答案
if(!is_scalar($xAnswer)){
	$xAnswer = json_encode($xAnswer);
}
$xAnswer = 1;
codecept_debug('=======题目' . $mEs->id . '答案start' . PHP_EOL);
codecept_debug($xAnswer);
codecept_debug('=======题目答案end' . PHP_EOL);
$I->executeJS('Esp.oLastQuestion.writeAnswer(' .  $xAnswer . ');');	//填写答案

$I->wait(2);	//暂停运行2秒
$I->executeJS(<<<JS
$('.um-manswer-feedback .submit .um-btn').click();
JS
);	//通过注入脚本来实现点击出招也可以
$I->wait(2);	//暂停运行5秒,等页面异步请求完毕
}
//根据测试结果不理想建议去闯关.
$isNeedPractice = $I->executeJS('var isVisible = $(".um-recommend-mission .title").is(":visible");return isVisible;');
if($isNeedPractice){
	$I->see('强化修炼');
	codecept_debug('需要去强化训练');

}
$I->click('.match-complete .ft .opts .J-receiveGold');
$I->waitForElement('.match-complete .bd .J-tipsGoldMsg');
$I->wait(3);
$I->click('.ft .J-againDiv .um-btn');
$I->wait(5);
}
}
}


$I->amGoingTo('再次参加大赛');
//第四个p标签是参赛,第六个p是报名人数
$isEndMatch = $I->executeJS('var isVisible = $(".p2 p:nth-child(4) .J-confirmMatch").is(":visible");return isVisible;');
if($isEndMatch){
$I->click('.p2 p:nth-child(4) .J-confirmMatch');
$I->wait(2);
$isMember = $I->executeJS('var isVisible = $(".uBoxWrapConfirm .wrapControl button:nth-child(1)").is(":visible");return isVisible;');
if($isMember){
$I->click('.uBoxWrapConfirm .wrapControl button:nth-child(1)');
$I->waitForElement('.match-confirm .ft .opts .J-startMatch');
$I->click('.match-confirm .ft .opts .J-startMatch');
$I->waitForElement('.um-manswer-feedback .submit .J-startPractic');//开始战斗标签
$I->click('.um-manswer-feedback .submit .J-startPractic');
$I->wait(5);
$I->amGoingTo('作答一下看看');
for($i = 0; $i < 10; $i++){
$encodeEsId = (string)$I->executeJS(<<<JS
	if(!Esp.oLastQuestion){
		return '';
	}
	return Esp.oLastQuestion.data('es').id;
JS
);
if(!$encodeEsId){
	//停止测试
	return;
}

$I->assertNotEquals('', $encodeEsId, '题目ID应该不为空的');
$decodeEsId = (int)Xxtea::decrypt($encodeEsId);
$mEs = Es::findOne($decodeEsId);	//从本地数据库读出这一题的模型
if(!$mEs){
	//由于本地没有这条题目,退出测试
	return;
}
$I->see('出招');
$oUnitTester = new \Codeception\TestCase\Test();	//由于 $I 是一个页面测试器,无法执行 assertInstanceOf ,所以new这个单元测试器来借方法用一下
$oUnitTester->assertInstanceOf('common\model\Es', $mEs, '应该是一个题目模型实例');

$xAnswer = $mEs->getAnswer();	//获取可填充的答案
if(!is_scalar($xAnswer)){
	$xAnswer = json_encode($xAnswer);
}
codecept_debug('=======题目' . $mEs->id . '答案start' . PHP_EOL);
codecept_debug($xAnswer);
codecept_debug('=======题目答案end' . PHP_EOL);
$I->executeJS('Esp.oLastQuestion.writeAnswer(' .  $xAnswer . ');');	//填写答案

$I->wait(2);	//暂停运行2秒
$I->executeJS(<<<JS
$('.um-manswer-feedback .submit .um-btn').click();
JS
);	//通过注入脚本来实现点击出招也可以
$I->wait(2);	//暂停运行5秒,等页面异步请求完毕
}
//根据测试结果不理想建议去闯关.
$isNeedPractice = $I->executeJS('var isVisible = $(".um-recommend-mission .title").is(":visible");return isVisible;');
$I->wait(5);
if($isNeedPractice){
	$I->see('强化修炼');
	codecept_debug('需要去强化训练');

}
$I->click('.match-complete .ft .opts .J-receiveGold');
$I->waitForElement('.match-complete .bd .J-tipsGoldMsg');
$I->wait(3);
$I->click('.ft .J-againDiv .um-btn');
$I->wait(5);
}
}

$I->click('.v3-match');
$I->waitForElement('.match-main .match-nav');
$I->amGoingTo('参加日常');
$I->seeElement('.J-bigMatchList');
$I->wait(5);
$isMatch = $I->executeJS('var isVisible = $(".matchdate .J-dailyMatchList .nodata").is(":visible");return isVisible;');
if($isMatch){
	codecept_debug('暂无比赛数据测试');
}else{
$I->click('.matchdate .J-dailyMatchList li:first-child a .match-img');
//第四个p标签是参赛,第六个p是报名人数
$isEndMatch = $I->executeJS('var isVisible = $(".p2 p:nth-child(4) .J-confirmMatch").is(":visible");return isVisible;');
if($isEndMatch){
$I->click('.p2 p:nth-child(4) .J-confirmMatch');
$I->wait(2);
$isMember = $I->executeJS('var isVisible = $(".uBoxWrapConfirm .wrapControl button:nth-child(1)").is(":visible");return isVisible;');
if($isMember){
$I->click('.uBoxWrapConfirm .wrapControl button:nth-child(1)');
$I->waitForElement('.match-confirm .ft .opts .J-startMatch');
$I->click('.match-confirm .ft .opts .J-startMatch');
$I->waitForElement('.um-manswer-feedback .submit .J-startPractic');//开始战斗标签
$I->click('.um-manswer-feedback .submit .J-startPractic');
$I->wait(5);
$I->amGoingTo('作答一下看看');
for($i = 0; $i < 5; $i++){
$encodeEsId = (string)$I->executeJS(<<<JS
	if(!Esp.oLastQuestion){
		return '';
	}
	return Esp.oLastQuestion.data('es').id;
JS
);
if(!$encodeEsId){
	//停止测试
	return;
}

$I->assertNotEquals('', $encodeEsId, '题目ID应该不为空的');
$decodeEsId = (int)Xxtea::decrypt($encodeEsId);
$mEs = Es::findOne($decodeEsId);	//从本地数据库读出这一题的模型
if(!$mEs){
	//由于本地没有这条题目,退出测试
	return;
}
$I->see('出招');
$oUnitTester = new \Codeception\TestCase\Test();	//由于 $I 是一个页面测试器,无法执行 assertInstanceOf ,所以new这个单元测试器来借方法用一下
$oUnitTester->assertInstanceOf('common\model\Es', $mEs, '应该是一个题目模型实例');

$xAnswer = $mEs->getAnswer();	//获取可填充的答案
if(!is_scalar($xAnswer)){
	$xAnswer = json_encode($xAnswer);
}
$xAnswer = 1;
codecept_debug('=======题目' . $mEs->id . '答案start' . PHP_EOL);
codecept_debug($xAnswer);
codecept_debug('=======题目答案end' . PHP_EOL);
$I->executeJS('Esp.oLastQuestion.writeAnswer(' .  $xAnswer . ');');	//填写答案

$I->wait(2);	//暂停运行2秒
$I->executeJS(<<<JS
$('.um-manswer-feedback .submit .um-btn').click();
JS
);	//通过注入脚本来实现点击出招也可以
$I->wait(2);	//暂停运行5秒,等页面异步请求完毕
}
//根据测试结果不理想建议去闯关.
$isNeedPractice = $I->executeJS('var isVisible = $(".um-recommend-mission .title").is(":visible");return isVisible;');
if($isNeedPractice){
	$I->see('强化修炼');
	codecept_debug('需要去强化训练');

}
$I->click('.match-complete .ft .opts .J-receiveGold');
$I->waitForElement('.match-complete .bd .J-tipsGoldMsg');
$I->wait(3);
$I->click('.ft .J-againDiv .um-btn');
$I->wait(5);
}
}
}

$I->amGoingTo('再次参加日常比赛');
//第四个p标签是参赛,第六个p是报名人数
$isEndMatch = $I->executeJS('var isVisible = $(".p2 p:nth-child(4) .J-confirmMatch").is(":visible");return isVisible;');
if($isEndMatch){
$I->click('.p2 p:nth-child(4) .J-confirmMatch');
$I->wait(2);
$isMember = $I->executeJS('var isVisible = $(".uBoxWrapConfirm .wrapControl button:nth-child(1)").is(":visible");return isVisible;');
if($isMember){
$I->click('.uBoxWrapConfirm .wrapControl button:nth-child(1)');
$I->waitForElement('.match-confirm .ft .opts .J-startMatch');
$I->click('.match-confirm .ft .opts .J-startMatch');
$I->waitForElement('.um-manswer-feedback .submit .J-startPractic');//开始战斗标签
$I->click('.um-manswer-feedback .submit .J-startPractic');
$I->wait(5);
$I->amGoingTo('作答一下看看');
for($i = 0; $i < 5; $i++){
$encodeEsId = (string)$I->executeJS(<<<JS
	if(!Esp.oLastQuestion){
		return '';
	}
	return Esp.oLastQuestion.data('es').id;
JS
);
if(!$encodeEsId){
	//停止测试
	return;
}

$I->assertNotEquals('', $encodeEsId, '题目ID应该不为空的');
$decodeEsId = (int)Xxtea::decrypt($encodeEsId);
$mEs = Es::findOne($decodeEsId);	//从本地数据库读出这一题的模型
if(!$mEs){
	//由于本地没有这条题目,退出测试
	return;
}
$I->see('出招');
$oUnitTester = new \Codeception\TestCase\Test();	//由于 $I 是一个页面测试器,无法执行 assertInstanceOf ,所以new这个单元测试器来借方法用一下
$oUnitTester->assertInstanceOf('common\model\Es', $mEs, '应该是一个题目模型实例');

$xAnswer = $mEs->getAnswer();	//获取可填充的答案
if(!is_scalar($xAnswer)){
	$xAnswer = json_encode($xAnswer);
}
codecept_debug('=======题目' . $mEs->id . '答案start' . PHP_EOL);
codecept_debug($xAnswer);
codecept_debug('=======题目答案end' . PHP_EOL);
$I->executeJS('Esp.oLastQuestion.writeAnswer(' .  $xAnswer . ');');	//填写答案

$I->wait(2);	//暂停运行2秒
$I->executeJS(<<<JS
$('.um-manswer-feedback .submit .um-btn').click();
JS
);	//通过注入脚本来实现点击出招也可以
$I->wait(2);	//暂停运行5秒,等页面异步请求完毕
}
//根据测试结果不理想建议去闯关.
$isNeedPractice = $I->executeJS('var isVisible = $(".um-recommend-mission .title").is(":visible");return isVisible;');
$I->wait(5);
if($isNeedPractice){
	$I->see('强化修炼');
	codecept_debug('需要去强化训练');

}
$I->click('.match-complete .ft .opts .J-receiveGold');
$I->waitForElement('.match-complete .bd .J-tipsGoldMsg');
$I->wait(3);
$I->click('.ft .J-againDiv .um-btn');
$I->wait(5);
}
}


$I->amGoingTo('比赛测试主页面概览');
$I->click('.v3-match');
$I->waitForElement('.match-main .match-nav');
$I->see('全部比赛');
$I->see('比赛之星');
$I->see('我的比赛');
$I->see('我的奖牌');
$I->seeElement('.um-mmymedal .sp');
$I->see('更多详情');
$I->click('.um-mmymedal .sp');
$I->wait(3);
$I->click('.v3-match');
$I->waitForElement('.match-main .match-nav');
$I->see('我的比赛');
$I->see('相关话题');
//进入话题 相关话题
$I->seeElement('.um-mtopic .hd .sp');
$I->click('.um-mtopic .hd .sp');
$I->wait(3);
$I->click('.v3-match');
$I->waitForElement('.match-main .match-nav');
$I->see('奖牌排行榜');
$I->seeElement('.madalrank-list .caption');
$I->see('排名');
$I->see('金牌');
$I->see('银牌');
$I->see('铜牌');
$I->see('总数');
$I->seeElement('.J-MedalPagination .J-next-dan-btn');
$I->click('.J-MedalPagination .J-next-dan-btn');
$I->waitForElement('.J-MedalPagination .J-prev-dan-btn');
$I->click('.J-MedalPagination .J-next-dan-btn');

$I->wait(3);
$I->amGoingTo('退出登陆');
$I->moveMouseOver('.um-opts-set');	//鼠标移动到这个元素上,使它触发hover事件出现另一个DOM
$I->waitForElement('.um-opts-set .um-msubset .um-opts-subset-ft a');
$I->click('#header .unstyled .um-opts-set .um-msubset .um-opts-subset-ft a');	//退出登陆的按钮,这是hover后才出来的,不可见元素不可点击













