<?php
codecept_debug('run ' . __FILE__);
include(__DIR__ . '/../config/before_boot.php');