<?php
namespace Codeception\Module;

/**
 * 单元测试助手
 */
class UnitHelper extends \Codeception\Module
{
	use \umtest\UnitHelperTrait;
}
