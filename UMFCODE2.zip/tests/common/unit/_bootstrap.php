<?php
include(__DIR__ . '/../../config/before_boot.php');
defined('YII_APP_BASE_PATH') or define('YII_APP_BASE_PATH', dirname(dirname(dirname(dirname(__DIR__)))));
require(YII_APP_BASE_PATH . '/../config-local.php');

defined('YII_BACKEND_TEST_ENTRY_URL') or define('YII_BACKEND_TEST_ENTRY_URL', parse_url(\Codeception\Configuration::config()['config']['test_entry_url'], PHP_URL_PATH));

defined('YII_TEST_BACKEND_ENTRY_FILE') or define('YII_TEST_BACKEND_ENTRY_FILE', YII_APP_BASE_PATH . '/apps/home/web/index-test.php');


// the entry script file path for functional and acceptance tests
$_SERVER['SCRIPT_FILENAME'] = YII_TEST_BACKEND_ENTRY_FILE;
$_SERVER['SCRIPT_NAME'] = YII_BACKEND_TEST_ENTRY_URL;
$_SERVER['SERVER_NAME'] =  parse_url(\Codeception\Configuration::config()['config']['test_entry_url'], PHP_URL_HOST);
$_SERVER['SERVER_PORT'] =  parse_url(\Codeception\Configuration::config()['config']['test_entry_url'], PHP_URL_PORT) ?: '80';

Yii::setAlias('@tests', dirname(dirname(__DIR__)));
$GLOBALS['aLocal'] = $aLocal;
$oAppCreater = new \common\lib\AppCreater(['appId' => 'home']);
$oAppCreater->on($oAppCreater::EVENT_AFTER_GET_APP_CONFIG, function($oEvent){
	$aTestConfig = require(dirname(dirname(__DIR__)) . '/config/home/unit.php');
	$oEvent->aConfig = \yii\helpers\ArrayHelper::merge($oEvent->aConfig, $aTestConfig);
});
$app = $oAppCreater->createApp();
$app->db->serverStatusCache = '';