<?php
namespace tests\common\framework;

use Yii;
use umeworld\lib\FileLogTarget;

/**
 * 文件日志记录器测试用例
 * @author 黄文非
 */
class FileLogTargetTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\home\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
		$testMethod = $this->getName();
		if($testMethod == 'testFilterMessageByCategory'){
			Yii::getLogger()->messages = [];	//清空日志,以免记录到项目runtime目录中
		}
    }

    /**
	 * 测试日志过滤器是否能正确按照 aFilterCategorys 属性的配置去过滤
	 */
    public function testFilterMessageByCategory()
    {
		$oLogger = Yii::getLogger();
		$oLogger->flush();
		$oTarget = new FileLogTarget([
			'aFilterCategorys' => [
				'a\b*'
			],
		]);

		Yii::info('消息1,将会被上面定义的 a\b\* 规则过滤掉', 'a\b\c');
		Yii::info('消息2,过滤后就会剩下这条消息了', 'a\d\c');
		$aAllMessages = $oLogger->messages;	//获取消息列表
		$aFilterMessagesResult = $oTarget->filterMessageByCategory($aAllMessages);
		$this->assertEquals(count($aAllMessages) - 1, count($aFilterMessagesResult), '过滤后的消息数应该比原始消息队列少1条');
		$oLogger->flush();
    }

}