<?php
namespace tests\common\framework;

use umeworld\lib\StringHelper;

class StringHelperTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

     /**
     * 测试创建字符串函数
     * @author zhangliping
     */
    public function testBuildRandomString()
    {
       $min = 2;
       $max = 4;
       //随机纯数字
       $resultNumber  = StringHelper::buildRandomString($min, $max, StringHelper::MODE_NUMBER);
       //随机纯字母
       $resultLetter = StringHelper::buildRandomString($min, $max, StringHelper::MODE_LETTER);
       //随机纯符号
       $resultPoint = StringHelper::buildRandomString($min, $max, StringHelper::MODE_POINT);
       //随机纯中文
       $resultChinese = StringHelper::buildRandomString($min, $max, StringHelper::MODE_CHINESE);
       //随机数字和字母组合
       $resultNumberLetter = StringHelper::buildRandomString($min, $max, StringHelper::MODE_NUMBER + StringHelper::MODE_LETTER);
       $resultNumberPoint = StringHelper::buildRandomString($min, $max, StringHelper::MODE_NUMBER + StringHelper::MODE_POINT);
       $resultNumberChinese = StringHelper::buildRandomString($min, $max, StringHelper::MODE_NUMBER + StringHelper::MODE_CHINESE);
       $resultLetterPoint = StringHelper::buildRandomString($min, $max, StringHelper::MODE_LETTER + StringHelper::MODE_POINT);
       $resultLetterChinese = StringHelper::buildRandomString($min, $max, StringHelper::MODE_LETTER + StringHelper::MODE_CHINESE);
       $resultPointChinese = StringHelper::buildRandomString($min, $max, StringHelper::MODE_POINT + StringHelper::MODE_CHINESE);
      //断言随机产生的数字字符串
       $this->assertInternalType('string', $resultNumber);
       $this->assertTrue(is_numeric($resultNumber));
       $flag = preg_match('/^[0-9]+$/i', $resultNumber);
       $this->assertEquals(1, $flag);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultNumber));
       $this->assertLessThanOrEqual($max, mb_strlen($resultNumber));
       //断言随机产生的英文字符串
       $this->assertInternalType('string', $resultLetter);
       $this->assertTrue(ctype_alpha($resultLetter));
       $flag = preg_match('/^[a-zA-Z]+$/i', $resultLetter);
       $this->assertEquals(1, $flag);
       $this->assertGreaterThanOrEqual($min, strlen($resultLetter));
       $this->assertLessThanOrEqual($max, strlen($resultLetter));
       //断言随机产生的英文字符
       $this->assertInternalType('string', $resultPoint);
       $flag = preg_match('((?=[\x21-\x7e]+)[^A-Za-z0-9])', $resultPoint);
       $this->assertEquals(1, $flag);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultPoint));
       $this->assertLessThanOrEqual($max, mb_strlen($resultPoint));
       //断言随机产生的中文字符
       $this->assertInternalType('string', $resultChinese);
       $flag = preg_match('/[\x{4e00}-\x{9fa5}]+/u', $resultChinese);
       $this->assertEquals(1, $flag);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultChinese));
       $this->assertLessThanOrEqual($max, mb_strlen($resultChinese,'utf8'));

       //中文和数字组合
       $this->assertInternalType('string', $resultNumberLetter);
       $flag = preg_match('/^[a-zA-Z0-9]+$/i', $resultNumberLetter);
       $this->assertEquals(1, $flag);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultNumberLetter));
       $this->assertLessThanOrEqual($max, mb_strlen($resultNumberLetter));

       $this->assertInternalType('string', $resultNumberPoint);
       $this->assertGreaterThanOrEqual($min, strlen($resultNumberPoint));
       $this->assertLessThanOrEqual($max, strlen($resultNumberPoint));

       $this->assertInternalType('string', $resultNumberChinese);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultNumberChinese, 'utf8'));
       $this->assertLessThanOrEqual($max, mb_strlen($resultNumberChinese, 'utf8'));

       $this->assertInternalType('string', $resultLetterPoint);
       $this->assertGreaterThanOrEqual($min, strlen($resultLetterPoint));
       $this->assertLessThanOrEqual($max, strlen($resultLetterPoint));

       $this->assertInternalType('string', $resultLetterChinese);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultLetterChinese, 'utf8'));
       $this->assertLessThanOrEqual($max, mb_strlen($resultLetterChinese, 'utf8'));

       $this->assertInternalType('string', $resultPointChinese);
       $this->assertGreaterThanOrEqual($min, mb_strlen($resultPointChinese, 'utf8'));
       $this->assertLessThanOrEqual($max, mb_strlen($resultPointChinese, 'utf8'));

    }
    /**
     * 测试截取字符串函数
     * @author  zhnagliping
     */
    public function testDeleteString()
    {
       $str = "afa中国@f.t";
       $min = 3;
       $max = 4;
       $offset = 0;
       $len = mb_strlen($str, 'utf-8');
       $result = StringHelper::deleteString($str, $min, $max, $offset);
       $length = mb_strlen($result, 'utf-8');
       $this->assertLessThanOrEqual(6,  $length);
       $this->assertGreaterThanOrEqual(5,  $length);
       $this->assertInternalType('string', $result);
    }

}