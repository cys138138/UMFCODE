<?php
namespace tests\common\framework;

use Yii;
use umeworld\lib\Query;
use common\model\Student;

class ConnectionTest extends \Codeception\TestCase\Test
{
	private $_newLoginLogId = 0;

    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
		$testMethod = $this->getName();
		if($testMethod == 'testGetLastSqls'){
			if($this->_newLoginLogId){
				$this->assertEquals(1, (new Query)->createCommand()->delete(Student::loginLogTableName(), [
					'id' => $this->_newLoginLogId,
				])->execute(), '删除测试数据失败');
			}
		}
    }

    /*
	 * 测试解析表别名
	 * @author 黄文非
	 */
    public function testParseTable()
    {
		$oDbConnection = Yii::createObject([
			'class' => 'umeworld\lib\Connection',
			'aTables' => [
				'abc' => 'table:db1.xyz',
				'bbc' => 'table:db2.ijk;cache:0;',
				'db2qq' => 'table:db2.qqq;cache:1;',
				'no_table_name' => 'cache:1;',
				'no_table_name2' => 'cache:0',
			],
		]);

		$this->assertEquals('aaa', $oDbConnection->parseTable('aaa'));	//无别名描述符

		$this->assertEquals('ccc', $oDbConnection->parseTable('_@ccc'));	//带别名描述符,但没配置
		$this->assertEquals('ccc', $oDbConnection->parseTable('_@ccc', false)['table']);	//结构体方式

		$this->assertEquals('db1.xyz', $oDbConnection->parseTable('_@abc'));	//从配置获取
		$this->assertEquals('db1.xyz', $oDbConnection->parseTable('_@abc', false)['table']);	//结构体方式

		$this->assertEquals('db2.ijk', $oDbConnection->parseTable('_@bbc'));	//多信息下的解析
		$aTableConfig = $oDbConnection->parseTable('_@bbc', false);
		$this->assertEquals('db2.ijk', $aTableConfig['table']);
		$this->assertEquals(0, $aTableConfig['cache']);	//缓存控制解析

		$this->assertEquals(1, $oDbConnection->parseTable('_@db2qq', false)['cache']);
		$this->assertEquals('no_table_name', $oDbConnection->parseTable('_@no_table_name'));	//缺少表名配置的解析

		$this->assertEquals(0, $oDbConnection->parseTable('no_table_name2', false)['cache']);
    }

	/**
	 * 测试获取上一条SQL语句
	 */
	public function testGetLastSqls() {
		$aCacheControl = ['isSelectFromCache' => false];
		//表达式查询
		$oQuery1 = (new Query($aCacheControl))->select(['result' => new \yii\db\Expression('1+2')]);
		$oCommand1 = $oQuery1->createCommand();
		$this->assertEquals(1, $oCommand1->execute(), 'SQL执行失败,可能因为服务器繁忙');
		$aLastSqls = Yii::$app->db->getLastSqls();
		$this->assertInternalType('array', $aLastSqls, '获取上一条的时候返回了非数组');
		$this->assertEquals(1, count($aLastSqls), '获取上一条失败');
		$this->assertEquals($oCommand1->rawSql, $aLastSqls[0], '上一条SQL语句不相同');

		//从表里查询
		$oCommand2 =	(new Query($aCacheControl))
						->select(['id'])
						->from(Student::tableName())
						->where(['id' => Yii::$app->test->commonStudent->id])->createCommand();
		$oCommand2->execute();
		$aLastSqls2 = Yii::$app->db->getLastSqls();
		$this->assertInternalType('array', $aLastSqls2, '第2次获取上一条的时候返回了非数组');
		$this->assertEquals(1, count($aLastSqls2), '第2次获取上一条失败');
		$this->assertEquals($oCommand2->rawSql, $aLastSqls2[0], '上一条SQL语句不相同');


		$aLastSqls3 = Yii::$app->db->getLastSqls(2);
		$this->assertInternalType('array', $aLastSqls3, '获取上两条失败');
		//获取多条
		$this->assertEquals([
			$oCommand2->rawSql,
			$oCommand1->rawSql,
		], $aLastSqls3, '上两条SQL不匹配');


		//在DML语句执行下的多条获取
		$oCommand3 =	(new Query($aCacheControl))
						->createCommand()
						->insert(Student::loginLogTableName(), [
							'user_id' => '123',
						]);
		$oCommand3->execute();
		$this->_newLoginLogId = Yii::$app->db->getLastInsertID();
		$aLastSqls4 = Yii::$app->db->getLastSqls(3);
		$this->assertInternalType('array', $aLastSqls4, '在有DML语句的情况下获取上三条失败');
		$this->assertEquals([
			$oCommand3->rawSql,
			$oCommand2->rawSql,
			$oCommand1->rawSql,
		], $aLastSqls4, '上3条SQL语句不匹配,实际数据是' . PHP_EOL . var_export($aLastSqls4, true));


		//关键字获取
		$aLastSqls5 = Yii::$app->db->getLastSqls(1, 'user');
		$this->assertInternalType('array', $aLastSqls5, '在有DML语句的情况下获取上三条失败');
		$this->assertEquals($oCommand3->rawSql, $aLastSqls5[0], '按关键字获取失败');
	}
}