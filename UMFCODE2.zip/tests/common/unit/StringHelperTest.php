<?php
namespace tests\common;

use umeworld\lib\StringHelper;

class StringHelperTest extends \Codeception\TestCase\Test
{
    /**
     * @测试String类的方法
	 * @zhangliping
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    /**
     * 测试创建字符串函数
     * @author zhangliping
     */
    public function testBuildRandomString()
    {
       $_min = 2;
       $_max = 4;
       //随机纯数字
       $resultNumber  = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_NUMBER);
       //随机纯字母
       $resultLetter = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_LETTER);
       //随机纯符号
       $resultPoint = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_POINT);
       //随机纯中文
       $resultChinese = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_CHINESE);
       //随机数字和字母组合
       $resultNumberLetter = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_NUMBER + StringHelper::MODE_LETTER);
       $resultNumberPoint = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_NUMBER + StringHelper::MODE_POINT);
       $resultNumberChinese = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_NUMBER + StringHelper::MODE_CHINESE);
       $resultLetterPoint = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_LETTER + StringHelper::MODE_POINT);
       $resultLetterChinese = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_LETTER + StringHelper::MODE_CHINESE);
       $resultPointChinese = StringHelper::buildRandomString($_min, $_max, StringHelper::MODE_POINT + StringHelper::MODE_CHINESE);
      //断言随机产生的数字字符串
       $this->assertInternalType('string', $resultNumber);
       $this->assertTrue(is_numeric($resultNumber));
       $flag = preg_match('/^[0-9]+$/i', $resultNumber);
       $this->assertEquals(1,$flag);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultNumber));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultNumber));
       //断言随机产生的英文字符串
       $this->assertInternalType('string', $resultLetter);
       $this->assertTrue(ctype_alpha($resultLetter));
       $flag = preg_match('/^[a-zA-Z]+$/i', $resultLetter);
       $this->assertEquals(1, $flag);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultLetter));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultLetter));
       //断言随机产生的英文字符
       $this->assertInternalType('string', $resultPoint);
       $flag = preg_match('((?=[\x21-\x7e]+)[^A-Za-z0-9])', $resultPoint);
       $this->assertEquals(1,$flag);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultPoint));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultPoint));
       //断言随机产生的中文字符
       $this->assertInternalType('string', $resultChinese);
       $flag = preg_match('/[\x{4e00}-\x{9fa5}]+/u', $resultChinese);
       $this->assertEquals(1,$flag);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultChinese));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultChinese,'utf8'));

       //中文和数字组合
       $this->assertInternalType('string', $resultNumberLetter);
       $flag = preg_match('/^[a-zA-Z0-9]+$/i', $resultNumberLetter);
       $this->assertEquals(1,$flag);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultNumberLetter));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultNumberLetter));

       $this->assertInternalType('string', $resultNumberPoint);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultNumberPoint));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultNumberPoint));

       $this->assertInternalType('string', $resultNumberChinese);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultNumberChinese, 'utf8'));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultNumberChinese, 'utf8'));

       $this->assertInternalType('string', $resultLetterPoint);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultLetterPoint));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultLetterPoint));

       $this->assertInternalType('string', $resultLetterChinese);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultLetterChinese, 'utf8'));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultLetterChinese, 'utf8'));

       $this->assertInternalType('string', $resultPointChinese);
       $this->assertGreaterThanOrEqual($_min, mb_strlen($resultPointChinese, 'utf8'));
       $this->assertLessThanOrEqual($_max, mb_strlen($resultPointChinese, 'utf8'));

    }
    /**
     * 测试截取字符串函数
     * @author  zhnagliping
     */
    public function testDeleteString()
    {
       $str = "afa中国@f.t";
       $min = 0;
       $max = 0;
       $offset = 4;
       $result = StringHelper::deleteString($str, $min, $max, $offset);
       $this->assertInternalType('string', $result);
    }

}