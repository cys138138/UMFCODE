<?php
namespace tests\common\sns;

use Yii;
use common\model\Thread;

class ThreadTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

   	/**
	 * 测试增加和删除方法
	 */
    public function testAdddelete()
    {
		$id = $this->_addTest();
		$this->tester->seeInDatabase('bbs_thread', array('id' => $id));

		$mThread = Thread::findOne($id);
		$this->assertInstanceOf('common\model\Thread', $mThread);
		$mThread->delete();
		$this->tester->dontSeeInDatabase('bbs_thread', array('id' => $id));
    }

	/**
	 * 测试保存方法
	 */
	public function testSave()
    {
		$id = $this->_addTest();
		$this->tester->seeInDatabase('bbs_thread', array('id' => $id));
		$mThread = Thread::findOne($id);
		$this->assertInstanceOf('common\model\Thread', $mThread);
		$mThread->set('title', '测试2');
		$mThread->set('content', '内容2');
		$save = $mThread->save();
		$this->assertTrue($save ? true : false);
		$mThread->delete();
		$this->tester->dontSeeInDatabase('bbs_thread', array('id' => $id));
	}

	/**
	 * 测试获取列表方法
	 */
	public function testGetList()
    {
		$aCondition = [
	 		'is_top'	=> 0,
	 		'is_recommend'	=> 0,
		];
		$aList = Thread::getThreadIndexList($aCondition, [], 1, 5);
		foreach($aList as $aThread){
			$this->assertTrue(is_array($aThread));
		}
		$num = Thread::getThreadCount($aCondition);
		$this->assertTrue(is_numeric($num));
	}

	/**
	 * 测试获取评论数，帖子数等方法
	 */
	public function testGetCount()
    {
		$aCondition = [
	 		'is_top'	=> 0,
	 		'is_recommend'	=> 0,
		];
		$threadCount = Thread::getThreadCount($aCondition);
		$this->assertTrue(is_numeric($threadCount));

		$userThreadCount = Thread::getUserThreadCount(Yii::$app->test->commonStudent->id);
		$this->assertTrue(is_numeric($userThreadCount));

		$id = $this->_addTest();
		$this->tester->seeInDatabase('bbs_thread', array('id' => $id));
		$mThread = Thread::findOne($id);
		$commentCount = $mThread->getCommentCount();
		$this->assertTrue(is_numeric($commentCount));

		$mThread->delete();
		$this->tester->dontSeeInDatabase('bbs_thread', array('id' => $id));
		//$this->assertTrue($delete ? true : false);
	}

	/**
	 * 测试获取评论列表
	 */
	public function testGetCommentList()
    {
		$aCondition = [
	 		'is_top'	=> 0,
	 		'is_recommend'	=> 0,
		];
		$aList = Thread::getThreadIndexList($aCondition, [], 1, 5);
		$aThread = $aList[0];
		$mThread = Thread::findOne($aThread['id']);
		$this->assertInstanceOf('common\model\Thread', $mThread);
		$aCommentList = $mThread->getCommentList(1, 5);
		if($aCommentList !== false){
			$this->assertTrue(true);
		}else{
			$this->assertTrue(false);
		}
	}

	private function _addTest(){
		$aData = [
			'content' => 'ABC',
			'resource_list' => [],
			'category_id' => 2,
			'classify_id' => 0,
			'title' => '测试',
			'user_id' => Yii::$app->test->commonStudent->id,
			'create_time' => NOW_TIME,
			'last_reply_time' => NOW_TIME,
			'support_times' => 0,
			'read_times' => 0,
			'is_recommend' => 0,
			'is_top' => 0,
			'status' => 2,
		];
		return Thread::add($aData);
	}

}