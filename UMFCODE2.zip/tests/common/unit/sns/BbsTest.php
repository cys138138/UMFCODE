<?php
namespace tests\commn\sns\bbs;
use common\model\ThreadComment;
use common\model\Thread;
use common\model\ThreadNotification;
use Yii;


/**
 * 话题模型测试
 * @auther 福
 */
class BbsTest extends \Codeception\TestCase\Test{
	private $_userId = 40137186;
	public function init(){
		$mStudent = (new \umeworld\lib\Query())->from('_@bbs_thread_index')->where(['and', ['status' => 2], ['>=', 'support_times', 5], ['>=', 'read_times', 200]])->one();
		Yii::$app->student->login($mStudent->user_id);
		$this->_userId = $mStudent->user_id;
	}

	/**
	 *测试读取话题列表是否正常
	 */
	public function testShowList(){
		$aDataList = Thread::getThreadIndexList(['status' => Thread::STATUS_RELEASE, 'is_top' => 0], ['user_info', 'content', 'comment_count'], 1, 20, ['create_time' => SORT_DESC]);
		$this->assertTrue(is_array($aDataList));
		if(is_array($aDataList)){
			foreach($aDataList as $key => $aTopic){
				$this->tester->assertCompareArrayStruct($aTopic, [
					'title',
					'number' => 'user_id',
					'content',
					'status',
					'category_id',
				]);
			}
		}
	}

	/**
	 *读取我的帖子是否正常
	 */
	public function testMyTopic(){
		$aDataList = Thread::getThreadIndexList(['user_id' => $this->_userId, 'status' => Thread::STATUS_RELEASE, 'category_id' => 0], ['user_info', 'category_name', 'comment_count'], 1, 20, ['create_time' => SORT_DESC]);
		$this->assertTrue(is_array($aDataList));
		if(is_array($aDataList)){
			foreach($aDataList as  $aTopic){
				$this->tester->assertCompareArrayStruct($aTopic, [
					'id',
					'title',
					'status',
					'category_id',
				]);
			}
		}
	}

	/**
	 *读取我的帖子是否正常
	 */
	public function testMyReply(){
		$aDataList = ThreadComment::getUserCommentList($this->_userId, 1, 20);
		$this->assertTrue(is_array($aDataList));
		if(is_array($aDataList)){
			foreach($aDataList as  $aTopic){
				$this->tester->assertCompareArrayStruct($aTopic, [
					'id',
					'content',
					'thread_id',
					'user_id',
					'thread_info',
				]);
			}
		}
	}

	/**
	 *我的消息通知
	 */
	public function testMyNews(){
		$aDataList = ThreadNotification::getNotificationList(['user_id' => $this->_userId], 1, 5, ['is_read' => SORT_ASC, 'id'=>SORT_DESC]);
		$this->assertTrue(is_array($aDataList));
		if(is_array($aDataList)){
			foreach($aDataList as  $aTopic){
				$this->tester->assertCompareArrayStruct($aTopic, [
					'id',
					'user_id',
					'notification_id',
					'thread_id',
				]);
				if(!isset($aTopic['parent_id'])){
					$this->assertArrayHasKey('thread_title', $aTopic);
				}
			}
		}
	}

	/**
	 *显示文章
	 */
	public function testShowTopic(){
		$oThread = Thread::findOne(39);
		if($oThread === false){
			$this->assertTrue($oThread === false);
		}else{
			$this->assertInstanceOf('common\model\Thread', $oThread);
			$this->tester->assertCompareArrayStruct($oThread->toArray(), [
				'title',
				'user_id',
				'category_id',
				'status',
			]);
		}
	}

}

