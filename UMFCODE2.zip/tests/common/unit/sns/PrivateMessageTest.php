<?php
namespace tests\common\unit\sns;

use Yii;
use \common\model\PrivateMessage;
use umeworld\lib\Query;

class PrivateMessageTest extends \Codeception\TestCase\Test{
	use \Codeception\Specify;

	private $_userId = 0;
	private $_senderUserId = 92603177;
	private $_addPrivateMessageId = 0;
 
	protected function _before(){
		$testMethod = $this->getName();
		if($testMethod != 'testAddPrivateMessage' && $testMethod != 'testDeleteThisMessage'){
			$this->_userId = \Yii::$app->test->commonStudent->id;
			$aData = [
				'sender_user_id'	=>	$this->_senderUserId,
				'receiver_user_id'	=>	$this->_userId,//19577027
				'content'			=>	'单元测试私信',
				'create_time'		=>	NOW_TIME,
				'is_read'			=>	0,
				'status'		=>	0,
			];
			$result = (new Query())->createCommand()->insert(PrivateMessage::tableName(), $aData)->execute();
			if(!$result){
				throw new \Exception('增加私信记录失败');
			}
			$this->_addPrivateMessageId = Yii::$app->db->getLastInsertID();
		}
	}

	protected function _after(){
		$testMethod = $this->getName();
		if($testMethod != 'testAddPrivateMessage' && $testMethod != 'testDeleteThisMessage'){
			if($this->_addPrivateMessageId){
				$row = Yii::$app->db->createCommand()->delete(PrivateMessage::tableName(), ['id' => $this->_addPrivateMessageId])->execute();
					if(!$row){
						throw new \Exception('删除私信记录失败');
					}
			}
		}
	}
	
	/**
	 * 测试是否有新消息
	 * @author zhangliping
	 */
	public function testHasNewMessage(){
		$isHasNewMessage = PrivateMessage::hasNewMessage($this->_userId);
		$this->assertTrue($isHasNewMessage);
	}
	/**
	 * 测试增加私信
	 * @author zhangliping
	 */
	public function testAddPrivateMessage(){
		$aData = [
			'sender_user_id'	=>	$this->_senderUserId,//8436235
			'receiver_user_id'	=>	$this->_userId,
			'content'			=>	'单元测试增加私信',
			'create_time'		=>	NOW_TIME,
			'is_read'			=>	0,
			'status'		=>	0,
		];
		$messageId = PrivateMessage::addPrivateMessage($aData);
		$this->assertGreaterThan(0, $messageId);
		$row = Yii::$app->db->createCommand()->delete(PrivateMessage::tableName(), ['id' => $messageId])->execute();
		if(!$row){
			throw new \Exception('删除私信记录失败');
		}
	}
	
	/**
	 * 测试获取小纸条列表方法
	 * @author zhangliping
	 */
	public function testGetPrivateMessageList(){
		$aConditon = [
	 		'user_id'	=>  $this->_userId ,
	 		'opposite_user_id'	=> $this->_senderUserId,
		];
		$aControl = [
			'page'	=> 15,
			'page_size'	=> 1,
		];
		$privateMessageList = PrivateMessage::getPrivateMessageList($aConditon, $aControl);
		$this->assertInternalType('array', $privateMessageList);
		foreach($privateMessageList as $detailData){
			$this->tester->assertCompareArrayStruct($detailData, [
				'id',
				'sender_user_id',
				'receiver_user_id',
				'content',
				'create_time',
				'is_read',
				'status',
				'sender_user_info' => [
					'id',
					'name',
					'profile',
				],
            ]);
        }
	}
 
	/*
	 * 测试获取小纸条总数
	 * @author zhangliping
	 */
	public function testGetPrivateMessageTotalCount(){
		$aConditon = [
	 		'user_id'	=> $this->_userId ,
	 		'opposite_user_id'	=> $this->_senderUserId,
		];
		$nums = PrivateMessage::getPrivateMessageTotalCount($aConditon);
		$this->assertGreaterThan(0, $nums);
	}

	/*
	 * 测试获取私信的条数
	 * @author zhangliping
	 */
	public function testGetPrivateMessageCount(){
	 	$aCondition = [
			'receiver_user_id' => $this->_userId,
		];
		$nums = PrivateMessage::getPrivateMessageCount($aCondition);
		$this->assertGreaterThan(0, $nums);
	}
	/**
	 * 测试标记对话为已读
	 * @author zhangliping
	 */
	public function testSetToRead(){
		$userId = $this->_userId;
		$oppositeUserId = $this->_senderUserId;
		$result = PrivateMessage::setToRead($userId, $oppositeUserId);
		$this->assertGreaterThan(0, $result);
	}
	/**
	 * 测试获取PC端私信的好友列表
	 * @author zhangliping
	 */
	public function testGetPrivateMessageFriendList(){
		$aCondtion = [
	 		'user_id'	=> $this->_userId,
		];
	    $aConrtol = [
	 		'page'	=>	1,
	 		'page_size'	=>	5,
	     ];
		$aFriendList = PrivateMessage::getPrivateMessageFriendList($aCondtion, $aConrtol);
		$this->assertInternalType('array', $aFriendList);
		foreach($aFriendList as $detailData){
			$this->tester->assertCompareArrayStruct($detailData, [
				'sender_user_id',
				'create_time',
				'is_read',
				'sender_user_info' => [
					'id',
					'name',
					'profile',
					'vip',
				],
            ]);
        }
	}
	/**
	 * 测试删除本条小纸条
	 * @author zhangliping
	 */
	public function testDeleteThisMessage(){
		$aData = [
			'sender_user_id'	=>	$this->_senderUserId, 
			'receiver_user_id'	=>	$this->_userId,
			'content'			=>	'单元测试删除本条小纸条',
			'create_time'		=>	NOW_TIME,
			'is_read'			=>	0,
			'status'		=>	0,
		];
		$messageId = PrivateMessage::addPrivateMessage($aData);
		$this->assertGreaterThan(0, $messageId);
		if(!$messageId){
			throw new \Exception('增加私信失败');
		}
		$mPrivateMessage = PrivateMessage::findOne($messageId);
		if(!$mPrivateMessage){
			throw new \Exception('实例化私信模型失败');
		}
		$result = $mPrivateMessage->deleteThisMessage($this->_senderUserId);
		$this->assertEquals(1, $result);
	}
	
	/**
	 * 测试删除用户和别人的所有会话
	 * @author zhangliping
	 */
	public function testDeleteConversation(){
		//删除用户和被人的所有会话
		$aData = [
			'sender_user_id'	=>	$this->_senderUserId, 
			'receiver_user_id'	=>	$this->_userId,
			'content'			=>	'单元测试小纸条删除和某人的会话记录',
			'create_time'		=>	NOW_TIME,
			'is_read'			=>	0,
			'status'		=>	0,
		];
		$messageId = PrivateMessage::addPrivateMessage($aData);
		if(!$messageId){
			throw new \Exception('增加私信失败');
		}
		$result = PrivateMessage::deleteConversation($this->_userId, $this->_senderUserId);
		$this->assertGreaterThan(0, $result);
	}
}
