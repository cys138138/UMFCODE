<?php
namespace tests\common\unit\sns;

use Yii;
use \common\model\UserFriend;
use \common\model\ClassRecord;
use \yii\helpers\ArrayHelper;
use umeworld\lib\Query;

class FriendTest extends \Codeception\TestCase\Test {
	use \Codeception\Specify;

	private $_userId = 0;
	private $_mFriend = null;

	private $_aUserFriendData = [];

	protected function _before(){
		$this->_userId = \Yii::$app->test->commonStudent->id;
		$this->_mFriend = UserFriend::findOne($this->_userId);
		$testMethod = $this->getName();

		if($testMethod == 'testAddRecord'){
			$this->_aUserFriendData = (new Query())->from(UserFriend::tableName())->where(['id' => $this->_userId])->one();
			if($this->_aUserFriendData){
				$row = Yii::$app->db->createCommand()->delete(UserFriend::tableName(), ['id' => $this->_userId])->execute();
				if(!$row){
					throw new \Exception('删除原始好友记录失败');
				}
			}
		}
	}

	protected function _after(){
		$testMethod = $this->getName();
		if($testMethod == 'testAddRecord'){
			Yii::$app->db->createCommand()->insert(UserFriend::tableName(), $this->_aUserFriendData)->execute();
		}
	}

	/**
	 * 测试获取好友ID列表
	 * @author jay
	 */
	public function testGetUserFriend() {
		$this->assertInstanceOf('\common\model\UserFriend', $this->_mFriend);
		//获取好友id集合
		$aFriendList = $this->_mFriend->getUserFriendIdList();
		foreach ($aFriendList as $id) {
			//检查id列表是否是数字
			$this->assertGreaterThanOrEqual(0, $id);
		}
		$this->assertGreaterThanOrEqual(0, $this->_mFriend->getFriendNums());
	}

	/**
	 * 测试模型是否正常找到UserFriend模型
	 * @author jay
	 */
	public function testFindUserFriendInstance(){
		$mUserFriend = UserFriend::findOne($this->_userId);
		$this->assertInstanceOf('\common\model\UserFriend', $mUserFriend);
	}

	/**
	 * 测试计算可能认识的人的个数
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testCheckProbablyFriends() {
		$nums = $this->_mFriend->checkProbablyFriends();
		$this->assertGreaterThan(0, $nums);
	}

	/**
	 * 测试计算可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriends() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriends();
		$this->assertInternalType('array', $aProbablyUserIds);
		$this->assertGreaterThan(0, count($aProbablyUserIds));
		$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));
	}

	/**
	 * 测试计算用户可能认识的人排除的用户id
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsSpecialUserIds() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsSpecialUserIds();
		$this->assertInternalType('array', $aProbablyUserIds);
		$this->assertGreaterThan(0, count($aProbablyUserIds));
		$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));
	}

	/**
	 * 测试计算用户同班的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromUserClass() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromUserClass();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));
			$aClassIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'class');
			$aTempClassIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $aProbablyUserIds]), 'class');
			$aIntersect = array_intersect($aClassIds, $aTempClassIds);
			$this->assertGreaterThan(0, count($aIntersect));
		}
	}

	/**
	 * 测试计算用户同校同年级的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromSameSchoolAndSameGrade() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameSchoolAndSameGrade();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));

			$aGrades = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'grade');
			$aSchoolIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'school_id');
			foreach($aProbablyUserIds as $id){
				$aTempGrades = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'grade');
				$aTempSchoolIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'school_id');
				$aGradeIntersect = array_intersect($aGrades, $aTempGrades);
				$this->assertGreaterThan(0, count($aGradeIntersect));
				$aSchoolIdsIntersect = array_intersect($aSchoolIds, $aTempSchoolIds);
				$this->assertGreaterThan(0, count($aSchoolIdsIntersect));
			}
		}
	}

	/**
	 * 测试计算用户以前同年级的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromPreviousSameGrade() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameSchoolAndSameGrade();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));

			$aGrades = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'grade');
			$aSchoolIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'school_id');
			foreach($aProbablyUserIds as $id){
				$aTempGrades = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'grade');
				$aTempSchoolIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'school_id');
				$aGradeIntersect = array_intersect($aGrades, $aTempGrades);
				$this->assertGreaterThan(0, count($aGradeIntersect));
				$aSchoolIdsIntersect = array_intersect($aSchoolIds, $aTempSchoolIds);
				$this->assertGreaterThan(0, count($aSchoolIdsIntersect));
			}
		}
	}

	/**
	 * 测试计算用户同校的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromSameSchool() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameSchool();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));

			$aSchoolIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'school_id');
			foreach($aProbablyUserIds as $id){
				$aTempSchoolIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'school_id');
				$aSchoolIdsIntersect = array_intersect($aSchoolIds, $aTempSchoolIds);
				$this->assertGreaterThan(0, count($aSchoolIdsIntersect));
			}
		}
	}

	/**
	 * 测试计算用户同地区的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromSameArea() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameArea();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));
			$aAreaIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'area_id');
			foreach($aProbablyUserIds as $id){
				$aTempAreaIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'area_id');
				$aIntersect = array_intersect($aAreaIds, $aTempAreaIds);
				$this->assertGreaterThan(0, count($aIntersect));
				break;
			}
		}
	}

	/**
	 * 测试计算用户同城市的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromSameCity() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameCity();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));

			$aCityIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'city_id');
			foreach($aProbablyUserIds as $id){
				$aTempCityIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'city_id');
				$aIntersect = array_intersect($aCityIds, $aTempCityIds);
				$this->assertGreaterThan(0, count($aIntersect));
				break;
			}
		}
	}

	/**
	 * 测试计算用户同省的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromSameProvince() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameProvince();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));

			$aProvinceIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $this->_userId]), 'province_id');
			foreach($aProbablyUserIds as $id){
				$aTempProvinceIds = ArrayHelper::getColumn(ClassRecord::findAll(['user_id' => $id]), 'province_id');
				$aIntersect = array_intersect($aProvinceIds, $aTempProvinceIds);
				$this->assertGreaterThan(0, count($aIntersect));
				break;
			}
		}
	}

	/**
	 * 测试计算用户全国的可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromSameCountry() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromSameCountry();
		$this->assertInternalType('array', $aProbablyUserIds);

		$aMyFriendIds = $this->_mFriend->getUserFriendIdList();
		foreach($aMyFriendIds as $id){
			$this->assertTrue(!isset($aProbablyUserIds[$id]));
		}
	}

	/**
	 * 测试计算用户共同好友可能认识的人
	 * @author jay
	 * @depends testFindUserFriendInstance
	 */
	public function testGetUserProbablyFriendsFromCommonFriend() {
		$aProbablyUserIds = $this->_mFriend->getUserProbablyFriendsFromCommonFriend();
		$this->assertInternalType('array', $aProbablyUserIds);
		if($aProbablyUserIds){
			$this->assertGreaterThan(0, count($aProbablyUserIds));
			$this->assertTrue(!isset($aProbablyUserIds[$this->_userId]));

			$aMyFriendIds = $this->_mFriend->getUserFriendIdList();
			foreach($aProbablyUserIds as $id){
				$mUserFriend = UserFriend::findOne($id);
				$aTempList = $mUserFriend->getUserFriendIdList();
				$aIntersect = array_intersect($aMyFriendIds, $aTempList);
				$this->assertGreaterThan(0, count($aIntersect));
				break;
			}
		}
	}

	/**
	 * 测试添加好友记录是否正常
	 * @author 黄文非
	 */
	public function testAddRecord(){
		$mUserFriend = UserFriend::add($this->_userId);
		$this->assertInstanceOf('common\model\UserFriend', $mUserFriend);
		$this->assertTrue($mUserFriend->delete());
	}
}
