<?php
namespace tests\common\unit\activity;

use Yii;
use common\model\activity\GuessScholarship;
use common\model\activity\GuessScholarshipUserRelation;
use umeworld\lib\Query;
use common\xxt\gd\InterfaceGd;

class GuessScholarshipTe2st extends \Codeception\TestCase\Test{
}