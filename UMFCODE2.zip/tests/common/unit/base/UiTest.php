<?php
namespace tests\common\base;

use Yii;
use common\model\Area;
use common\ui\CommonUi1;
use common\model\School;
use common\model\Grade;

class UiTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    /**
	 * 测试获取完整地区
	 */
    public function testGetFullAddress()
    {
		$mArea = Area::findOne(Yii::$app->test->aParams['area']['area_id']);
		$mCity = Area::findOne($mArea->pid);
		$mProvince = Area::findOne($mCity->pid);

		//测试默认的拼装
		$this->assertEquals($mProvince->name . ' ' . $mCity->name . ' ' . $mArea->name, Yii::$app->ui->getFullAddress($mArea));

		//测试换一个间隔符的拼装
		$this->assertEquals($mProvince->name . '-' . $mCity->name . '-' . $mArea->name, Yii::$app->ui->getFullAddress($mArea, '$province-$city-$area'));

		//测试调换省市区显示位置的拼装顺便换下间隔符
		$this->assertEquals($mArea->name . '_77_-' . $mCity->name . '-' . $mProvince->name, Yii::$app->ui->getFullAddress($mArea, '$area_77_-$city-$province'));
    }

    /**
	 * 测试获取完整学校信息
	 */
    public function testGetFullSchoolInfo()
    {
		$oUi = new CommonUi1();
		$mStudent = Yii::$app->test->oCommonStudent->getInstance();
		$mSchool = School::findOne($mStudent->school_id);
		$mGrade = Grade::findOne($mStudent->grade);

		//测试默认的拼装
		$this->assertEquals($mSchool->name . ' ' . $mGrade->name . ' ' . $mStudent->class, $oUi->getFullSchoolInfo($mStudent));

		//测试换一个间隔符的拼装
		$this->assertEquals($mSchool->name . '_' . $mGrade->name . '_' . $mStudent->class, $oUi->getFullSchoolInfo($mStudent, '$school_$grade_$class'));

		//测试调换省市区显示位置的拼装顺便换下间隔符
		$this->assertEquals($mStudent->class . '_77_-' . $mGrade->name . '-' . $mSchool->name, $oUi->getFullSchoolInfo($mStudent, '$class_77_-$grade-$school'));
    }

}