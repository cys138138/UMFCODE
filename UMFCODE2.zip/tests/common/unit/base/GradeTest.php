<?php
namespace tests\common\base;

use common\model\Grade as Grade;
use common\model\Subject as Subject;
use Yii;

class GradeTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;
	private $_aGradeList = [];
	private $_aSubjectList = [];
	private $_aMGradeList = [];

	protected function _before()
    {
		//获取配置数据
		$this->_aGradeList = require(Yii::getAlias('@common') . '/config/model/grade.php');
		$this->assertInternalType('array', $this->_aGradeList);
		$this->assertInternalType('array', $this->_aGradeList['grade_list']);
		$this->assertInternalType('array', $this->_aGradeList['grade_subject_relation']);

		$this->_aSubjectList = require(Yii::getAlias('@common') . '/config/model/subject.php');
		$this->assertInternalType('array', $this->_aSubjectList);
		$this->assertInternalType('array', $this->_aSubjectList['subject_list']);
		$this->assertInternalType('array', $this->_aSubjectList['subject_category_relation']);

		//获取对象组
		foreach ($this->_aGradeList['grade_list'] as $key => $value){
			$mGrade = Grade::findOne($key);
			$this->assertInstanceOf('common\model\Grade', $mGrade);
			$this->_aMGradeList[$key] = $mGrade;
		}
    }

    protected function _after()
    {
    }

	/**
	 * 获取所有年级的列表
	 * @author zhou
	 */
	public function testGetGradeList(){
		foreach ($this->_aMGradeList as $id => $mGrade){
			$aGradeList = $mGrade->getGradeList();
			$this->assertInternalType('array', $aGradeList);
			$this->assertEquals($this->_aGradeList['grade_list'], $aGradeList);
		}
	}

	/**
	 * 测试获取年级ID
	 * @author zhou
	 */
	public function testGetId(){
		foreach ($this->_aMGradeList as $id => $mGrade){
			$mGrade->getId();
			$this->assertInternalType('integer', $id);
			$this->assertEquals($id, $mGrade->id);
			$this->_mGrade = null;
		}
	}

	/**
	 * 测试获取年级名称
	 * @author zhou
	 */
	public function testGetName(){
		foreach ($this->_aMGradeList as $id => $mGrade){
			$name = $mGrade->getName();
			$this->assertInternalType('string', $name);
			$this->assertEquals($name, $mGrade->name);
			$this->_mGrade = null;
		}
	}

	/**
	 * 测试获取一个年级指定游戏场景下的科目列表
	 * @author zhou
	 */
	public function testGetSubjectList(){
		$aGames = [null, Subject::GAME_MISSION, Subject::GAME_PK];
		foreach ($aGames as $game){
			switch($game){
				case null:
					foreach ($this->_aMGradeList as $id => $mGrade){
						$aSubjectList = $mGrade->getSubjectList($game);
						$this->assertEquals($this->_aGradeList['grade_subject_relation'][$id], $aSubjectList);
					}
					break;
				case Subject::GAME_MISSION:
					foreach ($this->_aMGradeList as $id => $mGrade){
						$aSubjectList = $mGrade->getSubjectList($game);
						$aTempGradeList = $this->_aGradeList['grade_subject_relation'][$id];
						unset($aTempGradeList[4]);
						$this->assertEquals($aTempGradeList, $aSubjectList);
					}
					$aTempGradeList = null;
					break;
				case Subject::GAME_PK:
					foreach ($this->_aMGradeList as $id => $mGrade){
						$aSubjectList = $mGrade->getSubjectList($game);
						$this->assertEquals($this->_aGradeList['grade_subject_relation'][$id], $aSubjectList);
					}
					break;
			}
		}
	}

	/**
	 * @author 黄文非
	 */
	public function testIsAllowRegister() {
		for($i = Grade::MIN_GRADE; $i <= Grade::MAX_GRADE; $i++){
			$mGrade = Grade::findOne($i);
			if(!$mGrade){
				continue;
			}
			if($mGrade->id <= Grade::MAX_REGISTER_GRADE){
				$this->assertTrue($mGrade->isAllowRegister());
			}else{
				$this->assertFalse($mGrade->isAllowRegister());
			}
		}
	}

	/**
	 * 测试判断本年级是否允许某一个科目
	 * @auth zhou
	 * @depends testGetGradeList
	 */
	public function testAllowSubject(){
		foreach ($this->_aSubjectList['subject_list'] as $subjectId => $subjectName){
			foreach ($this->_aMGradeList as $gradeId => $mGrade){
				$this->assertEquals($mGrade->allowSubject($subjectId), isset($this->_aGradeList['grade_subject_relation'][$gradeId][$subjectId]));
			}
		}
	}

}