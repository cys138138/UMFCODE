<?php
namespace tests\common\base;

use Yii;
use common\model\ClassRecord;

class ClassRecordTest extends \Codeception\TestCase\Test{
	protected $_mArea = null;
	protected $_mAreaCity = null;
	protected $_aClassRecordCache = [];

	protected function _before(){
		$this->_mClassRecord = ClassRecord::findOne(['user_id' => Yii::$app->test->oCommonStudent->id]);
		$this->assertInstanceOf('common\model\ClassRecord', $this->_mClassRecord);
	}
	
	protected function _after(){
		if($this->_aClassRecordCache){
			foreach($this->_aClassRecordCache as $k => $v){
				$this->_mClassRecord->set($k, $v);
			}
			$this->_mClassRecord->save();
			$this->_aClassRecordCache = [];
		}
	}

	/**
	 * 测试ClassRecord模型的save方法
	 */
	public function testSave(){
		//backup
		$this->_aClassRecordCache = $this->_mClassRecord->toArray();
		//update
		$this->_mClassRecord->set('year', 0);
		$this->_mClassRecord->set('province_id', 0);
		$this->_mClassRecord->set('city_id', 0);
		$this->_mClassRecord->set('area_id', 0);
		$this->_mClassRecord->set('school_id', 0);
		$this->_mClassRecord->set('grade', 0);
		$this->_mClassRecord->set('class', 0);
		$this->_mClassRecord->set('is_active', 0);
		$this->_mClassRecord->save();
		//assert
		$mClassRecord = ClassRecord::findOne($this->_mClassRecord->id);
		$this->assertInstanceOf('common\model\ClassRecord', $mClassRecord);
		foreach($mClassRecord->toArray() as $key => $value){
			if(!in_array($key, ['id', 'user_id'])){
				$this->assertEquals(0, $value);
			}
		}
		
	}
}