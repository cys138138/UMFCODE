<?php
namespace tests\common\base;

use Yii;
use common\model\Es;
use common\business\Game;
use common\model\Student;
use umeworld\lib\Query;

/**
 * 题目测试
 */
class EsTest extends \Codeception\TestCase\Test{
	use \Codeception\Specify;
	  /**
     * @var \tests\common\UnitTester
     */
    protected $tester;
    protected $mEs = null;
    protected $mExitEs = null;
    protected $getAddAnalysisId = null;
    protected $getAddFeedbackId = null;
    protected $user_id = null;
    protected $commonEsId = null;
    protected $exitFeedback = null;
    protected $exitFeedbackId = null;

	protected function _before(){
		$testMethod = $this->getName();
		if($testMethod == 'testEsModelAddFeedback' || $testMethod == 'testEsModelIsFeedBacked'){
			$this->commonEsId = Yii::$app->test->aParams['commonEs']['es_id'];
			$this->mEs =  $this->_getRandomEs(['id' => $this->commonEsId]);
			$this->exitFeedback =  $this->_getRandomFeedbackEs();
			if(is_array($this->exitFeedback)){
				foreach ($this->exitFeedback as $key => $value) {
					if($key == 'user_id'){
  						$this->user_id = $value;
					}
					if($key == 'es_id'){
						$this->exitFeedbackId = $value;
					}
				}
			}else{
				$this->user_id = null;
				$this->exitFeedbackId  = null;
			}
		}
		if($testMethod == 'testEsModelAddAnalysis'){
			$this->commonEsId = Yii::$app->test->aParams['commonEs']['es_id'];
		}
	}

	protected function _after(){
		$testMethod = $this->getName();
		if($testMethod == 'testEsModelAddFeedback'){
			$compleId =  (new Query())->createCommand()->delete(Es::feedbackTableName(), ['id' => $this->getAddFeedbackId])->execute();
        	$this->assertEquals(1, $compleId);
		}
		if($testMethod == 'testEsModelAddAnalysis'){
			$this->commonEsId = Yii::$app->test->aParams['commonEs']['es_id'];
			$compleId = (new Query())->createCommand()->delete(Es::analysisTableName(), ['id' => $this->commonEsId])->execute();
        	$this->assertEquals(1, $compleId);

		}
	}

    /**
     * 测试随机获取若干个题目ID
	 * @author zhangliping
     */
	public function testEsModelGetRandomEsIdList()
	{
		$count = mt_rand(1, 5);
		$aLevel = [
			Es::LEVEL_EASY,
			Es::LEVEL_NORMAL,
			Es::LEVEL_HARD
		];
		shuffle($aLevel);
		$level = current($aLevel);
		$level = Es::LEVEL_EASY;
		$total = (new \umeworld\lib\Query())->from('_@mission')->count();
		$offset = mt_rand(0, $total - 1);
		$pageSize = 1;
		$missionId = (new \umeworld\lib\Query())->select('id')->from('_@mission')->where(['is_forbidden' => 0])->offset($offset)->limit($pageSize)->scalar();
		$mMission = \common\model\Mission::findOne($missionId);
		$this->assertInstanceOf('common\model\Mission', $mMission);
		$aEsIds = Es::getRandomEsIdList($mMission->category_ids, $count, [], $level, []);
		$this->assertEquals($count, sizeof($aEsIds));
	}

    /**
     *  测试检查答案是否正确
     */
	public function testEsModelCheckAnswer()
	{
		$aEsType = Es::getTypeList();
		foreach($aEsType as $type => $name){
			$aWhere = ['type_id' => $type, 'status' => 5];
			$total = (new \umeworld\lib\Query())->from('_@es_index')->where($aWhere)->count();
			$offset = mt_rand(0, $total - 1);
			$pageSize = 1;
			$aEs = (new \umeworld\lib\Query())->from('_@es_index')->where($aWhere)->offset($offset)->limit($pageSize)->one();

			$mEs = Es::findOne($aEs['id']);
			$this->assertInstanceOf('common\model\Es', $mEs);

			if($type == Es::TYPE_SINGLE_CHOICE){
				$this->assertTrue($mEs->validateAnswer(1));
				$this->assertFalse($mEs->validateAnswer([1]));
				$answer = $mEs->getAnswer();
				$isCorrect = $mEs->checkAnswer($answer);
				$this->assertTrue($isCorrect);
				for($i = 0; $i < count($mEs->es_content['option']); $i++){
					if($i != $answer){
						$isWrong = $mEs->checkAnswer($i);
						$this->assertFalse($isWrong);
						break;
					}
				}

			}elseif($type == Es::TYPE_MULTIPLE_CHOICE){
				$this->assertTrue($mEs->validateAnswer([1, 2]));
				$this->assertFalse($mEs->validateAnswer(1));

				$aAnswer = $mEs->getAnswer();
				$isCorrect = $mEs->checkAnswer($aAnswer);
				$this->assertTrue($isCorrect);

				for($i = 0; $i < count($mEs->es_content['option']); $i++){
					if(count($aAnswer) > 1){
						array_pop($aAnswer);
						$isWrong = $mEs->checkAnswer($aAnswer);
						$this->assertFalse($isWrong);
						break;
					}else{
						if(!in_array($mEs->es_content['option'][$i], $aAnswer)){
							array_push($aAnswer, $i);
							$isWrong = $mEs->checkAnswer($aAnswer);
							$this->assertFalse($isWrong);
							break;
						}
					}
				}

			}elseif($type == Es::TYPE_JUDGME){
				$this->assertTrue($mEs->validateAnswer(1));
				$this->assertFalse($mEs->validateAnswer([1]));

				$answer = $mEs->getAnswer();
				$isCorrect = $mEs->checkAnswer($answer);
				$this->assertTrue($isCorrect);

				if($answer){
					$isWrong = $mEs->checkAnswer(0);
					$this->assertFalse($isWrong);
				}else{
					$isWrong = $mEs->checkAnswer(1);
					$this->assertFalse($isWrong);
				}

			}elseif($type == Es::TYPE_FILL_BLANK || $type == Es::TYPE_WORD_FILL_BLANK){
				$this->assertTrue($mEs->validateAnswer([
					['a', 'b'],
					['x', 'y'],
				]));
				$this->assertFalse($mEs->validateAnswer(['a', 'b', 'c']));

				$aAnswer = $mEs->getAnswer();
				$isCorrect = $mEs->checkAnswer($aAnswer);
				$this->assertTrue($isCorrect);

				$aAnswer[0][0] .= 'Fuck';
				$isWrong = $mEs->checkAnswer($aAnswer);
				$this->assertFalse($isWrong);

			}elseif($type == Es::TYPE_COMPLEX_READING || $type == Es::TYPE_COMPLEX_FILL_BLANK){
				$aAnswer = $mEs->getAnswer();
				$index = mt_rand(0, count($aAnswer) - 1);
				$isCorrect = $mEs->checkAnswer([
					$index => $aAnswer[$index],
				]);
				$this->assertTrue($isCorrect);
			}

		}
	}

	/**
	 * @author 黄文非
     * 测试获取答案
     */
	public function testEsModelGetAnswer()
	{
		$aEsType = Es::getTypeList();
		$this->assertTrue(is_array($aEsType));
		foreach($aEsType as $type => $name){
			$aWhere = ['in', 'type_id', [$type]];
			$total = (new \umeworld\lib\Query())->from('_@es_index')->where($aWhere)->count();
			$offset = mt_rand(0, $total - 1);
			$pageSize = 1;

			$aEs = (new \umeworld\lib\Query())->from('_@es_index')->where($aWhere)->offset($offset)->limit($pageSize)->one();

			//codecept_debug($aEs);
			$mEs = Es::findOne($aEs['id']);
			$this->assertInstanceOf('common\model\Es', $mEs);

			$aAnswer = $mEs->getAnswer();

			//codecept_debug($aAnswer);
			//codecept_debug('####################' . $name);

			if($type == Es::TYPE_SINGLE_CHOICE){
				$this->assertGreaterThanOrEqual(0, $aAnswer);
				$this->assertLessThan(5, $aAnswer);
			}elseif($type == Es::TYPE_MULTIPLE_CHOICE){//if(!is_array($aAnswer)){file_put_contents('/var/www/umfun/b1.txt', $aEs['id']. '#' . var_export($aAnswer,1));}
				$this->assertTrue(is_array($aAnswer));
				foreach($aAnswer as $value){
					$this->assertGreaterThanOrEqual(0, $value);
					$this->assertLessThan(10, $value);
				}
			}elseif($type == Es::TYPE_JUDGME){
				$this->assertGreaterThanOrEqual(0, $aAnswer);
				$this->assertLessThanOrEqual(1, $aAnswer);
			}elseif($type == Es::TYPE_FILL_BLANK){
				$this->assertTrue(is_array($aAnswer));
				foreach($aAnswer as $aValue){
					$this->assertGreaterThan(0, sizeof($aValue));
				}
			}elseif($type == Es::TYPE_WORD_FILL_BLANK){
				$this->assertTrue(is_array($aAnswer));
				foreach($aAnswer as $aValue){
					$this->assertTrue(is_array($aValue));
				}
			}elseif($type == Es::TYPE_COMPLEX_READING){
				$this->assertTrue(is_array($aAnswer));
			}elseif($type == Es::TYPE_COMPLEX_FILL_BLANK){
				$this->assertTrue(is_array($aAnswer));
			}

		}
	}

	/**
	 * 测试获取题目摘要的方法
	 */
	public function testGetDescTest(){
		foreach(array_keys(Es::getTypeList()) as $typeId){
			$mEs = $this->_getRandomEs(['type_id' => $typeId]);
			$descText = $mEs->getDescText();
			$this->assertInternalType('string', $descText, '摘要是字符串');

			if(!isset($mEs->es_content['image'])){
				$this->assertNotEmpty($descText, '题目内容没图片,摘要的内容不应该为空');
			}
		}
	}

	/**
	 * 随机获取一个题目模型
	 * @param array $aWhere Query查询条件
	 * @return \common\model\Es
	 * @throws \Exception
	 * @author 黄文非
	 */
	protected function _getRandomEs($aWhere){
		$id = (new Query())->select(['id'])->from('_@es_index')->where($aWhere)->orderBy('rand()')->limit(1)->one();
		if(!$id){
			$this->assertTrue(false, '随机抽取题目ID失败');
		}
		$mEs = Es::findOne($id);
		if(!$mEs){
			$this->assertTrue(false, '随机获取题目模型失败');
		}
		return $mEs;
	}

	/**
	 * 随机获取一个题目反馈的信息
	 * @return \common\model\Es
	 * @throws \Exception
	 * @author zhangliping
	 */
	protected function _getRandomFeedbackEs(){
		$id = (new Query())->select(['es_id', 'user_id'])->from('_@es_feedback') ->orderBy('rand()')->limit(1)->one();
		if(!$id){
			throw new \Exception(false, '随机抽取反馈题目ID失败');
		}
		return $id;
	}

	/**
	 * 抽取各中类型题目进行答案格式验证
	 * @author shuai
	 */
	public function testValidataAnswer(){
		//单选
		$mSingleChoice = $this->_getRandomEs(['type_id' => Es::TYPE_SINGLE_CHOICE]);
		$this->assertTrue($mSingleChoice->validateAnswer($mSingleChoice->getAnswer()));
		$this->assertFalse($mSingleChoice->validateAnswer('xx'));

		//多选
		$mMultipie = $this->_getRandomEs(['type_id' => Es::TYPE_MULTIPLE_CHOICE]);
		$this->assertTrue($mMultipie->validateAnswer($mMultipie->getAnswer()));
		$this->assertTrue($mMultipie->validateAnswer([]));
		$this->assertFalse($mMultipie->validateAnswer('xx'));

		//判断题
		$mJudgme = $this->_getRandomEs(['type_id' => Es::TYPE_JUDGME]);
		$this->assertTrue($mJudgme->validateAnswer($mJudgme->getAnswer()));
		$this->assertTrue($mJudgme->validateAnswer(1));
		$this->assertTrue($mJudgme->validateAnswer(0));
		$this->assertFalse($mJudgme->validateAnswer('x'));
		$this->assertFalse($mJudgme->validateAnswer(3));
		//填空题
		$mFillBlank = $this->_getRandomEs(['type_id' => Es::TYPE_FILL_BLANK]);
		$this->assertTrue($mFillBlank->validateAnswer($mFillBlank->getAnswer()));
		$this->assertTrue($mFillBlank->validateAnswer([['a']]));
		$this->assertFalse($mFillBlank->validateAnswer([[[]]]));
		$this->assertFalse($mFillBlank->validateAnswer(['b']));
		$this->assertFalse($mFillBlank->validateAnswer('xx'));

		//选词项填空题
		$mWordFillBlank =  $this->_getRandomEs(['type_id' => Es::TYPE_WORD_FILL_BLANK]);
		$this->assertTrue($mWordFillBlank->validateAnswer($mWordFillBlank->getAnswer()));
		$this->assertTrue($mWordFillBlank->validateAnswer([['a']]));
		$this->assertFalse($mWordFillBlank->validateAnswer([[[]]]));
		$this->assertFalse($mWordFillBlank->validateAnswer(['b']));
		$this->assertFalse($mWordFillBlank->validateAnswer('xx'));



		//阅读理解题(复合题)
		$mComplexReading = $this->_getRandomEs(['type_id' => Es::TYPE_COMPLEX_READING]);
		$this->assertTrue($mComplexReading->validateAnswer($mComplexReading->getAnswer()));
		$this->assertFalse($mComplexReading->validateAnswer('xx'));

		//自己构造一个复合题进行判断
		$mComplexReading->es_content = [
			'content' => '题干',
			'es_item' => [
				//子题
				0 => [
					'type' => Es::TYPE_SINGLE_CHOICE,
					'content' => [
						'content' => 'aa',
						'option' => [
							0 => [
								'content' => 'bb',
							],
							1 => [
								'content' => 'cc',
							],
						],
						'answer' => 0,
					],
				],
				//选词填空
				1 => [
					'type' => Es::TYPE_WORD_FILL_BLANK,
					'content' => [
						'content' => '这是一首 ____， 作者是 ____ 。',
						'answer' => [
							0 => ['诗'],
							1 => [
								'李白',
								'李太白',
							],
						],
					],
				],//多选
				2 => [
					'type' => Es::TYPE_MULTIPLE_CHOICE,
					'content' => [
						'content' => '下列选项正确的一项是：',
						'image' => [
							'/esimg/chinese/0/xxx.jpg',
						],
						'option' => [
							//选项
							0 => [
								'content' => '1 + 1 = 11', //选项内容
								'image' => [
									'yyy.jpg',
								],
							],
							1 => [
								'content' => '1 + 2 = 13',
							],
							2 => [
								'content' => '1 + 1 = 21',
							],
							3 => [
								'content' => '1 + 1 = 2',
							],
							4 => [
								'content' => '1 + 1 = 111',
							],
						],
						'answer' => [3, 4], //答案的option下标序号
					],
				],//判断题
				3 => [
					'type' => Es::TYPE_JUDGME,
					'content' => [
						'content' => '我是男的',
						'image' => [
							'/xxx.jpg',
							'/yyy.jpg',
						],
						'answer' => 1,
					],
				],
				4 => [
					'type' => Es::TYPE_FILL_BLANK,
					'content' => [
						'content' => '李亚林是 ____ 公司的 ____ , ____ 今年 ____ 岁, 其代表作有 ____, ____, ____ ?', //题干内容
						'image' => [
							//题目图片,如果没有则不构建这个键名
							'/esimg/chinese/0/xxx.jpg',
							'yyy.jpg',
							'zzz.jpg',
							'qqq.jpg',
						],
						'answer' => [
							//填空项
							0 => ['新宜讯网络技术有限公司'],
							1 => ['PHP程序员'],
							2 => [
								'JavaScript程序员',
								'JS程序员',
							],
							3 => ['27'],
							4 => ['X系统'],
							5 => ['Y系统'],
							6 => ['Z系统'],
						],
					],
				],
			],
		];
		//单选
		$this->assertTrue($mComplexReading->validateAnswer([0 => 1]));
		$this->assertFalse($mComplexReading->validateAnswer([0 => 'xx']));
		//选词项填空题
		$this->assertTrue($mComplexReading->validateAnswer([1 => [['a']]]));
		$this->assertFalse($mComplexReading->validateAnswer([1 => [[[]]]]));
		$this->assertFalse($mComplexReading->validateAnswer([1 => ['b']]));
		$this->assertFalse($mComplexReading->validateAnswer([1 => 'xx']));
		//多选
		$this->assertTrue($mComplexReading->validateAnswer([2 => []]));
		$this->assertTrue($mComplexReading->validateAnswer([2 => [3]]));
		$this->assertFalse($mComplexReading->validateAnswer([2 => ['x']]));
		$this->assertFalse($mComplexReading->validateAnswer([2 => 'xx']));
		//判断
		$this->assertTrue($mComplexReading->validateAnswer([3 => 1]));
		$this->assertTrue($mComplexReading->validateAnswer([3 => 0]));
		$this->assertFalse($mComplexReading->validateAnswer([3 => 'x']));
		$this->assertFalse($mComplexReading->validateAnswer([3 => 3]));
		//填空
		$this->assertTrue($mComplexReading->validateAnswer([4 => [['a']]]));
		$this->assertFalse($mComplexReading->validateAnswer([4 => [[[]]]]));
		$this->assertFalse($mComplexReading->validateAnswer([4 => ['b']]));
		$this->assertFalse($mComplexReading->validateAnswer([4 => 'xx']));

		//完形填空题
		$mComplexFillBlank =  $this->_getRandomEs(['type_id' => Es::TYPE_COMPLEX_FILL_BLANK]);
		$this->assertTrue($mComplexFillBlank->validateAnswer($mComplexFillBlank->getAnswer()));

	}

    /**
     * 测试添加解题思路
     * @author zhangliping
     */
	public function testEsModelAddAnalysis(){
		$aRecord = [
			'user_id' => Yii::$app->test->oCommonStudent->id,
			'user_type'=> Student::ROLE_TYPE,
			'analysis'=> '测试数据请忽略'
		];
		$this->mEs = $this->_getRandomEs(['id' => $this->commonEsId]);
		$insertID = $this->mEs->addAnalysis($aRecord);
		/*$this->getAddAnalysisId = Yii::$app->db->getLastInsertId();*/
 		$this->assertTrue($insertID);
		$this->tester->seeInDatabase(Es::analysisTableName(), [
			'id' => $this->commonEsId,
		]);
	}

    /**
     * 测试添加题目反馈
     * @author zhangliping
     */
	public function testEsModelAddFeedback(){
		$aFeedback = [
			'user_id' => Yii::$app->test->oCommonStudent->id,
			'user_type'	=> Student::ROLE_TYPE,
			'reason' => '粗心大意',
			'user_answer' => '题目简单',
			'status' => 1,
			'create_time' => NOW_TIME
		];
		//判断返回值
		$_insertID = $this->mEs->addFeedback($aFeedback, Game::GAME_MISSION_PRACTICE, 77);
		$this->getAddFeedbackId = (int)Yii::$app->db->getLastInsertId();
		$this->assertEquals(1, $_insertID);
		$this->tester->seeInDatabase(Es::feedbackTableName(), [
			'id' => $this->getAddFeedbackId,
		]);
	}

	/**
	 * 测试用户反馈是否已经存在
	 * @author zhangliping
	 */
	public function testEsModelIsFeedBacked(){
		$userId = Yii::$app->test->oCommonStudent->id;
		$this->mEs = $this->_getRandomEs(['id' => $this->commonEsId]);
		$this->isFeedback = $this->mEs->isFeedBacked($userId);
		$this->assertFalse($this->isFeedback);
		$userId = $this->user_id;
		$this->mEs = $this->_getRandomEs(['id' => $this->exitFeedbackId]);
		$feedbackFalse =$this->mEs->isFeedBacked($userId);
		$this->assertTrue($feedbackFalse);
	}

	/**
	 * 获取本题是否已经移除了答案
	 * @author zhangliping
	 */
	public function testEsModelGetIsRemovedAnswer(){
        $this->mEs = Yii::$app->test->getRandomEs();
        $this->isRemovedAnswer = $this->mEs->getIsRemovedAnswer();
        $this->aRemove = $this ->mEs->removeAnswer();
        $this->removeAnswerResult = $this->mEs->getIsRemovedAnswer();
        $this->assertInstanceOf('common\model\Es', $this->mEs);
        $this->assertFalse($this->isRemovedAnswer);
        $this->assertTrue($this->removeAnswerResult);
	}

	/**
	 * 测试获取题型列表
	 * @author zhangliping
	 */
	public function testEsModelGetTypeList(){
		$this->typeList = Es::getTypeList();
		$this->assertInternalType('array' , $this->typeList);
		$this->assertEquals(7, count($this->typeList));
	}

    /**
     * 测试判断本题是否选择题,包含了单选和多选题型哦!
     * @author zhangliping
     */
	public function testEsModelIsChoiceEs(){
		$this->isSingleChoiceEs = $this->_getRandomEs(['type_id' => Es::TYPE_SINGLE_CHOICE]);
		$this->isMultipleChoiceEs = $this->_getRandomEs(['type_id' => Es:: TYPE_MULTIPLE_CHOICE]);
		$this->singleResult = $this->isSingleChoiceEs->isChoiceEs();
		$this->multipleResult = $this->isSingleChoiceEs->isChoiceEs();
		$this->assertInstanceOf('common\model\Es' , $this->isSingleChoiceEs);
		$this->assertInstanceOf('common\model\Es' , $this->isMultipleChoiceEs);
		$this->assertTrue($this->singleResult);
		$this->assertTrue($this->multipleResult);
	}

	/**
	 * 测试判断本题是否为混合题
	 * @author zhangliping
	 */
	public function testEsModelIsComplexEs(){
		$this->isComplexReandingEs = $this->_getRandomEs(['type_id' => Es::TYPE_COMPLEX_READING]);
        $this->isCorrectFillBlankEs = $this->_getRandomEs(['type_id' => Es::TYPE_COMPLEX_FILL_BLANK]);
        $this->ComplexReandingEs = $this->isComplexReandingEs->isComplexEs();
        $this->CorrectFillBlankEs = $this->isComplexReandingEs->isComplexEs();
		$this->assertInstanceOf('common\model\Es' , $this->isComplexReandingEs);
		$this->assertInstanceOf('common\model\Es' , $this->isCorrectFillBlankEs);
		$this->assertTrue($this->ComplexReandingEs);
		$this->assertTrue($this->CorrectFillBlankEs);
	}

	/**
	 * 测试判断本题是否为填空题
	 * @author zhangliping
	 */
	public function testEsModelIsFillBlankEs(){
		$this->mFillBlankEs = $this->_getRandomEs(['type_id' => Es::TYPE_FILL_BLANK]);
		$this->mWordFillBlankEs = $this->_getRandomEs(['type_id' => Es::TYPE_WORD_FILL_BLANK]);
		$this->fillBlanksEs = $this->mFillBlankEs->isFillBlankEs();
		$this->wordFillBlankEs = $this->mWordFillBlankEs->isFillBlankEs();
		$this->assertInstanceOf('common\model\Es', $this->mFillBlankEs);
		$this->assertInstanceOf('common\model\Es', $this->mWordFillBlankEs);
		$this->assertTrue($this->fillBlanksEs);
		$this->assertTrue($this->wordFillBlankEs);
	}

    /**
	 * 测试判断本题是否为判断题
	 * @author zhangliping
	 */
	public function testEsModelIsJudgmentEs(){
		$this->mJudgmentEs = $this->_getRandomEs(['type_id' => Es::TYPE_JUDGME]);
		$this->judgmeEs = $this->mJudgmentEs->isJudgmentEs();
		$this->assertInstanceOf('common\model\Es' , $this->mJudgmentEs);
		$this->assertTrue($this->judgmeEs);
	}

	/**
	 * 测试判断本题是否为多选题
	 * @author zhangliping
	 */
	public function testEsModelIsMultipleChoiceEs(){
		$this->mMultipleChoiceEs = $this->_getRandomEs(['type_id' => Es::TYPE_MULTIPLE_CHOICE]);
		$this->mulitpleChoiceEs = $this->mMultipleChoiceEs->isMultipleChoiceEs();
		$this->assertInstanceOf('common\model\Es' , $this->mMultipleChoiceEs);
		$this->assertTrue($this->mulitpleChoiceEs);
	}
}