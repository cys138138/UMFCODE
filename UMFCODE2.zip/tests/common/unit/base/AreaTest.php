<?php
namespace tests\common\base;

use Yii;
use common\model\Area;

class AreaTest extends \Codeception\TestCase\Test{
	protected $_mArea = null;
	protected $_mAreaCity = null;

	protected function _before(){
		$this->_mArea = Area::findOne(Yii::$app->test->aParams['area']['area_id']);
		$this->_mAreaCity = Area::findOne(Yii::$app->test->aParams['area']['city_id']);
	}

	/**
	 * 测试实例化area模型
	 * @author zhangliping
	 */
	public function testAreaModelInstance(){
		$this->assertInstanceOf('common\model\Area', $this->_mArea);
		$this->assertInstanceOf('common\model\Area', $this->_mAreaCity);
	}

	/**
	 * 测试Area模型的isArea方法是否返回了正确的值
	 * @author  zhangliping
	 */
	public function testAreaModelIsArea(){
		$this->assertTrue($this->_mArea->isArea());
		$this->assertFalse($this->_mAreaCity->isArea());
	}

	/**
	 * 测试Area模型的getAreaList获取地区列表
	 * @author  zhangliping
	 */
	public function testGetAreaList(){
		$aAreaList = Area::getAreaList(['id' => [$this->_mArea->id, $this->_mArea->pid]]);
		$this->assertInternalType('array', $aAreaList);
		$this->assertCount(2, $aAreaList);
	}

    /**
     * 测试根据地区id获取地区的城市和省份信息
     * @author zhangliping
     */
	public function testGetDetailAreaListByAreaIds(){
		$aAreaIds = $this->_mArea;
		$aAreaDetailList = Area::getDetailAreaListByAreaIds(['id' => $this->_mArea->id]);
		$this->assertInternalType('array', $aAreaDetailList);
            foreach ($aAreaDetailList as $detailData){
            $this->tester->assertCompareArrayStruct($detailData, [
                'id',
                'pid',
                'name',
                'city_info'=>[
                   	'id',
                	'pid',
               		'name',
                ],
                'province_info' => [
                	'id',
                	'pid',
               		'name',
                ],
            ]);
        }
	}
}