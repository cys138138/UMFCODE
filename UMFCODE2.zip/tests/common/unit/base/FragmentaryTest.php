<?php
namespace tests\common;


class FragmentaryTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

	/**
	 * 测试cnzz站长统计代码的输出是否正常
	 */
    public function testCnzzCode()
    {
		$cnzzCode = \common\widgets\Cnzz::widget(['mustOutput' => true]);
		$this->assertInternalType('string', $cnzzCode);
		$this->assertNotEmpty($cnzzCode);
    }

}