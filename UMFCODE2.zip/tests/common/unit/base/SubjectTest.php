<?php
namespace tests\common\unit;

use Yii;
use common\model\Subject;
/**
 * 科目模型单元测试
 * @author 黄文非
 */
class SubjectTest extends \Codeception\TestCase\Test
{
	use \Codeception\Specify;

	protected $tester;

	/**
	 * 测试科目列表的读取
	 */
	public function testSubjectList(){
		$aSubjectList = Subject::getSubjectList();
		$this->assertInternalType('array', $aSubjectList, '科目列表是数组');
		$aConfigSubjectList = require(Yii::getAlias('@common/config/model/subject.php'));
		$this->assertInternalType('array', $aConfigSubjectList, '读出的配置也是数组');
		$this->assertInternalType('array', $aConfigSubjectList['subject_list'], '读出的配置里的科目列表也是数组');
		$this->assertEquals(count($aConfigSubjectList['subject_list']), count($aSubjectList), '配置的科目列表数和模型给出的列表数应该是相等的');

		$randomSubjectId = array_rand($aSubjectList);
		$mSubject = Subject::findOne($randomSubjectId);
		$this->assertInstanceOf(Subject::className(), $mSubject, '断言科目模型的类');

		$aTeacherStatisticsSubjectList = Subject::getSubjectList(Subject::GAME_TEACHER_STATISTICS);
		$this->assertEquals(3, count($aTeacherStatisticsSubjectList), '教师统计科目应该只有语数英三个的');
		foreach(['语文', '数学', '英语'] as $subjectName){
			$this->assertContains($subjectName, $aTeacherStatisticsSubjectList, '教师统计科目应该会包含' . $subjectName);
		}
	}
}
