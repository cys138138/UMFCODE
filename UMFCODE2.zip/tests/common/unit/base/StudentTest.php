<?php
namespace tests\common\unit;

use common\event\BeforeDeductStudentCurrency;
use common\model\Student;
use common\model\UserNumerical;
use umeworld\lib\Query;
use Yii;

/**
 * 学生用户测试
 * @author 黄文非
 */
class StudentTest extends \Codeception\TestCase\Test{
	/**
	 * @var Student
	 */
	private $_mStudent = null;

	/**
	 * 金币操作测试
	 */
	public function testOperatingCurrency(){
		$testGoldNums = 10;	//要测试操作的金币数
		$numericalTableName = UserNumerical::tableName();

		//添加金币
		$mStudent = Student::findOne(Yii::$app->test->oCommonStudent->id);
		$gold = $mStudent->gold;	//先存起原来的金币,后面要用
		$mStudent->addCurrency($testGoldNums);
		$studentType = $mStudent->isVip();
 		if($studentType == 1){
			$this->tester->seeInDataBase($numericalTableName, [
				'id' => $mStudent->id,
				'gold' => $gold + $testGoldNums,
			]);

			//扣除金币
			$mStudent->deductCurrency($testGoldNums);
			$this->tester->seeInDataBase($numericalTableName, [
				'id' => $mStudent->id,
				'gold' => $gold,	//以原来的金币数查询
			]);

			//扣除金币前通过事件将扣除金币减半
			$mStudent->on(Student::EVENT_BEFORE_DEDUCT_CURRENCY, function(BeforeDeductStudentCurrency $oEvent){
				$oEvent->money = $oEvent->money / 2;
			});
			$mStudent->deductCurrency($testGoldNums);
			$this->tester->seeInDataBase($numericalTableName, [
				'id' => $mStudent->id,
				'gold' => $gold - $testGoldNums / 2,
			]);

			//恢复原始金币数
			$mStudent->set('gold', $gold);
			$mStudent->save();
			$this->tester->seeInDataBase($numericalTableName, [
				'id' => $mStudent->id,
				'gold' => $gold,
			]);
		}
	}

	/**
	 * 测试今天是否已经登录返回值
	 */
	public function testIsFirstLoginToday() {
		$mStudent = Yii::$app->test->commonStudent->getInstance();
		$studentId = $mStudent->id;
		$isFirstLoginToday = $mStudent->isFirstLoginToday();
		$this->assertInternalType('bool', $isFirstLoginToday);
		if(!$isFirstLoginToday){
			$aWhere = [
				'and',
				['user_id' => $mStudent->id],
				['user_type' => Student::ROLE_TYPE],
				['>', 'login_time', strtotime(date('Y-m-d', NOW_TIME))],
			];
			$oCommand = (new Query())->createCommand()->delete(Student::loginLogTableName(), $aWhere);
			$oCommand->execute();

			$mStudent = Student::findOne($studentId);
			$isFirstLoginToday = $mStudent->isFirstLoginToday();
			$this->assertInternalType('bool', $isFirstLoginToday);
			$this->assertTrue($mStudent->isFirstLoginToday());
		}

		$logId = $mStudent->addLoginLog();
		$this->assertGreaterThanOrEqual(0, $logId);

		$mStudent = Student::findOne($studentId);
		$isFirstLoginToday = $mStudent->isFirstLoginToday();
		$this->assertFalse($isFirstLoginToday, '添加了登陆日志后重新构建的学生模型应该是并非第一次登陆的');

		(new Query())->createCommand()->delete(Student::loginLogTableName(), ['id' => $logId])->execute();
	}

	/**
	 * 测试插入每天登陆日志
	 */
	public function testAddLoginLog() {
		$mStudent = Student::findOne(Yii::$app->test->commonStudent->id);
		$logId = $mStudent->addLoginLog();
		$this->assertGreaterThanOrEqual(0, $logId);
		(new Query())->createCommand()->delete(Student::loginLogTableName(), ['id' => $logId])->execute();
	}

	/**
	 * 测试VIP到期时间的处理
	 * @author 黄文非
	 */
	public function testVipExpireTime(){
		$this->_mStudent = Yii::$app->test->commonStudent->getInstance();
		foreach([1, 2 ,3] as $testVipLevel){
			$this->_testVipExpireTime($testVipLevel);
		}
	}

	/**
	 * 测试获取学生年纪(周岁)
	 * @author zhou
	 */
	public function testGetValue(){
		$mStudent = Yii::$app->test->commonStudent->getInstance() ;

		$age = $mStudent->getAge();
		$this->assertInternalType('integer', $age);
	}

	private function _testVipExpireTime($testVipLevel){
		$testExpireTime = NOW_TIME + 86400 + $testVipLevel;	//测试的VIP到期时间
		$mNumerical = UserNumerical::findOne($this->_mStudent->id);	//把原来的数值信息取出来先,后面要用来恢复成这个模型的数据状态

		$this->assertTrue($this->_mStudent->setVipExpireTime($testVipLevel, $testExpireTime), '设置VIP到期时间失败');
		$this->tester->seeInDatabase(UserNumerical::tableName(), [
			'id' => $this->_mStudent->id,
			'vip' => $testVipLevel,
			'vip_expiration_time' => $testExpireTime,
		], '数据库里的VIP信息不符合预期');
		$this->assertTrue($this->_mStudent->isVip(), '设置VIP后该用户isVip方法居然不是VIP');
		$this->assertEquals($testVipLevel, $this->_mStudent->getVipLevel(), 'getVipLevel方法返回的VIP级别跟测试的级别不一致');

		//恢复原来的数据
		$mNumerical->set('vip', $mNumerical->vip);
		$mNumerical->set('vip_expiration_time', $mNumerical->vip_expiration_time);
		$this->assertGreaterThan(0, $mNumerical->save(), 'VIP级别' . $testVipLevel . ' 测试后恢复数据失败');
	}
}

























