<?php
namespace tests\common\base;

use Yii;
use common\model\EsWrong;
use umeworld\lib\Query;

/**
 * 错题测试
 */
class EsWrongTest extends \Codeception\TestCase\Test{

	/**
	 * 测试获取用户错题月统计列表是否正确
	 */
	public function testEsWrongModelGetUserWrongEsMonthStatistics(){
		$aCondition = ['user_id' => Yii::$app->test->commonStudent->id];
		$aControl = ['page' => 1, 'page_size' => 5];
		$aWrongEsMonthStatisticsList = EsWrong::getUserWrongEsMonthStatistics($aCondition, $aControl);
		$this->assertTrue(is_array($aWrongEsMonthStatisticsList));
		$aStruct = [
			'month',
			'nums'
		];
		foreach($aWrongEsMonthStatisticsList as $aWrongEsMonthStatistics){
			$this->tester->assertCompareArrayStruct($aWrongEsMonthStatistics, $aStruct);
		}
	}

	/**
	 * 测试获取用户月错题统计
	 */
	public function testEsWrongModelGetMonthWrongEsStatisticsList(){
		$aCondition = ['user_id' => Yii::$app->test->commonStudent->id];
		$aControl = ['page' => 1, 'page_size' => 5];
		$aWrongEsStatisticsList = EsWrong::getMonthWrongEsStatisticsList($aCondition, $aControl);
		$this->assertTrue(is_array($aWrongEsStatisticsList));
		$aStruct = [
			'year',
			'month',
			'es_repair_count',
			'es_wrong_count',
		];
		foreach($aWrongEsStatisticsList as $aWrongEsStatistics){
			$this->tester->assertCompareArrayStruct($aWrongEsStatistics, $aStruct);
		}
		$monthCount = EsWrong::getMonthWrongEsStatisticsCount($aCondition);
		$this->assertTrue(is_numeric($monthCount));
	}
	
	/**
	 * 获取用户月错题数量统计
	 */
	public function testGetMonthWrongEsStatisticsCount(){
		$aCondition = ['user_id' => Yii::$app->test->commonStudent->id];
		$aControl = ['page' => 1, 'page_size' => 5];
		$aWrongEsStatisticsCount = EsWrong::getMonthWrongEsStatisticsCount($aCondition, $aControl);
		$this->assertTrue(is_numeric($aWrongEsStatisticsCount));
	}
	
	/**
	 *  测试获取错题列表
	 * @autho zhangleep
	 */
	public function testGetWrongEsList(){
		$aCondition = [
	 		'user_id'	=>	Yii::$app->test->commonStudent->id,
	 		'mission_id'		=>	2,
	 		'subject_id'		=>	1,
	 		'type_id'		=>	2,
		];
		$aControl = [
	 		'page'	=>1,
	 		'page_size'	=>5,
		];
		
		$wrongEsList = EsWrong::getWrongEsList($aCondition, $aControl);
		
		$aStruct = [
			'year',
			'month',
			'es_repair_count',
			'es_wrong_count',
		];
		if(count($wrongEsList)){
			foreach($wrongEsList as $aWrongEs){
				$this->tester->assertCompareArrayStruct($aWrongEs, $aStruct);
			}
		}
	}
	
	/**
	 *  获取错题数
	 * @author zhangliping
	 */
	public function testGetWrongEsCount(){
		$aCondition = [
	 		'user_id'	=>	Yii::$app->test->commonStudent->id,
	 		'mission_id'		=>	2,
	 		'subject_id'		=>	1,
	 		'type_id'		=>	2,
		];
		$wrongCount = EsWrong::getWrongEsCount($aCondition);
		$this->assertTrue(is_numeric($wrongCount));	
	}
	
	/**
	 * 获取用户修复错题总数
	 */
	public function testGetUserRepairEsCount(){
		$aCondition = [
	 		'user_id'	=>	Yii::$app->test->commonStudent->id,
	 		'mission_id'	=>	1,
	 		'subject_id'	=>	1,
	 		'type_id'		=>	2,
		];
		$repairCount = EsWrong::getUserRepairEsCount($aCondition);
		$this->assertTrue(is_numeric($repairCount));	 
	}
	
	/**
	 * 关卡错题统计列表
	 */
	public function testGetMissionWrongEsStatisticsList(){
		$aCondition = [
	 		'user_id'	=>	Yii::$app->test->commonStudent->id,
	 		'subject_id' =>	1,
		];
		$aControl = [
	 		'page'	=>1,
	 		'page_size'	=>5,
		];
		
		$wrongEsList = EsWrong::getMissionWrongEsStatisticsList($aCondition, $aControl);
		$aStruct = [
			'mission_id',
			'es_repair_count',
			'es_wrong_count',
		];
		if(count($wrongEsList)){
			foreach($wrongEsList as $aWrongEs){
				$this->tester->assertCompareArrayStruct($aWrongEs, $aStruct);
			}
		}
	}
	
	/**
	 * 获取用户题统计的关卡数量
	 */
	public function testGetMissionWrongEsStatisticsCount(){
		$aCondition = [
	 		'user_id'	=>	Yii::$app->test->commonStudent->id,
	 		'subject_id' =>	1,
		];
		$missionCount = EsWrong::getMissionWrongEsStatisticsCount($aCondition);
		$this->assertTrue(is_numeric($missionCount)); 
	}
	
	/**
	 * 获取错题所属的科目和关卡信息
	 */
	public function testGetMissionInfo(){
		 $aCondition = [
			'userId' => Yii::$app->test->commonStudent->id,
			'one' => 1,
			'subjectId' => 1,
		];
		$aControl = [
			 'page' =>1,
	 		 'pageSize' =>3,
		];	 
		$aMissionInfo = EsWrong::getMissionInfo($aCondition, $aControl);
		$aStruct = [
			'subject_id',
			'mission_id',
			'grade',
			'name',
			'grade_name',
		];
		if(count($aMissionInfo)){
			foreach($aMissionInfo as $aMission){
				$this->tester->assertCompareArrayStruct($aMission, $aStruct);
			}
		}
	}
	
	/**
	 * 获取用户错题关卡列表
	 */
	public function testGetUserEsWrongMissionList(){
		$aCondition = [
			'user_id' => Yii::$app->test->commonStudent->id,
			'subject_id' => 1,
		];
		$aControl = [
			'page' =>1,
	 		'page_size' =>3,
		];	 
		$aUserWrongEsMissionInfo = EsWrong::getUserEsWrongMissionList($aCondition, $aControl);
		$aStruct = [
			'id',
			'grade_name',
		];
		if($aUserWrongEsMissionInfo){
			foreach($aUserWrongEsMissionInfo as $aMission){
				$this->tester->assertCompareArrayStruct($aMission, $aStruct);
			}
		}
	}	
	
	/**
	 * 获取用户错题关卡数量
	 */
	public function testGetUserEsWrongMissionCount(){
		$aCondition = [
	 		'user_id'	=>	Yii::$app->test->commonStudent->id,
	 		'subject_id' =>	1,
		];
		$missionCount = EsWrong::getUserEsWrongMissionCount($aCondition);
		$this->assertTrue(is_numeric($missionCount)); 
	}
}