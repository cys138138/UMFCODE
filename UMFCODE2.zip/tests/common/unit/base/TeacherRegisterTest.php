<?php
namespace tests\common\unit;

use common\model\TeacherRegister;
use common\model\Teacher;
use common\model\School;
use common\role\TeacherRegisterBaseInfo;
use umeworld\lib\Query;
use Yii;

/**
 * 教师用户注册测试
 * @author jay
 */
class TeacherRegisterTest extends \Codeception\TestCase\Test{
	/**
	 * 测试教师用户注册
	 */
	public function testTeacherRegister() {
		$aTeacherBaseData = TeacherRegister::initTeacherBaseData();
		$this->assertInternalType('array', $aTeacherBaseData);
		$this->assertArrayHasKey('name', $aTeacherBaseData); 
		$this->assertArrayHasKey('extend_type', $aTeacherBaseData); 
		$oBaseInfo = new TeacherRegisterBaseInfo();
		$oBaseInfo->extendType = Teacher::GD_EXTEND_CODE;
		$oBaseInfo->name = '马老师';
		$oBaseInfo->xxtId = 0;
		$mSchool = School::findOne(['type' => 0]);
		$this->assertInstanceOf('common\model\School', $mSchool);
		$oBaseInfo->areaId = $mSchool->area_id;
		$oBaseInfo->schoolId = $mSchool->id;
		$oBaseInfo->aXxtData = [];
		$mTeacher = TeacherRegister::createBaseInfo($oBaseInfo);
		$this->assertInstanceOf('common\model\Teacher', $mTeacher);
		
		//删除添加的数据
		(new Query())->createCommand()->delete(Teacher::tableName(), ['id' => $mTeacher->id])->execute();
		(new Query())->createCommand()->delete(Teacher::dataTableName(), ['id' => $mTeacher->id])->execute();
	}

}
