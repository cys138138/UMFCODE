<?php
namespace tests\common\unit;

use common\event\BeforeDeductStudentCurrency;
use common\model\UserFriend;
use common\model\School;
use common\model\Grade;
use common\model\Student;
use common\model\UserNumerical;
use common\model\StudentRegister;
use common\role\StudentRegisterBaseInfo;
use common\role\StudentRegisterFullInfo;
use umeworld\lib\Query;
use Yii;

/**
 * 学生用户注册测试
 * @author jay
 */
class StudentRegisterTest extends \Codeception\TestCase\Test{
	/**
	 * 测试用户注册
	 */
	public function testStudentRegister() {
		$ufId = StudentRegister::getUfId();
		$this->assertTrue(is_numeric($ufId));
		$oBaseInfo = new StudentRegisterBaseInfo();
		$this->assertInstanceOf('common\role\StudentRegisterBaseInfo', $oBaseInfo);
		$oBaseInfo->id = $ufId;
		$oBaseInfo->password = Student::encryptPassword(121212);
		$oFullInfo = new StudentRegisterFullInfo();
		$this->assertInstanceOf('common\role\StudentRegisterFullInfo', $oFullInfo);
		$mSchool = School::findOne(['type' => 0]);
		$this->assertInstanceOf('common\model\School', $mSchool);
		$oFullInfo->areaId = $mSchool->area_id;
		$oFullInfo->schoolId = $mSchool->id;
		$aGradeList = Grade::getGradeList();
		$this->assertInternalType('array', $aGradeList);
		$oFullInfo->grade = current(array_keys($aGradeList));
		$oFullInfo->className = '1班';
		$oFullInfo->name = '测试名';
		
		$mStudent = StudentRegister::createBaseInfo($oBaseInfo);
		$mStudent->fillFullInfo($oFullInfo);
		StudentRegister::initAppBaseData($ufId);
		$this->assertInstanceOf('common\model\Student', $mStudent);
		
		//删除添加的数据
		(new Query())->createCommand()->delete(Student::tableName(), ['id' => $ufId])->execute();
		(new Query())->createCommand()->delete(Student::personalTableName(), ['id' => $ufId])->execute();
		(new Query())->createCommand()->delete(Student::classTableName(), ['user_id' => $ufId])->execute();
		(new Query())->createCommand()->delete(Student::loginLogTableName(), ['user_id' => $ufId])->execute();
		(new Query())->createCommand()->delete(UserFriend::tableName(), ['id' => $ufId])->execute();
		(new Query())->createCommand()->delete('mark', ['id' => $ufId])->execute();
		(new Query())->createCommand()->delete('user_invitation', ['id' => $ufId])->execute();
		(new Query())->createCommand()->insert('account_number', ['number' => $ufId, 'level' => 0])->execute();
	}

}
