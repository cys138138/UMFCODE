<?php
namespace tests\common\base;

use Yii;
use common\model\Student;
use common\model\Teacher;
use umeworld\lib\Query;

class TeacherTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

	/**
	 * 测试添加登陆记录
	 */
	public function testAddLoginLog(){
		$mTeacher = Yii::$app->test->getRandomTeacher();
		$logId = $mTeacher->addLoginLog();
		$this->assertGreaterThanOrEqual(0, $logId);
		(new Query())->createCommand()->delete(Student::loginLogTableName(), ['id' => $logId])->execute();
	}

}