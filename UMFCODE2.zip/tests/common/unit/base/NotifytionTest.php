<?php
namespace tests\common\base;

use common\lib\Notifytion;
use umeworld\lib\ServerErrorHttpException;


class NotifytionTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }


    /**
	 * 测试增加通知数据
	 * @author 黄文非
	 */
    public function testAdd()
    {
		$oNotifytion = new Notifytion();
		$this->assertTrue($oNotifytion->add('a', 1), '添加通知失败');
		$this->assertFalse($oNotifytion->add('a', 2, Notifytion::DATA_ADD_MODE_ON_NOT_EXISTS), '如果不存在才添加,但居然添加了,上面是已添加过这个通知的');

		$appendMode = Notifytion::DATA_ADD_MODE_APPEND;
		try{
			$oNotifytion->add('a', 1, $appendMode);
			$this->assertTrue(true, '上一行竟然没抛出异常运算到这里了');
		}catch(ServerErrorHttpException $e){}

		$this->assertTrue($oNotifytion->add('b', 'x', $appendMode), '追加模式添加通知时失败');
		$this->assertTrue($oNotifytion->add('b', 'y', $appendMode), '第二次追加模式添加通知时失败');
    }

    /**
	 * 测试获取通知数据
	 * @depends testAdd
	 * @author 黄文非
	 */
    public function testGet()
    {
		$oNotifytion = new Notifytion();
		$value1 = 1;
		$oNotifytion->add('a', 1);
		$this->assertEquals($value1, $oNotifytion->get('a'), '覆盖模式添加的通知数据和获取出来的值不一样');
		$value2 = 2;
		$oNotifytion->add('a', $value2, Notifytion::DATA_ADD_MODE_ON_NOT_EXISTS);
		$this->assertEquals($value1, $oNotifytion->get('a'), '不存在才添加的模式执行后居然覆盖了上一次的通知数据');
		$oNotifytion->add('a', $value2, Notifytion::DATA_ADD_MODE_OVERWRITE);
		$this->assertEquals($value2, $oNotifytion->get('a'), '覆盖模式写入通知数据失败');

		$oNotifytion->add('b', 'x', Notifytion::DATA_ADD_MODE_APPEND);
		$this->assertEquals(['x'], $oNotifytion->get('b'), '追加模式第一次写入的数据读出来没有自动变成数组');
		$oNotifytion->add('b', 'y', Notifytion::DATA_ADD_MODE_APPEND);
		$this->assertEquals(['x', 'y'], $oNotifytion->get('b'), '第二次次追加后取出来的通知数据并不包含两个元素');
		$this->assertInternalType('array', $oNotifytion->aData, '全部通知数据并不是一个数组');
    }

    /**
	 * 测试移除通知数据
	 * @depends testAdd
	 * @depends testGet
	 * @author 黄文非
	 */
    public function testRemove()
    {
		$oNotifytion = new Notifytion();
		$oNotifytion->add('a', 1);
		$oNotifytion->remove('a');
		$this->assertEquals(null, $oNotifytion->get('a'), '移除覆盖模式写入的通知数据失败');

		$oNotifytion->add('b', 'x', Notifytion::DATA_ADD_MODE_APPEND);
		$oNotifytion->remove('b');
		$oNotifytion->add('b', 'y', Notifytion::DATA_ADD_MODE_APPEND);
		$this->assertEquals(['y'], $oNotifytion->get('b'), '移除后重新以追加模式添加的数据对比失败');
    }

}