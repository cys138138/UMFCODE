<?php
namespace tests\common\unit;

use common\model\StudentVisitor;
use umeworld\lib\Query;
use Yii;

/**
 * 用户来访测试
 * @author jay
 */
class StudentVisitorTest extends \Codeception\TestCase\Test{
	private $_userId = 0;
	private $_mStudentVisitor = null;
	private $_aStudentVisitorCache = [];
	private $_isAddVisitorFlag = false;

	protected function _before(){
		$this->_userId = \Yii::$app->test->commonStudent->id;
		$this->_mStudentVisitor = StudentVisitor::findOne(['praise_count' => 0]);
	}
	
	protected function _after(){
		$mStudentVisitor = $this->_mStudentVisitor;
		//然后恢复数据
		if($this->_aStudentVisitorCache){
			foreach($this->_aStudentVisitorCache as $key => $value){
				$mStudentVisitor->set($key, $value);
			}
			$mStudentVisitor->save();
			$this->_aStudentVisitorCache = [];
		}
		
		if($this->_isAddVisitorFlag){
			$mStudentVisitor->set('today_count', ['sub', 1]);
			$mStudentVisitor->set('all_count', ['sub', 1]);
			$mStudentVisitor->save();
			$this->_isAddVisitorFlag = false;
		}
	}
	
	
	/**
	 * 测试初始化数据
	 */
	public function testInitVisitorVisitor() {
		$this->assertInstanceOf('common\model\StudentVisitor', $this->_mStudentVisitor);
		$mStudentVisitor = $this->_mStudentVisitor;
		//先保存数据
		$this->_aStudentVisitorCache = $mStudentVisitor->toArray();
		$this->assertInternalType('array', $this->_aStudentVisitorCache);
		//再删除数据
		(new Query())->createCommand()->delete(StudentVisitor::tableName(), ['id' => $mStudentVisitor->id])->execute();
		$mStudentVisitor = StudentVisitor::initVisitor($mStudentVisitor->id);
		$this->assertInstanceOf('common\model\StudentVisitor', $mStudentVisitor);
	}
	
	/**
	 * 测试用户是否已赞
	 */
	public function testIsUserPraised() {
		$isUserPraised = $this->_mStudentVisitor->isUserPraised($this->_userId);
		$this->assertInternalType('boolean', $isUserPraised);
	}

	/**
	 * 测试用户赞
	 */
	public function testUserPraise() {
		$this->_mStudentVisitor->userPraise($this->_userId);
		$isUserPraised = $this->_mStudentVisitor->isUserPraised($this->_userId);
		$this->assertTrue($isUserPraised);
	}

	/**
	 * 测试用户是否来访过
	 */
	public function testIsUserVisited() {
		$isUserVisited = $this->_mStudentVisitor->isUserVisited($this->_userId);
		$this->assertInternalType('boolean', $isUserVisited);
	}

	/**
	 * 测试添加来访用户记录
	 */
	public function testAddVisitor() {
		$this->_mStudentVisitor->addVisitor($this->_userId);
		$isUserPraised = $this->_mStudentVisitor->isUserVisited($this->_userId);
		$this->assertTrue($isUserPraised);
		$this->_isAddVisitorFlag = true;
	}

}
