<?php
namespace tests\common\unit;

use Yii;
use common\model\ParentUser;
use common\model\Student;
use umeworld\lib\Query;
use common\xxt\gd\InterfaceGd;

class ParentTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    /**
	 * 测试获取性别
	 * @author 黄文非
	 */
    public function testGetGender()
    {
		$aParent = (new Query())->select(['id'])->from(ParentUser::tableName())->where(['<>', 'xxt_data', ''])->limit(1)->orderBy('rand()')->one();
		$mParent = ParentUser::findOne($aParent['id']);

		$gender = $mParent->getGender();
		$this->assertTrue(in_array($gender, [
			ParentUser::GENDER_MALE,
			ParentUser::GENDER_FEMALE,
			ParentUser::GENDER_UNKNOW,
		]), '家长性别应该在三个常量之一');
    }

	/**
	 * 测试添加登陆记录
	 * @author 黄文非
	 */
	public function testAddLoginLog(){
		$mParent = Yii::$app->test->getRandomParent();
		$logId = $mParent->addLoginLog();
		$this->assertGreaterThanOrEqual(0, $logId);
		(new Query())->createCommand()->delete(Student::loginLogTableName(), ['id' => $logId])->execute();
	}

}