<?php
namespace tests\common\base;

use Yii;
use common\model\Recharge;
use umeworld\lib\Query;

class RechargeTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    //protected $tester;
	private $_mStudent = 0;

    protected function _before(){
		$this->_mStudent = Yii::$app->test->commonStudent->getInstance();//Yii::$app->test->oCommonStudent->id;
    }

    /**
	 * 测试实例化Recharge模型 测试增加用户使用期限 initRecharge addUserLimitTime
	 * @author twl
	 */
    public function testInitRechargeAndAddUserLimitTime(){
		$numericalTableName = \common\model\UserNumerical::tableName();
		$mStudent = $this->_mStudent;
		$month = 1;
		$payMoney = Recharge::VIP_ONE_MONTH_PRINC * $month;
		//原来的vip期限时间
		$vipExpirationTime = $mStudent->vip_expiration_time;
		//vip 等级
		//$vipLevel = $mStudent->vip;
		$aData = [
			'user_id' 			=> $mStudent->id,
			'type'				=> Recharge::PRODUCT_VIP3,
			'quantity'			=> $month,
			'proxy_user_id'		=> 0,
			'by_proxy_user_id'	=> 0,
			'pay_type'			=> Recharge::PAY_TYPE_ALIPAY,
			'pay_money'			=> $payMoney,
			'serial_number'		=> '',
			'pay_finish'		=> 0,
			'ub_finish'			=> 0,
		];
		$mRecharge = Recharge::initRecharge($aData);
		$this->assertInstanceOf('common\model\Recharge', $mRecharge);
		//测试增加用户使用期限
		$limitTime = $mRecharge->addUserLimitTime($mRecharge->user_id, $mRecharge->quantity, 2);
		$this->assertTrue((bool)$limitTime);
		$this->assertGreaterThan(0, $limitTime);
		$this->tester->seeInDataBase($numericalTableName, [
			'id' => $mStudent->id,
			'vip_expiration_time' => $limitTime,
		]);
		
		//恢复原始用户使用期限
		$mStudent->set('vip_expiration_time', $vipExpirationTime);
		$mStudent->save();
		$this->tester->seeInDataBase($numericalTableName, [
			'id' => $mStudent->id,
			'vip_expiration_time' => $vipExpirationTime,
		]);
		//去除测试数据
		(new Query())->createCommand()->delete(Recharge::tableName(), ['id' => $mRecharge->id])->execute();
    }
}