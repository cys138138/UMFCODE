<?php
namespace tests\common\game;

use common\model\Prop;
use common\business\Game;

class PropTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    /**
	 * 测试获取特定场景下的道具类型
	 * @author 黄文非
	 */
    public function testGetSceneTypes()
    {
		$this->assertInternalType('array', Prop::getSceneTypes(Game::GAME_MISSION_PRACTICE));
		$this->assertInternalType('array', Prop::getSceneTypes(Game::GAME_MISSION_CHALLENGE));
		$this->assertInternalType('array', Prop::getSceneTypes(Game::GAME_PK));
		$this->assertInternalType('array', Prop::getSceneTypes(Game::GAME_MATCH));
    }

}