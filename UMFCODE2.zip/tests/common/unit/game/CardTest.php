<?php
namespace tests\common\unit\game;
use common\model\Card;
use common\model\CardGroup;
use common\business\Game;

/**
 * 卡牌测试
 * @author  zhangliping
 */
class CardTest extends \Codeception\TestCase\Test{
	use \Codeception\Specify;

	protected $_mCard = null;

	protected function _before(){
		if(in_array($this->getName(), ['testGetCardCount', 'testGetCardList'])){
			$this->_mCard = Card::findOne(1);
			$this->_mCardGroup = CardGroup::findOne(1);
			$this->assertInstanceOf('common\model\Card', $this->_mCard);
			$this->assertInstanceOf('common\model\CardGroup', $this->_mCardGroup);
		}
	}

	/**
	 * 测试基本的卡牌读取
	 * @author  zhangliping
	 */
	public function testCard(){
		$mCard = Card::findOne(1);
		$this->assertTrue(is_object($mCard));
	}

	/**
	 * 测试所有卡牌ID列表
	 * @author  zhangliping
	 */
	public function testGetAllCardIdList(){
		$aCardIdList = Card::getAllCardIdList();
		$this->assertTrue(is_array($aCardIdList));
		if(is_array($aCardIdList)){
			foreach($aCardIdList as $id){
				$this->assertTrue(is_numeric($id));
			}
		}
	}

	/**
	 * 测试随机普通抽卡
	 * @author  zhangliping
	 */
	public function testGetOneRandomNormalCard(){
			$mCard = Card::getOneRandomNormalCard();
			if(is_object($mCard)){
				$this->assertInstanceOf('common\model\Card', $mCard);
			}elseif (is_string($mCard)) {
				$this->assertEquals('magic', $mCard);
			}else{
				throw new Exception("随机抽取的普通卡牌有错误!!");	
			} 
	}

	/**
	 * 测试卡牌分组
	 * @author  zhangliping
	 */
	public function testGetCardGroupList(){
		$this->specify('测试卡牌每个分组是否正确', function(){
			foreach(CardGroup::getCardGroupList() as $mCardGroup){
				$this->assertInstanceOf('common\model\CardGroup', $mCardGroup);
			}
		});

		$this->specify('测试卡牌每个分组实例与配置文件的对比', function(){
			$aCardConfig = require(YII_APP_BASE_PATH . '/common/config/model/cards.php');
			foreach($aCardConfig as $aCardGroup){
				$mCardGroup = CardGroup::findOne($aCardGroup['id']);
				$this->assertInstanceOf('common\model\CardGroup', $mCardGroup);
				$this->assertTrue($mCardGroup->getCardCount() == count($aCardGroup['card_list']));
			}
		});
	}

	/**
	 * 测试随机抽取一张卡牌
	 * @author  zhangliping
	 */
	public function testGetOneRandomCard(){
		$mCard = Card::getOneRandomCard(Game::GAME_MISSION_CHALLENGE);
		if(is_string($mCard)){
			$this->assertEquals('magic', $mCard);
		}elseif (is_object($mCard)) {
			$this->assertInstanceOf('common\model\Card', $mCard);
		}else{
			throw new Exception("抽取的卡牌有错误!!");	 
		}
	}

	/**
	 * 测试获取本组卡牌的卡牌数量
	 * @author  zhangliping
	 */
	public function testGetCardCount(){
		$count = $this->_mCardGroup->getCardCount();
		$this->assertInternalType('int', $count);
		$this->assertGreaterThan(0, $count);
	}

	/**
	 * 测试获取本组卡牌的卡牌列表
	 * @author  zhangliping
	 */
	public function testGetCardList(){
		$aCardList = $this->_mCardGroup->getCardList();
		$this->assertInternalType('array', $aCardList);
		$this->assertGreaterThan(0, count($aCardList));
	}
 
}
