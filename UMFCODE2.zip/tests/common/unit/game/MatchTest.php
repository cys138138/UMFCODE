<?php
namespace tests\common\game;

use Yii;
use common\model\Match;
use common\model\StudentMatch;
use yii\helpers\ArrayHelper;
use umeworld\lib\Query;

class MatchTest extends \Codeception\TestCase\Test
{
	use \Codeception\Specify;


	protected $_testBigMatchId = 0;		//测试大赛的id
	protected $_testDailyMatchId = 0;	//测试日常比赛的id
	protected $_mBigMatch = null;		//大赛模型实例
	protected $_mDailyMatch = null;		//日常比赛模型实例
	protected $_mStudentDailyMatch = null;	//日常比赛用户参赛模型实例
	protected $_mStudentBigMatch = null;	//大赛用户参赛模型实例
	protected $_mStudent = null;			//学生模型实例
	protected $_mEs = null;					//比赛当前题目

	protected function _before(){
		$this->_mStudent = Yii::$app->test->commonStudent->getInstance();
		//!!!!!临时改动
		Yii::setAlias('tests', Yii::getAlias(UMFUN_TEST_PROJECT_PATH));
		//向数据库加一场大赛用来测试
		$matchId = \tests\manage\unit\game\MatchTest::buildBigMatch();
		$this->_mBigMatch = Match::findOne($matchId);
		$this->_testBigMatchId = $matchId;

		//像数据库加一场日常比赛用来测试
		$matchId = \tests\manage\unit\game\MatchTest::buildDailyMatch();
		$this->_mDailyMatch = Match::findOne($matchId);
		$this->_testDailyMatchId = $matchId;
	}

	protected function _after(){
		//删除加入的测试比赛并删除这些比赛的参赛数据
		$aMatchUserRelationIds = StudentMatch::getMatchUserRelationList(['match_id' => [$this->_testBigMatchId, $this->_testDailyMatchId]], ['select' => ['id']]);
		if($aMatchUserRelationIds){
			$aRelationIds = ArrayHelper::getColumn($aMatchUserRelationIds, 'id');
			(new Query())->createCommand()->delete(StudentMatch::tableName(), ['id' => $aRelationIds])->execute();
			(new Query())->createCommand()->delete(StudentMatch::dataTableName(), ['id' => $aRelationIds])->execute();
		}

		//删除加入的测试比赛
		(new Query())->createCommand()->delete(Match::tableName(), ['id' => [$this->_testBigMatchId, $this->_testDailyMatchId]])->execute();
	}

	public function testMatch(){
		//测试大赛实例化是否正常
		$this->_testBuildBigMatch();

		//测试日常比赛实例化是否正常
		$this->_testBuildDailyMatch();

		//测试模型能否正常找到大赛
		$this->_testMatchModelGetBigMatchHall();

		//测试模型能否正常找到日常比赛
		$this->_testMatchModelGetDailyMatchHall();

		//测试StudentModel::getUserMatchStatus是否正确---目前应该是可参赛状态
		$this->_testStudentMatchModelGetUserMatchStatus(StudentMatch::CAN_JOIN_MATCH);

		//测试用户参赛
		$this->_testStudentMatchInitUserMatch();

		//测试StudentModel::getUserMatchStatus是否正确---目前应该是可以继续比赛状态
		$this->_testStudentMatchModelGetUserMatchStatus(StudentMatch::CAN_CONTINUE_MATCH);

		//测试模型能否正常统计参赛人数
		$this->_testMatchModelGetJoinMatchStudentCount();

		//测试模型能否正常统计题目数
		$this->_testMatchModelGetMatchEsCount();

		//测试模型能否正常统计题目数
		$this->_testMatchModelGetNearestJoinMatchUserList();

		//测试是否能正常获取用户年级组
		$this->_testMatchModelGetGradeGroupGradeIdListByGradeId();

		//测试是否能正常获取比赛的状态
		$this->_testMatchModelGetMatchStatus();

		//测试分配题目数量是否正确
		$this->_testMatchModelDistributeEsList();

		//测试拿出当前题目实例是否正常
		$this->_testStudentMatchModelGetMatchEs();

		//测试答题全过程
		while(!$this->_mStudentDailyMatch->isFinishMatch()){
			//测试比赛出题
			$this->_testStudentMatchModelGetNextMatchEs();

			//测试比赛答题
			$this->_testStudentMatchAnswerEs();
		}

		//检查比赛完成后的结果是否正确
		$this->_checkFinishMatchResult();

		//测试比赛历史记录是否正常
		$this->_testStudentMatchGetMatchHistory();

		//测试比赛排名是否正确
		$this->_testStudentMatchGetUserRanking();

		//测试按分数排名
		$this->_testStudentMatchGetUserRankingByScore();

		//测试获取最近的成绩
		$this->_testStudentMatchGetLatelyMatchScore();

		//测试用户正确率
		$this->_testStudentMatchGetMatchCorrectPercent();

		//测试比赛加积分是否正确
		$this->_testStudentMatchGetAnswerExperience();

		//测试StudentModel::getUserMatchStatus是否正确---目前应该是可以继续比赛状态
		$this->_testStudentMatchModelGetUserMatchStatus(StudentMatch::CAN_JOIN_AGAIN);

		//测试获取用户排名是否正确
		$this->_testMatchModelGetMatchScoreRakingList();

		//保存获奖用户
		$this->_saveWinners();

		//测试StudentModel::getUserMatchStatus是否正确---目前应该是可以继续比赛状态
		$this->_testStudentMatchModelGetUserMatchStatus(StudentMatch::CAN_ACCEPT_PRIZE);

		//测试获奖列表
		$this->_testMatchModelGetMatchWinnerList();

		//获取用户获得的奖品
		$this->_testStudentMatchModelGetMatchWinnerList();

		//测试用户领奖
		$this->_testStudentMatchReceiveUserPrize();

		//测试模型是否能正常筛选出用户的赛事列表
		$this->_testStudentMatchModelGetUserMatchList();

		//测试模型是否可以拿到最后一次参赛填写的地址
		$this->_testStudentMatchModelGetUserLastMatchAddress();

		//测试模型再次参赛是否正常
		$this->_testStudentMatchModelJoinMatchAgain();

		//测试完成比赛抽奖
		$this->_testStudentMatchModelDrawFinishPrize();

		//测试是否完成过一次比赛和是否可以答题
		$this->_testStudentMatchModelIsFinishedFirstAndIsCanAnswerMatch();
	}

	/**
	 * 测试创建大赛并测试实例化比赛
	 */
	private function _testBuildBigMatch(){
		$this->assertGreaterThan(0, $this->_testBigMatchId);
		$this->assertInstanceOf('common\model\Match', $this->_mBigMatch);
	}

	/**
	 * 测试创建日常比赛并测试实例化比赛
	 */
	private function _testBuildDailyMatch(){
		$this->assertGreaterThan(0, $this->_testDailyMatchId);
		$this->assertInstanceOf('common\model\Match', $this->_mDailyMatch);
	}

	/**
	 * 测试模型能否正常找到大赛
	 */
    private function _testMatchModelGetBigMatchHall(){
		$aUserType = [0, \common\xxt\gd\InterfaceGd::PLATFORM_TYPE, \common\xxt\sx\InterfaceSx::PLATFORM_TYPE];
		foreach($aUserType as $userType){
			$aBigMatchList = Match::getBigMatchHall(['xxt_type' => $userType]);
			$this->assertTrue(is_array($aBigMatchList));
			$aStruct = [
				'id',
				'name',
				'big_match_profile',
				'duration',
				'es_count',
				'is_big_match',
				'join_match_count',
				'limit_grades',
				'match_start_time',
				'match_end_time',
				'status',
			];
			foreach($aBigMatchList as $aBigMatch){
				$this->tester->assertCompareArrayStruct($aBigMatch, $aStruct);
			}
		}
	}

	/**
	 * 测试模型能否正常找到日常比赛
	 */
	private function _testMatchModelGetDailyMatchHall(){
		$aUserType = [0, \common\xxt\gd\InterfaceGd::PLATFORM_TYPE, \common\xxt\sx\InterfaceSx::PLATFORM_TYPE];
		foreach($aUserType as $userType){
			$aDailyMatchList = Match::getDailyMatchHall(['xxt_type' => $userType]);
			$this->assertTrue(is_array($aDailyMatchList));
			$aStruct = [
				'id',
				'name',
				'profile',
				'duration',
				'es_count',
				'is_big_match',
				'join_match_count',
				'limit_grades',
				'match_start_time',
				'match_end_time',
				'status',
				'subject_id',
				'grade_id',
			];
			foreach($aDailyMatchList as $aDailyMatch){
				$this->tester->assertCompareArrayStruct($aDailyMatch, $aStruct);
			}
		}
	}

	/**
	 * 测试用户参赛
	 */
	private function _testStudentMatchInitUserMatch(){

		$aUserData = [
			'user_id'	=> $this->_mStudent->id,
			'match_id'	=> $this->_testDailyMatchId,
			'grade_id'	=> $this->_mStudent->grade,
			'address'	=>	[
				'call_phone'	=>	13802444214,
				'address'		=>	'新港东',
				'qq'			=>	270078578,
				'name'			=>	'太上皇',
				'province_id'	=>	440000,
				'city_id'		=>	440100,
				'area_id'		=>	440105,
			],
		];
		$this->_mStudentDailyMatch = StudentMatch::initUserMatch($aUserData);
		$this->assertInstanceOf('common\model\studentMatch', $this->_mStudentDailyMatch);
		$aUserData = [
			'user_id'	=>	$this->_mStudent->id,
			'match_id'	=> $this->_testBigMatchId,
			'grade_id'	=> $this->_mStudent->grade,
			'address'	=>	[
				'call_phone'	=>	13802444214,
				'address'		=>	'新港东',
				'qq'			=>	270078578,
				'name'			=>	'太上皇',
				'province_id'	=>	440000,
				'city_id'		=>	440100,
				'area_id'		=>	440105,
			],
		];
		$this->_mStudentBigMatch = StudentMatch::initUserMatch($aUserData);
		$this->assertInstanceOf('common\model\studentMatch', $this->_mStudentBigMatch);
	}

	/**
	 * 测试模型能否正常统计参赛人数
	 */
	private function _testMatchModelGetJoinMatchStudentCount(){
		$count = $this->_mBigMatch->getJoinMatchStudentCount();
		$this->assertEquals(1, $count);

		$count = $this->_mDailyMatch->getJoinMatchStudentCount();
		$this->assertEquals(1, $count);
	}

	/**
	 * 测试模型能否正常统计题目数
	 */
	private function _testMatchModelGetMatchEsCount(){
		$count = $this->_mBigMatch->getMatchEsCount();
		$this->assertEquals(10, $count);

		$count = $this->_mDailyMatch->getMatchEsCount();
		$this->assertEquals(6, $count);
	}

	/**
	 * 测试模型能否正常统计题目数
	 */
	private function _testMatchModelGetNearestJoinMatchUserList(){
		$aControl = [
			'page'	=>	1,
			'page_size'	=>	1
		];
		$aUserRelationList = $this->_mBigMatch->getNearestJoinMatchUserList($aControl);
		$aStruct = [
			'id',
			'user_id',
			'best_score',
			'user_info'	=>	[
				'id',
				'name',
				'profile',
				'year',
				'school_name',
				'grade',
				'class',
				'vip',
			],
		];
		$this->tester->assertCompareArrayStruct($aUserRelationList[0], $aStruct);
	}

	/**
	 * 测试是否能正常获取用户年级组
	 */
	private function _testMatchModelGetGradeGroupGradeIdListByGradeId(){
		$aGradeList = $this->_mBigMatch->getGradeGroupGradeIdListByGradeId($this->_mStudent->grade);
		$aGradeGroup13 = explode(',', Match::GRADE_GROUP_ONE_TO_THREE_GRADES);
		$aGradeGroup46 = explode(',', Match::GRADE_GROUP_FOUR_TO_SIX_GRADES);
		$aGradeGroup79 = explode(',', Match::GRADE_GROUP_SEVEN_TO_NINE_GRADES);
		$aTargetGradeGroup = [];
		if(in_array($this->_mStudent->grade, $aGradeGroup13)){
			$aTargetGradeGroup = $aGradeGroup13;
		}elseif(in_array($this->_mStudent->grade, $aGradeGroup46)){
			$aTargetGradeGroup = $aGradeGroup46;
		}elseif(in_array($this->_mStudent->grade, $aGradeGroup79)){
			$aTargetGradeGroup = $aGradeGroup79;
		}
		$this->assertEquals($aGradeList, $aTargetGradeGroup);
	}

	/**
	 * 测试是否能正常获取比赛的状态
	 */
	private function _testMatchModelGetMatchStatus(){
		//目前是进行中的
		$status = $this->_mDailyMatch->getMatchStatus();
		$this->assertEquals($status, Match::ON_THE_MATCH);

		$matchStartTime = $this->_mDailyMatch->match_start_time;
		$matchEndTime = $this->_mDailyMatch->match_end_time;

		//设置成未开始的
		$this->_mDailyMatch->set('match_start_time', NOW_TIME + 600);
		$this->_mDailyMatch->set('match_end_time', NOW_TIME + 3600);
		$this->_mDailyMatch->save();
		$status = $this->_mDailyMatch->getMatchStatus();
		$this->assertEquals($status, Match::MATCH_NOT_START);

		//测试StudentModel::getUserMatchStatus是否正确---目前应该是比赛未开始状态
		$this->_testStudentMatchModelGetUserMatchStatus(Match::MATCH_NOT_START);

		//设置成已结束的
		$this->_mDailyMatch->set('match_start_time', NOW_TIME - 3600);
		$this->_mDailyMatch->set('match_end_time', NOW_TIME - 600);
		$this->_mDailyMatch->save();
		$status = $this->_mDailyMatch->getMatchStatus();
		$this->assertEquals($status, Match::END_OF_MATCH);

		//测试StudentModel::getUserMatchStatus是否正确---目前应该是比赛已结束状态
		$this->_testStudentMatchModelGetUserMatchStatus(Match::END_OF_MATCH);

		//恢复原来的开始和结束时间
		$this->_mDailyMatch->set('match_start_time', $matchStartTime);
		$this->_mDailyMatch->set('match_end_time', $matchEndTime);
		$this->_mDailyMatch->save();
	}

	/**
	 * 测试分配题目数量是否正确
	 */
	private function _testMatchModelDistributeEsList(){
		$this->assertEquals(count($this->_mStudentBigMatch->remainder_es_ids), 10);
	}

	/**
	 * 测试拿出当前题目实例是否正常
	 */
	protected  function _testStudentMatchModelGetMatchEs(){
		$mEs = $this->_mStudentDailyMatch->getMatchEs();
		$this->assertInstanceOf('common\model\Es', $mEs);
		$aRemainderEsIds = $this->_mStudentDailyMatch->remainder_es_ids;
		$esId = current($aRemainderEsIds);
		$this->assertEquals($mEs->id, $esId);
	}

	/**
	 * 测试比赛是否能正常拿到题目
	 */
	private function _testStudentMatchModelGetNextMatchEs(){
		$this->_mEs = $this->_mStudentDailyMatch->getNextMatchEs();
		$this->assertInstanceOf('common\model\Es', $this->_mEs);
	}

	/**
	 * 测试比赛是否能正常作答
	 */
	private function _testStudentMatchAnswerEs(){
		$aAnswer = $this->_mEs->getAnswer();
		$isCorrect = $this->_mStudentDailyMatch->answerEs($aAnswer);
		$this->assertEquals($isCorrect, true);
	}

	/**
	 * 检查比赛完成后的结果是否正确
	 */
	private function _checkFinishMatchResult(){
		//测试分数是否正常
		$this->_testStudentMatchGetMatchBestScore();

		//测试完成时间、开始时间、最好成绩时间和第一次完成时间
		$this->assertEquals($this->_mStudentDailyMatch->start_time, NOW_TIME);
		$this->assertEquals($this->_mStudentDailyMatch->end_time, NOW_TIME);
		$this->assertEquals($this->_mStudentDailyMatch->best_score_time, NOW_TIME);
		$this->assertEquals($this->_mStudentDailyMatch->first_finish_time, NOW_TIME);

		//测试历史记录是否正确
		$aHistory = $this->_mStudentDailyMatch->match_history;
		$aHistoryOne = array_pop($aHistory);
		$this->assertEquals($aHistoryOne['start_time'], NOW_TIME);
		$this->assertEquals($aHistoryOne['end_time'], NOW_TIME);
		$this->assertEquals($aHistoryOne['score'], 10000);
	}

	/**
	 * 检查计分是否正确
	 */
	private function _testStudentMatchGetMatchBestScore(){
		$this->assertEquals($this->_mStudentDailyMatch->getMatchBestScore(), 100);
	}

	/**
	 * 测试获取用户排名是否正确
	 */
	private function _testMatchModelGetMatchScoreRakingList(){
		$aConditon = ['user_grade_id' => $this->_mStudentBigMatch->user_grade_id];
		$aControl = [
			'page'	=>	1,
			'page_size'	=>	1,
		];
		$aMatchRankingList = $this->_mBigMatch->getMatchScoreRakingList($aControl, $aConditon);
		$aStruct = [
			'id',
			'user_id',
			'best_score',
			'user_info'	=>	[
				'id',
				'name',
				'profile',
				'year',
				'school_name',
				'grade',
				'class',
				'vip',
			],
		];
		$this->tester->assertCompareArrayStruct($aMatchRankingList[0], $aStruct);
	}

	/**
	 * 保存获奖用户
	 */
	private function _saveWinners(){
		$mMatch = \manage\model\Match::findOne($this->_mBigMatch->id);
		$aAwardsList = $mMatch->getPrizeUserList();
		$mMatch->saveWinners($aAwardsList['top'], $aAwardsList['rand']);
		//跟新获奖的状态
		$this->_mStudentBigMatch->set('prize_status', StudentMatch::PRIZE_UNRECEIVED);

		$mMatch = \manage\model\Match::findOne($this->_mDailyMatch->id);
		$aAwardsList = $mMatch->getPrizeUserList();
		$mMatch->saveWinners($aAwardsList['top'], $aAwardsList['rand']);
		//跟新获奖的状态
		$this->_mStudentDailyMatch->set('prize_status', StudentMatch::PRIZE_UNRECEIVED);
	}

	private function _testMatchModelGetMatchWinnerList(){
		$aWinnerList = $this->_mBigMatch->getMatchWinnerList();
		$aStruct = [
			'user_id',
			'receive_time',
			'user_info'	=>	[
				'id',
				'name',
				'profile',
				'vip',
			],
			'best_score',
		];
		foreach($aWinnerList as $type => $aTypeWinners){
			if($type != 'create_time'){
				foreach($aTypeWinners as $aGroupWinnerList){
					foreach($aGroupWinnerList as $aWinner){
						if($aWinner){
							$this->tester->assertCompareArrayStruct($aWinner, $aStruct);
						}
					}
				}
			}
		}
	}

	/**
	 * 测试用户获得的奖品
	 */
	protected function _testStudentMatchModelGetMatchWinnerList(){
		$aUserPrize = $this->_mStudentBigMatch->getUserPrize();
		$aStruct = [
			'gold',
			'prize',
		];
		$this->tester->assertCompareArrayStruct($aUserPrize, $aStruct);
	}

	/**
	 * 测试用户领奖
	 */
	protected function _testStudentMatchReceiveUserPrize(){
		$this->_mStudentBigMatch->receiveUserPrize();
		$this->assertEquals($this->_mStudentBigMatch->prize_status, StudentMatch::PRIZE_RECEIVED);
		$aWinnerList = $this->_mBigMatch->getMatchWinnerList();
		foreach($aWinnerList as $type => $aTypeWinners){
			if($type != 'create_time'){
				foreach($aTypeWinners as $aGroupWinnerList){
					foreach($aGroupWinnerList as $aWinner){
						if($aWinner){
							$this->assertEquals($aWinner['receive_time'], NOW_TIME);
						}
					}
				}
			}
		}
	}

	/**
	 * 测试模型是否能正常筛选出用户的赛事列表
	 */
	protected function _testStudentMatchModelGetUserMatchList(){
		$userId = Yii::$app->test->commonStudent->id;
		$aPrizeFlag = [true, false];
		$aOrder = ['', 'create_time', 'best_score', 'ranking'];
		foreach($aPrizeFlag as $prizeFlag){
			foreach($aOrder as $order){
				$aCondition = [
					'user_id' => $userId,
					'prize_flag' => $prizeFlag,
				];
				$aControl = [
					'order' => $order,
					'page' => 1,
					'page_size' => 5,
				];
				$aUserMatchList = StudentMatch::getUserMatchList($aCondition, $aControl);
				$aStruct = [
					'id',
					'name',
					'profile',
					'description',
					'grade_id',
					'status',
					'subject_id',
					'join_match_count',
					'match_user_relation' => [
						'best_score',
						'ranking',
						'prize_status',
					],
				];
				$this->assertTrue(is_array($aUserMatchList));
				foreach($aUserMatchList as $aUserMatch){
					$this->tester->assertCompareArrayStruct($aUserMatch, $aStruct);
					if($prizeFlag){
						$this->assertGreaterThan(0, $aUserMatch['match_user_relation']['prize_status']);
					}
				}
			}
		}
	}

	/**
	 * 测试模型是否可以拿到最后一次参赛填写的地址
	 */
	protected function _testStudentMatchModelGetUserLastMatchAddress(){
		$aAddress = StudentMatch::getUserLastMatchAddress($this->_mStudent->id);
		$this->assertTrue(is_array($aAddress));
		$aStruct = [
			'call_phone',
			'address',
			'qq',
			'name',
			'province_id',
			'city_id',
			'area_id',
		];
		$this->tester->assertCompareArrayStruct($aAddress, $aStruct);
	}

	/**
	 * 测试拿到用户参赛状态是否正确
	 * @param type $expectStatu 预计的状态
	 */
	protected function _testStudentMatchModelGetUserMatchStatus($expectStatu){
		if($expectStatu == StudentMatch::CAN_ACCEPT_PRIZE){
			$matchEndTime = $this->_mDailyMatch->match_end_time;
			//设置成结束的
			$this->_mDailyMatch->set('match_end_time', NOW_TIME - 100);
			$this->_mDailyMatch->save();

			$status = StudentMatch::getUserMatchStatus($this->_mDailyMatch, $this->_mStudentDailyMatch);
			$this->assertEquals($status, $expectStatu);
			//还原
			$this->_mDailyMatch->set('match_end_time', $matchEndTime);
			$this->_mDailyMatch->save();
		}else{
			$status = StudentMatch::getUserMatchStatus($this->_mDailyMatch, $this->_mStudentDailyMatch);
			$this->assertEquals($status, $expectStatu);
		}
	}

	/**
	 * 测试用户的参赛记录是否正常
	 */
	private function _testStudentMatchGetMatchHistory(){
		$aHistory = $this->_mStudentDailyMatch->getMatchHistory();
		$aStruct = [
			'start_time',
			'end_time',
			'score',
		];
		$aHistory = $aHistory[0];
		$this->tester->assertCompareArrayStruct($aHistory, $aStruct);
		$this->assertEquals($aHistory['start_time'], NOW_TIME);
		$this->assertEquals($aHistory['end_time'], NOW_TIME);
		$this->assertEquals($aHistory['score'], 100);
	}

	/**
	 * 测试用户排名是否正确
	 */
	private function _testStudentMatchGetUserRanking(){
		$ranking = $this->_mStudentDailyMatch->getUserRanking();
		$this->assertEquals($ranking, 1);
	}

	/**
	 * 测试按分数排名
	 */
	private function _testStudentMatchGetUserRankingByScore(){
		$ranking = $this->_mStudentDailyMatch->getUserRankingByScore(10000);
		$this->assertEquals($ranking, 1);
		$ranking = $this->_mStudentDailyMatch->getUserRankingByScore(9999);
		$this->assertEquals($ranking, 2);
	}

	/**
	 * 测试获取最近的成绩
	 */
	private function _testStudentMatchGetLatelyMatchScore(){
		$score = $this->_mStudentDailyMatch->getLatelyMatchScore();
		$this->assertEquals($score, 100);
	}

	/**
	 * 测试获取正确率
	 */
	private function _testStudentMatchGetMatchCorrectPercent(){
		$correctPercent = $this->_mStudentDailyMatch->getMatchCorrectPercent();
		$this->assertEquals($correctPercent, 1);
	}

	/**
	 * 测试比赛加积分是否正确
	 */
	private function _testStudentMatchGetAnswerExperience(){
		$experience = $this->_mStudentDailyMatch->getAnswerExperience(true);
		$this->assertEquals($experience, 1);
		$experience = $this->_mStudentDailyMatch->getAnswerExperience(false);
		$this->assertEquals($experience, 0);
	}

	/**
	 * 测试再次参赛
	 */
	private function _testStudentMatchModelJoinMatchAgain(){
		$result = $this->_mStudentDailyMatch->joinMatchAgain($this->_mStudentDailyMatch->address);
		$this->assertEquals($result, 2);
		$this->assertEquals($this->_mStudentDailyMatch->start_time, 0);
		$this->assertEquals($this->_mStudentDailyMatch->end_time, 0);
		$this->assertEquals($this->_mStudentDailyMatch->is_can_draw, 0);
		$this->assertEquals($this->_mStudentDailyMatch->rejoin_times, 1);
		$this->assertEquals($this->_mStudentDailyMatch->correct_es_count, 0);
		$this->assertEquals(count($this->_mStudentDailyMatch->remainder_es_ids), $this->_mStudentDailyMatch->getMatch()->getMatchEsCount());
	}

	/**
	 * 测试完成比赛抽奖
	 */
	private function _testStudentMatchModelDrawFinishPrize(){
		$gold = $this->_mStudentDailyMatch->drawFinishPrize();
		$this->assertTrue(is_numeric($gold));
		$this->assertGreaterThanOrEqual(0, $gold);
	}

	/**
	 * 测试是否完成了第一次比赛，是否可以比赛答题
	 */
	private function _testStudentMatchModelIsFinishedFirstAndIsCanAnswerMatch(){
		//目前是再次参赛阶段还没开始应该不可以答题(没点开始)，并且是完成过一次比赛的
		$this->assertTrue($this->_mStudentDailyMatch->isFinishedFirst());
		$this->assertFalse($this->_mStudentDailyMatch->isCanAnswerMatch());
		//开始比赛--这个时候是可以答题的
		$this->_mStudentDailyMatch->set('start_time', NOW_TIME);
		$this->assertTrue($this->_mStudentDailyMatch->isCanAnswerMatch());
		//清空题目--这个时候应该不能答题了
		$aRemainderEsIds = $this->_mStudentDailyMatch->remainder_es_ids;
		$this->_mStudentDailyMatch->set('remainder_es_ids', []);
		$this->assertFalse($this->_mStudentDailyMatch->isCanAnswerMatch());

		//设置为超时
		$this->_mStudentDailyMatch->set('remainder_es_ids', $aRemainderEsIds);
		$matchDuration = $this->_mStudentDailyMatch->getMatch()->duration;
		$this->_mStudentDailyMatch->set('start_time', NOW_TIME - $matchDuration * 60 - 1);
		$this->assertFalse($this->_mStudentDailyMatch->isCanAnswerMatch());
		$this->_mStudentDailyMatch->set('start_time', NOW_TIME);
		$this->assertTrue($this->_mStudentDailyMatch->isCanAnswerMatch());

		//修改first_finish_time为0，目前是第一次超时完成的情况
		$this->_mStudentDailyMatch->set('first_finish_time', 0);
		$this->assertTrue($this->_mStudentDailyMatch->isFinishedFirst());

		//修改rejoin_times = 0,目前是第一次参赛中的情况
		$this->_mStudentDailyMatch->set('rejoin_times', 0);
		$this->assertFalse($this->_mStudentDailyMatch->isFinishedFirst());

		//第一次参赛超时情况
		$this->_mStudentDailyMatch->set('start_time', NOW_TIME - $matchDuration * 60 - 1);
		$this->assertTrue($this->_mStudentDailyMatch->isFinishedFirst());

		//第一次参赛，未超时完成了比赛
		$this->_mStudentDailyMatch->set('start_time', NOW_TIME);
		$this->_mStudentDailyMatch->set('first_finish_time', NOW_TIME);
		$this->assertTrue($this->_mStudentDailyMatch->isFinishedFirst());
	}
}