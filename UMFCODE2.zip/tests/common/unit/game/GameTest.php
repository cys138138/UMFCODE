<?php
namespace tests\common\game;

use Yii;
use common\business\Game;
use yii\helpers\ArrayHelper;
use common\model\Dan;
use common\model\UserMonthStatistics;

class GameTest extends \Codeception\TestCase\Test
{
	use \Codeception\Specify;

	public $testStudentId = 0;
	private $_userId = 0;
	private $_mStudent = null;
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
		//测试前可以向数据库初始化一些模拟数据
		$this->testStudentId = Yii::$app->test->commonStudent->id;
		$this->_userId = Yii::$app->test->commonStudent->id;
		$this->_mStudent = Yii::$app->test->commonStudent->getInstance();
		Yii::$app->student->login($this->_mStudent);
    }

    protected function _after()
    {
    }

    /**
	 * 测试计算一次单纯的修炼作答应得的分数
	 * @author 黄文非
	 */
    public function testSumPracticeAnswerExperience()
    {
		$testTimes = count(Yii::$app->params['mission']['practice']['answer_right']);
		for($i = 1; $i <= $testTimes; $i++){
			$aConfigItem = Yii::$app->params['mission']['practice']['answer_right'][$i - 1];
			$this->assertEquals($aConfigItem['prize'][0]['value'], Game::sumPracticeAnswerExperience($i));
		}
    }

	 /**
	 * 测试根据用户段位计算卡牌兑换率
	 * @author jay
	 */
    public function testGetExchangeCardsRateByUserDan(){
		$aExchangeCardsRate = ArrayHelper::getColumn(Dan::getDanList(), 'exchange_cards_rate');
		$rate = Game::getExchangeCardsRateByUserDan();
		$this->assertContains($rate, $aExchangeCardsRate);
	}

	 /**
	 * 测试答题得分计算
	 * @author jay
	 */
    public function testScoringComputation(){
		$leftTime = 100;
		$totalTime = 300;
		$correctPercent = 0.5;
		$score = Game::scoringComputation($leftTime, $totalTime, $correctPercent);
		$this->assertGreaterThan(0, $score);
		$this->assertLessThan(10000, $score);
	}

	 /**
	 * 测试能力值计算方法
	 * @author jay
	 */
    public function testAutoCountScore(){
		$mUserMonthStatistics = UserMonthStatistics::findOne(['user_id' => $this->_userId]);
		$this->assertInstanceOf('common\model\UserMonthStatistics', $mUserMonthStatistics);
		$score = Game::autoCountScore($mUserMonthStatistics->statistics);
		$this->assertGreaterThanOrEqual(0, $score);
		$this->assertLessThanOrEqual(100, $score);
	}

	 /**
	 * 测试获取随机游戏提示
	 * @author jay
	 */
    public function testGetRandomGameTips(){
		$aGameTips = include_once(Yii::getAlias('@home/config/tips_game.php'));
		$aModule = array_keys($aGameTips);
		foreach($aModule as $module){
			$num = mt_rand(1, 5);
			$aTipsList = Game::getRandomGameTips($module, $num);
			$this->assertInternalType('array', $aTipsList);
			$this->assertCount($num, $aTipsList);
		}
	}

	 /**
	 * 测试获取用户等级
	 * @author jay
	 */
    public function testGetStudentLevel(){
		$aLevel = Yii::$app->params['level'];
		$experience = mt_rand(current($aLevel), end($aLevel));
		$level = Game::getStudentLevel($experience);
		$this->assertGreaterThanOrEqual(0, $level);
		$this->assertLessThanOrEqual(count($aLevel), $level);
	}

    /**
	 * 测试获取游戏场景列表
	 * @author 黄文非
	 */
	public function testGetScenes(){
		$this->assertInternalType('array', Game::getScenes());
	}
}