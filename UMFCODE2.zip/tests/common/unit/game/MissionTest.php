<?php
namespace tests\common\unit\game;

use Yii;
use common\model\Grade;
use common\model\Subject;
use common\model\Mission;
use common\model\UserMission;
use common\model\Es;
use umeworld\lib\Query;
use umeworld\lib\Debug;

/**
 * 关卡测试
 */
class MissionTest extends \Codeception\TestCase\Test{
	use \Codeception\Specify;

	public $testStudentId = 0;
	private $_userId = 0;
	private $_missionId = 4;
	private $_mStudent = null;
	private $_mMission = null;
	private $_isForbidden = 0;
	private $_aRandomUserMissionCache = [];	//随机抽取的模型都缓存在这里以免再次随机查询

	protected function _before(){
		//测试前可以向数据库初始化一些模拟数据
		$this->testStudentId = Yii::$app->test->commonStudent->id;
		$this->_userId = Yii::$app->test->commonStudent->id;
		$this->_mStudent = Yii::$app->test->commonStudent->getInstance();
		$this->_mMission = Mission::findOne($this->_missionId);
		$this->_isForbidden = $this->_mMission->is_forbidden;
    }

    protected function _after(){
		//测试后可以清除掉模拟数据
		if($this->_mMission instanceof \common\model\Mission){
			$this->_mMission->set('is_forbidden', $this->_isForbidden);
			$this->_mMission ->save();
		}
    }

	/**
	 * 测试获取所有年级年有科目以及某用户的关卡
	 */
	public function testGetMissionList(){
		$aGradeList = Grade::getGradeList();
		foreach($aGradeList as $gradeId => $gradeName){
			$mGrade = Grade::findOne($gradeId);
			$this->assertInstanceOf('common\model\Grade', $mGrade);

			$aSubjectList = $mGrade->getSubjectList(Subject::GAME_MISSION);
			foreach($aSubjectList as $subjectId => $subjectName){
				$this->assertTrue(is_string($subjectName));
				$aMissionList = Mission::getMissionList($subjectId, $gradeId, false, $this->_userId);
				$this->assertTrue(is_array($aMissionList));
			}
		}
	}

	/**
	 * 测试是否能判断一个关卡是否过关
	 * @author jay
	 */
	public function testIsPracticeFinish(){
		$mUserMission1 = $this->_getRandomUserMission(['is_task_finish' => 1]);
		$this->assertTrue($mUserMission1->isFinishPractice());

		$mUserMission2 = $this->_getRandomUserMission(['is_task_finish' => 0]);
		$this->assertFalse($mUserMission2->isFinishPractice());

		$mUserMission3 = $this->_getRandomUserMission(['is_pass' => 1]);
		$this->assertTrue($mUserMission3->isFinishPractice());
	}

	protected function _getRandomUserMission($xCondition){
		is_array($xCondition) && ksort($xCondition);
		$cacheKey = md5(serialize($xCondition));
		if(isset($this->_aRandomUserMissionCache[$cacheKey])){
			return $this->_aRandomUserMissionCache[$cacheKey];
		}
		$mMission = [];
		do{
			$oQuery = (new Query())
						->from(UserMission::tableName())
						->where($xCondition)
						->limit(1)
						->orderBy('rand()');
			$aMission = $oQuery->one();
			$mUserMission = UserMission::toModel($aMission);
			$mMission = Mission::findOne($mUserMission->mission_id);
		}while(!$mMission || $mMission->is_forbidden == 1);

		$this->assertInstanceOf('common\model\UserMission', $mUserMission);

		$this->_aRandomUserMissionCache[$cacheKey] = $mUserMission;

		return $mUserMission;
	}

	/**
	 * 测试开始挑战和读题
	 * @author jay
	 */
	/*public function testChallengeEs(){
		return;
		$mUserMission = UserMission::findOne([
			'user_id' => $this->testStudentId,
			'mission_id' => $this->_mMission->id,
		]);
		$this->assertInstanceOf('common\model\UserMission', $mUserMission);
		//初始化挑战
		$mUserMission->initMissionChallengeData();

		//取题
		$aEs = $mUserMission->getChallengeEs();
		$this->assertTrue(is_array($aEs));

		//做题
		$esId = \umeworld\lib\Xxtea::decrypt($aEs['id']);
		$this->assertTrue(is_numeric($esId));
		$mEs = Es::findOne($esId);
		$this->assertInstanceOf('common\model\Es', $mEs);
		$aUserAnswer = [
			'id' => $aEs['id'],
			'answer' => $mEs->getAnswer(),
		];
		$ts = \umeworld\lib\Xxtea::decrypt($aEs['ts']);
		$this->assertTrue(is_numeric($ts));


		//$mUserMission->answerChallenge($aUserAnswer, $ts);
	}*/

	/**
	 * 测试是否可以抽卡牌
	 * @author jay
	 */
	public function testIsCanDrawCards(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$mUserMission->set('draw_count', 0);
		$mUserMission->save();
		$aResult = $mUserMission->isCanDrawCards();
		//$this->assertEquals(true, $aResult);
	}

	/**
	 * 测试获取过关人数
	 * @author jay
	 */
	public function testGetPassMissionUserCount(){
		$aResult = \common\model\UserMission::getPassMissionUserCount($this->_missionId);
		$this->assertGreaterThanOrEqual(0, $aResult);
	}

	/**
	 * 测试用户关卡排名
	 * @author jay
	 */
	public function testGetUserMissionRanking(){
		$aResult = \common\model\UserMission::getUserMissionRanking($this->_missionId, 9000, []);
		$this->assertGreaterThanOrEqual(0, $aResult);
	}

	/**
	 * 测试获取关卡题目统计数据
	 * @author jay
	 */
	public function testGetUserMissionEsWrongStatistics(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$aResult = $mUserMission->getUserMissionEsWrongStatistics();
		$aStruct = [
			'all_count',
			'choose_count',
			'fill_count',
			'judge_count'
		];
		$this->tester->assertCompareArrayStruct($aResult, $aStruct);
	}

	/**
	 * 测试获取关卡最高分
	 * @author jay
	 */
	public function testGetMissionTopScore(){
		$aResult = $this->_mMission->getTopScore();
		$this->assertGreaterThanOrEqual(0, $aResult);
		$this->assertLessThan(10000, $aResult);
	}

	/**
	 * 测试获取关卡最高分用户信息
	 * @author jay
	 */
	public function testGetMissionTopScoreUserInfo(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$aResult = $mUserMission->getMissionTopScoreUserInfo();
		$this->tester->assertCompareArrayStruct($aResult, [
			'id',
			'name',
			'profile',
			'vip',
			'score'
		]);
	}

	/**
	 * 测试获取用户关卡在好友中的排名
	 * @author jay
	 */
	public function testGetUserMissionRankingInFriends(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$aResult = $mUserMission->getUserMissionRankingInFriends();
		$this->assertGreaterThanOrEqual(1, $aResult);
	}

	/**
	 * 测试获取用户在关卡战胜比率
	 * @author jay
	 */
	public function testGetUserMissionDefeatPercent(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$aResult = $mUserMission->getUserMissionDefeatPercent();
		$this->assertGreaterThanOrEqual(0, $aResult);
		$this->assertLessThan(100, $aResult);
	}

	/**
	 * 测试关卡挑战是否可取题
	 * @author jay
	 */
	public function testIsCanGetChallengeEs(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$mUserMission->initMissionChallengeData();
		$this->assertTrue($mUserMission->isCanGetChallengeEs());
	}

	/**
	 * 测试关卡挑战取题
	 * @author jay
	 */
	public function testGetChallengeEs(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$aResult = $mUserMission->getChallengeEs();
		$this->tester->assertCompareArrayStruct($aResult, [
			'id',
			'subject_id',
			'type_id',
			'correct_counts',
			'answer_counts',
			'correct_percent',
			'answer_time_total',
			'es_content',
			'hard_level',
			'ts'
		]);
	}

	/**
	 * 测试关卡修炼取题
	 * @author jay
	 */
	public function testGetPracticeEs(){
		$mUserMission = \common\model\UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$aResult = $mUserMission->generatePracticeEs();
		$this->tester->assertCompareArrayStruct($aResult, [
			'id',
			'subject_id',
			'type_id',
			'correct_counts',
			'answer_counts',
			'correct_percent',
			'answer_time_total',
			'es_content',
			'hard_level',
			'ts'
		]);
	}

	/**
	 * 测试关卡初始化数据
	 * @author jay
	 */
	public function testInitMissionChallengeData(){
		$mUserMission = UserMission::findOne([
			'user_id' => $this->_userId,
			'mission_id' => $this->_missionId
		]);
		$mUserMission->initMissionChallengeData();
		$aUserMission = $mUserMission->toArray();

		$this->assertEquals(3, $aUserMission['current_challenge_process']['life']);
		$this->assertEquals(900, $aUserMission['current_challenge_process']['time']);
		$this->assertEquals(10, sizeof($aUserMission['current_challenge_process']['es_list']));
		$this->assertEquals(0, $aUserMission['current_challenge_process']['rightEsCount']);

		$this->tester->assertCompareArrayStruct($aUserMission, ['current_challenge_process']);
		$this->tester->assertCompareArrayStruct($aUserMission['current_challenge_process'], [
			'life',
			'time',
			'es_list',
			'rightEsCount'
		]);
		foreach($aUserMission['current_challenge_process']['es_list'] as $value){
			$this->assertEquals(0, $value);
		}
	}

	/**
	 * depends testGetPracticeEs测试关卡修炼作答
	 * @author jay
	 */
	public function testAnswerPractice(){
		$mUserMission = Yii::$app->test->commonUserMission;
		if(!$mUserMission->last_es_id){
			return;
		}
		$aEs = $mUserMission->generatePracticeEs();
		$mEs = Es::findOne($mUserMission->last_es_id);
		$aResult = $mUserMission->answerPractice($mEs->getAnswer());
		$this->assertInternalType('bool', $aResult);
	}

	/**
	 * 测试初始化用户关卡
	 * @author jay
	 */
	public function testInitUserMission(){
		(new Query())->createCommand()->delete(UserMission::tableName(), ['user_id' => $this->_userId, 'mission_id' => $this->_missionId])->execute();
		$userId = $this->_userId;
		$missionId = $this->_missionId;
		$mUserMission = UserMission::initUserMission($userId, $missionId);
		$this->assertInstanceOf('common\model\UserMission', $mUserMission);
		$aUserMission = $mUserMission->toArray();
		$this->tester->assertCompareArrayStruct($aUserMission, [
			'user_id',
			'mission_id'
		]);
		$this->assertEquals($userId, $aUserMission['user_id']);
		$this->assertEquals($missionId, $aUserMission['mission_id']);
	}

	/**
	 * 测试关卡排行列表
	 * @author jay
	 */
	public function testGetMissionScoreRankingList(){
		$missionId = $this->_missionId;
		$page = 1;
		$pageSize = 10;
		$aPointUserIds = [];
		$aCondition = [];
		$aList = \common\model\UserMission::getMissionScoreRankingList($missionId, $page, $pageSize, $aPointUserIds, $aCondition);
		$this->assertInternalType('array', $aList);
		$this->assertEquals(10, sizeof($aList));

		foreach($aList as $key => $aValue){
			if(!$key){
				continue;
			}
			$this->assertGreaterThanOrEqual($aList[$key]['score'], $aList[$key - 1]['score']);
		}
	}

	/**
	 * @author zhou
	 * 测试Mission模型的getMissionChallengeEsCount,关卡挑战的题目数量
	 */
	public function testGetMissionChallengeEsCount(){
		$mMission = $this->_mMission;
		$this->assertInstanceOf('\common\model\Mission', $mMission, '返回值不是Mission类型,而是' . gettype($mMission));
		$result = $mMission->getMissionChallengeEsCount();
		$this->assertInternalType('integer', $result);
		$this->assertGreaterThan(0 , $result, '数量小于或等于0');
	}

	/**
	 * @author zhou
	 * 测试Mission模型的getMissionListByCondition，根据条件获取关卡列表
	 */
	public function testGetMissionListByCondition(){
		//正确测试，1个参数
		$aCondtion = [
			'subject_id'	=> 1,
	 		'grade'			=> 5,
	 		'id'			=> $this->_missionId,
		];
		$aMissionList = Mission::getMissionListByCondition($aCondtion);
		$this->assertEquals(1, count($aMissionList), '数组的长度是：'.count($aMissionList));
		$this->assertInternalType('array', $aMissionList, '返回的不是数组');
		$aStruct = [
			'id',
			'subject_id',
			'grade',
			'category_ids',
			'name',
			'task_content',
			'challenge_es_count',
			'challenge_limit_duration',
			'challenge_limit_blood',
			'challenge_count',
			'challenge_success_count',
			'orders',
			'recent_record',
			'is_forbidden'
		];

		foreach ($aMissionList as $key => $aMission){
			$this->tester->assertCompareArrayStruct($aMission, $aStruct);
		}
	}

	/**
	 * @author zhou
	 * 测试Mission模型的save方法
	 */
	public function testMissionSave(){
		$this->assertInstanceOf('\common\model\Mission', $this->_mMission);
		$this->_mMission->set('is_forbidden', 1);
		$result = $this->_mMission->save();
		$this->assertInternalType('integer', $result);
	}

	/**
	 * @author zhou
	 * 测试UserMission的save方法
	 */
	public function testUserMissionSave(){
		$mUserMission = UserMission::findOne([
			'user_id' => $this->testStudentId,
			'mission_id' => 1,
		]);

		$this->assertInstanceOf('common\model\UserMission', $mUserMission, '返回值不是UserMission类型,而是'.gettype($mUserMission));
		$mUserMission->set('next_draw_time', 1);
		$result = $mUserMission->save();
		$this->assertInternalType('integer', $result);
	}

	/**
	 * @author zhou
	 * 测试UserMission的findOne方法
	 */
	public function testUserMissionFindOne(){
		$mUserMission = UserMission::findOne([
			'user_id' => $this->testStudentId,
			'mission_id' => 1,
		]);
		$this->assertInstanceOf('common\model\UserMission', $mUserMission, '返回值不是UserMission类型,而是'.gettype($mUserMission));

		$mUserMission = UserMission::findOne([
			'user_id' => 0,
			'mission_id' => 0,
		]);
		$this->assertFalse($mUserMission, '返回值不是false，而是'.gettype($mUserMission));
	}

	/**
	 * @author zhou
	 * 测试UserMission的__get方法
	 */
	public function testUserMissionGet(){
		$aProperty = [
			'task_process',
			'current_challenge_process',
			'challenge_history',
			'break_record',
			'adaptive_learning_process',
			'task_es_history',
			'task_continuous_correct_count',
			'challenge_continuous_correct_count',
		];

		$mUserMission = UserMission::findOne([
			'user_id' => $this->testStudentId,
			'mission_id' => 1,
		]);

		$this->assertInstanceOf('common\model\UserMission', $mUserMission, '返回值不是UserMission类型,而是'.gettype($mUserMission));

		foreach ($aProperty as $property){
			$this->assertTrue(!is_null($mUserMission->$property), '最后一个是测试其它属性的');
		}
	}

	/**
	 * 测试是否能判断出AL训练结束
	 * @author jay
	 */
	public function testIsFinishAdaptiveLearning() {
		Debug::mark('a');
		$missionRelationId = (new Query())
					->select(['id'])
					->from(UserMission::dataTableName())
					->where(['and', ['<>', 'adaptive_learning_process', ''], ['<>', 'adaptive_learning_process', '[]']])
					->limit(1)
					->orderBy('rand()')
					->one();
		Debug::mark('b');
		debug(Debug::getUseMemory('a', 'b'));	//打印查询消耗时间,因为这张表是没有做索引的,为免张来变大导致异常的测试缓慢,加个输出信息以助提示

		$mUserMission = UserMission::findOne($missionRelationId);
		$alEsBatchCount = count($mUserMission->adaptive_learning_process);

		//!!!!!测试用例报这里没有下标0所以判断一下找找BUG是哪个数据
		if(!isset($mUserMission->adaptive_learning_process[$alEsBatchCount])){
			Yii::error((string)Yii::$app->buildError('该关卡的AL进度判断好像不太正常', false, $mUserMission->toArray()));
		}

		if($mUserMission->adaptive_learning_process[$alEsBatchCount]['is_finish']){
			$this->assertTrue($mUserMission->isFinishAdaptiveLearning());
		}else{
			$this->assertFalse($mUserMission->isFinishAdaptiveLearning());
		}
	}

	/**
	 * 测试一些其它值的获取
	 * @author jay
	 */
	public function testGetOtherValues() {
		$mUserMission = $this->_getRandomUserMission('1=1');
		//获取AL训练题数
		$this->assertGreaterThanOrEqual(0, $mUserMission->getAdaptiveLearningCorrectEsNums());

		//获取修炼进度百分数
		$this->assertGreaterThanOrEqual(0, $mUserMission->getPracticeProcess());

	}

	/**
	 * 测试获取下一关
	 * @author jay
	 */
	public function testGetNextMission(){
		$mMission = $this->_mMission;
		$this->assertInstanceOf('common\model\Mission', $mMission, 'Mission,而是' . gettype($mMission));
		$mNextMission = $mMission->getNextMission();
		if (!$mNextMission) {
			$this->assertFalse($mNextMission);
		} else {
			//通过query 获取下一关
			$aMission = (new Query())->from(Mission::tableName())->where(['>', 'orders', $mMission->orders])->one();
			if (!$aMission) {
				$this->assertFalse($aMission);
			}
			$this->assertInstanceOf('common\model\Mission', $mNextMission, 'Mission,而是' . gettype($mNextMission));
			$this->assertEquals($aMission['id'], $mNextMission->id);
		}
	}
}