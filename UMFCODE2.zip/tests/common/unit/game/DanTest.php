<?php
namespace tests\common\unit;

use umeworld\lib\Query;
use common\model\Student;
use common\model\Dan;

/**
 * 段位测试
 */
class DanTest extends \Codeception\TestCase\Test
{
	use \Codeception\Specify;

	/**
	 * 获取段位信息
	 * @param type $studentId
	 * @return type
	 */
	private function _getDanInfo($studentId){
		$mStudent = Student::findOne($studentId);
		if(!$mStudent){
			return $mStudent;
		}
		return $mStudent->getDanInfo();
	}

	/**
	 * 判断一个学生的段位名称是否准确
	 * @param type $studentId
	 * @param type $danName
	 */
	private function _testDanName($studentId, $danName){
		$mDan = $this->_getDanInfo($studentId);
		$this->assertEquals($danName, $mDan->name);
	}

	/**
	 * 测试不同段位的用户获取段位信息的情况
	 */
	public function testDiffStudentDanInfo(){
		$this->specify('没段位的用户是否读不出段位', function(){
			$mDan = $this->_getDanInfo(46405012);
			$this->assertFalse($mDan, '没段位的用户读取段位却不是false');
		});

		$this->specify('有段位的用户是否能读出段位模型', function(){
			$mDan = $this->_getDanInfo(52752125);
			$this->assertInstanceOf('common\model\Dan', $mDan);
		});

		/*
		$this->specify('各段位用户读出的段位信息是否准确', function(){
			$this->_testDanName(52752125, '钻石');
			$this->_testDanName(19110692, '白金');
			$this->_testDanName(37875936, '黄金');
			$this->_testDanName(16242509, '白银');
			$this->_testDanName(36953465, '青铜');
		});
		 */
	}

	/**
	 * 判断获取的段位列表是否正确
	 */
	public function testDanModelGetDanList(){
		$aMDanList = Dan::getDanList();
		//判断元素个数
		$this->assertEquals(5, count($aMDanList));
		//段位格式是否正确
		foreach($aMDanList as $mDan){
			$this->assertTrue(is_object($mDan));
			$this->assertArrayHasKey('id', $mDan);
			$this->assertArrayHasKey('name', $mDan);
			$this->assertArrayHasKey('image', $mDan);
			$this->assertArrayHasKey('min', $mDan);
			$this->assertArrayHasKey('max', $mDan);
			$this->assertArrayHasKey('next_dan_id', $mDan);
			$this->assertArrayHasKey('exchange_cards_rate', $mDan);
		}
	}

	/**
	 * 判断获取达到最低段位条件是否正确
	 */
	public function testDanModelGetConditions(){
		$aConditons = Dan::getConditions();
		$this->assertArrayHasKey('pass_misison_count', $aConditons);
	}

	/**
	 * 判断获取有段位最小闯关数是否正确
	 */
	public function testDanModelGetDanPassMissionCount(){
		$passMissionCount = Dan::getDanPassMissionCount();
		$this->assertEquals(20, $passMissionCount);
	}
}
