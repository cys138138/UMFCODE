<?php
namespace tests\common\user;

use Yii;
use common\model\StudentVip;

class StudentVipTest extends \Codeception\TestCase\Test{
	use \Codeception\Specify;
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;
	public $testStudentId = 0;

    protected function _before(){
		//测试前可以向数据库初始化一些模拟数据
		$this->testStudentId = Yii::$app->test->commonStudent->id;
    }

    protected function _after(){}

    /**
	 * 测试是否已经领过奖
	 * @author jay
	 */
    public function testIsRecivedPrize(){
		$mStudentVip = StudentVip::findOne($this->testStudentId);
		$this->assertInstanceOf('common\model\StudentVip', $mStudentVip);
		
		$receivePrizeStatus = $mStudentVip->isRecivedPrize();
		$this->assertTrue(is_bool($receivePrizeStatus));
    }

}