<?php
namespace tests\common\user;


class FeedbackTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    // tests
    public function testMe()
    {

    }

}