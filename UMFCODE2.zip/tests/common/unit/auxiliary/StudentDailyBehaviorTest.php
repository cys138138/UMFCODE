<?php
namespace tests\common\auxiliary;

use Yii;
use common\model\UserDailyBehavior;

/**
 * 学生每日任务测试用例
 */
class StudentDailyBehaviorTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;
	private $_aDailyBehaviorData = [];
	private $_mUserDailyBehaviorForTestInit = null;	//测试初始化的模型

	protected function _before()
    {
		$testMethod = $this->getName();
		if($testMethod == 'testInitAndRebuild'){
			//备份并删除原始任务数据
			$mTask = UserDailyBehavior::findOne(Yii::$app->test->commonStudent->id);
			if($mTask){
				$this->_aDailyBehaviorData = $mTask->toArray();
				$mTask->delete();
			}
		}
    }

    protected function _after()
    {
		$testMethod = $this->getName();
		if($testMethod == 'testInitAndRebuild'){
			//恢复原始任务状态
			if($this->_aDailyBehaviorData){
				if(!$this->_mUserDailyBehaviorForTestInit){
					//!!!!!有时候测试失败，部署一下追踪代码
					throw new \Exception('恢复数据失败' . PHP_EOL . var_export($this->_aDailyBehaviorData, true));
				}

				foreach($this->_aDailyBehaviorData as $key => $value){
					$this->_mUserDailyBehaviorForTestInit->set($key, $value);
				}
				$this->assertInternalType('boolean', $this->_mUserDailyBehaviorForTestInit->save(), '测试变更的每日任务数据恢复失败');

			}else{
				$this->assertTrue($this->_mUserDailyBehaviorForTestInit->delete(), '测试添加的每日任务数据删除失败');
			}
		}
    }

    /**
	 * 测试初始化和重新分配每日任务
	 * @author 黄文非
	 */
    public function testInitAndRebuild()
    {
		$this->_mUserDailyBehaviorForTestInit = UserDailyBehavior::initUserDailyBehavior(Yii::$app->test->commonStudent->id);
		$this->assertInstanceOf(UserDailyBehavior::className(), $this->_mUserDailyBehaviorForTestInit);
		$this->assertInternalType('bool', $this->_mUserDailyBehaviorForTestInit->rebuildDailyTask());
    }
}