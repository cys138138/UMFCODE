<?php

namespace tests\common\user;

use Yii;
use common\model\Mark;

/**
 * 签到测试
 */
class MarkTest extends \Codeception\TestCase\Test {

	protected $tester;
	private $testStudentId;
	private $_userId;
	private $_mStudent;

	protected function _before() {
		$this->testStudentId = Yii::$app->test->commonStudent->id;
		$this->_userId = Yii::$app->test->commonStudent->id;
		$this->_mStudent = Yii::$app->test->commonStudent->getInstance();
		Yii::$app->student->login($this->_mStudent);
	}

	protected function _after() {
		
	}

	//测试今天是否签到
	public function testIsMarked() {
		$isMark = Mark::isMarked($this->_userId);
		if (!$isMark) {
			$this->assertFalse($isMark);
		} else {
			$this->assertTrue($isMark);
		}
	}

	/**
	 * 测试签到操作
	 * @depends testIsMarkModel
	 */
	public function testMarked() {
		$mMark = Mark::findOne($this->_userId);

		$isMark = Mark::isMarked($this->_userId);
		$this->assertTrue(is_bool($isMark));
		//去签到
		if (!$isMark) {
			//断言false
			$this->assertTrue($mMark->mark($this->_userId));
			$this->assertFalse($mMark->mark($this->_userId));
			$mMark->set('last_mark_date', date('Ymd', strtotime('-1 day')));
			$mMark->save();
		} else {
			//已经签到则断言为false
			$this->assertFalse($mMark->mark($this->_userId));

			//已经签到则删除签到
			$mMark->set('last_mark_date', date('Ymd', strtotime('-1 day')));
			$mMark->save();

			//再次判断是否
			$this->assertTrue($mMark->mark($this->_userId));
		}

		$mMark->set('last_mark_date', date('Ymd', strtotime('-1 day')));
		$mMark->set('mark_continuous', 1);
		$mMark->save();

		$mMark = Mark::findOne($this->_userId);
		$beforeMarkDay = $mMark->mark_total;
		//测试连续签到 mark_continuous
		//设置连续签到为1因为上面已经设置上一次签到为昨天
		$this->assertTrue($mMark->mark($this->_userId));

		$mMark = Mark::findOne($this->_userId);
		$this->assertEquals($mMark->mark_continuous, 2);

		$this->assertEquals(($beforeMarkDay + 1), $mMark->mark_total, '连续签到总数加一');
	}

	/**
	 * 测试我的好友签到排行
	 * @depends testIsMarkModel
	 */
	public function testGetFriendMarkRankingList() {
		$mMark = Mark::findOne($this->_userId);

		$aFriendMarkRankingList = $mMark->getFriendMarkRankingList($this->_userId, 1, 10, 0);
		$aStruct = [
			'number' => 'id',
			'number' => 'mark_total',
			'number' => 'mark_continuous',
			'number' => 'last_mark_date',
			'array' => 'user_info',
			'number' => 'rankNumber',
		];
		$this->assertInternalType('array', $aFriendMarkRankingList);
		foreach ($aFriendMarkRankingList as $k => $aFriendMarkRanking) {
			$this->tester->assertCompareArrayStruct($aFriendMarkRanking, $aStruct);
			//
			$aMarkInfo = $mMark->getMarkInfo($this->_userId);
			//确认我的排名是否等于通过getMarkInfo 获取到的是一样的位置
			if ($this->_userId == $aFriendMarkRanking['id']) {
				$this->assertEquals($aMarkInfo['friend_mark_rank'], $aFriendMarkRanking['rankNumber']);
			}
			if (isset($aFriendMarkRankingList[$k - 1])) {
				$this->assertGreaterThan($aFriendMarkRankingList[$k]['mark_total'], $aFriendMarkRankingList[$k - 1]['mark_total']);
			}
		}
	}

	/**
	 * 测试签到排行
	 * @depends testIsMarkModel
	 */
	public function testGetMarkRankingList() {
		$mMark = Mark::findOne($this->_userId);

		$aMarkRankingList = $mMark->getMarkRankingList(1, 10, 'mark_total');
		$this->assertInternalType('array', $aMarkRankingList);
		$aStruct = [
			'number' => 'id',
			'number' => 'mark_total',
			'number' => 'mark_continuous',
			'number' => 'last_mark_date',
			'array' => 'user_info',
			'number' => 'rankNumber',
		];
		foreach ($aMarkRankingList as $k => $aMarkRanking) {
			$this->tester->assertCompareArrayStruct($aMarkRanking, $aStruct);
			if (isset($aMarkRankingList[$k - 1])) {
				$this->assertGreaterThan($aMarkRankingList[$k - 1]['mark_total'], $aMarkRankingList[$k]['mark_total']);
			}
		}
	}

	/**
	 * 测试模型是否是mark模型
	 */
	public function testIsMarkModel() {
		$mMark = Mark::findOne($this->_userId);
		$this->assertInstanceOf('common\model\Mark', $mMark);
	}

	/**
	 * 测试返回的签到信息
	 * @depends testIsMarkModel
	 */
	public function testGetMarkInfo() {
		$mMark = Mark::findOne($this->_userId);
		//获取签到信息
		$aMarkInfo = $mMark->getMarkInfo($this->_userId);
		$this->assertInternalType('array', $aMarkInfo);
		$aStruct = [
			'is_marked',
			'week_str',
			'today_date',
			'mark_total_day',
			'continue_mark_day',
			'today_gold',
			'friend_mark_rank',
		];
		$this->tester->assertCompareArrayStruct($aMarkInfo, $aStruct);
	}

}
