<?php
namespace tests\common\auxiliary;

use Yii;
use common\lib\BbsManageListenerManager;
use manage\model\Manager;

/**
 * BBS管理者审核监听管理器测试
 */
class BbsManageListenerManagerTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;

	/**
	 * 测试创建新的会话ID
	 * @author 黄文非
	 */
    public function testGetListenerListCount()
    {
		$mManager = new BbsManageListenerManager();
		$mManager->clearListener();
		$this->assertEquals(0, $mManager->getListenerListCount(), '监听者数量不是0');
		$mManagerUser = Manager::findOne(1);
		$newSessionId = $mManager->addListener($mManagerUser);
		$this->assertInternalType('string', $newSessionId, '添加监听者后返回值不是字符串');
		$this->assertEquals($newSessionId, $mManager->addListener($mManagerUser), '重复添加监听者后ID居然不一样');
		$this->assertEquals(1, $mManager->getListenerListCount(), '添加监听者后获取的监听者数量不是1');
    }

	/**
	 * 测试创建新的会话ID
	 * @author 黄文非
	 * @depends testGetListenerListCount
	 */
    public function testBuildNewSessionId()
    {
		$mManager = new BbsManageListenerManager();
		$mManager->clearListener();
		$id = $mManager->buildNewSessionId();
		$this->assertInternalType('string', $id, '创建的会话ID不是字符串');
		$this->assertEquals('session_1', $id, '创建的会话ID不对');
    }

}