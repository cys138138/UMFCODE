<?php
namespace tests\common\auxiliary;

use common\model\Event as Event;
use umeworld\lib\Query;

class EventTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;
	private $_mEvent = null;
	private $_insertID = null;
	protected function _before()
    {
		//判断模型的实例类型
		$this->_mEvent = Event::findOne([]);
		$this->assertInstanceOf('common\model\Event', $this->_mEvent);
    }

    protected function _after()
    {
		if(! is_null($this->_insertID)){
			//删除sns_event表的增加数据
			$this->_mEvent->id = $this->_insertID;
			$this->_mEvent->delete();
			//删除sns_event_data表的增加数据
			(new Query())->createCommand()->delete('sns_event_data', ['id' => $this->_insertID])->execute();
		}
    }
	
	/**
	 * 测试插入一条动态
	 * @author zhou
	 */
	public function testAdd(){
		//插入, 当插入 data_id 的时候，数据逻辑上就不匹配了,建议如果牵涉到关联表的，最好做下接收参数的处理
		$aRecord = [
			'user_id' => 12345678,
			'type' => 100,
		];
		//判断返回值
		$this->_insertID = (integer)$this->_mEvent->add($aRecord);
		$this->assertInternalType('integer', $this->_insertID);
		//查看数据库变化
		$this->tester->canSeeInDatabase(Event::tableName(), [
			'id' => $this->_insertID,
			'user_id' => 12345678,
			'type' => 100,
		]);
	}
	
	/**
	 * 测试解析事件类型
	 * @author zhou
	 */
	public function testParseEventType(){
		$typeStr = 'gold';
		$this->assertEmpty(array_diff([
				Event::MARK,
				Event::EXCHANGE_CARD,
				Event::WIN_MATCH_WITH_GOLD,
				Event::WIN_PK_WITH_GOLD,
				Event::OPEN_VIP_PACKAGE,
				Event::BIND_EMAIL,
				Event::BUY_PROP,
				Event::EXCHANGE_GOODS,
				Event::FINISH_DAILY_TASK,
				Event::RECOMMEND_THREAD,
			], $this->_mEvent->parseEventType($typeStr))
		);
		
		$typeStr = 'mission';
		$this->assertEmpty(array_diff([
				Event::PASS_MISSION,
				Event::EXCHANGE_CARD,
			], $this->_mEvent->parseEventType($typeStr))
		);
		
		$typeStr = 'match';
		$this->assertEmpty(array_diff([
				Event::FINISH_MATCH,
				Event::WIN_MATCH_WITH_GOLD,
				Event::WIN_MATCH_WITHOUT_GOLD,
			], $this->_mEvent->parseEventType($typeStr))
		);
		
		$typeStr = 'activity';
		$this->assertEmpty(array_diff([-1], $this->_mEvent->parseEventType($typeStr))
		);
		
		$typeStr = 'other';
		$this->assertEmpty(array_diff([
				Event::BIND_EMAIL,
				Event::PUBLISH_THREAD,
				Event::BECOME_VIP,
				Event::BECOME_FRIEND,
			], $this->_mEvent->parseEventType($typeStr))
		);
		
		$typeStr = 'all';
		$this->assertEmpty(array_diff([
				Event::MARK,
				Event::PASS_MISSION,
				Event::EXCHANGE_CARD,
				Event::FINISH_MATCH,
				Event::WIN_MATCH_WITH_GOLD,
				Event::WIN_MATCH_WITHOUT_GOLD,
				Event::WIN_PK_WITH_GOLD,
				Event::WIN_PK_WITHOUT_GOLD,
				Event::OPEN_VIP_PACKAGE,
				Event::BIND_EMAIL,
				Event::BUY_PROP,
				Event::EXCHANGE_GOODS,
				Event::FINISH_DAILY_TASK,
				Event::PUBLISH_THREAD,
				Event::RECOMMEND_THREAD,
				Event::BECOME_VIP,
				Event::BECOME_FRIEND,
			], $this->_mEvent->parseEventType($typeStr))
		);
		
	}
	
	/**
	 * 测试按条件计算事件列表个数
	 * @author zhou
	 */
	public function testGetEventListCount(){
		$aCondition = [
			'id' => 1,
			'type' => 1,
			'user_id' => 24793563,
		];
		$result = $this->_mEvent->getEventListCount($aCondition);
		$this->assertTrue(is_numeric($result));
		
		$aCondition = [];
		$result = $this->_mEvent->getEventListCount($aCondition);
		$this->assertTrue(is_numeric($result));
		$this->assertGreaterThanOrEqual(1, (int)$result);		
	}
	
	/**
	 * 测试 getEventList (获取活动列表)
	 * @author zhou
	 */
	public function testGetEventList(){
		$aCondition = [
			'id' => 1,
		];
		$page = 1;
		$pageSize = 10;
		$aDataList = $this->_mEvent->getEventList($aCondition, $page, $pageSize);
		$sDataList = serialize($aDataList);
		$this->assertInternalType('array', $aDataList, $sDataList);
		$this->assertLessThanOrEqual($pageSize, count($aDataList));
		foreach ($aDataList as $aEventData){
			$this->tester->assertCompareArrayStruct($aEventData, [
				'id',
				'user_id',
				'type',
				'data_id',
				'data',
				'user_info' => [
					'id',
					'name',
					'profile',
					'vip'
				]
			]);
		}		
	}
	

}