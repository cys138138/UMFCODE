<?php
namespace tests\common\auxiliary;


class ExchangeTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\common\UnitTester
     */
    protected $tester;
	private $_mExchange = null;
	private $_page = 1;
	private $_pageSize = 10;
    protected function _before()
    {
		$this->_mExchange = \common\model\Exchange::findOne(['id' => 19]);
		$this->assertInstanceOf('\common\model\Exchange', $this->_mExchange);
    }

    protected function _after()
    {
    }
	
	/**
	 * 测试兑换商城物品列表
	 * @author zhou
	 * getExchangeGoodsList($aCondition, $page, $pageSize, $aOrder = ['recommand_time' => SORT_DESC])
	 */
	public function testGetExchangeGoodsList(){	
		$aCondition = [
			'release' => 1,
		];
		$aDataList = $this->_mExchange->getExchangeGoodsList($aCondition, $this->_page, $this->_pageSize);
		$this->assertLessThanOrEqual($this->_pageSize, count($aDataList));
		$this->assertInternalType('array', $aDataList);
		$aCondition = [
			'select' => ['level'=>1],
		];
		$this->assertInternalType('array', $aDataList);
		$aCondition = [
			'is_recommand' => 1,
		];		
		$this->assertInternalType('array', $aDataList);
		$aOrder = [
			'recommand_time' => SORT_ASC,
			'recommand_time' => SORT_DESC,
		];		
		$this->assertInternalType('array', $aDataList);
		$aCondition = [
			'is_recommand' => 1,
			'release' => 1,
			'select' => ['level'=>1],
			'is_recommand' => 1,
		];		
		$this->assertInternalType('array', $aDataList);
		//3.返回值测试
		if(! empty($aDataList)){
			foreach ($aDataList as $aExchange){
				$this->tester->assertCompareArrayStruct($aExchange, [
					'id',
					'profile',
					'name',
					'summary',
					'level',
					'gold',
					'original_gold',
					'stock',
					'support',
					'sales_volume',
					'description',
					'create_time',
					'recommand_time',
					'recommand_image',
					'orders',
					'release',
					'rush_time',
					'quick_spot',
				]);
			}
		}		
	}
	
}