<?php
namespace tests\common\auxiliary;

use Yii;
use common\model\Teacher;
use common\model\TeacherExchangeGoods;

class TeacherExchangeTest extends \Codeception\TestCase\Test {

}
