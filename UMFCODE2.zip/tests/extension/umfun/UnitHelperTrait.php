<?php
namespace umtest;

use Codeception\TestCase\Test;

/**
 * 各模块的单元测试助手共享代码块
 */
trait UnitHelperTrait{
	/**
	 * @var Codeception\TestCase\Test phpunit测试器
	 */
	public $oPhpUnit;

	public function _before(Test $oTester){
		//初始化phpunit测试器
		$this->oPhpUnit = $oTester;
	}

	/**
	 * 断言一个数组 $aArray 的结构体是至少包含了 $aStruct 所描述的层次key的
	 *
	 * 例如:
	 *
	 * ~~~
	 * //被检查的数据
	 * $aData = [
	 *		'id' => 123,
	 *		'name' => '小明',
	 *		'xxt_data' => [
	 *			'CityId' => 1,
	 *			'SchoolId' => 1,
	 *		],
	 * ];
	 *
	 * //要检查的结构
	 * $aStruct = [
	 *		'id',
	 *		'name',
	 *		'xxt_data' => [
	 *			'CityId'
	 *		],
	 * ];
	 * $this->tester->assertCompareArrayStruct($aData, $aStruct);	//通过
	 *
	 * ~~~
	 * @param array $aArray 要测试的数组
	 * @param array $aStruct 要对比的结构
	 */
	public function assertCompareArrayStruct($aArray, $aStruct){
		$this->_judgeArrayHasSameKeyAndValue($aArray, $aStruct);
	}

	private function _judgeArrayHasSameKeyAndValue($aSource, $aTarget){
		$this->oPhpUnit->assertInternalType('array', $aSource);
		$this->oPhpUnit->assertInternalType('array', $aTarget);

		foreach($aTarget as $key => $value){
			if($key === 'number'){
				//$this->oPhpUnit->assertInternalType('int', $aSource[$value]);
				$this->oPhpUnit->assertTrue(is_numeric($aSource[$value]));
				continue;
			}

			if($key === 'string'){
				$this->oPhpUnit->assertInternalType('string', $aSource[$value]);
				continue;
			}

			if($key === 'array'){
				$this->oPhpUnit->assertInternalType('array', $aSource[$value]);
				continue;
			}

			if($key === 'scalar'){
				$this->oPhpUnit->assertTrue(is_scalar($aSource[$value]));
				continue;
			}

			if($key === 'object'){
				$this->oPhpUnit->assertInternalType('object', $aSource[$value]);
				continue;
			}

			if(is_array($value) || !is_int($key)){
				$this->oPhpUnit->assertArrayHasKey($key, $aSource);
			}else{
				$this->oPhpUnit->assertArrayHasKey($value, $aSource);
				continue;
			}

			if(is_array($value)){
				$this->_judgeArrayHasSameKeyAndValue($aSource[$key], $aTarget[$key]);
			}
		}
	}
}