<?php
Yii::setAlias('umtest', __DIR__);

if(!function_exists('debug')){
	function debug($xData, $isStop = false){
		codecept_debug('===============');
		codecept_debug($xData);
		codecept_debug('===============');
		if($isStop){
			exit;
		}
	}
}