<?php
namespace umtest;

use Yii;

/**
 * 各模块的页面测试共享代码块
 */
trait AcceptanceHelperTrait{
	/**
	 * 获取上次请求的响应内容
	 * @param type $asJson
	 * @return type
	 */
	private function _getResponseContent($asJson = false){
		$oBrowser = $this->getModule('PhpBrowser');
		$content = (string)$oBrowser->client->getInternalResponse()->getContent();
		if($asJson){
			$content = json_decode($content, true);
		}
		return $content;
	}

	/**
	 * 获取页面的csrf令牌
	 * @param type $oTester
	 * @return type
	 */
	public function grabCsrfToken(){
		return $this->_getCsrfToken();
	}

	/**
	 * 断言响应内容是否为JSON格式
	 */
	public function seeRsponseIsJson(){
		$xResponseContent = $this->_getResponseContent();
		if(!$xResponseContent){
			$this->assertEquals('断言请求结果应该是JSON', '其实是空字符串', '预期的JSON为空');
		}
		json_decode($xResponseContent, true);
		$this->assertEquals(0, json_last_error(), '返回结果不是JSON');
	}

	/**
	 * 断言JSON结果
	 * @param function $function 断言回调,接收JSON解出来的数组进行判断
	 */
	public function seeInJsonResult($function){
		$this->seeRsponseIsJson();
		$function($this->_getResponseContent(true));
	}

	/**
	 * 通过账号密码登陆
	 * @param string $account
	 * @param string $password
	 */
	public function amLoginStudentByAccount($account, $password){
		$oBrowser = $this->getModule('PhpBrowser');
		$oBrowser->sendAjaxPostRequest(Yii::$app->urlManagerLogin->createUrl(['login/login']), [
			'email' => $account,
			'password' => $password,
			'_csrf' => $this->_getCsrfToken(),
		]);
	}

	public function amLoginTeacherById($id){
		$oBrowser = $this->getModule('WebDriver');
		$oAssert = $this->getModule('Asserts');
		$oBrowser->amOnPage('http://dev.umfun.test');
		$aResult = $oBrowser->executeJs(
<<<JS
			var aReturn = {};
			$.ajax({
				url : 'http://dev.umfun.test/?r=codeception/login-teacher&id=$id',
				async : false,
				dataType : 'json',
				success : function(aResult){
					aReturn = aResult;
				}
			});
			return aReturn;
JS
		);

		$oAssert->assertEquals(1, $aResult['status']);
	}
	/**
	 * 通过账号登入
	 * @param  int $id 学生id
	 */
	public function amLoginStudentById($id){
		$oBrowser = $this->getModule('WebDriver');
		$oAssert = $this->getModule('Asserts');
		$oBrowser->amOnPage('http://dev.umfun.test');
		$aResult = $oBrowser->executeJs(
<<<JS
			var aReturn = {};
			$.ajax({
				url : 'http://dev.umfun.test/?r=codeception/login-student&id=$id',
				async : false,
				dataType : 'json',
				success : function(aResult){
					aReturn = aResult;
				}
			});
			return aReturn;
JS
		);
		$oAssert->assertEquals(1, $aResult['status']);

	}

	/**
	 * 断言登陆是否成功
	 */
	public function assertLoginSuccess(){
		$oBrowser = $this->getModule('PhpBrowser');
		$oBrowser->seeResponseCodeIs(200);
		$this->seeRsponseIsJson();
		$this->seeInJsonResult(function($aResult){
			$this->assertEquals(1, $aResult['status']);
		});
	}

	/**
	 * 获取页面的csrf口令
	 * @return string
	 */
	private function _getCsrfToken(){
		$oBrowser = $this->getModule('PhpBrowser');
		return $oBrowser->grabAttributeFrom('meta[name="csrf-token"]', 'content');
	}
}