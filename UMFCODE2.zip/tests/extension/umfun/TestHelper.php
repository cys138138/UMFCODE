<?php
namespace umtest;

use common\model\UserMission;
use Yii;
use yii\base\Component;
use umeworld\lib\Query;
use common\model\ParentUser;
use common\model\Student;
use common\model\Teacher;
use common\model\Es;
use PHPUnit_Framework_Assert;

/**
 * 测试助手,用于配合测试框架代码封装一些常用的东西
 * @author 黄文非
 * @property \umtest\CommonStudent $commonStudent 公共的测试学生对象
 * @property \common\model\UserMission $commonStudent 公共的测试学生对象
 */
class TestHelper extends Component{
	/**
	 * 测试助手的其它参数
	 * @var array
	 */
	public $aParams = [];

	/**
	 * @var CommonStudent 公共测试学生
	 */
	public $oCommonStudent;

	/**
	 * @var CommonTeacher 公共测试教师
	 */
	public $oCommonTeacher;

	/**
	 * @var int 公共测试关卡ID
	 */
	protected $_commonMissionId;

	/**
	 * 设置公共的测试学生
	 */
	public function setCommonStudent($oCommonStudent){
		$this->oCommonStudent = Yii::createObject($oCommonStudent);
	}

	/**
	 * 设置公共的测试学生
	 */
	public function setCommonTeacher($oCommonTeacher){
		$this->oCommonTeacher = Yii::createObject($oCommonTeacher);
	}

	/**
	 * 获取公共的测试学生
	 * @return CommonStudent
	 */
	public function getCommonStudent(){
		return $this->oCommonStudent;
	}

	/**
	 * 获取公共的测试学生
	 * @return CommonStudent
	 */
	public function getCommonTeacher(){
		return $this->oCommonTeacher;
	}

	/**
	 * 设置公共的测试关卡ID
	 */
	public function setCommonMissionRelationId($commonMissionId){
		$this->_commonMissionId = $commonMissionId;
	}

	/**
	 * 获取公共的测试关卡
	 * @return UserMission
	 */
	public function getCommonUserMission(){
		return UserMission::findOne($this->_commonMissionId);
	}

	/**
	 * 随机获取一个学生
	 * @return \common\model\Student
	 */
	public function getRandomStudent(){
		$aStudent = (new Query())->from(ParentUser::tableName())->limit(1)->orderBy('rand()')->one();
		PHPUnit_Framework_Assert::assertInternalType('array', $aStudent);
		$mStudent = Student::toModel($aStudent);
		PHPUnit_Framework_Assert::assertInstanceOf('common\model\Student', $mStudent);
		return $mStudent;
	}

	/**
	 * 随机获取一个家长
	 * @return \common\model\ParentUser
	 */
	public function getRandomParent(){
		//$aParent = (new Query())->from(ParentUser::tableName())->limit(1)->orderBy('rand()')->one();
		$count = (new Query())->from(ParentUser::tableName())->count();
		$offset = mt_rand(1, $count - 1);
		$aParent = (new Query())->from(ParentUser::tableName())->offset($offset)->limit(1)->one();
		PHPUnit_Framework_Assert::assertInternalType('array', $aParent);
		$mParent = ParentUser::toModel($aParent);
		PHPUnit_Framework_Assert::assertInstanceOf('common\model\ParentUser', $mParent);
		return $mParent;
	}

	/**
	 * 随机获取一个老师
	 * @return \common\model\Teacher
	 */
	public function getRandomTeacher(){
		$aTeacher = (new Query())->from(Teacher::tableName())->limit(1)->orderBy('rand()')->one();
		PHPUnit_Framework_Assert::assertInternalType('array', $aTeacher);
		$mTeacher= Teacher::toModel($aTeacher);
		PHPUnit_Framework_Assert::assertInstanceOf('common\model\Teacher', $mTeacher);
		return $mTeacher;
	}

	/**
	 * 随机获取一条题目
	 * @return \common\model\Es
	 */
	public function getRandomEs(){
		$aEs = (new Query())->from(Es::tableName())->where([
			'status' => 5
		])->limit(1)->orderBy('rand()')->one();
		PHPUnit_Framework_Assert::assertInternalType('array', $aEs);
		$mEs = Es::toModel($aEs);
		PHPUnit_Framework_Assert::assertInstanceOf('common\model\Es', $mEs);
		return $mEs;
	}
}