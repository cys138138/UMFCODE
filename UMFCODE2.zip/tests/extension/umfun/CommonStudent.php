<?php
namespace umtest;

use common\model\Student;
use yii\base\Object;

class CommonStudent extends Object{
	public $id;
	public $password;
	public $email;
	public $tel;
	public $xxtId;
	public $xxtPlatform;

	private $_mStudent = null;

	public function setId($id){
		$this->id = $id;
	}

	public function setEmail($email){
		$this->email = $email;
	}

	public function setTel($tel){
		$this->tel = $tel;
	}

	public function setXxtId($xxtId){
		$this->xxtId = $xxtId;
	}

	public function setXxtPlatform($xxtPlatform){
		$this->xxtPlatform = $xxtPlatform;
	}

	/**
	 * 获取公共测试学生的模型实例
	 * @return \common\model\Student
	 */
	public function getInstance(){
		if($this->_mStudent){
			return $this->_mStudent;
		}

		$this->_mStudent = Student::findOne($this->id);
		return $this->_mStudent;
	}
}