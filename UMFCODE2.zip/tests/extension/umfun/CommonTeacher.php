<?php
namespace umtest;

use common\model\Teacher;
use yii\base\Object;

/**
 * 公共测试教师
 */
class CommonTeacher extends Object{
	public $id;
	public $xxtId;
	public $xxtPlatform;

	private $_mTeacher = null;

	public function setId($id){
		$this->id = $id;
	}

	public function setXxtId($xxtId){
		$this->xxtId = $xxtId;
	}

	public function setXxtPlatform($xxtPlatform){
		$this->xxtPlatform = $xxtPlatform;
	}

	/**
	 * 获取公共测试学生的模型实例
	 * @return \common\model\Teacher
	 */
	public function getInstance(){
		if($this->_mTeacher){
			return $this->_mTeacher;
		}

		$this->_mTeacher = Teacher::findOne($this->id);
		return $this->_mTeacher;
	}
}