<?php
namespace tests\manage;

/**
 * 样式模型单元测试
 * @author zhou
 */
use Yii;
use umeworld\lib\Query;
use yii\helpers\ArrayHelper;
use common\model\Vip;
use yii\db\Command;
use manage\model\Style;

class StyleTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\manage\UnitTester
     */
    protected $tester;
	
	protected function _before()
    {

    }

    protected function _after()
    {
		
    }

    /**
	 * 测试据条件获取风格列表总数
	 * @author zhou
	 */
    public function testGetStyleCount(){
		//条件为空
		$aCondition = [];
		$styleCount = Style::getStyleCount($aCondition);
		$this->assertTrue(is_scalar($styleCount));
		$this->assertGreaterThan(0, (int)$styleCount);
		$count = (new Query())->from(Style::tableName())->where(1)->count();
		$this->assertEquals($count, $styleCount);
		
		//只有一个条件 id
		$id = (new Query())->from(Style::tableName())->scalar();
		$aCondition = ['id' => $id];
		$styleCount = Style::getStyleCount($aCondition);
		$this->assertTrue(is_scalar($styleCount));
		$this->assertEquals(1, (int)$styleCount);
		$count = (new Query())->from(Style::tableName())->where(['id' => $id])->count();
		$this->assertEquals($count, $styleCount);
		
		//有多个条件
		$aCondition = [
			'is_default' => 0,
			'level_limit' => 0
		];
		$styleCount = Style::getStyleCount($aCondition);
		$this->assertTrue(is_scalar($styleCount));
		$this->assertGreaterThan(0, (int)$styleCount);
		$count = (new Query())->from(Style::tableName())->where($aCondition)->count();
		$this->assertEquals($count, $styleCount);
    }
	
	/**
	 * 测试插入风格
	 */
	public function testAddStyle(){
		//无条件返回false
		$mStyle = Style::addStyle();
		$this->assertInternalType('boolean', $mStyle);
		$this->assertEquals(false, $mStyle);
		//插入已有id的数据,报错
		//插入其它数据
		$aCondition = [
			'name' => 'for test'
		];		
		$mStyle = Style::addStyle($aCondition);
		$this->assertInstanceOf('manage\model\Style', $mStyle);
		
		//删除添加的数据
		$id = $mStyle->id;
		Yii::$app->db->createCommand()->delete('style', ['id' => $id])->execute();
	}
	
	/**
	 * 测试删除风格
	 * @depends testAddStyle
	 */
	public function testDeleteStyle(){
		$aCondition = [
			'name' => 'for test'
		];
		$mStyle = Style::addStyle($aCondition);
		$id = $mStyle->id;
		$result = Style::deleteStyle(['id' => $id]);
		$this->assertEquals(1, (int)$result);
	}
	
	/**
	 * 测试获取样式列表
	 */
	public function testGetStyleList(){
		//没有条件时候
		$aCondition = [];
		$aControl = [];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertInternalType('array', $aStyleList);
		$count = (new Query())->from(Style::tableName())->where(1)->count();
		$this->assertEquals($count, count($aStyleList));
		foreach ($aStyleList as $aStyle){
			$this->tester->assertCompareArrayStruct($aStyle, [
				'id',
				'name',
				'pack_name',
				'status',
				'is_default',
				'level_limit',
				'vip_limit',
				'gold_coin',
				'used_count',
				'create_time',
				'orders',
				'category_id'
			]);
		}
		//没有筛选条件，有分页条件的时候
		$aControl = [
			'page' => 1
		];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertInternalType('array', $aStyleList);
		$count = (new Query())->from(Style::tableName())->where(1)->count();
		$this->assertEquals($count, count($aStyleList));
		foreach ($aStyleList as $aStyle){
			$this->tester->assertCompareArrayStruct($aStyle, [
				'id',
				'name',
				'pack_name',
				'status',
				'is_default',
				'level_limit',
				'vip_limit',
				'gold_coin',
				'used_count',
				'create_time',
				'orders',
				'category_id'
			]);
		}
		//没有筛选条件，有分页条件的时候2
		$aControl = [
			'page' => 1,
			'page_size' => 1
		];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertInternalType('array', $aStyleList);
		$this->assertEquals(1, count($aStyleList));
		foreach ($aStyleList as $aStyle){
			$this->tester->assertCompareArrayStruct($aStyle, [
				'id',
				'name',
				'pack_name',
				'status',
				'is_default',
				'level_limit',
				'vip_limit',
				'gold_coin',
				'used_count',
				'create_time',
				'orders',
				'category_id'
			]);
		}
		//没有筛选条件，只选择部分字段
		$aControl = [
			'select' => [
				'id', 
				'name'
			],
		];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertInternalType('array', $aStyleList);
		foreach ($aStyleList as $aStyle){
			$this->assertEquals(2, count($aStyle));
			$this->tester->assertCompareArrayStruct($aStyle, [
				'id',
				'name',
			]);
		}
		//有筛选条件
		$id = (new Query())->from(Style::tableName())->scalar();
		$aCondition = [
			'id' => $id
		];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertInternalType('array', $aStyleList);
		$this->assertEquals(1, count($aStyleList));
		//查看排序
		$aCondition = [];
		$aControl = [
			'order' => [
				'id' => SORT_ASC //顺序
			],
		];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertEquals($id, $aStyleList[0]['id']);
		
		$id = (new Query())->from(Style::tableName())->orderBy(['id' => SORT_DESC])->scalar();
		$aControl = [
			'order' => [
				'id' => SORT_DESC //顺序
			],
		];
		$aStyleList = Style::getStyleList($aCondition, $aControl);
		$this->assertEquals($id, $aStyleList[0]['id']);
	}

	/**
	 * 测试设置默认风格
	 * @depends testGetStyleList
	 */
	public function testSetDefaultStyle(){
		//获取默认皮肤
		$mStyleDefault = Style::findOne(['is_default' => 1]);
		$this->assertEquals(1, (int)$mStyleDefault->is_default);
		//修改默认皮肤
		$mStyleNotDefault = Style::findOne(['is_default' => 0]);
		$id = $mStyleNotDefault->id;
		$this->assertEquals(0, (int)$mStyleNotDefault->is_default);
		$mStyleNotDefault->set('is_default', 1);
		$mStyleNotDefault->save();
		//设置默认皮肤
		Style::setDefaultStyle($mStyleNotDefault);
		//查看是否修改成功
		$mStyle = Style::findOne(['is_default' => 1]);
		$this->assertEquals($id, $mStyle->id);
		//还原默认皮肤
		$mStyleDefault->set('is_default', 1);
		$mStyleDefault->save();
		Style::setDefaultStyle($mStyleDefault);
	}
}