<?php
namespace tests\manage\unit\game;

use manage\model\Match;

class MatchTest extends \Codeception\TestCase\Test
{
    public static function buildBigMatch(){
		$aMatch = [
			'name'				=> '自动测试大赛',
			'profile'			=>	'',
			'big_match_profile'	=>	'',
			'description'		=>	'大赛描述',
			'rule'				=>	'比赛规则介绍',
			'match_start_time'	=>	NOW_TIME,
			'match_end_time'	=>	NOW_TIME + 86400,
			'duration'			=>	5,
			'join_fee'			=>	0,
			'rejoin_fee'		=>	5,
			'limit_level'		=>	0,
			'limit_xxt_type'	=>	[0, \common\xxt\gd\InterfaceGd::PLATFORM_TYPE, \common\xxt\sx\InterfaceSx::PLATFORM_TYPE],
			'is_team_match'		=>	0,
			'is_big_match'		=>	1,
			'limit_grades'		=>	[],
			'is_finish_can_draw'=>	1,
			'grade_id'			=>	5,
			'subject_id'		=>	1,
			'es_category_rule'	=>	[
				1	=>	1460,
				2	=>	1599,
				3	=>	1706,
				4	=>	1808,
				5	=>	197,
				6	=>	67,
				7	=>	569,
				8	=>	642,
				9	=>	681,
			],
			'view_css'			=>	'',
			'es_rule'			=>	[
				[
					'es_type_id'	=>	1,
					'es_count'		=>	10,
				]
			],
			'awards'			=>	[
				'top'	=>	[
					1	=>	[
						'gold'	=>	10,
						'prize'	=>	'好东西'
					],
					2	=>	[
						'gold'	=>	5,
						'prize'	=>	'好东西'
					],
					3	=>	[
						'gold'	=>	2,
						'prize'	=>	'好东西'
					],
				],
				'rand'	=>	[
					'number'	=>	3,
					'gold'		=>	3,
					'prize'	=>	'好东西',
					'ranking_limit_score'	=>	30,
				],
			],
			'winners'			=>	[],
			'is_release'		=>	1,
			'create_time'		=>	NOW_TIME,
		];
		return Match::initMatch($aMatch);
	}

	public static function buildDailyMatch(){
		$aMatch = [
			'name'				=> '自动测试日常比赛',
			'profile'			=>	'',
			'big_match_profile'	=>	'',
			'description'		=>	'日常比赛描述',
			'rule'				=>	'比赛规则介绍',
			'match_start_time'	=>	NOW_TIME,
			'match_end_time'	=>	NOW_TIME + 86400,
			'duration'			=>	5,
			'join_fee'			=>	0,
			'rejoin_fee'		=>	5,
			'limit_level'		=>	0,
			'limit_xxt_type'	=>	[0, \common\xxt\gd\InterfaceGd::PLATFORM_TYPE, \common\xxt\sx\InterfaceSx::PLATFORM_TYPE],
			'is_team_match'		=>	0,
			'is_big_match'		=>	0,
			'limit_grades'		=>	[],
			'is_finish_can_draw'=>	1,
			'grade_id'			=>	5,
			'subject_id'		=>	1,
			'es_category_rule'	=>	[725],
			'view_css'			=>	'',
			'es_rule'			=>	[
				[
					'es_type_id'	=>	1,
					'es_count'		=>	1,
				],
				[
					'es_type_id'	=>	3,
					'es_count'		=>	1,
				],
				[
					'es_type_id'	=>	4,
					'es_count'		=>	1,
				],
				[
					'es_type_id'	=>	5,
					'es_count'		=>	1,
				],
				[
					'es_type_id'	=>	6,
					'es_count'		=>	1,
				],
				[
					'es_type_id'	=>	7,
					'es_count'		=>	1,
				],
			],
			'awards'			=>	[
				'top'	=>	[
					1	=>	[
						'gold'	=>	10,
						'prize'	=>	'好东西'
					],
					2	=>	[
						'gold'	=>	5,
						'prize'	=>	'好东西'
					],
					3	=>	[
						'gold'	=>	2,
						'prize'	=>	'好东西'
					],
				],
				'rand'	=>	[
					'number'	=>	3,
					'gold'		=>	3,
					'prize'	=>	'好东西',
					'ranking_limit_score'	=>	30,
				],
			],
			'winners'			=>	[],
			'is_release'		=>	1,
			'create_time'		=>	NOW_TIME,
		];
		return Match::initMatch($aMatch);
	}
}