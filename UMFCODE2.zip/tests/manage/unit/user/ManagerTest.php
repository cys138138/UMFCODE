<?php
namespace tests\manage\user;

use Yii;
use manage\model\Manager;
use umeworld\lib\Query;

class ManagerTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\manage\UnitTester
     */
    protected $tester;

    protected function _before()
    {
    }

    protected function _after()
    {
    }

    /**
	 * @author 黄文非
	 */
    public function testIsRootAdmin()
    {
		$adminId = Yii::$app->params['admin_id'];
		$aManager = (new Query())->from(Manager::tableName())->where(['<>', 'id', $adminId])->orderBy('rand()')->limit(1)->one();
		$mOtherManager = Manager::toModel($aManager);
		$this->assertFalse($mOtherManager->isRootAdmin());

		$mRootManager = Manager::findOne($adminId);
		$this->assertTrue($mRootManager->isRootAdmin());
    }

}