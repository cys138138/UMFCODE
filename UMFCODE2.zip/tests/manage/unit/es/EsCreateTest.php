<?php
namespace tests\manage\es;
 
use Yii;
use manage\model\Es;
use yii\db\Command;
use umeworld\lib\Query;
use manage\model\Grade;
use manage\model\Subject;
use manage\model\form\es\EditForm;

class EsCreateTest extends \Codeception\TestCase\Test
{

    protected $tester;
	private $_esId = 0;
	private $_categoryId = 363;
	private $_managerId = 1;
	private $_mEs = null;
	private $_oEditForm = null;
	
    protected function _before(){
		if(!$this->_oEditForm){
			$this->_initEsEditForm();
		}
    }

    protected function _after(){
		if($this->_esId){
			$this->_testDeleteEs();
		}
    }

	/**
	 * 测试出单选题
	 * @author jay
	 */
    public function testAddSingleChoiceEs(){
		$this->_oEditForm->esType = Es::TYPE_SINGLE_CHOICE;
		$this->_oEditForm->aEs = [
			'content' => 'iiiiii  lllll',
			'answer' => 3,
			'option' => [
				['content' => 'qqqqq'],
				['content' => 'wwwww'],
				['content' => 'eeeee'],
				['content' => 'rrrrr'],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }
	
	/**
	 * 测试出多选题
	 * @author jay
	 */
    public function testAddMultipleSingleChoiceEs(){
		$this->_oEditForm->status = Es::STATUS_SUBMIT;
		$this->_oEditForm->esType = Es::TYPE_MULTIPLE_CHOICE;
		$this->_oEditForm->aEs = [
			'content' => 'asdf',
			'answer' => [1, 3],
			'option' => [
				['content' => 'aaaa'],
				['content' => 'ssss'],
				['content' => 'dddd'],
				['content' => 'ffff'],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试出判断题
	 * @author jay
	 */
    public function testAddJudgmeEs(){
		$this->_oEditForm->esType = Es::TYPE_JUDGME;
		$this->_oEditForm->aEs = [
			'content' => 'zzzz?',
			'answer' => 0,
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试出填空题
	 * @author jay
	 */
    public function testAddFillBlankEs(){
		$this->_oEditForm->esType = Es::TYPE_FILL_BLANK;
		$this->_oEditForm->aEs = [
			'content' => 'zz ____ vv ____ bb',
			'answer' => [
				['aa'],
				['cc'],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试出选词项填空题
	 * @author jay
	 */
    public function testAddWordFillBlankEs(){
		$this->_oEditForm->esType = Es::TYPE_WORD_FILL_BLANK;
		$this->_oEditForm->aEs = [
			'content' => '____ 1.aa ____ 2.bb ____ 3.aa ____ 4.bb',
			'answer' => [
				['A'],
				['C'],
				['B'],
				['D'],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试出阅读理解题
	 * @author jay
	 */
    public function testAddComplexReadingEs(){
		$this->_oEditForm->esType = Es::TYPE_COMPLEX_READING;
		$this->_oEditForm->aEs = [
			'content' => 'aabbccddeeffgg',
			'es_item' => [
				[
					'type' => Es::TYPE_JUDGME,
					'content' => [
						'content' => 'zzzz?',
						'answer' => 0,
					],
				],
				[
					'type' => Es::TYPE_JUDGME,
					'content' => [
						'content' => 'cccc?',
						'answer' => 1,
					],
				],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试出完形填空题
	 * @author jay
	 */
    public function testAddComplexFillBlankEs(){
		$this->_oEditForm->esType = Es::TYPE_COMPLEX_FILL_BLANK;
		$this->_oEditForm->aEs = [
			'content' => 'aabbccddeeffgg',
			'es_item' => [
				[
					'type' => Es::TYPE_JUDGME,
					'content' => [
						'content' => 'zzzz?',
						'answer' => 0,
					],
				],
				[
					'type' => Es::TYPE_SINGLE_CHOICE,
					'content' => [
						'content' => 'iiiiii  lllll',
						'answer' => 3,
						'option' => [
							['content' => 'qqqqq'],
							['content' => 'wwwww'],
							['content' => 'eeeee'],
							['content' => 'rrrrr'],
						],
					],
				],
				[
					'type' => Es::TYPE_FILL_BLANK,
					'content' => [
						'content' => 'zz ____ vv ____ bb',
						'answer' => [
							['aa'],
							['cc'],
						],
					],
				],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试删除题目
	 * @author jay
	 */
    private function _testDeleteEs(){
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		$isSuccess = $mEs->delete();
		$this->assertTrue($isSuccess);
		$this->_esId = 0;
    }
	
	/**
	 * 初始化题目验证表单
	 * @author jay
	 */
	private function _initEsEditForm(){
		$this->_oEditForm = new EditForm();
		
		$this->assertInstanceOf('manage\model\form\es\EditForm', $this->_oEditForm);
		
		$this->_oEditForm->id = 0;
		$this->_oEditForm->isSubmit = 0;
		$this->_oEditForm->scenario = EditForm::SCENE_ADD_ES;
		$this->_oEditForm->subjectId = Subject::SUBJECT_ENGLISH_ID;
		$this->_oEditForm->categoryId = $this->_categoryId;
		$this->_oEditForm->status = Es::STATUS_SAVE;
		$this->_oEditForm->esType = Es::TYPE_SINGLE_CHOICE;
		$this->_oEditForm->aEs = [];
	}
	
	/**
	 * 测试添加题目
	 * @author jay
	 */
	private function _testAddEs(){
		$this->_mEs = Es::toModel([
			'type_id' => $this->_oEditForm->esType,
			'es_content' => $this->_oEditForm->aEs,
		]);
		$contentText = $this->_mEs->buildSearchText();
		$contentJson = $this->_mEs->es_content;
		$aEsData = [
			'subject_id' => $this->_oEditForm->subjectId,
			'type_id' => $this->_oEditForm->esType,
			'category_id' => $this->_oEditForm->categoryId,
			'status' => $this->_oEditForm->status,
			'correct_counts' => 0,
			'answer_counts' => 0,
			'correct_percent' => 0,
			'answer_time_total' => 0,
			'appeal_status' => Es::STATUS_APPEAL_NOT,
			'content_json' => $contentJson,
			'content_text' => $contentText,
			'action' => $this->_oEditForm->status,
			'submiter_user_id' => $this->_managerId,
			'approver_user_id' => 0,
			'operating_time' => NOW_TIME,
		];
		$this->_esId = Es::addEs($aEsData);
		//验证题目id
		$this->assertGreaterThan(0, $this->_esId);
		
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, $this->_oEditForm->status);
	}
}