<?php
namespace tests\manage\es;
 
use Yii;
use manage\model\Es;
use yii\db\Command;
use umeworld\lib\Query;
use manage\model\Manager;
use manage\model\Grade;
use manage\model\Subject;
use manage\model\form\es\EditForm;
use manage\model\form\es\OperateForm;

class EsManageTest extends \Codeception\TestCase\Test
{

    protected $tester;
	private $_esId = 0;
	private $_categoryId = 363;
	private $_managerId = 1;
	private $_mEs = null;
	private $_oEditForm = null;
	private $_oOperateForm = null;
	private $_mManager = null;
	
    protected function _before(){
		if(!$this->_mManager){
			$this->_mManager = Manager::findOne($this->_managerId);
			Yii::$app->manager->login($this->_mManager);
		}
		
		if(!$this->_oEditForm){
			$this->_initEsEditForm();
		}
		if(!$this->_oOperateForm){
			$this->_initEsOperateForm();
		}
    }

    protected function _after(){
		if($this->_esId){
			$this->_testDeleteEs();
		}
    }
	
	/**
	 * 测试（提交题目、通审题目、复核通过题目、作废题目）
	 * @author jay
	 */
	public function testSubmitAndPassApproveAndPassCheckAndCancelEs(){
		$this->_AddEs();
		//测试提交题目
		$this->_testSubmitEs();
		
		//测试通审题目
		$this->_testPassApproveEs();
		
		//测试复核通过题目
		$this->_testPassCheckEs();
		
		//测试作废题目
		$this->_testCancelEs();
	}
	
	/**
	 * 测试（提交题目、通审题目、复核不通过题目）
	 * @author jay
	 */
	public function testSubmitAndPassApproveAndFailCheckEs(){
		$this->_AddEs();
		//测试提交题目
		$this->_testSubmitEs();
		
		//测试通审题目
		$this->_testPassApproveEs();
		
		//测试复核不通过题目
		$this->_testFailCheckEs();
	}
		
	/**
	 * 测试(提交题目、驳回题目、申诉题目、申诉通过）
	 * @author jay
	 */
	public function testSubmitAndSendBackAndAppealAndPassAppealEs(){
		$this->_AddEs();
		//测试提交题目
		$this->_testSubmitEs();
		
		//驳回题目
		$this->_testSendBackEs();
		
		//申诉题目
		$this->_testAppealEs();
		
		//申诉通过题目
		$this->_testPassAppealEs();
		
	}
	
	/**
	 * 测试(提交题目、驳回题目、申诉题目、申诉不通过）
	 * @author jay
	 */
	public function testSubmitAndSendBackAndAppealAndFailAppealEs(){
		$this->_AddEs();
		//测试提交题目
		$this->_testSubmitEs();
		
		//驳回题目
		$this->_testSendBackEs();
		
		//申诉题目
		$this->_testAppealEs();
		
		//申诉不通过题目
		$this->_testFailAppealEs();
		
	}
	
	/**
	 * 测试提交题目
	 * @author jay
	 */
	public function _testSubmitEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_COMMIT_ES;
		$this->_oOperateForm->aId = [$this->_esId];
		$this->_oOperateForm->validate();
		$isSuccess = $this->_oOperateForm->commitEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_SUBMIT);
	}
		
	/**
	 * 申诉通过题目
	 * @author jay
	 */
	public function _testPassAppealEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_PASS_APPEAL_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->passAppealEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_PASS_CHECK);
		$this->assertEquals($mEs->appeal_status, Es::STATUS_APPEAL_SUCCESS);
	}
	
	/**
	 * 申诉不通过题目
	 * @author jay
	 */
	public function _testFailAppealEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_FAIL_APPEAL_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->failAppealEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->appeal_status, Es::STATUS_APPEAL_FAIL);
	}
	
	/**
	 * 申诉题目
	 * @author jay
	 */
	public function _testAppealEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_APPEAL_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->appealEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->appeal_status, Es::STATUS_APPEAL_ING);
	}
		
	/**
	 * 驳回题目
	 * @author jay
	 */
	public function _testSendBackEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_SEND_BACK_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->comment = 'ffffff';
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->sendBackEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_SEND_BACK);
	}
		
	/**
	 * 测试通审题目
	 * @author jay
	 */
	public function _testPassApproveEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_APPROVE_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->approveEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_WAIT_RECHECK);
	}
		
	/**
	 * 测试复核通过题目
	 * @author jay
	 */
	public function _testPassCheckEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_PASS_CHECK_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->passCheckEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_PASS_CHECK);
	}
		
	/**
	 * 测试复核不通过题目
	 * @author jay
	 */
	public function _testFailCheckEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_FAIL_CHECK_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->comment = 'fffffff';
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->failCheckEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_FAIL_CHECK);
	}
	
	/**
	 * 测试作废题目
	 * @author jay
	 */
	public function _testCancelEs(){
		$this->_oOperateForm->scenario = OperateForm::SCENE_CANCEL_ES;
		$this->_oOperateForm->id = $this->_esId;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->validate();
		
		$isSuccess = $this->_oOperateForm->cancelEs();
		$this->assertTrue($isSuccess);
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, Es::STATUS_FAIL_CANCEL);
	}

	/**
	 * 测试出题
	 * @author jay
	 */
    public function _AddEs(){
		$this->_oEditForm->esType = Es::TYPE_SINGLE_CHOICE;
		$this->_oEditForm->aEs = [
			'content' => 'iiiiii  lllll',
			'answer' => 3,
			'option' => [
				['content' => 'qqqqq'],
				['content' => 'wwwww'],
				['content' => 'eeeee'],
				['content' => 'rrrrr'],
			],
		];
		$isValidate = $this->_oEditForm->validate();
		$this->assertTrue($isValidate);
		$this->_testAddEs();
    }

	/**
	 * 测试删除题目
	 * @author jay
	 */
    private function _testDeleteEs(){
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		$isSuccess = $mEs->delete();
		$this->assertTrue($isSuccess);
		$this->_esId = 0;
    }
	
	/**
	 * 初始化题目操作表单
	 * @author jay
	 */
	private function _initEsOperateForm(){
		$this->_oOperateForm = new OperateForm();
		
		$this->assertInstanceOf('manage\model\form\es\OperateForm', $this->_oOperateForm);
		
		$this->_oOperateForm->id = 0;
		$this->_oOperateForm->aId = [];
		$this->_oOperateForm->comment = '';
		$this->_oOperateForm->reason = '';
		$this->_oOperateForm->scenario = OperateForm::SCENE_COMMIT_ES;
	}
	
	/**
	 * 初始化题目验证表单
	 * @author jay
	 */
	private function _initEsEditForm(){
		$this->_oEditForm = new EditForm();
		
		$this->assertInstanceOf('manage\model\form\es\EditForm', $this->_oEditForm);
		
		$this->_oEditForm->id = 0;
		$this->_oEditForm->isSubmit = 0;
		$this->_oEditForm->scenario = EditForm::SCENE_ADD_ES;
		$this->_oEditForm->subjectId = Subject::SUBJECT_ENGLISH_ID;
		$this->_oEditForm->categoryId = $this->_categoryId;
		$this->_oEditForm->status = Es::STATUS_SAVE;
		$this->_oEditForm->esType = Es::TYPE_SINGLE_CHOICE;
		$this->_oEditForm->aEs = [];
	}
	
	/**
	 * 测试添加题目
	 * @author jay
	 */
	private function _testAddEs(){
		$this->_mEs = Es::toModel([
			'type_id' => $this->_oEditForm->esType,
			'es_content' => $this->_oEditForm->aEs,
		]);
		$contentText = $this->_mEs->buildSearchText();
		$contentJson = $this->_mEs->es_content;
		$aEsData = [
			'subject_id' => $this->_oEditForm->subjectId,
			'type_id' => $this->_oEditForm->esType,
			'category_id' => $this->_oEditForm->categoryId,
			'status' => $this->_oEditForm->status,
			'correct_counts' => 0,
			'answer_counts' => 0,
			'correct_percent' => 0,
			'answer_time_total' => 0,
			'appeal_status' => Es::STATUS_APPEAL_NOT,
			'content_json' => $contentJson,
			'content_text' => $contentText,
			'action' => $this->_oEditForm->status,
			'submiter_user_id' => $this->_managerId,
			'approver_user_id' => 0,
			'operating_time' => NOW_TIME,
		];
		$this->_esId = Es::addEs($aEsData);
		//验证题目id
		$this->assertGreaterThan(0, $this->_esId);
		
		//验证题目
		$mEs = Es::findOne($this->_esId);
		$this->assertInstanceOf('manage\model\Es', $mEs);
		//验证题目状态
		$this->assertEquals($mEs->status, $this->_oEditForm->status);
	}
}