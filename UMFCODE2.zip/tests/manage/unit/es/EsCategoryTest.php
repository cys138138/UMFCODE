<?php
namespace tests\manage\es;
 
use Yii;
use manage\model\EsCategory;
use yii\db\Command;
use umeworld\lib\Query;
use common\model\Grade;


class EsCategoryTest extends \Codeception\TestCase\Test
{
    /**
     * @var \tests\manage\UnitTester
     */
    protected $tester;
	private $_aMEsCategory = [];
    protected function _before()
    {
		//有Child
		$id = Yii::$app->db->createCommand('select a.id from es_category a where a.parent_id in (select id from es_category) limit 1')->queryScalar();
		$this->assertTrue(is_scalar($id));
		$mEsCategory = EsCategory::findOne(['id' => $id]);
		$this->assertInstanceOf('manage\model\EsCategory', $mEsCategory);
		$this->_aMEsCategory[] = $mEsCategory;
		
		//无Child
		$id = Yii::$app->db->createCommand('select a.id from es_category a where a.id not in (select parent_id from es_category) limit 1')->queryScalar();
		$this->assertTrue(is_scalar($id));
		$mEsCategory = EsCategory::findOne(['id' => $id]);
		$this->assertInstanceOf('manage\model\EsCategory', $mEsCategory);
		$this->_aMEsCategory[] = $mEsCategory;
		
		$mEsCategory = null;		
    }

    protected function _after()
    {
		
    }

	/**
	 * 测试判断是否存在子目录
	 * @author zhou
	 */
    public function testHasChild()
    {
		$this->assertTrue($this->_aMEsCategory[0]->hasChild());	
		$this->assertFalse($this->_aMEsCategory[1]->hasChild());	
    }
	
	/**
	 * 测试获取一个年级模型实例
	 * @author zhou
	 */
	public function testGetGrade(){
		//父类为顶级分类
		$id = Yii::$app->db->createCommand('select id from es_category where parent_id not in (select id from es_category) limit 1')->queryScalar();
		$this->assertTrue(is_scalar($id));
		$mGrade = EsCategory::findOne(['id' => $id])->getGrade();
		$this->assertTrue(is_null($mGrade));
		
		//父类不为顶级分类
		$id = Yii::$app->db->createCommand('select id from es_category where parent_id  in (select id from es_category) limit 1')->queryScalar();
		$this->assertTrue(is_scalar($id));
		$mGrade = EsCategory::findOne(['id' => $id])->getGrade();
		$this->assertInstanceOf('common\model\Grade', $mGrade);
	}

}