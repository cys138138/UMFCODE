<?php
$aConfig = require(dirname(dirname(__DIR__)) . '/config/manage/acceptance.php');
$debugIndex = array_search('debug', $aConfig['bootstrap']);
if($debugIndex !== false){
	unset($aConfig['bootstrap'][$debugIndex]);
}
unset($debugIndex);
new umeworld\lib\Application($aConfig);