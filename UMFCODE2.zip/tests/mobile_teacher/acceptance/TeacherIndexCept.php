<?php use tests\mobile_teacher\AcceptanceTester;
use umeworld\lib\Url;
use umeworld\lib\Http;
use umeworld\lib\Query;
use umeworld\lib\Xxtea;
$I = new AcceptanceTester($scenario);
$I->wantTo('perform actions and see result');
$I->amLoginTeacherById(10);
$I->amOnPage(Url::to(['site/index']));

$I->waitForElement('#wrapPage .um-mt-home');
$I->see('欢迎使用优满分教师版');
//了解开通积分计划
$I->seeElement('#wrapPage .um-mt-home .desc .J-show-caption');//点这里了解积分计划
$I->executeJS(<<<JS
$('#wrapPage .um-mt-home .desc .J-show-caption').click();
JS
);
$I->waitForElement('.J-caption-mask .pop-caption-block .J-close');
$I->wait(3);
$I->executeJS(<<<JS
$('.J-caption-mask .pop-caption-block .J-close').click();
JS
);
$I->waitForElement('#wrapPage .um-mt-home');
$I->wait(3);

//开启积分计划
$isOpen = $I->executeJS('var isVisible = $(".J-show-sign").is(":visible");return isVisible;');
if($isOpen){
$I->seeElement('.um-mt-home .J-plan .plan-off .operate .J-show-sign');
$I->executeJS(<<<JS
$('.um-mt-home .J-plan .plan-off .operate .J-show-sign').click();
JS
);
$I->executeJS('$(".um-mt-home .J-plan .plan-off .operate .J-show-sign").click()');
$I->waitForElement('.J-sign-mask .pop-plan-block .title');
$I->see('开通积分计划');
$I->seeElement('.J-sign-mask .pop-plan-block .context');
$I->fillField(['class' => 'J-mobile-number'], '13065169005');

//获取验证码最后需要手动从手机里得到验证码输入
$I->seeElement('.J-sign-mask .pop-plan-block .context .J-code-button');
$I->click('.J-sign-mask .pop-plan-block .context .J-code-button');
$I->wait(5);
$I->click('.J-sign-mask .pop-plan-block .J-close');
$I->waitForElement('#wrapPage .um-mt-home');
}

//测试班级管理和兑换商城按钮，作业消息，名片，资料，兑换等
//查看班级管理标签
$I->seeElement('.um-mt-home .operate a:first-child');
$I->executeJS(<<<JS
$('.um-mt-home .operate a:first-child').click();
JS
);
$I->waitForElement('.um-mt-class-manage');
$I->see('班级管理');
$I->see('创建班级');
$I->seeElement('.footer a:first-child');
$I->click('.footer a:first-child');
$I->wait(3);

//查看首页兑换商城标签
$I->seeElement('.um-mt-home .operate a:last-child');
$I->executeJS(<<<JS
$('.um-mt-home .operate a:last-child').click();
JS
);
$I->waitForElement('.um-mt-exchange');
$I->see('兑换商城');
$I->seeElement('.footer a:first-child');
$I->click('.footer a:first-child');
$I->wait(3);

//底部标签能否点击，我的班级，兑换商城，我，返回，首页等按钮
//我发布作业
$I->seeElement('.um-mt-home .menu a:first-child');
$I->executeJS(<<<JS
$('.um-mt-home .menu a:first-child').click();
JS
);
$I->waitForElement('.um-mt-work-review .J-wr-list');
//$I->see('我发布作业');
$I->click('.footer a:first-child');
$I->wait(3);
//我的消息
$I->seeElement('.um-mt-home .menu a:nth-child(2)');
$I->executeJS(<<<JS
$('.um-mt-home .menu a:nth-child(2)').click();
JS
);
$I->waitForElement('.um-mt-message .J-msgList');

//我的名片
$I->click('#J-menu-manage');
$I->waitForElement('.um-mt-class-manage');
//查看班级管理主页面
$isOpenClass = $I->executeJS('var isVisible = $(".J-class-notice .J-show-build").is(":visible");return isVisible;');
if($isOpenClass){
	$I->click('.J-class-notice .J-show-build');
	$I->waitForElement('.J-class-mask .pop-class-block');
	//填写班级号，选择科目.
	$I->seeElement('.J-class-mask .pop-class-block .context .bottom-distance .J-class-name');//填写班级号
	$I->seeElement('.J-class-mask .pop-class-block .context .common-select-side .J-subject-select');
	$I->fillField(['class' => 'J-class-name'], '语文七班');
	$I->selectOption('.J-subject-select', '1');
	$I->click('.J-class-mask .pop-class-block .context .J-build-submit');
	$I->wait(5);
}

//先创建班级确保有班级
$seeBuildClass = $I->executeJS('var isVisible = $("#wrapPage .um-mt-class-manage .class-list .J-show-build-button").is(":visible");return isVisible;');
$I->assertTrue($seeBuildClass);
$I->click('.J-show-build-button');
$I->waitForElement('.J-class-mask .pop-class-block');
$I->seeElement('.J-class-mask .pop-class-block .context .bottom-distance .J-class-name');//填写班级
$I->seeElement('.J-class-mask .pop-class-block .context .common-select-side .J-subject-select');//科目
$I->fillField(['class' => 'J-class-name'], '语文七班');
$I->selectOption('.J-subject-select', '1');
$I->click('.J-class-mask .pop-class-block .context .J-build-submit');
$I->wait(5);
//然后开始新建名片
$I->click('#J-menu-home');
$I->waitForElement('.um-mt-home .menu a:nth-child(3)');
$I->executeJS(<<<JS
$('.um-mt-home .menu a:nth-child(3)').click();
JS
);
$I->waitForElement('.um-mt-card');
$isOpenCard = $I->executeJS('var isVisible = $(".J-no-card .J-newCard").is(":visible");return isVisible;');
$isHaveCard = $I->executeJS('var isVisible = $(".J-have-card").is(":visible"); return isVisible;');
//名片不存时
if($isOpenCard){
	$I->seeElement('.um-mt-card .J-newCard');
	$I->click('.um-mt-card .J-newCard');
	$I->waitForElement('.J-addCard-alert');
	$cardClass = $I->executeJS('return $(".J-addCard-alert .content #form_addCard .alert-label:first-child .J-class-select option:nth-child(1)").attr("value");');
	$I->selectOption('.J-class-select', $cardClass);
	$cardSubject = $I->executeJS('return $(".J-addCard-alert .content #form_addCard .alert-label:nth-child(2) .J-role-select option:nth-child(2)").attr("value");');
	$I->selectOption('.J-role-select', $cardSubject);
	$I->seeElement('.alert-okBtn .J-alert-okBtn');
    $I->click('.alert-okBtn .J-alert-okBtn');
	$I->wait(5);
	$isHaveCard = $I->executeJS('var isVisible = $(".J-have-card").is(":visible"); return isVisible;');
}

//最后删除班级
$I->click('#J-menu-manage');
$I->waitForElement('.um-mt-class-manage');
$I->executeJS('$("#wrapPage .um-mt-class-manage .class-list .J-class-item:first-child .J-show-button").click()');
$I->wait(1);
$I->executeJS('$("#wrapPage .um-mt-class-manage .class-list .J-class-detail .J-detail-tab:nth-child(3)").click()');
$I->waitForElement('.J-class-detail .J-class-operate .J-tab-remove');
$result = $I->executeJS('var isVisible = $(".J-class-detail .J-class-operate .J-tab-remove").is(":visible"); return isVisible;');
$I->assertTrue($result);
$I->executeJS('$(".J-class-detail .J-class-operate .J-tab-remove").click()');
$I->waitForElement(".wrapMask .uBoxWrapConfirm .wrapControl button:nth-child(1)");
$I->executeJS('$(".wrapMask .uBoxWrapConfirm .wrapControl button:nth-child(1)").click()');
$I->wait(3);
$I->click('#J-menu-home');
//我的资料
$I->wait(3);
$isMyInfo = $I->executeJS('var isVisible = $(".um-mt-home .menu a:nth-child(4)").is(":visible"); return isVisible;');
if($isMyInfo){
	$I->executeJS('$(".um-mt-home .menu a:nth-child(4)").click()');
	$I->waitForElement("#wrapPage .um-mt-user-edit");
}
$I->click('.footer a:first-child');

//我的兑换
$I->wait(3);
$I->seeElement('.um-mt-home .menu a:nth-child(5)');
$I->executeJS('$(".um-mt-home .menu a:nth-child(5)").click()');
$I->waitForElement('.um-mt-exchange-self');
$I->see('我的兑换');
$I->click('.footer a:first-child');
$I->wait(3);
return;






