<?php use tests\mobile_teacher\AcceptanceTester;
use umeworld\lib\Url;
use umeworld\lib\Http;
use umeworld\lib\Query;
$I = new AcceptanceTester($scenario);
$I->wantTo('perform actions and see result');
$I->amLoginTeacherById(10);
$I->amOnPage(Url::to(['site/index']));
//班级管理
$I->waitForElement('.footer');
$I->click('#J-menu-manage');
$I->waitForElement('.um-mt-class-manage');
//查看班级管理主页面
$isOpenClass = $I->executeJS('var isVisible = $(".J-class-notice .J-show-build").is(":visible");return isVisible;');
if($isOpenClass){
	$I->click('.J-class-notice .J-show-build');
	$I->waitForElement('.J-class-mask .pop-class-block');
	//填写班级号，选择科目.
	$I->seeElement('.J-class-mask .pop-class-block .context .bottom-distance .J-class-name');//填写班级号
	$I->seeElement('.J-class-mask .pop-class-block .context .common-select-side .J-subject-select');
	$I->fillField(['class' => 'J-class-name'], '语文七班');
	$I->selectOption('.J-subject-select', '1');
	$I->click('.J-class-mask .pop-class-block .context .J-build-submit');
	$I->wait(5);

}
$seeBuildClass = $I->executeJS('var isVisible = $("#wrapPage .um-mt-class-manage .class-list .J-show-build-button").is(":visible");return isVisible;');
$I->assertTrue($seeBuildClass);
$I->click('.J-show-build-button');
$I->waitForElement('.J-class-mask .pop-class-block');
$I->seeElement('.J-class-mask .pop-class-block .context .bottom-distance .J-class-name');//填写班级
$I->seeElement('.J-class-mask .pop-class-block .context .common-select-side .J-subject-select');//科目
$I->fillField(['class' => 'J-class-name'], '语文七班');
$I->selectOption('.J-subject-select', '1');
$I->click('.J-class-mask .pop-class-block .context .J-build-submit');
$I->wait(5);

//发作业操作
$I->waitForElement('#wrapPage .um-mt-class-manage');
$I->see('班级管理');
$isWork = $I->executeJS('var isVisible = $("#wrapPage .um-mt-class-manage .class-list .J-class-item:nth-child(2) .operate a").is(":visible"); return isVisible;');
$I->assertTrue($isWork);
$I->executeJS('$("#wrapPage .um-mt-class-manage .class-list .J-class-item:nth-child(2) .operate a").click()');
$I->waitForElement('.um-mt-work-manage');
$I->fillField(['class'=>'J-work-desc'],'好好学着点');
$workGrade = $I->executeJS('return $(".um-mt-work-manage .header .common-select-side .J-grade-select option:nth-child(2)").attr("value");');
$I->selectOption('.J-grade-select', $workGrade);
$I->seeElement(".um-mt-work-manage .context .work-detail .J-item:first-child .J-checkbox");
$I->click(".um-mt-work-manage .context .work-detail .J-item:first-child .J-checkbox");
$I->seeElement('.context .J-plan-button');
$I->executeJS('$(".context .J-plan-button").click()');
$I->wait(5);
$I->click('#J-menu-manage');
$I->waitForElement('.um-mt-class-manage');


//班级的删除操作
$I->executeJS('$("#wrapPage .um-mt-class-manage .class-list .J-class-item:first-child .J-show-button").click()');
$I->wait(1);
$I->executeJS('$("#wrapPage .um-mt-class-manage .class-list .J-class-detail .J-detail-tab:nth-child(3)").click()');
$I->wait(1);
$result = $I->executeJS('var isVisible = $(".J-class-operate").is(":visible");return isVisible;');
$I->assertTrue($result);
$I->executeJS('$(".J-class-detail .J-class-operate .J-tab-remove").click()');
$I->waitForElement(".wrapMask .uBoxWrapConfirm .wrapControl button:nth-child(1)");
$I->executeJS('$(".wrapMask .uBoxWrapConfirm .wrapControl button:nth-child(1)").click()');
$I->waitForElement('.um-mt-class-manage');


$I->executeJS('$(".J-class-detail .J-class-operate .J-tab-remove").click()');
$I->waitForElement(".wrapMask .uBoxWrapConfirm .wrapControl button:nth-child(1)");
$I->executeJS('$(".wrapMask .uBoxWrapConfirm .wrapControl button:nth-child(1)").click()');
//发金币，通知家长,班级编辑（上已经测试了删除操作）
return;






