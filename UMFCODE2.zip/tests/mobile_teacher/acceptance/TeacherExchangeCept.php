<?php use tests\mobile_teacher\AcceptanceTester;
use umeworld\lib\Url;
use umeworld\lib\Http;
use umeworld\lib\Query;
use umeworld\lib\Xxtea;
$I = new AcceptanceTester($scenario);
$I->wantTo('perform actions and see result');
$I->amLoginTeacherById(10);
return;
$I->amOnPage(Url::to(['site/index']));
$I->waitForElement('.footer');
$I->click('#J-menu-gift');
$I->waitForElement('.um-mt-exchange');
$I->see('兑换商城');

//查看兑换商品展示页面
$I->seeElement('.operate-bar .common-select-normal #category');
$I->click('.operate-bar .common-select-normal #category');
$I->wait(2);
$I->seeElement('.operate-bar .common-select-normal #sort');
$I->click('.operate-bar .common-select-normal #sort');
$I->wait(2);
$I->see('默认排序');
$I->see('积分升序');
$I->see('积分降序');
$I->see('兑换数升序');
$I->see('兑换数降序');
$I->see('上架时间升序');
$I->see('上架时间降序');
//获取我的积分和要兑换的积分
$myPoints = $I->executeJS('return $(".um-mt-exchange .operate-bar .label .purple-font").text();');
codecept_debug($myPoints);
//开始积分兑换(积分兑换得比较积分狗不够兑换，如果不够得到什么提示，然后就是返回,看积分是否变化，接着积分兑换是不是还够!)
$exchangePoints = $I->executeJS('return $(".um-mt-exchange #goodsList .item:last-child .price .purple-font").text();');
//获取积分数$myPoints = $I->executeJS('return $(".um-mt-exchange .operate-bar .label .purple-font").text();');
codecept_debug($exchangePoints);
$I->wait(1);
//开始积分兑换(积分兑换得比较积分狗不够兑换，如果不够得到什么提示，然后就是返回,看积分是否变化，接着积分兑换是不是还够!)
$I->seeElement('.contain .um-mt-exchange');
$goodsUrl = $I->grabAttributeFrom('.um-mt-exchange #goodsList a:last-child', 'href');
$goodsIdUrl = explode('/',$goodsUrl);
$goodsId = $goodsIdUrl[4];
$I->click('.um-mt-exchange #goodsList a:last-child');
$I->waitForElement('.um-mt-exchange-detail');
$I->see('商品详情');
//查看兑换量和库存量
$goodsExchangeCount = $I->executeJS('return $(".um-mt-exchange-detail .intro .info #goodsExchangeCount").text();');
codecept_debug($goodsExchangeCount);
$goodsStockCount = $I->executeJS('return $(".um-mt-exchange-detail .intro .info #goodsStockCount").text();');
codecept_debug($goodsStockCount);
$I->waitForElement('.um-mt-exchange-detail .exchange-button');
$I->click('.um-mt-exchange-detail .exchange-button');
$I->waitForElement('.J-contact-form .J-contact-button');
//填写收货地址
$I->fillField(['class' => 'J-contact-contact'], '谢天');
$I->fillField(['class' => 'J-contact-qq'], '907057241');
$I->fillField(['class' => 'J-contact-phone'], '13065169005');
$I->selectOption('.J-contact-province', '210000');
$I->selectOption('.J-contact-city', '210600');
$I->selectOption('.J-contact-areaId', '210603');
$I->fillField(['class' => 'J-contact-address'], '黄埔村榕树巷');
$I->click('.J-contact-form .J-contact-button'); //确认兑换
$I->wait(1);
//判断兑换结果，包括库存量是否还有，积分能否兑换,是否开启兑换，最后兑换如果失败了怎么办
if($goodsStockCount == 0){
	$I->see('该商品已经没有存库了');
}elseif($myPoints < $exchangePoints){
	//$I->see('您目前的积分不足以兑换');
}else{
$I->see('兑换成功');
$I->wait(3);
//查看兑换后积分兑换量和库存量的变化
//兑换量变化
$goodsExchangeCountAfter = $I->executeJS('return $(".um-mt-exchange-detail .intro .info #goodsExchangeCount").text();');
$I->assertEquals($goodsExchangeCountAfter, $goodsExchangeCount+1);

//库存量变化
$goodsStockCountAfter = $I->executeJS('return $(".um-mt-exchange-detail .intro .info #goodsStockCount").text();');
$I->assertEquals($goodsStockCountAfter+1, $goodsStockCount);

//积分的变化
$I->click('#J-menu-gift');
$I->waitForElement('.um-mt-exchange');
$I->see('兑换商城');
$myPointsAfter = $I->executeJS('return $(".um-mt-exchange .operate-bar .label .purple-font").text();');
$I->assertEquals($myPoints, $myPointsAfter+$exchangePoints);

//删除兑换记录把数据还原
//删除那条兑换记录teacher_exchange_record
$exchangeId = (new Query())->select(['id'])->from('_@teacher_exchange_record') ->where(['goods_id' => $goodsId, 'teacher_id' => 10])->orderBy(['create_time' => SORT_DESC])->limit(1)->one();
$I->assertNotEmpty($exchangeId, '教师最新积分兑换记录的id');
$deleteId = (new Query())->createCommand()->delete(Yii::$app->db->parseTable('_@teacher_exchange_record'), ['id' => $exchangeId])->execute();
$I->assertNotEquals(0, $deleteId);

//兑换量和库存量的还原teacher_exchange_goods(id； stock+1,sales_volume-1);
//$updateId = (new Query())->createCommand()->update(Yii::$app->db->parseTable('_@teacher_exchange_goods'), ['id' => $this->goodsId,'stock' => $this->exchangeId])->execute();
$aData = [
    'stock' => $goodsStockCount,
    'sales_volume' => $goodsExchangeCount
];

$updateId =(new Query())->createCommand()->update(Yii::$app->db->parseTable('_@teacher_exchange_goods'), $aData, ['id' => $goodsId])->execute();
$I->assertNotEquals(0, $updateId);

//还原积分
$aData = [
    'accumulate_points' => $myPoints,
];

$updatePoints = (new Query())->createCommand()->update(Yii::$app->db->parseTable('_@teacher_index'), $aData, ['id' => 10])->execute();
$I->assertNotEquals(0, $updatePoints);
}
return;






