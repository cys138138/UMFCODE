<?php use tests\mobile_teacher\AcceptanceTester;
use umeworld\lib\Url;
use umeworld\lib\Http;
use umeworld\lib\Query;
$I = new AcceptanceTester($scenario);
$I->wantTo('perform actions and see result');
$I->amLoginTeacherById(10);
$I->amOnPage(Url::to(['site/index']));
$I->executeJS(<<<JS
$('#J-menu-gift').click();
JS
);
return;