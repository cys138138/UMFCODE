<?php

defined('PROJECT_PATH') || define('PROJECT_PATH', __DIR__);
defined('FRAMEWORK_PATH') || define('FRAMEWORK_PATH', PROJECT_PATH . '/framework'      );

$aLocal = [
	'is_debug' => true,
	'env' => 'dev',
	'domain_suffix' => [
		'dev' => 'dev',
		'test' => 'test',
		'prod' => 'com',
	],
	'db' => [
		'master' => [
			'host' => '192.168.1.202',
			'username' => 'umfun_php_m',
			'password' => '121212',
			'node' => [
				['dsn' => 'mysql:host=192.168.1.202;dbname=umfun'],
			],
		],
		'slaver' => [
			'host' => '192.168.1.202',
			'username' => 'umfun_php_s',
			'password' => '121212',
			'node' => [
				['dsn' => 'mysql:host=192.168.1.202;dbname=umfun'],
			],
		],
	],
	'cache' => [
		'redis' => [
			'host'		=>	'192.168.1.202',
			'port'		=>	'6379',
			'password'	=>	'',
			'server_name' => 'redis_1',
			'part' => [
				'data' => 1,
				'login' => 2,
				'temp' => 3,
			],
		],

		'redisCache' => [
			'host'		=>	'192.168.1.202',
			'port'		=>	'6379',
			'password'	=>	'',
			'server_name' => 'redis_1',
			'part' => 3,
		],
	],
	'resource' => [
		//数学公式解析插件
		'mathjax' => 'http://192.168.1.202:9300/MathJax.js?config=umfun',
	],
	'temp' => [],
];


if(isset($_SERVER['SERVER_ADDR'])){
	if($_SERVER['SERVER_ADDR'] == '192.168.1.202'){
		$aLocal['env'] = 'test';
		$aLocal['cache']['redis']['part']['login'] = 4;
	}elseif($_SERVER['SERVER_ADDR'] == '115.159.25.111'){
		$aLocal['env'] = 'prod';
	}
}

if(!class_exists('Yii')){
	defined('YII_DEBUG') || define('YII_DEBUG', $aLocal['is_debug']);
	defined('YII_ENV') || define('YII_ENV', $aLocal['env']);
	require(FRAMEWORK_PATH . '/autoload.php');
	require(FRAMEWORK_PATH . '/yiisoft/yii2/Yii.php');
	require(PROJECT_PATH . '/rebuild/common/config/bootstrap.php');
}