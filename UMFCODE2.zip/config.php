<?php
define('DOMAIN_EXTEND', 'umfun.' . $aLocal['domain_suffix'][$aLocal['env']]);
define('DEFAULT_COOKIE_DOMAIN', DOMAIN_EXTEND);
define('IS_DISPLAY_ERROR', $aLocal['is_debug']);
define('SYSTEM_RESOURCE_URL', 	'http://s.' . DOMAIN_EXTEND . '/');

define('SYSTEM_ROOT_PATH', 		dirname(__FILE__) . '/');
define('SYSTEM_APPS_PATH', 		SYSTEM_ROOT_PATH . 'apps/');
define('SYSTEM_LOG_PATH', 		SYSTEM_ROOT_PATH . 'runtime/old/');
define('SYSTEM_RESOURCE_PATH', 	SYSTEM_ROOT_PATH . 'resource/');
define('SYSTEM_BASE_PATH', 		FRAMEWORK_PATH . '/umedev/');
define('SYSTEM_BASE_CLASS', 	SYSTEM_BASE_PATH . 'base.php');
define('DEFAULT_COOKIE_NAME_ENCODE',	0);
define('DEFAULT_COOKIE_EXPIRE', 		0);
define('DEFAULT_COOKIE_PATH', 			'/');
define('LOG_FILE_SIZE', 1048576);		//每个日志文件最大 10MB
define('XXT_LOG_FILE', SYSTEM_LOG_PATH . 'xxt_interface/' . date('Y-m-d') . '.log');		//每个日志文件最大100MB
define('XXTEA_KEY', 	'j2j_7GH_9Hj_azdd98YT');
define('SMTP_FROM', 	'UMFun(优满分)');
define('SMTP_ACCOUNT', 	'service@mail.umfun.com');
define('SMTP_PASSWORD', '5wfylhFxybwDUA5Zi31LQ8Ux');
define('SMTP_HOST', 	'smtp.mail.umfun.com');
define('SMTP_PORT', 	'25');
define('SMTP_TIME_OUT', '20');
define('SYSTEM_STATISTICS_CODE', !IS_DISPLAY_ERROR ? '<script src="http://s16.cnzz.com/stat.php?id=5670400&web_id=5670400" type="text/javascript" async="async"></script>' : '');
define('XXT_PERFORM_CODE', 'EFSAHRYEHKWW4854RE23QE4');
define('XXT_PLATFORM_KEY', 'EFSEWWW4854FAAEEWRE2QE8');

define('APP_LOGIN', 	'www.' 		. DOMAIN_EXTEND);
define('APP_HOME', 		'i.' 		. DOMAIN_EXTEND);
define('APP_ABOUT', 	'about.'	. DOMAIN_EXTEND);
define('APP_PAY', 		'pay.' 		. DOMAIN_EXTEND);
define('APP_PROXY', 	'proxy.' 	. DOMAIN_EXTEND);
define('APP_SERVICE', 	'service.' 	. DOMAIN_EXTEND);
define('APP_MANAGE', 	'm.' 		. DOMAIN_EXTEND);
define('APP_PARENT', 	'p.' 		. DOMAIN_EXTEND);
define('APP_TEACHER', 	't.' 		. DOMAIN_EXTEND);
define('APP_VIP',		'vip.' 		. DOMAIN_EXTEND);
define('APP_XXT',		'h5i.' 		. DOMAIN_EXTEND);
define('APP_P_XXT',		'p.xxt.' 	. DOMAIN_EXTEND);
define('APP_T_XXT',		'h5t.'		. DOMAIN_EXTEND);
define('APP_BBS',		'bbs.' 		. DOMAIN_EXTEND);


$GLOBALS['DB_CONFIG']['MYSQL_SERVER'] = array(
    'mysql_master_1'=>array(
        'host'		=>	$aLocal['db']['master']['host'],
        'username'	=>	$aLocal['db']['master']['username'],
        'password'	=>	$aLocal['db']['master']['password'],
    ),
    'mysql_slave_1'=>array(
        'host'		=>	$aLocal['db']['slaver']['host'],
        'username'	=>	$aLocal['db']['slaver']['username'],
        'password'	=>	$aLocal['db']['slaver']['password'],
    ),
);

$GLOBALS['DB_CONFIG']['REDIS_SERVER'] = array(
    'redis_1'=>array(
        'is_active' => 1,
        'host'		=>	$aLocal['cache']['redis']['host'],
        'port'		=>	$aLocal['cache']['redis']['port'],
        'password'	=>	$aLocal['cache']['redis']['password'],
    ),
);

define('IS_DEBUG', IS_DISPLAY_ERROR);
define('DATABASE_CHARSET', 'utf8');
$GLOBALS['DB_CONFIG']['IS_REDIS_ACTIVE'] = 1;
$GLOBALS['DB_CONFIG']['REDIS_PART'] = $aLocal['cache']['redis']['part']['data'];
$GLOBALS['DB_CONFIG']['LOGIN_REDIS_PART'] = $aLocal['cache']['redis']['part']['login'];
define('DEFAULT_REDIS_SERVER', 'redis_1');

define('T_MANAGER',						'mysql_master_1:mysql_slave_1,umfun.manager,redis_1');
define('T_MANAGER_GROUP',				'mysql_master_1:mysql_slave_1,umfun.manager_group,redis_1');
define('T_ES',							'mysql_master_1:mysql_slave_1,umfun.es,redis_1');
define('T_ES_CATEGORY',					'mysql_master_1:mysql_slave_1,umfun.es_category,redis_1');
define('T_ES_INDEX',					'mysql_master_1:mysql_slave_1,umfun.es_index,redis_1');
define('T_ES_LOG',						'mysql_master_1:mysql_slave_1,umfun.es_log,redis_1');
define('T_ES_ANALYSIS',					'mysql_master_1:mysql_slave_1,umfun.es_analysis,redis_1');
define('T_USER',						'mysql_master_1:mysql_slave_1,umfun.user,redis_1');
define('T_PERSONAL',					'mysql_master_1:mysql_slave_1,umfun.personal,redis_1');
define('T_USER_CLASS',					'mysql_master_1:mysql_slave_1,umfun.class,redis_1');
define('T_SCHOOL',						'mysql_master_1:mysql_slave_1,umfun.school,redis_1');
define('T_AREA',						'mysql_master_1:mysql_slave_1,umfun.area,redis_1');
define('T_ACCOUNT_NUMBER',				'mysql_master_1:mysql_slave_1,umfun.account_number,redis_1');
define('T_USER_LOGIN_LOG',				'mysql_master_1:mysql_slave_1,umfun.user_login_log,redis_1');
define('T_ALL_USER_LOGIN_LOG',			'mysql_master_1:mysql_slave_1,umfun.user_login_log,redis_1');
define('T_APPROVER_ES_RELATION',		'mysql_master_1:mysql_slave_1,umfun.approver_es_relation,redis_1');
define('T_USER_ES_FAVOURITE',			'mysql_master_1:mysql_slave_1,umfun.user_es_favourite,redis_1');
define('T_ES_FEEDBACK',					'mysql_master_1:mysql_slave_1,umfun.es_feedback,redis_1');
define('T_UB_USED',						'mysql_master_1:mysql_slave_1,umfun.ub_used,redis_1');
define('T_MISSION',						'mysql_master_1:mysql_slave_1,umfun.mission,redis_1');
define('T_MISSION_USER_RELATION_INDEX',	'mysql_master_1:mysql_slave_1,umfun.mission_user_relation_index,redis_1');
define('T_MISSION_USER_RELATION',		'mysql_master_1:mysql_slave_1,umfun.mission_user_relation,redis_1');
define('T_USER_ES_WRONG',				'mysql_master_1:mysql_slave_1,umfun.user_es_wrong,redis_1');
define('T_PROXY_USER',					'mysql_master_1:mysql_slave_1,umfun.proxy_user,redis_1');
define('T_PROXY_ANNOUNCEMENT',			'mysql_master_1:mysql_slave_1,umfun.proxy_announcement,redis_1');
define('T_SNS_EVENT',					'mysql_master_1:mysql_slave_1,umfun.sns_event,redis_1');
define('T_SNS_EVENT_DATA',				'mysql_master_1:mysql_slave_1,umfun.sns_event_data,redis_1');
define('T_SNS_PRIVATE_MESSAGE',			'mysql_master_1:mysql_slave_1,umfun.sns_private_message,redis_1');
define('T_SNS_PUBLIC_MESSAGE',			'mysql_master_1:mysql_slave_1,umfun.sns_public_message,redis_1');
define('T_SNS_SHUOSHUO',				'mysql_master_1:mysql_slave_1,umfun.sns_shuoshuo,redis_1');
define('T_SNS_SHUOSHUO_COMMENT',		'mysql_master_1:mysql_slave_1,umfun.sns_shuoshuo_comment,redis_1');
define('T_USER_FRIEND',					'mysql_master_1:mysql_slave_1,umfun.user_friend,redis_1');
define('T_USER_GROUP',					'mysql_master_1:mysql_slave_1,umfun.user_group,redis_1');
define('T_USER_RELATION',				'mysql_master_1:mysql_slave_1,umfun.user_relation,redis_1');
define('T_USER_GOODS',				    'mysql_master_1:mysql_slave_1,umfun.user_goods,redis_1');
define('T_PERSONAL_MESSAGE',			'mysql_master_1:mysql_slave_1,umfun.personal_message,redis_1');
define('T_NEW_AND_OLD_ES_RELATION',		'mysql_master_1:mysql_slave_1,umfun.new_and_old_es_relation,redis_1');
define('T_NEW_AND_OLD_CATEGORY_RELATION',	'mysql_master_1:mysql_slave_1,test.new_and_old_category_relation,redis_1');
define('T_CHINESE_ES',					'mysql_master_1:mysql_slave_1,test.chinese_es,redis_1');
define('T_CHINESE_KPS',					'mysql_master_1:mysql_slave_1,test.chinese_kps,redis_1');
define('T_CHINESE_KPS_CS',				'mysql_master_1:mysql_slave_1,test.chinese_kps_cs,redis_1');
define('T_MATH_ES',						'mysql_master_1:mysql_slave_1,test.math_es,redis_1');
define('T_MATH_KPS',					'mysql_master_1:mysql_slave_1,test.math_kps,redis_1');
define('T_MATH_KPS_CS',					'mysql_master_1:mysql_slave_1,test.math_kps_cs,redis_1');
define('T_ENGLISH_ES',					'mysql_master_1:mysql_slave_1,test.english_es,redis_1');
define('T_ENGLISH_KPS',					'mysql_master_1:mysql_slave_1,test.english_kps,redis_1');
define('T_ENGLISH_KPS_CS',				'mysql_master_1:mysql_slave_1,test.english_kps_cs,redis_1');
define('T_ES_COMMENT',					'mysql_master_1:mysql_slave_1,umfun.comment,redis_1');
define('T_QUESTION',					'mysql_master_1:mysql_slave_1,umfun.question,redis_1');
define('T_ANSWER',						'mysql_master_1:mysql_slave_1,umfun.answer,redis_1');
define('T_USER_NUMERICAL',				'mysql_master_1:mysql_slave_1,umfun.user_numerical,redis_1');
define('T_USER_GOLD_RECORD',			'mysql_master_1:mysql_slave_1,umfun.user_gold_record,redis_1');
define('T_USER_DAILY_BEHAVIOR',			'mysql_master_1:mysql_slave_1,umfun.user_daily_behavior,redis_1');
define('T_MEDAL',						'mysql_master_1:mysql_slave_1,umfun.medal,redis_1');
define('T_MARK',						'mysql_master_1:mysql_slave_1,umfun.mark,redis_1');

//充值模块相关表配置
define('T_BATCH',						'mysql_master_1:mysql_slave_1,umfun_recharge.card_batch,redis_1');
define('T_MONTHLY_FEE_RECHARGE_CARD',	'mysql_master_1:mysql_slave_1,umfun_recharge.card_month_recharge,redis_1');
define('T_CARD_RESOURCE',				'mysql_master_1:mysql_slave_1,umfun_recharge.card_resource,redis_1');
define('T_UB_RECHARGE_CARD',			'mysql_master_1:mysql_slave_1,umfun_recharge.card_ub_recharge,redis_1');
define('T_RECHARGE',					'mysql_master_1:mysql_slave_1,umfun_recharge.recharge,redis_1');
define('T_MATCH',						'mysql_master_1:mysql_slave_1,umfun.match,redis_1');
define('T_MATCH_USER_RELATION',			'mysql_master_1:mysql_slave_1,umfun.match_user_relation_index,redis_1');
define('T_USER_VISITOR',				'mysql_master_1:mysql_slave_1,umfun.user_visitor,redis_1');
define('T_STYLE',						'mysql_master_1:mysql_slave_1,umfun.style,redis_1');
define('T_USER_EXTEND',			'mysql_master_1:mysql_slave_1,umfun.user_extend,redis_1');

define('T_PK_INDEX',			'mysql_master_1:mysql_slave_1,umfun.pk_index,redis_1');
define('T_PK',			'mysql_master_1:mysql_slave_1,umfun.pk,redis_1');

define('T_USER_INVITATION',			'mysql_master_1:mysql_slave_1,umfun.user_invitation,redis_1');
define('T_PERSONAL_MESSAGE_BAK',			'mysql_master_1:mysql_slave_1,umfun.personal_message_bak,redis_1');

define('T_LIMIT',			'mysql_master_1:mysql_slave_1,umfun.limit,redis_1');
define('T_LOGIN_LIMIT',			'mysql_master_1:mysql_slave_1,umfun.login_limit,redis_1');
define('T_EMAIL_LIMIT',			'mysql_master_1:mysql_slave_1,umfun.email_limit,redis_1');
define('T_USER_INFO_APPROVE',			'mysql_master_1:mysql_slave_1,umfun.user_info_approve,redis_1');

//视频表
define('T_VIDEO',			'mysql_master_1:mysql_slave_1,umfun.video,redis_1');
define('T_VIDEO_CATEGORY',			'mysql_master_1:mysql_slave_1,umfun.video_category,redis_1');

//家长表
define('T_PARENT',						'mysql_master_1:mysql_slave_1,umfun.parent,redis_1');

//老师表
define('T_TEACHER',						'mysql_master_1:mysql_slave_1,umfun.teacher,redis_1');
define('T_TEACHER_INDEX',						'mysql_master_1:mysql_slave_1,umfun.teacher_index,redis_1');
define('T_STUDENT_GROUP',						'mysql_master_1:mysql_slave_1,umfun.student_group,redis_1');

//道具
define('T_PROP',						'mysql_master_1:mysql_slave_1,umfun.prop,redis_1');
define('T_PROP_USER_RELATION',						'mysql_master_1:mysql_slave_1,umfun.prop_user_relation,redis_1');
define('T_PROP_PURCHASE_RECORDS',						'mysql_master_1:mysql_slave_1,umfun.prop_purchase_records,redis_1');
define('T_PROP_USE_RECORDS',						'mysql_master_1:mysql_slave_1,umfun.prop_use_records,redis_1');
define('T_PROP_SEND_RECORDS',						'mysql_master_1:mysql_slave_1,umfun.prop_send_records,redis_1');
define('T_EXCHANGE_GOODS',						'mysql_master_1:mysql_slave_1,umfun.exchange_goods,redis_1');
define('T_EXCHANGE_RECORDS',						'mysql_master_1:mysql_slave_1,umfun.exchange_records,redis_1');
define('T_PUSH_INFO_SOURCE_COUNT',						'mysql_master_1:mysql_slave_1,umfun.push_info_source_count,redis_1');

//vip
define('T_VIP_PRIVILEGE',						'mysql_master_1:mysql_slave_1,umfun.vip_privilege,redis_1');

//反馈
define('T_FEEDBACK',						'mysql_master_1:mysql_slave_1,umfun.feedback,redis_1');

//BBS
define('T_BBS_CATEGORY',						'mysql_master_1:mysql_slave_1,umfun.bbs_category,redis_1');
define('T_BBS_THREAD_INDEX',						'mysql_master_1:mysql_slave_1,umfun.bbs_thread_index,redis_1');
define('T_BBS_THREAD',						'mysql_master_1:mysql_slave_1,umfun.bbs_thread,redis_1');
define('T_BBS_COMMENT_INDEX',						'mysql_master_1:mysql_slave_1,umfun.bbs_comment_index,redis_1');
define('T_BBS_COMMENT',						'mysql_master_1:mysql_slave_1,umfun.bbs_comment,redis_1');
define('T_BBS_NOTIFICATION',						'mysql_master_1:mysql_slave_1,umfun.bbs_notification,redis_1');
define('T_BBS_TYPE',						'mysql_master_1:mysql_slave_1,umfun.bbs_category_classify,redis_1');

//活动
define('T_TEACHER_DAY_TEACHER',						'mysql_master_1:mysql_slave_1,umfun.teacher_day_teacher,redis_1');
define('T_TEACHER_DAY_STUDENT',						'mysql_master_1:mysql_slave_1,umfun.teacher_day_student,redis_1');
define('T_RAIDERS_PRIZE',						'mysql_master_1:mysql_slave_1,umfun.raiders_prize,redis_1');
define('T_RAIDERS_AWARD',						'mysql_master_1:mysql_slave_1,umfun.raiders_award,redis_1');
define('T_RAIDERS_JOIN',						'mysql_master_1:mysql_slave_1,umfun.raiders_join,redis_1');
define('T_RAIDERS_RAIDERS_SELECT_PRIZE_RECORD',						'mysql_master_1:mysql_slave_1,umfun.raiders_select_prize_record,redis_1');
define('T_TEACHER_USER_RELATION',						'mysql_master_1:mysql_slave_1,umfun.teacher_user_relation,redis_1');

//教育资讯
define('T_EDU_NEWS_CATEGORY',						'mysql_master_1:mysql_slave_1,umfun.edu_news_category,redis_1');
define('T_EDU_NEWS_CONTENT',						'mysql_master_1:mysql_slave_1,umfun.edu_news_content,redis_1');

//学生月统计
define('T_USER_MONTH_STATISTICS_INDEX',						'mysql_master_1:mysql_slave_1,umfun.user_month_statistics_index,redis_1');
define('T_USER_MONTH_STATISTICS',						'mysql_master_1:mysql_slave_1,umfun.user_month_statistics,redis_1');

//团队比赛活动
define('T_TEAM_JOIN',									'mysql_master_1:mysql_slave_1,umfun.team_join,redis_1');
define('T_TEAM_MATCH',									'mysql_master_1:mysql_slave_1,umfun.team_match,redis_1');
define('T_TEAM_PRIZE',									'mysql_master_1:mysql_slave_1,umfun.team_prize,redis_1');

//天津英华表常量
define('T_TJ_USER',									'mysql_master_1:mysql_slave_1,umfun.tj_user,redis_1');