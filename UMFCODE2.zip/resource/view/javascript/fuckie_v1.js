

//IE6-7提示升级
$(function(){  
  
	var fuckHtml = '\
		<div id="browser" class="browser">\
				<span class="txt">检测到您的浏览器版本过低，为了给您更好的体验，请您升级浏览器：</span>\
				<span class="links">\
					<a href="http://windows.microsoft.com/zh-cn/internet-explorer/ie-8-worldwide-languages" target="_blank"><i class="icon_ie8"></i>IE8</a>\
					<a href="https://www.google.com/chrome/" target="_blank"><i class="icon_chrome"></i>chrome</a>\
					<a href="http://www.firefox.com.cn/download/" target="_blank"><i class="icon_firefox"></i>firefox</a>\
					<a href="http://www.opera.com/download/" target="_blank"><i class="icon_opera"></i>opera</a>\
					<a href="http://support.apple.com/kb/DL1531?viewlocale=zh_CN" target="_blank"><i class="icon_safari"></i>safari</a>\
				</span>\
				<span class="active"><a class="close" href="javascript:;">×</a></span>\
		</div>';
	
	$('body').prepend(fuckHtml);
	$('#browser .close').click(function(){
		$('#browser').slideUp('fast',function(){
			$(this).remove();
		});
	});
  
  
});


