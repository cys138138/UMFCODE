


//小纸条
function noteSelect(){
    $('#select_friends_active').click(function(){
        $(this).next().slideToggle(200);
        return false;
    });
    $.Tab('#select_friends_group', '#select_friends_list', 'click');
    $('#select_friends_list .list a').click(function(){
        $('#select_friends_active').html($(this).html());
        $('#select_friends_frame').slideUp(200);
        return false;
    });
    $('#note_dialogue_list, #note_dialogue_group').children('li').hover(function(){
        $(this).toggleClass('on');
    })
}


//好友管理
function friendsManagement(){
    function CheckInputCount(){
        $('[xid="textCount"]').on('keydown', function(){
            $(this).parent().find('span.totalnum').children('em').html($(this).val().length);
        });
    }

    function cancelLi(){
        $('[xid="cancel"]').on('click', function(){
            $(this).parent().hide();
        });
    }

    CheckInputCount();
    cancelLi();

	/*
    $('#friendsgroup_list [xid="groupName"]').click(function(){
        $(this).parent('li').addClass('cur').siblings('li').removeClass('cur');
    });
*/
    /*$('#friendsgroup_list [xid="groupEdit"]').click(function(){
        var $oLi = '\n\
            <li class="group_edit_li" id="group_edit_li">\n\
                <input type="text" maxlength="6" xid="textCount" class="text" maxlength="6" value=" ' + $(this).prev().prev().html() + '" />\n\
                <a href="#" class="btn_save">保存</a>\n\
                <i xid="cancel" class="icon icon_group_cancel" title="取消"></i>\n\
                <span class="totalnum"><em>' + $(this).prev().prev().html().length + '</em>/6</span>\n\
            </li>';
        $(this).parent().siblings('#group_edit_li').remove();
        $(this).parent('li').after($oLi);
        CheckInputCount();
        cancelLi();
    });*/

    $('#createBtn').click(function(){
        $(this).parent().next().show();
    });

/*
    //好友分组-右侧的下拉菜单
    $('[xid=change_group]').hover(function(){
        $(this).children('ul').slideToggle(100);
    });
*/
}



//个人中心-左侧折叠菜单
function snsGroupMenu(){
    var $group_list = $('#sns_group_list > li:gt(3)');
    var $show_active = $('#group_show_active');
    $group_list.hide();
    $show_active.click(function(){
        $group_list.toggle();
        if($group_list.is(':visible')){
            $(this).find('span').text('隐藏部分分组');
        }else{
            $(this).find('span').text('展开全部分组');
        }
        return false;
    });

    $('.sns_member .head').hover(function(){
        $(this).find('.head_edit').stop().slideToggle('fast');
    });
}


//个人中心-选项卡
function feedTab(){
    $.Tab('#feed_tab', '#feed_mod', 'click');
    $.Tab('#rec_tab_hd', '#rec_tab_bd', 'click');
}

//访客删除按钮-显示隐藏
function snsVisitors(){
    $('#sns_visitors li').hover(function(){
        $(this).find('.del').toggle();
    });
	$('.sns_challenge li').hover(function(){
        $(this).find('.btn').toggle();
    });
}


//at 好友
function insertHtmlAtCaret(html) {
    var sel, range;
    if (window.getSelection) {
        // IE9 and non-IE
        sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            range = sel.getRangeAt(0);
            range.deleteContents();
            // Range.createContextualFragment() would be useful here but is
            // non-standard and not supported in all browsers (IE9, for one)
            var el = document.createElement("div");
            el.innerHTML = html;
            var frag = document.createDocumentFragment(),
                node, lastNode;
            while ((node = el.firstChild)) {
                lastNode = frag.appendChild(node);
            }
            range.insertNode(frag);
            // Preserve the selection
            if (lastNode) {
                range = range.cloneRange();
                range.setStartAfter(lastNode);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
        }
    } else if (document.selection && document.selection.type != "Control") {
        // IE < 9
        document.selection.createRange().pasteHTML(html);
    }
}

//显示朋友列表
function atFriedsList(){
    $('#at_active').click(function(){
        $('#at_friends_frame').toggle();
        $(this).find('.icon_at').toggleClass('at_active_on');
    });
    $.Tab('#at_friends_group', '#at_friends_list', 'click');

    $('#at_friends_closed').click(function(){
        $('#at_friends_frame').hide();
        $('#at_active').find('.icon_at').removeClass('at_active_on');
    });

    $(document).on('click', '#at_friends_list .list a', function(){
        $('#texteditor').focus();
        var oBtn = '<button contenteditable="false">@' + $(this).find('.name').text() +'</button>';
        insertHtmlAtCaret(oBtn);
		var atUserId = $('#atUserId').val();
		$('#atUserId').val($(this).attr('uid') + ',' + atUserId);
    });
}

//转发说说的弹窗
function retweetPop(){
    var popHtml = '\
            <div class="retweet_pop">\
                <div class="pop_hd">\
                    <h3>转给我的好友</h3>\
                    <a class="close" title="关闭">×</a>\
                </div>\
                <div class="pop_info">\
                    <div class="feed_reply_inner">\
                        <div class="reply_inputer">\
                        <div class="editors editors_focus" contenteditable="true" id="forward_content" ></div>\
                    </div>\
                    <div class="reply_addons">\
                        <div class="poster_attach c">\
                            <span class="at">\
                                <a class="retweet_at" title="@好友"><i class="icon icon_at"></i></a>\
                                <span class="at_tips">\
                                    <i class="triangle"></i>\
                                试一试@你的好友！\
                                </span>\
                            </span>\
                        </div>\
                        <div class="poster_op">\
                        <div class="btn"><input type="button" class="icon poster_btn" value="转发" onclick="forwardShuoShuo();"></div>\
                        </div>\
                        </div>\
                    </div>\
                </div>\
            </div>\
            ';

    $(document).on('click', '.retweet_active', function(event){		
        $('.retweet_pop').remove();
		$('#forwardId').val($(this).attr('shuoshuo_id'));
        $(this).parents('.single').append(popHtml);
        var retweetPop = $('.retweet_pop');
        var replyFriends = $('#reply_at_friends');
        var editors = retweetPop.find('.editors');
        editors.focus();
        retweetPop.on('click', '.close', function(){
            $('body').append(replyFriends);
            retweetPop.remove();
            replyFriends.removeClass('reply_at_friends_show');
        });
        event.stopPropagation();

        $('.retweet_at').on('click', function(){
            $(this).parents('.retweet_pop').append(replyFriends);
            replyFriends.addClass('reply_at_friends_show');
            $('#reply_at_list a').unbind('click');
            $('#reply_at_list a').bind('click', function(){
                editors.focus();
                var oBtn = '<button contenteditable="false">@' + $(this).find('.name').text() +'</button>';
                insertHtmlAtCaret(oBtn);
				var atUserId = $('#atUserId').val();
				$('#atUserId').val($(this).attr('uid') + ',' + atUserId);
            });
        });
        $('#reply_friends_closed').click(function(){
            $('body').append(replyFriends);
            replyFriends.removeClass('reply_at_friends_show');
        });

    });
}


//说说列表下面的回复
function feedReply(){

    function operating(){
        $(document).on('click', '.feed_reply', function(event){
            var editors = $(this).find('.editors');
            var replyAt = $(this).find('.reply_at');
            var _this = $(this);
            var replyFriends = $('#reply_at_friends');

            $(this).find('.editors_place').hide();
            editors.addClass('editors_focus').focus();
            $(this).find('.reply_addons').show();
            event.stopPropagation();


            $(document).on('click', function(){
                if(editors.html() == ''){
                    editors.removeClass('editors_focus')
                        .next().show()
                        .parent().next().hide();
                    replyFriends.removeClass('reply_at_friends_show');
                }
            });

            replyAt.on('click', function(){
                _this.append(replyFriends);
                replyFriends.addClass('reply_at_friends_show');
                $('#reply_at_list a').off('click');
                $('#reply_at_list a').on('click', function(){
                    editors.focus();
                    var oBtn = '<button contenteditable="false">@' + $(this).find('.name').text() +'</button>';
                    insertHtmlAtCaret(oBtn);
					var atUserId = $('#atUserId').val();
					$('#atUserId').val($(this).attr('uid') + ',' + atUserId);
                });
                $('#reply_friends_closed').click(function(){
                    $('body').append(replyFriends);
                    replyFriends.removeClass('reply_at_friends_show');
                });
            });

        });
    }

    operating();

}


//说说输入框字数限制
function shuoNum(){

	var filterRegexp = [] // 内容匹配正则
	filterRegexp['button1'] = /<button[^>]*>/ig; // 保留button
	filterRegexp['button2'] = /<\/button>/ig; // 保留button
	filterRegexp['button12'] = /<button[^>]*>[^<]+<\/button>/ig; // 保留button
	filterRegexp['div1'] = /<div[^>]*>/ig; // 保留div
	filterRegexp['div2'] = /<\/div>/ig; // 保留div
	filterRegexp['expression'] = /\[:\/[a-z\d]+\]/ig; // 表情
	filterRegexp['strip_tags1'] = /<[a-z][^>]*>/ig; // 去除html标签
	filterRegexp['strip_tags2'] = /<\/[^>]*>/ig; // 去除html标签
	filterRegexp['html_entity'] = /\&[a-z]+\;/ig; // html实体替换为空格&nbsp;
	filterRegexp['image_name'] = /<img[^>]+src="[^"]+\/([0-9a-z]+)\.([a-z]+)[^>]*>/ig; // 图片匹配

	var filter = [];
	filter['#'] = [];
	filter['#'].push(filterRegexp['button12']);
	filter['#'].push(filterRegexp['div1']);
	filter['#'].push(filterRegexp['div2']);
	filter['#'].push(filterRegexp['expression']);
	filter['#'].push(filterRegexp['image_name']);
	filter[' '] = filterRegexp['html_entity'];
	filter['__'] = [];
	filter['__'].push(filterRegexp['strip_tags1']);
	filter['__'].push(filterRegexp['strip_tags2']);

	var countShwo = function(th){
		var $th = $(th);
        $th.parents('.single').addClass('level').siblings().removeClass('level');
        $th.prev('.editors_num').remove();
        $th.before('<span class="editors_num">0/140</span>');
        var $num = $th.prev('.editors_num');

		texts = $th.html();
		for( i in filter ){
			//【__】为替换空字符
			replaceVal = i == '__' ? '' : i;
			if(typeof(filter[i].length) == 'undefined'){
				texts = texts.replace(filter[i],replaceVal);
			}else{
				for(j=0; j<filter[i].length; j++){
					texts = texts.replace(filter[i][j],replaceVal);
				}
			}
		}
		//console.log(texts,texts.length);
		$num.html(texts.length + '/140');
		if(texts.length > 140){
			$num.css('color', 'red');
		}else{
			$num.css('color', '#888');
		}
	}

    $('body').delegate('.editors, .texteditor', 'focus', function(){
		countShwo(this);//
    }).delegate('.editors, .texteditor', 'blur', function(){
        $('.editors_num').remove();
    }).delegate('.editors, .texteditor', 'keydown', function(){
		countShwo(this);//
    }).delegate('.editors, .texteditor', 'keyup', function(){
		countShwo(this);//
    });

}


//输入@弹出好友列表
function friendsShow(){
    $('body').delegate('.editors, .texteditor', 'focus', function(){
        var editors = $(this);
        var $single = $(this).parent().parent();
        var replyFriends = $('#reply_at_friends');
        $(document).keydown(function(event){
            if(event.shiftKey && event.keyCode==50){
                $single.append(replyFriends);
                replyFriends.addClass('reply_at_friends_show');
                return false;
            }
        });
        $('#reply_at_list a').off('click');
        $('#reply_at_list a').on('click', function(){
            editors.focus();
            var oBtn = '<button contenteditable="false">@' + $(this).find('.name').text() +'</button>&nbsp;';
            insertHtmlAtCaret(oBtn);
        });
        $('#reply_friends_closed').click(function(){
            $('body').append(replyFriends);
            replyFriends.removeClass('reply_at_friends_show');
        });
    });
}









$(function(){
    noteSelect();           //小纸条
    friendsManagement();    //好友管理
    snsGroupMenu();         //个人中心-菜单
    feedTab();              //个人中心-选项卡
    snsVisitors();          //访客删除按钮
    atFriedsList();         //at 好友
    retweetPop();           //转发说说
    feedReply();            //说说回复
    shuoNum();              //字数限制
    friendsShow();          //输入@弹出好友列表
});