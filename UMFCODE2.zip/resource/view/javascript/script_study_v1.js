
//评论
function esComment(){
    //添加评论类型
    $('#add_comment_menu > li').click(function(){
        $(this).toggleClass('selected').siblings().removeClass('selected');
        return false;
    });
    //评论列表的选项卡
    $.Tab('#comment_select', '#comment_content', 'click');
    $('.comment_list .comment_list > li:last').css('borderBottom', 'none');
}

//挑战页面右侧道具选项卡
function challengePropsTab(){
    $('#sidebar_props_select > li:lt(5)').addClass('sidebar_props_top');
    $('#sidebar_props_select > li:gt(4)').addClass('sidebar_props_bottom');
    $.Tab('#sidebar_props_select', '#sidebar_props_content', 'mouseover');
}

//错题集下拉菜单
function wrongListSelect(){
    $('#wrongList_select > li').hover(function(){
        $(this).children('ul').toggle();
    });
}

//挑战结果弹窗
function challengePop(){
    $('#mask').height($('body').height());
    $('#mask').click(function(){
        $(this).hide();
        $('#challenge_pop').hide();
    });
}


//勋章
function myMedal(){
    $('.medal_wrap').each(function(){
        var wrap = $(this);
        var wrapHeight = wrap.height();
        var medalBtn = wrap.find('.medal_btn');
        
        wrap.css({'height': '100px'});
        medalBtn.click(function(){
            $(this).find('span:first').toggle();
            if(wrap.css('height') == '100px'){
                wrap.animate({'height': wrapHeight});
            }else{
                wrap.animate({'height': '100px'});
            }
        });
    });

}

$(function(){
    esComment();            //评论
    challengePropsTab();    //道具选项卡
    wrongListSelect();       //错题集下拉菜单
    challengePop();         //挑战结果弹窗
    myMedal();              //勋章
});
