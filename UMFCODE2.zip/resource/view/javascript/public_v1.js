/**
*@param data   提示文字
*@param classId	提示样式 succe_ok成功样式 ，error错误
*/
function showDialog(data,classId)
{
	easyDialog.open({
		  container : {  
		    content : '<div class="whole"> <div class="Prompt1"><div class="'+classId+'"></div>'+data+'<div class="Prompt_right1"></div></div></div>'
		  },
		  autoClose : 2000,
		  overlay : false
		});
$('#easyDialogWrapper').css('border','0');
} 


//弹出窗口
function showBoxWindow(_W,_H,_TITLE,_URL,IS_UP){
	var ie6=!-[1,]&&!window.XMLHttpRequest;

	var mask =window.parent.document.createElement("div");
	mask.id="mask_div";
	mask.style.position ="fixed";
	mask.style.margin="0px";
	mask.style.padding="0px";
	mask.style.top="0px";
	mask.style.left="0px";
	mask.style.width="100%";
	mask.style.height="100%";
	mask.style.zIndex="999";
	mask.style.backgroundColor="rgb(0,0,0)";
	mask.style.opacity="0.7";
	mask.style.filter="alpha(opacity=70)";
	mask.style.display="block";
	

	

	var load_main = window.parent.document.createElement("div");
	load_main.id="load_div";
	load_main.style.width=_W+'px';
	load_main.style.height=parseInt(_H+36)+'px';
	load_main.style.position ="fixed";
	load_main.style.zIndex="10000";
	load_main.style.backgroundColor="#fff";
	load_main.style.overflow='hidden';
	load_main.style.border='7px solid #999';
	var _mt= parseInt(document.documentElement.clientHeight) - parseInt(_H);
	_mt = parseInt(_mt/2) + 'px';
	var _lf= parseInt(document.documentElement.clientWidth) - parseInt(_W);
	_lf = parseInt(_lf/2) + 'px';
	load_main.style.left=_lf;
	load_main.style.top= _mt;
	
	
	var top_div = window.parent.document.createElement("div");
	top_div.style.width=_W+'px';
	top_div.style.height='36px';
	top_div.style.padding='0 10px';
	top_div.style.borderBottom='1px solid #ccc';	
	var top_h=parseInt(_W)-30;

	var close_ifream_str = '关闭窗口';
	if(GetCookie('FID')=='d3fK3OO7fc5r3vuIo_'){close_ifream_str = 'Close';}
	
	var top_str = "<div style='width:"+top_h+"px;height:36px;padding:0 15px;border-bottom:1px solid #ccc;line-height:36px;color:#06c'><h4 style='float:left;font-size:14px' id='ifream_title'>"+_TITLE+"</h4><h4 style='float:right;cursor:pointer' title='"+close_ifream_str+"' onclick='cancel_mask()'>X</a></h4>";
	
	if(IS_UP == 'is_up'){top_str += "<input type='hidden' id='is_up' />";}
	if(IS_UP == 'write_msg'){top_str += "<input type='hidden' id='write_msg' />";}
	
	
	load_main.innerHTML=top_str;

	
	var ifream = window.parent.document.createElement("iframe");
	
	ifream.id="load_ifream";
	
	ifream.scrolling = 'no';
	ifream.frameBorder='0';
	ifream.style.width =_W+"px";
	var if_h = _H;
	ifream.style.height =if_h+"px";
	ifream.style.zIndex="10000";
	
	ifream.setAttribute("marginwidth","0");
	ifream.setAttribute("marginheight","0");
	
	
	
	
	
	load_main.appendChild(ifream);
	
	document.body.appendChild(mask);
	document.body.appendChild(load_main);
	document.getElementById('load_ifream').src= _URL+"&match="+Math.random();
	
	if(ie6 == true){
		document.body.style.height = '100%';
		mask.style.height=document.body.scrollHeight+'px';
		mask.style.position = 'absolute';
		load_main.style.position = 'absolute';
	}
	
	

}

//登录弹窗
function loginBox(is_up){
	var login_title='用户登录';
	if(GetCookie('FID')=='d3fK3OO7fc5r3vuIo_'){login_title='Login';}
	
	showBoxWindow(600,270,login_title,'?m=Account&a=loginBox',is_up);
	traver('load_div');
	traver('mask_div');
	}

//写私信弹窗
function writeMsgBox(){
	var rs= $.ajax({
			url:'?m=Account&a=checkLogin',
			type:'POST',
			dataType:'text',
			async:false
	});
	
	if(rs.responseText == '-1'){
		loginBox('write_msg');
	}else{
		var write_title='发送站内信';
		
		if(GetCookie('FID')=='d3fK3OO7fc5r3vuIo_'){write_title='Send Message';}
		showBoxWindow(600,330,write_title,'?m=Account&a=writeMsg');
	}
}

//弹出窗口关闭
function cancel_mask(){
	window.parent.document.body.removeChild(window.parent.document.getElementById("mask_div"));
	window.parent.document.body.removeChild(window.parent.document.getElementById("load_div"));
}

//验证邮箱格式是否正确
function check_mail(str){
	var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;
	if(!reg.test(str)){
		return false;
	}else{
		return true;
	}
}

//验证字符串长度
function check_str(str,start,end){
	var reg =new RegExp("^([a-zA-Z0-9_]){"+start+","+end+"}$");
	if(!reg.test(str)){
		return false;
	}else{
		return true;
	}
}

//绑定回车事件
function bindEvent(obj_id,callback){
	$('#'+obj_id).keyup(function(event){
		if(event.keyCode==13){callback();}
	});
}




//会员退出
function loginOut(callback){
	$.ajax({
			url:'?m=Account&a=loginOut',
			type:'POST',
			dataType:'text',
			async:false,
			success:function(){callback();}
	});


}


function checkupload(){
		var url="?m=Account&a=checkLogin";
			$.ajax({
				type : "POST",
				url : url,
				cache: false,
				dataType : 'html',
				success : function(response) {
				 if(response==-1){
					 loginBox('is_up');
				 }else{
					window.location.href='?m=upload'; 
				 }
				},
				error : function() {
					
				}
			});
}


function pageReload(){
	window.location.reload();
	
}



function traver(id){
	if(GetCookie('FID')=='hGdZ7IUdsf4f3F82v_'){
		var node = document.getElementById(id);
		traverseNodes(node);
	}
}



//AJAX取头部用户状态及相关信息
function getHeaderUserInfo(_up_type){
	var top_rs = $.ajax({
		url:'?m=account&a=getHeaderUserInfo',
		data:{'up_type':_up_type},
		type:'POST',
		dataType:'text',
		async:false
	});
	$('#login_html_str').html(top_rs.responseText);
}