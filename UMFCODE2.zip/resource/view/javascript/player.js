 if (typeof(freeovpObject) == 'undefined') {
        var freeovpObject = {};
        freeovpObject.players = [];

        freeovpObject.isDomReady = function() {
          var d = document;
          if (d && d.getElementsByTagName && d.getElementById && d.body) {
            clearInterval(freeovpObject.domTimer);
            for(var i=0; i<freeovpObject.players.length; i++) {
              freeovpObject.writePlayer(i);
            }
            freeovpObject.domDone = true;
          }
        };

        freeovpObject.writePlayer = function(idx) {
        
          if (navigator.userAgent.match(/iP(od|hone|ad)/i)) {
           var source = freeovpObject.players[idx].source;
			

			var vidRexp = new RegExp();
            vidRexp.compile(/player.polyv.net\/videos\/([0-9a-zA-Z_-]*).swf/i);
			if (vidRexp.test(source)) {
				var results = vidRexp.exec(source);
				var vid=results[1];

				var urlstr="http://v.polyv.net/uc/video/getMp4?vid="+vid;
					
			 	var div1 = document.getElementById(freeovpObject.players[idx].container);
              	var vid = div1.ownerDocument.createElement("video");
                vid.src = urlstr;
                vid.controls = "controls";
                vid.width = freeovpObject.players[idx].width;
                vid.height = freeovpObject.players[idx].height;
                div1.parentNode.replaceChild(vid, div1);
			}

            
          } else {

            document.getElementById(freeovpObject.players[idx].container).innerHTML = freeovpObject.players[idx].getHtml() + '';
          }
        };

        freeovpObject.hasFlash = function () {
          var version = '0,0,0,0';
          try {
            try {
              var axo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash.6');
              try {
                axo.AllowScriptAccess = 'always';
              } catch (e) {
                version = '6,0,0';
              }
            } catch (e) {
            }
            version = new ActiveXObject('ShockwaveFlash.ShockwaveFlash').GetVariable('$' + 'version').replace(/\D+/g, ',').match(/^,?(.+),?$/)[1];
          } catch (e) {
            try {
              if (navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
                version = (navigator.plugins['Shockwave Flash 2.0'] ||
                navigator.plugins['Shockwave Flash']).description.replace(/\D+/g, ",").match(/^,?(.+),?$/)[1];
              }
            } catch (e) {
            }
          }
          var major = parseInt(version.split(',')[0], 10);
          var minor = parseInt(version.split(',')[2], 10);
          if (major > 9 || (major == 9 && minor > 97)) {
            return true;
          } else {
            return false;
          }
        };

        freeovpObject.swf = function (src,id,width,height,bgcolor) {
          if (!document.getElementById) { return; }
          this.source = src;
          this.id = id+'_swf';
          this.container = id+'_div';
          this.width = width;
          this.height = height;
          this.flashvars = {id:this.id};
          this.params = {
            'bgcolor':bgcolor,
            'allowfullscreen':'true',
            'allowscriptaccess':'always',
            'wmode':'opaque'
          };
          freeovpObject.players.push(this);
          if (freeovpObject.domDone && freeovpObject.hasFlash()) {
            var len = freeovpObject.players.length-1;
            setTimeout(function(){freeovpObject.writePlayer(len)},50);
          }
        };

        freeovpObject.swf.prototype = {
          getHtml:function() {
            var html = "";
            var fv = this.getVariables();
            if (navigator.plugins && navigator.mimeTypes && navigator.mimeTypes.length) {
              html = '<embed type="application/x-shockwave-flash" src="'+ this.source +'" width="'+ this.width +'" height="'+ this.height +'"';
              html += ' id="'+ this.id +'" name="'+ this.id +'" ';
              for(var key in this.params) {
                html += [key] +'="'+ this.params[key] +'" ';
              }
              html += 'flashvars="'+ fv +'" />';
            } else {
              html = '<object id="'+ this.id +'" name="'+ this.id +'" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="'+ this.width +'" height="'+ this.height +'">';
              html += '<param name="movie" value="'+ this.source +'" />';
              for(var key in this.params) {
                html += '<param name="'+ key +'" value="'+ this.params[key] +'" />';
              }
              html += '<param name="flashvars" value="'+ fv +'" />';
              html += "</object>";
            }
            return html;
          },
          addVariable: function(name,value) {
            this.flashvars[name] = encodeURIComponent(decodeURIComponent(value));
          },
          getVariables: function () {
            var pairs = new Array();
            for(var key in this.flashvars) {
              pairs[pairs.length] = key+"="+this.flashvars[key];
            }
            return pairs.join('&');
          }
        };
        if(freeovpObject.hasFlash() || navigator.userAgent.match(/iP(od|hone|ad)/i)) { freeovpObject.domTimer = setInterval(freeovpObject.isDomReady,50); }
      }