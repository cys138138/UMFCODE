/**
 * 比赛中心
 * Created by HuanLei on 13-11-8.
 */

//选项卡
function matchTab(){
    //$.Tab('.match_hd', '.match_bd', 'click');
    $.Tab('.notice_hd', '.notice_bd', 'click');
}

//赛事动态-折叠菜单
function noticeAccordion(){
    $('.notice_bd .list').each(function(){
        $(this).children('li:first').addClass('selected');
    });
    $('.notice_bd .list').on('mouseover', 'li', function(){
        $(this).addClass('selected').siblings('li').removeClass('selected');
    });
}


//参赛动态
function againSwitch(){
    var slider = $("#again");
    var list = slider.find(".list");
    var ul = list.find("ul");
    var prev = slider.find(".prev");
    var next = slider.find(".next");
    var li = ul.find("li");
    var timer = null;
    var i = 0;
    ul.width(li.eq(0).outerWidth(true) * li.length);
    var list_width = parseInt(list.width());
    var ul_width = parseInt(ul.width());
    var num = Math.floor(ul_width / list_width);

    if(num > 0){
        prev.addClass("enabled");
        next.addClass("enabled");
    }
    function switching(i){
        ul.animate({"left": -i * list_width + "px"}, "fast");
    }
    function autoplay(){
        i++;
        if(i > num){
            i = 0;
        }
        switching(i);
    }
    prev.click(function(){
        i--;
        if(i == -1){
            i = num;
        }
        switching(i);
    });
    next.click(function(){
        autoplay();
    });

    clearInterval(timer);
    timer = setInterval(autoplay, 2000);
    slider.mouseover(function(){
        clearInterval(timer);
    }).mouseout(function(){
        timer = setInterval(autoplay, 2000);
    });
}

//滚动
function profileMarquee(){
    var $list = $("#profile_list");
    var $ul = $list.find("ul");
    $ul.append($ul.html());
    var height = parseInt($ul.height());
    var timer = null;
    var i = 0;

    function marquee(){
        i--;
        if (-i >= height/2){
            i = 0;
        }
        $ul.css("top", i + "px");
    }
    timer = setInterval(marquee, 30);
    $list.on({
        mouseover: function(){
            clearInterval(timer);
        },
        mouseout: function(){
            timer = setInterval(marquee, 30);
        }
    });
}

$(function(){
    matchTab();             //选项卡
    noticeAccordion();      //赛事动态-折叠菜单
    againSwitch();          //参赛动态
    profileMarquee();      //滚动
});