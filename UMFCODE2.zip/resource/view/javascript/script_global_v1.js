 

(function(window, $){
	window.Tools = {
		stripHtml : function(string){
			return string.replace(/<[^>].*?>/g, '');
		}
	};
})(window, jQuery);
 
//选项卡插件
;(function($){
    $.extend({
        Tab: function(menu, cont, event){
            var menu = $(menu).children();
            var cont = $(cont).children();
            menu.first().addClass("cur");
            cont.hide().first().show();
            menu.on(event, function(){
                var index = menu.index(this);
                $(this).addClass("cur").siblings().removeClass("cur");
                cont.eq(index).show().siblings().hide();
            });
        }
    });
})(jQuery);



function time2FormatStr(seconds){
	seconds = parseInt(seconds);
	var hourse = Math.floor(seconds / 3600),
	minute = Math.floor((seconds - hourse * 3600) / 60),
	second = seconds - hourse * 3600 - minute * 60;

	if(hourse < 10){
		hourse = '0' + hourse;
	}
	if(minute < 10){
		minute = '0' + minute;
	}
	if(second < 10){
		second = '0' + second;
	}
	return hourse + ':' + minute + ':' + second
}

function time2Str(seconds){
	if(seconds < 1){
		return '';
	}else if(seconds >= 1 && seconds < 60){
		return parseInt(seconds) + '秒';
	}else if(seconds >= 60 && seconds < 3600){
		var s = Math.floor(seconds % 60);
		var m = Math.floor(seconds / 60);
		if(s){
			return m + '分钟' + s + '秒';
		}else{
			return m + '分钟';
		}
	}else{
		var n = seconds % 3600;
		var m = Math.floor(n / 60);
		var h = Math.floor(seconds / 3600);
		if(m){
			return h + '小时' + m + '分钟';
		}else{
			return h + '小时';
		}
	}
}

function transTime(timeStamp){
	var seconds = Math.floor(($.now()) / 1000) - timeStamp;
	if(seconds < 1) {
		return '刚刚';
	}
	if(seconds >= 1 && seconds < 60){
		return parseInt(seconds) + '秒前';
	}else if (seconds >= 60 && seconds < 3600){
		var minutes = Math.floor(seconds / 60);
		return minutes + '分钟前';
	}else if (seconds >= 3600 && seconds < 86400){
		var hour = Math.floor(seconds / 3600);
		return hour + '小时前';
	}else if (seconds >= 86400 && seconds < 172800){
		return '昨天';
	}else if (seconds >= 172800 && seconds < 259200){
		return '前天';
	}else{
		var manyDay = Math.floor(seconds / 86400);
		return manyDay + '天前';
	}
}

//input提示文字
function ResetFields(){
    $('[xid=place]').each(function() {
        if($(this).val()){
            $(this).prev('label').hide();
        };
        $(this).keydown(function(e) {
            if(e.keyCode != 9){
                $(this).prev('label').hide();
            }
        });
        $(this).keyup(function(){
           if($(this).val() == ''){
               $(this).prev('label').show();
           }
        });
    });
}

//头部下拉菜单
function headerMenu(){
    $('#toolbar_box li.item, #global_nav li.item').hover(function(){
        $(this).addClass('selected').find('.list').stop(true).slideDown(100);
    },function(){
        $(this).removeClass('selected').find('.list').stop(true).slideUp(100);
    });

    $('#msg_show_btn').click(function(){
        $('.msg_info').toggleClass('msg_info_show');
    });
    $('#msg_item').hover(function(){
        $('#msg_list').stop(true).slideDown(100);
		$(this).addClass('selected');
    },function(){
        $('#msg_list').stop(true).slideUp(100);
		$(this).removeClass('selected');
    });

}

//高亮导航菜单
function highlightMenu(menuKey){
	var oMenu = $('#global_nav [xid="m' + menuKey + '"]');
	if(!oMenu.length){
		return false;
	}

	oMenu.css({
		'font-weight' : 'bold'
	});
	oMenu.find('[xid="mA"]').css('color', '#F30');
}

//获得等级图标组
function getLevelIcons(level){
	var sunCount = Math.floor(level / 16);
	var moonCount = Math.floor((level - sunCount * 16) / 4);
	var starCount = level - sunCount * 16 - moonCount * 4;

	var aIcons = [], iconsHtml = '';
	for(var i = 0; i < sunCount; i++){
		aIcons.push('sun');
	}
	for(var i = 0; i < moonCount; i++){
		aIcons.push('moon');
	}
	for(var i = 0; i < starCount; i++){
		aIcons.push('star');
	}
	for(var i = 0; i < aIcons.length; i++){
		iconsHtml += '<img src="http://s.umfun.test/view/image/global/' + aIcons[i] + '.png" width="18" height="18" />';
	}
	return iconsHtml;
}



//头像图片加载失败方案2
function showHeadImg(imgObj,maxErrorNum){
    //showSpan.innerHTML += "--" + maxErrorNum;
    if(maxErrorNum>0){
        imgObj.onerror=function(){
            showHeadImg(imgObj,maxErrorNum-1);
        };
        setTimeout(function(){
            imgObj.src=imgObj.src + '?' + Math.random();
        },500);
    }else{
        imgObj.onerror=null;
        imgObj.src="http://s.umfun.test/view/image/global/head_error.png";
    }
}

//习题图片加载失败方案2
function showEsImg(imgObj,maxErrorNum){
    //showSpan.innerHTML += "--" + maxErrorNum;
    if(maxErrorNum>0){
        imgObj.onerror=function(){
            showEsImg(imgObj,maxErrorNum-1);
        };
        setTimeout(function(){
            imgObj.src=imgObj.src + '?' + Math.random();
        },500);
    }else{
        imgObj.onerror=null;
        imgObj.src="http://s.umfun.test/view/image/global/img_error.png";
    }
}


//侧边栏工具条
function sideTool(){
    var toolHtml = '\
        <div id="sidetool" class="sidetool">\
            <a class="feedback" href="http://service.umfun.com/feedback.html" target="_black">意见反馈</a>\
            <a class="gotop" href="#" title="回到顶部">^</a>\
        </div>\
    ';
    $('body').append(toolHtml);
    $(window).scroll(function(){
        if($(window).scrollTop() > 500){
            $("#sidetool .gotop").css('display', 'block');
        }else{
            $("#sidetool .gotop").css('display', 'none');
        }
    });
    $('.gotop').click(function(){
        $("html,body").animate({scrollTop: 0}, 'slow');
        return false;
    });
}





//签到
function checkin(){
    $('#checkin_active').click(function(){
        $('#checkin_user').slideToggle('fast');
        return false;
    });

    $.Tab('#checkin_tab', '#checkin_info', 'click');

    $('#checkin_close').click(function(){
        $('#checkin_user').slideUp('fast');
        return false;
    });
}

/**
 * JS辅助工具
 */
var JsTools = {
	/**
	 * 检测一个变量是否对象
	 */
	isObj : function(variable){
		return typeof(variable) == 'object' && Object.prototype.toString.call(variable).toLowerCase() == '[object object]' && !variable.length;
	},

	/**
	 * 合并两个数组或对象
	 */
	merge : function(obj1, obj2) {
		var oTmpObj1 = this.clone(obj1);
		if($.isArray(obj1) && $.isArray(obj2)){
			for(var i in obj2){
				if($.inArray(obj2[i], oTmpObj1) === -1){
					oTmpObj1.push(obj2[i]);
				}
			}
		}else if($.isPlainObject(obj1) && $.isPlainObject(obj2)){
			for(var key in obj2) {
				if(oTmpObj1.hasOwnProperty(key) || obj2.hasOwnProperty(key)){
					oTmpObj1[key] = obj2[key];
				}
			}
		}
		return this.clone(oTmpObj1);
	},

	/**
	 * 判断一个元素是否在数组内
	 * @param {type} value 元素值
	 * @param {type} array 数组
	 * @param {type} isStrict 是否严格模式
	 * @returns {Boolean}
	 */
	inArray : function(value, array, isStrict){
		for(var i in array){
			if(array[i] == value && !isStrict){
				return true;
			}else if(array[i] === value && isStrict){
				return true;
			}
		}
		return false;
	},

	/**
	 * 克隆一个数组或对象
	 */
	clone : function(oObj){
		if(oObj == null || typeof(oObj) !== 'object'){
			return oObj;
		}
		var oTempObj = new oObj.constructor();
		for(var key in oObj){
			oTempObj[key] = arguments.callee(oObj[key]);
		}
		return oTempObj;
	},

	shuffle : function(aArray){
		aArray.sort(function(key, value){
			return Math.random() > 0.5 ? -1 : 1;//用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
		});
		return aArray;
	}
};

/**
 * 封装的ajax
 * @param {type} aTmpOption ajax选项
 * @returns {undefined}
 */
function ajax(aTmpOption){
	var aOption = JsTools.clone(aTmpOption);
	if(!aOption.type){
		aOption.type = 'post';
	}

	if(!aOption.dataType){
		aOption.dataType = 'json';
	}

	if(!aOption.error){
		aOption.error = function(aRequest){
			UBox.show('抱歉，网络可能有点慢');
			if(aOption.afterError){
				aOption.afterError(aRequest);
			}
		};
	}

	aOption.success = function(aResult){
		var oAdvDialog = null;
		if(typeof(aResult.update) != 'undefined'){
			oAdvDialog = UAlert.show(aResult.update);
		}
		aTmpOption.success(aResult, oAdvDialog);
	};

	return $.ajax(aOption);
}



$(function(){
    ResetFields();          //input提示文字
    headerMenu();           //头部下拉菜单
    //sideTool();             //侧边栏工具条
    checkin();              //签到
});

