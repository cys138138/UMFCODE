function ClassSelector(wrapClassSelectId, dataUrl, addClassTextId){
	this.oWrapClassSelect = $('#' + wrapClassSelectId);
	this.oGrade = null;
	this.oClass = null;
	this.aData = null;
	this.dataUrl = dataUrl;
	this.oaddClassText = $('#' +addClassTextId);
	var self = this;

	this.load = function(schoolId){
		var self = this;
		$.ajax({
			type : 'post',
			url : this.dataUrl,
			data : 'schoolId=' + schoolId,
			success : function(result){
				self.aData = result.data;
				self.drawOption(self.aData);
				self.oaddClassText.css('display', 'none');
				self.oaddClassText.val('');
				$('#emClass').remove();
			}
		});

	};

	this.drawOption = function(result){
		self.oWrapClassSelect.html('<select id="gradeId" name="gradeId"></select>');
		var gradeOptionContent = '<option value="0">请选择</option>';
		for(var gradeKey in result){
			gradeOptionContent += '<option value="' + gradeKey + '">' + result[gradeKey].name + '</option>';
		}
		self.oGrade = $('#gradeId');
		self.oGrade.append(gradeOptionContent);

		self.oWrapClassSelect.append('<select id="classId" name="className"></select>');
		self.oClass = $('#classId');
		self.drawClassOption(self.oGrade.find('option:selected').val());

		self.oGrade.change(function(){
			self.drawClassOption($(this).val());

			self.oClass.change(function(){
				self.onchangeClass($(this).val());
			});
			self.oaddClassText.css('display', 'none');
			$('#emClass').remove();
		});
	};

	this.onchangeClass = function(className){
		if(className == 0){
			self.oaddClassText.css('display', 'inline');
			self.oaddClassText.after('<em id="emClass"> 班</em>');
		}else{
			self.oaddClassText.css('display', 'none');
			self.oaddClassText.val('');
			$('#emClass').remove();
		}
	}



	this.drawClassOption = function(grade){
		$('#classId').html('');
		var classOptionContent = '<option value="-1">请选择</option>';
		if(grade!=0){
			var aClassData = this.aData[grade];
			for(var i = 0; i < aClassData.child.length; i++){
				classOptionContent += '<option value="' + aClassData.child[i] + '">' + aClassData.child[i] + '</option>';
			}
			classOptionContent += '<option value="0">添加班级</option>';
		}
		$('#classId').append(classOptionContent);
	}




	this.getSelection = function(){
		var grade = self.oGrade.find('option:selected').val();
		var className = self.oClass.find('option:selected').val();
		return {grade : grade, classId : className};
	};

}



