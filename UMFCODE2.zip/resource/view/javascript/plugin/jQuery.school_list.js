(function(window, $){
	var self = null;
	window.SchoolList = function(wrapSchoolListId, sourceUrl, afterClickFunction){
		this.randCode = Math.floor(Math.random(10000, 99999) * 1000);	//随机生成一个编号
		self = this;	//储存自身指针
		this.oWrapSchoolList = $('#' + wrapSchoolListId);	//保存页面大框对象
		this.sourceUrl = sourceUrl;	//保存数据源地址

		this.afterClickFunction = afterClickFunction;
		this.aSchoolList = [];	//学校列表
		this.oSchoolListLi = null;	//学校jQuery DOM对象列表

		//初始化样式
		this.initStyle = function(){
			var cssCode = '\n\
	.schoolSelectorlList li{float:left; width:200px; font-size:14px; cursor:pointer; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; margin-right:6px; padding:5px;}';

			$('head').append('<style type="text/css">' + cssCode + '</style>');
		};

		//加载学校
		this.load = function(areaId){
			$.ajax({
				url : self.sourceUrl,
				data : 'areaId=' + areaId,
				type : 'post',
				success : function(result){
					if(result.status == 0){
						UBox.show(result.msg, 0);
						return;
					}
					var aSchoolList = self.aSchoolList = result.data;
					self.showSchoolList(aSchoolList);
				}
			});
		}

		/**
		 * 搜索学校,并返回学校数据集
		 */
		this.searchSchool = function(schoolName){
			var aSchoolListResult = [];
			if(schoolName.length == 0){
				aSchoolListResult = self.aSchoolList;
			}else{
				for(var i in self.aSchoolList){
					var aSchool = self.aSchoolList[i];
					if(aSchool.name.indexOf(schoolName) > -1){
						aSchoolListResult.push(aSchool);
					}
				}
			}
			return aSchoolListResult;
		}

		this.select = function(schoolId){
			self.oWrapSchoolList.find('#schoolSelectorLi' + schoolId).css('color', 'red');
		}

		this.schoolClickCallBack = function(){
			self.oSchoolListLi.css({"font-weight":"normal", "color":"#666", "background-color":"#f9f9f9"});
			$(this).css({"font-weight":"bold", "color":"#FFFFFF", "background-color":"#FF6600"});
			self.afterClickFunction($(this).val(), $(this).text());

		}

		this.showSchoolList = function(aSchoolList){
			self.oWrapSchoolList.html('<ul id="' + self.randCode + '" class="schoolSelectorlList"></ul>');
			var ulContent = '',
			oSchoolList = self.oWrapSchoolList.find('#' + self.randCode);	//得到UL对象
			for(var i in aSchoolList){
				ulContent += '<li xid="schoolSelectorLi" id="schoolSelectorLi' + aSchoolList[i].id + '" title="' + aSchoolList[i].name + '" value="' + aSchoolList[i].id + '">' + aSchoolList[i].name + '</li>';
			}
			oSchoolList.append(ulContent);

			//为每一个学校DOM对象绑定单击回调
			self.oSchoolListLi = oSchoolList.find('li[xid="schoolSelectorLi"]');
			self.oSchoolListLi.each(function(){
				this.onclick = self.schoolClickCallBack;
			});
		}
	}

})(window, jQuery);