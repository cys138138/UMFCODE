/**
 * Created by ZhaoHuanLei on 13-12-4.
 */

//PK列表
function pkTab(){
    //$.Tab('.core_hd .menu', '.core_bd', 'click');
    $.Tab('.rank_mod .menu', '.rank_mod .bd', 'click');
    $.Tab('.notice_mod .menu', '.notice_mod .bd', 'click');
    $.Tab('.object_item .menu', '.object_item .bd', 'click');
    $.Tab('.points_item .menu', '.points_item .bd', 'click');
}

//PK列表页面
function coreSwitch(){
    //鼠标划过头像显示名字
    $('.core_bd, .detailed_mod .compare, .pk_contrast_mod').on('mouseover', '.head', function(){
        $(this).find('.name').stop(true).animate({'bottom': '0'}, 'fast');
    }).on('mouseout', '.head', function(){
            $(this).find('.name').animate({'bottom': '-22px'}, 'fast');
    });
    //点击显示更多筛选
    $('#pk_more_show').click(function(){
        var menu = $(this).parent();
        menu.slideUp('fast');
        $('#pk_more_hide').click(function(){
            menu.slideDown('fast');
        });
    });
    //发起PK-选择类型
    $('.create_mod').on('mouseover', function(){
        $(this).find('.list').stop(true).slideDown();
    }).on('mouseout', function(){
        $(this).find('.list').stop(true).slideUp();
    });
}

//发起PK
function pointsFilter(){
    var objectBtn = $('#carte_obj');
    var pointsBtn = $('#carte_points');
    var filterItem = $('.filter_item');
    var objectItem = $('.object_item');
    var pointsItem = $('.points_item');
    objectBtn.on('click', function(){
        filterItem.after(objectItem);
        $(this).addClass('join_btn').removeClass('receive_btn')
            .siblings().removeClass('join_btn').addClass('receive_btn');
    });
    pointsBtn.on('click', function(){
        filterItem.after(pointsItem);
        $(this).addClass('join_btn').removeClass('receive_btn')
            .siblings().removeClass('join_btn').addClass('receive_btn');
    });
}


//显示题目
function showEsList() {
    var viewdetails = $('#viewdetails');
    var subject = $('.compare .subject');
    viewdetails.click(function(){
        if (subject.is(':visible')) {
            subject.slideUp();
            $(this).html('查看详细');
			$("html,body").animate({scrollTop: 0}, 'slow');
        } else {
            subject.slideDown();
            $(this).html('收起详细');
			$("html,body").animate({scrollTop: 800}, 'slow');
        }
    });
}

$(function(){
    pkTab();                //PK-选项卡
    coreSwitch();           //PK列表页面
    pointsFilter();         //发起PK
    showEsList();			//显示题目
});

