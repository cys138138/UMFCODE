//表单提交
function SubmitById(id){obj=document.getElementById(id);obj.submit();}
//表单重置
function ResetById(id){obj=document.getElementById(id);obj.reset();}