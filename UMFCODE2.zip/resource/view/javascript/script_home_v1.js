
//input提示文字
function resetFields(){
    $('#loginbox input, #agents_login_form input, #help_search input').each(function() {
        if($(this).val()){
            $(this).prev('label').hide();
        };
        $(this).keydown(function() {
           $(this).prev('label').hide();
        });
        $(this).keyup(function(){
           if($(this).val() == ''){
               $(this).prev('label').show();
           }
        });
    });
}


//用户反馈类型选中
function feedbackType(){
    $('#feedback_type > li:not(#morequestions)').click(function(){
        $(this).toggleClass('selected').siblings().removeClass('selected');
    });
    $('#morequestions').mouseover(function(){
        $(this).find('ul').show();
        $(this).toggleClass('morequestions_cur');
    });
    $('#morequestions').mouseout(function(){
        $(this).find('ul').hide();
    });
    $('#morequestions li a').click(function(){
        $('#morequestions > a').html($(this).html());
        $('#feedback_type > li').removeClass('selected');
        $('#morequestions').addClass('selected');
        $(this).parent().parent().hide();
    });
}

//TAB选项卡插件
;(function($){
    $.Tab = function(tabMenu,tabContent,event) {
        $(tabContent).children("li").hide();
        $(tabMenu).children("li:first").addClass("cur").show();
        $(tabContent).children("li:first").show();

        $(tabMenu).children("li").bind(event,function(){
            $(this).addClass("cur").siblings("li").removeClass("cur");
            var activeindex = $(tabMenu).children("li").index(this);
            $(tabContent).children().eq(activeindex).show().siblings().hide();
            return false;
        });
    };
})(jQuery);

function payCenter(){
    $.Tab("#pay_select","#pay_panel","click");   //充值中心选项卡
    //$.Tab("#pay_record_menu","#pay_record_info","click");   //充值记录选项卡
    $.Tab("#pay_type_select","#pay_type_panel","click");    //充值类型
    $('#pay_record_info tr:even').addClass('pay_record_even');  //隔行换色
}

//帮助中心菜单
function helpMenu(){
    $('#help_menu dd').hide();
    $('#help_menu dd:first').show();
    $('#help_menu dt:first').addClass('help_menu_cur');
    $('#help_menu dt').click(function(){
        $(this).toggleClass('help_menu_cur');
        $(this).next().slideToggle();
    });
}

//代理商
function agentsInfoShow(){
    $('#agents_info_mod').hide();
    $('#agents_info_btn').click(function(){
        $('#agents_info_mod').slideToggle();
        $(this).toggleClass('agents_info_btn_show');
		return false;
    });
}


//绑定回车事件
function bindEvent(objId,callback){
	$('#'+objId).keyup(function(event){
		if(event.keyCode==13){
			try{
				if(callback && typeof(eval(callback)) == 'function'){
					eval(callback)();
				}
			}catch(e){

			}
		}
	});
}

//注册-模拟select
function selectMenu(){
    $('[xid=select_active]').click(function(){
        $(this).next().toggle().parent().siblings('.selectbox').find('[xid=select_options]').hide();
        return false;
    });
    $('[xid=select_options] li').hover(function(){
        $(this).toggleClass('on')
    });
    $('[xid=select_options] li').click(function(event){
		$('#month').val($(this).attr('value'));
		$('#payFee').html($(this).attr('value') * 75 + '.00');
        $(this).parent().parent().prev().children('span').html($(this).html());
        $(this).parent().parent().hide();
    });
    $(document).click(function(){
        $('[xid=select_options]').hide();
    });
}

//注册-学校选择
function schoolSelect(){
    $('#school_select > li ').hover(function(){
        $(this).toggleClass('on');
    });
    $('#school_select > li').click(function(){
        $(this).addClass('selected').siblings().removeClass('selected');
    });
}

//注册-关卡选择
function pointsSelect(){
    $('#points_select_box li ').hover(function(){
        $(this).toggleClass('on');
    });
    $('#points_select_box li').click(function(){
        $(this).addClass('selected').siblings().removeClass('selected');
    });
}



//充值-弹窗
function payPop(){
    $('#test_btn').click(function(){
        $('#mask').height($('body').height()).show();
        $('#pay_pop').show();
    });
    $('#pay_pop_close').click(function(){
        $('#mask').hide();
        $('#pay_pop').hide();
    });
}



$(function(){
    resetFields();      //input提示文字
    feedbackType();     //用户反馈类型选中
    payCenter();        //充值中心
    helpMenu();         //帮助中心菜单
    agentsInfoShow();   //代理商
    selectMenu();       //select
    schoolSelect();     //学校选择
    pointsSelect();     //关卡选择
    payPop();           //充值-弹窗
});
