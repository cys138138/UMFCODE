
/**
 * 选项卡插件
 * $.Tab('菜单', '内容', '事件');
 */
;(function($){
    $.extend({
        Tab: function(menu, cont, event) {
            var menu = $(menu).children();
            var cont = $(cont).children();
            menu.first().addClass("cur");
            cont.hide().first().css('display', 'block');
            menu.on(event, function(){
                var index = menu.index(this);
                $(this).addClass("cur").siblings().removeClass("cur");
                cont.eq(index).css('display', 'block').siblings().hide();
            });
        }
    });
})(jQuery);

// 定死class，不定结构

/**
 * 输入框占位符
 * $("#search").placeholder();
 * $("input, textarea").placeholder();
 */
;(function($){
    $.fn.extend({
        placeholder: function() {
            if ("placeholder" in document.createElement("input")) return;
            $(this).each(function() {
                var self = $(this);
                var place = self.attr("placeholder");
                var color = self.css("color");
                if (!place) return;
                self.val(place).css("color", "#aaa");
                self.on({
                    focus: function() {
                        if (self.val() == place) {
                            self.val("");
                        }
                        self.css("color", color);
                    },
                    blur: function() {
                        if (self.val() == "") {
                            self.val(place).css("color", "#aaa");
                        }
                    }
                });
            });
        }
    });
})(jQuery);




/**
 * JS辅助工具
 */
var JsTools = {
    /**
     * 检测一个变量是否对象
     */
    isObject : function(variable){
        return typeof(variable) == 'object' && Object.prototype.toString.call(variable).toLowerCase() == '[object object]' && !variable.length;
    },

    /**
     * 合并两个数组或对象
     */
    merge : function(obj1, obj2) {
        var oTmpObj1 = this.clone(obj1);
        if($.isArray(obj1) && $.isArray(obj2)){
            for(var i in obj2){
                if($.inArray(obj2[i], oTmpObj1) === -1){
                    oTmpObj1.push(obj2[i]);
                }
            }
        }else if($.isPlainObject(obj1) && $.isPlainObject(obj2)){
            for(var key in obj2) {
                if(oTmpObj1.hasOwnProperty(key) || obj2.hasOwnProperty(key)){
                    oTmpObj1[key] = obj2[key];
                }
            }
        }
        return this.clone(oTmpObj1);
    },

    /**
     * 判断一个元素是否在数组内
     * @param {type} value 元素值
     * @param {type} array 数组
     * @param {type} isStrict 是否严格模式
     * @returns {Boolean}
     */
    inArray : function(value, array, isStrict){
        for(var i in array){
            if(array[i] == value && !isStrict){
                return true;
            }else if(array[i] === value && isStrict){
                return true;
            }
        }
        return false;
    },

    /**
     * 克隆一个数组或对象
     */
    clone : function(oObj){
        if(oObj == null || typeof(oObj) !== 'object'){
            return oObj;
        }
        var oTempObj = new oObj.constructor();
        for(var key in oObj){
            oTempObj[key] = arguments.callee(oObj[key]);
        }
        return oTempObj;
    },

    shuffle : function(aArray){
        aArray.sort(function(key, value){
            return Math.random() > 0.5 ? -1 : 1;//用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
        });
        return aArray;
    }
};

/**
 * 封装的ajax
 * @param {type} aTmpOption ajax选项
 * @returns {undefined}
 */
function ajax(aTmpOption){
	var aOption = JsTools.clone(aTmpOption);
	if(!aOption.type){
		aOption.type = 'post';
	}

	if(aOption.type == 'post' && (!aOption.data || JsTools.isObject(aOption.data))){
		if(!aOption.data){
			aOption.data = {};
		}
		aOption.data._csrf = $('meta[name="csrf-token"]').attr('content');
	}

	if(!aOption.dataType){
		aOption.dataType = 'json';
	}

	if(!aOption.error){
		aOption.error = function(aRequest){
			UBox.show('抱歉，网络可能有点慢');
			if(aOption.afterError){
				aOption.afterError(aRequest);
			}
		};
	}

	aOption.complete = function(oXhr){
		//自带的请求完成回调
		if(oXhr.status >= 300 && oXhr.status < 400 && oXhr.status != 304){
			var redirectUrl = oXhr.getResponseHeader('X-Redirect');
			if(oXhr.responseText){
				if(window.UBox){
					UBox.show(oXhr.responseText, 0, redirectUrl);
				}else{
					alert(oXhr.responseText);
					location.href = redirectUrl;
				}
			}else{
				location.href = redirectUrl;
			}
		}
		aTmpOption.complete && aTmpOption.complete(oXhr);
	};

	aOption.success = function(aResult){
		var oAdvDialog = null;
		if(aResult.status == 403){
			//重新登陆
			UBox.show(aResult.msg, 0, aResult.data, 5);
			return;
		}else if(typeof(aResult.update) != 'undefined'){
			oAdvDialog = UAlert.show(aResult.update);
		}
		if(typeof(aResult.notice) != 'undefined'){
			if(typeof(aResult.notice.tips_vip_activation) != 'undefined'){
				Ui1.buildVipNotice('开通会员', aResult.notice.tips_vip_activation, function(){
					var aDomainInfo = document.domain.split('.');
					aDomainInfo.shift();
					window.location.href = 'http://vip.' + aDomainInfo.join('.');
				}, function(){});
			}
		}
		aTmpOption.success(aResult, oAdvDialog);
	};

	return $.ajax(aOption);
}



/**
 * +1 提示盒子
 *  $('#btn').click(function() {
            $(this).tipsbox({
                str: '+20',
                interval: 400,
                style: 'font-weight:bold;font-family:arial;',
                callback: function() {
                    //alert("fuck");
                }
            });
        });
 */
;(function($){
    $.fn.extend({
        tipsbox: function(options) {
            options = $.extend({
                str: "+1",  //要显示的内容
                startSize: "14px",  //动画开始的文字大小
                endSize: "40px",    //动画结束文字大小
                interval: 500,  //动画执行的时间
                color: "red",   //文字颜色
                style: "",  //其他样式设置，如果除了颜色和字体大小还想设置其他样式,如：style: 'font-weight:bold;font-family:arial;',
                callback: function() {} //回调函数
            }, options);

            $("body").append("<span class='tips_box' style='"+ options.style +"'>"+ options.str +"</span>");
            var box = $(".tips_box");
            var self = $(this);
            var top = self.offset().top;
            var left = self.offset().left + self.width() / 2 - box.width() / 2;
            box.css({
                "position": "absolute",
                "top": top,
                "left": left,
                "font-size": options.startSize,
                "color": options.color
            });
            box.animate({
                "top": top - self.height() / 2,
                "opacity": 0,
                "font-size": options.endSize
            }, options.interval, function() {
                box.remove();
                options.callback();
            });
        }
    });
})(jQuery);



/**
 * 共用头部
 */
function globalHeader() {
    $('#set').hover(function() {
        $(this).addClass('cur').find('ul').stop(true).slideDown(100);
    }, function() {
        $(this).removeClass('cur').find('ul').stop(true).slideUp(100);
    });
    $('#search input').placeholder();
}



//高亮导航菜单
function highlightMenu(menuKey){
	$('#tools li').each(function(){
		$(this).removeClass('cur');
	});
	var oMenu = $('#tools [xid="m' + menuKey + '"]');
	if(!oMenu.length){
		return false;
	}
	oMenu.addClass('cur');
}

//获得等级图标组
function getLevelIcons(level){
	var sunCount = Math.floor(level / 16);
	var moonCount = Math.floor((level - sunCount * 16) / 4);
	var starCount = level - sunCount * 16 - moonCount * 4;

	var aIcons = [], iconsHtml = '';
	for(var i = 0; i < sunCount; i++){
		aIcons.push('sun');
	}
	for(var i = 0; i < moonCount; i++){
		aIcons.push('moon');
	}
	for(var i = 0; i < starCount; i++){
		aIcons.push('star');
	}
	for(var i = 0; i < aIcons.length; i++){
		iconsHtml += '<img src="http://s.' + DOMAIN + '/view/image/global/' + aIcons[i] + '.png" width="18" height="18" />';
	}
	return iconsHtml;
}

function time2FormatStr(seconds){
	seconds = parseInt(seconds);
	var hourse = Math.floor(seconds / 3600),
	minute = Math.floor((seconds - hourse * 3600) / 60),
	second = seconds - hourse * 3600 - minute * 60;

	if(hourse < 10){
		hourse = '0' + hourse;
	}
	if(minute < 10){
		minute = '0' + minute;
	}
	if(second < 10){
		second = '0' + second;
	}
	return hourse + ':' + minute + ':' + second
}

function time2Str(seconds){
	if(seconds < 1){
		return '';
	}else if(seconds >= 1 && seconds < 60){
		return parseInt(seconds) + '秒';
	}else if(seconds >= 60 && seconds < 3600){
		var s = Math.floor(seconds % 60);
		var m = Math.floor(seconds / 60);
		if(s){
			return m + '分钟' + s + '秒';
		}else{
			return m + '分钟';
		}
	}else{
		var n = seconds % 3600;
		var m = Math.floor(n / 60);
		var h = Math.floor(seconds / 3600);
		if(m){
			return h + '小时' + m + '分钟';
		}else{
			return h + '小时';
		}
	}
}

function transTime(timeStamp){
	var seconds = Math.floor(($.now()) / 1000) - timeStamp;
	if(seconds < 1) {
		return '刚刚';
	}
	if(seconds >= 1 && seconds < 60){
		return parseInt(seconds) + '秒前';
	}else if (seconds >= 60 && seconds < 3600){
		var minutes = Math.floor(seconds / 60);
		return minutes + '分钟前';
	}else if (seconds >= 3600 && seconds < 86400){
		var hour = Math.floor(seconds / 3600);
		return hour + '小时前';
	}else if (seconds >= 86400 && seconds < 172800){
		return '昨天';
	}else if (seconds >= 172800 && seconds < 259200){
		return '前天';
	}else{
		var manyDay = Math.floor(seconds / 86400);
		if(isNaN(manyDay)){
			return '';
		}

		if(manyDay < 30){
			return manyDay + '天前';
		}else if(manyDay > 30 && manyDay < 180){
			return Math.floor(manyDay / 30) + '个月前';
		}else if(manyDay > 180 && manyDay < 365){
			return '半年前';
		}

		return '很久以前';
	}
}


//滚动插件
;(function($) {
    $.fn.extend({

        //单行滚动
        marquee: function() {
            var box = $(this);
            var list = box.find('ul');
            var height = list.find('li').eq(0).height();
            var timer = null;
            var i = 0;
            var len = list.find('li').length;

            function auto(){
                i++;
                if (i == len) {
                    i = 0;
                    list.css({'top': '0'});
                }
                list.animate({'top': -i * height});
            }
            timer = setInterval(auto, 4000);

            box.hover(function() {
                clearInterval(timer);
            }, function() {
                timer = setInterval(auto, 4000);
            });

        },

        //多行滚动
        marqueeMulti: function() {
            var box = $(this);
            var height = box.height();
            var top = box.offset();
            var parentHeight = box.parent().height();
            if (height < parentHeight) return;
            box.append(box.html());
            var i = 0;
            function auto(){
                i--;
                if(-i >= height){
                    i = 0;
                }
                box.css('top', i + 'px');
            }
            var timer = setInterval(auto, 50);
            box.on({
                mouseover: function(){
                    clearInterval(timer);
                },
                mouseout: function(){
                    timer = setInterval(auto, 50);
                }
            });
        }

    });
})(jQuery);




//计算闯关得分星级的星星个数
function getMissionScoreLevel(score){
	if(score < 5600){
		return 0;
	}
	var starPoin = 0;
	for(var i = 5; i >= 1; i--){
		starPoin = 5600 + (i - 1) * 1000;
		if(score >= starPoin){
			return i;
		}
	}
	return 0;
}

/**
 * 生成格式化日期
 * @param {type} format 格式描述,与PHP的date函数参数用法完全一致,大部分参数支持
 * @param {type} timestamp 格式化参照的时间戳,不传则默认为当前时刻的时间戳
 */
function date(format, timestamp){
	//实例化日期对象
	var jsdate=((timestamp) ? new Date(timestamp*1000) : new Date());

	//补零
	var pad = function(data, len){
		if((data += '').length < len){
			//计算要补多少个零
			len = len - data.length;
			var str =  '0000';
			return data = str.substr(0,len) + data;
		}else{
			return data;
		}
	}
	var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

	//计算一年中的第几天
	var inYearDay = function(){
		var aDay = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
		var day = jsdate.getDate();
		var month = jsdate.getMonth();
		var year = jsdate.getFullYear();
		$reDay = 0;
		for(var i = 0;i < month;i++){
			$reDay += aDay[i];
		}
		$reDay += day;
		//计算闰年
		if(month>1 && (year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
			$reDay += 1;
		}
		return $reDay;
	};

	var fm = {
		//天
		j : function(){return jsdate.getDate();},
		d : function(){return pad(fm.j(), 2);},
		w : function(){return jsdate.getDay();},
		l : function(){return weekdays[fm.w()];},
		D: function(){return fm.l().substr(0,3);},
		N : function(){return fm.w() + 1;},
		z : function(){return inYearDay();},

		//月
		n : function(){return jsdate.getMonth() + 1;},
		m : function(){return pad(fm.n(), 2);},
		t : function(){
            var n;
            if( (n = jsdate.getMonth() + 1) == 2 ){
                return 28 + fm.L();
            } else{
                if( n & 1 && n < 8 || !(n & 1) && n > 7 ){
                    return 31;
                } else{
                    return 30;
                }
            }
        },

		//年
		Y : function(){return jsdate.getFullYear();},
        y : function(){return (jsdate.getFullYear() + "").slice(2);},
		L : function(){var y = fm.Y();return (!(y & 3) && (y % 1e2 || !(y % 4e2))) ? 1 : 0;},

		//秒
		s : function(){return pad(jsdate.getSeconds(), 2);},

		//分
		i : function(){return pad(jsdate.getMinutes(), 2);},

		//时
		H : function(){return pad(jsdate.getHours(), 2);},
		g : function(){return jsdate.getHours() % 12 || 12;},

		//am或pm
		a : function(){return jsdate.getHours() > 11 ? 'pm' : 'am';},

		//AM或PM
		A : function(){return fm.a().toUpperCase();},

		//周
		W : function(){
            var a = fm.z(), b = 364 + fm.L() - a;
            var nd2, nd = (new Date(jsdate.getFullYear() + '/1/1').getDay() || 7) - 1;
            if(b <= 2 && ((jsdate.getDay() || 7) - 1) <= 2 - b){
                return 1;
            } else{
                if(a <= 2 && nd >= 4 && a >= (6 - nd)){
                    nd2 = new Date(jsdate.getFullYear() - 1 + '/12/31');
                    return date("W", Math.round(nd2.getTime()/1000));
                } else{
                    return (1 + (nd <= 3 ? ((a + nd) / 7) : (a - (7 - nd)) / 7) >> 0);
                }
            }
        }

	};

	//分析format
	return format.replace(/[\\]?([a-zA-Z])/g, function(rekey1, rekey2){
		var result = '';
        if(rekey1 != rekey2){
            result = rekey2;
        }else if(fm[rekey2]){
            result = fm[rekey2]();
        }else{
            result = rekey2;
        }
        return result;
    });
}


//去掉iframe滚动条并显示全部内容
function SetCwinHeight(iframeObj){
    if (document.getElementById){
        if (iframeObj && !window.opera){
            if (iframeObj.contentDocument && iframeObj.contentDocument.body.offsetHeight){
                iframeObj.height = iframeObj.contentDocument.body.offsetHeight;
            }else if(document.frames[iframeObj.name].document && document.frames[iframeObj.name].document.body.scrollHeight){
                iframeObj.height = document.frames[iframeObj.name].document.body.scrollHeight;
            }
        }
    }
}

//皮肤更新提示
function skinUpdateTips(newSkinTime){
    var skinTips = $('<div class="skin_tips"><a class="close" href="javascript:;" title="关闭"></a></div>').appendTo('body');
    var close = skinTips.find('a');
    close.click(function() {
        skinTips.fadeOut(function(){
            skinTips.remove();
			$.cookie('new_skin_time', newSkinTime, {expires : 605000});
        });
    });
	$('.skin_btn').click(function() {
		$('.skin_tips .close').trigger('click');
	});
}



//道具购物车切换
function cartSwitch(){
    var slider = $(".props_total .cart, .props_tool");
    var list = slider.find(".list");
    var ul = list.find("ul");
    var prev = slider.find(".prev");
    var next = slider.find(".next");
    var li = ul.find("li");
    var i = 0;
    ul.width(li.eq(0).outerWidth(true) * li.length);
    var list_width = parseInt(list.width());
    var ul_width = parseInt(ul.width());
    var num = Math.ceil(ul_width / list_width);

    function switching(i){
        ul.animate({"left": -i * list_width + "px"}, "fast");
    }
    prev.click(function(){
        if(i > 0){
            i--;
        } else {
            return false;
        }
        switching(i);
    });
    next.click(function(){
        if(i < num-1){
            i++;
        } else {
            return false;
        }
        switching(i);
    });
}

//模拟Select下拉菜单
;(function($) {
    $.fn.extend({
        dropdown : function() {
            $(this).each(function() {
                var self = $(this);
                var act = self.children("a");
                var para = self.children("p");
                var links = para.find("a");
                self.addClass("dropdown");
                links.filter(":contains("+ act.text() +")").hide();
                self.on("click", function() {
                    para.toggle();
                    self.toggleClass("open");
                    links.on("click", function() {
                        var _this = $(this);
                        act.text(_this.text());
                        _this.hide().siblings().show();
                    });
                    return false;
                });
                $(document).on("click", function() {
                    para.hide();
                    self.removeClass("open");
                });
            });
        }
    });
})(jQuery);

//幻灯片
;(function($) {
    $.fn.extend({
        mySlide: function() {
            var box = $(this);
            var list = box.find('ul');
            var items = list.find('li');
            var len = items.length;
            if (len < 2) return;
            var width = box.width();
            list.width(width * len);
            box.append('<div class="dot"></div>');
            var dot = box.find('.dot');
            var active = '';
            var i = 0;
            var timer = null;

            box.addClass("my_slide");
            items.each(function() {
                active += '<a>&bull;</a>';
            });
            dot.append(active);
            var links = dot.find('a');
            function photoSwitch(i) {
                links.eq(i).addClass('cur').siblings().removeClass('cur');
                list.animate({'left' : -width * i});
            }
            photoSwitch(i);
            links.on('mouseover', function() {
                i = links.index(this);
                photoSwitch(i);
            });
            function auto() {
                i++;
                if (i > len-1) {
                    i = 0;
                }
                photoSwitch(i);
            }
            timer = setInterval(auto, 3000);
            box.on({
                mouseover: function(){
                    clearInterval(timer);
                },
                mouseout: function(){
                    timer = setInterval(auto, 3000);
                }
            });
        }
    });
})(jQuery);


//dropdown下拉菜单调用
function optionsDropdown() {
    $('.pk_mod .filter .options').dropdown();
}

function arrRemove(arr, val){
	for(var i = 0,n = 0;i < arr.length; i++){
		if(arr[i] != val){
			arr[n++] = arr[i];
		}
	}
	arr.length -= 1;
	return arr;
}

// sideTool
function sideTool(Parent){
    $(window).resize(function(){
        $(Parent).get(0).style.right = (document.documentElement.clientWidth - 1000) / 2 - 80 +'px';
    });
}

//首页check_list鼠标悬停文字
function checkListHover(){
    $('#checkList').find('li').hover(function(){
        $(this).find('.lay').stop().animate({'top': '0px'},'fast');
    },function(){
        $(this).find('.lay').stop().animate({'top': '100%'},'fast');
    });
}

(function($){
    $.extend({
        TabNew: function(menu, cont, event, sclass) {
            var menu = $(menu).children();
            var cont = $(cont).children();
            menu.first().addClass(sclass);
            cont.hide().first().css('display', 'block');
            menu.on(event, function(){
                var index = menu.index(this);
                $(this).addClass(sclass).siblings().removeClass(sclass);
                cont.eq(index).css('display', 'block').siblings().hide();
            });
        }
    });
})(jQuery);

//函数：carousel_a(outdiv,innerdiv,gutter,item)
//outdiv   : 外框div
//innerdiv ：要滚动的ul
//gutter   ：li之间的间隙
//item     ：有多少个li元素
//效果     : carousel_a会切换一整屏元素，到达第二页，到达尾页后，自动回滚到第一页，反之如是
function carousel_a(outdiv,innerdiv,gutter,item){
    var page = 1;//初始化page
    var perPage = item;//每版面LI的个数
    var giftUl = $(innerdiv);
    var giftLi = $(innerdiv).find('li');
    var giftLiNum = $(innerdiv).find('li').length;
    var giftUlWidth = giftLiNum * (giftLi.width()+gutter);

    var pageNumber = Math.ceil(giftLiNum/perPage);//有多少个版面

    var giftPrev = $(outdiv).find('.prev')
    var giftNext = $(outdiv).find('.next')
    $(innerdiv).width(giftUlWidth);

    giftNext.on('click',function(event){

        if(giftUl.is(':animated')){
            return false;
        }else if(page == pageNumber)
        {
            giftUl.animate({ left : '0px' },'fast')
            page = 1;
        }
        else{
        giftUl.animate({
            left : '-=' + ((giftLi.width() + gutter)*item)
        },'slow');
			page++;
        }

        return false;
    });

    giftPrev.on('click',function(event){
        if(giftUl.is(':animated')){
            return false;
        }else if(page == 1)
        {
            giftUl.animate({ left : ((giftLi.width() + gutter)*item)*(pageNumber-1)*-1 },'fast');
            page = pageNumber;
        }
        else{
        giftUl.animate({
            left : '+=' + ((giftLi.width() + gutter)*item)
        },'slow');
        page--;
        }

        return false;
    })
}

//hover遮罩
//结构target定位在li上，无滑动效果，只会出现
function hoverMask(outId,target,clickHide){
    $(target).hide();
    $(outId).find('li').each(function(){
        $(this).hover(function(){
         $(this).find(target).show();
    },function(){
        $(this).find(target).hide();
        });
    if(clickHide){
        $(this).click(function(){
            $(this).hide(400);
        });
    }
    });

}

//弹窗操作函数
//modFate(outDiv,close,mask)
//outDiv : 弹窗包裹seclect
//close : 关闭按钮seclect
//mask : 遮罩seclect
//用法 : modFate('#vipPackagePop','#vipPackagePop .close','#mask');
function modFate(outDiv,close,mask){
    var $dislog = $(outDiv);
    var $close = $(close);
    var $mask = $(mask);

    $dislog.fadeIn();
    $mask.height($(document).height()).fadeIn();
    $close.click(function(){
        $dislog.fadeOut(function(){
            $mask.height($(document).height()).hide();
        });
    });
}

function getVipName(name, vip){
	if(vip == 0){
		return name;
	}else if(vip == 1){
		return  '<span style="color:#F00">' + name + '</span>';
	}else if(vip == 2 || vip == 3){
		return  '<span style="color:#F8A501">' + name + '</span>';
	}
	return name;
}

function activityTeacher(){
    var $activityImg = $('#activityTeacher').find('.activity_img');
    var $stopAnimate = $('[stop-animate]');
    var activityCountVal = 5000; //切换时间
    var animateTime = 300;
    var count = 0;
    var timer = '';

    $('#activityTeacher').height('80');

    if($stopAnimate.length){
        clearInterval(timer);
        return;
    }

    $activityImg.each(function(index,value){
        $(this).attr('index-fix', index).hide();
    });

    $('[index-fix="0"]').show();

    var _auto = function(){
        count++;
        if(count>=$activityImg.length){
            count = 0;
        }

        $activityImg.fadeOut('fast');

        $activityImg.each(function(index,value){
            if(parseInt($(this).attr('index-fix')) == count){
                $(this).fadeIn(animateTime);

            }
        });
    };

    clearInterval(timer);

    timer = setInterval(function(){

        _auto();

    },activityCountVal);

    $('#activityTeacher').on({
        mouseover : function(){
            clearInterval(timer);
        },

        mouseout : function(){
            timer = setInterval(_auto, activityCountVal);
        }
    });
}

	function h(o) {
		var $o = $(o);
		var imgUrl = $o.attr('real');
		$('<img src="' + imgUrl + '">').appendTo('body').hide().load(function() {
			$o.attr('onload', '').attr('src', imgUrl).attr('real', '');
			$(this).remove();
		});
	}

$(function() {
    globalHeader();       	//共用头部
	cartSwitch();			//道具购物车切换
	optionsDropdown();		//dropdown下拉菜单调用
    checkListHover();       //首页check_list鼠标悬停文字
    activityTeacher()       //广告栏自动切换
});