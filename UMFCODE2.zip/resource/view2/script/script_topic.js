function topic_down(){
    $('.group_sort').each(function(){
        var _this = this;
        $(_this).click(function(){
            $('.sub_group_sort').fadeOut();
            $(_this).find('.sub_group_sort').fadeIn('fast')
            return false;
        });
    });
    $('.sub_group_sort a').click(function(){
        return false;
    })
    $(document).click(function(){
        $('.sub_group_sort').fadeOut();
    })
}

// 回到顶部
function goto_top(){}
goto_top.prototype  = {
    init:function(){
        var self    = this;
        self.scrolltop2_click();
        self.scrolltop2_mousemove();
        
        $(window).scroll(function(){
            // dh   = $(document).height();// 页面总高度
            wh  = $(window).height();  // 页面可视高度
            wh2 = wh/2;
            st  = $(document).scrollTop();
            if(st>(wh2)){
                self.show_scrolltop();
            }else{
                self.hide_scrolltop();
            }
            
        });
    
        // dh   = $(document).height();
        // wh   = $(window).height();
        // st   = $1.__scrolltop();
    },
    show_scrolltop:function(){
        obj     = $('#scrolltop2');
        offset  = $('.tp_main_warp,.tp_new_warp').offset();
        scroll_left     = offset.left+1080;
        
        if(obj.length>0){
            obj.show();
            obj.css('left',scroll_left+'px');
        }else{
            html    = '<div id="scrolltop2" style="left:'+scroll_left+'px;"> </div>';
            $("body").append(html);
        }
        
    },
    hide_scrolltop:function(){
        $('#scrolltop2').hide();
    },
    scrolltop2_click:function(){
        $('#scrolltop2').on('click', function(){
            window.scrollTo('0','0');
        });
    },
    scrolltop2_mousemove:function(){
        $('#scrolltop2').on('mouseover',function(){
            $(this).addClass('scrolltop2_mousemove');                                      
        });
        $('#scrolltop2').on('mouseleave',function(){
            $(this).removeClass('scrolltop2_mousemove');                                       
        });
        
    }
}

$(function($){
    topic_down();
})