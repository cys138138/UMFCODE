/**
 * JS辅助工具
 */
var JsTools = {
    /**
     * 检测一个变量是否对象
     */
    isObject : function(variable){
        return typeof(variable) == 'object' && Object.prototype.toString.call(variable).toLowerCase() == '[object object]' && !variable.length;
    },

    /**
     * 合并两个数组或对象
     */
    merge : function(obj1, obj2) {
        var oTmpObj1 = this.clone(obj1);
        if($.isArray(obj1) && $.isArray(obj2)){
            for(var i in obj2){
                if($.inArray(obj2[i], oTmpObj1) === -1){
                    oTmpObj1.push(obj2[i]);
                }
            }
        }else if($.isPlainObject(obj1) && $.isPlainObject(obj2)){
            for(var key in obj2) {
                if(oTmpObj1.hasOwnProperty(key) || obj2.hasOwnProperty(key)){
                    oTmpObj1[key] = obj2[key];
                }
            }
        }
        return this.clone(oTmpObj1);
    },

    /**
     * 判断一个元素是否在数组内
     * @param {type} value 元素值
     * @param {type} array 数组
     * @param {type} isStrict 是否严格模式
     * @returns {Boolean}
     */
    inArray : function(value, array, isStrict){
        for(var i in array){
            if(array[i] == value && !isStrict){
                return true;
            }else if(array[i] === value && isStrict){
                return true;
            }
        }
        return false;
    },

    /**
     * 克隆一个数组或对象
     */
    clone : function(oObj){
        if(oObj == null || typeof(oObj) !== 'object'){
            return oObj;
        }
        var oTempObj = new oObj.constructor();
        for(var key in oObj){
            oTempObj[key] = arguments.callee(oObj[key]);
        }
        return oTempObj;
    },

    shuffle : function(aArray){
        aArray.sort(function(key, value){
            return Math.random() > 0.5 ? -1 : 1;//用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
        });
        return aArray;
    }
};

/**
 * 封装的ajax
 * @param {type} aTmpOption ajax选项
 * @returns {undefined}
 */
function ajax(aTmpOption){
	var aOption = JsTools.clone(aTmpOption);
	if(!aOption.type){
		aOption.type = 'post';
	}

	if(!aOption.dataType){
		aOption.dataType = 'json';
	}

	if(!aOption.error){
		aOption.error = function(aRequest){
			alert('抱歉，网络可能有点慢');
			if(aOption.afterError){
				aOption.afterError(aRequest);
			}
		};
	}

	aOption.success = function(aResult){
		if(aResult.status == 403){
			//重新登陆
			location.href = aResult.data;
		}
		aTmpOption.success(aResult);
	};

	return $.ajax(aOption);
}

/**
 * 生成格式化日期
 * @param {type} format 格式描述,与PHP的date函数参数用法完全一致,大部分参数支持
 * @param {type} timestamp 格式化参照的时间戳,不传则默认为当前时刻的时间戳
 */
function date(format, timestamp){
	//实例化日期对象
	var jsdate=((timestamp) ? new Date(timestamp*1000) : new Date());
	
	//补零
	var pad = function(data, len){
		if((data += '').length < len){
			//计算要补多少个零
			len = len - data.length;
			var str =  '0000';
			return data = str.substr(0,len) + data;
		}else{
			return data;
		}
	}
	var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
	
	//计算一年中的第几天
	var inYearDay = function(){
		var aDay = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
		var day = jsdate.getDate();
		var month = jsdate.getMonth();
		var year = jsdate.getFullYear();
		$reDay = 0;
		for(var i = 0;i < month;i++){
			$reDay += aDay[i];
		}
		$reDay += day;
		//计算闰年
		if(month>1 && (year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
			$reDay += 1;
		}
		return $reDay;
	};
	
	var fm = {
		//天
		j : function(){return jsdate.getDate();},
		d : function(){return pad(fm.j(), 2);},
		w : function(){return jsdate.getDay();},
		l : function(){return weekdays[fm.w()];},
		D: function(){return fm.l().substr(0,3);},
		N : function(){return fm.w() + 1;},
		z : function(){return inYearDay();},
		
		//月
		n : function(){return jsdate.getMonth() + 1;},
		m : function(){return pad(fm.n(), 2);},
		t : function(){
            var n;
            if( (n = jsdate.getMonth() + 1) == 2 ){
                return 28 + fm.L();
            } else{
                if( n & 1 && n < 8 || !(n & 1) && n > 7 ){
                    return 31;
                } else{
                    return 30;
                }
            }
        },
		
		//年
		Y : function(){return jsdate.getFullYear();},
        y : function(){return (jsdate.getFullYear() + "").slice(2);},
		L : function(){var y = fm.Y();return (!(y & 3) && (y % 1e2 || !(y % 4e2))) ? 1 : 0;},
		
		//秒
		s : function(){return pad(jsdate.getSeconds(), 2);},
		
		//分
		i : function(){return pad(jsdate.getMinutes(), 2);},
		
		//时
		H : function(){return pad(jsdate.getHours(), 2);},
		g : function(){return jsdate.getHours() % 12 || 12;},
		
		//am或pm
		a : function(){return jsdate.getHours() > 11 ? 'pm' : 'am';},
		
		//AM或PM
		A : function(){return fm.a().toUpperCase();},
		
		//周
		W : function(){
            var a = fm.z(), b = 364 + fm.L() - a;
            var nd2, nd = (new Date(jsdate.getFullYear() + '/1/1').getDay() || 7) - 1;
            if(b <= 2 && ((jsdate.getDay() || 7) - 1) <= 2 - b){
                return 1;
            } else{
                if(a <= 2 && nd >= 4 && a >= (6 - nd)){
                    nd2 = new Date(jsdate.getFullYear() - 1 + '/12/31');
                    return date("W", Math.round(nd2.getTime()/1000));
                } else{
                    return (1 + (nd <= 3 ? ((a + nd) / 7) : (a - (7 - nd)) / 7) >> 0);
                }
            }
        }
		
	};
	
	//分析format
	return format.replace(/[\\]?([a-zA-Z])/g, function(rekey1, rekey2){
		var result = '';
        if(rekey1 != rekey2){
            result = rekey2;
        }else if(fm[rekey2]){
            result = fm[rekey2]();
        }else{
            result = rekey2;
        }
        return result;
    });
}


function time2FormatStr(seconds){
	seconds = parseInt(seconds);
	var hourse = Math.floor(seconds / 3600),
	minute = Math.floor((seconds - hourse * 3600) / 60),
	second = seconds - hourse * 3600 - minute * 60;

	if(hourse < 10){
		hourse = '0' + hourse;
	}
	if(minute < 10){
		minute = '0' + minute;
	}
	if(second < 10){
		second = '0' + second;
	}
	return hourse + ':' + minute + ':' + second
}

function heightAdap(){
	var imgHeight = $(window).height();
	$('img.img-style').height(imgHeight);
}

$(function(){
	heightAdap(); //背景高度自适应
});