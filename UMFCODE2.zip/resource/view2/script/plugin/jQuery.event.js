(function($, win){
	var aCurrentUser = {
		//当前用户
		id : 0
		,name : ''
		,profile : ''
	}
	,aUrl
	,oWrapEvents = null
	,oLastMoreUserList = null
	,oLastEditor = null
	,allowDeleteShuoShuo = false;

	var self = win.Event = {
		TYPE : {
			SHUO_SHUO: 1
			,BE_FRIEND : 3
			,PASS_MISSION_CHALLENGE : 6
			,PASS_MISSION_TASK : 7
			,PASS_MISSION_CHALLENGE_AND_THROUGH_SELF : 90
			,PASS_MISSION_CHALLENGE_AND_THROUGH_WORLD : 91
			,UPDATE_MEDAL : 8
			,JOIN_MATCH : 9
			,FINISH_MATCH : 11
			,REJOIN_MATCH : 17
			,GET_AWARD : 12
			,SHARE_PK : 16
			,SHARE_MATCH : 80
			,EXCHANGE_PRODUCT : 20
		}

		,config : function(aOption){
			if(aOption.wrapId){
				oWrapEvents = $('#' + aOption.wrapId);
				if(!oWrapEvents.length){
					$.error('找不到事件外框的DOM');
				}

				_bindEvents(oWrapEvents);
			}

			if(aOption.aCurrentUser){
				aCurrentUser = aOption.aCurrentUser;
			}

			if(aOption.aUrl){
				aUrl = aOption.aUrl;
			}

			if(aOption.allowDeleteShuoShuo){
				allowDeleteShuoShuo = aOption.allowDeleteShuoShuo;
			}
		}

		,appendList : function(aEventList){
			for(var i in aEventList){
				var aEvent = aEventList[i], eventHtml = '';
				try{
					if(aEvent.type == self.TYPE.SHUO_SHUO){
						eventHtml = self.buildShuoShuoHtml(aEvent);
					}else if(aEvent.type == self.TYPE.BE_FRIEND){
						eventHtml = self.buildBeFriendHtml(aEvent);
					}else if(aEvent.type == self.TYPE.PASS_MISSION_CHALLENGE){
						eventHtml = self.buildPassMissionChallengeHtml(aEvent);
					}else if(aEvent.type == self.TYPE.PASS_MISSION_TASK){
						eventHtml = self.buildPassMissionExerciseHtml(aEvent);
					}else if(aEvent.type == self.TYPE.PASS_MISSION_CHALLENGE_AND_THROUGH_SELF){
						eventHtml = self.buildPassMissionChallengeWithThroughSelfHtml(aEvent);
					}else if(aEvent.type == self.TYPE.PASS_MISSION_CHALLENGE_AND_THROUGH_WORLD){
						eventHtml = self.buildPassMissionChallengeWithThroughWorldHtml(aEvent);
					}else if(aEvent.type == self.TYPE.UPDATE_MEDAL){
						eventHtml = self.buildUpdateMedalHtml(aEvent);
					}else if(aEvent.type == self.TYPE.JOIN_MATCH){
						eventHtml = self.buildJoinMatchHtml(aEvent);
					}else if(aEvent.type == self.TYPE.FINISH_MATCH){
						eventHtml = self.buildFinishMatchHtml(aEvent);
					}else if(aEvent.type == self.TYPE.REJOIN_MATCH){
						eventHtml = self.buildRejoinMatchHtml(aEvent);
					}else if(aEvent.type == self.TYPE.GET_AWARD){
						eventHtml = self.buildAwardHtml(aEvent);
					}else if(aEvent.type == self.TYPE.SHARE_PK){
						eventHtml = self.buildSharePkHtml(aEvent);
					}else if(aEvent.type == self.TYPE.SHARE_MATCH){
						eventHtml = self.buildShareMatchHtml(aEvent);
					}else if(aEvent.type == self.TYPE.EXCHANGE_PRODUCT){
						eventHtml = self.buildExchangeProductHtml(aEvent);
					}
				}catch(error){
					oLog.add(error, '解析好友动态出错');
					oLog.add(aEvent, '动态内容');
					continue;
				}
				$(eventHtml).appendTo(oWrapEvents).data('aEvent', aEvent);
			}
			initPhotoViewer();
		}

		,buildShuoShuoHtml : function(aEvent){
			var shuoshuoInfoHtml = ''
			,sourceHtml = '';
			if(aEvent.source !== undefined){
				shuoshuoInfoHtml = _buildUserList(aEvent.support, 'TA们觉得很赞') +  '\
				<div class="_button_list">\
					' + _buildAButton('赞(<span xid="supportCount">' + aEvent.support_count + '</span>)', 'tc036 _good', 'btnSupportShuoShuo') + '\
					' + _buildAButton('评论(' + aEvent.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
					' + (aEvent.user.id == aCurrentUser.id ? '' : _buildAButton('转发', 'tc036 _forward', 'btnForward')) + '\
				</div>';

				if(aEvent.source.content){
					sourceHtml = '<div class="_by">\
						<a href="javascript:void(0);">' + getVipName(aEvent.source.user.name, aEvent.source.user.vip) + '：</a>\
						' + UMeEditor.decodeContent(aEvent.source.content) + '\
					</div>';
				}
			}

			var btnShowAllComment = aEvent.comment_count == aEvent.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论

			var aImages = [];
			if(aEvent.images.length){
				aImages = aEvent.images;
			}else if(!$.isEmptyObject(aEvent.source) && aEvent.source.images.length){
				aImages = aEvent.source.images;
			}

			var aImagesHtml = [];
			for(var i = 0, count = aImages.length; i < count; i++){
				aImagesHtml.push('<a class="_image" xid="shuoshuoImage" title="点击查看原图" target="_blank" href="' + aImages[i].src + '">\
					<img src="' + DEFAULT_IMG + '" real="' + aImages[i].thumb + '" onload="h(this);"></img>\
				</a>');
			}
			if(aImagesHtml.length){
				aImagesHtml.unshift('<div class="_match_end">');
				aImagesHtml.push('</div>');
			}

			var btnDeleteEventHtml = '';
			if(aEvent.user.id == aCurrentUser.id && allowDeleteShuoShuo){
				btnDeleteEventHtml =  _buildAButton('删除', '_delete tc036', 'btnDeleteShuoShuo') ;
			}else{
				btnDeleteEventHtml = '';
			}

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-type="' + aEvent.type + '" data-dataId="' + aEvent.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">' + (aEvent.source && aEvent.source.content ? '转发了说说' : '发表了新说说') + '</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
					' + btnDeleteEventHtml + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aEvent.content) + '</div>\
					' + sourceHtml + '\
					' + aImagesHtml.join('') + '\
				</div>\
				<div class="_then" xid="then">\
					' + shuoshuoInfoHtml +  '\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aEvent.comment, false, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		,buildJoinMatchHtml : function(aEvent){
			var matchUrl = aUrl.match.replace('_match_id', aEvent.match_id)
			,users = _buildUserList(aEvent.users, 'TA们也报名了', '_match');

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-dataId="' + aEvent.match_id + '" data-type="' + aEvent.type + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">报名了一场比赛</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<div class="_by c">\
						<div class="_match_end">\
							<a class="_image" target="_blank" href="' + matchUrl + '">\
								<img onload="h(this)" src="' + DEFAULT_IMG + '" real="' + aEvent.image + '" width="81" height="90" />\
							</a>\
							<div class="_description">\
								<a href="' + matchUrl + '" class="_name f14 tc036" target="_blank">' + aEvent.title + '</a>\
								<div class="_introduction tc999">' + aEvent.description + '</div>\
								<span class="_total">' + aEvent.member_count + '人参赛</span>\
								<span class="_time">' + _parseTime(aEvent.start_time) + ' - ' + _parseTime(aEvent.end_time) + '</span>\
							</div>\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					' + users + '\
					<div class="_button_list">\
						<a class="tc036 _match" href="' + matchUrl + '" target="_blank">查看比赛</a>\
					</div>\
				</div>\
			</div>';
		}

		,buildFinishMatchHtml : function(aEvent){
			var matchUrl = aUrl.match.replace('_match_id', aEvent.match_id)
			,users = _buildUserList(aEvent.users, 'TA们也完成了比赛', '_match');

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-dataId="' + aEvent.match_id + '" data-type="' + aEvent.type + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">完成了一场比赛</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<div class="_by c">\
						<div class="_match_end">\
							<a class="_image" target="_blank" href="' + matchUrl + '">\
								<img onload="h(this)" src="' + DEFAULT_IMG + '" real="' + aEvent.image + '" width="81" height="90" />\
							</a>\
							<div class="_description">\
								<a href="' + matchUrl + '" class="_name f14 tc036" target="_blank">' + aEvent.title + '</a>\
								<div class="_introduction tc999">' + aEvent.description + '</div>\
								<span class="_total">' + aEvent.member_count + '人参赛</span>\
								<span class="_time">' + _parseTime(aEvent.start_time) + ' - ' + _parseTime(aEvent.end_time) + '</span>\
							</div>\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					' + users + '\
					<div class="_button_list">\
						<a class="tc036 _match" href="' + matchUrl + '" target="_blank">查看比赛</a>\
					</div>\
				</div>\
			</div>';
		}

		,buildRejoinMatchHtml : function(aEvent){
			//aEvent.image = 'http://tb1.bdstatic.com/tb/cms/1231fangyuan-03.jpg';	//tt////////////////临时,部署后删除
			var matchUrl = aUrl.match.replace('_match_id', aEvent.match_id)
			,users = _buildUserList(aEvent.users, 'TA们也再次参加了', '_match');

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-dataId="' + aEvent.match_id + '" data-type="' + aEvent.type + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">再次参加了一场比赛</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<div class="_by c">\
						<div class="_match_end">\
							<a class="_image" target="_blank" href="' + matchUrl + '">\
								<img onload="h(this)" src="' + DEFAULT_IMG + '" real="' + aEvent.image + '" width="81" height="90" />\
							</a>\
							<div class="_description">\
								<a href="' + matchUrl + '" class="_name f14 tc036" target="_blank">' + aEvent.title + '</a>\
								<div class="_introduction tc999">' + aEvent.description + '</div>\
								<span class="_total">' + aEvent.member_count + '人参赛</span>\
								<span class="_time">' + _parseTime(aEvent.start_time) + ' - ' + _parseTime(aEvent.end_time) + '</span>\
							</div>\
						</div>\
					</div>\
					<div class="_history">\
						<p>\
							<i class="ico_event ico_event_arr"></i>\
							<span class="tc999">' + _parseTime(aEvent.join_time) + '</span>\
							' + _buildUserLink(aEvent.user, 'tc036') + '\
							参加了该比赛\
						</p>\
					</div>\
				</div>\
				<div class="_then">\
					' + users + '\
					<div class="_button_list">\
						<a class="tc036 _match" href="' + matchUrl + '" target="_blank">查看比赛</a>\
					</div>\
				</div>\
			</div>';
		}

		,buildAwardHtml : function(aEvent){
			var matchUrl = aUrl.match.replace('_match_id', aEvent.match_id)
			,winners = _buildUserList(aEvent.users, 'TA们得奖了', '_match')
			,result = '，比赛得分' + (aEvent.score / 100) + '分，比赛排名No.' + aEvent.ranking + '！';
			if(aEvent.win_type == 1){
				result = '荣获' + ['冠军', '亚军', '季军', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名'][aEvent.ranking - 1] + result + '<br/>赶紧去领奖吧！否则' + aEvent.match_limit_award_day + '天后就会因为过期无法领取的哦!';
			}else{
				result = '获得幸运奖' + result;
			}

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-dataId="' + aEvent.match_id + '" data-type="' + aEvent.type + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">在比赛中得奖了</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<span class="_content f14 ' + (aEvent.win_type == 1 ? 'tcC33' : 'tc333') + '">' + result + '</span>\
					<div class="_by c">\
						<div class="_match_end">\
							<a class="_image" target="_blank" href="' + matchUrl + '">\
								<img onload="h(this)" src="' + DEFAULT_IMG + '" real="' + aEvent.image + '" width="81" height="90" />\
							</a>\
							<div class="_description">\
								<a href="' + matchUrl + '" class="_name f14 tc036" target="_blank">' + aEvent.title + '</a>\
								<div class="_introduction tc999">' + aEvent.description + '</div>\
								<span class="_total">' + aEvent.member_count + '人参赛</span>\
								<span class="_time">' + _parseTime(aEvent.start_time) + ' - ' + _parseTime(aEvent.end_time) + '</span>\
								<span class="_best">冠军得分 ' + (aEvent.champion_score / 100) + '</span>\
							</div>\
						</div>\
					</div>\
					<div class="_history">\
						' + (parseInt(aEvent.rejoin_join_time) > 0 ? '<p>\
							<i class="ico_event ico_event_arr"></i>\
							<span class="tc999">' + _parseTime(aEvent.rejoin_join_time) + '</span>\
							' + _buildUserLink(aEvent.user, 'tc036') + '\
							再次报名了该比赛\
						</p>' : '') + '\
						<p>\
							<i class="ico_event ico_event_arr"></i>\
							<span class="tc999">' + _parseTime(aEvent.join_time) + '</span>\
							' + _buildUserLink(aEvent.user, 'tc036') + '\
							参加了该比赛\
						</p>\
					</div>\
				</div>\
				<div class="_then">\
					' + winners + '\
					<div class="_button_list">\
						<a class="tc036 _match" href="' + matchUrl + '" target="_blank">查看比赛</a>\
					</div>\
				</div>\
			</div>';
		}

		,buildUpdateMedalHtml : function(aEvent){
			var tips = '',
			title = '';
			if(aEvent.medal_level == 1){
				//第一级,获得勋章
				tips = '获得一枚“' + aEvent.medal_name + '”勋章，勋章等级Lv' + aEvent.medal_level + '！';
				title = '获得一枚新勋章';
			}else{
				tips = '“' + aEvent.medal_name + '”勋章升级，勋章当前等级Lv' + aEvent.medal_level + '！';
				title = '勋章升级';
			}
			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-type="' + aEvent.type + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">' + title + '</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<span class="_content f14 tc333">' + tips + '</span>\
					<div class="_by">\
						<div class="medallist">\
							<ul class="list c">\
								<li>\
									<a href="'+ aUrl.userHome.replace('_userId', aEvent.user.id) +'">\
										<img onload="h(this)" src="' + DEFAULT_IMG + '" real="' + aEvent.medal_image + '" width="76" height="80" />\
									</a>\
									<span class="level">LV' + aEvent.medal_level + '</span>\
								</li>\
							</ul>\
						</div>\
					</div>\
				</div>\
			</div>';
		}

		,buildPassMissionChallengeWithThroughSelfHtml : function(aEvent){



			return '<div class="_event mod">\
				<div class="_who">\
					' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">破了 ' + aEvent.mission.title + ' 关个人记录</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<p class="_content f14 tc333">挑战得分' + (aEvent.mission.score / 100) + '，超出本关个人记录历史最高记录' + ((aEvent.mission.score - aEvent.mission.my_record) / 100) + '分！</p>\
					<div class="_by">\
						<div class="fight">\
							<p class="_content"><i class="ico_event ico_event_tips"></i>' + aEvent.mission.title + '</p>\
							<div class="c">\
								<p class="fl">\
									<span class="tc999">挑战成绩：</span>\
									' + _getStartHtml(aEvent.mission.score) + '\
								</p>\
								<p class="fl">\
									<span class="tc999">得分：</span>\
									<b class="geor">' + (aEvent.mission.score / 100) + '</b>\
									分，超越了' + aEvent.mission.over_percent + '%的挑战者\
								</p>\
							</div>\
						</div>\
					</div>\
					<div class="_history">\
						<p>\n\
							<i class="ico_event ico_event_arr"></i>\n\
							<span class="tc999">' + _parseTime(aEvent.mission.pass_challenge_time) + '</span>\
							' + _buildUserLink(aEvent.user, 'tc036') + ' 挑战成功\n\
						</p>\
						<p>\n\
							<i class="ico_event ico_event_arr"></i>\n\
							<span class="tc999">' + _parseTime(aEvent.mission.pass_exercise_time) + '</span>\n\
							' + _buildUserLink(aEvent.user, 'tc036') + ' 完成修炼\n\
						</p>\
					</div>\
				</div>\
			</div>';
		}

		,buildPassMissionChallengeWithThroughWorldHtml : function(aEvent){
			return '<div class="_event mod">\
				<div class="_who">\
					' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">破了 ' + aEvent.mission.title + ' 关世界记录</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<p class="_content f14 tc333">挑战得分' + (aEvent.mission.result.my_score / 100) + '，超出本关世界记录历史最高记录' + ((aEvent.mission.result.my_score - aEvent.mission.result.world_score) / 100) + '分！</p>\
					<div class="_by">\
						<div class="fight">\
							<p class="_content"><i class="ico_event ico_event_tips"></i>' + aEvent.mission.title + '</p>\
							<div class="c">\
								<p class="fl">\
									<span class="tc999">挑战成绩：</span>\
									' + _getStartHtml(aEvent.mission.result.my_score) + '\
								</p>\
								<p class="fl">\
									<span class="tc999">得分：</span>\
									<b class="geor">' + (aEvent.mission.result.my_score / 100) + '</b>分，超越了所有的挑战者\
								</p>\
							</div>\
						</div>\
					</div>\
					<div class="_history">\
						<p>\n\
							<i class="ico_event ico_event_arr"></i>\n\
							<span class="tc999">' + _parseTime(aEvent.mission.pass_challenge_time) + '</span>\n\
							' + _buildUserLink(aEvent.user, 'tc036') + ' 挑战成功\
						</p>\
						<p>\n\
							<i class="ico_event ico_event_arr"></i>\n\
							<span class="tc999">' + _parseTime(aEvent.mission.pass_excercise_time) + '</span>\n\
							' + _buildUserLink(aEvent.user, 'tc036') + ' 完成修炼\n\
						</p>\
					</div>\
				</div>\
			</div>';
		}

		,buildPassMissionChallengeHtml : function(aEvent){
			return '<div class="_event mod" data-dataId="' + aEvent.id + '" data-type="' + aEvent.type + '">\
				<div class="_who">\
					' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">成功挑战了 ' + aEvent.mission[0].title + ' 关</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.mission[0].time) + '</span>\
				</div>\
				<div class="_what">\
					<p class="_content f14 tc333">挑战得分' + (aEvent.mission[0].score / 100) + '分，挑战成功！</p>\
					<div class="_by">\
						<div class="fight">\
							<p class="_content"><i class="ico_event ico_event_tips"></i>' + aEvent.mission[0].title + '</p>\
							<div class="c">\
								<p class="fl">\
									<span class="tc999">挑战成绩：</span>\
									' + _getStartHtml(aEvent.mission[0].score) + '\
								</p>\
								<p class="fl">\
									<span class="tc999">得分：</span>\
									<b class="geor">' + (aEvent.mission[0].score / 100) + '</b>分\
									' + (aEvent.mission[0].over_percent > 0 ? '，超越了' + aEvent.mission[0].over_percent + '%的挑战者' : '') + '\
								</p>\
							</div>\
						</div>\
					</div>\
					<div class="_history">\
						<p>\n\
							<i class="ico_event ico_event_arr"></i>\n\
							<span class="tc999">' + _parseTime(aEvent.mission[0].pass_exercise_time) + '</span>\n\
							' + _buildUserLink(aEvent.user, 'tc036') + ' 完成修炼\
						</p>\
					</div>\
				</div>\
			</div>';
		}

		,buildPassMissionExerciseHtml : function(aEvent){
			return '<div class="_event mod">\
				<div class="_who">\
					' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">成功修炼了 ' + aEvent.mission[0].title + ' 关</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.mission[0].time) + '</span>\
				</div>\
				<div class="_what">\
					<p class="_content f14 tc333">修炼成功！</p>\
					<div class="_by">\
						<div class="fight">\
							<p class="_content"><i class="ico_event ico_event_tips"></i>' + aEvent.mission[0].title + '</p>\
						</div>\
					</div>\
				</div>\
			</div>';
		}

		,buildBeFriendHtml : function(aEvent){
			var aFriendsHtml = [];
			for(var i in aEvent.friend){
				var aFriend = aEvent.friend[i];
				aFriendsHtml.push('<li xid="user" itemid="' + aFriend.id + '">\
					<p class="head">' + _buildUser(aFriend, {width : 50, height : 50}) + '</p>\
					<p class="name ellipsis">' + _buildUserLink(aFriend, 'tc036') + '</p>\
					<p class="btnbox">\
						<a class="' + (aFriend.is_friend ? 'then_btn' : 'btn') + '"' + (aFriend.is_friend ? '' : ' xid="btnAddFriend"') + ' href="javascript:void(0);">\
							<i class="ico ' + (aFriend.is_friend ? 'ico_then' : 'ico_add') + '"></i>\
							<span class="row">好友</span>\
						</a>\
					</p>\
				</li>');
			}

			return '<div class="_event mod">\
				<div class="_who">\
					' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">添加了新好友</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<div class="addfriends">\
						<ul class="list c">' + aFriendsHtml.join('') + '</ul>\
					</div>\
				</div>\
			</div>';
		}

		,buildShareMatchHtml : function(aEvent){
			var btnShowAllComment = aEvent.comment_count == aEvent.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论

			var tips = '得分: ' + (aEvent.source.score / 100) + '分，排名: No.' + aEvent.source.ranking;
			if(aEvent.source.is_win){
				var rankingName = aEvent.source.is_in_ranking ? ('荣获' + ['冠军', '亚军', '季军', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名'][aEvent.source.ranking - 1]) : '本场比赛获得了幸运奖';
				tips = getVipName(aEvent.user.name, aEvent.user.vip) + '，恭喜你，本场比赛' + rankingName + '！' + tips;
			}else{
				tips = '很遗憾，本场比赛未得奖！ ' + tips;
			}

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-type="' + aEvent.type + '" data-dataId="' + aEvent.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">分享了比赛结果</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aEvent.content) + '</div>\
					<div class="_by">\
						<p class="f14' + (aEvent.source.is_win ? ' tcC33' : '') + '">' + tips + '。</p>\
					</div>\
					<div class="_by c">\
						<div class="_match_end">\
							<a class="_image" href="' + aUrl.match.replace('_match_id', aEvent.source.id) + '" target="_blank">\
								<img src="' + DEFAULT_IMG + '" real="' + aEvent.source.image + '" width="81" height="90" />\
								<i class="ico_event ' + (($.now() / 1000) < aEvent.source.end_time ? 'ico_event_match' : 'ico_event_end') + '"></i>\
							</a>\
							<div class="_description">\
								<a href="' + aUrl.match.replace('_match_id', aEvent.source.id) + '" class="_name f14 tc036" target="_blank">' + aEvent.source.title + '</a>\
								<div class="_introduction tc999">' + aEvent.source.description + '</div>\
								<span class="_total">' + aEvent.source.member_count + '人参赛</span>\
								<span class="_time">' + _parseTime(aEvent.source.start_time) + ' - ' + _parseTime(aEvent.source.end_time) + '</span>\
								<span class="_best">冠军得分 ' + (aEvent.source.champion_score / 100) + '</span>\
							</div>\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					' + _buildUserList(aEvent.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('赞(<span xid="supportCount">' + aEvent.support_count + '</span>)', 'tc036 _good', 'btnSupportShuoShuo') + '\
						' + _buildAButton('评论(' + aEvent.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aEvent.comment, false, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		,buildSharePkHtml : function(aEvent){
			var btnShowAllComment = aEvent.comment_count == aEvent.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论

			var tips = '得分: ' + (aEvent.source.my_score / 100) + '分，对方得分：' + (aEvent.source.opposite_score / 100);
			if(aEvent.source.my_score >= aEvent.source.opposite_score){
				tips = getVipName(aEvent.user.name, aEvent.user.vip) + '，恭喜你，赢得本次PK的胜利！' + tips;
			}else{
				tips = '很遗憾，本次PK负败！' + tips;
			}

			var aSender = aEvent.source.opposite_user.is_sender ? aEvent.source.opposite_user : aEvent.user,
			aReceiver = aEvent.source.opposite_user.is_sender ? aEvent.user : aEvent.source.opposite_user;

			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-type="' + aEvent.type + '" data-dataId="' + aEvent.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user) + '\
						<span class="_description f14 tc999">分享了PK结果</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aEvent.content) + '</div>\
					<div class="_by">\
						<p class="f14' + (aEvent.source.my_score >= aEvent.source.opposite_score ? ' tcC33' : '') + '">' + tips + '。</p>\
					</div>\
					<div class="_by c">\
						<div class="_pk_end">\
							<span class="_master">' + _buildUser(aSender, {width : 50, height : 50}) + '</span>\
							' + _buildUserLink(aSender, '_master_name tc036') + '\
							<span class="_vs">VS</span>\
							<span class="_slave">' + _buildUser(aReceiver, {width : 50, height : 50}) + '</span>\
							' + _buildUserLink(aReceiver, '_slave_name tc036') + '\
							<a href="' + aUrl.missionExercise.replace('_mission_id', aEvent.source.mission_id) + '" class="_title f14 tc036" target="_blank">' + aEvent.source.mission_title + '</a>\
							<span class="_duration">' + aEvent.source.duration + '分钟</span>\
							<span class="_time">' + _parseTime(aEvent.source.pk_send_time) + ' - ' + _parseTime(aEvent.source.pk_over_time) + '</span>\
							<span class="_es">' + aEvent.source.es_count + '题</span>\
							' + (aEvent.source.attachment_gold ? '<span class="_gold">' + aEvent.source.attachment_gold + '金币</span>' : '') + '\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					' + _buildUserList(aEvent.source.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('赞(<span xid="supportCount">' + aEvent.support_count + '</span>)', 'tc036 _good', 'btnSupportShuoShuo') + '\
						' + _buildAButton('评论(' + aEvent.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
						<a class="tc036 _pk" href="javascript:;" onclick="showPkDetail(' + aEvent.source.id + ', 0)">查看PK</a>\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aEvent.comment, false, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		,buildExchangeProductHtml : function(aEvent){
			return '<div class="_event mod" xid="event" itemid="' + aEvent.id + '" data-type="' + aEvent.type + '" data-dataId="' + aEvent.goods.id + '">\
				<div class="_who">\
					' + _buildUser(aEvent.user, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aEvent.user, '_name f14 tc036') + '</a>\
						<span class="_description f14 tc999">在兑换商城兑换了礼品</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aEvent.time) + '</span>\
				</div>\
				<div class="_what">\
					<span class="_content f14 tcC33">' + aEvent.goods.name + '</span>\
					<div class="_by c">\
						<div class="_exchange_info">\
							<p>兑换条件：需要花费 ' + aEvent.goods.gold + ' 金币并且等级达到 ' + aEvent.goods.level + ' 级</p>\
							' + (aEvent.goods.stock > 0 ? '<p>还有' + aEvent.goods.stock + '件库存，喜欢就别错过哦&gt;_&lt;！</p>' : '可惜已经没有库存了~_~') + '\
						</div>\
					</div>\
				</div>\
				<div class="_then">\n\
					<div class="_button_list">\
						<a class="tc036 _mall" href="' + aUrl.exchange.replace('_goodsId', aEvent.goods.id) + '" target="_blank">查看礼品</a>\
						' + _buildAButton('我也喜欢(<span xid="supportCount">' + aEvent.goods.support + '</span>)', 'tc036 _good', 'btnSupportGoods') + '\
					</div>\
				</div>\
			</div>';
		}
	};

	function _buildUser(aUser, aSize){
		if(!aSize){
			aSize = {
				width : 30
				,height : 30
			};
		}
		var publicIco = aUser.is_public == 1 ? '<i class="ico ico_auth"></i>' : '';
		return '<p class="head" xid="userProfile">\
			<a class="_profile" href="' + aUrl.userHome.replace('_userId', aUser.id) + '" target="_blank">\
				'+ publicIco +'\
				<img src="' + DEFAULT_HEAD_IMG + '" real="' + aUser.profile + '" height="' + aSize.width + '" width="' + aSize.height + '" onload="h(this)" onmouseover="headCard(' + aUser.id + ', this)" />\
			</a>\
		</p>';
	}

	function _buildUserLink(aUser, className){
		if(!className){
			className = '_name f14 tc036';
		}
		return '<a class="' + className + '" href="' + aUrl.userHome.replace('_userId', aUser.id) + '" target="_blank">' + getVipName(aUser.name, aUser.vip) + '</a>';
	}

	/**
	 * 构建事件相关用户列表
	 * @param {type} aSupportUserList
	 * @param {type} supportCount
	 * @param {type} shuoshuoId
	 * @returns {String}
	 */
	function _buildUserList(aUserList, tips, flag){
		if(!aUserList || !$.isArray(aUserList)){
			return '';
		}

		var isMoreUser = false;
		if(aUserList.length == 11){
			aUserList.pop();
			isMoreUser = true;
		}

		var aUserListHtml = [];
		for(var i in aUserList){
			aUserListHtml.push(_buildUser(aUserList[i]));
		}

		var userListHtml = '';
		if(aUserListHtml.length){
			userListHtml = '<div class="_profile_list" xid="userList">\
				<a class="' + (flag ? flag : '_good') + '" title="' + tips + '"></a>\
				' + aUserListHtml.join('') + '\
				' + (isMoreUser ? '<a href="javascript:void(0);" class="_and_so_on" xid="btnShowMoreUser"></a>' : '') + '\
			</div>';
		}
		return userListHtml;
	}

	function _buildAButton(content, className, xid){
		return '<a href="javascript:void(0);" class="' + className + '" xid="' + xid + '">' + content + '</a>';
	}

	function _parseTime(timeStamp){
		return date('n月j日 H:i', timeStamp);
	}

	function _buildShuoShuoCommentList(aCommentList, isManager, allowDeleteUserId){
		var aCommentListHtml = [];
		for(var i in aCommentList){
			var aComment = aCommentList[i];
			aCommentListHtml.push(_buildShuoShuoComment(aComment, isManager, allowDeleteUserId));
		}
		return aCommentListHtml.join('');
	}

	/**
	 * 构建说说评论
	 * @param {type} aComment
	 * @param {type} isManager
	 * @param {type} allowDeleteUserId
	 * @returns {String}
	 */
	function _buildShuoShuoComment(aComment, isManager, allowDeleteUserId){
		var aComments = ['<div class="_comment_content c">\
			' + _buildUser(aComment.user) + '\
			<div class="_name_content">\
				<a class="_name f12 tc036" href="javascript:void(0);">' + getVipName(aComment.user.name, aComment.user.vip) + '</a>：\
				<span class="_content f12 tc333">' + UMeEditor.decodeContent(aComment.content) + '</span>\
				<div class="c">\
					<span class="_time f12 tc999">' + _parseTime(aComment.time) + '</span>\
					' + (isManager || allowDeleteUserId == aComment.user.id ? _buildAButton('删除', 'tc036 _delete_ico', 'btnDeleteComment') : '') + '\
					' + _buildAButton('回复', '_reply_ico', 'btnReplyShuoShuoComment') + '\
				</div>\
			</div>\
		</div>'];

		var aReplys = [aComment.reply_count == aComment.reply.length ? '' : _buildAButton('展开全部回复', 'tc036 _more_reply f12', 'btnShowAllReply')];
		for(var j in aComment.reply){
			aReplys.push(_buildShuoShuoReply(aComment.reply[j], isManager, allowDeleteUserId));
		}
		aComments.push('<div class="replys" xid="wrapReplys">' + aReplys.join('') + '</div>');
		aComments.push('<div class="replyEditor" xid="replyEditor"></div>');

		return '<div class="_comment" xid="comment" itemid="' + aComment.id + '" data-user_id="' + aComment.user.id + '" data-name="' + aComment.user.name.replace(/<[^>]+>/g, '') + '">' + aComments.join('') + '</div>';
	}

	/**
	 * 构建说说回复
	 * @param {type} aReply
	 * @param {type} isManager
	 * @param {type} allowDeleteUserId
	 * @returns {String}
	 */
	function _buildShuoShuoReply(aReply, isManager, allowDeleteUserId){
		var isReplyMe = aReply.reply_user.id === undefined;
		var isReplySelf = aReply.reply_user.id == aReply.user.id || (aReply.user.id == aCurrentUser.id && isReplyMe);
		var replyToHtml = '';
		if(!isReplySelf){
			replyToHtml = ' 回复<a class="_name f12 tc036" href="javascript:void(0)"> ' + (isReplyMe ? '我' : getVipName(aReply.reply_user.name, aReply.reply_user.vip)) + '</a>';
		}

		return '<div class="_reply c" xid="reply" itemid="' + aReply.id + '" data-user_id="' + aReply.user.id + '" data-name="' + aReply.user.name.replace(/<[^>]+>/g, '') + '">\
			<div class="_reply_content c">\
				' + _buildUser(aReply.user) + '\
				<div class="_name_content">\
					<a class="_name f12 tc036" href="javascript:void(0);">' + getVipName(aReply.user.name, aReply.user.vip) + '</a>' + replyToHtml + '：\
					<span class="_content f12 tc333">' + UMeEditor.decodeContent(aReply.content) + '</span>\
					<div class="c">\
						<span class="_time f12 tc999">' + _parseTime(aReply.time) + '</span>\
						' + (isManager || allowDeleteUserId == aReply.user.id ? _buildAButton('删除', '_delete_ico', 'btnDeleteReply') : '') + '\
						' + _buildAButton('回复', '_reply_ico', 'btnReplyShuoShuoReply') + '\
					</div>\
				</div>\
			</div>\
		</div>';
	}

	/**
	 * 获取事件单元外框对象
	 * @param {type} element
	 * @returns {unresolved}
	 */
	function _getEventDomByElement(element){
		return $(element).closest('[xid="event"]');
	}

	function _getStartHtml(score){
		var highlightStartNum = getMissionScoreLevel(score),
		aStartListHtml = [];
		for(var i = 0; i < highlightStartNum; i++){
			aStartListHtml.push('<i class="ico_event ico_event_star_light"></i>');
		}
		for(var i = 0; i < 5 - highlightStartNum; i++){
			aStartListHtml.push('<i class="ico_event ico_event_star_lock"></i>');
		}
		return aStartListHtml.join('');
	}

	/**
	 * 绑定事件操作函数
	 * @param {type} oWrap
	 * @returns {undefined}
	 */
	function _bindEvents(oWrap){
		/**
		 * 删除和我相关的说说
		 */
		oWrap.delegate('[xid="btnDeleteShuoShuo"]', 'click', function(){
			var oEvent = _getEventDomByElement(this);
			UBox.confirm('确定要删除这条消息吗？', function(){
				ajax({
					url : aUrl.deleteShuoShuo
					,data : {
						id : oEvent.data('aEvent').shuoshuo_id
					}
					,success : function(aResult){
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status == 1){
							oEvent.slideUp('normal', function(){
								$(this).remove();
							});
						}
					}
				});
			});
		});

		/**
		 * 赞说说的操作
		 */
		oWrap.delegate('[xid="btnSupportShuoShuo"]', 'click', function(){
			var oEvent = _getEventDomByElement(this);
			ajax({
				url : aUrl.supportShuoShuo
				,data : {
					id : oEvent.data('aEvent').shuoshuo_id
				}
				,success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					//赞数量+1
					var $oSupportCount = oEvent.find('span[xid="supportCount"]');
					$oSupportCount.text(parseInt($oSupportCount.text()) + 1);

					//显示头像
					var $oUserList = oEvent.find('div[xid="userList"]');	//赞的用户头像列表
					if(!$oUserList.length){
						$(_buildUserList([aCurrentUser], 'TA们觉得很赞')).prependTo(oEvent.find('div[xid="then"]'));
					}else{
						//已有10个头像则移除一个
						var $oUserProfileList = $oUserList.find('p[xid="userProfile"]');
						if($oUserProfileList.length == 10){
							$oUserProfileList.last().remove();
						}
						$(_buildUser(aCurrentUser)).insertAfter($oUserList.children().first());
					}
				}
			});
		});

		/**
		 * 说说评论操作
		 */
		oWrap.delegate('[xid="btnComment"]', 'click', function(){
			var oEvent = _getEventDomByElement(this)
			,dataId = oEvent.attr('data-dataId');

			if(oEvent.data('oEditor') && oLastEditor.id == dataId){
				return;
			}

			var fShowEditor = function(){
				var oEditor = UMeEditor.getInstance({
					oContext : oEvent.find('[xid="wrapCommentEditor"]')
					,aFace : ['qq']
					,tips : '我也说一句：'
					,imageBaseUrl : aUrl.source
					,submitCaption : '评论'
					,userList : true
					,userListUrl : aUrl.friendList
					,onSubmit : function(){
						var contentLength = oEditor.getContentLength();
						if(oEditor.isEmpty()){
							UBox.show('请填写评论内容！', -1);
							return false;
						}else if(contentLength < 1 || contentLength > 150){
							UBox.show('请填写1到150字之间的回复内容！', -1);
							return false;
						}
						ajax({
							url : aUrl.submitComment
							,data : {
								shuoshuoId : dataId
								,content : UMeEditor.encodeContent(oEditor.getContent())
								,atUserIds : oEditor.getAtUserIdList()
							}
							,success : function(aResult){
								if(aResult.status != 1){
									UBox.show(aResult.msg, aResult.status);
									return;
								}
								oLastEditor = null;
								oEvent.data('oEditor', null);
								oEditor.destory();
								aResult = aResult.data;
								var aComment = {
									id : aResult.id
									,content : aResult.content
									,reply : []
									,reply_count : 0
									,user : aCurrentUser
									,time : Math.floor($.now() / 1000)
								};
								var shuoshuoComment = _buildShuoShuoComment(aComment, false, aCurrentUser.id);
								oEvent.find('[xid="wrapComments"]').append(shuoshuoComment);
							}
						});
					}
				});
				oEditor.focus();
				oEditor.id = dataId;
				oLastEditor = oEditor;
				oEvent.data('oEditor', oEditor);
			};

			if(oLastEditor && oLastEditor.getContent().length){
				UBox.confirm('要放弃之前的编辑吗？', function(){
					oLastEditor.destory();
					oLastEditor = null;
					fShowEditor();
				});
			}else if(oLastEditor){
				oLastEditor.destory();
				oLastEditor = null;
				fShowEditor();
			}else{
				fShowEditor();
			}
		});

		/**
		 * 回复说说评论
		 */
		oWrap.delegate('[xid="btnReplyShuoShuoComment"],[xid="btnReplyShuoShuoReply"]', 'click', function(){
			var oEvent = _getEventDomByElement(this)
			,oButton = $(this)
			,oComment = oButton.closest('[xid="comment"]')
			,dataId = oEvent.attr('data-dataId')
			,commentId = oComment.attr('itemid')
			,isReply = oButton.attr('xid') == 'btnReplyShuoShuoReply'
			,replyId = ''
			,aReplyToUser = {};
			if(isReply){
				var oReply = oButton.closest('[xid="reply"]');
				replyId = oReply.attr('itemid');
				aReplyToUser = {
					id : oReply.data('user_id')
					,name : oReply.data('name')
				};
			}else{
				aReplyToUser = {
					id : oComment.data('user_id')
					,name : oComment.data('name')
				};
			}
			if(oEvent.data('oReplyEditor') && oLastEditor && (oLastEditor.id == dataId + '' + commentId + replyId)){
				return;
			}

			var fShowEditor = function(){
				var oEditor = UMeEditor.getInstance({
					oContext : oComment.find('[xid="replyEditor"]')
					,imageBaseUrl : aUrl.source
					,submitCaption : '回复'
					,aFace : ['qq']
					,userList : true
					,userListUrl : aUrl.friendList
					,tips : '我也说一句：'
					,onSubmit : function(){
						var contentLength = oEditor.getContentLength();
						if(oEditor.isEmpty()){
							UBox.show('请填写评论内容！', -1);
							return false;
						}else if(contentLength < 1 || contentLength > 150){
							UBox.show('请填写1到150字之间的回复内容！', -1);
							return false;
						}

						ajax({
							url : aUrl.submitComment
							,data : {
								reply_id : isReply ? replyId : commentId
								,content : UMeEditor.encodeContent(oEditor.getContent())
								,atUserIds : oEditor.getAtUserIdList()
							}
							,success : function(aResult){
								if(aResult.status != 1){
									UBox.show(aResult.msg, aResult.status);
									return;
								}
								oLastEditor = null;
								oEvent.data('oReplyEditor', null);
								oEditor.destory();
								aResult = aResult.data;
								var aReply = {
									id : aResult.id
									,content : aResult.content
									,reply_user : aReplyToUser
									,user : aCurrentUser
									,reply : []
									,reply_count : 0
									,time : Math.floor($.now() / 1000)
								};
								var commentReply = _buildShuoShuoReply(aReply, false, aCurrentUser.id);
								oComment.find('[xid="wrapReplys"]').append(commentReply);
							}
						});
					}
				});
				oEditor.focus();
				oEditor.id = dataId + '' + commentId + replyId;
				oLastEditor = oEditor;
				oEvent.data('oReplyEditor', oEditor);
			};

			if(oLastEditor && oLastEditor.getContent().length){
				UBox.confirm('要放弃之前的编辑吗？', function(){
					oLastEditor.destory();
					oLastEditor = null;
					fShowEditor();
				});
			}else if(oLastEditor){
				oLastEditor.destory();
				oLastEditor = null;
				fShowEditor();
			}else{
				fShowEditor();
			}
		});

		/**
		 * 转发说说
		 */
		oWrap.delegate('[xid="btnForward"]', 'click', function(){
			var aEvent = _getEventDomByElement(this).data('aEvent');
			var shuoshuoId = aEvent.shuoshuo_id;
			if(aEvent.source && aEvent.source.id){
				shuoshuoId = aEvent.source.id;
			}

			UAlert.config({
				user_id : aCurrentUser.id
				,sys_resource_url : aUrl.source
				,forward_shuoshuo_url : aUrl.publishShuoShuo
				,user_list_url : aUrl.friendList
			});
			UAlert.alertForwardShuoShuo(shuoshuoId, 1);
		});

		/**
		 * 删除说说的评论回复操作
		 */
		oWrap.delegate('[xid="btnDeleteComment"],[xid="btnDeleteReply"]', 'click', function(){
			var wrapXid = $(this).attr('xid') == 'btnDeleteComment' ? 'comment' : 'reply';
			var oComment = $(this).closest('[xid="' + wrapXid + '"]');
			UBox.confirm('确定要删除这条评论吗?', function(){
				ajax({
					url : aUrl.deleteShuoShuoComment
					,data : {
						commentId : oComment.attr('itemid')
					}
					,success : function(aResult){
						if(aResult.status == 0){
							UBox.show(aResult.msg, 0);
							return;
						}

						oComment.slideUp('normal', function(){
							$(this).remove();
						});
					}
				});
			});
		});

		/**
		 * 查看所有说说评论操作
		 */
		oWrap.delegate('[xid="btnShowAllComment"]', 'click', function(){
			var oEvent = _getEventDomByElement(this),
			oBtnShowAllComment = $(this);

			var fShowShuoShuoComment = function(aCommentList){
				oEvent.find('[xid="wrapComments"]').html(_buildShuoShuoCommentList(aCommentList, false, aCurrentUser.id));
			};

			var aCommentList = oEvent.data('aCommentList');
			if(aCommentList){
				fShowShuoShuoComment(aCommentList);
				return;
			}

			ajax({
				url : aUrl.getAllShuoShuoComment
				,data : {
					id : oEvent.attr('data-dataId')
				}
				,beforeSend : function(){
					oBtnShowAllComment.text('加载中...');
				}
				,success : function(aResult){
					if(aResult.status  == 0){
						UBox.show(aResult.msg, 0);
						oBtnShowAllComment.text('展开全部评论');
						return;
					}
					var aCommentList = [];
					//构建评论结构
					for(var i in aResult.data){
						var aTmpComment = aResult.data[i];
						aTmpComment.user_info.profile = aUrl.source + aTmpComment.user_info.profile;
						var aComment = {
							id : aTmpComment.id
							,content : aTmpComment.content
							,time : aTmpComment.create_time
							,user : aTmpComment.user_info
							,reply_count : aTmpComment.reply_count
							,reply : []
						};

						//构建回复结构
						for(var j in aTmpComment.reply){
							var aReply = aTmpComment.reply[j];
							aReply.user_info.profile = aUrl.source + aReply.user_info.profile;
							aReply.reply_user_info.profile = aUrl.source + aReply.reply_user_info.profile;
							aComment.reply.push({
								id : aReply.id
								,content : aReply.content
								,time : aReply.create_time
								,user : aReply.user_info
								,reply_user : aReply.reply_user_info
							});
						}

						aCommentList.push(aComment);
					}
					oEvent.data('aCommentList', aCommentList);
					fShowShuoShuoComment(aCommentList);
				}
				,error : function(){
					oBtnShowAllComment.text('展开全部评论');
				}
			});
		});

		/**
		 * 查看所有说说评论回复操作
		 */
		oWrap.delegate('[xid="btnShowAllReply"]', 'click', function(){
			var oComment = $(this).closest('[xid="comment"]')
			,oBtnShowAllReply = $(this);
			ajax({
				url : aUrl.getAllShuoShuoCommentReply
				,data : {id : oComment.attr('itemid')}
				,beforeSend : function(){
					oBtnShowAllReply.text('加载中...');
				}
				,success : function(aResult){
					if(aResult.status  == 0){
						UBox.show(aResult.msg, 0);
						oBtnShowAllReply.text('展开全部回复');
						return;
					}

					var aReplys = [];
					for(var i in aResult.data){
						var aTmpReply = aResult.data[i];
						aTmpReply.user_info.profile = aUrl.source + aTmpReply.user_info.profile;
						aTmpReply.reply_user_info.profile = aUrl.source + aTmpReply.reply_user_info.profile;
						var aReply = {
							id : aTmpReply.id
							,content : aTmpReply.content
							,time : aTmpReply.create_time
							,user : aTmpReply.user_info
							,reply_user : aTmpReply.reply_user_info
						};
						aReplys.push(_buildShuoShuoReply(aReply, false, aCurrentUser.id));
					}
					oComment.find('[xid="wrapReplys"]').html(aReplys.join(''));
				}
				,error : function(){
					oBtnShowAllReply.text('展开全部回复');
				}
			});
		});

		/**
		 * 查看说说图片
		 */
		oWrap.delegate('[xid="shuoshuoImage"]', 'click', function(){
			return true;
			popEasyDialog({
				title : '查看说说图片'
				,width : 800
				,height : 600
				,content : '<img src="' + $(this).attr('href') + '" />'
				,cancleCallBack : $.noop
				,btnNoText : '关闭'
			});
			return false;
		});

		var fShowAddFriend = function(){
			UAlert.config({
				user_id : $(this).closest('[xid="user"]').attr('itemid')
				,sys_resource_url : aUrl.source
				,user_info_url : aUrl.userInfo
				,user_home_url : aUrl.userHome
				,apply_friend_url : aUrl.applyFriend
			});
			UAlert.alertApplyFriend();
		};
		oWrap.delegate('[xid="btnAddFriend"]', 'click', fShowAddFriend);

		/**
		 * 查看更多事件相关用户
		 */
		oWrap.delegate('[xid="btnShowMoreUser"]', 'click', function(){
			var oEvent =_getEventDomByElement(this)
			,oBtnShowMoreUser = $(this)
			,eventId = oEvent.attr('itemid')
			,dataType = oEvent.attr('data-type')
			,type = 0
			,aEvent = oEvent.data('aEvent')
			,aNoShowUserIds = [];
			if(oLastMoreUserList && oLastMoreUserList.attr('itemid') == eventId){
				if(oBtnShowMoreUser.data('isShow')){
					oLastMoreUserList.remove();
					$('[xid="btnShowMoreUser"]').removeClass('cur');
					oLastMoreUserList = null;
					oBtnShowMoreUser.data('isShow', false);
				}
				return;
			}else if(oLastMoreUserList){
				oLastMoreUserList.remove();
				$('[xid="btnShowMoreUser"]').removeClass('cur');
				oLastMoreUserList = null;
			}

			var fGetUserId = function(aUserList){
				var aResult = [];
				for(var i in aUserList){
					aResult.push(aUserList[i].id);
				}
				return aResult;
			};

			//确认要读取的用户列表类型和不要显示的用户列表
			if(JsTools.inArray(dataType, [
				,self.TYPE.SHUO_SHUO
				,self.TYPE.SHARE_MATCH
			])){
				type = 1;
				aNoShowUserIds = $.merge(aNoShowUserIds, fGetUserId(aEvent.support));
			}else if(dataType == self.TYPE.JOIN_MATCH){
				type = 2;
				aNoShowUserIds = fGetUserId(aEvent.users);
			}else if(dataType == self.TYPE.FINISH_MATCH){
				type = 3;
				aNoShowUserIds = fGetUserId(aEvent.users);
			}else if(dataType == self.TYPE.REJOIN_MATCH){
				type = 4;
				aNoShowUserIds = fGetUserId(aEvent.users);
			}else if(dataType == self.TYPE.GET_AWARD){
				type = 5;
				aNoShowUserIds = fGetUserId(aEvent.users);
			}else{
				UBox.show('错误的事件类型！');
				return;
			}

			var fShowMoreUsers = function(aUserList){
				var aMoreUserList = [];
				for(var i in aUserList){
					var aUser = aUserList[i];
					aMoreUserList.push('<li xid="user" itemid="' + aUser.id + '">\
						' + _buildUser(aUser) + '\
						<p class="pub">\
							<span class="name ellipsis"><a href="#">' + getVipName(aUser.name, aUser.vip) + '</a></span>\
							<span class="part ellipsis">' + (aUser.gender > 0 ? ['男', '女'][aUser.gender - 1] : '') + ' ' + (aUser.age ? aUser.age + '岁' : '') + ' ' + aUser.province + aUser.city + '</span>\
						</p>\
						' + (aUser.is_friend ? '' : '<p class="follow">\
							<a class="act" href="javascript:void(0);" xid="btnAddFriend">\
								<i class="ico_event ico_event_add"></i>\
								好友\
							</a>\
						</p>') + '\
					</li>');
				}

				var oMoreUserList = $('<div class="event_pop" itemid="' + eventId + '">\
					<i class="arrow arrow_top"></i>\
					<i class="arrow arrow_top2"></i>\
					<a class="close" xid="btnCloseMoreUser" href="javascript:;">&#10005;</a>\
					<h2 class="title">赞过的人</h2>\
					<ul class="list">' + aMoreUserList.join('') + '</ul>\
				</div>').appendTo('body');
				oMoreUserList.find('[xid="btnCloseMoreUser"]').click(function(){
					oBtnShowMoreUser.removeClass('cur');
					oMoreUserList.hide(100);
					oLastMoreUserList = null;
				});
				oMoreUserList.find('[xid=btnAddFriend]').click(fShowAddFriend);

				var left = oBtnShowMoreUser.offset().left;
				var top = oBtnShowMoreUser.offset().top + oBtnShowMoreUser.height() + 10;
				oBtnShowMoreUser.addClass('cur').data('isShow', true);
				oMoreUserList.show(100).css({
					'left': left
					,'top': top
				});
				oLastMoreUserList = oMoreUserList;
			};

			var aMoreUserList = oEvent.data('aMoreUserList');
			if(aMoreUserList){
				fShowMoreUsers(aMoreUserList);
				return;
			}

			ajax({
				url : aUrl.moreUserList
				,data : {
					type : type
					,dataId : oEvent.attr('data-dataId')
					,aNoShowUserIds : aNoShowUserIds
				}
				,success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return;
					}else if(aResult.data.length == 0){
						return;
					}

					oEvent.data('aMoreUserList', aResult.data);
					fShowMoreUsers(aResult.data);
				}
			});
		});

		/**
		 * 赞兑换商品
		 */
		oWrap.delegate('[xid="btnSupportGoods"]', 'click', function(){
			var $oSupportCount = $(this).find('[xid="supportCount"]')
			,aEvent = $oSupportCount.closest('div[xid="event"]').data('aEvent');
			if($oSupportCount.data('is_supported')){
				UBox.show('您已经赞过一次了哦^-^', -1);
				return false;
			}

			ajax({
				url : aUrl.supportGoods
				,data : {goodsId : aEvent.goods.id}
				,success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return false;
					}
					$oSupportCount.text(parseInt(aEvent.goods.support) + 1).data('is_supported', true);
				}
			});
			return false;
		});
	}
})(jQuery, window);