(function(){
	window.CharInputer = {
		option : {
			title : '拼音元音音标输入器'
			,width : 255
			,height : 90
			,confirmCallBack : null
			,subject : 1
			,isOverlay : true
			,closeOnMouseout : true
		},

		isInjectCss : false,

		/**
		 * 初始化
		 */
		init : function(option){
			_initConfig(option);
			if(this.option.subject == 2){
				this.option.title = '数学符号输入器';
				this.option.width = 410;
				this.option.height = 95;
			}
			if(!this.isInjectCss){
				_initStyle();
				this.isInjectCss = true;
			}
		},

		/**
		 * 显示插件
		 */
		show : function(aOption){
			var $oEasyDialog = $('#easyDialogBox');
			if($oEasyDialog.length && $oEasyDialog.is(':visible')){
				return;
			}
			
			var showContentHTML = this.buildSelectorHTML();
			
			var option = {
				title : this.option.title
				,width : this.option.width
				,height : this.option.height
				,isOverlay : this.option.isOverlay
				,content : showContentHTML
			};
			
			if(aOption){				
				if(aOption.isOverlay !== undefined){
					option.isOverlay = aOption.isOverlay;
				}

				if(aOption.followElement && aOption.followElement.length){
					option.follow = aOption.followElement[0];
					option.followX = aOption.followOffsetX;
					option.followY = aOption.followOffsetY;
				}
			}
			
			_popDialog(option);
			
			var $oWrapCharInputer = $('#wrapCharInputer');
			$oWrapCharInputer.delegate('[xid="charItem"]', 'click', function(){
				var char = this.innerHTML;
				if(self.option.confirmCallBack != undefined){
					self.option.confirmCallBack(char);
				}else{
					_confirmCallBack(char);
				}
				easyDialog.close();
			});
			
			if(self.option.closeOnMouseout){
				$oWrapCharInputer.parent().mouseleave(function(){
					easyDialog.close();
				});
			}
		},

		/**
		 * 构建插件视图
		 */
		buildSelectorHTML : function(){
			var aCharGroupList = [];
			if(this.option.subject == 1){
				aCharGroupList = [
					['ā', 'á', 'ǎ', 'à', 'ō', 'ó', 'ǒ', 'ò'],
					['ē', 'é', 'ě', 'è', 'ī', 'í', 'ǐ', 'ì'],
					['ū', 'ú', 'ǔ', 'ù', 'ü', 'ǖ', 'ǘ', 'ǚ', 'ǜ']
				];
			}else if(this.option.subject == 2){
				aCharGroupList = [
					['+', '-', '×', '÷', '±', '≠', '＜', '＞', '≤', '≥', '≌', '≈', '°', '∽', '′', '″', '℃', '%', '•', 'π', 'α', 'β', 'γ', 'Ω', '⊥', '∥', '∠', '⊙', '⊕', '⊗', '△', '□', '▱', '√', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩'],
				];
			}

			var contentHtml = '';
			for(var i in aCharGroupList){
				var itemsHtml = '';
				for(var j in aCharGroupList[i]){
					itemsHtml += '<a class="charItem" xid="charItem" href="javascript:void(0);">' + aCharGroupList[i][j] + '</a>';
				}
				contentHtml += '<p>' + itemsHtml + '</p>';
			}
			contentHtml = '<div id="wrapCharInputer">' + contentHtml + '</div>';
			return contentHtml;
		}
	};
	
	var self = window.CharInputer;

	/**
	 * 初始化配置
	 */
	function _initConfig(option){
		for(var key in option){
			if(self.option[key] !== undefined){
				self.option[key] = option[key];
			}
		}
	}

	/**
	 * 弹出选择框
	 */
	function _popDialog(option){
		var aOption = {
			container : {
				width : option.width,
				height : option.height,
				header : option.title,
				content : option.content
			},
			overlay : option.isOverlay,
			followX : -100,
			drag : true
		};
		
		for(var key in {follow : 0, followX : 0, followY : 0}){
			if(option[key] !== undefined){
				aOption[key] = option[key];
			}
		}
		
		easyDialog.open(aOption);
		
		$('#easyDialogWrapper').css('height', 'auto').find('.easyDialog_footer').remove();
	}

	/**
	 * 初始化样式
	 */
	function _initStyle(){
		$('head').append('<style type="text/css">\n\
#wrapCharInputer{padding:0 15px;}\n\
#wrapCharInputer .charItem{display:inline-block; width:25px; font-size:16px !important; text-align:center;}\
#wrapCharInputer .charItem:hover{background:#2A7EA9; color:#FFF; text-decoration:none;}\
#wrapCharInputer p{height:30px; line-height:30px;}\
#wrapCharInputer input,#wrapCharInputer label{cursor:pointer;}\
#wrapCharInputer label{padding:0}\
</style>');
	}

	/**
	 * 默认的确定回调
	 */
	function _confirmCallBack(char){
		if(window.lastActiveObject === undefined || window.lastActiveObject == null){
			return;
		}
		var oInput = lastActiveObject;
		var lStr = oInput.value.slice(0, oInput.selectionStart),
		rStr = oInput.value.slice(oInput.selectionEnd, oInput.value.length);
		oInput.value = lStr + char + rStr;
		oInput.selectionStart = lStr.length + 1;
		oInput.selectionEnd = lStr.length + 1;
		oInput.focus();
		return true;
	}
})
(jQuery);