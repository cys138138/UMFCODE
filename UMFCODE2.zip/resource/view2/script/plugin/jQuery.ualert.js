(function($, window){
	window.UAlert = {
		aConfig : {
			user_id : 0,
			user_info_url : '',
			user_home_url : '',
			user_list_url : '',
			apply_friend_url : '',
			send_message_url : '',
			reply_message_url : '',
			send_pk_url : '',
			forward_shuoshuo_url : '',
			share_url : '',
			sys_resource_url : '',
			user_info : {},
			callback : function(){}
		},

		/**
		 * 设置配置参数
		 */
		config : function(aSetConfig){
			for(var key in aSetConfig){
				if(this.aConfig[key] !== undefined){
					this.aConfig[key] = aSetConfig[key];
				}
			}
		},

		RESULT_DATA : {},
		MEMORY_DATA : {},

		LEVEL_VALUE : 0,
		ACCUMULATE_VALUE : 0,
		GOLD_VALUE : 0,
		UB_VALUE : 0,
		MEDAL_VALUE : 0,
		MEDAL_LEVEL_VALUE : 0,
		TOY_VALUE : 0,
		FAVOURATE_VALUE : 0,
		ERROR_VALUE : 0,

		SHOW_TYPE : {
			TASKCOMPLETE : 'TASKCOMPLETE',			// 修练成功
			MISSIONSUCCESS : 'MISSIONSUCCESS',		// 闯关挑战成功
			MISSIONFAILD : 'MISSIONFAILD',			// 闯关挑战失败
			ACCEPTMATCHPRIZE : 'ACCEPTMATCHPRIZE',	// 领取比赛奖励
			PKWIN : 'PKWIN',						// PK赢了
			PKLOST : 'PKLOST',						// PK输了
			SIGNSUCCESS : 'SIGNSUCCESS',			// 签到成功
			GUIDTASKCOMPLETE : 'GUIDTASKCOMPLETE',	// 新手任务完成
			LIMITCAPTCHA : 'LIMITCAPTCHA'			// 输入验证码
		},

		NUMERICAL_TYPE : {
			LEVEL : 'level',						// 用户等级
			ACCUMULATE : 'accumulate',				// 经验
			GOLD : 'gold',							// 金币
			UB : 'ub',								// U币
			MEDAL : 'medal',						// 勋章
			MEDAL_LEVEL : 'medal_level',			// 勋章等级
			TOY : 'toy',							// 道具
			FAVOURATE : 'fav',						// 题目收藏
			ERROR : 'error'							// 题目错题
		},

		show : function(data){
			this.RESULT_DATA = data;
			this.analysisData(data);
			this.alertBox(data);
			this.topAlert(data);
			this.numPop();
			this.clearData();
			return ;
		},

		clearData : function(){
			this.LEVEL_VALUE = 0;
			this.ACCUMULATE_VALUE = 0;
			this.GOLD_VALUE = 0;
			this.UB_VALUE = 0;
			this.MEDAL_VALUE = 0;
			this.MEDAL_LEVEL_VALUE = 0;
			this.TOY_VALUE = 0;
			this.FAVOURATE_VALUE = 0;
			this.ERROR_VALUE = 0;
		},

		analysisData : function(data){
			if(typeof(data.numerical_data) != 'undefined'){
				for(var key in data.numerical_data){
					var oAccumulate = $('#accumulate').length ? $('#accumulate') : $(window.parent.document).find('#accumulate');
					var oGold = $('#gold').length ? $('#gold') : $(window.parent.document).find('#gold');
					if(key == this.NUMERICAL_TYPE.LEVEL){
						this.LEVEL_VALUE = data.numerical_data[key];
						$('#level').text(data.numerical_data[key]);
					}else if(key == this.NUMERICAL_TYPE.ACCUMULATE){
						if(oAccumulate.length == 0){
							if(typeof(data.custom_data) != 'undefined' && typeof(data.custom_data.add_accumulate_points) != 'undefined'){
								this.ACCUMULATE_VALUE = parseInt(data.custom_data.add_accumulate_points);
							}else{
								this.ACCUMULATE_VALUE = 0;
							}
						}else{
							this.ACCUMULATE_VALUE = parseInt(data.numerical_data[key]) - parseInt(oAccumulate.text());
							oAccumulate.text(data.numerical_data[key]);
						}
					}else if(key == this.NUMERICAL_TYPE.GOLD){
						this.GOLD_VALUE = parseInt(data.numerical_data[key]) - parseInt(oGold.text());
						oGold.text(data.numerical_data[key]);
					}else if(key == this.NUMERICAL_TYPE.UB){
						this.UB_VALUE = parseInt(data.numerical_data[key]) - parseInt($('#ub').text());
						$('#ub').text(data.numerical_data[key]);
					}else if(key == this.NUMERICAL_TYPE.MEDAL){
						this.MEDAL_VALUE = parseInt(data.numerical_data[key]) - parseInt($('#medal').text());
						$('#medal').text(data.numerical_data[key]);
					}else if(key == this.NUMERICAL_TYPE.MEDAL_LEVEL){
						this.MEDAL_LEVEL_VALUE = data.numerical_data[key];
					}else if(key == this.NUMERICAL_TYPE.TOY){
						this.TOY_VALUE = parseInt(data.numerical_data[key]) - parseInt($('#toy').text());
						$('#toy').text(data.numerical_data[key]);
					}else if(key == this.NUMERICAL_TYPE.FAVOURATE){
						this.FAVOURATE_VALUE = parseInt(data.numerical_data[key]) - parseInt($('#favourate').text());
						$('#favourate').text(data.numerical_data[key]);
					}else if(key == this.NUMERICAL_TYPE.ERROR){
						this.ERROR_VALUE = parseInt(data.numerical_data[key]) - parseInt($('#error').text());
						$('#error').text(data.numerical_data[key]);
					}else{
						$.error('error numerical type');
					}
				}
			}
		},

		// 修练成功
		alertTaskComplete : function(){
			var time = this.RESULT_DATA.custom_data.time,
			correctRate = this.RESULT_DATA.custom_data.correct_rate,
			//score = this.RESULT_DATA.custom_data.score,
			addAccumulatPoints = 0;

			if(typeof(this.RESULT_DATA.custom_data.add_accumulate_points) == 'undefined'){
				addAccumulatPoints = 0;
			}else{
				addAccumulatPoints = this.RESULT_DATA.custom_data.add_accumulate_points;
			}

			this.ACCUMULATE_VALUE = parseInt(addAccumulatPoints);
			var htmlStr = '\
				<div id="taskCompleteDialog" class="dialog_mod">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('恭喜完成本关修炼！', 1) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>修炼完成时间：<b>' + date('n月j日 H:i:s', time) + '</b></p>\
							<p>修炼正确率：<b>' + correctRate + '%</b></p>\
							<p>奖励经验：<em>' + correctRate + '%*50 = </em><b>' + addAccumulatPoints + '分</b></p>\
						</div>\
					</div>\
					<div class="dialog_fd">\
						' + this.buildFooterHtml() + '\
					</div>\
					<div class="btn_dialog">\
						<a href="javascript:;" id="choujiang" class="hidetxt_2 btn_dialog_bg btn_dialog_turn">立即抽奖</a>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			this.dialogBox($('#taskCompleteDialog'));
		},

		// 闯关挑战成功
		alertMissionSuccess : function(){
			var worldRecordHtml = '',
			personalRecordHtml = '',
			accumulateHtml = '',
			time = this.RESULT_DATA.custom_data.time,
			correctRate = this.RESULT_DATA.custom_data.correct_rate,
			wrongEsCount = this.RESULT_DATA.custom_data.wrong_es_count,
			spandTime = this.RESULT_DATA.custom_data.spand_time,
			//challengeCount = this.RESULT_DATA.custom_data.challenge_count,
			score = this.RESULT_DATA.custom_data.score,
			bestScore = this.RESULT_DATA.custom_data.best_score,
			missionCorrectRate = this.RESULT_DATA.custom_data.mission_correct_rate,
			addAccumulatePoints = 0,
			inFriendRanking = this.RESULT_DATA.custom_data.in_friend_ranking,
			missionMedalHtml = '',
			missionDecorationHtml = '',
			lotteryDrawHtml = '';

			if(typeof(this.RESULT_DATA.custom_data.add_accumulate_points) == 'undefined'){
				addAccumulatePoints = 0;
			}else{
				addAccumulatePoints = this.RESULT_DATA.custom_data.add_accumulate_points;
			}
			this.ACCUMULATE_VALUE = parseInt(addAccumulatePoints);
			if(typeof(this.RESULT_DATA.custom_data.world_record) != 'undefined'){
				worldRecordHtml = '<p><i class="ico_dialog ico_dialog_prompt"></i>破本关纪录：超纪录<b>' + this.RESULT_DATA.custom_data.world_record + '</b>分</p>';
			}
			if(typeof(this.RESULT_DATA.custom_data.personal_record) != 'undefined'){
				personalRecordHtml = '<p><i class="ico_dialog ico_dialog_prompt"></i>破自己纪录：超纪录<b>' + this.RESULT_DATA.custom_data.personal_record + '</b>分</p>';
			}

			if(typeof(this.RESULT_DATA.custom_data.lottery_draw) != 'undefined'){
				lotteryDrawHtml = '<div class="start_pk"><a href="javascript:;" id="choujiang">立即抽奖</a></div>';
			}

			/*if(typeof(addAccumulatePoints) != 'undefined' && (typeof(this.RESULT_DATA.custom_data.world_record) != 'undefined' || typeof(this.RESULT_DATA.custom_data.personal_record) != 'undefined')){
				accumulateHtml = '<p>奖励经验：<b>' + addAccumulatePoints + '分</b></p>';
			}else if(typeof(addAccumulatePoints) != 'undefined'){
				//accumulateHtml = '<p>奖励经验：<em>' + missionCorrectRate + '%*80+(900+' + spandTime + ')/900*20% = </em><b>' + addAccumulatePoints + '分</b></p>';
				accumulateHtml = '<p>奖励经验：<em>(答题得分 + 答题用时得分) = </em><b>' + addAccumulatePoints + '分</b></p>';
			}*/

			spandTime = parseInt(parseInt(spandTime) / 60) + '分' + (parseInt(spandTime) % 60);

			var htmlStr = '\
				<div id="missionSuccessDialog" class="dialog_mod_big">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('恭喜挑战成功！', 1) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="prompt fr">\
							' + personalRecordHtml + '\
							' + worldRecordHtml + '\
						</div>\
						<div class="list">\
							<p>挑战时间：<b>' + date('n月j日 H:i:s', time) + '</b></p>\
							<p>挑战正确率：<b>' + correctRate + '%</b></p>\
							<p>耗血：<b>' + wrongEsCount + '</b></p>\
							<p>耗时：<b>' + spandTime + '秒</b></p>\
							<p>挑战分数：<b>' + score + '分</b></p>\
							<p>在好友中排名：<b>第' + inFriendRanking + '名</b></p>\
							<p>最高记录分数：<b>' + bestScore + '分</b><span class="tip">温馨提示：时间越短，正确率越高</span></p>\
							<p>本关总正确率： <em>' + missionCorrectRate + '%</em></p>\
							' + accumulateHtml + '\
						</div>\
					</div>\
					<div class="dialog_fd">\
						' + this.buildFooterHtml() + '\
					</div>\
					<div class="btn_dialog">\
						<a href="' + UAlert.aConfig.send_pk_url + '" class="hidetxt_2 btn_dialog_bg btn_dialog_pk">马上PK</a>\
						<a href="javascript:;" id="choujiang" class="hidetxt_2 btn_dialog_bg btn_dialog_turn">立即抽奖</a>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			this.dialogBox($('#missionSuccessDialog'));
		},

		// 闯关挑战失败
		alertMissionFaild : function(){
			var time = this.RESULT_DATA.custom_data.time,
			//correctRate = this.RESULT_DATA.custom_data.correct_rate,
			//wrongEsCount = this.RESULT_DATA.custom_data.wrong_es_count,
			//spandTime = this.RESULT_DATA.custom_data.spand_time,
			//challengeCount = this.RESULT_DATA.custom_data.challenge_count,
			score = 0,
			bestScore = this.RESULT_DATA.custom_data.best_score,
			missionCorrectRate = this.RESULT_DATA.custom_data.mission_correct_rate;
			//addAccumulatePoints = this.RESULT_DATA.custom_data.add_accumulate_points;

			var htmlStr = '\
				<div id="missionFaildDialog" class="dialog_mod dialog_mod_fail">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('很遗憾，挑战失败！', 0) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>挑战时间：<b>' + date('n月j日 H:i:s', time) + '</b></p>\
							<p>挑战得分：<b>' + score + '分</b></p>\
							<p>最高记录：<b>' + bestScore / 100 + '分</b></p>\
							<p>本关总正确率： <em>' + missionCorrectRate + '%</em></p>\
						</div>\
					</div>\
					<div class="dialog_fd"></div>\
				</div>\
			';
			$('body').append(htmlStr);
			this.dialogBox($('#missionFaildDialog'));
		},

		// 比赛领奖
		alertAcceptMatchPrizeWin : function(){
			var matchName = this.RESULT_DATA.custom_data.match_name,
			bestScore = this.RESULT_DATA.custom_data.best_score,
			ranking = this.RESULT_DATA.custom_data.ranking,
			bestScoreTime = this.RESULT_DATA.custom_data.best_score_time;

			var htmlStr = '\
				<div id="acceptMatchPrizeWinDialog" class="dialog_mod">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('比赛奖励！', 1) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>赛事名称：<b>' + matchName + '</b></p>\
							<p>参赛时间：<b>' + date('n月j日 H:i:s', bestScoreTime) + '</b></p>\
							<p>比赛得分：<b>' + bestScore + '</b></p>\
							<p>得分排名：<b>' + ranking + '</b></p>\
						</div>\
					</div>\
					<div class="dialog_fd">\
						' + this.buildFooterHtml() + '\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			this.dialogBox($('#acceptMatchPrizeWinDialog'));
		},

		// PK赢了
		alertPkWin : function(){
			var time = this.RESULT_DATA.custom_data.time,
			sender = this.RESULT_DATA.custom_data.sender,
			receiver = this.RESULT_DATA.custom_data.receiver,
			senderFinishedTime = this.RESULT_DATA.custom_data.sender_finished_time,
			receiverFinishedTime = this.RESULT_DATA.custom_data.receiver_finished_time,
			senderCorrectCount = this.RESULT_DATA.custom_data.sender_correct_count,
			receiverCorrectCount = this.RESULT_DATA.custom_data.receiver_correct_count,
			senderScore = this.RESULT_DATA.custom_data.sender_score,
			receiverScore = this.RESULT_DATA.custom_data.receiver_score,
			senderSpandTime = this.RESULT_DATA.custom_data.sender_spand_time,
			receiverSpandTime = this.RESULT_DATA.custom_data.receiver_spand_time,
			gold = this.RESULT_DATA.custom_data.gold,
			totalGold = parseInt(gold) * 2,
			addAccumulatePoints = this.RESULT_DATA.custom_data.add_accumulate_points;
			this.GOLD_VALUE = totalGold;
			var temp = '';
			if(senderScore < receiverScore){
				temp = senderCorrectCount;
				senderCorrectCount = receiverCorrectCount;
				receiverCorrectCount = temp;
				temp = senderSpandTime;
				senderSpandTime = receiverSpandTime;
				receiverSpandTime = temp;
			}

			var htmlStr = '\
				<div id="pkWinDialog" class="dialog_mod_big">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('赢得本场PK的胜利！', 1) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>PK发起时间：<b>' + date('n月j日 H:i:s', time) + '</b></p>\
							<p>发起人：' + sender + '（' + senderFinishedTime + '）主场得分：' + senderScore + '</p>\
							<p>接受人：' + receiver + '（' + receiverFinishedTime + '）客场得分：' + receiverScore + '</p>\
						</div>\
						<div class="list">\
							<p>我答对' + senderCorrectCount + '题耗时' + senderSpandTime + '秒，对方答对' + receiverCorrectCount + '题耗时' + receiverSpandTime + '秒</p>\
							<p>奖励经验： <b>' + addAccumulatePoints + '分</b></p>\
							<p>PK金币：<b>' + gold + '金币</b></p>\
							<p>累计赢得：<b>' + totalGold + '金币</b></p>\
						</div>\
					</div>\
					<div class="dialog_fd">\
						' + this.buildFooterHtml() + '\
					</div>\
				</div>\
			';
			//$('body').append(htmlStr);
			$(window.parent.document).find('body').append(htmlStr);
			this.dialogBox($('#pkWinDialog'));
		},

		// PK输了
		alertPkLost : function(){
			var time = this.RESULT_DATA.custom_data.time,
			sender = this.RESULT_DATA.custom_data.sender,
			receiver = this.RESULT_DATA.custom_data.receiver,
			senderFinishedTime = this.RESULT_DATA.custom_data.sender_finished_time,
			receiverFinishedTime = this.RESULT_DATA.custom_data.receiver_finished_time,
			senderCorrectCount = this.RESULT_DATA.custom_data.sender_correct_count,
			receiverCorrectCount = this.RESULT_DATA.custom_data.receiver_correct_count,
			senderScore = this.RESULT_DATA.custom_data.sender_score,
			receiverScore = this.RESULT_DATA.custom_data.receiver_score,
			senderSpandTime = this.RESULT_DATA.custom_data.sender_spand_time,
			receiverSpandTime = this.RESULT_DATA.custom_data.receiver_spand_time,
			gold = this.RESULT_DATA.custom_data.gold;

			var temp = '';
			if(senderScore > receiverScore){
				temp = senderCorrectCount;
				senderCorrectCount = receiverCorrectCount;
				receiverCorrectCount = temp;
				temp = senderSpandTime;
				senderSpandTime = receiverSpandTime;
				receiverSpandTime = temp;
			}

			var htmlStr = '\
				<div id="pkLostDialog" class="dialog_mod dialog_mod_fail">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('很遗憾，本场PK失败', 0) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>PK发起时间：<b>' + date('n月j日 H:i:s', time) + '</b></p>\
							<p>发起人：' + sender + '（' + senderFinishedTime + '）主场得分：' + senderScore + '</p>\
							<p>接受人：' + receiver + '（' + receiverFinishedTime + '）客场得分：' + receiverScore + '</p>\
						</div>\
						<div class="list">\
							<p>我答对' + senderCorrectCount + '题耗时' + senderSpandTime + '秒，对方答对' + receiverCorrectCount + '题耗时' + receiverSpandTime + '秒</p>\
							<p>PK金币：<b>' + gold + '金币</b></p>\
						</div>\
					</div>\
				</div>\
			';
			//$('body').append(htmlStr);
			$(window.parent.document).find('body').append(htmlStr);
			this.dialogBox($('#pkLostDialog'));
		},

		// 签到成功
		alertSignSuccess : function(){
			var time = this.RESULT_DATA.custom_data.time,
			continueSign = this.RESULT_DATA.custom_data.continue_sign,
			nextDayGold = this.RESULT_DATA.custom_data.next_day_gold,
			gold = this.RESULT_DATA.custom_data.gold;
			this.GOLD_VALUE = this.RESULT_DATA.custom_data.gold;

			var htmlStr = '\
				<div id="signSuccessDialog" class="dialog_mod">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml('签到成功！', 1) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>签到时间：<b>' + date('n月j日 H:i:s', time) + '</b></p>\
							<p>已连续签到：<b>' + continueSign + '</b>天</p>\
							<p>奖励金币：' + gold + '</p>\
							<p>明日签到可获得金币：' + nextDayGold + '</p>\
						</div>\
						<div class="prompt">\
							<p><i class="ico_dialog ico_dialog_prompt"></i>连续签到<b>30</b>天以上，每日可获得<b>5</b>金币，加油！</p>\
						</div>\
					</div>\
					<div class="dialog_fd">\
						' + this.buildFooterHtml() + (parseInt(continueSign) >= 3 ? '<a href="javascript:; style="position: relative;display: block;width: 90px;text-align: center;background: #ff0000;color: #000000;top: -35px;left: 206px;" onclick="shareSignToClass();">分享到班圈</a>' : '') + '\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			this.dialogBox($('#signSuccessDialog'));
		},

		// 新手任务完成
		alertGuidTaskComplete : function(){
			refurbishTaskStatus();
			var taskName = this.RESULT_DATA.custom_data.task_name,
			addAccumulatePoints = this.RESULT_DATA.custom_data.add_accumulate_points,
			taskTotal = this.RESULT_DATA.custom_data.task_total,
			currentTaskIndex = this.RESULT_DATA.custom_data.current_task_index,
			headStr = '',
			footerStr = '',
			lotteryDrawHtml = '';
			if(currentTaskIndex != taskTotal){
				headStr = '新手任务完成' + currentTaskIndex + '/' + taskTotal + '！';
				footerStr = '还剩' + (parseInt(taskTotal) - parseInt(currentTaskIndex)) + '步即可完成全部新手任务，加油！';
			}else{
				headStr = '新手任务已全部完成！';
				footerStr = '恭喜您已成为熟手，接下来的路很长，就看你的了!';
			}

			if(typeof(this.RESULT_DATA.custom_data.lottery_draw) != 'undefined'){
				lotteryDrawHtml = '<div class="start_pk"><a href="javascript:;" id="choujiang">立即抽奖</a></div>';
			}

			var htmlStr = '\
				<div id="guidTaskCompleteDialog" class="dialog_mod">\
					<div class="dialog_hd">\
						' + this.buildHeaderHtml(headStr, 1) + '\
					</div>\
					<div class="dialog_bd">\
						<div class="list">\
							<p>已完成新手任务：' + taskName + '</p>\
							<p>奖励经验： <b>' + addAccumulatePoints + '分</b></p>\
						</div>\
						<div class="prompt">\
							<p><i class="ico_dialog ico_dialog_prompt"></i>' + footerStr + '</p>\
						</div>\
					</div>\
					<div class="dialog_fd">\
						' + this.buildFooterHtml() + '\
						' + lotteryDrawHtml + '\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			this.dialogBox($('#guidTaskCompleteDialog'));
		},

		alertCaptcha : function(title){
			var oUalert = this,
			isLogin = oUalert.RESULT_DATA.custom_data.__limit_type__ == 'LOGIN';
			if(isLogin){
				$('#verify_item').show();
				showLoginTips(oUalert.RESULT_DATA.custom_data.__msg__);
				return;
			}
			$('[xid=showAlertWindowId]').fadeOut();
			$('[xid=showAlertWindowId]').remove();
			if(!title){
				title = '操作过于频繁，请输入验证码';
			}
			var htmlStr = '\
				<div id="CaptchaDialog" class="profile_pop profile_often_pop" xid="showAlertWindowId">\
					<div class="hd">\
						<h2>' + title + '</h2>\
						<span class="follow"><a class="close" href="javascript:;" title="关闭">&#10005;</a></span>\
					</div>\
					<div class="bd c">\
						<div class="cont">\
							<p class="item">\
								<a href="javascript:;" class="checkcode_btn" onclick="UAlert.refreshCaptcha();" title="刷新验证码"><img class="checkcode" id="verify_Img" src="http://' + window.location.host + '/captcha/limitCaptcha/?' + Math.floor(Math.random() * 10000) + '" height="30" width="85" alt="" /> 看不清，刷新验证码</a>\
							</p>\
							<p class="textbox"><input class="text" type="text" name="captcha" id="limitCaptcha" /></p>\
							<p class="btnbox">\
								<span class="error fl" xid="limitErrorMsg"></span>\
								<button class="btn_069" onclick="UAlert.submitCaptcha();">确定</button>\
							</p>\
						</div>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			$('[xid=limitErrorMsg]').html(oUalert.RESULT_DATA.custom_data.__msg__);
			oUalert.showAlertWindow($('#CaptchaDialog'));
			oUalert.refreshCaptcha();
		},

		refreshCaptcha : function(){
			var captchaUrl = 'http://' + window.location.host + '/captcha/limitCaptcha/?' + Math.floor(Math.random() * 10000);
			$('#verify_Img').attr('src', captchaUrl);
			$('#limitCaptcha').val('');
		},

		submitCaptcha : function(){
			var oUalert = this,
			limitCaptcha = $('#limitCaptcha').val(),
			isApplyFriend = oUalert.RESULT_DATA.custom_data.__limit_type__ == 'APPLY_FRIEND',
			isDeleteFriend = oUalert.RESULT_DATA.custom_data.__limit_type__ == 'DELETE_FRIEND',
			isLogin = oUalert.RESULT_DATA.custom_data.__limit_type__ == 'LOGIN',
			isActiveEmail = oUalert.RESULT_DATA.custom_data.__limit_type__ == 'sendActiveEmail';
			if(limitCaptcha.length == 0 || limitCaptcha.length != 5){
				if(!isApplyFriend){
					UBox.show('输入的验证码长度不正确!', -1);
				}
				return;
			}
			oUalert.RESULT_DATA.custom_data.limit_captcha = limitCaptcha;
			if(!isActiveEmail){
				$('#CaptchaDialog').fadeOut();
				$('#dialogBoxMask').fadeOut();
			}
			ajax({
				url : oUalert.RESULT_DATA.custom_data.__post_url__,
				data : oUalert.RESULT_DATA.custom_data,
				success : function(aResult){
					if(isApplyFriend){
						oUalert.alertApplyFriend();
						var htmlStr = '';
						if(aResult.status > 0){
							UAlert.aConfig.callback(aResult);
							var resultClass = 'ico_succ';
						}else{
							var resultClass = 'ico_fail';
						}
						htmlStr = '<p class="prompt"><i class="ico ' + resultClass + '"></i>' + aResult.msg + '</p><p class="btnbox"><button class="btn_069" onclick="UAlert.closeApplyFriendWin();" >关闭</button></p>';
						$('#applyFriendDialogBody').html(htmlStr);
						return;
					}
					if(isActiveEmail){
						if(aResult.status == 1){
							$('#CaptchaDialog').remove();
						}else{
							$('[xid=limitErrorMsg]').html(aResult.msg);
						}
						UAlert.aConfig.callback(aResult);
						return;
					}
					UBox.show(aResult.msg, aResult.status);
					if(isLogin && aResult.status == 1){
						location.href = aResult.data;
					}
					if(isDeleteFriend){
						if(aResult.status == 1){
							deleteFrindCallBack(aResult);
						}
					}
				}
			});
		},

		alertReplyMessage : function(parentId, userId, callBack){
			$('#SendMessageDialog').fadeOut();
			$('#SendMessageDialog').remove();
			$('[xid=showAlertWindowId]').fadeOut();
			$('[xid=showAlertWindowId]').remove();
			var htmlStr = '\
				<div id="SendMessageDialog" class="profile_pop" xid="showAlertWindowId">\
					<div class="hd">\
						<h2>回复留言</h2>\
						<span class="follow"><a class="close" href="javascript:;" title="关闭">&#10005;</a></span>\
					</div>\
					<div style="padding: 2px 10px;">\
						<div id="ualertSendMessageEditor"></div>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);

			var oEditor = UMeEditor.getInstance({
				oContext : $('#ualertSendMessageEditor'),
				imageBaseUrl : UAlert.aConfig.sys_resource_url,
				submitCaption : '回复',
				onSubmit : function(){
					var contentLength = oEditor.getContentLength();
					if(contentLength < 1 || contentLength > 150){
						UBox.show('回复内容为1到150个字符长度', -1);
						reutrn;
					}

					ajax({
						url : UAlert.aConfig.reply_message_url,
						data : {
							parent_id : parentId,
							user_id : userId,
							content : oEditor.getContent(),
							at_user_ids : oEditor.getAtUserIdList()
						},
						success : function(aResult){
							UBox.show(aResult.msg, aResult.status);
							if(aResult.status == 1 && typeof(callBack) != 'undefined'){
								callBack();
							}
						}
					});
				}
			});
			UAlert.showAlertWindow($('#SendMessageDialog'));
		},

		alertForwardShuoShuo : function(shuoShuoId, type, callBack){
			$('#ForwardShuoShuoDialog').fadeOut();
			$('#ForwardShuoShuoDialog').remove();
			$('[xid=showAlertWindowId]').fadeOut();
			$('[xid=showAlertWindowId]').remove();
			var htmlStr = '\
				<div id="ForwardShuoShuoDialog" class="profile_pop" xid="showAlertWindowId">\
					<div class="hd">\
						<h2>转发说说</h2>\
						<span class="follow"><a class="close" href="javascript:;" title="关闭">&#10005;</a></span>\
					</div>\
					<div style="padding: 4px 15px;">\
						<label id="btnuSubmitAlertForwardShuoShuoEditor" style="margin: 3px 0;">同时评论&nbsp;&nbsp;<input type="checkbox" id="ualertTongshipinglun" checked /></label>\
						<div id="ualertForwardShuoShuoEditor" style="margin-top: 5px;"></div>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);

			var oEditor = UMeEditor.getInstance({
				oContext : $('#ualertForwardShuoShuoEditor'),
				imageBaseUrl : UAlert.aConfig.sys_resource_url,
				userList : true,
				userListUrl : UAlert.aConfig.user_list_url,
				aFace : ['qq'],
				submitCaption : '转发',
				onSubmit : function(){
					var contentLength = oEditor.getContentLength();
					if(contentLength < 1 || contentLength > 150){
						UBox.show('转发内容为1到150个字符长度', -1);
						reutrn;
					}

					ajax({
						url : UAlert.aConfig.forward_shuoshuo_url,
						data : {
							source_id : shuoShuoId,
							source_type : type,
							is_comment_source : $('#ualertTongshipinglun')[0].checked ? 1 : 0,
							content : oEditor.getContent(),
							at_user_ids : oEditor.getAtUserIdList()
						},
						success : function(aResult){
							UBox.show(aResult.msg, aResult.status);
							if(aResult.status == 1){
								$('#ForwardShuoShuoDialog').fadeOut(function(){
									$(this).remove();
								});
								if(typeof(callBack) != 'undefined'){
									callBack();
								}
							}
						}
					});
				}
			});
			UAlert.showAlertWindow($('#ForwardShuoShuoDialog'));
		},

		closeForwardShuoShuo : function(){
			$('#ForwardShuoShuoDialog').fadeOut();
			$('#ForwardShuoShuoDialog').remove();
		},

		alertShare : function(shareId, type, defaultContent, callBack){
			$('#alertShareDialog').fadeOut();
			$('#alertShareDialog').remove();
			$('[xid=showAlertWindowId]').fadeOut();
			$('[xid=showAlertWindowId]').remove();
			var htmlStr = '\
				<div id="alertShareDialog" class="profile_pop" xid="showAlertWindowId">\
					<div class="hd">\
						<h2>分享</h2>\
						<span class="follow"><a class="close" href="javascript:;" title="关闭">&#10005;</a></span>\
					</div>\
					<div style="padding: 2px 10px;">\
						<div id="ualertShareEditor"></div>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);

			var oEditor = UMeEditor.getInstance({
				oContext : $('#ualertShareEditor'),
				imageBaseUrl : UAlert.aConfig.sys_resource_url,
				submitCaption : '分享',
				onSubmit : function(){
					var contentLength = oEditor.getContentLength();
					if(contentLength < 1 || contentLength > 150){
						UBox.show('分享内容为1到150个字符长度', -1);
						reutrn;
					}

					ajax({
						url : UAlert.aConfig.share_url,
						data : {
							source_id : shareId,
							source_type : type,
							content : oEditor.getContent(),
							defaultContent : defaultContent,
							at_user_ids : oEditor.getAtUserIdList()
						},
						success : function(aResult){
							UBox.show(aResult.msg, aResult.status);
							if(aResult.status == 1){
								$('#alertShareDialog').fadeOut(function(){
									$(this).remove();
								});
								if(typeof(callBack) != 'undefined'){
									callBack();
								}
							}
						}
					});
				}
			});
			UAlert.showAlertWindow($('#alertShareDialog'));
		},

		closeShare : function(){
			$('#alertShareDialog').fadeOut();
			$('#alertShareDialog').remove();
		},

		alertSendPk : function(){
			window.location.href = this.aConfig.send_pk_url.replace('_userId', this.aConfig.user_id);
		},

		alertSendMessage : function(){
			$('#sendMessageDialog').fadeOut();
			$('#sendMessageDialog').remove();
			$('[xid=showAlertWindowId]').fadeOut();
			$('[xid=showAlertWindowId]').remove();
			this.getUserInfo(this._appendSendMessage);
		},

		_appendSendMessage : function(){
			var tipHtml = '',
			genderStr = '',
			userDetailHtml = '',
			onclickStr = 'UAlert.closeSendMessage();';
			UAlert.aConfig.user_info.gender == 1 ? genderStr = '男' : genderStr = '女';
			if(UAlert.aConfig.user_info.is_friend == 0){
				tipHtml = '<p class="prompt"><i class="ico ico_fail"></i>对方还不是你的好友，暂时无法发送小纸条！</p><p class="prompt">立刻 <a href="javascript:;" onclick="UAlert.closeSendMessage();UAlert.alertApplyFriend();">申请Ta为好友</a></p>';
				closeBtnHtml = '<button class="btn_069" onclick="' + onclickStr + '">关闭</button>';
				userDetailHtml = '\
					<p class="uid">' + UAlert.aConfig.user_info.id + '</p>\
					<p class="feature ellipsis" title="' + genderStr + ',' + UAlert.aConfig.user_info.age + '岁,' + UAlert.aConfig.user_info.constellation + '"><i class="ico ico_feature"></i>' + genderStr + ',' + UAlert.aConfig.user_info.age + '岁,' + UAlert.aConfig.user_info.constellation + '</p>\
					<p class="site ellipsis" title="' + UAlert.aConfig.user_info.province_name + '-' + UAlert.aConfig.user_info.city_name + '-' + UAlert.aConfig.user_info.area_name + '"><i class="ico ico_site"></i>' + UAlert.aConfig.user_info.province_name + '-' + UAlert.aConfig.user_info.city_name + '-' + UAlert.aConfig.user_info.area_name + '</p>\
					<p class="school ellipsis" title="' + UAlert.aConfig.user_info.school_name + '"><i class="ico ico_school"></i>' + UAlert.aConfig.user_info.school_name + '</p>\
				';
			}else if(UAlert.aConfig.user_info.is_friend == 1){
				tipHtml = '<p class="textbox"><textarea class="text" id="messageInfo" placeholder="请输入小纸条内容.."></textarea></p>';
				onclickStr = 'UAlert.sureSendMessage();';
				closeBtnHtml = '<button class="btn_069" onclick="' + onclickStr + '">发送</button>';
			}else if(UAlert.aConfig.user_info.is_friend == 2){
				tipHtml = '<p class="prompt"><i class="ico ico_fail"></i>是自己哦，不能给自己发小纸条哦！</p>';
				closeBtnHtml = '<button class="btn_069" onclick="' + onclickStr + '">关闭</button>';
			}
			var htmlStr = '\
				<div id="sendMessageDialog" class="profile_pop" xid="showAlertWindowId">\
					<div class="hd">\
						<h2>发送小纸条</h2>\
						<span class="follow"><a class="close" href="javascript:;" title="关闭">&#10005;</a></span>\
					</div>\
					<div class="bd c">\
						<div class="side">\
							<p class="head"><a href="' + UAlert.getUserHomeUrl(UAlert.aConfig.user_info.id) + '" target="_blank"><img width="80" height="80" src="' + DEFAULT_HEAD_IMG + '" real="' + UAlert.aConfig.sys_resource_url + UAlert.aConfig.user_info.profile + '" onload="h(this);" /></a></p>\
							<p class="pub">\
								<span class="name ellipsis"><a href="' + UAlert.getUserHomeUrl(UAlert.aConfig.user_info.id) + '" target="_blank">' + UAlert.aConfig.user_info.name + '</a></span>\
								<i class="lv lv' + UAlert.aConfig.user_info.level + '"></i>\
							</p>\
							' + userDetailHtml + '\
						</div>\
						<div class="cont" id="SendMessageDialogBody">\
							' + tipHtml + '\
							<p class="btnbox">' + closeBtnHtml + '</p>\
						</div>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			UAlert.showAlertWindow($('#sendMessageDialog'));

			//输入框占位文字
			if ($.fn.placeholder) {
				$('.profile_pop textarea').placeholder();
			}

		},

		sureSendMessage : function(){
			var messageInfo = $('#messageInfo').val();
			if(messageInfo.length == 0){
				UBox.show('小纸条内容不能为空哦！', -1);
				return;
			}

			ajax({
				url : UAlert.aConfig.send_message_url,
				data : {receiver_user_id : UAlert.aConfig.user_id, content : messageInfo},
				success : function(aResult){
					if(aResult.status == 1){
						var htmlStr = '<p class="prompt"><i class="ico ico_succ"></i>小纸条发送成功！</p><p class="btnbox"><button class="btn_069" onclick="UAlert.closeSendMessage();" >关闭</button></p>';
						$('#SendMessageDialogBody').html(htmlStr);
					}else{
						UBox.show(aResult.msg, -1);
					}
				}
			});
		},

		closeSendMessage : function(){
			$('#sendMessageDialog').fadeOut();
			$('#sendMessageDialog').remove();
		},

		alertApplyFriend : function(){
			$('#applyFriendDialog').fadeOut();
			$('#applyFriendDialog').remove();
			$('[xid=showAlertWindowId]').fadeOut();
			$('[xid=showAlertWindowId]').remove();
			this.getUserInfo(this._appendApplyFriend);
		},

		_appendApplyFriend : function(){
			var genderStr = '',
			tipHtml = '',
			closeBtnHtml = '',
			onclickStr = '';
			UAlert.aConfig.user_info.gender == 1 ? genderStr = '男' : genderStr = '女';
			UAlert.aConfig.user_info.age == 0 ? user_info_age = '' :  user_info_age = UAlert.aConfig.user_info.age + '岁,';
			onclickStr = 'UAlert.closeApplyFriendWin();';
			if(UAlert.aConfig.user_info.is_friend == 0){
				tipHtml = '<p class="item">请输入验证信息：</p><p class="textbox"><textarea class="text" id="verifyTextInfo" placeholder="Hi,我是.."></textarea></p>';
				onclickStr = 'UAlert.sureApplyFriend();';
				closeBtnHtml = '<button class="btn_069" onclick="' + onclickStr + '">确定</button>';
			}else if(UAlert.aConfig.user_info.is_friend == 1){
				tipHtml = '<p class="prompt"><i class="ico ico_fail"></i>对方已经是你的好友，请勿重复添加好友！</p>';
				closeBtnHtml = '<button class="btn_069" onclick="' + onclickStr + '">关闭</button>';
			}else if(UAlert.aConfig.user_info.is_friend == 2){
				tipHtml = '<p class="prompt"><i class="ico ico_fail"></i>是自己哦，不能添加自己为好友！</p>';
				closeBtnHtml = '<button class="btn_069" onclick="' + onclickStr + '">关闭</button>';
			}
			var htmlStr = '\
				<div id="applyFriendDialog" class="profile_pop" xid="showAlertWindowId">\
					<div class="hd">\
						<h2>好友申请</h2>\
						<span class="follow"><a class="close" href="javascript:;" title="关闭">&#10005;</a></span>\
					</div>\
					<div class="bd c">\
						<div class="side">\
							<p class="head"><a href="' + UAlert.getUserHomeUrl(UAlert.aConfig.user_info.id) + '" target="_blank"><img width="80" height="80" src="' + DEFAULT_HEAD_IMG + '" real="' + UAlert.aConfig.sys_resource_url + UAlert.aConfig.user_info.profile + '" onload="h(this);" /></a></p>\
							<p class="pub">\
								<span class="name ellipsis"><a href="' + UAlert.getUserHomeUrl(UAlert.aConfig.user_info.id) + '" target="_blank">' + UAlert.aConfig.user_info.name + '</a></span>\
								<i class="lv lv' + UAlert.aConfig.user_info.level + '"></i>\
							</p>\
							<p class="uid">' + UAlert.aConfig.user_info.id + '</p>\
							<p class="feature ellipsis" title="' + genderStr + ',' + user_info_age + UAlert.aConfig.user_info.constellation + '"><i class="ico ico_feature"></i>' + genderStr + ',' + user_info_age + UAlert.aConfig.user_info.constellation + '</p>\
							<p class="site ellipsis" title="' + UAlert.aConfig.user_info.province_name + '-' + UAlert.aConfig.user_info.city_name + '-' + UAlert.aConfig.user_info.area_name + '"><i class="ico ico_site"></i>' + UAlert.aConfig.user_info.province_name + '-' + UAlert.aConfig.user_info.city_name + '-' + UAlert.aConfig.user_info.area_name + '</p>\
							<p class="school ellipsis" title="' + UAlert.aConfig.user_info.school_name + '"><i class="ico ico_school"></i>' + UAlert.aConfig.user_info.school_name + '</p>\
						</div>\
						<div class="cont" id="applyFriendDialogBody">\
							' + tipHtml + '\
							<p class="btnbox">' + closeBtnHtml + '</p>\
						</div>\
					</div>\
				</div>\
			';
			$('body').append(htmlStr);
			UAlert.showAlertWindow($('#applyFriendDialog'));
		},

		sureApplyFriend : function(){
			var verifyTextInfo = $('#verifyTextInfo').val();

			ajax({
				url : UAlert.aConfig.apply_friend_url,
				data : {userId : UAlert.aConfig.user_id, confirmMessage : verifyTextInfo},
				success : function(aResult){
					var htmlStr = '';
					if(aResult.status > 0){
						UAlert.aConfig.callback(aResult);
						var resultClass = 'ico_succ';
					}else{
						var resultClass = 'ico_fail';
					}
					htmlStr = '<p class="prompt"><i class="ico ' + resultClass + '"></i>' + aResult.msg + '</p><p class="btnbox"><button class="btn_069" onclick="UAlert.closeApplyFriendWin();" >关闭</button></p>';
					$('#applyFriendDialogBody').html(htmlStr);
				}
			});
		},

		closeApplyFriendWin : function(){
			$('#applyFriendDialog').fadeOut();
			$('#applyFriendDialog').remove();
		},

		alertUserInfoCart : function(o){
			$('#userMinCard').fadeOut();
			$('#userMinCard').remove();
			var htmlStr = '<div id="userMinCard" class="min_card"><center style="line-height:130px;">努力加载中。。。</center></div>';
			imgTop = $(o).offset().top + $(o).width() / 2,
			imgLeft = $(o).offset().left + $(o).width() + 2 - $(o).width() / 2;
			if(imgLeft + 315 > $(document).scrollLeft() + $(window).width()){
				imgLeft = imgLeft - 315;
			}
			if(imgTop + 140 > $(document).scrollTop() + $(window).height()){
				imgTop = imgTop - 140;
			}
			$('body').append(htmlStr);
			$('#userMinCard').show();
			$('#userMinCard').css({top : imgTop, left : imgLeft});
			this.getUserInfo(this._appendUserInfoCart);
		},

		_appendUserInfoCart : function(){
			var genderCss = '';
			UAlert.aConfig.user_info.gender == 1 ? genderCss = 'boy' : genderCss = 'girl',
			oUserMinCard = $('#userMinCard');
			var mainClass = '';
			var iElement = '';
			var timestamp = parseInt(Date.parse(new Date()) / 1000);
			if(UAlert.aConfig.user_info.vip_expiration_time > timestamp){
				var vip = UAlert.aConfig.user_info.vip;
				if(vip == 1){
					mainClass = 'vip_general';
					iElement = '<i class="member_ico member_ico_general"></i><i class="member_ico member_ico_general_b"></i>';
				}else if(vip == 2){
					mainClass = 'vip_platinum';
					iElement = '<i class="member_ico member_ico_platinum"></i><i class="member_ico member_ico_platinum_b"></i>';
				}else if(vip == 3){
					mainClass = 'vip_diamond';
					iElement = '<i class="member_ico member_ico_diamond"></i><i class="member_ico member_ico_diamond_b"></i>';
				}
			}
			var htmlStr = iElement;
			htmlStr += '\
					<div class="part">\
						<p class="head"><a href="' + UAlert.getUserHomeUrl(UAlert.aConfig.user_info.id) + '" target="_blank"><img width="100" height="100" src="' + DEFAULT_HEAD_IMG + '" real="' + UAlert.aConfig.sys_resource_url + UAlert.aConfig.user_info.profile + '" onload="h(this);" /></a></p>\
						<p class="pub">\
							<span class="name ellipsis"><a href="' + UAlert.getUserHomeUrl(UAlert.aConfig.user_info.id) + '" target="_blank">' + UAlert.aConfig.user_info.name + '</a></span>\
							<i class="ico ico_' + genderCss + '"></i>\
							<i class="lv lv' + UAlert.aConfig.user_info.level + '"></i>\
						</p>\
						<p class="say" title="' + UAlert.aConfig.user_info.signature + '">' + UAlert.aConfig.user_info.signature + '</p>\
						<p class="site ellipsis"><i class="ico ico_site"></i>' + UAlert.aConfig.user_info.province_name + '-' + UAlert.aConfig.user_info.city_name + '-' + UAlert.aConfig.user_info.area_name + '</p>\
					</div>\
					<div class="btnbox">\
						<a class="act" href="javascript:;" title="申请好友" onclick="UAlert.alertApplyFriend();"><i class="ico ico_add"></i>申请好友</a>\
						<a class="act" href="javascript:;" title="发起PK" onclick="showSendPk(1, ' + UAlert.aConfig.user_info.id + ');"><i class="ico ico_fight"></i>发起PK</a>\
						<a class="act" href="javascript:;" title="小纸条" onclick="UAlert.alertSendMessage();"><i class="ico ico_send"></i>小纸条</a>\
					</div>\
			';
			oUserMinCard.addClass(mainClass);
			oUserMinCard.html(htmlStr);
			oUserMinCard.show();
			oUserMinCard.on('mouseleave', function() {
				oUserMinCard.fadeOut();
				oUserMinCard.remove();
			});
		},

		getUserInfo : function(callBack){
			var oUalert = this,
			userInfoMemoryKey = 'user_info_' + oUalert.aConfig.user_id;
			if(typeof(oUalert.MEMORY_DATA[userInfoMemoryKey]) != 'undefined'){
				oUalert.aConfig.user_info = oUalert.MEMORY_DATA[userInfoMemoryKey];
				callBack();
				return;
			}
			ajax({
				url : oUalert.aConfig.user_info_url,
				data : {user_id : oUalert.aConfig.user_id},
				success : function(aResult){
					if(aResult.status == 1){
						oUalert.aConfig.user_info = aResult.data;
						oUalert.MEMORY_DATA[userInfoMemoryKey] = aResult.data;
						callBack();
					}
				}
			});
		},

		buildHeaderHtml : function(title, flag){
			var htmlStr = '<a class="close" href="javascript:;" title="关闭"></a>';
			htmlStr += '<h2 class="row">' + title + '</h2>';
			return htmlStr;
		},

		buildFooterHtml : function(){
			var htmlStr = '';
			if(this.GOLD_VALUE == 0 && this.ACCUMULATE_VALUE == 0 && this.UB_VALUE == 0){
				return htmlStr;
			}
			htmlStr += '<span class="dialog_fd_txt">已获得奖励：</span>';
			htmlStr += '<div class="dialog_fd_prize">';

			if(this.GOLD_VALUE != 0){
				htmlStr += '<span class="sum row"><i class="ico_dialog ico_dialog_gold"></i><span class="row">金币奖励&nbsp;&nbsp;</span><b class="row">' + this.GOLD_VALUE + '</b></span>';
			}
			if(this.ACCUMULATE_VALUE != 0){
				htmlStr += '<span class="sum row"><i class="ico_dialog ico_dialog_integral"></i><span class="row">经验奖励&nbsp;&nbsp;</span><b class="row">' + this.ACCUMULATE_VALUE + '</b></span>';
			}
			if(this.UB_VALUE != 0){
				htmlStr += '<span class="sum row"><i class="ico_dialog ico_dialog_uf"></i><span class="row">U币奖励&nbsp;&nbsp;</span><b class="row">' + this.UB_VALUE + '</b></span>';
			}
			if(typeof(this.RESULT_DATA.custom_data.mission_medal) != 'undefined'){
				htmlStr += '<span class="sum row"><i class="ico_smedals ico_smedals_blue"></i><span class="row">经验&nbsp;&nbsp;</span><b class="row">+1</b></span>';
			}
			if(typeof(this.RESULT_DATA.custom_data.mission_decoration) != 'undefined'){
				htmlStr += '<span class="sum row"><i class="ico_smedals ico_smedals_gold"></i><span class="row">经验&nbsp;&nbsp;</span><b class="row">+1</b></span>';
			}
			if(this.RESULT_DATA.show_type == this.SHOW_TYPE.PKWIN){
				htmlStr += '<span class="sum row"><i class="ico_dialog ico_dialog_win"></i><span class="row">胜场&nbsp;&nbsp;</span><b class="row">+1</b></span>';
			}
			htmlStr += '</div>';
			return htmlStr;
		},

		alertBox : function(data){
			if(typeof(data.show_type) != 'undefined'){
				if(data.show_type == this.SHOW_TYPE.TASKCOMPLETE){
					this.alertTaskComplete();
				}else if(data.show_type == this.SHOW_TYPE.MISSIONSUCCESS){
					this.alertMissionSuccess();
				}else if(data.show_type == this.SHOW_TYPE.MISSIONFAILD){
					this.alertMissionFaild();
				}else if(data.show_type == this.SHOW_TYPE.ACCEPTMATCHPRIZE){
					this.alertAcceptMatchPrizeWin();
				}else if(data.show_type == this.SHOW_TYPE.PKWIN){
					this.alertPkWin();
				}else if(data.show_type == this.SHOW_TYPE.PKLOST){
					this.alertPkLost();
				}else if(data.show_type == this.SHOW_TYPE.SIGNSUCCESS){
					this.alertSignSuccess();
				}else if(data.show_type == this.SHOW_TYPE.GUIDTASKCOMPLETE){
					this.alertGuidTaskComplete();
				}else if(data.show_type == this.SHOW_TYPE.LIMITCAPTCHA){
					this.alertCaptcha();
				}else{
					$.error('other show type');
				}
			}
		},

		numPop : function(){
			var elem = '', str = '';
			var oAccumulate = $('#accumulate').length ? $('#accumulate') : $(window.parent.document).find('#accumulate');
			var oGold = $('#gold').length ? $('#gold') : $(window.parent.document).find('#gold');
			if(this.LEVEL_VALUE != 0){
				elem = $('#level');
				str = '+' + this.LEVEL_VALUE;
				this.LEVEL_VALUE = 0;
			}else if(this.ACCUMULATE_VALUE != 0){
				elem = oAccumulate;
				str = '+' + this.ACCUMULATE_VALUE;
				this.ACCUMULATE_VALUE = 0;
			}else if(this.GOLD_VALUE != 0){
				if(parseInt(this.GOLD_VALUE) < 0){
					return;
				}
				elem = oGold;
				str = this.GOLD_VALUE > 0 ? '+' + this.GOLD_VALUE : this.GOLD_VALUE;
				this.GOLD_VALUE = 0;
			}else if(this.UB_VALUE != 0){
				elem = $('#ub');
				str = this.UB_VALUE > 0 ? '+' + this.UB_VALUE : this.UB_VALUE;
				this.UB_VALUE = 0;
			}else if(this.MEDAL_VALUE != 0){
				elem = $('#medal');
				str = '+' + this.MEDAL_VALUE;
				this.MEDAL_VALUE = 0;
			}else if(this.TOY_VALUE != 0){
				elem = $('#toy');
				str = this.TOY_VALUE > 0 ? '+' + this.TOY_VALUE : this.TOY_VALUE;
				this.TOY_VALUE = 0;
			}else if(this.FAVOURATE_VALUE != 0){
				elem = $('#favourate');
				str = this.FAVOURATE_VALUE > 0 ? '+' + this.FAVOURATE_VALUE : this.FAVOURATE_VALUE;
				this.FAVOURATE_VALUE = 0;
			}else if(this.ERROR_VALUE != 0){
				elem = $('#error');
				str = this.ERROR_VALUE > 0 ? '+' + this.ERROR_VALUE : this.ERROR_VALUE;
				this.ERROR_VALUE = 0;
			}else{
				return;
			}

			if(elem.length == 0){
				return;
			}
			elem.tipsbox({
				str : str,	 				//要显示的内容
				startSize: "14px",  		//动画开始的文字大小
                endSize: "40px",    		//动画结束文字大小
                interval: 1000,  			//动画执行的时间
                color: "#ffff00",  			//文字颜色
                style: "",  				//其他样式设置，如果除了颜色和字体大小还想设置其他样式,如：style: 'font-weight:bold;font-family:arial;',
				callback : function(){}		//回调函数
			});
		},

		topAlert : function(data){
			if(typeof(data.top_alert) != 'undefined'){
				var topAlertHtml = '';
				for(var key in data.top_alert){
					if(key == this.NUMERICAL_TYPE.LEVEL){
						topAlertHtml += '恭喜您的账户等级已升级至Lv' + data.top_alert[key] + '加油！';
					}else if(key == this.NUMERICAL_TYPE.MEDAL_LEVEL){
						this.topAlert(data.top_alert[key]);
						for(var k in data.top_alert[key]){
							if(k == 1){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“身经百战勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“身经百战勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 2){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“过关斩将勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“过关斩将勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 3){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“箭无虚发勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“箭无虚发勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 4){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“百战百胜勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“百战百胜勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 5){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“PK战神勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“PK战神勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 6){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“PK胜者勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“PK胜者勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 7){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“赛事达人勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“赛事达人勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 8){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“赛事奖者勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“赛事奖者勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}else if(k == 9){
								if(data.top_alert[key][k] == 1){
									topAlertHtml += '恭喜您获得了“妙语连珠勋章”，加油！';
								}else{
									topAlertHtml += '恭喜您的“妙语连珠勋章”已升级至Lv' + data.top_alert[key][k] + '加油！';
								}
							}
						}
					}else{
						$.error('other top alert');
					}
				}
				if(topAlertHtml){
					this.topAlertShow(topAlertHtml);
				}
			}
		},

		topAlertShow : function(str){
			$('body').append('<div xid="topAlertBar" style="height:40px;text-align:center;color:#ffff00;background-color:#000000;position:absolute;display:none;line-height:40px;">' + str + '<a xid="topAlertBarClose" href="javascript:;" style="position:absolute;top:0;right:0;line-height:40px;width:20px;color:#ffff00;padding-right:10px;font-size:25px;">×</a></div>');
			var elem = $('[xid=topAlertBar]'),
			topAlertBarClose = $('[xid=topAlertBarClose]');
			elem.slideDown().css({
				'top': $(document).scrollTop() + 'px',
				'left': $(document).scrollLeft() + 'px',
				'width' : $(window).width() + 'px'
			});
			var t = setTimeout(function(){
				elem.slideUp(function(){
					$(this).remove();
				});
			}, 5000);
			topAlertBarClose.on('click', function(){
				elem.slideUp(function(){
					$(this).remove();
					clearInterval(t);
				});
			});
			$(window).scroll(function(){
				elem.css({
					'top': $(document).scrollTop() + 'px',
					'left': $(document).scrollLeft() + 'px',
					'width' : $(window).width() + 'px'
				});
			});
			$(window).resize(function(){
				elem.css({
					'top': $(document).scrollTop() + 'px',
					'left': $(document).scrollLeft() + 'px',
					'width' : $(window).width() + 'px'
				});
			});
		},

		dialogBox : function(elem){
			var oBody = $('body');
			var oDialogBoxMask = $('#dialogBoxMask');
			var x = 1, y = 1;
			if(this.RESULT_DATA.show_type == this.SHOW_TYPE.PKWIN){
				oBody = $(window.parent.document).find('body');
				elem = $(window.parent.document).find('#pkWinDialog');
				x = 2;
				y = 2.7;
			}else if(this.RESULT_DATA.show_type == this.SHOW_TYPE.PKLOST){
				oBody = $(window.parent.document).find('body');
				elem = $(window.parent.document).find('#pkLostDialog');
				x = 2;
				y = 2.7;
			}
			oBody.append('<div id="dialogBoxMask" class="mask"></div>');
			var oDialogBoxMask = $('#dialogBoxMask') ? $('#dialogBoxMask') : $(window.parent.document).find('#dialogBoxMask');
			oDialogBoxMask.fadeIn().height($(document).innerHeight());
			elem.fadeIn().css({
				'top': $(document).scrollTop() + ($(window).height() / 2) - (elem.innerHeight() / 2) + (275 * x) + 'px',
				'left': $(document).scrollLeft() + ($(window).width() / 2) - (elem.innerWidth() / 2) + (330 * y) + 'px'
			});
			elem.find('.close').on('click', function(){
				elem.fadeOut();
				elem.remove();
				oDialogBoxMask.fadeOut();
				oDialogBoxMask.remove();
			});
			$(window).scroll(function(){
				UAlert.goCenter(elem, 1);
				oDialogBoxMask.height($(document).innerHeight());
			});
			$(window).resize(function(){
				UAlert.goCenter(elem, 1);
				oDialogBoxMask.height($(document).innerHeight());
			});
		},

		showAlertWindow : function(elem){
			elem.fadeIn().css({
				'top': $(document).scrollTop() + ($(window).height() / 2) - (elem.innerHeight() / 2) + 275 + 'px',
				'left': $(document).scrollLeft() + ($(window).width() / 2) - (elem.innerWidth() / 2) + 330 + 'px'
			});
			elem.find('.close').on('click', function(){
				elem.fadeOut();
				elem.remove();
			});
			$(window).scroll(function(){
				UAlert.goCenter(elem, 2);
			});
			$(window).resize(function(){
				UAlert.goCenter(elem, 2);
			});
		},

		goCenter : function(elem, type){
			if(type == 1){
				elem.css('top', $(document).scrollTop() + ($(window).height() / 2) - (elem.innerHeight() / 2) + 275);
				elem.css('left', $(document).scrollLeft() + ($(window).width() / 2) - (elem.innerWidth() / 2) + 330);
			}else if(type == 2){
				elem.css('top', $(document).scrollTop() + ($(window).height() / 2) - (elem.innerHeight() / 2) + 275);
				elem.css('left', $(document).scrollLeft() + ($(window).width() / 2) - (elem.innerWidth() / 2) + 330);
			}
		},

		getUserHomeUrl : function(userId){
			return this.aConfig.user_home_url.replace('_userId', userId);
		}
	};
})(jQuery, window);

(function($){
    $.fn.extend({
        tipsbox : function(options) {
            options = $.extend({
                str : "+1",  			//要显示的内容
                startSize : "14px", 	//动画开始的文字大小
                endSize : "40px",    	//动画结束文字大小
                interval : 500,  		//动画执行的时间
                color : "red",   		//文字颜色
                style : "",  			//其他样式设置，如果除了颜色和字体大小还想设置其他样式,如：style: 'font-weight:bold;font-family:arial;',
                callback : function() {}
            }, options);

            $("body").append("<span class='tips_box' style='" + options.style + "'>" + options.str + "</span>");
            var box = $(".tips_box");
            var self = $(this);
            var top = self.offset().top;
            var left = self.offset().left + self.width() / 2 - box.width() / 2;
            box.css({
                "position" : "absolute",
                "top" : top,
                "left" : left,
                "font-size" : options.startSize,
                "color" : options.color
            });
            box.animate({
                "top" : top - self.height() / 2,
                "opacity" : 1,
                "font-size" : options.endSize
            }, options.interval, function() {
                box.remove();
                options.callback();
            });
        }
    });
})(jQuery);

function shareSignToClass(){
	$('#signSuccessDialog').remove();
	$('#dialogBoxMask').remove();
	var htmlStr = '\
		<div id="shareSignToClass" class="profile_pop" xid="showAlertWindowId">\
			<div class="hd">\
				<h2>分享到班圈</h2>\
				<span class="follow"><a class="close" href="javascript:;" title="关闭" onclick="javascript:$(\'#shareSignToClass\').remove();">&#10005;</a></span>\
			</div>\
			<div style="padding: 4px 15px;">\
				<div id="ualertForwardShuoShuoEditor" style="margin-top: 5px;"></div>\
			</div>\
		</div>\
	';
	$('body').append(htmlStr);
	$('#shareSignToClass').show();
	var oEditor = UMeEditor.getInstance({
		oContext : $('#ualertForwardShuoShuoEditor'),
		imageBaseUrl : UAlert.aConfig.sys_resource_url,
		submitCaption : '确定',
		onSubmit : function(){
			var contentLength = oEditor.getContentLength();
			if(contentLength < 1 || contentLength > 150){
				UBox.show('内容为1到150个字符长度', -1);
				reutrn;
			}

			ajax({
				url : shareSignToClassUrl,
				data : {
					content : oEditor.getContent()
				},
				success : function(aResult){
					UBox.show(aResult.msg, aResult.status);
					if(aResult.status == 1){
						$('#shareSignToClass').remove();
					}
				}
			});
		}
	});
}