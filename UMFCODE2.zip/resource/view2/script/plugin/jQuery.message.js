(function($, win){
	var aCurrentUser = {
		//当前用户
		id : 0
		,name : ''
		,profile : ''
	}
	,aUrl
	,oWrapMessages = null
	,oLastMoreUserList = null
	,oLastEditor = null;


	var self = win.Message = {
		TYPE : {
			AT_IN_SHUOSHUO: 1
			,AT_IN_SHUOSHUO_COMMENT: 100
			,RESHIPMENT_SHUOSHUO: 2
			,COMMENT_SHUOSHUO : 3
			,REPLY_IN_SHUOSHUO_COMMENT : 4
			,PUBLISH_IN_MESSAGE_BOARD : 8
			,REPLY_IN_MESSAGE_BOARD : 9
			,ES_FEEDBACK_RESULT : 10
			,MATCH_FINISH : 20
			,RECEIVE_PK : 30
			,REFUSE_ATTACHMENT : 31
			,PK_FINISH : 32
			,GIVE_PROP : 33
		}

		,config : function(aOption){
			if(aOption.wrapId){
				oWrapMessages = $('#' + aOption.wrapId);
				if(!oWrapMessages.length){
					$.error('找不到消息外框的DOM');
				}

				_bindEvents(oWrapMessages);
			}

			if(aOption.aCurrentUser){
				aCurrentUser = aOption.aCurrentUser;
			}

			if(aOption.aUrl){
				aUrl = aOption.aUrl;
			}
		}

		,appendList : function(aMessageList){
			for(var i in aMessageList){
				var aMessage = aMessageList[i], messageHtml = '';
				try{
					if(aMessage.type == self.TYPE.AT_IN_SHUOSHUO){
						messageHtml = self.getAtInShuoShuoHtml(aMessage);
					}else if(aMessage.type == self.TYPE.AT_IN_SHUOSHUO_COMMENT){
						messageHtml = self.getAtInShuoShuoCommentHtml(aMessage);
					}else if(aMessage.type == self.TYPE.RESHIPMENT_SHUOSHUO){
						messageHtml = self.getReshipmentShuoShuoHtml(aMessage);
					}else if(aMessage.type == self.TYPE.COMMENT_SHUOSHUO){
						messageHtml = self.getCommentShuoShuoHtml(aMessage);
					}else if(aMessage.type == self.TYPE.REPLY_IN_SHUOSHUO_COMMENT){
						messageHtml = self.getReplyInShuoShuoHtml(aMessage);
					}else if(aMessage.type == self.TYPE.PUBLISH_IN_MESSAGE_BOARD){
						messageHtml = self.getPublishInMessageBoardHtml(aMessage);
					}else if(aMessage.type == self.TYPE.REPLY_IN_MESSAGE_BOARD){
						messageHtml = self.getReplyInMessageBoardHtml(aMessage);
					}else if(aMessage.type == self.TYPE.ES_FEEDBACK_RESULT){
						messageHtml = self.getEsFeedBackResultHtml(aMessage);
					}else if(aMessage.type == self.TYPE.MATCH_FINISH){
						messageHtml = self.getMatchFinishHtml(aMessage);
					}else if(aMessage.type == self.TYPE.RECEIVE_PK){
						messageHtml = self.getReceivePkHtml(aMessage);
					}else if(aMessage.type == self.TYPE.REFUSE_ATTACHMENT){
						messageHtml = self.getRefuseAttachmentHtml(aMessage);
					}else if(aMessage.type == self.TYPE.PK_FINISH){
						messageHtml = self.getPkFinishHtml(aMessage);
					}else if(aMessage.type == self.TYPE.GIVE_PROP){
						messageHtml = self.getGivePropHtml(aMessage);
					}
				}catch(error){
					oLog.add(error, '解析与我相关动态出错');
					oLog.add(aMessage, '动态内容');
					continue;
				}
				$(messageHtml).appendTo(oWrapMessages).data('aMessage', aMessage);
			}
			initPhotoViewer();
		}

		,getAtInShuoShuoHtml : function(aMessage){
			var btnShowAllComment = aMessage.comment_count == aMessage.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">的说说提到了我</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.content) + '</div>\
					' + _buildShuoShuoImageList(aMessage.images) + '\
				</div>\
				<div class="_then" xid="then">\
					' + _buildUserList(aMessage.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('赞(<span xid="supportCount">' + aMessage.support_count + '</span>)', 'tc036 _good', 'btnSupportShuoShuo') + '\
						' + _buildAButton('评论(' + aMessage.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
						' + _buildAButton('转发', 'tc036 _forward', 'btnForward') + '\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aMessage.comment, false, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		,getAtInShuoShuoCommentHtml : function(aMessage){
			var btnShowAllComment = aMessage.comment_count == aMessage.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论
			var promulgatorName = aMessage.sender.id != aMessage.user.id ? _buildUserLink(aMessage.user) : 'TA';
			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">在 ' + promulgatorName + ' 的说说评论中提到了我</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.content) + '</div>\
					' + _buildShuoShuoImageList(aMessage.images) + '\
				</div>\
				<div class="_then">\
					' + _buildUserList(aMessage.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('赞(<span xid="supportCount">' + aMessage.support_count + '</span>)', 'tc036 _good', 'btnSupportShuoShuo') + '\
						' + _buildAButton('评论(' + aMessage.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
						' + _buildAButton('转发', 'tc036 _forward', 'btnForward') + '\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aMessage.comment, aMessage.user.id == aCurrentUser.id, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		/**
		 * 某人转发了我的说说
		 * @param {type} aMessage
		 * @returns {String}
		 */
		,getReshipmentShuoShuoHtml : function(aMessage){
			var btnShowAllComment = aMessage.comment_count == aMessage.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论

			var sourceContent = '原文已被删除';
			if(aMessage.source){
				sourceContent = '<a href="javascript:;">' + _buildUserLink(aMessage.source.user) + '</a>：' + aMessage.source.content + _buildShuoShuoImageList(aMessage.source.images);
			}

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">转发了我的说说</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.content) + '</div>\
					<div class="_by c">' + sourceContent + '</div>\
				</div>\
				<div class="_then">\
					' + _buildUserList(aMessage.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('评论(' + aMessage.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aMessage.comment, false, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		/**
		 * 某人评论了我的说说
		 * @param {type} aMessage
		 * @returns {String}
		 */
		,getCommentShuoShuoHtml : function(aMessage){
			var btnShowAllComment = aMessage.comment_count == aMessage.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">评论了我的说说</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.content) + '</div>\
					' + _buildShuoShuoImageList(aMessage.images) + '\
				</div>\
				<div class="_then">\
					' + _buildUserList(aMessage.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('评论(' + aMessage.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aMessage.comment, true) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		/**
		 * 某人在说说中回复了我
		 * @param {type} aMessage
		 * @returns {String}
		 */
		,getReplyInShuoShuoHtml : function(aMessage){
			var btnShowAllComment = aMessage.comment_count == aMessage.comment.length ? '' : _buildAButton('展开全部评论', '_more_comment f12 tc036', 'btnShowAllComment');	//展开查看全部评论
			var promulgatorName = aMessage.sender.id != aMessage.user.id ? _buildUserLink(aMessage.user) : 'TA';

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.shuoshuo_id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">在 ' + promulgatorName + ' 的说说中提到了我</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btn	DeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.content) + '</div>\
					' + _buildShuoShuoImageList(aMessage.images) + '\
				</div>\
				<div class="_then" xid="then">\
					' + _buildUserList(aMessage.support, 'TA们觉得很赞') +  '\
					<div class="_button_list">\
						' + _buildAButton('赞(<span xid="supportCount">' + aMessage.support_count + '</span>)', 'tc036 _good', 'btnSupportShuoShuo') + '\
						' + _buildAButton('评论(' + aMessage.comment_count + ')', 'tc036 _comment', 'btnComment') + '\
						' + _buildAButton('转发', 'tc036 _forward', 'btnForward') + '\
					</div>\
					<div class="_comments" xid="wrapComments">\
						' + btnShowAllComment + '\
						' + _buildShuoShuoCommentList(aMessage.comment, aMessage.user == aCurrentUser.id, aCurrentUser.id) + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		,getPublishInMessageBoardHtml : function(aMessage){
			//组装一二级评论
			var aReplyList = [];
			for(var i in aMessage.message_tree.reply){
				var aReply = aMessage.message_tree.reply[i];
				aReply.user = aReply.is_sender == 1 ? aMessage.sender : aCurrentUser;
				aReplyList.push(_buildMessageReply(aReply, false, aCurrentUser.id));
			}

			var btnShowAllComment = aMessage.message_tree.reply_count == aMessage.message_tree.reply.length ? '' : _buildAButton('展开全部回复', '_more_comment f12 tc036', 'btnShowAllMessageReply');	//展开查看全部回复

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.message_id + '" data-userId="' + aMessage.sender.id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">给我留言了</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.message_tree.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.message_tree.content) + '</div>\
				</div>\
				<div class="_then">\
					<div class="_button_list">\
					' + _buildAButton('回复', 'tc036 _comment', 'btnReplyMessageReply') + '\
					</div>\
					<div class="_comments" xid="wrapReplys">\
						' + btnShowAllComment + '\
						' + aReplyList.join('') + '\
					</div>\
					<div xid="wrapCommentEditor"></div>\
				</div>\
			</div>';
		}

		,getReplyInMessageBoardHtml : function(aMessage){
			//组装一二级评论
			var aReplyList = [];
			for(var i in aMessage.message_tree.reply){
				var aReply = aMessage.message_tree.reply[i];
				aReply.user = aReply.is_sender == 1 ? aMessage.sender : aCurrentUser;
				aReplyList.push(_buildMessageReply(aReply, false, aCurrentUser.id));
			}

			var btnShowAllComment = aMessage.message_tree.reply_count == aMessage.message_tree.reply.length ? '' : _buildAButton('展开全部回复', '_more_comment f12 tc036', 'btnShowAllMessageReply');	//展开查看全部回复

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '" data-dataId="' + aMessage.message_id + '" data-userId="' + aMessage.sender.id + '">\
				<div class="_who">' + _buildUser(aMessage.sender, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.sender) + '\
						<span class="_description f14 tc999">回复了我的留言</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_content f14 tc333">' + UMeEditor.decodeContent(aMessage.content) + '</div>\
					<div class="_by">\
						' + (aMessage.message_tree.user.id == aCurrentUser.id ? '我' : getVipName(aMessage.sender.name, aMessage.sender.vip)) + '：' + UMeEditor.decodeContent(aMessage.message_tree.content) + '\
						<div class="_then">\
							<div class="_comments" xid="wrapReplys">\
								' + btnShowAllComment + '\
								' + aReplyList.join('') + '\
							</div>\
							<div xid="wrapCommentEditor"></div>\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					<div class="_button_list">\
					' + _buildAButton('回复', 'tc036 _comment', 'btnReplyMessageReply') + '\
					</div>\
				</div>\
			</div>';
		}

		/**
		 * 我反馈的题目报错被官方采纳/未采纳
		 * @param {type} aMessage
		 * @returns {win.Message.getEsFeedBackResultHtml.html}
		 */
		,getEsFeedBackResultHtml : function(aMessage){
			var message = '';
			if(aMessage.is_pass){
				message = '已采纳我的题目反馈，获得 ' + aMessage.reward.gold + ' 金币' + (aMessage.reward.accumulate_points ? '和 ' + aMessage.reward.accumulate_points + ' 经验' : '') + '奖励';
			}else{
				message = '未采纳我的题目反馈';
			}
			
			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '">\
				<div class="_who" style="padding-left:10px;">\
					<div class="_name_description">\
						<span class="_description f14 tc999">题库专员' + message + '</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<span class="_content f14 tc333">\
						我的反馈：' + aMessage.reason + '\
						' + (aMessage.is_pass ? '' : '<br /><br />\
						官方回复：' + aMessage.reply) + '\
					</span>\
					<div class="_by es_content">' + $(document.createElement('div')).append(ES.buildDetail(aMessage.es)).html() + '</div>' + '\
				</div>\
			</div>';
		}

		/**
		 * 我参加的某场比赛已结束
		 * @param {type} aMessage
		 * @returns {win.Message.getMatchFinishHtml.html}
		 */
		,getMatchFinishHtml : function(aMessage){
			//aMessage.image = 'http://tb1.bdstatic.com/tb/cms/1231fangyuan-03.jpg';	//et//////////////////临时,部署后删除
			var matchUrl = aUrl.match.replace('_match_id', aMessage.match_id),
			result = '我的参赛得分：' + (aMessage.best_score / 100) + '分，排名：No.' + aMessage.ranking + '。';
			if(aMessage.win_info.type){
				var orderName = aMessage.win_info.type == 2 ? '幸运奖' : ['冠军', '亚军', '季军', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名'][aMessage.ranking - 1];
				result = '恭喜你，本场比赛荣获' + orderName + '！' + result;
			}else{
				result = '很遗憾，本场比赛未得奖！' + result;
			}

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-dataId="' + aMessage.match_id + '" data-type="' + aMessage.type + '">\
				<div class="_who">' + _buildUser(aCurrentUser, {width : 50, height : 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aCurrentUser) + '\
						<span class="_description f14 tc999">我参加的比赛已结束</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<span class="_content f14 ' + (aMessage.win_info.type ? 'tcC33' : 'tc333') + '">' + result + '</span>\
					<div class="_by c">\
						<div class="_match_end">\
							<a class="_image" href="' + matchUrl + '">\
								<img onload="h(this)" src="' + DEFAULT_IMG + '" real="' + aMessage.image + '" width="81" height="90" />\
							</a>\
							<div class="_description">\
								<a href="' + matchUrl + '" class="_name f14 tc036">' + aMessage.title + '</a>\
								<div class="_introduction tc999">' + aMessage.description + '</div>\
								<span class="_total">' + aMessage.member_count + '人参赛</span>\
								<span class="_time">' + _parseTime(aMessage.start_time) + ' - ' + _parseTime(aMessage.end_time) + '</span>\
								<span class="_best">冠军得分 ' + (aMessage.champion_score / 100) + '</span>\
							</div>\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					' + _buildUserList(aMessage.users, 'TA们得奖了', '_match') + '\
					<div class="_button_list">\
						<a class="tc036 _match" href="' + matchUrl + '" target="_blank">查看比赛</a>\
						' + _buildAButton('分享给好友', 'tc036 _share', 'btnShare') + '\
					</div>\
				</div>\
			</div>';
		}

		/**
		 * 某人向我发起了一场PK
		 * @param {type} aMessage
		 * @returns {String}
		 */
		,getReceivePkHtml : function(aMessage){
			var aSender = aMessage.opposite_user.is_sender ? aMessage.opposite_user : aCurrentUser,
			aReceiver = aMessage.opposite_user.is_sender ? aCurrentUser : aMessage.opposite_user;

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-dataId="' + aMessage.pk_id + '" data-type="' + aMessage.type + '">\
				<div class="_who">' + _buildUser(aMessage.opposite_user, {width: 50, height:50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.opposite_user) + '\
						<span class="_description f14 tc999">向我发起了一场PK</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<span class="_content f14 tc333">' + aMessage.duration + '分钟内完成《' + aMessage.mission + '》关卡' + aMessage.es_count + '个题目，并于' + _parseTime(aMessage.pk_over_time) + '之前完成，否则你就输啦！' + (aMessage.attachment_gold > 0 ? aMessage.opposite_user.name + '还要额外和你PK ' + aMessage.attachment_gold + '个金币，接受吗？' : '') + '</span>\
					<div class="_by c">\
						<div class="_pk_end">\
							<span class="_master">' + _buildUser(aSender, {width:50, height:50}) + '</span>\
							<a class="_master_name tc036" href="' + aUrl.userHome.replace('_userId', aSender.id) + '" target="_blank">' + getVipName(aSender.name, aSender.vip) + '</a>\
							<span class="_vs">VS</span>\
							<span class="_slave">' + _buildUser(aReceiver, {width:50, height:50}) + '</span>\
							<a class="_slave_name tc036" href="' + aUrl.userHome.replace('_userId', aReceiver.id) + '" target="_blank">' + '</a>\
							<a href="' + aUrl.missionChallenge.replace('_mission_id', aMessage.mission_id) + '" class="_title f14 tc036">PK' + aMessage.mission + '</a>\
							<span class="_duration">' + aMessage.duration + '分钟</span>\
							<span class="_time">' + _parseTime(aMessage.pk_send_time) + ' - ' + _parseTime(aMessage.pk_over_time) + '</span>\
							<span class="_es">' + aMessage.es_count + '题</span>\
							' + (aMessage.attachment_gold ? '<span class="_gold">' + aMessage.attachment_gold + '金币</span>' : '') + '\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					<div class="_button_list">\
						<a class="tc036 _pk" href="javascript:;" onclick="showPkDetail(' + aMessage.pk_id + ', 0)">前往应战</a>\
					</div>\
				</div>\
			</div>';
		}

		/**
		 * 某人拒绝了我的PK筹码
		 * @param {type} aMessage
		 * @returns {String}
		 */
		,getRefuseAttachmentHtml : function(aMessage){
			var aSender = aMessage.opposite_user.is_sender ? aMessage.opposite_user : aCurrentUser,
			aReceiver = aMessage.opposite_user.is_sender ? aCurrentUser : aMessage.opposite_user;

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-dataId="' + aMessage.pk_id + '" data-type="' + aMessage.type + '">\
				<div class="_who">' + _buildUser(aMessage.opposite_user, {width: 50, height:50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.opposite_user) + '\
						<span class="_description f14 tc999">拒绝了我的金币PK条件</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<div class="_by c">\
						<div class="_pk_end">\
							<span class="_master">' + _buildUser(aSender, {width:50, height:50}) + '</span>\
							<a class="_master_name tc036" href="' + aUrl.userHome.replace('_userId', aSender.id) + '" target="_blank">' + getVipName(aSender.name, aSender.vip) + '</a>\
							<span class="_vs">VS</span>\
							<span class="_slave">' + _buildUser(aReceiver, {width:50, height:50}) + '</span>\
							<a class="_slave_name tc036" href="' + aUrl.userHome.replace('_userId', aReceiver.id) + '" target="_blank">' + getVipName(aReceiver.name, aReceiver.vip) + '</a>\
							<a href="' + aUrl.missionChallenge.replace('_mission_id', aMessage.mission_id) + '" class="_title f14 tc036">PK' + aMessage.mission + '</a>\
							<span class="_duration">' + aMessage.duration + '分钟</span>\
							<span class="_time">' + _parseTime(aMessage.pk_send_time) + ' - ' + _parseTime(aMessage.pk_over_time) + '</span>\
							<span class="_es">' + aMessage.es_count + '题</span>\
							' + (aMessage.attachment_gold ? '<span class="_gold">' + aMessage.attachment_gold + '金币</span>' : '') + '\
						</div>\
					</div>\
					<div class="_history">\
						' + (!aMessage.opposite_user.is_sender ? '' :'<p><span class="tc999">' + _parseTime(aMessage.pk_send_time) + '</span><a href="javascript:;" class="tc036">' + getVipName(aMessage.opposite_user.name, aMessage.opposite_user.vip) + '</a>向我发起了PK</p>') + '\
					</div>\
				</div>\
				<div class="_then">\
					<div class="_button_list">\
						<a class="tc036 _pk" href="javascript:;" onclick="showPkDetail(' + aMessage.pk_id + ', 0)">查看PK</a>\
					</div>\
				</div>\
			</div>';
		}

		/**
		 * 某和我的PK已结束
		 * @param {type} aMessage
		 * @returns {win.Message.getPkFinishHtml.html}
		 */
		,getPkFinishHtml : function(aMessage){
			var aSender = aMessage.opposite_user.is_sender ? aMessage.opposite_user : aCurrentUser,
			aReceiver = aMessage.opposite_user.is_sender ? aCurrentUser : aMessage.opposite_user;
			var tips = '';
			if(aMessage.is_win){
				tips = '恭喜你，赢得本次PK的胜利！我的PK得分：';
			}else{
				tips = '很遗憾，本次的PK负败！我的PK得分：';
			}
			tips += (aMessage.opposite_user.is_sender ? aMessage.receiver_score / 100 : aMessage.sender_score / 100) + '，对方得分：' + (aMessage.opposite_user.is_sender ? (aMessage.sender_score / 100) : (aMessage.receiver_score / 100));

			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-dataId="' + aMessage.pk_id + '" data-type="' + aMessage.type + '">\
				<div class="_who">' + _buildUser(aMessage.opposite_user, {width: 50, height:50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.opposite_user) + '\
						<span class="_description f14 tc999">和我的PK已结束</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					<span class="_content f14 ' + (aMessage.is_win ? 'tcC33' : 'tc333') + '">' + tips + '</span>\
					<div class="_by c">\
						<div class="_pk_end">\
							<span class="_master">' + _buildUser(aSender, {width:50, height:50}) + '</span>\
							<a class="_master_name tc036" href="' + aUrl.userHome.replace('_userId', aSender.id) + '" target="_blank">' + getVipName(aSender.name, aSender.vip) + '</a>\
							<span class="_vs">VS</span>\
							<span class="_slave">' + _buildUser(aReceiver, {width:50, height:50}) + '</span>\
							<a class="_slave_name tc036" href="' + aUrl.userHome.replace('_userId', aReceiver.id) + '" target="_blank">' + getVipName(aReceiver.name, aReceiver.vip) + '</a>\
							<a href="' + aUrl.missionChallenge.replace('_mission_id', aMessage.mission_id) + '" class="_title f14 tc036">PK' + aMessage.mission + '</a>\
							<span class="_duration">' + aMessage.duration + '分钟</span>\
							<span class="_time">' + _parseTime(aMessage.pk_send_time) + ' - ' + _parseTime(aMessage.pk_over_time) + '</span>\
							<span class="_es">' + aMessage.es_count + '题</span>\
							' + (aMessage.attachment_gold ? '<span class="_gold">' + aMessage.attachment_gold + '金币</span>' : '') + '\
						</div>\
					</div>\
					<div class="_history">\
						' + (!aMessage.opposite_user.is_sender ? '' :'<p><span class="tc999">' + _parseTime(aMessage.pk_send_time) + '</span><a href="javascript:;" class="tc036">' + getVipName(aMessage.opposite_user.name, aMessage.opposite_user.vip) + '</a>向我发起了PK</p>') + '\
					' + ((aMessage.attachment_gold > 0 && !aMessage.opposite_user.is_sender) ? '<p><span class="tc999">' + _parseTime(aMessage.receiver_start_time) + '</span><a href="javascript:;" class="tc036">' + getVipName(aMessage.opposite_user.name, aMessage.opposite_user.vip) + '</a>' + (aMessage.is_opposite_receive_attachment ? '接受' : '拒绝') + '金币PK条件</p>' : '') + '\
					</div>\
				</div>\
				<div class="_then">\
					<div class="_button_list">\
						<a class="tc036 _pk" href="javascript:;" onclick="showPkDetail(' + aMessage.pk_id + ', 0)">查看PK</a>\
						' + (aMessage.is_win ? _buildAButton('分享给好友', 'tc036 _share', 'btnShare') : '') + '\
					</div>\
				</div>\
			</div>';
		}
		
		,getGivePropHtml : function(aMessage){
			return '<div class="_event mod" xid="message" itemid="' + aMessage.id + '" data-type="' + aMessage.type + '">\
				<div class="_who">\
					' + _buildUser(aMessage.user, {width : 50, height: 50}) + '\
					<div class="_name_description">\
						' + _buildUserLink(aMessage.user) + '</a>\
						<span class="_description f14 tc999">赠送了一个道具 ' + getVipName(aMessage.prop.name, aMessage.prop.vip) + ' 给你！</span>\
					</div>\
					<span class="_time f12 tc999">' + _parseTime(aMessage.time) + '</span>\
					' + _buildAButton('删除', '_delete tc036', 'btnDeleteEvent') + '\
				</div>\
				<div class="_what">\
					' + aMessage.message + '\
					<div class="_by c">\
						<div class="_prop_info">\
							<span class="_image">\
								<img src="' + DEFAULT_IMG + '" real="' + aMessage.prop.image + '" onload="h(this)" width="66" height="66" />\
							</span>\
							<p class="_name">\
								<a class="_title f14 tc036" href="javascript:;">' + getVipName(aMessage.prop.name, aMessage.prop.vip) + '</a>\
								<span class="_price">' + aMessage.prop.price + '金币</span>\
							</p>\
							<p><span class="_description">' + aMessage.prop.desc + '</span></p>\
						</div>\
					</div>\
				</div>\
				<div class="_then">\
					<div class="_button_list">\
						<a class="tc036 _props" href="javascript:showPakget();">查看道具</a>\
					</div>\
				</div>\
			</div>';
		}
	};

	function _buildUser(aUser, aSize){
		if(!aSize){
			aSize = {
				width : 30
				,height : 30
			};
		}
		
		return '<p class="head" xid="userProfile">\
			<a class="_profile" href="' + aUrl.userHome.replace('_userId', aUser.id) + '" title="' + aUser.name.replace(/<[^>]+>/g, '') + '" target="_blank">\
				<img src="' + DEFAULT_HEAD_IMG + '" real="' + aUser.profile + '" height="' + aSize.width + '" width="' + aSize.height + '" onload="h(this)" />\
			</a>\
		</p>';
	}
	
	function _buildUserLink(aUser, className){
		if(!className){
			className = '_name f14 tc036';
		}
		return '<a class="' + className + '" href="' + aUrl.userHome.replace('_userId', aUser.id) + '" target="_blank">' + getVipName(aUser.name, aUser.vip) + '</a>';
	}

	/**
	 * 构建事件相关用户列表
	 * @param {type} aUserList
	 * @param {type} tips
	 * @returns {String}
	 */
	function _buildUserList(aUserList, tips){
		if(!aUserList || !$.isArray(aUserList)){
			return '';
		}

		var isMoreUser = false;
		if(aUserList.length == 11){
			aUserList.pop();
			isMoreUser = true;
		}

		var aUserListHtml = [];
		for(var i in aUserList){
			aUserListHtml.push(_buildUser(aUserList[i]));
		}

		var userListHtml = '';
		if(aUserListHtml.length){
			userListHtml = '<div class="_profile_list" xid="userList">\
				<a class="_good" title="' + tips + '"></a>\
				' + aUserListHtml.join('') + '\
				' + (isMoreUser ? '<a href="javascript:void(0);" class="_and_so_on" xid="btnShowMoreUser"></a>' : '') + '\
			</div>';
		}
		return userListHtml;
	}

	function _buildAButton(content, className, xid){
		return '<a href="javascript:void(0);" class="' + className + '" xid="' + xid + '">' + content + '</a>';
	}

	function _parseTime(timeStamp){
		return isNaN(timeStamp) ? timeStamp : date('n月j日 H:i', timeStamp);
	}

	function _buildShuoShuoCommentList(aCommentList, isManager, allowDeleteUserId){
		var aCommentListHtml = [];
		for(var i in aCommentList){
			var aComment = aCommentList[i];
			aCommentListHtml.push(_buildShuoShuoComment(aComment, isManager, allowDeleteUserId));
		}
		return aCommentListHtml.join('');
	}

	function _getMessageDomByElement(oElement){
		return $(oElement).closest('[xid="message"]');
	}

	/**
	 * 构建说说的评论
	 * @param {type} aComment
	 * @param {type} isManager
	 * @param {type} allowDeleteUserId
	 * @returns {String}
	 */
	function _buildShuoShuoComment(aComment, isManager, allowDeleteUserId){
		var aComments = ['<div class="_comment_content c">\
			' + _buildUser(aComment.user) + '\
			<div class="_name_content">\
				<a class="_name f12 tc036" href="#">' + getVipName(aComment.user.name, aComment.user.vip) + '</a>：\
				<span class="_content f12 tc333">' + UMeEditor.decodeContent(aComment.content) + '</span>\
				<div class="c">\
					<span class="_time f12 tc999">' + _parseTime(aComment.time) + '</span>\
					' + (isManager || allowDeleteUserId == aComment.user.id ? _buildAButton('删除', 'tc036 _delete_ico', 'btnDeleteComment') : '') + '\
					' + _buildAButton('回复', '_reply_ico', 'btnReplyShuoShuoComment') + '\
				</div>\
			</div>\
		</div>'];

		var aReplys = [aComment.reply_count == aComment.reply.length ? '' : _buildAButton('展开全部回复', 'tc036 _more_reply f12', 'btnShowAllReply')];
		for(var j in aComment.reply){
			aReplys.push(_buildShuoShuoReply(aComment.reply[j], isManager, allowDeleteUserId));
		}
		aComments.push('<div class="replys" xid="wrapReplys">' + aReplys.join('') + '</div>');
		aComments.push('<div class="replyEditor" xid="replyEditor"></div>');

		return '<div class="_comment" xid="comment" itemid="' + aComment.id + '" data-user_id="' + aComment.user.id + '" data-name="' + aComment.user.name.replace(/<[^>]+>/g, '') + '">' + aComments.join('') + '</div>';
	}

	/**
	 * 构建说说的评论回复
	 * @param {type} aReply
	 * @param {type} isManager
	 * @param {type} allowDeleteUserId
	 * @returns {String}
	 */
	function _buildShuoShuoReply(aReply, isManager, allowDeleteUserId){
		var noReplyUser = aReply.reply_user.id == aReply.user.id;
		var isReplyMe = aReply.reply_user.id === undefined;
		var replyToHtml = '';
		if(!noReplyUser){
			replyToHtml = ' 回复<a class="_name f12 tc036" href="javascript:void(0)"> ' + (isReplyMe ? '我' : getVipName(aReply.reply_user.name, aReply.reply_user.vip)) + '</a>';
		}

		return '<div class="_reply c" xid="reply" itemid="' + aReply.id + '" data-user_id="' + aReply.user.id + '" data-name="' + aReply.user.name.replace(/<[^>]+>/g, '') + '">\
			<div class="_reply_content c">\
				' + _buildUser(aReply.user) + '\
				<div class="_name_content">\
					<a class="_name f12 tc036" href="javascript:void(0);">' + getVipName(aReply.user.name, aReply.user.vip) + '</a>' + replyToHtml + '：\
					<span class="_content f12 tc333">' + UMeEditor.decodeContent(aReply.content) + '</span>\
					<div class="c">\
						<span class="_time f12 tc999">' + _parseTime(aReply.time) + '</span>\
						' + (isManager || allowDeleteUserId == aReply.user.id ? _buildAButton('删除', '_delete_ico', 'btnDeleteReply') : '') + '\
						' + _buildAButton('回复', '_reply_ico', 'btnReplyShuoShuoReply') + '\
					</div>\
				</div>\
			</div>\
		</div>';
	}

	/**
	 * 构建说说图片列表
	 * @param {type} aImageList
	 * @returns {String}
	 */
	function _buildShuoShuoImageList(aImageList){
		var aImages = [];
		for(var i = 0, count = aImageList.length; i < count; i++){
			aImages.push('<a class="_image" xid="shuoshuoImage" title="点击查看原图" target="_blank" href="' + aImageList[i] + '">\
<img width="130" height="90" onload="h(this);" real="' + aImageList[i] + '" src="' + DEFAULT_IMG + '"></img>\
</a>');
		}
		if(aImages.length){
			aImages.unshift('<div class="_match_end">');
			aImages.push('</div>');
		}
		return aImages.join('');
	}

	/**
	 * 构建留言回复列表
	 * @param {type} aReply
	 * @param {type} isManager
	 * @param {type} allowDeleteUserId
	 * @returns {String}
	 */
	function _buildMessageReply(aReply, isManager, allowDeleteUserId){
		return '<div class="_comment"><div class="_comment_content c" xid="messageReply" itemid="' + aReply.id + '">\
			' + _buildUser(aReply.user) + '\
			<div class="_name_content">\
				<a class="_name f12 tc036" href="javascript:void(0);">' + getVipName(aReply.user.name, aReply.user.vip) + '</a>：\
				<span class="_content f12 tc333">' + UMeEditor.decodeContent(aReply.content) + '</span>\
				<div class="c">\
					<span class="_time f12 tc999">' + _parseTime(aReply.time) + '</span>\
					' + (isManager || allowDeleteUserId == aReply.user.id ? _buildAButton('删除', 'tc036 _delete_ico', 'btnDeleteMessageReply') : '') + '\
					' + _buildAButton('回复', '_reply_ico', 'btnReplyMessageReply') + '\
				</div>\
			</div>\
		</div></div>';
	}

	/**
	 * 绑定消息处理事件
	 * @param {type} oWrapMessages
	 * @returns {undefined}
	 */
	function _bindEvents(oWrapMessages){
		oWrapMessages.delegate('[xid="btnDeleteEvent"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this);
			UBox.confirm('确定要删除这条消息吗？', function(){
				ajax({
					url : aUrl.deleteMessage
					,data : {
						id : oMessage.attr('itemid')
					}
					,success : function(aResult){
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status == 1){
							oMessage.slideUp('normal', function(){
								$(this).remove();
							});
						}
					}
				});
			});
		});

		/**
		 * 赞说说的操作
		 */
		oWrapMessages.delegate('[xid="btnSupportShuoShuo"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this);
			ajax({
				url : aUrl.supportShuoShuo
				,data : {
					id : oMessage.data('aMessage').shuoshuo_id
				}
				,success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return;
					}
					var $oSupportCount = oMessage.find('span[xid="supportCount"]');
					$oSupportCount.text(parseInt($oSupportCount.text()) + 1);
					
					//显示头像
					var $oUserList = oMessage.find('div[xid="userList"]');	//赞的用户头像列表
					if(!$oUserList.length){
						$(_buildUserList([aCurrentUser], 'TA们觉得很赞')).prependTo(oMessage.find('div[xid="then"]'));
					}else{
						//已有10个头像则移除一个
						var $oUserProfileList = $oUserList.find('p[xid="userProfile"]');
						if($oUserProfileList.length == 10){
							$oUserProfileList.last().remove();
						}
						$(_buildUser(aCurrentUser)).insertAfter($oUserList.children().first());
					}
				}
			});
		});

		/**
		 * 删除说说的评论回复操作
		 */
		oWrapMessages.delegate('[xid="btnDeleteComment"],[xid="btnDeleteReply"]', 'click', function(){
			var wrapXid = $(this).attr('xid') == 'btnDeleteComment' ? 'comment' : 'reply';
			var oComment = $(this).closest('[xid="' + wrapXid + '"]');
			UBox.confirm('确定要删除这条评论吗?', function(){
				ajax({
					url : aUrl.deleteShuoShuoComment
					,data : {
						commentId : oComment.attr('itemid')
					}
					,success : function(aResult){
						if(aResult.status == 0){
							UBox.show(aResult.msg, 0);
							return;
						}

						oComment.slideUp('normal', function(){
							$(this).remove();
						});
					}
				});
			});
		});

		/**
		 * 说说评论操作
		 */
		oWrapMessages.delegate('[xid="btnComment"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this)
			,dataId = oMessage.attr('data-dataId');
			if(oMessage.data('oEditor') && oLastEditor.id == dataId){
				return;
			}

			var fShowEditor = function(){
				var oEditor = UMeEditor.getInstance({
					oContext : oMessage.find('[xid="wrapCommentEditor"]')
					,imageBaseUrl : aUrl.source
					,aFace : ['qq']
					,submitCaption : '评论'
					,userList : true
					,userListUrl : aUrl.friendList
					,tips : '我也说一句：'
					,onSubmit : function(){
						var contentLength = oEditor.getContentLength();
						if(oEditor.isEmpty()){
							UBox.show('请填写评论内容！', -1);
							return false;
						}else if(contentLength < 1 || contentLength > 150){
							UBox.show('请填写1到150字之间的回复内容！', -1);
							return false;
						}

						ajax({
							url : aUrl.submitShuoShuoComment
							,data : {
								shuoshuoId : dataId
								,content : UMeEditor.encodeContent(oEditor.getContent())
								,atUserIds : oEditor.getAtUserIdList()
							}
							,success : function(aResult){
								if(aResult.status != 1){
									UBox.show(aResult.msg, aResult.status);
									return;
								}
								oLastEditor = null;
								oMessage.data('oEditor', null);
								oEditor.destory();
								aResult = aResult.data;
								var aComment = {
									id : aResult.id
									,content : aResult.content
									,reply : []
									,reply_count : 0
									,user : aCurrentUser
									,time : Math.floor($.now() / 1000)
								};
								var shuoshuoComment = _buildShuoShuoComment(aComment, false, aCurrentUser.id);
								oMessage.find('[xid="wrapComments"]').append(shuoshuoComment);
							}
						});
					}
				});
				oEditor.focus();
				oEditor.id = dataId;
				oLastEditor = oEditor;
				oMessage.data('oEditor', oEditor);
			};

			if(oLastEditor && oLastEditor.getContent().length){
				UBox.confirm('要放弃之前的编辑吗？', function(){
					oLastEditor.destory();
					oLastEditor = null;
					fShowEditor();
				});
			}else if(oLastEditor){
				oLastEditor.destory();
				oLastEditor = null;
				fShowEditor();
			}else{
				fShowEditor();
			}
		});

		/**
		 * 回复说说评论
		 */
		oWrapMessages.delegate('[xid="btnReplyShuoShuoComment"],[xid="btnReplyShuoShuoReply"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this)
			,oButton = $(this)
			,oComment = $(this).closest('[xid="comment"]')
			,dataId = oMessage.attr('data-dataId')
			,commentId = oComment.attr('itemid')
			,isReply = oButton.attr('xid') == 'btnReplyShuoShuoReply'
			,replyId = ''
			,aReplyToUser = {};
			if(isReply){
				var oReply = oButton.closest('[xid="reply"]');
				replyId = oReply.attr('itemid');
				aReplyToUser = {
					id : oReply.data('user_id')
					,name : oReply.data('name')
				};
			}else{
				aReplyToUser = {
					id : oComment.data('user_id')
					,name : oComment.data('name')
				};
			}
			if(oMessage.data('oReplyEditor') && (oLastEditor.id == dataId + '' + commentId + replyId)){
				return;
			}
			var fShowEditor = function(){
				var oEditor = UMeEditor.getInstance({
					oContext : oComment.find('[xid="replyEditor"]')
					,imageBaseUrl : aUrl.source
					,tips : '我也说一句：'
					,aFace : ['qq']
					,submitCaption : '回复'
					,userList : true
					,userListUrl : aUrl.friendList
					,onSubmit : function(){
						var contentLength = oEditor.getContentLength();
						if(oEditor.isEmpty()){
							UBox.show('请填写评论内容！', -1);
							return false;
						}else if(contentLength < 1 || contentLength > 150){
							UBox.show('请填写1到150字之间的回复内容！', -1);
							return false;
						}

						ajax({
							url : aUrl.submitShuoShuoComment
							,data : {
								reply_id : isReply ? replyId : commentId
								,content : UMeEditor.encodeContent(oEditor.getContent())
								,atUserIds : oEditor.getAtUserIdList()
							}
							,success : function(aResult){
								if(aResult.status != 1){
									UBox.show(aResult.msg, aResult.status);
									return;
								}
								oLastEditor = null;
								oMessage.data('oReplyEditor', null);
								oEditor.destory();
								aResult = aResult.data;
								var aReply = {
									id : aResult.id
									,content : aResult.content
									,reply_user : aReplyToUser
									,user : aCurrentUser
									,reply : []
									,reply_count : 0
									,time : Math.floor($.now() / 1000)
								};
								var commentReply = _buildShuoShuoReply(aReply, false, aCurrentUser.id);
								oComment.find('[xid="wrapReplys"]').append(commentReply);
							}
						});
					}
				});
				oEditor.focus();
				oEditor.id = dataId + '' + commentId + replyId;
				oLastEditor = oEditor;
				oMessage.data('oReplyEditor', oEditor);
			};

			if(oLastEditor && oLastEditor.getContent().length){
				UBox.confirm('要放弃之前的编辑吗？', function(){
					oLastEditor.destory();
					oLastEditor = null;
					fShowEditor();
				});
			}else if(oLastEditor){
				oLastEditor.destory();
				oLastEditor = null;
				fShowEditor();
			}else{
				fShowEditor();
			}
		});

		/**
		 * 留言回复操作
		 */
		oWrapMessages.delegate('[xid="btnReplyMessageReply"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this)
			,messageId = oMessage.attr('data-dataId');
			if(oMessage.data('oEditor') && oLastEditor.id == 'msg' + messageId){
				return;
			}

			var fShowEditor = function(){
				var oEditor = UMeEditor.getInstance({
					oContext : oMessage.find('[xid="wrapCommentEditor"]')
					,imageBaseUrl : aUrl.source
					,aFace : ['qq']
					,submitCaption : '回复'
					,onFocus : function(){
						oEditor.slideDown();
					}
					,onWrapperBlur : function(){
						oEditor.slideUp();
					}
					,onSubmit : function(){
						var contentLength = oEditor.getContentLength();
						if(oEditor.isEmpty()){
							UBox.show('请填写评论内容！', -1);
							return false;
						}else if(contentLength < 1 || contentLength > 150){
							UBox.show('请填写1到150字之间的回复内容！', -1);
							return false;
						}

						ajax({
							url : aUrl.submitMessageComment
							,data : {
								user_id : oMessage.attr('data-userId')
								,parent_id : messageId
								,content : UMeEditor.encodeContent(oEditor.getContent())
							}
							,success : function(aResult){
								if(aResult.status != 1){
									UBox.show(aResult.msg, aResult.status);
									return;
								}
								oLastEditor = null;
								oMessage.data('oEditor', null);
								oEditor.destory();
								var aReply = {
									id : aResult.data.id
									,user : aCurrentUser
									,content : aResult.data.content
									,time : Math.floor($.now() / 1000)
								};
								var shuoshuoComment = _buildMessageReply(aReply, false, aCurrentUser.id);
								oMessage.find('[xid="wrapReplys"]').append(shuoshuoComment);
							}
						});
					}
				});
				oEditor.focus();
				oEditor.id = 'msg' + messageId;
				oLastEditor = oEditor;
				oMessage.data('oEditor', oEditor);
			};

			if(oLastEditor && oLastEditor.getContent().length){
				UBox.confirm('要放弃之前的编辑吗？', function(){
					oLastEditor.destory();
					oLastEditor = null;
					fShowEditor();
				});
			}else if(oLastEditor){
				oLastEditor.destory();
				oLastEditor = null;
				fShowEditor();
			}else{
				fShowEditor();
			}
		});

		/**
		 * 查看所有说说评论操作
		 */
		oWrapMessages.delegate('[xid="btnShowAllComment"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this)
			,oBtnShowAllComment = $(this);

			var fShowShuoShuoComment = function(aCommentList){
				oMessage.find('[xid="wrapComments"]').html(_buildShuoShuoCommentList(aCommentList, false, aCurrentUser.id));
			};

			var aCommentList = oMessage.data('aCommentList');
			if(aCommentList){
				fShowShuoShuoComment(aCommentList);
				return;
			}

			ajax({
				url : aUrl.getAllShuoShuoComment
				,data : {
					id : oMessage.attr('data-dataId')
				}
				,beforeSend : function(){
					oBtnShowAllComment.text('加载中...');
				}
				,success : function(aResult){
					if(aResult.status  == 0){
						UBox.show(aResult.msg, 0);
						oBtnShowAllComment.text('展开全部评论');
						return;
					}
					var aCommentList = [];
					//构建评论结构
					for(var i in aResult.data){
						var aTmpComment = aResult.data[i];
						aTmpComment.user_info.profile = aUrl.source + aTmpComment.user_info.profile;
						var aComment = {
							id : aTmpComment.id
							,content : aTmpComment.content
							,time : aTmpComment.create_time
							,user : aTmpComment.user_info
							,reply_count : aTmpComment.reply_count
							,reply : []
						};

						//构建回复结构
						for(var j in aTmpComment.reply){
							var aReply = aTmpComment.reply[j];
							aReply.user_info.profile = aUrl.source + aReply.user_info.profile;
							aReply.reply_user_info.profile = aUrl.source + aReply.reply_user_info.profile;
							aComment.reply.push({
								id : aReply.id
								,content : aReply.content
								,time : aReply.create_time
								,user : aReply.user_info
								,reply_user : aReply.reply_user_info
							});
						}

						aCommentList.push(aComment);
					}
					oMessage.data('aCommentList', aCommentList);
					fShowShuoShuoComment(aCommentList);
				}
				,error : function(){
					oBtnShowAllComment.text('展开全部评论');
				}
			});
		});

		/**
		 * 查看某个留言下的所有回复节点
		 */
		oWrapMessages.delegate('[xid="btnShowAllMessageReply"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this)
			,oBtnShowAllReply = $(this);

			var fShowShuoShuoComment = function(aRplyList){
				var aReplyList = [];
				for(var i in aRplyList){
					var aReply = aRplyList[i];
					aReplyList.push(_buildMessageReply(aReply, false, aCurrentUser.id));
				}
				oMessage.find('[xid="wrapReplys"]').html(aReplyList.join(''));
			};

			var aRplyList = oMessage.data('aRplyList');
			if(aRplyList){
				fShowShuoShuoComment(aRplyList);
				return;
			}

			ajax({
				url : aUrl.getAllMessageReply
				,data : {
					id : oMessage.attr('data-dataId')
				}
				,beforeSend : function(){
					oBtnShowAllReply.text('加载中...');
				}
				,success : function(aResult){
					if(aResult.status  == 0){
						UBox.show(aResult.msg, 0);
						oBtnShowAllReply.text('展开全部回复');
						return;
					}
					oMessage.data('aRplyList', aResult.data);
					fShowShuoShuoComment(aResult.data);
				}
				,error : function(){
					oBtnShowAllReply.text('展开全部回复');
				}
			});
		});

		/**
		 * 查看所有说说评论回复操作
		 */
		oWrapMessages.delegate('[xid="btnShowAllReply"]', 'click', function(){
			var oComment = $(this).closest('[xid="comment"]')
			,oBtnShowAllReply = $(this);
			ajax({
				url : aUrl.getAllShuoShuoCommentReply
				,data :{id : oComment.attr('itemid')}
				,beforeSend : function(){
					oBtnShowAllReply.text('加载中...');
				}
				,success : function(aResult){
					if(aResult.status  == 0){
						UBox.show(aResult.msg, 0);
						oBtnShowAllReply.text('展开全部回复');
						return;
					}

					var aReplys = [];
					for(var i in aResult.data){
						var aTmpReply = aResult.data[i];
						aTmpReply.user_info.profile = aUrl.source + aTmpReply.user_info.profile;
						aTmpReply.reply_user_info.profile = aUrl.source + aTmpReply.reply_user_info.profile;
						var aReply = {
							id : aTmpReply.id
							,content : aTmpReply.content
							,time : aTmpReply.create_time
							,user : aTmpReply.user_info
							,reply_user : aTmpReply.reply_user_info
						};
						aReplys.push(_buildShuoShuoReply(aReply, false, aCurrentUser.id));
					}
					oComment.find('[xid="wrapReplys"]').html(aReplys.join(''));
				}
				,error : function(){
					oBtnShowAllReply.text('展开全部回复');
				}
			});
		});

		/**
		 * 删除留言板回复操作
		 */
		oWrapMessages.delegate('[xid="btnDeleteMessageReply"]', 'click', function(){
			var _this = this;
			UBox.confirm('确实要删除这条回复吗?', function(){
				var oReply = $(_this).closest('[xid="messageReply"]');
				ajax({
					url : aUrl.deleteMessageReply
					,data : {
						id : oReply.attr('itemid')
					}
					,success : function(aResult){
						if(aResult.status == 0){
							UBox.show(aResult.msg, 0);
							return;
						}

						oReply.slideUp('normal', function(){
							$(this).remove();
						});
					}
				});
			});
		});

		/**
		 * 分享PK或赛事
		 */
		oWrapMessages.delegate('[xid="btnShare"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this);
			var sourceType = oMessage.attr('data-type') == 20 ? 3 : 2;

			UAlert.config({
				user_id : aCurrentUser.id
				,sys_resource_url : aUrl.source
				,share_url : aUrl.publishShuoShuo
			});
			UAlert.alertShare(oMessage.attr('data-dataId'), sourceType, '伙伴们!我中奖了!你还不来试试!?');
		});

		/**
		 * 转发说说
		 */
		oWrapMessages.delegate('[xid="btnForward"]', 'click', function(){
			UAlert.config({
				user_id : aCurrentUser.id
				,sys_resource_url : aUrl.source
				,forward_shuoshuo_url : aUrl.publishShuoShuo
				,user_list_url : aUrl.friendList
			});
			UAlert.alertForwardShuoShuo(_getMessageDomByElement(this).attr('data-dataId'), 1);
		});

		/**
		 * 查看更多事件相关用户
		 */
		oWrapMessages.delegate('[xid="btnShowMoreUser"]', 'click', function(){
			var oMessage = _getMessageDomByElement(this)
			,oBtnShowMoreUser = $(this)
			,messageId = oMessage.attr('itemid')
			,dataType = oMessage.attr('data-type')
			,type = 0
			,aMessage = oMessage.data('aMessage')
			,aNoShowUserIds = [];
			if(oLastMoreUserList && oLastMoreUserList.attr('itemid') == messageId){
				if(oBtnShowMoreUser.data('isShow')){
					oLastMoreUserList.remove();
					$('[xid="btnShowMoreUser"]').removeClass('cur');
					oLastMoreUserList = null;
					oBtnShowMoreUser.data('isShow', false);
				}
				return;
			}else if(oLastMoreUserList){
				oLastMoreUserList.remove();
				$('[xid="btnShowMoreUser"]').removeClass('cur');
				oLastMoreUserList = null;
			}

			var fGetUserId = function(aUserList){
				var aResult = [];
				for(var i in aUserList){
					aResult.push(aUserList[i].id);
				}
				return aResult;
			};

			//确认要读取的用户列表类型和不要显示的用户列表
			if(JsTools.inArray(dataType, [
				,self.TYPE.AT_IN_SHUOSHUO
				,self.TYPE.AT_IN_SHUOSHUO_COMMENT
				,self.TYPE.RESHIPMENT_SHUOSHUO
				,self.TYPE.COMMENT_SHUOSHUO
				,self.TYPE.REPLY_IN_SHUOSHUO_COMMENT
			])){
				type = 1;
				aNoShowUserIds = fGetUserId(aMessage.support);
			}else if(dataType == self.TYPE.MATCH_FINISH){
				type = 5;
				aNoShowUserIds = fGetUserId(aMessage.users);
			}else{
				UBox.show('错误的事件类型！');
				return;
			}

			var fShowMoreUsers = function(aUserList){
				var aMoreUserList = [];
				for(var i in aUserList){
					var aUser = aUserList[i];
					aMoreUserList.push('<li xid="user" itemid="' + aUser.id + '">\
						' + _buildUser(aUser) + '\
						<p class="pub">\
							<span class="name ellipsis"><a href="#">' + getVipName(aUser.name, aUser.vip) + '</a></span>\
							<span class="part ellipsis">' + (aUser.gender > 0 ? ['男', '女'][aUser.gender - 1] : '') + ' ' + (aUser.age ? aUser.age + '岁' : '') + ' ' + aUser.province + aUser.city + '</span>\
						</p>\
						' + (aUser.is_friend ? '' : '<p class="follow">\
							<a class="act" href="javascript:void(0);" xid="btnAddFriend">\
								<i class="ico_event ico_event_add"></i>\
								好友\
							</a>\
						</p>') + '\
					</li>');

				}

				var oMoreUserList = $('<div class="event_pop" itemid="' + messageId + '">\
					<i class="arrow arrow_top"></i>\
					<i class="arrow arrow_top2"></i>\
					<a class="close" xid="btnCloseMoreUser" href="javascript:;">&#10005;</a>\
					<h2 class="title">赞过的人</h2>\
					<ul class="list">' + aMoreUserList.join('') + '</ul>\
				</div>').appendTo('body');
				oMoreUserList.find('[xid="btnCloseMoreUser"]').click(function(){
					oBtnShowMoreUser.removeClass('cur');
					oMoreUserList.hide(100);
					oLastMoreUserList = null;
				});
				oMoreUserList.find('[xid=btnAddFriend]').click(function(){
					UAlert.config({
						user_id : $(this).closest('[xid="user"]').attr('itemid')
						,sys_resource_url : aUrl.source
						,user_info_url : aUrl.userInfo
						,user_home_url : aUrl.userHome
						,apply_friend_url : aUrl.applyFriend
					});
					UAlert.alertApplyFriend();
				});

				var left = oBtnShowMoreUser.offset().left;
				var top = oBtnShowMoreUser.offset().top + oBtnShowMoreUser.height() + 10;
				oBtnShowMoreUser.addClass('cur').data('isShow', true);
				oMoreUserList.show(100).css({
					'left': left,
					'top': top
				});
				oLastMoreUserList = oMoreUserList;
			};

			var aMoreUserList = oMessage.data('aMoreUserList');
			if(aMoreUserList){
				fShowMoreUsers(aMoreUserList);
				return;
			}

			ajax({
				url : aUrl.moreUserList
				,data : {
					type : type
					,dataId : oMessage.attr('data-dataId')
					,aNoShowUserIds : aNoShowUserIds
				}
				,success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
						return;
					}else if(aResult.data.length == 0){
						return;
					}

					oMessage.data('aMoreUserList', aResult.data);
					fShowMoreUsers(aResult.data);
				}
			});
		});
	}
})(jQuery, window);