var urlGetProp = '';
var urlPutCart = '';
var urlGetNum = '';
var urlCountCartGold = '';
var urlSource = '';
var urlUBbExchange = '';
var urlUBbPay = '';
var urlCancelCart = '';
var urlBuyOne = '';
var urlGetNumerical = '';
var urlBuyFromCart = '';
var urlGetPackage = '';
var aCartProPiIDs = [];
var aPropIntroduce = [];
var selectedProp = 0;
var urlDiscardProp = '';
var objProp = false;
var toUserId = 0;
var urlSendProp = '';
var urlGetToolBar = '';
var urlGetSendProp = '';
var urlProfileError = '';
var urlGetMyProp = '';
var urlIgnoreMyProp = '';
var urlUseProp = '';
var lastEsId = 0;
var lastPropId = 0;
var notPropHtml = '<div class="notfound">\
						<p>您还没有道具哦，<br/>赶快到<a class="act" onclick="showMall(1)return false;" href="javascript:void()">道具商城</a>购买吧~~</p>\
					</div>';


function initProp(getProp, putCart, getNum, countCartGold, source, ubExchange, ubPay, cancelCart, buyOne, getNumerical, buyCart, getPackage, discardProp, sendProp, getToolBar, getSendProp, profileError, getMyProp, ignoreMyProp, useProp){
	urlGetProp = getProp;
	urlPutCart = putCart;
	urlGetNum = getNum;
	urlCountCartGold = countCartGold;
	urlSource = source;
	urlUBbExchange = ubExchange;
	urlUBbPay = ubPay;
	urlCancelCart = cancelCart;
	urlBuyOne = buyOne;
	urlGetNumerical = getNumerical;
	urlBuyFromCart = buyCart;
	urlGetPackage = getPackage;
	urlDiscardProp = discardProp;
	urlSendProp = sendProp;
	urlGetToolBar = getToolBar;
	urlGetSendProp = getSendProp;
	urlProfileError = profileError;
	urlGetMyProp = getMyProp;
	urlIgnoreMyProp = ignoreMyProp;
	urlUseProp = useProp;
}

function getPropHeader(type){
	if(type == 1){
		var mall = 'class="cur"';
		var myPackage = '';
		var getSendProp = '';
	}else if(type == 2){
		var mall = '';
		var myPackage = 'class="cur"';
		var getSendProp = '';
	}else if(type == 3){
		var mall = '';
		var myPackage = '';
		var getSendProp = 'class="cur"';
	}
	var headHtml = '<div id="mask" class="mask" style="display:block;"></div>\
				<div id="props" class="props">\
					<div class="hd">\
						<a onclick="showMall(1);return false;" '+mall+' href="javascript:;"><i class="ico_props ico_props_mall"></i>道具商城</a>\
						<a onclick="showPakget();return false;" '+myPackage+' href="javascript:;"><i class="ico_props ico_props_mine"></i>我的道具</a>\
						<a ' + getSendProp + ' onclick="showGetProp(1);return false;" href="javascript:;"><i class="ico_props ico_props_receive"></i>领取道具</a>\
					</div>\
					<a onclick="closeProp();return false;" class="close" href="javascript:;" title="关闭">&times;</a>\
					<div class="bd">';
	return headHtml;
}

function showPakget(){
	aPropIntroduce = [];
	ajax({
		url : urlGetPackage,
		type : 'post',
		success:function(aResult){
			var headHtml = getPropHeader(2);
			var html = '';
			var aPropList = aResult.data.prop_list;
			var aGroupList = aResult.data.group_list;
			var aFriendList = aResult.data.friend_list;
			var propHtml = '';
			var myPropCount = 0;


			for(var i = 0; i < aPropList.length; i++){
				for(var j = 0; j < aPropList[i].nums; j++){
					if(j == 0 && i == 0){
						var selected = 'class="selected"';
						selectedProp = aPropList[i].id;
					}else{
						var selected = '';
					}
					propHtml += '<li onclick="showIntro('+aPropList[i].id+','+i+', this);return false;" '+selected+'>\
								<a href="javascript:void(0)" onclick="return false;">\
									<span class="img"><img src="'+ urlSource + aPropList[i].ico+'" width="66" height="66" alt=""></span>\
									<span class="ellipsis name" title="'+aPropList[i].name+'">'+aPropList[i].name+'</span>\
								</a>\
							</li>';
				}
				myPropCount += aPropList[i].nums;

				var haveList = '';
				if(aPropList[i].have_list.length > 0){
					haveList += '<div class="member">\
								<p>他们也有这个道具</p>\
								<ul class="list">';
					for(var k = 0; k < aPropList[i].have_list.length; k++){
						haveList += '<li title="' + aPropList[i].have_list[k].name + '"><a href="javascript:void(0)" onclick="return false;"><img real="'+ urlSource + aPropList[i].have_list[k].profile+'" onload="h(this);" src="' + urlProfileError + '"  width="30" height="30" alt=""/></a></li>';
					}
					haveList += '</ul>\
							</div>';
				}

				//道具包内使用道具
				var propUseHtml = '',
					propFun = '';
				if(aPropList[i].type == 5 || aPropList[i].type == 6){
					switch(aPropList[i].prop_code){
						case "sbjf1":propFun = 'useSbjf1';break;
						case "sbjf3":propFun = 'useSbjf3';break;
						case "sbjf7":propFun = 'useSbjf7';break;
						case "djbkr":propFun = 'useDjbkr';break;
						default:propFun = 'useDjbkr';
					}
					propUseHtml += '<p class="use">\
						<a onclick="' + propFun + '(' + aPropList[i].id + ', this);return false;" id="xxxxx" class="btn btn_orange" href="javascript:;">使 用</a>\
					</p>';
				}

				var propIntroHtml = '<div class="intro">\
					<h3 class="title">道具介绍</h3>\
					<p class="img">\
						<img src="'+ urlSource + aPropList[i].ico+'" width="66" height="66" alt="">\
					</p>\
					<p class="desc">\
						名称：'+aPropList[i].name+'<br/>\
						功效：'+aPropList[i].effect+'<br/>\
						使用范围：'+aPropList[i].range+'<br/>\
					</p>\
					' + propUseHtml +'\
				</div>' + haveList;
				aPropIntroduce.push(propIntroHtml);
			}
			for(var i = 0; i < (aResult.data.prop_count - myPropCount); i++){
				propHtml += '<li></li>';
			}

			if(myPropCount <= 0){
				var firstProp = notPropHtml;
				var style = 'style="display:none;"';
			}else{
				var firstProp = aPropIntroduce[0];
				var style = '';
			}

			var groupHtml = '<li onclick="selectGroup(0, this);return false;" class="cur"><a href="javascript:void(0)"><b>全部</b></a></li>';
			for(var i = 0; i < aGroupList.length; i++){
				groupHtml += '<li onclick="selectGroup('+aGroupList[i].id+', this);return false;"><a href="javascript:void(0)"><b>'+aGroupList[i].group_name+'</b></a></li>';
			}

			var friendHtml = '';
			for(var i = 0; i < aFriendList.length; i++){
				friendHtml += '<li xid="friend'+aFriendList[i].group_id+'" onclick="selectFriend('+aFriendList[i].id+', this);return false;">\
								<a href="javascript:void(0)">\
									<span class="head"><img onload="h(this);" real="'+ urlSource + aFriendList[i].profile+'" width="30" height="30" src="' + urlProfileError + '" alt=""/></span>\
									<span class="ellipsis name">'+aFriendList[i].name+'</span>\
								</a>\
							</li>';
			}
			html += headHtml + '<!--我的道具 [-->\
			<div id="myPropList" class="props_mine"">\
				<div class="cont">\
					<div class="list">\
						<ul id="propList"> '+propHtml+'</ul>\
					</div>\
				</div>\
				<div id="propIntroduce" class="side"> '+firstProp+' </div>\
			</div>\
			<!--我的道具 ]-->\
			<!--赠送 [-->\
			<div id="sendProp" class="props_handsel" style="display:none;">\
				<div class="side">\
					<div class="menu">\
						<h3>请选择好友</h3>\
						<ul id="groupList" class="group"> '+groupHtml+'</ul>\
					</div>\
				</div>\
				<div class="cont">\
					<p class="say"><input id="sendMessage" maxlength="30" class="text" type="text" placeholder="说点什么吧（30字内）"/></p>\
					<div class="friends">\
						<ul id="friendList" class="list">'+friendHtml+' </ul>\
					</div>\
				</div>\
			</div>\
			<!--赠送 ]-->\
			<div class="ft">\
				<!--我的道具用 [-->\
				<p xid="propBottom" class="count fl">共有道具总数 <em id="myPropSum">'+myPropCount+'</em></p>\
				<p xid="propBottom" class="prompt fl">道具包容量不够？ <a class="act" href="javascript:void(0)"  onclick="showMall(1);return false;">点我马上扩容！</a></p>\
				<p id="sendBottom" xid="propBottom" '+style+' class="btnbox fr">\
					<a onclick="showSendFriend();return false;" class="btn btn_orange" href="javascript:;">赠  送</a>\
					<a onclick="discardProp();return false;" class="btn btn_gray" href="javascript:;">丢  弃</a>\
				</p>\
				<!--我的道具用 ]-->\
				<!--赠送 [-->\
				<p xid="sendBottom" class="count fl" style="display:none;">已选好友 <a class="act" href="javascript:void(0)"  id="selectedName"></a></p>\
				<p xid="sendBottom" class="btnbox fr" style="display:none;">\
					<a onclick="sendProp();return false;" class="btn btn_orange" href="javascript:;">赠  送</a>\
					<a onclick="returnPackage();return false;" class="btn btn_gray" href="javascript:;">取  消</a>\
				</p>\
				<!--赠送 ]-->\
			</div>';

			closeProp();
			$('body,#header,#newHead').last().append(html);
			$('#mask').height($(document).height());
			cartSwitch();
			objProp = $('#propList li:first');
		}
	});
}

function showGetProp(type){
	$('#noticeSendProp').remove();
	var headHtml = getPropHeader(3);
	var html = headHtml + '<!--领取 [-->\
			<div class="props_receive">\
				<div id="sendPropMenu" class="menu">\
					<a onclick="getSendProp(1, this);return false;" href="#"><i class="ico_props ico_props_friends"></i>好友赠送</a>\
					<a onclick="getSendProp(2, this);return false;" href="javascript:;"><i class="ico_props ico_props_mission"></i>系统奖励</a>\
				</div>\
				<div id="sendPropList" class="list"> </div>\
			</div>\
			<!--领取 ]-->\
		</div>\
	</div><!--道具 ]-->';
	closeProp();
	$('body,#header,#newHead').last().append(html);
	$('#mask').height($(document).height());
	getSendProp(1, $('#sendPropMenu a:first'));
}

function getSendProp(type, obj){
	ajax({
		url : urlGetSendProp,
		data : {type : type},
		type : 'post',
		success:function(aResult){
			$('#sendPropMenu a').removeClass('cur');
			$(obj).addClass('cur');

			var html = '';
			var data = aResult.data;
			if(data.length <= 0){
				html += '<p class="air">您还没有可领取的道具，快去<a onclick="showMall(1);return false;" class="act" href="javascript:void(0)">道具商城</a>购买吧~</p>';
			}else{
				html += '<ul>';
				for(var i = 0; i < data.length; i++){
					if(type == 1){
						var whoHtml = '<p class="head"><img src="' + urlProfileError + '" onload="h(this);" real="' + urlSource + data[i].user_info.profile + '" width="30" height="30" alt=""/></p>\
							<p class="part">\
								<span class="name">' + data[i].user_info.name + '</span>\
								<span class="time">' + data[i].create_time + '</span>\
								给您送了一个<span class="sum">' + data[i].prop_info.name + '</span>\
							</p>\
							<p class="advice">赠  言：' + data[i].message + '</p>';
					}else if(type == 2){
						var whoHtml = '<p class="part" style="margin-left:-49px;">\
								<span class="name">系统</span>\
								<span class="time">' + data[i].create_time + '</span>\
								奖励您一个<span class="sum">' + data[i].prop_info.name + '</span>\
							</p>';
					}
					html += '<li>' + whoHtml + '<p class="intro">\
								<span class="img"><img src="' + urlSource +  data[i].prop_info.ico + '" width="40" height="40" alt=""></span>\
								<span class="desc">\
									功效：' + data[i].prop_info.effect + '<br/>\
									使用范围：' + data[i].prop_info.range + '\
								</span>\
							</p>\
							<p class="btnbox">\
								<a onclick="getProp(' + data[i].id + ', ' + type + ', this);return false;" class="btn btn_orange" href="javascript:;">领  取</a>\
								<a onclick="ignoreProp(' + data[i].id + ', ' + type + ', this);return false;" class="btn btn_gray" href="javascript:;">忽  略</a>\
							</p>\
						</li>';
				}
				html += '</ul>';
			}
			$('#sendPropList').html(html);
		}
	});
}

function getProp(id, type, obj){
	if(type != 1 && type != 2){
		UBox.show('参数错误', -1);
		return;
	}
	var clickEvent = $(obj).attr('onclick');
	$(obj).attr('onclick', '');
	ajax({
		url : urlGetMyProp,
		data : {id : id, type : type},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				$(obj).parents('li').slideUp('normal', function(){
					$(this).remove();
				});
			}else{
				$(obj).attr('onclick', clickEvent);
			}
		}
	});
}

function ignoreProp(id, type, obj){
	if(type != 1 && type != 2){
		UBox.show('参数错误', -1);
		return;
	}
	var clickEvent = $(obj).attr('onclick');
	$(obj).attr('onclick', '');

	ajax({
		url : urlIgnoreMyProp,
		data : {id : id, type : type},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				$(obj).parents('li').slideUp('normal', function(){
					$(this).remove();
				});
			}else{
				$(obj).attr('onclick', clickEvent);
			}
		}
	});
}

function showMall(type){
	ajax({
		url : urlGetNum,
		type : 'post',
		success:function(aResult){
			var html = '';
			var propList = buildPropList(aResult.data.list);
			var data = aResult.data;
			var cartHtml = '';
			for(var i = 0; i < 24; i++){
				if(data.cart[i] != undefined){
					cartHtml += '<li id="cart'+data.cart[i].id+'">\
									<a onclick="selectCartProp('+data.cart[i].id+', this);return false;" href="javascript:void(0);">\
										<span class="img"><img src="'+ urlSource + data.cart[i].ico+'" width="34" height="34" alt=""/></span>\
										<span class="num">'+data.cart[i].nums+'</span>\
									</a>\
								</li>';
				}else{
					cartHtml += '<li xid="empty"></li>';
				}
			}
			var headHtml = getPropHeader(1);
			html += headHtml + '<div class="props_mall">\
							<div class="props_cate">\
								<div id="propMenu" class="menu">\
									<a onclick="getPropList(1, this);return false;" class="cur" href="javascript:;"><i class="ico_props ico_props_points"></i>闯关道具</a>\
									<a onclick="getPropList(2, this);return false;" href="javascript:;"><i class="ico_props ico_props_universal"></i>通用答题道具</a>\
									<a onclick="getPropList(3, this);return false;" href="javascript:;"><i class="ico_props ico_props_match"></i>PK和比赛道具</a>\
									<a onclick="getPropList(4, this);return false;" href="javascript:;"><i class="ico_props ico_props_expansion"></i>经验和扩容道具</a>\
									<a onclick="getPropList(5, this);return false;" href="javascript:;"><i class="ico_props ico_props_hot"></i>热门打折道具</a>\
									<a onclick="getPropList(6, this);return false;" href="javascript:;"><i class="ico_props ico_props_dress"></i>装扮类道具</a>\
								</div>\
								<div id="propList" class="list">'+propList+'</div>\
							</div>\
							<div class="props_total">\
								<div class="cart">\
									<div class="title">\
										<a onclick="deleteCart();return false;" id="deleteProp" style="display:none" class="del" href="javascript:;">删除道具</a>\
										<i class="ico_props ico_props_cart"></i>\
										购物车商品总数\
										<span id="propSum" class="sum">'+data.cartCount+'</span>\
									</div>\
									<div class="info">\
										<a id="prev" class="prev"><i class="arrow"></i></a>\
										<div class="list">\
											<ul id="cartList"> '+cartHtml+' </ul>\
										</div>\
										<a id="next" class="next"><i class="arrow"></i></a>\
									</div>\
								</div>\
								<div class="wealth">\
									<ul>\
										<li class="name"><i class="ico_props ico_props_wealth"></i>我的财富</li>\
										<!--li>U  币 </li-->\
										<li>金  币</li>\
										<li></li>\
										<li class="prompt"><!--span>会员价指的是<br/>白金会员价哦！</span--></li>\
										<!--li id="myUb" class="num">'+data.num.ub+'</li-->\
										<li id="myGold" class="num">'+data.num.gold+'</li>\
										<li></li>\
									</ul>\
								</div>\
							</div>\
						</div>\
						<!--商城 [-->\
					</div>\
					<div class="ft">\
						<!--商城用 [-->\
						<p class="count fl">共计：<em id="cartGoldCount" class="row">0</em> 金币</p>\
						<!--$gXxtUserId<p class="btnbox fr">\
							<a target="_blank" class="btn btn_green" href="'+urlUBbPay+'">U币充值</a>\
							<a target="_blank" class="btn btn_orange" href="'+urlUBbExchange+'">兑换金币</a>\
						</p>-->\
						<p class="btnbox_buy fr">\
							<a onclick="buyFromCart();return false;" class="btn btn_orange" href="javascript:;">购  买</a>\
						</p>\
						<!--商城用 ]-->\
					</div>\
				</div>';
			closeProp();
			$('body,#header,#newHead').last().append(html);
			addCartToMemory();
			countCartGold();
			$('#mask').height($(document).height());
			cartSwitch();
		}
	});

}

function putCart(id, obj){
	var cartNums = $('#cartList li[xid="full"]').length;
	if(cartNums >= 24){
		UBox.show('购物车已满', -1);
		return;
	}

	var nums = parseInt($(obj).parents('.btnbox').prev().find('input').val());
	ajax({
		url : urlPutCart,
		data : {id : id, nums : nums},
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				var objCartPropNums = $('#cart' + id);
				if(objCartPropNums.length > 0){
					var beforNums = parseInt($(objCartPropNums).find('span.num').text());
					var afterNums = beforNums + nums;
					$(objCartPropNums).find('span.num').text(afterNums);
				}else{
					var src = $(obj).parents('.btnbox').prev().prev().prev().find('img').attr('src');
					var html = '	<a onclick="selectCartProp('+id+', this);return false;" href="javascript:void(0);">\
										<span class="img"><img src="'+ src+'" width="34" height="34" alt=""/></span>\
										<span class="num">'+nums+'</span>\
									</a>';
					var objCart = $('#cartList li[xid="empty"]:first');
					$(objCart).attr('id', 'cart' + id);
					$(objCart).attr('xid', 'full');
					$(objCart).html(html);
				}
				var beforeSum = parseInt($('#propSum').text());
				var afterSum = beforeSum + nums;
				$('#propSum').text(afterSum);
				addCartToMemory();
				countCartGold();
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function selectCartProp(id, obj){
	var nums = parseInt($(obj).find('span.num').text());
	var liObj = $(obj).parents('li');
	if($(liObj).hasClass('selected')){
		$(liObj).removeClass('selected');
		for(var i = 0; i < nums; i++){
			aCartProPiIDs = arrRemove(aCartProPiIDs, id);
		}
	}else{
		$(liObj).addClass('selected');
		for(var i = 0; i < nums; i++){
			aCartProPiIDs.push(id);
		}
	}
	if(aCartProPiIDs.length > 0){
		$('#deleteProp').show();
	}else{
		$('#deleteProp').hide();
	}
}

function countCartGold(){
	ajax({
		url : urlCountCartGold,
		data : {ids : aCartProPiIDs},
		type : 'post',
		success:function(aResult){
			if(!aResult.data){
				aResult.data = 0;
			}
			$('#cartGoldCount').text(aResult.data);
			//重新计算购物车总价
			aCartProPiIDs = [];
		}
	});
}


function closeProp(){
	$('#mask,#props').remove();
}

function buildPropList(data){
	var html = '';
	if(data.length <= 0){
		html = '<p class="air"">该分类暂时没有道具！</p>';
	}else{
		html += '<ul>';
		for(var i = 0; i < data.length; i++){
			html += '<li>\
						<p class="part">\
							<span class="img"><a href="javascript:void(0)" onclick="return false;"><img src="' + urlSource + data[i].ico+'" width="66" height="66" alt=""/></a></span>\
							<span class="ellipsis name">'+data[i].name+'</span>\
						</p>\
						<p class="price">\
							价&nbsp;&nbsp;&nbsp;&nbsp;格：'+data[i].price+'<br/>\
						</p>\
						<p class="num">\
							<span>数量</span>\
							<a class="add" onclick="minusPropNums(this);return false;" href="javascript:;"><i class="arrow"></i></a>\
							<input xid="nums" class="text" type="text" value="1"/>\
							<a onclick="addPropNums(this);return false;" class="min" href="javascript:;"><i class="arrow"></i></a>\
						</p>\
						<p class="btnbox">\
							<!---a onclick="buyOneKind('+data[i].id+', this)" class="buy" href="javascript:void(0);">购买</a--->\
							<a onclick="putCart('+data[i].id+', this);return false;" class="fav" href="javascript:void(0);">加入购物车</a>\
						</p>\
						<p class="overlay">\
							功效：'+data[i].effect+'<br/>\
							使用范围：'+data[i].range+'<br/>\
							已卖出：<em class="sum">'+data[i].purchase_total+'</em>\
						</p>\
					</li>';
		}
		html += '</ul>';
	}
	return html;
}

function minusPropNums(obj){
	var objNum = $(obj).next();
	var val = parseInt(objNum.val()) - 1;
	if(val < 1){
		val = 1;
	}
	objNum.val(val);
}

function addPropNums(obj){
	var objNum = $(obj).prev();
	var val = parseInt(objNum.val()) + 1;
	if(val > 99){
		val = 99;
	}
	objNum.val(val);
}

function deleteCart(){
	//删除前先刷新要删除ID
	aCartProPiIDs = [];
	var aCartProp = $('#cartList li.selected');;
	aCartProp.each(function(){
		var nums = 0,
			$this = $(this);
			nums = $this.find('span.num').text();
			propId = $this.attr('id').substr(4);
		for(var i = 0; i < nums; i++){
			aCartProPiIDs.push(propId);
		}
	});

	ajax({
		url : urlCancelCart,
		data : {ids : aCartProPiIDs},
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				var deleteNums = aCartProPiIDs.length;
				var beforeSum = parseInt($('#propSum').text());
				var afterSum = beforeSum - deleteNums;
				$('#propSum').text(afterSum);
				aCartProPiIDs = [];
				$('#deleteProp').hide();

				var selectedObj = $('#cartList li.selected');
				var selectedNums = selectedObj.length;
				$(selectedObj).remove();
				var html = '';
				for(var i = 0; i < selectedNums; i++){
					html += '<li xid="empty"></li>';
				}
				$('#cartList').append(html);
				$('#cartGoldCount').text(0);
				addCartToMemory();
				countCartGold();
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function getPropList(type, obj){
	ajax({
		url : urlGetProp,
		data : {type : type},
		type : 'post',
		success:function(aResult){
			$('#propMenu a').removeClass('cur');
			$(obj).addClass('cur');
			var data = aResult.data;
			var html = buildPropList(data);
			$('#propList').html(html);
		}
	});
}

function buyOneKind(id, obj){
	var clickEvent = $(obj).attr('onclick');
	$(obj).attr('onclick', '');
	var nums = parseInt($(obj).parents('.btnbox').prev().find('input').val());
	ajax({
		url : urlBuyOne,
		data : {id : id, nums : nums},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			$(obj).attr('onclick', clickEvent);
			if(aResult.status == 1){
				getNumerical();
				if($('#myPropUse').length > 0){
					getPropBar(propType);
				}
			}
		}
	});
}

function buyFromCart(){
	aCartProPiIDs = [];
	addCartToMemory();
	if(aCartProPiIDs.length <= 0){
		UBox.show('请先在购物车选择要购买的道具', -1);
		return;
	}
	ajax({
		url : urlBuyFromCart,
		data : {ids : aCartProPiIDs},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				aCartProPiIDs = [];
				$('#propSum').text(0);
				$('#deleteProp').hide();

				var selectedObj =  $('#cartList li').not('[xid="empty"]');
				var selectedNums = selectedObj.length;
				$(selectedObj).remove();

				var html = '';
				for(var i = 0; i < selectedNums; i++){
					html += '<li xid="empty"></li>';
				}
				$('#cartList').append(html);
				$('#cartGoldCount').text(0);

				getNumerical();
				if($('#myPropUse').length > 0){
					getPropBar(propType);
				}
			}
		}
	});
}

function getNumerical(){
	ajax({
		url : urlGetNumerical,
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				$('#myUb').text(aResult.data.ub);
				$('#myGold').text(aResult.data.gold);
			}
		}
	});
}

function showIntro(id, i, obj){
	$('#propList li.selected').removeClass('selected');
	$(obj).addClass('selected');
	$('#propIntroduce').html(aPropIntroduce[i]);
	selectedProp = id;
	objProp = obj;
}

function selectGroup(id, obj){
	if(id == 0){
		$('#friendList li').show();
	}else{
		$('#friendList li').hide();
		$('#friendList li[xid="friend' + id + '"]').show();
	}
	$('#groupList li.cur').removeClass('cur');
	$(obj).addClass('cur');
}

function selectFriend(id, obj){
	var name = $(obj).find('span.name').text();
	$('#selectedName').text(name);
	$('#friendList li.selected').removeClass('selected');
	$(obj).addClass('selected');
	toUserId = id;
}

function discardProp(){
	if(selectedProp <= 0){
		UBox.show('请先选择道具', -1);
		return;
	}
	UBox.confirm('您确定要丢去该道具？', function(){
		ajax({
			url : urlDiscardProp,
			data : {id : selectedProp},
			type : 'post',
			success:function(aResult){
				UBox.show(aResult.msg, aResult.status);
				if(aResult.status == 1){
					$(objProp).remove();
					$('#propList').append('<li></li>');
					var beforeSum = parseInt($('#myPropSum').text());
					var afterSum = beforeSum - 1;
					$('#myPropSum').text(afterSum);
					if(afterSum <= 0){
						$('#propIntroduce').html(notPropHtml);
						$('#sendBottom').hide();
					}

				}
			}
		});
	});
}

function showSendFriend(){
	$('#myPropList').hide();
	$('p[xid="propBottom"]').hide();
	$('#sendProp').show();
	$('p[xid="sendBottom"]').show();
}

function returnPackage(){
	$('#myPropList').show();
	$('p[xid="propBottom"]').show();
	$('#sendProp').hide();
	$('p[xid="sendBottom"]').hide();
}

function sendProp(){
	if(toUserId <= 0){
		UBox.show('请先选择好友', -1);
		return;
	}
	var message = $.trim($('#sendMessage').val());
	if(!message || message == ''){
		UBox.show('给您的好友留个言吧', -1);
		return;
	}
	if(selectedProp <= 0){
		UBox.show('请选择道具', -1);
		return;
	}
	ajax({
		url : urlSendProp,
		data : {toUserId : toUserId, message : message, propId : selectedProp},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				showPakget();
			}
		}
	});
}

function getPropBar(type){
	ajax({
		url : urlGetToolBar,
		data : {type : type},
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				var data = aResult.data;
				var html = '';
				var nums = 0;
				for(var i = 0; i < data.enable.length; i++){
					html += '<li title="' + data.enable[i].name + '：' + data.enable[i].effect + '" onclick="'+data.enable[i].fun+'('+data.enable[i].id+', this);return false;">\
                            <a href="javascript:void(0);return false;">\
                                <span class="ico_props_tool tool_li_bg">\
			                        <img src="' + urlSource+data.enable[i].ico + '" width="48" height="48" alt="">\
			                        <i class="ico_props_tool tool_li_sub">' + data.enable[i].nums + '</i>\
			                    </span>\
			                    <span class="w_mask"></span>\
			                    <span class="overlay">使用</span>\
                            </a>\
                        </li>';
					nums++;

				}
				for(var i = 0; i < data.disable.length; i++){
					html += '<li title="' + data.disable[i].name + '道具暂不适用" class="disabled">\
						<a href="javascript:void(0);" class="disable" onclick="return false;">\
							<span class="ico_props_tool tool_li_bg">\
		                        <img src="'+urlSource + data.disable[i].ico+'" width="48" height="48" alt="">\
		                        <i class="ico_props_tool tool_li_sub">' + data.disable[i].nums + '</i>\
		                    </span>\
		                    <span class="w_mask"></span>\
		                    <span class="overlay">禁用</span>\
						</a>\
					</li>';
					nums++;
				}
				if(nums <= 0){
					html += '<li><a href="javascript:void(0);" onclick="return false;">\
							<span class="ico_props_tool tool_li_bg"></span>\
						</a></li>';
				}
				for(var j = 0; j < (21 - nums); j++){
					html += '<li><a href="javascript:void(0);" onclick="return false;">\
							<span class="ico_props_tool tool_li_bg"></span>\
						</a></li>';
				}
				$('#myPropUse').html(html);
				carousel_a('#props_tool_new', '#props_tool_new .list ul', 5, 8);
				hoverMask('#myPropUse', '.w_mask,.overlay,.overlay_disable', false);
				props_tool_new();
				//cartSwitch();
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function usePropCallBack(obj){
	var before = parseInt($(obj).find('i.tool_li_sub').text());
	var after = before - 1;
	if(after <= 0){
		$(obj).hide(400);
	}else{
		$(obj).find('i.tool_li_sub').text(after);
	}

	//处理道具商城使用后的效果
	$(obj).parent().parent().parent().parent().find('#propList li[class="selected"]').remove();
	$('#propList').append('<li></li>');
	$(obj).parent().parent().parent().find('div.intro, div.member').remove();
}

function buildEsParms(id, esId){
	var aData = {};
	if(typeof(matchIdUsePropFlag) != 'undefined'){
		aData = {id : id, esId : esId, game : 'match', match_id: matchIdUsePropFlag};
	}else{
		aData = {id : id, esId : esId};
	}
	return aData;
}

function useSlyz(id, obj){
	var aEs = ES.oLastQuestion.data('es');
	var esType = aEs.type_id;
	if(esType != 1 && esType != 2){
		UBox.show('该道具只适用于选择题', -1);
		return;
	}
	var esId = aEs.id;
	if(lastEsId == esId){
		UBox.show('一道题目只可以排除错误答案一次喔', -1);
		return;
	}
	lastEsId = esId;
	ajax({
		url : urlUseProp,
		data : buildEsParms(id, esId),
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				usePropCallBack(obj);
				var oQuestion = ES.oLastQuestion;
				oQuestion.removeOption(aEs.options_relation[aResult.data]);
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function useSjyz(id, obj){
	var aEs = ES.oLastQuestion.data('es');
	var esType = aEs.type_id;
	if(esType != 1 && esType != 2){
		UBox.show('该道具只适用于选择题', -1);
		return;
	}
	var esId = aEs.id;
	if(lastEsId == esId){
		UBox.show('一道题目只可以排除错误答案一次喔', -1);
		return;
	}
	lastEsId = esId;
	ajax({
		url : urlUseProp,
		data : buildEsParms(id, esId),
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				usePropCallBack(obj);
				var oQuestion = ES.oLastQuestion;
				for(var i = 0; i < aResult.data.length; i++){
					oQuestion.removeOption(aEs.options_relation[aResult.data[i]]);
				}
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function useSlzy(id, obj){
	var aEs = ES.oLastQuestion.data('es');
	var esId = aEs.id;
	if(lastEsId == esId && lastPropId == id){
		UBox.show('答案已经出来啦', -1);
		return;
	}
	lastEsId = esId;
	ajax({
		url : urlUseProp,
		data : buildEsParms(id, esId),
		type : 'post',
		success:function(aResult){
			if(aResult.status == 1){
				usePropCallBack(obj);
				var aAnswer = aResult.data;
				var oQuestion = ES.oLastQuestion;
				oQuestion.writeAnswer(aAnswer);
				lastPropId = id;
			}else{
				UBox.show(aResult.msg, aResult.status);
			}
		}
	});
}

function useDjbkr(id, obj){
	ajax({
		url : urlUseProp,
		data : {id : id},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				usePropCallBack(obj);
			}
		}
	});
}

function useSbjf1(id, obj){
	doublePoins(id, obj);
}

function useSbjf3(id, obj){
	doublePoins(id, obj);
}

function useSbjf7(id, obj){
	doublePoins(id, obj);
}

function doublePoins(id, obj){
	ajax({
		url : urlUseProp,
		data : {id : id},
		type : 'post',
		success:function(aResult){
			UBox.show(aResult.msg, aResult.status);
			if(aResult.status == 1){
				usePropCallBack(obj);
			}
		}
	});
	return false;
}

function addCartToMemory(){
	aCartProPiIDs = [];
	var aCartProp = $('#cartList li').not('[xid="empty"]');
	aCartProp.each(function(){
		var nums = 0,
			$this = $(this);
			nums = $this.find('span.num').text();
			propId = parseInt($this.attr('id').substr(4));
		for(var i = 0; i < nums; i++){
			aCartProPiIDs.push(propId);
		}
	});
}


// 道具条新特效
function props_tool_new() {
    var $listLiWidth = $('.props_tool_new .list li').width();
    var $listLiLength = $('.props_tool_new .list li').length;
    var $optsWidth = $('.props_opts').width();
    var $optsMR = $('.props_opts').css('margin-right');
	var w1 = ($listLiWidth + 5)*$listLiLength + parseInt($('.props_tool_new .list ul').css('left'))*-1 + 'px';
	var w2 = $optsWidth + 'px';
	$('.props_tool_new .list ul').css({'margin-left' : w1});
	$('.props_opts ul').css({'margin-left' : w2});
	$('.prop_show').removeClass('prop_show').addClass('prop_hide')

    $('.prop_hide').click(function(){
        var _this = $(this);
        if(_this.hasClass('prop_show')){
            $('.props_tool_new .list ul').animate({
                'margin-left' : w1
            },300);

            $('.props_opts ul').animate({
                'margin-left' : w2
            },300);
            _this.removeClass('prop_show').addClass('prop_hide')
        }else{
            $('.props_tool_new .list ul').animate({
                'margin-left' : '0'
            },300);

            $('.props_opts ul').animate({
                'margin-left' : 0
            },300);
            _this.removeClass('prop_hide').addClass('prop_show')
        }
		return false;
    });

}