<?php
$face = array(
	'name' => '兔斯基表情'
);
$face['name'] = "兔斯基表情";

for($i = 0; $i < 38; $i++){
	$face['aImgList'][] = array('src'=>$i.'.gif', 'sign'=>'[face]face1/'.$i.'.gif[/face]');
}
echo $_GET['jsoncallback'] . '(' . json_encode($face) . ');';
