<?php
$aFace = array(
  'name' => '经典表情',
  'aImgList' => 
  array(
    array(
      'src' => '0.gif',
      'sign' => '[face]qq/0.gif[/face]',
    ),
    array(
      'src' => '1.gif',
      'sign' => '[face]qq/1.gif[/face]',
    ),
    array(
      'src' => '2.gif',
      'sign' => '[face]qq/2.gif[/face]',
    ),
    array(
      'src' => '3.gif',
      'sign' => '[face]qq/3.gif[/face]',
    ),
    array(
      'src' => '4.gif',
      'sign' => '[face]qq/4.gif[/face]',
    ),
    array(
      'src' => '5.gif',
      'sign' => '[face]qq/5.gif[/face]',
    ),
    array(
      'src' => '7.gif',
      'sign' => '[face]qq/7.gif[/face]',
    ),
    array(
      'src' => '8.gif',
      'sign' => '[face]qq/8.gif[/face]',
    ),
    array(
      'src' => '9.gif',
      'sign' => '[face]qq/9.gif[/face]',
    ),
    array(
      'src' => '10.gif',
      'sign' => '[face]qq/10.gif[/face]',
    ),
    array(
      'src' => '11.gif',
      'sign' => '[face]qq/11.gif[/face]',
    ),
    array(
      'src' => '12.gif',
      'sign' => '[face]qq/12.gif[/face]',
    ),
    array(
      'src' => '13.gif',
      'sign' => '[face]qq/13.gif[/face]',
    ),
    array(
      'src' => '14.gif',
      'sign' => '[face]qq/14.gif[/face]',
    ),
    array(
      'src' => '15.gif',
      'sign' => '[face]qq/15.gif[/face]',
    ),
    array(
      'src' => '16.gif',
      'sign' => '[face]qq/16.gif[/face]',
    ),
    array(
      'src' => '17.gif',
      'sign' => '[face]qq/17.gif[/face]',
    ),
    array(
      'src' => '18.gif',
      'sign' => '[face]qq/18.gif[/face]',
    ),
    array(
      'src' => '19.gif',
      'sign' => '[face]qq/19.gif[/face]',
    ),
    array(
      'src' => '20.gif',
      'sign' => '[face]qq/20.gif[/face]',
    ),
    array(
      'src' => '21.gif',
      'sign' => '[face]qq/21.gif[/face]',
    ),
    array(
      'src' => '22.gif',
      'sign' => '[face]qq/22.gif[/face]',
    ),
    array(
      'src' => '23.gif',
      'sign' => '[face]qq/23.gif[/face]',
    ),
    array(
      'src' => '24.gif',
      'sign' => '[face]qq/24.gif[/face]',
    ),
    array(
      'src' => '25.gif',
      'sign' => '[face]qq/25.gif[/face]',
    ),
    array(
      'src' => '26.gif',
      'sign' => '[face]qq/26.gif[/face]',
    ),
    array(
      'src' => '27.gif',
      'sign' => '[face]qq/27.gif[/face]',
    ),
    array(
      'src' => '28.gif',
      'sign' => '[face]qq/28.gif[/face]',
    ),
    array(
      'src' => '29.gif',
      'sign' => '[face]qq/29.gif[/face]',
    ),
    array(
      'src' => '30.gif',
      'sign' => '[face]qq/30.gif[/face]',
    ),
    array(
      'src' => '31.gif',
      'sign' => '[face]qq/31.gif[/face]',
    ),
    array(
      'src' => '32.gif',
      'sign' => '[face]qq/32.gif[/face]',
    ),
    array(
      'src' => '33.gif',
      'sign' => '[face]qq/33.gif[/face]',
    ),
    array(
      'src' => '34.gif',
      'sign' => '[face]qq/34.gif[/face]',
    ),
    array(
      'src' => '35.gif',
      'sign' => '[face]qq/35.gif[/face]',
    ),
    array(
      'src' => '36.gif',
      'sign' => '[face]qq/36.gif[/face]',
    ),
    array(
      'src' => '37.gif',
      'sign' => '[face]qq/37.gif[/face]',
    ),
    array(
      'src' => '38.gif',
      'sign' => '[face]qq/38.gif[/face]',
    ),
    array(
      'src' => '39.gif',
      'sign' => '[face]qq/39.gif[/face]',
    ),
    array(
      'src' => '40.gif',
      'sign' => '[face]qq/40.gif[/face]',
    ),
    array(
      'src' => '41.gif',
      'sign' => '[face]qq/41.gif[/face]',
    ),
    array(
      'src' => '42.gif',
      'sign' => '[face]qq/42.gif[/face]',
    ),
    array(
      'src' => '43.gif',
      'sign' => '[face]qq/43.gif[/face]',
    ),
    array(
      'src' => '44.gif',
      'sign' => '[face]qq/44.gif[/face]',
    ),
    array(
      'src' => '45.gif',
      'sign' => '[face]qq/45.gif[/face]',
    ),
    array(
      'src' => '46.gif',
      'sign' => '[face]qq/46.gif[/face]',
    ),
    array(
      'src' => '47.gif',
      'sign' => '[face]qq/47.gif[/face]',
    ),
    array(
      'src' => '48.gif',
      'sign' => '[face]qq/48.gif[/face]',
    ),
    array(
      'src' => '49.gif',
      'sign' => '[face]qq/49.gif[/face]',
    ),
    array(
      'src' => '50.gif',
      'sign' => '[face]qq/50.gif[/face]',
    ),
    array(
      'src' => '51.gif',
      'sign' => '[face]qq/51.gif[/face]',
    ),
    array(
      'src' => '52.gif',
      'sign' => '[face]qq/52.gif[/face]',
    ),
    array(
      'src' => '53.gif',
      'sign' => '[face]qq/53.gif[/face]',
    ),
    array(
      'src' => '54.gif',
      'sign' => '[face]qq/54.gif[/face]',
    ),
    array(
      'src' => '55.gif',
      'sign' => '[face]qq/55.gif[/face]',
    ),
    array(
      'src' => '56.gif',
      'sign' => '[face]qq/56.gif[/face]',
    ),
    array(
      'src' => '57.gif',
      'sign' => '[face]qq/57.gif[/face]',
    ),
    array(
      'src' => '58.gif',
      'sign' => '[face]qq/58.gif[/face]',
    ),
    array(
      'src' => '59.gif',
      'sign' => '[face]qq/59.gif[/face]',
    ),
    array(
      'src' => '60.gif',
      'sign' => '[face]qq/60.gif[/face]',
    ),
    array(
      'src' => '61.gif',
      'sign' => '[face]qq/61.gif[/face]',
    ),
    array(
      'src' => '62.gif',
      'sign' => '[face]qq/62.gif[/face]',
    ),
    array(
      'src' => '63.gif',
      'sign' => '[face]qq/63.gif[/face]',
    ),
    array(
      'src' => '64.gif',
      'sign' => '[face]qq/64.gif[/face]',
    ),
    array(
      'src' => '68.gif',
      'sign' => '[face]qq/68.gif[/face]',
    ),
    array(
      'src' => '69.gif',
      'sign' => '[face]qq/69.gif[/face]',
    ),
    array(
      'src' => '70.gif',
      'sign' => '[face]qq/70.gif[/face]',
    ),
    array(
      'src' => '71.gif',
      'sign' => '[face]qq/71.gif[/face]',
    ),
    array(
      'src' => '72.gif',
      'sign' => '[face]qq/72.gif[/face]',
    ),
    array(
      'src' => '73.gif',
      'sign' => '[face]qq/73.gif[/face]',
    ),
    array(
      'src' => '74.gif',
      'sign' => '[face]qq/74.gif[/face]',
    ),
    array(
      'src' => '75.gif',
      'sign' => '[face]qq/75.gif[/face]',
    ),
    array(
      'src' => '76.gif',
      'sign' => '[face]qq/76.gif[/face]',
    ),
    array(
      'src' => '77.gif',
      'sign' => '[face]qq/77.gif[/face]',
    ),
    array(
      'src' => '78.gif',
      'sign' => '[face]qq/78.gif[/face]',
    ),
    array(
      'src' => '79.gif',
      'sign' => '[face]qq/79.gif[/face]',
    ),
    array(
      'src' => '80.gif',
      'sign' => '[face]qq/80.gif[/face]',
    ),
    array(
      'src' => '81.gif',
      'sign' => '[face]qq/81.gif[/face]',
    ),
    array(
      'src' => '82.gif',
      'sign' => '[face]qq/82.gif[/face]',
    ),
    array(
      'src' => '83.gif',
      'sign' => '[face]qq/83.gif[/face]',
    ),
    array(
      'src' => '84.gif',
      'sign' => '[face]qq/84.gif[/face]',
    ),
    array(
      'src' => '85.gif',
      'sign' => '[face]qq/85.gif[/face]',
    ),
    array(
      'src' => '86.gif',
      'sign' => '[face]qq/86.gif[/face]',
    ),
    array(
      'src' => '87.gif',
      'sign' => '[face]qq/87.gif[/face]',
    ),
    array(
      'src' => '88.gif',
      'sign' => '[face]qq/88.gif[/face]',
    ),
    array(
      'src' => '89.gif',
      'sign' => '[face]qq/89.gif[/face]',
    ),
    array(
      'src' => '92.gif',
      'sign' => '[face]qq/92.gif[/face]',
    ),
    array(
      'src' => '93.gif',
      'sign' => '[face]qq/93.gif[/face]',
    ),
    array(
      'src' => '94.gif',
      'sign' => '[face]qq/94.gif[/face]',
    ),
    array(
      'src' => '95.gif',
      'sign' => '[face]qq/95.gif[/face]',
    ),
    array(
      'src' => '96.gif',
      'sign' => '[face]qq/96.gif[/face]',
    ),
    array(
      'src' => '97.gif',
      'sign' => '[face]qq/97.gif[/face]',
    ),
    array(
      'src' => '98.gif',
      'sign' => '[face]qq/98.gif[/face]',
    ),
    array(
      'src' => '99.gif',
      'sign' => '[face]qq/99.gif[/face]',
    ),
    array(
      'src' => '100.gif',
      'sign' => '[face]qq/100.gif[/face]',
    ),
    array(
      'src' => '101.gif',
      'sign' => '[face]qq/101.gif[/face]',
    ),
    array(
      'src' => '102.gif',
      'sign' => '[face]qq/102.gif[/face]',
    ),
    array(
      'src' => '103.gif',
      'sign' => '[face]qq/103.gif[/face]',
    ),
    array(
      'src' => '104.gif',
      'sign' => '[face]qq/104.gif[/face]',
    ),
    array(
      'src' => '105.gif',
      'sign' => '[face]qq/105.gif[/face]',
    ),
    array(
      'src' => '106.gif',
      'sign' => '[face]qq/106.gif[/face]',
    ),
    array(
      'src' => '107.gif',
      'sign' => '[face]qq/107.gif[/face]',
    ),
    array(
      'src' => '108.gif',
      'sign' => '[face]qq/108.gif[/face]',
    ),
    array(
      'src' => '109.gif',
      'sign' => '[face]qq/109.gif[/face]',
    ),
    array(
      'src' => '110.gif',
      'sign' => '[face]qq/110.gif[/face]',
    ),
    array(
      'src' => '111.gif',
      'sign' => '[face]qq/111.gif[/face]',
    ),
    array(
      'src' => '112.gif',
      'sign' => '[face]qq/112.gif[/face]',
    ),
    array(
      'src' => '113.gif',
      'sign' => '[face]qq/113.gif[/face]',
    ),
    array(
      'src' => '114.gif',
      'sign' => '[face]qq/114.gif[/face]',
    ),
    array(
      'src' => '115.gif',
      'sign' => '[face]qq/115.gif[/face]',
    ),
    array(
      'src' => '116.gif',
      'sign' => '[face]qq/116.gif[/face]',
    ),
    array(
      'src' => '117.gif',
      'sign' => '[face]qq/117.gif[/face]',
    ),
    array(
      'src' => '118.gif',
      'sign' => '[face]qq/118.gif[/face]',
    ),
    array(
      'src' => '119.gif',
      'sign' => '[face]qq/119.gif[/face]',
    ),
    array(
      'src' => '120.gif',
      'sign' => '[face]qq/120.gif[/face]',
    ),
    array(
      'src' => '121.gif',
      'sign' => '[face]qq/121.gif[/face]',
    ),
    array(
      'src' => '122.gif',
      'sign' => '[face]qq/122.gif[/face]',
    ),
    array(
      'src' => '123.gif',
      'sign' => '[face]qq/123.gif[/face]',
    ),
    array(
      'src' => '124.gif',
      'sign' => '[face]qq/124.gif[/face]',
    ),
    array(
      'src' => '125.gif',
      'sign' => '[face]qq/125.gif[/face]',
    ),
    array(
      'src' => '126.gif',
      'sign' => '[face]qq/126.gif[/face]',
    ),
    array(
      'src' => '127.gif',
      'sign' => '[face]qq/127.gif[/face]',
    ),
    array(
      'src' => '128.gif',
      'sign' => '[face]qq/128.gif[/face]',
    ),
    array(
      'src' => '129.gif',
      'sign' => '[face]qq/129.gif[/face]',
    ),
    array(
      'src' => '130.gif',
      'sign' => '[face]qq/130.gif[/face]',
    ),
    array(
      'src' => '131.gif',
      'sign' => '[face]qq/131.gif[/face]',
    ),
    array(
      'src' => '132.gif',
      'sign' => '[face]qq/132.gif[/face]',
    ),
    array(
      'src' => '133.gif',
      'sign' => '[face]qq/133.gif[/face]',
    ),
    array(
      'src' => '134.gif',
      'sign' => '[face]qq/134.gif[/face]',
    ),
    array(
      'src' => '135.gif',
      'sign' => '[face]qq/135.gif[/face]',
    ),
    array(
      'src' => '136.gif',
      'sign' => '[face]qq/136.gif[/face]',
    ),
    array(
      'src' => '137.gif',
      'sign' => '[face]qq/137.gif[/face]',
    ),
    array(
      'src' => '138.gif',
      'sign' => '[face]qq/138.gif[/face]',
    ),
    array(
      'src' => '139.gif',
      'sign' => '[face]qq/139.gif[/face]',
    ),
    array(
      'src' => '140.gif',
      'sign' => '[face]qq/140.gif[/face]',
    ),
    array(
      'src' => '141.gif',
      'sign' => '[face]qq/141.gif[/face]',
    ),
    array(
      'src' => '142.gif',
      'sign' => '[face]qq/142.gif[/face]',
    ),
    array(
      'src' => '143.gif',
      'sign' => '[face]qq/143.gif[/face]',
    ),
    array(
      'src' => '144.gif',
      'sign' => '[face]qq/144.gif[/face]',
    ),
    array(
      'src' => '145.gif',
      'sign' => '[face]qq/145.gif[/face]',
    ),
    array(
      'src' => '146.gif',
      'sign' => '[face]qq/146.gif[/face]',
    ),
    array(
      'src' => '147.gif',
      'sign' => '[face]qq/147.gif[/face]',
    ),
    array(
      'src' => '148.gif',
      'sign' => '[face]qq/148.gif[/face]',
    ),
    array(
      'src' => '149.gif',
      'sign' => '[face]qq/149.gif[/face]',
    ),
    array(
      'src' => '150.gif',
      'sign' => '[face]qq/150.gif[/face]',
    ),
    array(
      'src' => '151.gif',
      'sign' => '[face]qq/151.gif[/face]',
    ),
    array(
      'src' => '152.gif',
      'sign' => '[face]qq/152.gif[/face]',
    ),
    array(
      'src' => '153.gif',
      'sign' => '[face]qq/153.gif[/face]',
    ),
    array(
      'src' => '154.gif',
      'sign' => '[face]qq/154.gif[/face]',
    ),
    array(
      'src' => '155.gif',
      'sign' => '[face]qq/155.gif[/face]',
    ),
    array(
      'src' => '156.gif',
      'sign' => '[face]qq/156.gif[/face]',
    ),
    array(
      'src' => '157.gif',
      'sign' => '[face]qq/157.gif[/face]',
    ),
    array(
      'src' => '158.gif',
      'sign' => '[face]qq/158.gif[/face]',
    ),
    array(
      'src' => '159.gif',
      'sign' => '[face]qq/159.gif[/face]',
    ),
    array(
      'src' => '160.gif',
      'sign' => '[face]qq/160.gif[/face]',
    ),
    array(
      'src' => '161.gif',
      'sign' => '[face]qq/161.gif[/face]',
    ),
    array(
      'src' => '162.gif',
      'sign' => '[face]qq/162.gif[/face]',
    ),
    array(
      'src' => '163.gif',
      'sign' => '[face]qq/163.gif[/face]',
    ),
    array(
      'src' => '164.gif',
      'sign' => '[face]qq/164.gif[/face]',
    ),
    array(
      'src' => '165.gif',
      'sign' => '[face]qq/165.gif[/face]',
    ),
    array(
      'src' => '166.gif',
      'sign' => '[face]qq/166.gif[/face]',
    ),
    array(
      'src' => '167.gif',
      'sign' => '[face]qq/167.gif[/face]',
    ),
    array(
      'src' => '168.gif',
      'sign' => '[face]qq/168.gif[/face]',
    ),
    array(
      'src' => '169.gif',
      'sign' => '[face]qq/169.gif[/face]',
    ),
    array(
      'src' => '170.gif',
      'sign' => '[face]qq/170.gif[/face]',
    ),
    array(
      'src' => '171.gif',
      'sign' => '[face]qq/171.gif[/face]',
    ),
    array(
      'src' => '172.gif',
      'sign' => '[face]qq/172.gif[/face]',
    ),
    array(
      'src' => '173.gif',
      'sign' => '[face]qq/173.gif[/face]',
    ),
    array(
      'src' => '174.gif',
      'sign' => '[face]qq/174.gif[/face]',
    ),
    array(
      'src' => '175.gif',
      'sign' => '[face]qq/175.gif[/face]',
    ),
  ),
);
echo $_GET['jsoncallback'] . '(' . json_encode($aFace) . ');';
