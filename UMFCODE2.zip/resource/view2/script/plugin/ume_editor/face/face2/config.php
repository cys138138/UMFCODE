<?php
$face = array();
$face['name'] = "兔斯基表情";

for($i = 0; $i < 10; $i++){
	$face['aImgList'][] = array('src'=>$i.'.gif', 'sign'=>'[face]face2/'.$i.'.gif[/face]');
}
echo $_GET['jsoncallback'] . '(' . json_encode($face) . ');';
