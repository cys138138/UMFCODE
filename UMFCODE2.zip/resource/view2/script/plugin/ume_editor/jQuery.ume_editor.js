(function($, win){
	var basePath = (function(){
		var reg = new RegExp('jQuery.ume_editor.js.*'),
		scripts = document.getElementsByTagName('script');
		for(var i = 0, ii = scripts.length; i < ii; i++){
			var path = scripts[i].getAttribute('src');
			if(reg.test(path)){
				return path.replace(reg, '');
			}
		}
	})();
	var instanceCount = 0;
	/**
	 * ie:
	 * 回车：<p> </p>
	 * 空格：&nbsp;
	 --------------------------
	 * chrome:
	 * 回车：<div><br></div>
	 * 空格：&nbsp;
	 --------------------------
	 * firefox:
	 * 回车：<br>
	 * 空格：<br>
	 * 键位绑定不同于ie和chrome
	 */
	var regexpContent = {
		buttonBefore: /<button[^>]+>/ig,
		buttonAfter: /<\/button>/ig,
		atName: /<button[^>]+>@([^<]+)<\/button>/ig,
		atHtmlNull :  /<button[^>]+><\/button>/ig,
		atSignNull :  /\[at\]\[\/at\]/ig,
		atSign: /\[at\]([^\]]+)\[\/at\]/ig,
		atHtml: /<button[^>]+>@([^<]+)<\/button>/ig,
		expressionSign: /\[face\][a-z\d\/]+\[\/face\]/ig,
		expressionHtml: /<img[^>]+sign="([^"]+)"[^>]*>/ig,
		imageName: /<img[^>]+src="[^"]+\/([0-9a-z]+)\.([a-z]+)[^>]*>/ig,
		htmlEntity: /\&[a-z]+\;/ig,
		brTag: /<\/br>|<br>|<br\/>/ig,
		ieEnter:/<p>&nbsp;<\/p>/ig,
		chromeEnter:/<div><br><\/div>/ig,
		empty : /\s+/ig,
		allTagHtml: /<[^>]+>/ig,
		filterTagHtml : /<p>|<\/p>|<div>|<\/div>/ig
	};

	if($('body').data('isInjectCSS') == null){
		$('body').data('isInjectCSS',false);
	}
	if(win._umfunFaceList == null){
		win._umfunFaceList = [];
	}
	if(win._umfunFriendGroupList == null){
		win._umfunFriendGroupList = [];
	}

    win.UMeEditor = {
		getInstance : function(aConfig){
			if(!$('body').data('isInjectCSS')){
				_inJectCSS();
				$('body').data('isInjectCSS',true);
			}
			instanceCount++;
			return new Editor(aConfig);
		},
		//按照规则还原存储状态的字符串到html
		decodeContent : function(content){
			content = content.replace(regexpContent['atSignNull'], '');
			content = content.replace(/(\[face\]([^\]]+)\[\/face\])/ig, '<img src="' + basePath + 'face/$2" sign="$1" alt="">');
			content = content.replace(/\[at\]/ig, '<button class="_at_user">');
			content = content.replace(/\[\/at\]/ig, '</button>');
			content = content.replace(/\s+/ig, ' ');
			return content;
		},
		//按照规则转换html到存储状态的字符串
		encodeContent : function(content){
			content = content.replace(regexpContent['atHtmlNull'], '');
			content = content.replace(regexpContent['expressionHtml'], '$1');
			content = content.replace(regexpContent['buttonBefore'], '[at]');
			content = content.replace(regexpContent['buttonAfter'], '[/at]');
			content = content.replace(/<\/br>|<br>|<br\/>/ig, ' ');
			content = content.replace(/<[^>]+>/ig, '');
			content = content.replace(/\s+/ig, ' ');
			return content;
		},
		
		filterText : function(content){
			content = content.replace(/(\[face\]([^\]]+)\[\/face\])/ig, '');
			content = content.replace(/\[at\]/ig, ' ');
			content = content.replace(/\[\/at\]/ig, ' ');
			return content;
		}
	};

	function _inJectCSS(){
		$('head').append('<style type="text/css">\
i.ico_edit, .ico_load {display:inline-block;*display:inline;*zoom:1;vertical-align:middle;}\
i.ico_load {width:32px;height:32px;background:url(loading.gif) no-repeat;}\
i.ico_edit {background:url(' + basePath + '/editors.png) no-repeat;}\
i.ico_edit_face, .ico_edit_at, .ico_edit_photo {width:16px;height:16px;}\
i.ico_edit_face {}\
i.ico_edit_at {background-position:-16px 0;}\
i.ico_edit_photo {background-position:-32px 0;}\
a.on .ico_edit_face {background-position:0 -16px;}\
a.on .ico_edit_at {background-position:-16px -16px;}\
a.on .ico_edit_photo {background-position:-32px -16px;}\
\
.editorsbox {width:100%;position:relative;z-index:9;zoom:1;margin-bottom:10px;color:#666;}\
.editorsbox a {color:#666;}\
.editorsbox ._at_item{margin:0 3px; background-color:transparent;border:none;color:#069;}\
.editorsbox .area {margin-bottom:10px;zoom:1;border:1px solid #ccc;}\
.editorsbox .editors {min-height:50px;_height:50px;padding:1%;overflow-y:auto;background-color:#fff;box-shadow:inset 1px 1px 5px #f2f2f2;font-size:14px;color:#555;outline:none;word-wrap:break-word;}\
.editorsbox .addons {width:100%;height:30px;}\
.editorsbox .attach {float:left;padding-left:10px;}\
.editorsbox .attach a {float:left;display:block;margin-right:10px;padding-bottom:1px;cursor:pointer;}\
.editorsbox .total {float:left;margin-left:5px;display:inline;font:bold 14px Georgia;color:#666;}\
.editorsbox .operate {float:right;}\
.editorsbox .btn {width:80px;height:30px;border:none;background-color:#3F81C2;font:14px/30px Microsoft YaHei;color:#fff;cursor:pointer;}\
.editorsbox .btn:hover {background-color:#069;}\
\
.editpop {width:100%;position:absolute;top:100%;left:0;z-index:10;margin-top:10px;border:1px solid #ddd;border-top:2px solid #036;background-color:#fff;box-shadow: 0px 5px 29px #C0C0C0;display:none;}\
.editpop .arrow {width:0;height:0;position:absolute;top:-14px;overflow:hidden;border:6px solid transparent;_border-style:dashed;border-bottom:6px solid #036;}\
.editpop .hd {height:30px;padding:0 10px;background-color:#eee;font:14px/30px Microsoft YaHei;color:#999;box-shadow:none;}\
.editpop .hd b {margin-right:10px;}\
.editpop .hd .cur {color:#036;}\
.editpop .hd .close {height:30px;float:right;margin-top:5px;*margin-top:-25px;display:block;color:#777;}\
.editpop li {zoom:1;}\
\
.facebox {}\
.facebox .arrow {left:10px;}\
.facebox .hd b {cursor:pointer;}\
.facebox .face_list {width:100%;max-height:160px;_height:160px;overflow-y:auto;}\
.facebox .face_list ul {padding:10px;overflow:hidden;zoom:1;}\
.facebox .face_list li {float:left;}\
.facebox .face_list a {padding:2px;display:block;border:1px solid #fff;}\
.facebox .face_list img {vertical-align:middle;}\
.facebox .face_list a:hover {border-color:#ddd;background-color:#f9f9f9;}\
\
.friendsbox .arrow {left:35px;}\
.friendsbox .bd {padding-left:100px;}\
.friendsbox .group_list {width:100px;position:relative;float:left;margin-left:-100px;padding:10px 0;display:inline;}\
.friendsbox .group_list li {margin-bottom:2px;}\
.friendsbox .group_list a {height:20px;padding-left:10px;display:block;line-height:20px;color:#999;}\
.friendsbox .group_list .cur a {background-color:#999;color:#fff;}\
.friendsbox .group_list a:hover {color:#036;}\
.friendsbox .friends_list {min-height:200px;max-height:270px;_height:270px;float:left;*float:none;overflow-y:auto;border-left:1px solid #eee;}\
.friendsbox .friends_list ul {padding:10px 10px 10px 0;overflow:hidden;zoom:1;}\
.friendsbox .friends_list li {float:left;margin:0 0 10px 10px;display:inline;}\
.friendsbox .friends_list a {width:90px;height:30px;padding:2px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\
.friendsbox .friends_list .name {margin-left:5px;}\
.friendsbox .friends_list a:hover {background-color:#3F81C2;color:#fff;}\
\
.photobox .arrow {left:62px;}\
.photobox .photo_list {padding-top:20px;*padding-bottom:20px;overflow:hidden;zoom:1;}\
.photobox .photo_list li {width:160px;height:130px;position:relative;float:left;margin:0 0 20px 25px;display:table-cell;text-align:center;line-height:130px;background-color:#f2f2f2;border:1px solid #ccc;}\
\
.photobox .del {width:24px;height:24px;position:absolute;top:0;right:0;z-index:2;background-color:#000;filter:alpha(opacity:70);opacity:0.7;text-align:center;line-height:24px;color:#fff;font-size:18px;font-family:simsun;}\
.photobox .del:hover {background-color:#222;}\
.photobox .thumbnail {+position:absolute; top:50%;z-index:1;font-size:0;}\
.photobox .thumbnail img {max-width:160px;max-height:130px;+position:relative;top:-50%;left:-50%;}\
.photobox .add_entry {width:100%;height:100%;line-height:130px;position:relative;display:block;overflow:hidden;background-color:#eee;cursor:pointer;font:22px/130px Microsoft YaHei;}\
.photobox .add_entry input {width:100%;position:absolute;top:0;left:0;font-size:120px;filter:alpha(opacity:0);opacity:0;cursor:pointer;}\
.photobox .add_entry:hover {background-color:#ddd;color:#333;}\
.photobox .loading {width:100%;height:100%;background-color:#ccc;}\
.photobox .loading .ico_load {margin-top:30px;}\
.photobox .loading .prompt {display:block;font:14px/40px Microsoft YaHei;}\
	</style>');
	}

	function _insertElement(html){
		if(window.getSelection){
			//如果非IE9以下的浏览器,包括火狐谷歌等
			var oSelection = window.getSelection();
			if(oSelection.getRangeAt && oSelection.rangeCount){
				//如果是可以满足下面需求的一个selection对象
				var oRange = oSelection.getRangeAt(0);
				oRange.deleteContents();
				// Range.createContextualFragment() would be useful here but is
				// non-standard and not supported in all browsers (IE9, for one)
				var oElement = $('<div>' + html + '</div>');
				var frag = document.createDocumentFragment(), node, lastNode;
				while(node = oElement[0].firstChild){
					lastNode = frag.appendChild(node);
				}
				oRange.insertNode(frag);
				// Preserve the selection
				if(lastNode){
					oRange = oRange.cloneRange();
					oRange.setStartAfter(lastNode);
					oRange.collapse(true);
					oSelection.removeAllRanges();
					oSelection.addRange(oRange);
				}
			}
		}else if(document.selection && document.selection.type != "Control"){
			//如果是小于IE9以下的IE浏览器
			document.selection.createRange().pasteHTML(html);
		}
	}

	function Editor(aConfig){
		var self = this;
		var oWrap = aConfig.oContext;
		var currentFacePack = '';
		var currentUserGroupPack = '';
		var cacheEditorWidth = 0;
		var cacheEditorHeight = 0;

		//默认配置，可以让外部使用的参数。
		var _aConfig = {
			oContext: [],						//必须，使用页面div的jq对象
			width : '98%',						//整体宽度
			height : 50,						//外框高度#隐性的可调节控制条高度
			upfile : false,						//表情
			userList : false,					//好友
			userListUrl : '',						//获取好友的url
			aFace : [],							//表情组
			imageBaseUrl : '',					//图片资源地址
			imageUploadUrl : '',				//上传提交的url
			upfileErrorCallBackFunction : function(){alert('upflie error!');}, //图片上传错误回调
			limitImage : 6,						//图片上传限制
			deleteImageCallBackFunction : null,	//图片删除回调
			limitContent : 150,				//内容字数限制
			onSubmit : null,					//提交按钮被点击时的回调
			onBlur : null,						//编辑框失去焦点时的回调
			onFocus : null,					//编辑框进入焦点时的回调
			baseFilter : [],
			wordCountFilter : [],
			submitCaption : '发表',			//提交按钮的文字
			onWrappingBlur : null,			//编辑器失去焦点
			onWrappingClick : null,			//编辑器盒子被点击
			startText : ''					//初始化开始的文字
		};

		_aConfig.baseFilter['  '] = [
			regexpContent.htmlEntity,
			regexpContent.ieEnter,
			regexpContent.chromeEnter,
			regexpContent.brTag,
			regexpContent.empty
		];
		_aConfig.baseFilter['#'] = [
			regexpContent.filterTagHtml
		];

		_aConfig.wordCountFilter['#'] = [
			regexpContent.expressionHtml,
			regexpContent.atHtml,
			regexpContent.expressionSign,
			regexpContent.atSign
		];
		_aConfig.wordCountFilter['  '] = [
			regexpContent.ieEnter,
			regexpContent.chromeEnter,
			regexpContent.brTag,
			regexpContent.empty,
			regexpContent.filterTagHtml
		];
		_aConfig.wordCountFilter['__'] = [
			regexpContent.allTagHtml
		];

		for (var key in _aConfig) {
			if (aConfig[key] == undefined) {
				aConfig[key] = _aConfig[key];
			}
		}


		oWrap.html('<div xid="editorsbox" class="editorsbox">\
			<div class="panel">\
				<div class="area">\
					<div xid="ueContent" class="editors" contenteditable="true">' + aConfig.startText + '</div>\
				</div>\
				<div class="addons" style="display:block;">\
					<div class="attach" xid="attach">\
						<a xid="ueBtnOpenFace" class="act_face" sytle="display:none;" href="javascript:;" title="发表情"><i class="ico_edit ico_edit_face"></i></a>\
						<a xid="ueBtnOpenFriends" class="act_at" sytle="display:none;" href="javascript:;" title="提到好友"><i class="ico_edit ico_edit_at"></i></a>\
						<a xid="ueBtnOpenUpFile" class="act_photo" sytle="display:none;" href="javascript:;" title="发图片"><i class="ico_edit ico_edit_photo"></i></a>\
					</div>\
					<div xid="ueWordTotal" class="total" style="display:block;">0/0</div>\
					<div class="operate">\
						<textarea xid="ueTrueText" style="display:none;"></textarea>\
						<button xid="ueSubmit" class="btn">' + aConfig.submitCaption + '</button>\
					</div>\
				</div>\
			</div>\
			<!--表情 [-->\
			<div xid="ueFaceBox" tab="pop" class="editpop facebox" style="display:none;">\
				<i class="arrow"></i>\
				<div class="hd" xid="ueFaceTab"></div>\
				<div class="bd">\
					<div class="face_list">\
						<ul xid="ueFaceList"></ul>\
					</div>\
				</div>\
			</div>\
			<!--表情 [-->\
			\
			<!--好友 [-->\
			<div xid="ueFriendsBox" tab="pop" class="editpop friendsbox">\
				<i class="arrow"></i>\
				<div class="hd">\
					<b>请选择@好友</b>\
					<a xid="ueFriendClose" class="close" href="javascript:;" title="关闭">&times;</a>\
				</div>\
				<div class="bd">\
					<div class="group_list">\
						<ul xid="group_list"></ul>\
					</div>\
					<div class="friends_list">\
						<ul xid="friends_list"></ul>\
					</div>\
				</div>\
			</div>\
			<!--好友 [-->\
			\
			<!--图片上传 [-->\
			<div xid="ueUpFile" tab="pop" class="editpop photobox">\
				<i class="arrow"></i>\
				<div class="hd">\
					<b>图片上传</b>\
					<span xid="imageCountItem">(2/6)</span>\
					<a xid="ueUpFileClose" class="close" href="javascript:;" title="关闭">&times;</a>\
				</div>\
				<div class="bd">\
					<div class="photo_list" xid="photo_list">\
						<ul></ul>\
					</div>\
				</div>\
			</div>\
			<!--图片上传 ]-->\
		</div>');

/* --------------------------------------------------------- 通用 --------------------------------------------------------- */

		//根据光标插入html
		function _insertContent(html){
			var $oContent = oWrap.find('[xid="ueContent"]');
			$oContent.focus();
			_insertElement(html);
			$oContent.focus();
		}

/* --------------------------------------------------------- 统计 --------------------------------------------------------- */

		/**
		 * 过滤内容
		 * @param {type} filterRegexp
		 * @param {type} texts
		 * @returns {unresolved}
		 */
		function _filterContent(filterRegexp, texts) {
			for (var i in filterRegexp) {
				//【__】为替换空字符
				var replaceVal = i == '__' ? '' : i;
				if (typeof (filterRegexp[i].length) == 'undefined') {
					texts = texts.replace(filterRegexp[i], replaceVal);
				} else {
					for (var j = 0; j < filterRegexp[i].length; j++) {
						texts = texts.replace(filterRegexp[i][j], replaceVal);
					}
				}
			}
			return texts;
		}


/* --------------------------------------------------------- 上传 --------------------------------------------------------- */


		//更新上传图片数量显示
		function updateImageConunt(){
			upLoadFileLength = parseInt(oWrap.find('[xid="ueUpFile"] .photo_list ul li').length);
			upLoadFileLength--;
			oWrap.find('[xid="imageCountItem"]').html('(' + upLoadFileLength + '/' + aConfig.limitImage + ')');
		}

		function _loadUpFile(){
			var time = new Date().getTime();
			oWrap.find('[xid="photo_list"]').append('<iframe src="javascript:void(0);" name="__ue_iframe_upfile' + time + '" style="display:none;"  time="' + time + '"></iframe>');
			oWrap.find('[xid="ueUpFile"] .photo_list ul').append( '<li xid="upFileButton" ><form action="' + aConfig.imageUploadUrl + '" method="POST" id="form" enctype="multipart/form-data" target="__ue_iframe_upfile' + time + '"><a class="add_entry" href="javascript:;"><input type="file" name="upfile" id="" />添加图片</a></form><p class="loading" style="display:none;"><i class="ico_load"></i><span class="prompt">图片上传中...</span></p></li>' );

			oWrap.find('[xid="upFileButton"] input[type="file"]').change(function(){
				oWrap.find('form').submit();
				oWrap.find('[xid="ueUpFile"] .photo_list ul li:last form').hide();
				oWrap.find('[xid="ueUpFile"] .photo_list ul li:last .loading').show();
			}).click(function(){
				//如果超过6张图就停止
				if(aConfig.limitImage >= oWrap.find('li').length){
					this.value = '';
				}
			});

			//异步完毕，加载图片和信息
			oWrap.find('iframe[name="__ue_iframe_upfile' + time + '"]').load(function(){
				if(typeof(this.contentWindow.document) == 'unknown'){
					return false;
				}
				try{
					var aData = $.parseJSON(this.contentWindow.document.body.innerHTML);
					if(aData.status == 1){
						$(this).prev().find('li:last').before('<li><a class="del" href="javascript:;" title="删除图片" path="' + aData.data.path + '">&times;</a><p class="thumbnail"><img src="' + aData.data.src + '" alt="" ></p></li>');
					}else{
						aConfig.upfileErrorCallBackFunction(aData);
					}
				}catch(err){
					aConfig.upfileErrorCallBackFunction({status : 0, msg : '上传失败'});
				}
				$(this).prev().find('li:last').remove();

				//由于ie控件只能使用一次，所以只能每次都做删除和添加操作
				var time = $(this).attr('time');
				$(this).prev().append('<li xid="upFileButton">\
					<form action="' + aConfig.imageUploadUrl + '" method="POST" id="form" enctype="multipart/form-data" target="__ue_iframe_upfile' + time + '">\
						<a class="add_entry" href="javascript:;">\
							<input type="file" name="upfile" id="" onchange="$(this).parent().parent().submit();"/>\
							添加图片\
						</a>\
					</form>\
					<p class="loading" style="display:none;">\
						<i class="ico_load"></i>\
						<span class="prompt">图片上传中...</span>\
					</p>\
				</li>');
				toggleUpFileBotton();
			});
		}

		//切换上传按钮
		function toggleUpFileBotton( isShow ){
			updateImageConunt();
			if(isShow == true){
				oWrap.find('[xid="ueUpFile"] .photo_list ul li:last').show();
			}else{
				if(aConfig.limitImage < oWrap.find('[xid="ueUpFile"] .photo_list ul li').length){
					oWrap.find('[xid="ueUpFile"] .photo_list ul li:last').hide();
				}else{
					oWrap.find('[xid="ueUpFile"] .photo_list ul li:last').show();
				}
			}
		}


/* -------------------------------------------------------- 好友 -------------------------------------------------------- */


		function _loadFriend(){
			if(win._umfunFriendGroupList.length == 0){
				var url = aConfig.userListUrl;
				$.ajax({
					url : url,
					dataType : 'json',
					success : function(aResult){
						if(aResult.status == 1){
							win._umfunFriendGroupList = aResult.data;
						}
					}
				});
			}
		}

		function _loadFriendList(currentUserGroupPack){
			var loadFriendUserInfoBox = function(aFriendGroupInfos){
				var aTabFriendHtml = [];
				for( var userIndex in aFriendGroupInfos ){
					var userInfo = aFriendGroupInfos[userIndex];
					aTabFriendHtml.push('<li xid="ueFriendItem"><a href="javascript:;"><span class="head"><img src="' + DEFAULT_HEAD_IMG  + '" real="' + aConfig.imageBaseUrl + userInfo.profile + '" width="30" height="30" alt="" onload="h(this)" /></span><span xpid="' + userInfo.id + '" class="name">' + userInfo.name + '</span></a></li>');
				}
				return aTabFriendHtml;
			};

			var aFriendGroupList = win._umfunFriendGroupList;
			var userListTemp = [];
			var friendGroupHtml = [];
			friendGroupHtml.push('<li xid="all" class="cur"><a href="javascript:;">全部好友</a></li>');
			for(var groupName in aFriendGroupList ){
				friendGroupHtml.push('<li xid="' + groupName + '" ' + ( currentUserGroupPack == groupName ? 'class="cur"' : '' ) + ' ><a href="javascript:;">' + groupName + '</a></li>');
			}

			for(var groupIndex in aFriendGroupList){
				 userListTemp.push( loadFriendUserInfoBox(aFriendGroupList[groupIndex]).join('') );
			}
			oWrap.find('[xid="friends_list"]').html( userListTemp.join('') );

			oWrap.find('[xid="group_list"]').html(friendGroupHtml.join('')).find('li').click(function(){
				var userListTemp = [];
				if($(this).attr('xid') == 'all'){
					for(var groupIndex in aFriendGroupList){
						 userListTemp.push( loadFriendUserInfoBox(aFriendGroupList[groupIndex]).join('') );
					}
				}else{
					userListTemp.push( loadFriendUserInfoBox(aFriendGroupList[ $(this).attr('xid') ]).join('') );
				}
				oWrap.find('[xid="friends_list"]').html( userListTemp.join('') );

				$(this).siblings().removeClass('cur');
				$(this).addClass('cur');
			});
		}


/* --------------------------------------------------------- 表情 --------------------------------------------------------- */


		function _loadFace(facePackList){
			var facePack = facePackList.shift()
			,faceConfigUrl = basePath + 'face/' + facePack + '/config.php?jsoncallback=?';
			if(win._umfunFaceList[facePack] == null){
				$.ajax({
					url : faceConfigUrl,
					dataType : 'json',
					success : function(aResult){
						if(!JsTools.isObject(aResult)){
							return;
						}
						win._umfunFaceList[facePack] = aResult;
						if(facePackList.length){
							_loadFace(facePackList);
						}
					}
				});
			}else{
				if(facePackList.length){
					_loadFace(facePackList);
				}
			}
		}


		/**
		 * 载入表情列表
		 * @param {type} defaultFacePack
		 * @returns {undefined}
		 */
		function _loadFaceList(defaultFacePack){
			var loadFace = function(facePack){
				var aFaceList = win._umfunFaceList[facePack]
				,facePath = basePath + 'face/' + facePack + '/';
				var aFaceListHtml = [];
				for(var i in aFaceList.aImgList){
					aFaceListHtml.push('<li xid="ueFaceItem"><a href="javascript:;" ><img sign="' + aFaceList.aImgList[i].sign + '" src="' + facePath + aFaceList.aImgList[i].src + '" alt=""/></a></li>');
				}
				oWrap.find('[xid="ueFaceList"]').html(aFaceListHtml.join(''));
			};

			var aFaceTabHtml = [];
			for(var i in aConfig.aFace){
				aFaceTabHtml.push('<b itemid="' + aConfig.aFace[i] + '"' + (defaultFacePack == aConfig.aFace[i] ? ' class="cur"' : '') + '>' + win._umfunFaceList[aConfig.aFace[i]].name + '</b>');
			}

			aFaceTabHtml.push('<a xid="ueBtnCloseFaceBox" class="close" href="javascript:;" title="关闭">&times;</a>');
			oWrap.find('[xid="ueFaceTab"]').html(aFaceTabHtml).find('b').click(function(){
				loadFace($(this).attr('itemid'));
				$(this).siblings().removeClass('cur');
				$(this).addClass('cur');
			});
			loadFace(defaultFacePack);
		}


/* --------------------------------------------------------- 插件调用控制 --------------------------------------------------------- */
		//对象复制
		function clone(oObj){
			if(oObj == null || typeof(oObj) !== 'object'){
				return oObj;
			}
			var oTempObj = new oObj.constructor();
			for(var key in oObj){
				oTempObj[key] = arguments.callee(oObj[key]);
			}
			return oTempObj;
		}
		var $oContent = oWrap.find('[xid="ueContent"]');
		$oContent.crushColor = function(){
			//文字低亮
			$(this).css('color', '#999');
		};
		
		$oContent.highLightColor = function(){
			//文字高亮
			$(this).css('color', '#555');
		};

		//上传
		if(aConfig.upFile){
			_loadUpFile();
			updateImageConunt();

			//上传的展开收缩
			oWrap.find('[xid="ueBtnOpenUpFile"]').click(function(){
				oWrap.find('[tab="pop"]').slideUp(100);
				if(oWrap.find('[xid="ueUpFile"]').css('display') == 'none'){
					oWrap.find('[xid="ueUpFile"]').slideDown(100);
					attachControlBar(this, true);
				}else{
					attachControlBar(this, false);
				}
			});

			//上传的删除按钮
			oWrap.find('div[xid="editorsbox"]').delegate('[xid="ueUpFile"] .photo_list ul li a.del', 'click', function(){
				$(this).parent().remove();
				if( aConfig.deleteImageCallBackFunction != null){
					aConfig.deleteImageCallBackFunction( $(this).attr('path') );
				}
				toggleUpFileBotton();
			});

			oWrap.find('[xid="ueUpFileClose"]').click(function(){
				oWrap.find('[xid="ueUpFile"]').slideUp(100);
			});
			oWrap.find('[xid="ueBtnOpenUpFile"]').show();
		}else{
			oWrap.find('[xid="ueBtnOpenUpFile"]').hide();
		}


		//好友
		if(aConfig.userList){
			currentUserGroupPack = 0;
			_loadFriend();

			//好友列表的展开收缩
			oWrap.find('[xid="ueBtnOpenFriends"]').click(function(){
				oWrap.find('[tab="pop"]').slideUp(100);
				if(oWrap.find('[xid="ueFriendsBox"]').css('display') == 'none'){
					oWrap.find('[xid="ueFriendsBox"]').slideDown(100);
					_loadFriendList(currentUserGroupPack);
					attachControlBar(this, true);
				}else{
					attachControlBar(this, false);
				}
			});

			//点击好友
			oWrap.find('div[xid="editorsbox"]').delegate('[xid="ueFriendItem"]', 'click', function(){
				var flag = String(Math.random()).slice(2);
				_insertContent('<button face_id="' + flag + '" contenteditable="false" class="_at_item" uid="' + $(this).find('span.name').attr('xpid') + '" >@' + $(this).find('span.name').text() + '</button>&nbsp;');
				var stringContent = $oContent.html();
				if(oWrap.data('atFriendMark')){
					stringContent = stringContent.replace(/@<button face_id="\d+"/, '<button');
					$oContent.html(stringContent);
				}
				oWrap.find('[tab="pop"]').slideUp(100);
			});

			//点击关闭
			oWrap.find('div[xid="editorsbox"]').delegate('[xid="ueFriendClose"]', 'click', function(){
				oWrap.find('[xid="ueFriendsBox"]').slideUp(100);
			});
			oWrap.find('[xid="ueBtnOpenFriends"]').show();
		}else{
			oWrap.find('[xid="ueBtnOpenFriends"]').hide();
		}


		//表情
		if(aConfig.aFace.length){
			currentFacePack = aConfig.aFace[0];
			_loadFace(clone(aConfig.aFace));	//注意克隆数组,不要直接传,因为里面会改变数组,以免影响外部配置
			//表情的展开收缩
			var $oContainer = oWrap.find('div[xid="editorsbox"]');
			oWrap.find('[xid="ueBtnOpenFace"]').click(function(){
				oWrap.find('[tab="pop"]').slideUp(100);
				if(oWrap.find('[xid="ueFaceBox"]').css('display') == 'none'){
					oWrap.find('[xid="ueFaceBox"]').slideDown(100);
					_loadFaceList(currentFacePack);
					attachControlBar(this, true);
				}else{
					attachControlBar(this, false);
				}
			});
			//点击表情
			$oContainer.delegate('[xid="ueFaceItem"]', 'click', function(){
				_insertContent($(this).find('a').html() + '&nbsp;');
				oWrap.find('[tab="pop"]').slideUp(100);
			});
			//点击关闭
			$oContainer.delegate('[xid="ueBtnCloseFaceBox"]', 'click', function(){
				oWrap.find('[xid="ueFaceBox"]').slideUp(100);
			});
			oWrap.find('[xid="ueBtnOpenFace"]').show();
		}else{
			oWrap.find('[xid="ueBtnOpenFace"]').hide();
		}

		//控制栏标签高亮控制***
		function attachControlBar(th, open){
			oWrap.find('[xid="attach"] a').removeClass('on');
			if(open){
				$(th).addClass('on');
			}
		}


/* -------------------------------------------------------- 设置和绑定 -------------------------------------------------------- */
		
		self.id = aConfig.id ? aConfig.id + $.now() : $.now();

		/**
		 * 字数提示更新
		 * @param {type} html 统计字数的内容
		 */
		function _countWordText(html){
			//限制输入的字数不能超过配置所限定的字数
			var $oWordCountText = oWrap.find('[xid="ueWordTotal"]');
			var mateText = _filterContent(aConfig.baseFilter, html).replace(/#+/ig,' ');
			var filterTexts = $.trim(_filterContent(aConfig.wordCountFilter, mateText).replace(/\s+/ig,' '));

			if(filterTexts.length >= aConfig.limitContent){
				$oWordCountText.css('color', 'red');
				//超出长度阻止文字输入,未能兼容所有浏览器
				/*if(mateText.length == filterTexts.length){
					//$(this).html( mateText.substr(0,aConfig.limitContent) );
				}else{
					var imageName = /<img[^>]+src="[^"]+\/([0-9a-z]+)\.([a-z]+)[^>]*>|<button[^>]+>@([^<]+)<\/button>/ig;
					var aButton = mateText.match(imageName);
					aButton = aButton ? aButton : [];
				}*/
			}else{
				$oWordCountText.css('color', '#999');
			}
			
			var signText = $.trim(UMeEditor.encodeContent(mateText).replace(/\s+/ig,' '));
			oWrap.find('[xid="ueTrueText"]').val(signText);
			$oWordCountText.html(filterTexts.length + '/' + aConfig.limitContent);
		}
		_countWordText('');
		
		//绑定字数统计事件 ueWordTotal
		$oContent.bind('click focus blur keydown keyup', function(){
			_countWordText(this.innerHTML);
		});


		//焦点进入编辑器
		$oContent.focus(function(){
			$oContent.html(self.getContent()).highLightColor();
			aConfig.onFocus && aConfig.onFocus();
			if(window.getSelection && $oContent[0].lastChild){
				var oRange = window.getSelection().getRangeAt(0);
				oRange.setStartAfter($oContent[0].lastChild);
			}
		});

		//焦点离开编辑器
		$oContent.blur(function(){
			var content = self.getContent();
			if(content == ''){
				$oContent.crushColor();
				content = aConfig.tips;
			}
			$oContent.html(content);
			aConfig.onBlur && aConfig.onBlur();
		});

		//焦点离开外框
		if(aConfig.onWrappingBlur != null){
			oWrap.click(function(e){
				var oLastEditor = $('body').data('oLastEditor');
				if(oLastEditor != null){
					if(aConfig.onWrappingClick != null){
						aConfig.onWrappingClick($('body').data('oLastEditor'));
					}
					if(oLastEditor.id != self.id){
						$('body').trigger('click');
					}
				}
				$('body').data('oLastEditor', self);
				e.stopPropagation();
			});
			
			$('html').delegate('body', 'click', function(){
				var oLastEditor = $('body').data('oLastEditor');
				if(oLastEditor != null){
					aConfig.onWrappingBlur(oLastEditor);
					if(oLastEditor.id == self.id){
						$('body').data('oLastEditor', null);
					}
				}
			});
		}


		//提交按钮
		if(aConfig.onSubmit != null){
			oWrap.find('[xid="ueSubmit"]').click(function(){
				aConfig.onSubmit();
				oWrap.find('a[xid="ueBtnCloseFaceBox"],a[xid="ueFriendClose"],a[xid="ueUpFileClose"]').trigger('click');
			});
		}
		
		if(typeof(aConfig.tips) == 'string'){
			$oContent.html(aConfig.tips).crushColor();
		}


		//@按键//兼容火狐
		$oContent.keypress(function(e){
			if((e.keyCode == 10 || e.keyCode == 13 ) && e.ctrlKey){
				aConfig.onSubmit();
			}
			if(e.keyCode == 64 || (e.keyCode == 0 && e.which == 64)){//@键
				oWrap.data('atFriendMark', true);
				oWrap.find('[xid="ueBtnOpenFriends"]').click();
			}else{
				oWrap.data('atFriendMark', false);
			}
			$('body').data('oLastEditor', self);//纯粹记录当前对象，以便伸缩之用
			$oContent.highLightColor();
		});


/* -------------------------------------------------------- 对外方法 -------------------------------------------------------- */

		self.getWrap = function(){
			return oWrap;
		};

		//获取编辑器可见部分的内容
		self.getContent = function(){
			var content = $.trim(_filterContent(aConfig.baseFilter, $.trim($oContent.html())).replace(/#+/ig, ' ').replace(/\s+/ig,' '));
			if(content == aConfig.tips){
				content = '';
			}
			return content;
		};

		//获取编辑器可见部分的内容长度
		self.getContentLength = function(isTrim){
			var content = self.getContent();
			if(content == aConfig.tips){
				content = '';
			}
			if(isTrim){
				return $.trim(content).length;
			}else{
				return $.trim(_filterContent(aConfig.wordCountFilter, content).replace(/\s+/ig, ' ')).length;
			}
		};

		//获取编辑器是否有内容
		self.isEmpty = function(content){
			if(content){
				return _filterContent(aConfig.wordCountFilter, $.trim(content)) == '';
			}else{
				return _filterContent(aConfig.wordCountFilter, $.trim($oContent.html())) == '';
			}
		};

		//默认焦点在编辑器
		self.focus = function(){
			setTimeout(function(){
				$('body').data('oLastEditor', self);
			}, 300);	//纯粹记录当前对象，以便伸缩之用
			$oContent.focus();
		};

		//获取编辑器字数判断时的内容
		self.getSignFilterText = function(){
			return $.trim(_filterContent(aConfig.wordCountFilter, $oContent.html()).replace(/\s+/ig, ' '));
		};

		//获取编辑器隐藏的提交内容
		self.getTrueText = function(){
			return oWrap.find('[xid="ueTrueText"]').val();
		};

		//获取@的用户ID列表
		self.getAtUserIdList = function(){
			//获取被@用户
			var html = this.getContent();
			var userListChun = html.match(regexpContent.atName);

			if (userListChun == null) {
				return [];
			}
			var matchs = [];
			for(var i = 0; i < userListChun.length; i++){
				var regexpArray = /uid="(\d+)/ig.exec(userListChun[i]);
				if(regexpArray[1] != null){
					matchs.push(regexpArray[1]);
				}
			}
			return matchs;
		};

		//获取上传后的图片地址列表
		self.getImageList = function(){
			var imagesLists = [];
			oWrap.find('.photo_list li a.del').each(function(){
				imagesLists.push($(this).attr('path'));
			});
			return imagesLists;
		};

		//清空编辑器
		self.clear = function(){
			$oContent.html('');
			$oContent.blur();
			$oContent.val('');
			oWrap.find('[xid="ueUpFile"] .photo_list ul li a.del').each(function(){
				$(this).parent().remove();
			});
			updateImageConunt();
		};

		//解除插件，保留输入过得文字
		self.unbind = function(){
			oWrap.empty().html($oContent.html());
		};

		//销毁整个插件所生成的dom
		self.destory = function(){
			oWrap.find('[xid="editorsbox"]').remove();
		};

		//销毁整个插件所生成的dom
		self.config = function(){
			return aConfig;
		};

		//伸
		self.slideDown = function(){
			oWrap.find('.addons').show();
			if($oContent.html() == aConfig.tips){
				$oContent.html('');
			}else{
				var content = $oContent.data('content');
				if(content && content != aConfig.tips){
					//必须有内容才能放进去,不然会跟表情插入产生冲突而清空内容
					$oContent.html(content);
				}
			}
			$oContent.highLightColor();
			$oContent.css({
				height : '50px'
				,'min-height' : '50px'
			});
			if(window.getSelection && $oContent[0].lastChild){
				var oRange = window.getSelection().getRangeAt(0);
				oRange.setStartAfter($oContent[0].lastChild);
			}
		};

		//缩
		self.slideUp = function(){
			var content = $oContent.html();
			$oContent.data('content', content)
			.css({
				height : '20px'
				,'min-height' : '20px'
			});
			oWrap.find('.addons').hide();
			if(self.isEmpty()){
				$oContent.html(aConfig.tips);
				$oContent.crushColor();
			}else if(content == aConfig.tips){
				$oContent.crushColor();
			}else{
				$oContent.html(content.replace(/<br>/g, ' '));
			}
		};
		
		self.getText = function(content){
			if(!content){
				content = UMeEditor.encodeContent(this.getContent());
			}
			return UMeEditor.filterText(content);
		};

		//配置&缓存
		cacheEditorWidth = aConfig.width;
		cacheEditorHeight = aConfig.height;
		$oContent.width(aConfig.width);
		$oContent.css({
			height : cacheEditorHeight
			,'min-height' : cacheEditorHeight
		});
	}

/* ---------------------------------------------------------  --------------------------------------------------------- */

})(jQuery, window);

