/**
 * 前端表单验证器
 * @param name 表单的name名字,如果是数字则不用加方括号,只需要方括号前面那个单词
 */
function Validater(name){
	var self = this;	//自身指针你懂的
	this.aDataDom = [];	//表单集
	this.aData = [];	//数据集
	this.shadow = '5px';

	//收集临时的DOM,然后过滤掉前面名字相同的DOM,比如password和password_comfirm,过滤掉后者
	var tmpDomObj = $('[name^=' + name + ']');
	tmpDomObj.each(function(){
		var domName = this.name.substr(name.length);
		if(!domName || domName.charAt(0) == '['){
			self.aDataDom.push(this);	//记下DOM

			//采集表单值
			var oDataDom = $(this);
			if(oDataDom.is('input:radio') || oDataDom.is('input:checkbox')){
				//跳过未选中的单选和复选控件
				if(!this.checked){
					return;
				}
			}
			self.aData.push({
				dom : this,	//控件DOM对象
				field : name,	//表单名字
				originalValue : oDataDom.val(),	//原始值
				value : $.trim(oDataDom.val())	//trim后的值
			});
		}
	});

	//检查是否得到表单对象
	if(this.aDataDom.length == 0){
		alert('页面内容验证出错,请联系站点管理员');
		$.error('验证字段 ' + name + ' 不存在');
	}

	//报错方法
	this.errorCallBack = function(error, oData){
		if(window.UBox != undefined){
			UBox.show(error, -1);
		}else{
			alert(error);
		}

		//5秒标红
		var oJQDom = $(oData.dom);
		var originalBorderColor = oJQDom.css('border-color');
		if(!originalBorderColor){
			originalBorderColor = oData.dom.style.borderColor;
		}

		oJQDom.css('border-color', 'red');
		oJQDom.css('box-shadow', '0 0 ' + self.shadow + ' #FF0000');
		setTimeout(function(){
			oJQDom.css('border-color', originalBorderColor);
			oJQDom.css('box-shadow', '');
		}, 5000);
		return false;
	};

	//是否是邮箱格式
	this.isEmail = function(){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
			if(!reg.test(this.value)){
				ok = this;
			}
		});
		return ok;
	};

	//字符串长度 max 为0　表示不限制长度
	this.length = function(min_len, max_len){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var value = this.value;
			if(max_len == 0){
				if(value.length < min_len){
					ok = this;
				}
			}else{
				if(value.length > max_len || value.length < min_len){
					ok = this;
				}
			}
		});
		return ok;
	};

	//是否是手机号
	this.isPhone = function(){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var reg = /^((\+86)|(86))?1[3|4|5|8]{1}\d{9}$/;
			if(!reg.test(this.value)){
				ok = this;
			}
		});
		return ok;
	};

	//是否是指定类型的字符串 type = 1数字　type=2字母　type=3数字字母组合 type=4 数字字母下划线组合
	this.isStr = function(type){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var reg = '';
			if(type == 1){
				reg = /^\d+$/;
			}else if(type == 2){
				reg = /^[a-zA-Z]+$/;
			}else if(type == 3){
				reg = /^[a-zA-Z0-9]+$/;
			}else if(type == 4){
				reg = /^\w+$/;
			}

			if(!reg.test(this.value)){
				ok = this;
			}
		});
		return ok;
	};

	//是否包含中文字[\u4e00-\u9fa5]
	this.haveChinese = function(){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var reg = /^.*[\u4e00-\u9fa5]+.*$/;
			if(!reg.test(this.value)){
				ok = this;
			}
		});
		return ok;
	};

	//是否在这个范围内的数字
	this.range = function(minNumber, maxNumber){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var num = parseInt(this.value);
			if(isNaN(num)){
				ok = this;
			}else if(minNumber > num || num > maxNumber){
				ok = this;
			}
		});
		return ok;
	};

	//是否不为空
    this.notNull = function(){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			if(this.value == '' || this.value == null){
				ok = this;
			}
		});
		return ok;
    };

	//是否是邮箱格式
	this.isUrl = function(){
		if(this.aData.length == 0){
			return false;
		}
		var ok = true;
		$(this.aData).each(function(){
			var reg = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
			if(!reg.test(this.value)){
				ok = this;
			}
		});
		return ok;
	};

    this.isNumber = function(length){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        $(this.aData).each(function(){
            if(length){
                if((this.value.length != length) || isNaN(this.value)){
                    ok = this;
                }
            }else{
                if(isNaN(this.value)){
                    ok = this;
                }
            }
        });
        return ok;
    };

    this.isInteger = function(length){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        $(this.aData).each(function(){
            if(!/^[0-9]+$/.test(this.value)){
				ok = this;
			}else if(length){
                if((this.value.length != length) || isNaN(this.value)){
                    ok = this;
                }
            }else{
                if(isNaN(this.value)){
                    ok = this;
                }
            }
        });
        return ok;
    };

    this.eq = function(value){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        $(this.aData).each(function(){
            if(this.value !== value){
                ok = this;
            }
        });
        return ok;
    };

    this.neq = function(value){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        $(this.aData).each(function(){
            if(this.value === value){
                ok = this;
            }
        });
        return ok;
    };

    this._in = function(value){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        var aValue = [];
        for(var i = 0; i < arguments.length; i++){
            aValue[i] = arguments[i];
        }
        $(this.aData).each(function(){
            var count = 0;
            for(var i = 0; i < aValue.length; i++){
                if(this.value == aValue[i]){
                    count++;
                }
            }
            if(count==0){
                ok = this;
            }
        });
        return ok;
    };

    this.notIn = function(value){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        $(this.aData).each(function(){
            if(String(value).indexOf(this.value) >= 0){
                ok = this;
            }
        });
        return ok;
    };

    this.noStr = function(value){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        var reg = new RegExp('[' + value + ']');
        //var reg = new RegExp('[' + '\/\-=' + ']');
        $(this.aData).each(function(){
            if(reg.test(this.value)){
                ok = this;
            }
        });
        return ok;
    };

    this.isLetterNumberUnderline = function(){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        var reg = /^[a-zA-Z]{1}[a-zA-Z0-9_]*$/;
        $(this.aData).each(function(){
            if(!reg.test(this.value)){
                ok = this;
            }
        });
        return ok;
    };

    this.haveChinese = function(){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        var reg = /[\u4e00-\u9fa5]/;
        $(this.aData).each(function(){
            if(reg.test(this.value)){
                ok = this;
            }
        });
        return ok;
    };

    this.isAllChinese = function(){
		if(this.aData.length == 0){
			return false;
		}
        var ok = true;
        var reg = /^[\u4e00-\u9fa5]+$/;
        $(this.aData).each(function(){
            if(!reg.test(this.value)){
                ok = this;
            }
        });
        return ok;
    };

}