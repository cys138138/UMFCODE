function ClassSelector(wrapClassSelectId, dataUrl, addClassTextId, config){
	//function ClassSelector(wrapClassSelectId, dataUrl, addClassTextId){
	this.oWrapClassSelect = $('#' + wrapClassSelectId);
	this.oGrade = null;
	this.oClass = null;
	this.aData = null;
	this.dataUrl = dataUrl;
	this.oGrade = config.oGrade ? config.oGrade : $('#gradeId');//  年纪
	this.oClass = config.oClass ? config.oClass : $('#classId');//  班级
	this.oAddClassText = addClassTextId ? $('#' + addClassTextId) : (function(){
		var oSpan = $(document.createElement('span'));
		oSpan.css('display', 'none');
		$('body').append(oSpan);
		return oSpan;
	})();
	var self = this;

	this._after_changeClass = config._after_changeClass ? config._after_changeClass : function(){};
	this._after_changeGrade = config._after_changeGrade ? config._after_changeGrade : function(){};
	
	this.load = function(schoolId){
		var self = this;
		$.ajax({
			type : 'post',
			url : this.dataUrl,
			data : 'schoolId=' + schoolId,
			success : function(result){
				self.aData = result.data;
				self.drawOption(self.aData);
				self.oAddClassText.css('display', 'none');
				self.oAddClassText.val('');
//				$('#emClass').remove();
			}
		});
	};

	this.drawOption = function(result){
		var gradeOptionContent = '<option value="0">请选择</option>';
		var gradeHtmlArray = [];
		for(var gradeKey in result){
			//gradeOptionContent += '<option value="' + gradeKey + '">' + result[gradeKey].name + '</option>';
			gradeHtmlArray.push('<option value="');
			gradeHtmlArray.push(gradeKey);
			gradeHtmlArray.push('">');
			gradeHtmlArray.push(result[gradeKey].name);
			gradeHtmlArray.push('</option>');
		}
		gradeOptionContent += gradeHtmlArray.join('');
		self.oGrade.html(gradeOptionContent);
		
		if(self.oClass.length){
			self.drawClassOption(self.oGrade.find('option:selected').val());
			self.oWrapClassSelect.find(self.oClass.selector).empty();
			self.oGrade.change(function(){
				self.drawClassOption($(this).val());
				self.oClass.change(function(){
					self.onchangeClass($(this).val());
					self._after_changeClass();
				});
				self.oAddClassText.css('display', 'none');
//				$('#emClass').remove();
				self._after_changeGrade();
			});
		}
		
	};

	this.onchangeClass = function(className){
		if(className == '0班'){
			self.oAddClassText.css('display', 'inline-block');
			if(self.oAddClassText.find('#emClass').length == 0){
				self.oAddClassText.append('<em id="emClass"> 班</em>');
				if($('#addClassText').length != 0 ){
					$('#addClassText').remove();
					$('#emClass').remove();
				}
				self.oWrapClassSelect.append('<input type="text" id="addClassText" name="addClassText" style="width:36px;display:inline;" /><em id="emClass"> 班</em>');
			}
		}else{
			self.oAddClassText.css('display', 'none');
			self.oAddClassText.val('');
			if($('#addClassText').length != 0 ){
					$('#addClassText').remove();
					$('#emClass').remove();
				}
//			$('#emClass').remove();
		}
	};



	this.drawClassOption = function(grade){
		self.oClass.html('');
		var classOptionContent = '<option value="-1">请选择</option>';
		if(grade != 0){
			var aClassData = this.aData[grade];
			for(var i = 0; i < aClassData.child.length; i++){
				classOptionContent += '<option value="' + aClassData.child[i] + '">' + aClassData.child[i] + '</option>';
			}
			classOptionContent += '<option value="0班">添加班级</option>';
		}
		self.oClass.append(classOptionContent);
	};




	this.getSelection = function(){
		var grade = self.oGrade.find('option:selected').val();
		var className = self.oClass.find('option:selected').val();
		return {grade : grade, classId : className};
	};
	
}



