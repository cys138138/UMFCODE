(function($, window){
	window.UShuoShuo = {
		aConfig : {
			login_user_id : 0,
			appendDom : {},
			user_home_url : '',
			user_info_url : '',
			support_url : '',
			comment_url : '',
			all_comment_url : '',
			all_reply_url : '',
			delete_shuo_url : '',
			delete_comment_url : '',
			apply_friend_url : '',
			publish_url : '',
			user_list_url : '',
			image_upload_url : '',
			sys_resource_url : '',
			pk_url : '',
			match_url : '',
			callBack : function(){}
		},
		
		oEditor : '',
		
		/**
		 * 设置配置参数
		 */
		config : function(aSetConfig){
			for(var key in aSetConfig){
				if(this.aConfig[key] !== undefined){
					this.aConfig[key] = aSetConfig[key];
				}
			}
		},
		
		UMEditor : {
			curReplyBoxId : 0,
			curReplyCommentBoxId : 0
		},
				
		showShuoShuo : function(data){
			var htmlStr = '';
			if(typeof(data) == 'object'){
				if(typeof(data.length) != 'undefined'){
					for(var i = 0; i < data.length; i++){
						htmlStr += this.buildShuoShuoHtml(data[i]);
					}
				}else{
					htmlStr += this.buildShuoShuoHtml(data);
				}
				this.aConfig.appendDom.slideDown('normal', function(){
					$('#shuoShuoList').append(htmlStr);
					initPhotoViewer();
					UShuoShuo.aConfig.callBack();
				});
			}else{
				console.log(data + 'is not a object')
			}
		},
		
		buildShuoShuoHtml : function(data){
			var htmlStr = '',
			titleStr = '发表说说',
			forwardHtml = '',
			pkHtml = '',
			matchHtml = '',
			goodHtml = '',
			pkBtn = '',
			matchBtn = '',
			commentHtml = '';
			
			if(data.source_type == 1){
				titleStr = '转发说说';
				var imgList = '';
				if(data.source_info.images.length != 0){
					imgList += '<div class="_by c"><div class="_match_end">';
					for(var i = 0; i < data.source_info.images.length; i++){
						imgList += '\
							<a class="_image" xid="shuoshuoImage" data-fancybox-group="thumb' + data.id + '" href="' + this.aConfig.sys_resource_url + data.source_info.images[i] + '" target="_blank" title="点击查看原图">\
								<img width="130" height="90" src="' + DEFAULT_IMG + '" real="' + this.aConfig.sys_resource_url + data.source_info.images[i] + '" onload="h(this);" />\
							</a>\
						';
					}
					imgList += '</ul></div></div>';
				}
				forwardHtml = '\
					<div class="_by c">\
						<div class="_shuoshuo f14">\
							<a class="tc036" href="' + this.getUserHomeUrl(data.source_info.user_info.id) + '">' + getVipName(data.source_info.user_info.name, data.source_info.user_info.vip) + '</a>：' + UMeEditor.decodeContent(data.source_info.content) + '\
						</div>\
						' + imgList + '\
					</div>\
				';
			}else if(data.source_type == 2){
				titleStr = '分享了PK结果';
				pkBtn = '<a class="tc036 _pk" href="' + data.source_info.pk_url + '">查看PK</a>';
				pkHtml = this.getPkFinishHtml(data);
			}else if(data.source_type == 3){
				titleStr = '分享了比赛结果';
				matchBtn = '<a class="tc036 _match" href="' + data.source_info.match_url + '">查看比赛</a>';
				matchHtml = this.getMatchFinishHtml(data);
			}else{
			
			}
			
			if(data.support.length != 0 ){
				goodHtml = this.buildGoodListHtml(data);
			}
			
			if(data.source_type == 3 && data.source_info.users.length != 0){
				goodHtml = this.buildMatchWinnerList(data);
			}
			
			
			if(data.comment.length != 0){
				commentHtml = this.buildCommentList(data);
			}else{
				commentHtml = '<div class="_comment"></div>';
			}
			
			var deleteBtn = '';
			if(data.user_info.id == this.aConfig.login_user_id){
				deleteBtn = '<a href="javascript:;" class="_delete tc036" onclick="UShuoShuo.deleteShuoShuo(' + data.id + ', this);">删除</a>';
			}
			
			var showAllBtn = '',
			goodBtn = '',
			forwardBtn = '',
			imagesListHtml = '';
			if(data.comment.length > 10){
				showAllBtn = '<a class="_more_comment f12 tc036" href="javascript:;" onclick="UShuoShuo.showAllComment(' + data.id + ');">展开全部评论</a>';
			}
			forwardBtn = '<a class="tc036 _forward" href="javascript:;" onclick="UShuoShuo.forwardShuoShuo(' + data.id + ');">转发</a>';
			if(data.images.length != 0){
				imagesListHtml += '<div class="_by c"><div class="_match_end">';
				for(var i = 0; i < data.images.length; i++){
					imagesListHtml += '\
						<a class="_image" xid="shuoshuoImage" data-fancybox-group="thumb' + data.id + '" href="' + this.aConfig.sys_resource_url + data.images[i].image + '" xid="shuoshuoImage" target="_blank" title="点击查看原图">\
							<img src="' + DEFAULT_IMG + '" real="' + this.aConfig.sys_resource_url + data.images[i].thumb + '" onload="h(this);" />\
						</a>\
					';
				}
				imagesListHtml += '</ul></div></div>';
			}
			
			goodBtn = '<a class="tc036 _good" href="javascript:;" onclick="UShuoShuo.support(' + data.id + ');">赞(<i xid="support_' + data.id + '">' + data.support.length + '</i>)</a>';
			
			htmlStr += '\
				<div class="_event mod">\
					<div class="_who">\
						<span class="head"><a href="' + this.getUserHomeUrl(data.user_info.id) + '"><img class="_profile" width="50" height="50" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.user_info.profile + '" onload="h(this);" /></a></span>\
						<div class="_name_description">\
							<a class="_name f14 tc036" href="' + this.getUserHomeUrl(data.user_info.id) + '">' + getVipName(data.user_info.name, data.user_info.vip) + '</a>\
							<span class="_description f14 tc999">' + titleStr + '</span>\
						</div>\
						<span class="_time f12 tc999">' + data.create_time + '</span>\
						' + deleteBtn + '\
					</div>\
					<div class="_what">\
						<div class="_content f14 tc333">\
							' + UMeEditor.decodeContent(data.content) + '\
						</div>\
						' + imagesListHtml + '\
						' + forwardHtml + '\
						' + matchHtml + '\
						' + pkHtml + '\
					</div>\
					<div class="_then">\
							' + goodHtml + '\
						<div class="_button_list">\
							' + goodBtn + '\
							<a class="tc036 _comment" href="javascript:;" onclick="UShuoShuo.showComment(' + data.id + ');">评论(<i xid="commentCount_' + data.id + '">' + data.comment.length + '</i>)</a>\
							' + forwardBtn + '\
							' + pkBtn + '\
							' + matchBtn + '\
						</div>\
						<div class="_comments" xid="shuoshuoCommentList_' + data.id + '">\
							' + showAllBtn + '\
							<!--comment_item-->\
							' + commentHtml + '\
							<div xid="replyCommentOuterBox_' + data.id + '"></div>\
						</div>\
					</div>\
				</div>\
			';
			return htmlStr;
		},
		
		showReplyComment : function(shuoId, commentId, parentId, replyId){
			UShuoShuo.checkEditor(function(){
				if(commentId != UShuoShuo.UMEditor.curReplyCommentBoxId && UShuoShuo.UMEditor.curReplyCommentBoxId != 0){
					$('[xid=replyCommentInnerBox_' + UShuoShuo.UMEditor.curReplyCommentBoxId + ']').html('');
				}
				if($('[xid=replyCommentOuterBox_' + UShuoShuo.UMEditor.curReplyBoxId + ']').length != 0){
					$('[xid=replyCommentOuterBox_' + UShuoShuo.UMEditor.curReplyBoxId + ']').html('');
				}
				if(UShuoShuo.UMEditor.curReplyCommentBoxId != commentId){
					UShuoShuo.UMEditor.curReplyCommentBoxId = commentId;
				}
				var htmlStr = '<div id="uShuoShuoReplyCommentEditor_' + commentId + '"></div>';
				$('[xid=replyCommentInnerBox_' + commentId + ']').html(htmlStr);
				
				UShuoShuo.oEditor = UMeEditor.getInstance({
					oContext : $('#uShuoShuoReplyCommentEditor_' + commentId),
					imageBaseUrl : UShuoShuo.aConfig.sys_resource_url,
					aFace : ['qq'],
					userList : true,
					userListUrl : UShuoShuo.aConfig.user_list_url,
					submitCaption : '回复',
					onSubmit : function(){
						var contentLength = UShuoShuo.oEditor.getContentLength();
						if(contentLength < 1 || contentLength > 150){
							UBox.show('回复内容为1到150个字符长度', -1);
							reutrn;
						}
						
						ajax({
							url : UShuoShuo.aConfig.comment_url,
							data : { 
								//reply_id : commentId, 
								reply_id : replyId, 
								content : UShuoShuo.oEditor.getContent(),
								at_user_ids : UShuoShuo.oEditor.getAtUserIdList()
							},
							success : function(aResult){
								if(aResult.status == 1){
									UShuoShuo.oEditor.destory();
									UShuoShuo.oEditor = null;
									UShuoShuo.showAllReply(commentId);
								}
								UBox.show(aResult.msg, aResult.status);
							}
						});
					}
				});
				UShuoShuo.oEditor.focus();
			});
		},
		
		showComment : function(id){
			UShuoShuo.checkEditor(function(){
				if(id != UShuoShuo.UMEditor.curReplyBoxId && UShuoShuo.UMEditor.curReplyBoxId != 0){
					$('[xid=replyCommentOuterBox_' + UShuoShuo.UMEditor.curReplyBoxId + ']').html('');
				}
				if($('[xid=replyCommentInnerBox_' + UShuoShuo.UMEditor.curReplyCommentBoxId + ']').length != 0){
					$('[xid=replyCommentInnerBox_' + UShuoShuo.UMEditor.curReplyCommentBoxId + ']').html('');
				}
				if(UShuoShuo.UMEditor.curReplyBoxId != id){
					UShuoShuo.UMEditor.curReplyBoxId = id;
				}
				var htmlStr = '<div id="uShuoShuoCommentEditor_' + id + '"></div>';
				$('[xid=replyCommentOuterBox_' + id + ']').html(htmlStr);
		
				UShuoShuo.oEditor = UMeEditor.getInstance({
					oContext : $('#uShuoShuoCommentEditor_' + id),
					imageBaseUrl : UShuoShuo.aConfig.sys_resource_url,
					aFace : ['qq'],
					userList : true,
					userListUrl : UShuoShuo.aConfig.user_list_url,
					submitCaption : '评论',
					onSubmit : function(){
						var contentLength = UShuoShuo.oEditor.getContentLength();
						if(contentLength < 1 || contentLength > 150){
							UBox.show('评论内容为1到150个字符长度', -1);
							reutrn;
						}
						
						ajax({
							url : UShuoShuo.aConfig.comment_url,
							data : { 
								shuoshuoId : id, 
								content : UShuoShuo.oEditor.getContent(),
								at_user_ids : UShuoShuo.oEditor.getAtUserIdList()
							},
							success : function(aResult){
								if(aResult.status == 1){
									UShuoShuo.oEditor.destory();
									UShuoShuo.oEditor = null;
									var oCommentCount = $('[xid=commentCount_' + id + ']');
									oCommentCount.html(parseInt(oCommentCount.html()) + 1);
									UShuoShuo.showAllComment(id);
								}
								UBox.show(aResult.msg, aResult.status);
							}
						});
					}
				});	
				UShuoShuo.oEditor.focus();
			});
		},
		
		checkEditor : function(callback){
			if(UShuoShuo.oEditor && UShuoShuo.oEditor.getContent().length){
				UBox.confirm('要放弃之前的编辑吗？', function(){
					UShuoShuo.oEditor.destory();
					UShuoShuo.oEditor = null;
					callback();
				});
			}else if(UShuoShuo.oEditor){
				UShuoShuo.oEditor.destory();
				UShuoShuo.oEditor = null;
				callback();
			}else{
				callback();
			}
		},
		
		showAllComment : function(id){
			var oShuoShuo = this;
			ajax({
				url : oShuoShuo.aConfig.all_comment_url,
				data : {id : id},
				success : function(aResult){
					if(aResult.status == 1){
						var aData = {id : id};
						aData.comment = aResult.data;
						var htmlStr = '';
						htmlStr = '\
							' + oShuoShuo.buildCommentList(aData) + '\
							<div xid="replyCommentOuterBox_' + id + '"></div>\
						';
						$('[xid=shuoshuoCommentList_' + id + ']').html(htmlStr);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		
		showAllReply : function(id){
			var oShuoShuo = this;
			ajax({
				url : oShuoShuo.aConfig.all_reply_url,
				data : {id : id},
				success : function(aResult){
					if(aResult.status == 1){
						var aData = {};
						aData.reply = aResult.data;
						var htmlStr = '';
						htmlStr = '\
							' + oShuoShuo.buildReplyList(aData) + '\
							<div xid="replyCommentInnerBox_' + id + '"></div>\
						';
						$('[xid=replyCommentList_' + id + ']').html(htmlStr);
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				}
			});
		},
		
		deleteShuoShuo : function(id, o){
			var oShuo = this;
			UBox.confirm('确定要删除吗？', function(){
				ajax({
					url : oShuo.aConfig.delete_shuo_url,
					data : {id : id},
					success : function(aResult){
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status == 1){
							var obj = $(o).parent().parent();
							obj.slideUp('normal', function(){
								obj.remove();
								if($('#shuoShuoList').children().length == 0){
									$('#shuoShuoList').html('<div class="air" style="background: #ffffff;height:200px;padding-top: 200px;text-align: center;"><p>没有说说数据哦！</p></div>')
								}
								if($('#shuoshuoCount').length != 0){
									$('#shuoshuoCount').html(parseInt($('#shuoshuoCount').html()) - 1);
								}
							});
							
						}
					}
				});
			});
		},
		
		deleteComment : function(id, o){
			var oShuo = this;
			UBox.confirm('确定要删除吗？', function(){
				ajax({
					url : oShuo.aConfig.delete_comment_url,
					data : {commentId : id},
					success : function(aResult){
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status == 1){
							var obj = $(o).parent().parent().parent().parent();
							obj.slideUp('normal', function(){
								obj.remove();
							});
							var oCommentList = $(o).parent().parent().parent().parent().parent(),
							sId = oCommentList.attr('xid').substring(20, oCommentList.attr('xid').length);
							var oCommentCount = $('[xid=commentCount_' + sId + ']');
							oCommentCount.html(parseInt(oCommentCount.html()) - 1);
						}
					}
				});
			});
		},
		
		deleteReply : function(id, o){
			this.deleteComment(id, o);
		},
		
		support : function(id){
			var supportNum = parseInt($('[xid=support_' + id + ']').html());
			
			ajax({
				url : this.aConfig.support_url,
				data : {id : id},
				success : function(aResult){
					if(aResult.status != 1){
						UBox.show(aResult.msg, aResult.status);
					}else{
						$('[xid=support_' + id + ']').html(supportNum + 1);
					}
				}
			});
		},
		
		forwardShuoShuo : function(id){
			var oShuo = this;
			UAlert.config({
				sys_resource_url: oShuo.aConfig.sys_resource_url,
				forward_shuoshuo_url: oShuo.aConfig.publish_url,
				user_list_url : oShuo.aConfig.user_list_url
			});
			//显示弹窗
			UAlert.alertForwardShuoShuo(id, 1, function(){});	

		},
		
		buildReplyList : function(data){
			var replyCommentHtml = '';
			if(data.reply.length != 0){
				for(var j = 0; j < data.reply.length; j++){
					var deleteReplyBtn = '';
					if(data.reply[j].user_info.id == this.aConfig.login_user_id){
						deleteReplyBtn = '<a href="javascript:;" class="_delete_ico tc036" onclick="UShuoShuo.deleteReply(' + data.reply[j].id + ', this);">删除</a>';
					}
					replyCommentHtml += '\
						<div class="_reply c">\
							<div class="_reply_content c">\
								<span class="head">\
									<a href="' + this.getUserHomeUrl(data.reply[j].user_info.id) + '"><img class="_profile" width="30" height="30" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.reply[j].user_info.profile + '" onload="h(this);" /></a>\
								</span>\
								<div class="_name_content">\
									<a class="_name f12 tc036" href="' + this.getUserHomeUrl(data.reply[j].user_info.id) + '">' + getVipName(data.reply[j].user_info.name, data.reply[j].user_info.vip) + '</a> 回复 <a class="_name f12 tc036" href="' + this.getUserHomeUrl(data.reply[j].reply_user_info.id) + '">' + data.reply[j].reply_user_info.name + '</a>：\
									<span class="_content f12 tc333">' + UMeEditor.decodeContent(data.reply[j].content) + '</span>\
									<div class="c">\
										<span class="_time f12 tc999">' + data.reply[j].create_time + '</span>\
										' + deleteReplyBtn + '\
										<a href="javascript:;" class="_reply_ico" onclick="UShuoShuo.showReplyComment(' + data.reply[j].shuoshuo_id + ', ' + data.reply[j].parent_id + ', ' + data.reply[j].id + ', ' + data.reply[j].id + ');">回复</a>\
									</div>\
								</div>\
							</div>\
						</div>\
					';
				}
			}else{
				replyCommentHtml = '<div class="_reply c"></div>';
			}
			return replyCommentHtml;
		},
		
		buildCommentList : function(data){
			var commentHtml = '';
			for(var i = 0; i < data.comment.length; i++){
				var replyCommentHtml = '',
				showAllBtn = '';
				if(data.comment[i].length > 20){
					showAllBtn = '<a class="_more_reply f12 tc036" href="javascript:;" onclick="UShuoShuo.showAllReply(' + data.comment[i].id + ');">展开全部回复</a>';
				}
				replyCommentHtml = this.buildReplyList(data.comment[i]);
				var deleteCommentBtn = '';
				if(data.comment[i].user_info.id == this.aConfig.login_user_id){
					deleteCommentBtn = '<a href="javascript:;" class="_delete_ico tc036" onclick="UShuoShuo.deleteComment(' + data.comment[i].id + ', this);">删除</a>';
				}
				commentHtml += '\
					<div class="_comment">\
						<div class="_comment_content c">\
							<span class="head">\
								<a href="' + this.getUserHomeUrl(data.comment[i].user_info.id) + '"><img class="_profile" width="30" height="30" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.comment[i].user_info.profile + '" onload="h(this);" /></a>\
							</span>\
							<div class="_name_content">\
								<a class="_name f12 tc036" href="' + this.getUserHomeUrl(data.comment[i].user_info.id) + '">' + getVipName(data.comment[i].user_info.name, data.comment[i].user_info.vip) + '</a>：\
								<span class="_content f12 tc333">' + UMeEditor.decodeContent(data.comment[i].content) + '</span>\
								<div class="c">\
									<span class="_time f12 tc999">' + data.comment[i].create_time + '</span>\
									' + deleteCommentBtn + '\
									<a href="javascript:;" class="_reply_ico" onclick="UShuoShuo.showReplyComment(' + data.id + ', ' + data.comment[i].id + ', ' + data.comment[i].id + ', ' + data.comment[i].id + ');">回复</a>\
								</div>\
							</div>\
						</div>\
						<div class="replys" xid="replyCommentList_' + data.comment[i].id + '">\
							' + showAllBtn + '\
							<!--reply_item-->\
							' + replyCommentHtml + '\
							<div xid="replyCommentInnerBox_' + data.comment[i].id + '"></div>\
						</div>\
					</div>\
				';
			}
			return commentHtml;
		},
		
		buildGoodListHtml : function(data){
			var flag = false,
			goodHtml = '',
			eventPopHtml = '\
				<div class="event_pop" xid="event_pop_' + data.id + '">\
				<i class="arrow arrow_top"></i>\
				<i class="arrow arrow_top2"></i>\
				<a class="close" href="javascript:;">&#10005;</a>\
				<h2 class="title">赞过的人</h2>\
				<ul class="list">\
			';
			goodHtml += '<div class="_profile_list"><a class="_good" title="赞过的人"></a>';
			for(var i = 0; i < data.support.length; i++){
				if(i < 10){
					goodHtml += '<a href="' + this.getUserHomeUrl(data.support[i].id) + '" title="' + data.support[i].name.replace(/<[^>]+>/g, '') + '"><img width="30" height="30" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.support[i].profile + '" onload="h(this);" /></a>';
				}else{
					flag = true;
					var gender = '';
					gender = data.support[i].gender == 1 ? '男' : '女';
					eventPopHtml += '\
						<li>\
							<p class="head"><a href="' + this.getUserHomeUrl(data.support[i].id) + '" title="' + data.support[i].name.replace(/<[^>]+>/g, '') + '"><img width="30" height="30" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.support[i].profile + '" onload="h(this);" /></a></p>\
							<p class="pub">\
								<span class="name ellipsis"><a href="' + this.getUserHomeUrl(data.support[i].id) + '">' + getVipName(data.support[i].name, data.support[i].vip) + '</a></span>' + gender + data.support[i].age + '岁 ' + data.support[i].province_name + data.support[i].city_name + data.support[i].area_name + '\
							</p>\
							<p class="follow"><a class="act" href="javascript:;" onclick="UShuoShuo.showAddFriend(' + data.support[i].id + ');"><i class="ico_event ico_event_add"></i>好友</a></p>\
						</li>\
					';
				}
			}
			if(flag){
				eventPopHtml += '</ul></div>';
				$('body').append(eventPopHtml);
			}
			if(data.support.length > 10){
				goodHtml += '<a href="javascript:;" class="_and_so_on" onclick="UShuoShuo.showMoreBox(' + data.id + ', this);"></a>';
			}
			goodHtml += '</div>';
			return goodHtml;
		},
		
		buildMatchWinnerList : function(data){
			var goodHtml = '';
			var flag = false,
			eventPopHtml = '\
				<div class="event_pop" xid="event_pop_' + data.id + '">\
				<i class="arrow arrow_top"></i>\
				<i class="arrow arrow_top2"></i>\
				<a class="close" href="javascript:;">&#10005;</a>\
				<h2 class="title">获奖的人</h2>\
				<ul class="list">\
			';
			goodHtml += '<div class="_profile_list"><a class="_match" title="比赛获奖的人"></a>';
			for(var i = 0; i < data.source_info.users.length; i++){
				if(i < 10){
					goodHtml += '<a href="' + this.getUserHomeUrl(data.source_info.users[i].user_info.id) + '" title="' + data.source_info.users[i].user_info.name.replace(/<[^>]+>/g, '') + '"><img width="30" height="30" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.source_info.users[i].user_info.profile + '" onload="h(this);" /></a>';
				}else{
					flag = true;
					var gender = '';
					gender = data.source_info.users[i].user_info.gender == 1 ? '男' : '女';
					eventPopHtml += '\
						<li>\
							<p class="head"><a href="' + this.getUserHomeUrl(data.source_info.users[i].user_info.id) + '" title="' + data.source_info.users[i].user_info.name.replace(/<[^>]+>/g, '') + '"><img width="30" height="30" src="' + DEFAULT_HEAD_IMG + '" real="' + this.aConfig.sys_resource_url + data.source_info.users[i].user_info.profile + '" onload="h(this);" /></a></p>\
							<p class="pub">\
								<span class="name ellipsis"><a href="' + this.getUserHomeUrl(data.source_info.users[i].user_info.id) + '">' + getVipName(data.source_info.users[i].user_info.name, data.source_info.users[i].user_info.vip) + '</a></span>' + gender + data.source_info.users[i].user_info.age + '岁 ' + data.source_info.users[i].user_info.province_name + data.source_info.users[i].user_info.city_name + data.source_info.users[i].user_info.area_name + '\
							</p>\
							<p class="follow"><a class="act" href="javascript:;"><i class="ico_event ico_event_add" onclick="UShuoShuo.showAddFriend(' + data.source_info.users[i].user_info.id + ');"></i>好友</a></p>\
						</li>\
					';
				}
			}
			if(flag){
				eventPopHtml += '</ul></div>';
				$('body').append(eventPopHtml);
			}
			goodHtml += '<a href="javascript:;" class="_and_so_on" onclick="UShuoShuo.showMoreBox(' + data.id + ', this);"></a></div>';
			return goodHtml;
		},
		
		showAddFriend : function(id){
			var oShuo = this;
			UAlert.config({
				user_id : id,
				user_info_url: oShuo.aConfig.user_info_url,
				sys_resource_url: oShuo.aConfig.sys_resource_url,
				apply_friend_url: oShuo.aConfig.apply_friend_url
			});
			//显示弹窗
			UAlert.alertApplyFriend();	
		},
		
		showMoreBox : function(id, o){
			var top = $(o).offset().top + 35, 
			left = $(o).offset().left + $(o).width() - 30,
			obj = $('[xid=event_pop_' + id + ']');
			//obj.css({top : top, left : left});
			//$('[xid=event_pop_' + id + ']').show();
            //var self = $(this);
            //var pop = $('.event_pop');
            var close = obj.find('.close');
            //var left = self.offset().left;
           // var top = self.offset().top + self.height() + 10;
            $(o).addClass('cur');
            obj.show(100).css({
                'left': left,
                'top': top
            });
            close.click(function() {
                $(o).removeClass('cur');
                obj.hide(100);
            });
		},
		
		getUserHomeUrl : function(userId){
			return this.aConfig.user_home_url.replace('_userId', userId);
		},
		
		getMatchFinishHtml : function(aMessage){
			var matchUrl = aMessage.source_info.match_url,
			result = '我的参赛得分：' + (parseInt(aMessage.source_info.best_score) / 100) + '分，排名：No.' + aMessage.source_info.ranking + '。';
			if(aMessage.source_info.ranking < 11){
				var orderName = ['冠军', '亚军', '季军', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名'][aMessage.source_info.ranking - 1];
				result = '恭喜你，本场比赛荣获' + orderName + '！' + result;
			}else{
				result = '很遗憾，本场比赛未得奖！' + result;
			}
			
			return '\
				<span class="_content f14 ' + (aMessage.source_info.ranking < 11 ? 'tcC33' : 'tc333') + '">' + result + '</span>\
				<div class="_by c">\
					<div class="_match_end">\
						<a class="_image" href="' + matchUrl + '">\
							<img width="130" height="90" src="' + DEFAULT_IMG + '" real="' + this.aConfig.sys_resource_url + aMessage.source_info.match_profile + '" onload="h(this);" />\
						</a>\
						<div class="_description">\
							<a href="' + matchUrl + '" class="_name f14 tc036">' + aMessage.source_info.match_name + '</a>\
							<div class="_introduction tc999">' + aMessage.source_info.description + '</div>\
							<span class="_total">' + aMessage.source_info.member_count + '人参赛</span>\
							<span class="_time">' + aMessage.source_info.match_start_time + ' - ' + aMessage.source_info.match_end_time + '</span>\
							<span class="_best">冠军得分 ' + (parseInt(aMessage.source_info.champion_score) / 100) + '</span>\
						</div>\
					</div>\
				</div>\
			';
		},
		
		getPkFinishHtml : function(aMessage){
			var aSender = aMessage.source_info.sender_user_info,
			aReceiver = aMessage.source_info.receiver_user_info;
			var tips = '';
			if(aMessage.source_info.winner_user_id == aMessage.user_info.id){
				tips = '恭喜你，赢得本次PK的胜利！我的PK得分：';
			}else{
				tips = '很遗憾，本次的PK负败！我的PK得分：';
			}
			if(aMessage.user_info.id == aMessage.source_info.sender_user_info.id){
				tips += (parseInt(aMessage.source_info.sender_score) / 100) + '，对方得分：' + (parseInt(aMessage.source_info.receiver_score) / 100);
			}else{
				tips += (parseInt(aMessage.source_info.receiver_score) / 100) + '，对方得分：' + (parseInt(aMessage.source_info.sender_score) / 100);
			}
			
			return '\
				<span class="_content f14 ' + (aMessage.source_info.winner_user_id == aMessage.user_info.id ? 'tcC33' : 'tc333') + '">' + tips + '</span>\
				<div class="_by c">\
					<div class="_pk_end">\
						<span class="_master">' + this._buildUser(aSender, {width:50, height:50}) + '</span>\
						<a class="_master_name tc036" href="javascript:void(0);">' + getVipName(aSender.name, aSender.vip) + '</a>\
						<span class="_vs">VS</span>\
						<span class="_slave">' + this._buildUser(aReceiver, {width:50, height:50}) + '</span>\
						<a class="_slave_name tc036" href="javascript:void(0);">' + getVipName(aReceiver.name, aReceiver.vip) + '</a>\
						<a href="' + aMessage.source_info.mission_url + '" class="_title f14 tc036">PK' + aMessage.source_info.mission_name + '</a>\
						<span class="_duration">' + aMessage.source_info.duration + '分钟</span>\
						<span class="_time">' + aMessage.source_info.create_time + ' - ' + aMessage.source_info.over_time + '</span>\
						<span class="_es">' + aMessage.source_info.es_counts + '题</span>\
						' + (aMessage.source_info.attachment_gold ? '<span class="_gold">' + aMessage.source_info.attachment_gold + '金币</span>' : '') + '\
					</div>\
				</div>\
			';
		},
		
		_parseTime : function(timeStamp){
			if(!timeStamp){
				return '时间:未知';
			}
			var unixTimestamp = new Date(timeStamp * 1000).toLocaleString(),
			time = unixTimestamp.replace(/^[0-9]+年|星期./g, '');
			return time.substr(0, time.length - 3);
		},
		
		_buildUserList : function(aSupportUserList){
			if(!aSupportUserList || !$.isArray(aSupportUserList)){
				return '';
			}

			var aUserListHtml = [];
			for(var i in aSupportUserList){
				aUserListHtml.push(_buildUser(aSupportUserList[i]));
			}
			return aUserListHtml.join('');
		},
		
		_buildUser : function(aUser, aSize){
			if(!aSize){
				aSize = {
					width : 30
					,height : 30
				};
			}
			return '<a class="_profile" href="' + this.aConfig.user_home_url.replace('_userId', aUser.id) + '" title="' + aUser.name.replace(/<[^>]+>/g, '') + '" target="_blank"><img width="' + aSize.width + '" height="' + aSize.height + '" src="' + DEFAULT_HEAD_IMG + '" real="' + aUser.profile + '" onload="h(this);" /></a>';
		}
	};
})(jQuery, window);