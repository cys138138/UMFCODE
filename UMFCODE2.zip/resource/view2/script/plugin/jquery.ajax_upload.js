/**
 * AjaxUpload 基于jQuery的微型异步上传插件
 * @author KK
 */
(function($){
	$.fn.extend({
		AjaxUpload : function(aOptions){
			aOptions = $.extend({
				text : '上传图片'
				,fileKey : '_ume_upload_file'
			}, aOptions);

			var $this = $(this);

			if(!$this.attr('name')){
				$this.attr('name', aOptions.fileKey);
			}

			//生成上传按钮
			var $oBtnUpload = $('<button type="button" class="' + $this.attr('class') + '" ' + $this.attr('style') + '>' + aOptions.text + '</button>').click(function(){
				$this.trigger('click');	//触发文件表单的单击来弹出文件选择器
			});
			$this.hide().after($oBtnUpload);


			$this.change(function(){
				var oCloneFile = $this.clone();
				oCloneFile[0].files = $this[0].files;	//兼容谷歌浏览器
				$('<iframe src="javascript:void(0);" style="display:none;" name="__tmpUploadIframe"></iframe>').appendTo('body').load(function(){
					var oPre = this.contentDocument.body.firstChild;
					if(!oPre){
						UBox.show('上传出错！相关信息：' + this.contentDocument.body.innerHTML);
					}

					var url = null,		//文件在浏览器内的URL
					file = oCloneFile[0].files[0];
					if (window.createObjectURL != undefined) {
						url = window.createObjectURL(file);
					} else if (window.URL != undefined) {
						url = window.URL.createObjectURL(file);
					} else if (window.webkitURL != undefined) {
						url = window.webkitURL.createObjectURL(file);
					}

					var aResult = $.parseJSON(oPre.innerHTML);
					aOptions.callback(aResult, file, url);

					$oForm.remove();
					$(this).remove();
				});

				var $oForm = $('<form style="display:none;" action="' + aOptions.uploadUrl + '" method="POST" enctype="multipart/form-data" target="__tmpUploadIframe"></form>').append(oCloneFile).appendTo('body');
				$oForm.submit();
			});

		}
	});
})(jQuery);