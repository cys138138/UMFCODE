(function($, win){
	var ieReg = new RegExp('msie', 'i');
	if(!ieReg.test(navigator.userAgent)){
		return;
	}
	win.console = {
		log : function(){
			
		}
		,error : function(){}
		,trace : function(){}
	};
})(jQuery, window);