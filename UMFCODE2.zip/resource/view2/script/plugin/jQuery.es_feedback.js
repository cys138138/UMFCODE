(function(window, $){
	var self = null;
	var commitUrl = '', selectRadio = '', aOptionValue = new Array();
	window.EsFeedback = self = {
		config : function(options){
			commitUrl = options.url;
			selectRadio = options.selectRadio;
			aOptionValue = options.aSelect;
		},
		show : function(options){
			//弹出反馈内容填写框
			var html = buildFeedBackHtml();
			
			popEasyDialog({
				title : '题目问题反馈',
				width : 450,
				height : 300,
				content : html,
				confirmCallBack : function(){
					EsFeedback.commit(options); 
					return false;
				}
			});
		},
		
		/**
		* 提交反馈内容
		*/
		commit : function(options){
			var selectValue = '', clickValue = '', content = '';
			clickValue = $('input[xid=esFeedbackInputValue]:checked').val();
			selectValue = $('select[id=esFeedbackSelectedValue] :selected').val();
			content = $('#feedbackContent').val();
			
			if(clickValue == 1){
				if(!selectValue){
					UBox.show('请选择原因！', -1);
					return false;
				}
				options.reason = selectValue;
			}else{
				if(!content){
					UBox.show('请填写原因！', -1);
					return false;
				}
				options.reason = content;
			}
			
			if(commitUrl == ''){
				UBox.show('未定义反馈的地址', -1);
				return false;
			}
			$.ajax({
				type : 'post',
				url : commitUrl,
				dataType : 'json',
				data : options,
				success : function(result){
					if(result.status == 1){
						UBox.show(result.msg, 1);
						easyDialog.close();
					}else if(result.status == 0){
						UBox.show(result.msg, 0);
					}
				},
				error : function(){
					UBox.show('系统出错，请稍后再试！', 0);
					easyDialog.close();
				}
			});
		},
		
		autoSelect : function (){
			$('input[id=esFeedbackCheckValue1]').click();
		}
	}	
	
	/**
	* 构建反馈填写框的HTML内容
	*/
	function buildFeedBackHtml(){
		var i, selectHtml = '<option value="">请选择原因</option>';
		for(i in aOptionValue){
			selectHtml += '<option value="'+ aOptionValue[i] +'">' + aOptionValue[i] + '</option>';
		}
		return getCssCode() + '<div class="wrapEsFeedback"><div class="feedbackSelect">\
		<span>请填写反馈原因：</span><br />\
		<input type="radio" name="esFeedbackInputValue"  xid="esFeedbackInputValue" id="esFeedbackCheckValue1" value="1" />\
		<select onchange="EsFeedback.autoSelect();" id="esFeedbackSelectedValue">' + selectHtml + '</select></div><div class="feedbackText">\
		<input type="radio" checked name="esFeedbackInputValue" xid="esFeedbackInputValue" id="esFeedbackCheckValue" value="2" />\
		<label for="esFeedbackCheckValue">其它：</label>\
		<br /><textarea id="feedbackContent" class="feedbackContent" ></textarea>\
		</div></div>';
	}
	
	/**
	* 构建反馈填写框的HTML内容
	*/
	function getCssCode(){
		return '<style type="text/css">\
		.wrapEsFeedback{width:430px; height:280px;}\
		.wrapEsFeedback .feedbackSelect{margin:10px 20px; width: 200px; height:50px;}\
		.wrapEsFeedback .feedbackSelect input{margin:5px 10px 10px 0;}\
		.wrapEsFeedback .feedbackText{margin:10px 20px; width:350px; height:150px;}\
		.wrapEsFeedback .feedbackText input{margin:5px 10px 10px 0;}\
		.wrapEsFeedback .feedbackText .feedbackContent{width:390px; height:165px; resize:none}</style>';
	}
})(window, jQuery);