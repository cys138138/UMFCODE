(function(win, $){
	win.Turntable = function(aOptions){
		var startTime = 0;
		var timeDesHandle = null;
		aOptions = $.extend({}, aOptions);
		var $oContext = aOptions.oContext;
		var $sTurnId = aOptions.sTurnId;		
		$oContext.html('<img id="' + $sTurnId + '" src="' + aOptions.background + '" />');
	
		this.start = function(){
			$('#' + $sTurnId).stopRotate();
			$('#' + $sTurnId).rotate({
				angle : 0, 
				duration : 1000000,
				animateTo : 150000
			});
			timeDesHandle = setInterval(function(){
				startTime++;
			}, 1000);
		};
		
		this.stop = function(angle){
			var remainTime = aOptions.limitRotateTime - startTime;
			var fStop = function(){
				clearInterval(timeDesHandle);
				
				$('#' + $sTurnId).stopRotate();
				$('#' + $sTurnId).rotate({
					angle : 0, 
					duration : 2000, 
					animateTo : angle, 
					callback : function(){
						aOptions.callback();
					}
				});
			};
			
			if(remainTime > 0){
				setTimeout(function(){
					fStop();
				}, remainTime * 1000);
			}else{
				fStop();
			}
		};
	};
})(window, jQuery);