function h(self){
	var $self = $(self);
	var real = $self.attr('real');
	//图片地址异常的情况不请求
	if(!real || real.substr(-1) == '/'){
	    return;
	}
	var image = new Image();
	image.src = real;
	image.onload = function(){
	    $self.attr('src', real).removeAttr('onload').removeAttr('real');
	};
}

