/**
 * 个人中心
 * Created by ZhaoHuanLei on 2014-5-7.
 */


//幻灯片
function vipSlide() {
    $('.vip_banner').mySlide();
    $('.vip_exchange_mod .slide').mySlide();
}

//特权
function vipPrivilege() {
    var box = $('.vip_cate_mod'),
        cate = box.find('.cate'),
        cateItem = cate.find('li'),
        fun = box.find('.fun'),
        funItem = fun.find('li');

    cateItem.on('click', function() {
        var self = $(this),
            selfClass = self.attr('class');
        self.addClass('selected').siblings().removeClass('selected');
        funItem.removeClass('selected');
        fun.find('.' + selfClass).addClass('selected');
    });
}



$(function() {
    vipSlide();             //幻灯片
    vipPrivilege();         //特权
});