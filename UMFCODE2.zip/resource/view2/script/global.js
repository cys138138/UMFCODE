function heightAdap(){
	var imgHeight = $(window).height();
	$('img.img-style').height(imgHeight);
	$('.warp').height(imgHeight);
}

function tollgateSelect(){

	$('.tollgate-item').click(function(){
		if($(this).parent().hasClass('pass-disabled')) {
			return false;
		}else {
			$(this).next('.item-select').fadeIn().parent().siblings().find('.item-select').fadeOut();
		}
		
	})

}

//短对话框居中
function shortCenter() {
	var centerH = ($(document).height() - $('#main').height()) / 2
	$('#main').css({
		'position' : 'relative',
		'top' : centerH + 'px'
	})
}

// 通用关闭
function mClose(selector) {
	if(selector) {
		$(selector).fadeOut();
	}
}



$(function(){
	heightAdap(); //背景高度自适应
	tollgateSelect(); //tollgate点击出现修炼-挑战-取消
})


//------------ By Charlie
function time2FormatStr(seconds){
	seconds = parseInt(seconds);
	var hourse = Math.floor(seconds / 3600),
	minute = Math.floor((seconds - hourse * 3600) / 60),
	second = seconds - hourse * 3600 - minute * 60;

	if(hourse < 10){
		hourse = '0' + hourse;
	}
	if(minute < 10){
		minute = '0' + minute;
	}
	if(second < 10){
		second = '0' + second;
	}
	return hourse + ':' + minute + ':' + second
}