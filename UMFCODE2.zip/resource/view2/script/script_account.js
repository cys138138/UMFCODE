/**
 * 注册流程
 * Created by ZhaoHuanLei on 13-12-13.
 */

//首页登录注册
function loginStatic() {
    //点击切换效果
    var static_mod = $('#static_mod');
    var cover = static_mod.find('.arrow')
    var menu = static_mod.find('.hd li');
    var cont = static_mod.find('.bd');
    menu.click(function() {
        var self = $(this);
        var i = menu.index(this);
        menu.eq(i).addClass('cur').siblings().removeClass('cur');
        cover.animate({'left': self.position().left + 25}, 'fast');
        cont.animate({'left': -i * 340}, 'fast');
		
		if(i){
			//refreshRegiterCaptcha();
			$('#verify_register_img').attr('src', getCaptcha());
		}else{
			//refreshLoginCaptcha();
			$('#verify_login_img').attr('src', getCaptcha());
		}
		
    });
    static_mod.find('.code_item .follow').on('mouseover mouseout', function() {
        $(this).next('.tips').stop().slideToggle(200);
    });
    //输入框文字
    static_mod.find('input').placeholder();
}

//中奖用户-滚动
function lotteryMarquee() {
    var $list = $("#dynamic_list");
    var $ul = $list.find("ul");
    $ul.append($ul.html());
    var height = parseInt($ul.height());
    var timer = null;
    var i = 0;
    function marquee(){
        i--;
        if (-i >= height/2){
            i = 0;
        }
        $ul.css("top", i + "px");
    }
    timer = setInterval(marquee, 30);
    $list.on({
        mouseover: function(){
            clearInterval(timer);
        },
        mouseout: function(){
            timer = setInterval(marquee, 30);
        }
    });
}

//转盘
function turntable() {
    var pin = $('#pin');
    var turntable = $('#turntable');
    pin.rotate({
        bind:{
            click:function(){
                var a = Math.floor(Math.random() * 360);
                turntable.rotate({
                    duration: 8000,
                    angle: 0,
                    animateTo: 3000+1440+a,
                    //easing: $.easing.easeOutSine,
                    callback: function(){
//                        alert('中奖了！');
                    }
                });
            }
        }
    });
}


//填写资料弹窗
function dataPop() {
    var selectSchoolInfo = $('#selectSchoolInfo');
    var searchschool = $('#searchSchool');
    var school_list = $('#school_list');
    var box = $('#data_pop');
    var close = box.find('.close');
    selectSchoolInfo.on('click', function() {
        $('body').append('<div id="mask" class="mask"></div>');
        var mask = $('#mask');
        mask.height($('body').height()).fadeIn('fast');
        box.fadeIn('fast');
        close.click(function() {
            mask.fadeOut('fast');
            box.fadeOut('fast');
        })
    });
    searchschool.on('click', function() {
        
		$('#fillSchoolName').hide();
		$('#searchSchool').attr('class','text');
		$('#schoolId').val(-1);
    });
    $('#data_mod input').placeholder();
    $('.school_mod input').placeholder();

}


//背景轮播
function accSlide() {
    var li = $('.acc_slide li');
    var prev = $('.acc_slide_page .prev');
    var next = $('.acc_slide_page .next');
    var len = li.length;
    var i = len - 1;

    li.eq(i).show();

    function auto(i) {
        li.fadeOut();
        li.eq(i).fadeIn();
    }

    prev.on('click', function() {
        if (i > 0) {
            i--;
            auto(i);
            prev.show();
            next.show();
        }
        if (i == 0) {
            prev.hide();
        }
    })
    next.on('click', function() {
        if (i < len - 1) {
            i++;
            auto(i);
            prev.show();
            next.show();
        }
        if (i == len - 1) {
            next.hide();
        }
    })
}


$(function() {
    loginStatic();          //首页登录注册
    lotteryMarquee();       //中奖用户-滚动
    //turntable();            //转盘
    dataPop();              //填写资料弹窗
    accSlide();             //背景轮播
})
