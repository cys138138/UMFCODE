/**
 * 家长、老师入口
 * Created by ZhaoHuanLei on 2014-02-25
 */


//选项卡调用
function entranceCall() {
    $.Tab('#trend .menu', '#trend .list', 'click');
    $.Tab('.acc_mod .menu', '.acc_mod .list', 'click');

    //调用输入框占位符    
	$('.p_index .loginbox input').placeholder();
    //调用select美化插件   
	if($.fn.easyDropDown) {
		 $('.choose_school select').easyDropDown();
	}
}

//教师登录注册
function teacherStatic() {
    //点击切换效果
    var static_mod = $('#t_static');
    var cover = static_mod.find('.arrow')
    var menu = static_mod.find('.hd li');
    var cont = static_mod.find('.bd');
    menu.on('click', function() {
        var self = $(this);
        var i = menu.index(this);
        menu.eq(i).addClass('cur').siblings().removeClass('cur');
        cover.animate({'left': self.position().left + 25}, 'fast');
        cont.animate({'left': -i * 340}, 'fast');
    });
    static_mod.find('.code_item .follow').on('mouseover mouseout', function() {
        $(this).next('.tips').stop().slideToggle(200);
    });
    //输入框文字
    $('#t_static input').placeholder();
}



//分析详情切换效果
function analysisSwitch() {
    $('.result_mod').on('click', '.view_btn', function() {
        $(this).next().slideToggle();
    });
}



$(function() {
    entranceCall();                     //选项卡调用
    teacherStatic();                    //教师登录注册
    //analysisSwitch();                   //分析详情切换效果
});