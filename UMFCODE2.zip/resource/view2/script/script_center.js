/**
 * 个人中心
 * Created by ZhaoHuanLei on 13-12-13.
 */



//关卡切换效果
function pointsSwitch(subjectId) {
    var box = $('#mission_list_' + subjectId).find('ul');
    var list = box.find('a');
    box.fadeOut(0).fadeIn();
    list.hover(function() {
        $(this).find('.lay').stop().animate({'top': '0px'}, 'fast');
    }, function() {
        $(this).find('.lay').stop().animate({'top': '100%'}, 'fast');
    });
}


//输入框占位符调用
function textPlace() {
    $('#ad_share_mod input').placeholder();
    $('#addmsg_mod textarea').placeholder();
    $('.profile_pop textarea').placeholder();
    $('.props .text').placeholder();
}


//签到
function checkin() {
    var act = $('#checkin_act');
    var rank = $('.checkin_rank');
    var close = rank.find('.close');
    var options = rank.find('.options');
    act.on('click', function() {
        rank.slideToggle('fast');
        $(this).toggleClass('cur');
        return false;
    });
    function layerClose() {
        rank.slideUp('fast');
        act.removeClass('cur');
    }
    close.on('click', function() {
        layerClose();
    });

    options.each(function() {
        var self = $(this);
        var para = self.find('p');
        var tit = para.find('span');
        var menu = self.find('ul');
        function optionsClose() {
            options.removeClass('cur').find('ul').hide();
        }
        para.on('click', function() {
            optionsClose();
            menu.show();
            self.addClass('cur');
            menu.on('click', 'li', function() {
                tit.text($(this).text());
                $(this).addClass('selected').siblings().removeClass('selected');
                optionsClose();
            });
            return false;
        });
        $(document).on('click', function() {
            optionsClose();
        });
    });

}

//个人中心：可能认识的人
function mayknow() {
    $('.mayknow_mod').on('mouseover mouseout', 'li', function() {
        $(this).find('.name').toggle().next('.btnbox').toggle();
    });
}

//最近比赛
function latelymatchTab() {
    var dtitle = $('.latelymatch_mod dt');
    var ddesc = $('.latelymatch_mod dd');
    ddesc.hide().first().show();
    dtitle.on('mouseover', function() {
        ddesc.hide();
        $(this).next().show();
    });
}


//用户资料卡
function userCard() {
    $('.person').hover(function() {
        $(this).find('.min_card').fadeIn();
    }, function() {
        $(this).find('.min_card').hide();
    });
}

//小纸条
function note() {
    //显示删除按钮
    $('.note_mod').on('mouseover mouseout', 'li', function() {
        $(this).toggleClass('on');
    });
}


//好友管理
function friendsManage() {

    //调用select美化插件
    if ($.fn.easyDropDown) {
        $('.select_site_pop select').easyDropDown();
    }

    //调用输入框占位符
    $('.friends_mod .side input').placeholder();

    //右侧好友分组
    $('.friends_group_mod').on('mouseover mouseout', 'li', function() {
        $(this).toggleClass('on');
    });

    //下拉菜单
    $('.fridends_manage_mod').on('mouseover mouseout', '.group_options', function() {
        $(this).parent().parent().addClass('zindex').siblings().removeClass('zindex');
        $(this).find('ul').stop(true).toggle();
    });

    $('.fridends_manage_mod').on('mouseover mouseout', 'li', function() {
       $(this).toggleClass('on');
    });

    //添加、编辑分组
    var groupHtml = '\
        <li id="newGroupName" class="group_edit">\
            <input class="text" type="text" maxlength="12"/>\
            <button class="use_btn save_btn">保存</button>\
            <a class="cancel" href="javascript:;" title="取消">&#10005;</a>\
        </li>';

    function removeGroupHtml() {
        $('.friends_group_mod .group_edit').remove();
    }
    $('.friends_group_mod').on('click', '.edit', function() {
        removeGroupHtml();
        var self = $(this);
        var parent = self.parent().parent();
        parent.after(groupHtml).addClass('cur').siblings().removeClass('cur');
        $('.group_edit').on('click', '.cancel', function() {
            removeGroupHtml();
        });
    });
    $('.friends_group_mod .create_btn').on('click', function() {
        removeGroupHtml();
        var self = $(this);
        var parent = self.parent();
        parent.after(groupHtml);
        $('.friends_group_mod .save_btn').html('添加');
        $('.group_edit').on('click', '.cancel', function() {
            removeGroupHtml();
        });
    });

}


//错题集
function questionList() {
    $('.question_mod').on('mouseover mouseout', 'li', function() {
        $(this).toggleClass('on');
    });
    $('.question_mod ul').on('click', 'input', function() {
        var self = $(this);
        self.prop('check', !self.prop('check'));
        self.parent().parent().toggleClass('selected');
    });
}


//读取cookies
function getCookie(name)
{
	var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
	if(arr=document.cookie.match(reg)){
		return unescape(arr[2]);
	}else{
		return null;
	}
}


//引导
function guide(url, reourceUrl, addFriendUrl, mallUrl, goodsUrl){
	var recommandHtml = '';
	var goodsHtml = '';
	ajax({
		type : 'post',
		url : url,
		success : function(result){
			var friendData = result.data.friend;
			var goodData = result.data.goods;
			for(var i = 0; i < friendData.length; i++){
				recommandHtml += '<li xid="' + friendData[i].id + '" class="selected">\
							<a href="javascript:;">\
								<span class="head"><img src="' + DEFAULT_HEAD_IMG + '" real="' + reourceUrl + friendData[i].profile + '" width="80" height="80" alt="" onload="h(this);" /></span>\
								<span class="name ellipsis">' + getVipName(friendData[i].name, friendData[i].vip) + '</span>\
								<span class="controls"><i class="ico ico_then"></i></span>\
							</a>\
						</li>';
			}
			
			for(var i = 0; i < goodData.length; i++){
				var thisGoodsUrl = goodsUrl.replace('_goodsId', goodData[i].id);
				goodsHtml += '<li>\
								<div class="gift_carousel_list_img">\
									<a target="_blank" href="' + thisGoodsUrl + '"><img onload="h(this);" real="' + reourceUrl + goodData[i].profile + '" src="' + DEFAULT_HEAD_IMG + '" ></a>\
									<span>' + goodData[i].name + '</span>\
								</div>\
								<div class="gift_carousel_list_txt">\
									<span>' + goodData[i].gold + '</span>金币(<span class="smallFont">LV' + goodData[i].level + '</span>)\
								</div>\
							</li>';
			}
			var html = '\
				<div class="guide_mod">\
					<div class="guide_mask"></div>\
					<!--引导1：欢迎 [-->\
					<div class="guide_welcome png"><a class="guide_btn" href="javascript:;">知道了</a></div>\
					<!--引导1：欢迎 [-->\
					<!--引导2：礼物 [-->\
					<div class="guide_gift png"><a class="guide_btn" href="javascript:;">知道了</a><a target="_blank" class="gift_link" href="' + mallUrl + '">兑换商品</a>\
                    <div class="gift_carousel c">\
                        <a href="" class="prev"></a>\
                         <div class="gift_carousel_list">\
                            <ul>' + goodsHtml + '</ul>\
                        </div>\
                        <a href="javascript:;" class="next"></a>\
                    </div>\
                    </div>\
					<!--引导2：礼物 [-->\
					<!--引导3：新手帮助 [-->\
					<div class="guide_help png"><a class="guide_btn" href="javascript:;">知道了</a></div>\
					<!--引导3：新手帮助 [-->\
					<!--引导4：好友推荐 [-->\
					<div class="guide_friends png">\
						<ul id="recommandList" class="list">' + recommandHtml + '</ul>\
						<a class="guide_btn" href="javascript:;">加为好友</a>\
						<a class="guide_skip_btn" href="javascript:;">跳过</a>\
					</div>\
					<!--引导4：好友推荐 [-->\
				</div>';

			$('body').append(html);
			var mask = $('.guide_mask').height($(document).height());
			var guide = $('.guide_mod');
			var welcome = $('.guide_welcome');
			// var feed = $('.guide_feed');
			// var tools = $('.guide_tools');
			// var menu = $('.guide_menu');
			// var mayknow = $('.guide_mayknow');
            var gift = $('.guide_gift');
            var help = $('.guide_help');
			var friends = $('.guide_friends');

			$('html, body').animate({'scrollTop': 0});
			welcome.fadeIn();
			welcome.find('.guide_btn').click(function() {
				welcome.hide();
				gift.fadeIn();
			});
            gift.find('.guide_btn').click(function() {
                gift.hide();
                help.fadeIn();
            });
            help.find('.guide_btn').click(function() {
                help.hide();
                friends.fadeIn();
            });
			// feed.find('.guide_btn').click(function() {
			// 	feed.hide();
			// 	tools.fadeIn();
			// });
			// tools.find('.guide_btn').click(function() {
			// 	tools.hide();
			// 	menu.fadeIn();
			// });
			// menu.find('.guide_btn').click(function() {
			// 	menu.hide();
			// 	mayknow.fadeIn();
			// 	$('html, body').animate({'scrollTop': 600});
			// });
			// mayknow.find('.guide_btn').click(function() {
			// 	mayknow.hide();
			// 	var userId = getCookie('userId');
			// 	var str = userId + "=1";
			// 	var date = new Date();
			// 	var ms = 9999 * 24 * 3600 * 1000;
			// 	date.setTime(date.getTime() + ms);
			// 	str += "; expires=" + date.toGMTString();
			// 	document.cookie = str; 
			// 	friends.fadeIn();
			// 	$('html, body').animate({'scrollTop': 0});
			// });

			friends.find('.guide_skip_btn').click(function() {
				friends.fadeOut(function() {
					guide.remove();
				});
			});
			friends.on('click', 'li', function() {
				$(this).toggleClass('selected');
			});

			friends.find('.guide_btn').click(function(){
				var len = friends.find('.selected').length; //包含selected的li表示选中
				//alert('已经选中'+ len +'好友');   //测试 - 已经选中的用户
				var friendList = [];
				friends.find('.selected').each(function(){
					friendList.push($(this).attr('xid'));
				});
				
				ajax({
					type : 'post',
					url : addFriendUrl,
					data : {
						friendList : friendList
					},
					success : function(result){
						UBox.show(result.msg, result.status);
						if(result.status == 1){
							friends.fadeOut(function() {
								guide.remove();
							});
						}
					}
				});
			});
            
            //guide_help 动态高度
            help.css({
                top : $(window).height() - $(window).scrollTop() - (450) +'px'
            });
            $(window).resize(function(){
                help.css({
                    top : $(window).height() - $(window).scrollTop() - (450) +'px'
                });
            });
            //引导2 gift轮播
            function guide_gift_carousel(){
                var page = 1;//初始化page
                var perPage = 3;//每版面LI的个数
                var giftUl = $('.gift_carousel_list ul');
                var giftLi = $('.gift_carousel_list ul').find('li');
                var giftLiNum = $('.gift_carousel_list ul').find('li').length;
                var giftUlWidth = giftLiNum*(giftLi.width()+22);

                var pageNumber = Math.ceil(giftLiNum/perPage);//有多少个版面

                var giftPrev = $('.gift_carousel .prev')
                var giftNext = $('.gift_carousel .next')

                $('.gift_carousel_list ul').width(giftUlWidth);

                giftNext.on('click',function(event){
                    if(giftUl.is(':animated')){
                        return false;
                    }else if(page == pageNumber)
                    {
                        giftUl.animate({ left : '0px' },'fast')
                        page = 1;
                    }
                    else{
                    giftUl.animate({
                        left : '-=' + ((giftLi.width() + 22)*3)
                    },'slow')
                    page++;
                    }

                    return false;
                })

                giftPrev.on('click',function(event){
                    if(giftUl.is(':animated')){
                        return false;
                    }else if(page == 1)
                    {
                        giftUl.animate({ left : ((giftLi.width() + 22)*3)*(pageNumber-1)*-1 },'fast')
                        page = pageNumber;
                    }
                    else{
                    giftUl.animate({
                        left : '+=' + ((giftLi.width() + 22)*3)
                    },'slow')
                    page--;
                    }

                    return false;
                }) 
            }   
            guide_gift_carousel();
            //end  gift轮播 
			}
	});
}



//修改头像
function reviseHead() {
    $(document).on('mouseover mouseout', 'div.head', function() {
        $(this).find('.revise').stop(true).slideToggle(200);
    });
}



//说说图片弹窗
function initPhotoViewer() {	
	if ($.fn.gallery) {
        $('[xid="shuoshuoImage"]').gallery();
    }
}



//赛事列表
function matchList() {
    $('#match_list').on('mouseenter ', '.part', function() {
        $(this).find('.overlay').stop(true).animate({'top': '1px'}, 200);
    }).on('mouseleave', '.part', function() {
        $(this).find('.overlay').stop(true).animate({'top': '100%'}, 200);
    });
}


//兑换商城
function exchangeEffect() {
    //滚动
    $('#exc_being_list').marqueeMulti();
    //焦点图
    $('.exc_slide').mySlide();
}


//错题
function wrongQuestion() {
    //下来菜单调用
    $('.ques_repair_mod .options').dropdown();return;
    //回复
    var box = $('.ques_review_mod');
    var replyHtml = '\
        <li class="add_reply">\
            <a class="tipsbox del" href="javascript:;">\
                <i class="ico ico_del2"></i>\
                <span class="overlay">关闭<i class="arrow"></i></span>\
            </a>\
            <div class="area"><textarea class="text">回复 刘志军：</textarea></div>\
            <div class="addons">\
                <div class="attach">\
                    <a class="act_face" href="javascript:;" title="发表情"><i class="ico ico_face"></i></a>\
                    <span class="total">0/400</span>\
                </div>\
                <div class="operate">\
                    <label for=""><input type="checkbox"/>匿名</label>\
                    <a class="btn" href="javascript:;">发表</a>\
                </div>\
            </div>\
        </li>';
    function place(text) {
        var text = text,
            place = text.val();
        text.focus(function() {
            if (text.val() == place) {
                text.val('').css({
                    'height': '50px',
                    'color' : '#333'
                });
            }
        }).blur(function() {
            if(text.val() == '') {
                text.val(place).css({
                    'height': '20px',
                    'color' : '#999'
                });
            }
        });
    }
    box.on('click', '.reply', function() {
        box.find('li.add_reply').remove();
        var item = $(this).parent();
        item.after(replyHtml);
        var text = box.find('li.add_reply').find('textarea');
        place(text);
        var del = box.find('.del');
        del.click(function() {
            box.find('li.add_reply').remove();
        });
    });
    var text2 = box.find('div.add_reply').find('textarea');
    place(text2);
}



//错题修复-关卡切换
function quesRepair() {
    var box = $('.ques_repair_mod .area');
    var act = box.find('.act');
    var stop = true;
    act.click(function() {
        if (stop) {
            act.text('展开');
            box.addClass('cutover');
            stop = false;
        } else {
            act.text('收起');
            box.removeClass('cutover');
            stop = true;
        }
    });
    act.trigger('click');
}


$(function() {
    pointsSwitch();             	//关卡切换效果
    textPlace();                  	//输入框占位符调用
    checkin();                  	//签到
    latelymatchTab();               //选项卡调用
    userCard();                     //用户资料卡
    mayknow();                      //可能认识的人
    note();                         //小纸条
    friendsManage();                //好友管理
    questionList();                 //错题集
    reviseHead();                   //修改头像
	initPhotoViewer();				//说说图片弹窗
    matchList();                    //赛事列表
	//exchangeEffect();				//兑换商城
    wrongQuestion();                //错题
    quesRepair();                   //错题修复-关卡切换
});