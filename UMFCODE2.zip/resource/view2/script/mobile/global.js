
function heightAdap(){
	var imgHeight = $(document).height();

	$('img.img-style').css("height",imgHeight);
	$('.warp').height(imgHeight);
	$(window).resize(function(){
		var imgHeight = $(document).height();
		$('img.img-style').css("height",imgHeight);
		$('.warp').height(imgHeight);
	});
	$(window).scroll(function(){
		var imgHeight = $(document).height();
		$('img.img-style').css("height",imgHeight);
		$('.warp').height(imgHeight);
	});
}

function tollgateSelect(){

	$('.tollgate-item').click(function(){
		if($(this).parent().hasClass('pass-disabled')) {
			return false;
		}else {
			$(this).next('.item-select').fadeIn().parent().siblings().find('.item-select').fadeOut();
		}
		
	})

}

//短对话框居中
function shortCenter(selector) {
	var centerH = ($(document).height() - $(selector).height()) / 2
	$(selector).css({
		'position' : 'relative',
		'top' : centerH + 'px'
	})
}

// 通用关闭
function mClose(selector) {
	if(selector) {
		$(selector).fadeOut();
	}
}

function time2Str(seconds){
	if(seconds < 1){
		return '';
	}else if(seconds >= 1 && seconds < 60){
		return parseInt(seconds) + '秒';
	}else if(seconds >= 60 && seconds < 3600){
		var s = Math.floor(seconds % 60);
		var m = Math.floor(seconds / 60);
		if(s){
			return m + '分钟' + s + '秒';
		}else{
			return m + '分钟';
		}
	}else{
		var n = seconds % 3600;
		var m = Math.floor(n / 60);
		var h = Math.floor(seconds / 3600);
		if(m){
			return h + '小时' + m + '分钟';
		}else{
			return h + '小时';
		}
	}
}

function h(o){
	var $o = $(o);
	var imgUrl = $o.attr('real');
	$('<img src="' + imgUrl + '">').appendTo('body').hide().load(function(){
		$o.attr('onload', '').attr('src', imgUrl).attr('real', '');
		$(this).remove();
	});
}

$(function(){
	heightAdap(); //背景高度自适应
})


