

// selectTemp 切换 
function teacherTabs(){
	$('#tabs').find('#tabsControl li a').each(function(index,val){
		$(this).click(function(){
			var _index = index;
			$(this).addClass('current').parent().siblings().find('a').removeClass('current')
			$('#tabsContent' + (++_index)).css('display','block').siblings().css('display','none')
		});
	});
};




var $oConditionContent = null;

// 自适应高度
function indexAdapt(){
	var wh = $(document).height();
	var hh = $('#headerHome').outerHeight();
	$('#contentHome').css({'height':wh-hh});
	$(window).resize(function(){
		var wh = $(document).height();
		var hh = $('#headerHome').outerHeight();
		$('#contentHome').css({'height':wh-hh});
	});
	$(window).scroll(function(){
		var wh = $(document).height();
		var hh = $('#headerHome').outerHeight();
		$('#contentHome').css({'height':wh-hh});
	});
};




$(function(){
	indexAdapt();
});
