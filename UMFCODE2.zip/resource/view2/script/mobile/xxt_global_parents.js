

// totalScore 切换 
function totalScoreTabs(){
	$('#dataTabs, #dataTabs1').find('.data-tabs-title a').each(function(index,val){
		$(this).click(function(){
			var _index = index;
			$(this).addClass('current').siblings().removeClass('current');
			$('#dataTabsContent, #dataTabsContent1').find('.pane').eq(index).css('display','table').siblings().css('display','none')
		});
	});
};

// 模拟select下拉
function selectBox(){
	$('#selectBox, #selectBox1').each(function(){
		$(this).click(function(){
			$(this).find('.option').slideDown();
			return false;
		})
		$(document).click(function(){
			$(this).find('.option').slideUp();
			return false;
		});
	});

	// 传值
	$('.option a').each(function(){
		$(this).click(function(){
			var val = $(this).text();
			$('.select-txt').html(val);
			$('.option').slideUp();
			return false;
		})
	})
};




// 自适应高度
function indexAdapt(){
	var wh = $(window).height();
	var hh = $('#headerHome').outerHeight();
	$('#contentHome').css({'height':wh-hh});
	$(window).resize(function(){
		var wh = $(document).height();
		var hh = $('#headerHome').outerHeight();
		$('#contentHome').css({'height':wh-hh});
	});
	$(window).scroll(function(){
		var wh = $(document).height();
		var hh = $('#headerHome').outerHeight();
		$('#contentHome').css({'height':wh-hh});
	});
};

function htmlAdapt(){
	var wh = $(window).height();
	$('body,html').css({'height':wh})
	$(window).resize(function(){
		var wh = $(window).height();
		$('body,html').css({'height':wh})
	});
	$(window).scroll(function(){
		var wh = $(window).height();
		$('body,html').css({'height':wh})
	});
};

$(function(){
	htmlAdapt();
	indexAdapt();
});
