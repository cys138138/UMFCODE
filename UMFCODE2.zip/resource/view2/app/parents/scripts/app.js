Zepto(function($) {
    var $body = $('body'),
        // $wlHeader = $('.widget-hd'),
        // demoListTpl = $('#tpl-demo-list').html(),
        // listCompiler = Handlebars.compile(demoListTpl),
        $demoList = $('#demo-list'),
        widgets = ['goback', 'report', 'home', 'tutorial', 'more'],
        localStorageSupported = ('localStorage' in window) && window['localStorage'],
        storage = window.localStorage;
        $('#navBars li').removeClass('am-active');
    $(' #navBars a').not('#navbar-more').on('click', function(e) {
      e.preventDefault();
	  if($(this).attr('id') == 'btn-back'){return;}
      $('.more-list').removeClass('am-active');
      var widgetName = $(this).attr('data-rel');

      window.location.hash = widgetName;

      $('#navBars li').removeClass('am-active');
      $(' #navbar-' + widgetName).addClass('am-active');

      // set demo list title
      // $wlHeader.find('h1').text($(this).text() + 'Demos');
    });

    $(window).on('hashchange', function(e) {
      updateDemoList();
    });



    // 更多点击事件
    $('#navbar-more').on('click',function(e){
      e.preventDefault();
      $(this).find('.navbars-icon').parent().parent().addClass('am-active');
      $('.more-list').addClass('am-active');
    });

    $(document).on('click',function(e){

      if($(e.target).closest('#navbar-more, .more-list').length==0){
        $('.more-list').removeClass('am-active');
      }
    })

    $('#mobile-home').addClass('am-page-active');

    // 初始化页面
    updateDemoList();

    function updateDemoList() {
      var widgetName = window.location.hash.replace('#', '')

      // 显示当前页面图标
      $('#navBars li').removeClass('am-active');
      $('#navbar-' + widgetName).addClass('am-active');

      // hash为null，什么都不做
      if(widgetName == ('null'&&'more')){
        return false;
      }
      if(widgetName == 'goback'){
        return;
      }
      if(widgetName == 'more'){
        $('#navbar-more').addClass('am-active');
      }

      if(widgetName == 'cont'){
        $('#navbar-tutorial').addClass('am-active');
      }

      // hash为空，默认为home
      if(widgetName == ''){
        widgetName = 'home';
        // 显示当前页面图标
        $('#navBars li').removeClass('am-active');
        $('#navbar-' + widgetName).addClass('am-active');
      }else{
        $('.am-page').each(function(index){
          if($(this).hasClass('am-page-active')){
            $(this).removeClass('am-page-active').addClass('am-page-hide am-page-animate');
          }
        });

        $('#mobile-'+ widgetName).removeClass('am-page-hide am-page-hidden am-page-animate').addClass('am-page-reset');
        setTimeout(function(){
          $('#mobile-'+ widgetName)
            .addClass('am-page-active am-page-animate');

          if (widgetName === '' || widgets.indexOf(widgetName) < 0 ) {
            $body.removeClass('demo-list-active');
          }
        },20);
      }

      // ajax 提取数据
      //   $.ajax({
      //     type: 'GET',
      //     url: '/widgets/' + widgetName + '?json=1',
      //     dataType: 'json',
      //     success: function(data) {
      //       $demoList.empty().html(listCompiler(data));
      //       $('body').addClass('demo-list-active');
      //       storage.setItem(storageKey, JSON.stringify(data));
      //     },
      //     error: function(xhr, type) {
      //       alert('Ajax error');
      //     }
      //   });
    }
	setTimeout(dialogConfirm(), 2000);
  });

function showlink(link){
  window.location.href=link;
}


function dialogConfirm(){
	var alertHd = $('.um-alert-hd');
	var alertBd = $('.um-alert-bd');
	Zepto('[data-alert]').on('click', function() {
		// 写数据
		if(Zepto(this).attr('data-alert')=='report' || Zepto(this).attr('data-alert')=='tutorial'){
			//点击进入模拟账号提示
			alertBd.html('现在进入功能演示，将切换至演示帐号！演示帐号的数据并非您本人数据，您可通过页面顶部的按钮 退出演示帐号！');
		}else if(Zepto(this).attr('data-alert')=='noShowAnalogAccount'){
			alertBd.html('今后将不再显示推荐完整体验功能。如需进入功能演示，可通过底部更多按钮进入');
		}
		var that = Zepto(this);
		// 弹窗配置
		Zepto('#um-confirm').modal({
			relatedElement: this,
			onConfirm: function(){
				// 确认操作
				if(that.attr('data-alert')=='report'){
					//点击进入报告操作
					showlink('/?m=Statistic&a=enterAnalogAccount&type=1');
				}else if(that.attr('data-alert')=='tutorial'){
					//点击进入辅导操作
					showlink('/?m=Statistic&a=enterAnalogAccount&type=2');
				}else if(that.attr('data-alert')=='noShowAnalogAccount'){
					//点击进入辅导操作
					noShowAnalogAccount();
				}
			},
			onCancel: function() {
				return;
			}
		});
	});
}

function showDialogConfirm(type){
	var alertHd = $('.um-alert-hd');
	var alertBd = $('.um-alert-bd');
	alertBd.html('现在进入功能演示，将切换至演示帐号！演示帐号的数据并非您本人数据，您可通过页面顶部的按钮 退出演示帐号！');
	Zepto('#um-confirm').modal({
		relatedElement: this,
		onConfirm: function(){
			// 确认操作
			if(type == 1){
				showlink('/?m=Statistic&a=enterAnalogAccount&type=1');
			}else if(type == 2){
				showlink('/?m=Statistic&a=enterAnalogAccount&type=2');
			}else{
				showlink('/?m=Statistic&a=enterAnalogAccount');
			}
		},
		onCancel: function() {
			return;
		}
	});
}


