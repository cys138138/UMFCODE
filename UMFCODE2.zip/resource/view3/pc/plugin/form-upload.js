(function(win){
	win.FormUpload = function(elements, url, callback){
		if(typeof(elements) == 'undefined'){return;}

		var form = null;
		if(typeof(FormData) != 'undefined'){
			if(elements.tagName == 'FORM'){
				form = new FormData(elements);
			}else{
				form = new FormData();
				for(var key in elements){
					if(elements.hasOwnProperty(key)){
						form.append(key, elements[key]);
					}
				}
			}
			var xhr = new XMLHttpRequest();
			xhr.open("post", url, true);
			xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
			xhr.send(form);
			xhr.addEventListener('load', function (e) {
			   callback(JSON.parse(e.target.response));
			});
		}
	};
})(window);