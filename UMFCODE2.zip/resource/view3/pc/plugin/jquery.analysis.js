(function($, win){
	/*
	 * 解题思路插件
	 * 依赖 Jq|UBox|layer|CharInputer 插件
	 */

	win.analysisPlugin = function(action, options){
		switch(action){
			case 'add' :
				_add(options);
				break;
			case 'edit' :
				_edit(options);
				break;
			default :
				$.error('解题插件传入错误的操作方法，当前方法是:' + action);
				break;
		}
	};

	function _add(aConfig){
		lastActiveObject = null;
		//发表解题思路
		var content = aConfig.defaultContent,
			subject = aConfig.subject,
			callbackFun = aConfig.callback,
			editUrl = aConfig.editUrl,
			publishAnalysis = function (analysis){
				var isOk = false;
				ajax({
					url : editUrl,
					async : false,
					data : {
						es_id : aConfig.id,
						analysis : analysis
					},
					success : function(aResult){
						UBox.show(aResult.msg, aResult.status);
						if(aResult.status != 1){
							return;
						}
						isOk = true;
						$('#esItem' + aConfig.id).data('analysis', analysis).showAnalysis();
						if(typeof(callbackFun) === 'function'){
							return callbackFun();
						}
					}
				});
				return isOk;
			};

		$.layer({
			type: 1,
			title: '增加解题思路',
			shade: [0.8, '#000'],
			area: ['600px', '360px'],
			btns: 1,
			page: {html: '<style>.dialogWriteEsAnalysis textarea{width: 575px;height: 260px;}</style><div id="dialogWriteEsAnalysis" class="dialogWriteEsAnalysis"><textarea xid="esAnalysis">' + content + '</textarea></div>'},
			btn: ['确定'],
			zIndex: 9888,
			yes: function(index){
				var esAnalysis = $.trim($('#dialogWriteEsAnalysis [xid="esAnalysis"]').val());
				if(!esAnalysis){
					UBox.show('请填写解题思路', -1);
					return false;
				}

				if(content != esAnalysis) publishAnalysis(esAnalysis);
				layer.close(index);
			}
		});

		if(subject == 1 || subject == 2){
			if(typeof(CharInputer) == 'undefined'){
				$.error('在解题思路插件使用时没有引用符号输入插件!');
				return;
			}
			var tool;
			if(subject == 1){
				tool = '拼音输入器';
			}else if(subject == 2){
				tool = '数学符号输入器';
			}
			$('.xubox_botton').append('<a onclick="CharInputer.show();" class="xubox_no xubox_botton3" style="left: 60%;">' + tool + '</a>');

			$('#dialogWriteEsAnalysis').on('click', '[xid="esAnalysis"]', function(){
				lastActiveObject = this;
			});
			CharInputer.init({subject : subject, isOverlay:false});
		}
	};

	function _edit(aConfig){
		lastActiveObject = null;
		var content = aConfig.defaultContent,
			subject = aConfig.subject,
			callbackFun = aConfig.callback,
			editUrl = aConfig.editUrl,
			postAnalysis = function(str){
				if(!editUrl){
					UBox.show('错误的解题思路地址', -1);
					return false;
				}
				ajax({
					url : editUrl,
					data : {
						id : aConfig.id,
						content : str
					},
					success : function(aResult){
						if(aResult.status != 1){
							UBox.show(aResult.msg, aResult.status);
							return false;
						}

						ES.drawMathExpression($('.J-analysis-' + aConfig.id).text(str));
						$('#esItem' + aConfig.id).data('analysis', str);
						UBox.show('解题思路更新成功!', 1);
						if(typeof(callbackFun) === 'function'){
							return callbackFun();
						}
					}
				});
			};

		$.layer({
			type: 1,
			title: '修改解题思路',
			shade: [0.8, '#000'],
			area: ['600px', '360px'],
			btns: 1,
			page: {html: '<style>.dialogEditorEsAnalysis textarea{width: 588px;height: 260px;}</style><div id="dialogEditorEsAnalysis" class="dialogEditorEsAnalysis"><textarea xid="esAnalysis">' + content + '</textarea></div>'},
			btn: ['确定'],
			zIndex: 9888,
			yes: function(index){
				var esAnalysis = $.trim($('#dialogEditorEsAnalysis [xid="esAnalysis"]').val());
				if(!esAnalysis){
					alert('请填写解题思路');
					return false;
				}
				if(content != esAnalysis) postAnalysis(esAnalysis);
				layer.close(index);
			}
		});

		if(subject == 1 || subject == 2){
			if(typeof(CharInputer) == 'undefined'){
				$.error('在解题思路插件使用时没有引用符号输入插件!');
				return;
			}
			var tool;
			if(subject == 1){
				tool = '语文插件';
			}else if(subject == 2){
				tool = '数学插件';
			}
			$('.xubox_botton').append('<a onclick="CharInputer.show();" class="xubox_no xubox_botton3" style="left: 60%;">' + tool + '</a>');

			$('#dialogEditorEsAnalysis').on('click', '[xid="esAnalysis"]', function(){
				lastActiveObject = this;
			});
			CharInputer.init({subject : subject, isOverlay:false});
		}
	};
})(jQuery, window);