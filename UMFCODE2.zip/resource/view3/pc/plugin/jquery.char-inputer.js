(function(){
	window.CharInputer = {
		aOption : {
			title : ''
			,width : 0
			,height : 0
			,confirmCallBack : null
			,subject : 1
			,isOverlay : true
			,closeOnMouseout : true
		},

		dialogIndex : null,

		/**
		 * 初始化
		 */
		init : function(aOption){
			$.extend(self.aOption, aOption);
			if(self.aOption.subject == 1){
				self.aOption.title = '音标输入器';
				self.aOption.width = 300;
				self.aOption.height = 150;
			}else if(self.aOption.subject == 2){
				self.aOption.title = '数学符号输入器';
				self.aOption.width = 330;
				self.aOption.height = 200;
			}

			if(!_isInjectedCss){
				_initStyle();
				_isInjectedCss = true;
			}
		},

		/**
		 * 显示插件
		 */
		show : function(aExtendOption){
			if(aExtendOption){
				$.extend(self.aOption, aExtendOption);
			}
			var showContentHTML = self.buildSelectorHTML();

			var aOption = {
				type : 1,
				area : [self.aOption.width + 'px', self.aOption.height + 'px'],
				title : self.aOption.title,
				shadeClose : true,
				content : showContentHTML
			};

			if(self.aOption.isOverlay === false){
				aOption.shade = 0;
			}
			if(self.aOption.followElement && self.aOption.followElement.length){
				aOption.follow = self.aOption.followElement[0];
				aOption.followX = self.aOption.followOffsetX;
				aOption.followY = self.aOption.followOffsetY;
			}

			if(!aOption.success){
				aOption.success  = function(layero, index){
					if(!layero.addClass){
						layero = $(layero);
					}
					layero.addClass('display-container');
					$('#layui-layer-shade' + index + ', #layermbox' + index).addClass('display-container');
				}
			}

			self.dialogIndex = layer.open(aOption);

			var $oWrapCharInputer = $('#wrapCharInputer');
			$oWrapCharInputer.on('click', '.J-charItem', function(){
				var char = this.innerHTML,
					isCloseDialog = false;
				if(self.aOption.confirmCallBack != undefined){
					isCloseDialog = self.aOption.confirmCallBack(char);
				}else{
					isCloseDialog = _confirmCallBack(char);
				}
				isCloseDialog && layer.close(self.dialogIndex);
			});
		},

		/**
		 * 构建插件视图
		 */
		buildSelectorHTML : function(){
			var aCharGroupList = [];
			if(self.aOption.subject == 1){
				aCharGroupList = [
					['ā', 'á', 'ǎ', 'à', 'ō', 'ó', 'ǒ', 'ò'],
					['ē', 'é', 'ě', 'è', 'ī', 'í', 'ǐ', 'ì'],
					['ū', 'ú', 'ǔ', 'ù', 'ü', 'ǖ', 'ǘ', 'ǚ', 'ǜ']
				];
			}else if(self.aOption.subject == 2){
				aCharGroupList = [
					['+', '-', '×', '÷', '±', '≠', '＜', '＞', '≤', '≥', '≌', '≈', '°', '∽', '′', '″', '℃', '%', '•', 'π', 'α', 'β', 'γ', 'Ω', '⊥', '∥', '∠', '⊙', '⊕', '⊗', '△', '□', '▱', '√', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩']
				];
			}

			var contentHtml = '';
			for(var i in aCharGroupList){
				var itemsHtml = '';
				for(var j in aCharGroupList[i]){
					itemsHtml += '<a class="charItem J-charItem" href="javascript:;">' + aCharGroupList[i][j] + '</a>';
				}
				contentHtml += '<p>' + itemsHtml + '</p>';
			}
			contentHtml = '<div id="wrapCharInputer">' + contentHtml + '</div>';
			return contentHtml;
		}
	};

	var self = window.CharInputer,
		_isInjectedCss = false;	//是否注入过CSS样式

	/**
	 * 初始化样式
	 */
	function _initStyle(){
		$('head').append('<style type="text/css">\
#wrapCharInputer{padding:0 15px;}\
#wrapCharInputer .charItem{display:inline-block; width:30px; font-size:16px !important; text-align:center; vertical-align:top;}\
#wrapCharInputer .charItem:hover{background:#2A7EA9; color:#FFF; text-decoration:none;}\
#wrapCharInputer p{max-width: 330px; line-height:30px; margin:0;}\
#wrapCharInputer input,#wrapCharInputer label{cursor:pointer;}\
#wrapCharInputer label{padding:0}\
</style>');
	}

	/**
	 * 默认的确定回调
	 */
	function _confirmCallBack(char){
		if(window.lastActiveObject === undefined || window.lastActiveObject == null){
			$.error('未设置 window.lastActiveObject 变量');
			return false;
		}
		var oInput = lastActiveObject;
		var lStr = oInput.value.slice(0, oInput.selectionStart),
		rStr = oInput.value.slice(oInput.selectionEnd, oInput.value.length);
		oInput.value = lStr + char + rStr;
		oInput.selectionStart = lStr.length + 1;
		oInput.selectionEnd = lStr.length + 1;
		oInput.focus();
		return true;
	}
})
(jQuery);