(function($, win){
var _scriptPath = App.url.resource + 'view3/mobile/plugin/ui1/';

win.Ui1 = {
	rootPath : _scriptPath,
	resourceUrl : App.url.resource,
	defaultImage: _scriptPath + 'img_error.png',
	defaultProfile : _scriptPath + 'head_error.png',

	/**
	 * 构建img标签
	 * @param  {[type]} real     图像实际地址
	 * @param  {[type]} src      图片默认地址（图片加载异常显示）
	 * @param  {[type]} aOptions 配置参数
	 * @return {[type]}          图片html
	 */
	buildImage : function(real, src, aOptions){
		if(src == undefined){
			src = self.defaultImage;
		}else if(real){
			var index = real.lastIndexOf('http://');
		    if(0 < index){    //额外资源路径
		        real = real.substr(index);
		    }else if(real == self.resourceUrl){ //空白资源
		        real = '';
		    }
		}

		var attrsHtml = '';	//属性
		aOptions = aOptions || {};
		aOptions.src = src;
		aOptions.real = real;
		for(var name in aOptions){
			attrsHtml += ' ' + name + '="' + aOptions[name] + '"';
		}
		return '<img ' + attrsHtml + ' onload="Ui1.loadImage(this)" />';
	},

	/**
	 * 构建头像
	 * @param {type} aStudentInfo
	 * @param {type} isJump
	 * @param {type} aOptions
	 * @returns {String}
	 */
	buildProfile : function(aStudentInfo, aOptions){
		var addClass = ' ';
		if(JsTools.isObject(aOptions) && typeof(aOptions.addClass) == 'string'){
			addClass += aOptions.addClass;
		}

		var profile = aStudentInfo.profile;
		if(typeof(profile) == 'string' && profile.lastIndexOf('http://') == -1 ){  //没有资源路径
		    profile = self.resourceUrl + profile;
		}

		var profileImage = self.buildImage(
				profile,	//实际头像
				self.defaultProfile,	//默认头像
				{class : 'avatar circle'}
			);	//头像图片
		return '<span class="profile' + addClass + '">' + profileImage + '</span>';
	},

	/**
	 * 构建用户名称
	 * @param {type} aStudentInfo
	 * @param {type} isJump
	 * @returns {String}
	 */
	buildVipName : function(aStudentInfo){
		return '<span class="vname vip' + aStudentInfo.vip + '-name">' + aStudentInfo.name + '</span>';
	},

	/**
	 * 构建会员图标
	 * @param {type} vipLevel
	 * @returns {String}
	 */
	buildVipIcon : function(vipLevel){
		return '<span class="icon-vip' + vipLevel + ' icon"></span>';
	},

	/**
	 * 加载img，如果加载成功则把示例替换成实际图片（real替换src）
	 * @param {type} self
	 */
	loadImage : function (self){
	    var $self = $(self);
	    var real = $self.attr('real');
	    //图片地址异常的情况不请求
	    if(!real || real.substr(-1) == '/'){
	        return;
	    }
	    var image = new Image();
	    image.src = real;
	    image.onload = function(){
	        $self.attr('src', real);
	    };
	},

	/**
	 * 构建活动转盘
	 * @param {type} option
	 * @returns {Object}
	 */
	buildTrochalDisk: function (option){
	    if(option.num == undefined){
	        $.error('buildTrochalDisk::请输入最小转动圈数');
	    }else if(option.requestUrl == undefined){
	        $.error('buildTrochalDisk::请输入请求地址');
	    }else if(option.awardsUrl == undefined){
	        $.error('buildTrochalDisk::请输入轮盘图片地址');
	    }else if(option.count == undefined){
	        $.error('buildTrochalDisk::请输入抽奖次数');
	    }
	    var self = this;
	    self.url = option.requestUrl;
	    self.num = option.num;    //最少转动圈数，约等于秒，请求阶段1圈0.5秒，结果阶段1圈1秒（额外度数不计入）
	    self.imgWheel = option.awardsUrl;
	    self.count = option.count;	//抽奖次数
	    self.isActivityPlaying = option.isActivityPlaying;
	    self.times = 0;     //当前已经转动圈数
	    self.intervalHandle = 0;
	    self.reponse = '';  //请求结果
	    self.angle = 0;     //结果度数
	    self.imgStar = '/static/activity/trochal-disk/img/wheel-star.png';	//星星装饰
	    self.imgContent = '/static/activity/trochal-disk/img/wheel-content.png';	//轮盘外圈
	    self.imgCursor = '/static/activity/trochal-disk/img/wheel-cursor.png';	//轮盘指针
	    self.imgButton = '/static/activity/trochal-disk/img/wheel-button.png';	//轮盘按钮
	    self.eventStart = 'eventTrochalDiskStart';
	    self.eventEnd = 'eventTrochalDiskEnd';
	    self.eventOver = 'eventTrochalDiskOver';
	    self.reponse = {};	//响应数据

	    //装饰星星
	    var $star = $('<img/>');
	    $star.css({
	        'position': 'absolute',
	        'top': 0,
	        'left': 0
	    });
	    $star.attr({
	       'src': self.imgStar,
	        'width': '105%'
	    });

	    //轮盘内圈
	    var $wheel = $('<img/>');
	    $wheel.attr({
	        'src': self.imgWheel,
	        'width': '100%'
	    });

	    //光标
	    var $cursor = $('<img/>');
	    $cursor.css({
	        'position': 'absolute',
	        'margin': 'auto',
	        'left': 0,
	        'right': 0,
	        'top': '-15px',
	        'width': '12%'
	    });
	    $cursor.attr({
	        'src': self.imgCursor
	    });

	    //轮盘按钮
	    var $button = $('<img/>');
	    $button.css({
	        'position': 'absolute',
	        'margin': 'auto',
	        'left': 0,
	        'right': 0,
	        'top': 0,
	        'bottom': 0,
	        'width': '22%',
	        '-webkit-tap-highlight-color': 'transparent',
	        'transition': 'transform .3s linear',
	        '-webkit-transition': '-webkit-transform .3s linear'
	    });
	    $button.attr({
	        'src': self.imgButton
	    });
	    $button.click(function(){
	        if(0 < self.times){
	            return;
	        }

	        if(self.isActivityPlaying == 0){//活动结束
	        	$wheelCtn.trigger(self.eventOver, {status: 0});
	        	return;
	        }else if(self.count <= 0){//次数用尽
	        	$wheelCtn.trigger(self.eventEnd, {status: 0});
	        	return;
	        }else{
	        	self.count -= 1;
	        	$wheelCtn.trigger(self.eventStart, self.count);
	        }

	        //隐藏按钮
	        $button.css('display', 'none');

	        //滚轮动画
	        $wheel.css({
	            'transition': 'transform .5s linear',
	            '-webkit-transition': '-webkit-transform .5s linear'
	        });

	        //轮盘转动
	        _trochalAction({extra: 0, times: 1});
	        clearInterval(self.intervalHandle);
	        self.intervalHandle = setInterval(_runTrochalDisk , 500);
	        
	        ajax({
	        	url: self.url,
	        	success: function(res){
	        		var data = res['data'];
	        		if(res.status == 1){
	        			self.reponse = res;
	        			self.angle = data.degree;
	        		}else{
	        			//异常情况提前中断
	        			self.intervalHandle = clearInterval(self.intervalHandle);
	        			$wheelCtn.trigger(self.eventEnd, {status: 0});
	        		}
	        	}
	        });
	    });
	    _buttonThrob();

	    //轮盘外圈
	    var $wheelCtn = $('<div></div>');
	    $wheelCtn.css({
	        'position': 'relative',
	        'box-sizing': 'border-box',
	        '-webkit-box-sizing': 'border-box',
	        'width': '100%',
	        'padding': '6%',
	        'font-size': 0,
	        'background': 'url(' + self.imgContent + ') center no-repeat',
	        'background-size': '100%'
	    });
	    $wheelCtn.append($star);
	    $wheelCtn.append($wheel);
	    $wheelCtn.append($cursor);
	    $wheelCtn.append($button);
	    $wheelCtn.EVENT_START = self.eventStart;
	    $wheelCtn.EVENT_END = self.eventEnd;
	    $wheelCtn.EVENT_OVER = self.eventOver;

	    function _runTrochalDisk(){
	        var angle = $wheel.data('angle');
	        if(self.angle != 0){
	            var times = self.times < self.num? self.num - self.times: 1;
	            self.intervalHandle = clearInterval(self.intervalHandle);
	            $wheel.css({
	                'transition': 'transform ' + times + 's cubic-bezier(0, 0, 0, 1)',
	                '-webkit-transition': '-webkit-transform ' + times + 's cubic-bezier(0, 0.5, 0, 1)'
	            });
	            _trochalAction({extra: 360 - self.angle, times: times});
	            setTimeout(_stopTrochalDisk, times * 1000);
	        }else{
	            _trochalAction({extra: 0, times: 1});
	        }
	    }

	    function _stopTrochalDisk(){
	        self.times = 0;   //reset begin status
	        $button.css('display', 'block');
	        $wheelCtn.trigger(self.eventEnd, self.reponse);

	        _buttonThrob();	//重置按钮动画
	    }

	    function _trochalAction(parameters){
	        var extra = parameters.extra;
	        var times = parameters.times;
	        var prevAngle = $wheel.data('angle') || 0;
	        var angle = extra + prevAngle - prevAngle % 360 + 360 * times;
	        $wheel.data('angle', angle);
	        $wheel.css({
	            'transform': 'rotate(' + angle + 'deg)',
	            '-webkit-transform': 'rotate(' + angle + 'deg)'
	        });
	        self.times += 1;
	    }

	    function _buttonThrob(){
	        self.intervalHandle = setInterval(_buttonAction, 300);
	    }

	    function _buttonAction(){
	        var isScale = $button.data('scale');
	        if(isScale){
	            $button.css({
	                'transform': 'scale(1.0)',
	                '-webkit-transform': 'scale(1.0)'
	            });
	        }else{
	            $button.css({
	                'transform': 'scale(0.9)',
	                '-webkit-transform': 'scale(0.9)'
	            });
	        }
	        $button.data('scale', !isScale);
	    }

	    return $wheelCtn;
	},
	/**
	 * 滚动加载组件
	 * @return {[type]} [description]
	 *
	 * var $module = Ui1.buildScrollLoadModule();
	 * $module.bind($module.EVENT_BOTTOM, function(){});	//滚动底触发事件
	 * $module.appendTo($root);		//添加到根节点
	 * $module.addChild($child);	//添加子节点
	 */
	buildScrollLoadModule: function(){
	    var $inner = $('<div class="J-module-scroll-inner"></div>');
	    var $outer = $('<div class="J-module-scroll-outer"></div>');
	    $outer.EVENT_BOTTOM = 'event_bottom';
	    $outer.data('event', $outer.EVENT_BOTTOM);
	    $outer.css({
	        'overflow-x': 'hidden',
	        'overflow-y': 'scroll'
	    });
	    $outer.append($inner);
	    $outer.addChild = function(child){
	    	$inner.append(child);
	    }
	    $outer.scrollTop = function(){
	    	$outer[0].scrollTop = 0;
	    };

	    $outer.bind('scroll', function(evt){
	        var curTarget = evt.currentTarget;
	        var scrollTop = curTarget.scrollTop;
	        var innerHeight = curTarget.scrollHeight;
	        var outerHeight = curTarget.clientHeight;

	        if(innerHeight == outerHeight + scrollTop){  //上拉触发加载
	            $outer.trigger($outer.EVENT_BOTTOM);
	        }
	    });
	    return $outer;
	},

	/**
	 * 翻页组件，有页码标识
	 * @return {[type]} [description]
	 *
	 * var $module = Ui1.buildScrollPageModule();
	 * var $container = $module.getContainer();	//获取内部容器
	 * $container.html(cartoonHtml);
	 * $container.css('width', '123px');
	 * $module.updateNum();		//更新页面标识（容器添加子节点之后）
	 *
	 * @param {boolean} isInnerNum 是否内嵌页码
	 */
	buildScrollPageModule: function(isInnerNum){
		var eventName = 'play';
		var lightColor = isInnerNum ? '#3285CB' : '#4d4d4d';
		var darkColor = isInnerNum ? '#fff' : '#ccc';
	    var $inner = $('<div class="J-module-scroll-inner" data-event-name="' + eventName + '"></div>');
	    $inner.bind('touchstart', function(evt){
	    	// evt.preventDefault();
	        var $curTarget = $(evt.currentTarget);
	        var event = evt.originalEvent;
	        var startX = event['targetTouches'][0].pageX;
	        var marginL = $curTarget.css('margin-left');
	        $curTarget.data('startX', startX);
	        $curTarget.data('marginL', marginL);
	        $curTarget.css({
	            'transition': 'margin-left 0s',
	            '-webkit-transition': 'margin-left 0s'
	        });
	    }).bind('touchmove', function(evt){
	    	evt.preventDefault();
	        var $curTarget = $(evt.currentTarget);
	        var event = evt.originalEvent;
	        var startX = $curTarget.data('startX');
	        var marginL = $curTarget.data('marginL');
	        var innerW = $curTarget.css('width');    //内容器宽
	        var outerW = $curTarget.parent().css('width');
	        var curX = event['targetTouches'][0].pageX;
	        var moveX = curX - startX;
	        var distance = parseInt(marginL) + parseInt(moveX);
	        if(parseInt(outerW)/2 < distance || distance < parseInt(outerW) - parseInt(innerW) - parseInt(outerW)/2){   //越界
	            return;
	        }
	        $curTarget.css('margin-left', distance + 'px');
	    }).bind('touchend', function(evt){
	    	evt.preventDefault();
	        var $curTarget = $(evt.currentTarget);
	        var startX = $curTarget.data('startX');
	        var event = evt.originalEvent;
	        var curX = event['changedTouches'][0].pageX;
	        $curTarget.removeData('startX');
	        $curTarget.removeData('marginL');

	        if(Math.abs(curX - startX) < 5){
	            return;
	        }

	        //moving transition
	        var curIndex = 0;
	        var marginL = $curTarget.css('margin-left');
	        var innerW = $curTarget.css('width');    //内容器宽
	        var outerW = $curTarget.parent().css('width');
	        marginL = parseInt(marginL);
	        innerW = parseInt(innerW);
	        outerW = parseInt(outerW);

	        //增加滑动距离
	        var distance = curX - startX;
	        if(distance < 0){  //scroll left
	            marginL -= outerW / 2;
	        }else{
	            marginL += outerW / 2;
	        }

	        //边界判断
	        if(0 < marginL){
	            curIndex = 0;
	        }else if(marginL + innerW < outerW){
	            curIndex = innerW / outerW - 1;
	        }else{
	            marginL = Math.abs(marginL);
	            curIndex = parseFloat(marginL / outerW).toFixed(0);
	        }

	        $curTarget.css({
	            'margin-left': -1 * curIndex * outerW + 'px',
	            'transition': 'margin-left .5s',
	            '-webkit-transition': 'margin-left .5s'
	        });

	        //更改页面标记
	        var $page = $curTarget.parents('.J-module-scroll-page');
	        $page.find('.J-module-scroll-num > span').css('border-color', darkColor);
	        $page.find('.J-module-scroll-num > span').eq(curIndex).css('border-color', lightColor);
	    }).bind(eventName, function(evt){
	    	$curTarget = $(this);
	    	var marginL = $curTarget.css('margin-left');
	    	var innerW = $curTarget.css('width');    //内容器宽
	    	var outerW = $curTarget.parent().css('width');

	    	marginL = parseInt(marginL);
	    	innerW = parseInt(innerW);
	    	outerW = parseInt(outerW);

	    	if(outerW < innerW + marginL){
	    	    curIndex = Math.abs(marginL) / outerW + 1;
	    	    $curTarget.css('margin-left', marginL - outerW + 'px');
	    	}else{
	    	    curIndex = 0;
	    	    $curTarget.css('margin-left', '0px');
	    	}
	    	$curTarget.css({'transition': 'margin-left .5s', '-webkit-transition': 'margin-left .5s'});

	    	//更改页面标记
	    	var $page = $curTarget.parents('.J-module-scroll-page');
	    	$page.find('.J-module-scroll-num > span').css('border-color', darkColor);
	    	$page.find('.J-module-scroll-num > span').eq(curIndex).css('border-color', lightColor);
	    });

	    var $pageNum = $('<div class="J-module-scroll-num"></div>');
	    $pageNum.css({
	        'text-align': 'center',
	        'height': '24px',
	        'line-height': '24px'
	    });
	    //内嵌页码修改
	    if(isInnerNum){
	    	$pageNum.css('margin-top', '-24px');
	    }
	    var $outer = $('<div class="J-module-scroll-page"></div>');
	    $outer.append($inner);
	    $outer.append($pageNum);
	    $outer.css({
	        'overflow-x': 'hidden'
	    });
	    $outer.getContainer = function(){
	        return $inner;
	    };
	    $outer.updateNum = function(){
	        var innerW = $inner.css('width');    //内容器宽
	        var marginL = $inner.css('margin-left');
	        var outerW = $outer.css('width');
	        var totalPage = Math.ceil(parseInt(innerW) / parseInt(outerW));
	        var $span = null;
	        var spanHtml = '';
	        for(var i = 0; i < totalPage; ++i){
	            spanHtml += '<span style="display: inline-block; border: 6px solid black; border-radius: 6px; margin: 6px 2px; vertical-align: top;"></span>';
	        }
	        $pageNum.html(spanHtml);
	        $span = $pageNum.find('span');      //update

	        marginL = parseInt(marginL || 0);
	        outerW = parseInt(outerW);
	        marginL = Math.abs(marginL);
	        var curIndex = parseFloat(marginL / outerW).toFixed(0);
	        $span.css('border-color', darkColor);
	        $span.eq(curIndex).css('border-color', lightColor);
	    };
	    return $outer;
	},

	/**
	 * 将一个过去的时间戳转换成"XXX前"的文字
	 * @param int timeStamp 小于当前时间的过去的时间戳,单位:秒
	 * @returns string
	 */
	timeToAgo : function(timeStamp){
		var seconds = Math.floor(($.now()) / 1000) - timeStamp;
		if(seconds < 1) {
			return '刚刚';
		}
		if(seconds >= 1 && seconds < 60){
			return parseInt(seconds) + '秒前';
		}else if (seconds >= 60 && seconds < 3600){
			var minutes = Math.floor(seconds / 60);
			return minutes + '分钟前';
		}else if (seconds >= 3600 && seconds < 86400){
			var hour = Math.floor(seconds / 3600);
			return hour + '小时前';
		}else if (seconds >= 86400 && seconds < 172800){
			return '昨天';
		}else if (seconds >= 172800 && seconds < 259200){
			return '前天';
		}else{
			var manyDay = Math.floor(seconds / 86400);
			if(isNaN(manyDay)){
				return '未知';
			}

			if(manyDay < 30){
				return manyDay + '天前';
			}else if(manyDay > 30 && manyDay < 180){
				return Math.floor(manyDay / 30) + '个月前';
			}else if(manyDay > 180 && manyDay < 365){
				return '半年前';
			}

			return '很久以前';
		}
	},

	date : function(format, timestamp, isLocalTime){
		if(isLocalTime == undefined){
			isLocalTime = true;
		}

		if(!isLocalTime){
			var oLocalDate = new Date();
			timestamp = timestamp - Math.abs(oLocalDate.getTimezoneOffset()) * 60;
		}

		var jsdate = new Date(timestamp * 1000);


		//补零
		var pad = function(data, len){
			if((data += '').length < len){
				//计算要补多少个零
				len = len - data.length;
				var str =  '0000';
				return data = str.substr(0, len) + data;
			}else{
				return data;
			}
		};
		var weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

		//计算一年中的第几天
		var inYearDay = function(){
			var aDay = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
			var day = jsdate.getDate();
			var month = jsdate.getMonth();
			var year = jsdate.getFullYear();
			var $reDay = 0;
			for(var i = 0; i < month; i++){
				$reDay += aDay[i];
			}
			$reDay += day;
			//计算闰年
			if(month > 1 && (year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
				$reDay += 1;
			}
			return $reDay;
		};

		var fm = {
			//天
			j : function(){return jsdate.getDate();},
			d : function(){return pad(fm.j(), 2);},
			w : function(){return jsdate.getDay();},
			l : function(){return weekdays[fm.w()];},
			D: function(){return fm.l().substr(0,3);},
			N : function(){return fm.w() + 1;},
			z : function(){return inYearDay();},

			//月
			n : function(){return jsdate.getMonth() + 1;},
			m : function(){return pad(fm.n(), 2);},
			t : function(){
				var n;
				if( (n = jsdate.getMonth() + 1) == 2 ){
					return 28 + fm.L();
				} else{
					if( n & 1 && n < 8 || !(n & 1) && n > 7 ){
						return 31;
					} else{
						return 30;
					}
				}
			},

			//年
			Y : function(){return jsdate.getFullYear();},
			y : function(){return (jsdate.getFullYear() + "").slice(2);},
			L : function(){var y = fm.Y();return (!(y & 3) && (y % 1e2 || !(y % 4e2))) ? 1 : 0;},

			//秒
			s : function(){return pad(jsdate.getSeconds(), 2);},

			//分
			i : function(){return pad(jsdate.getMinutes(), 2);},

			//时
			H : function(){return pad(jsdate.getHours(), 2);},
			g : function(){return jsdate.getHours() % 12 || 12;},

			//am或pm
			a : function(){return jsdate.getHours() > 11 ? 'pm' : 'am';},

			//AM或PM
			A : function(){return fm.a().toUpperCase();},

			//周
			W : function(){
				var a = fm.z(), b = 364 + fm.L() - a;
				var nd2, nd = (new Date(jsdate.getFullYear() + '/1/1').getDay() || 7) - 1;
				if(b <= 2 && ((jsdate.getDay() || 7) - 1) <= 2 - b){
					return 1;
				} else{
					if(a <= 2 && nd >= 4 && a >= (6 - nd)){
						nd2 = new Date(jsdate.getFullYear() - 1 + '/12/31');
						return self.date("W", Math.round(nd2.getTime()/1000));
					} else{
						return (1 + (nd <= 3 ? ((a + nd) / 7) : (a - (7 - nd)) / 7) >> 0);
					}
				}
			}

		};

		//分析format
		return format.replace(/[\\]?([a-zA-Z])/g, function(rekey1, rekey2){
			var result = '';
			if(rekey1 != rekey2){
				result = rekey2;
			}else if(fm[rekey2]){
				result = fm[rekey2]();
			}else{
				result = rekey2;
			}
			return result;
		});
	},

	/**
	 * 将一个秒数转换成时分秒表达式
	 * @param int seconds
	 * @returns {String}
	 */
	timeToFormatStr : function(seconds){
		seconds = parseInt(seconds);
		var hourse = Math.floor(seconds / 3600),
		minute = Math.floor((seconds - hourse * 3600) / 60),
		second = seconds - hourse * 3600 - minute * 60;

		if(hourse < 10){
			hourse = '0' + hourse;
		}
		if(minute < 10){
			minute = '0' + minute;
		}
		if(second < 10){
			second = '0' + second;
		}
		return hourse + ':' + minute + ':' + second;
	},

	/**
	 * 将一个时间戳转换成星座名称并返回
	 * @author zhou
	 * @return {mixed} 成功返回星座名，失败返回false
	 */
	timeToConstellation : function(timeStamp){
		timeStamp = parseInt(timeStamp * 1000);
		if(timeStamp === NaN){
			return false;
		}

		var oDate = new Date(timeStamp);
		var month = oDate.getUTCMonth() + 1;
		var day = oDate.getUTCDate();

		var _getAstro = function(month, day){
			var s = '魔羯水瓶双鱼牡羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯';
			var arr = [20,19,21,21,21,22,23,23,23,23,22,22];
			return s.substr(month * 2 - (day < arr[month - 1] ? 2 : 0), 2) + '座';
		};

		return _getAstro(month, day);
	}

};

var self = win.Ui1;
})($, window);