/**
 * 移动触摸方法
 * click和touch同时存在时，click后触发会被touch阻断（不阻断因为触发click在mobile端会卡帧）
 * 所以提供tap方法修复该问题
 */
(function($){
	$.fn.tap = function(fn){
		var $self = $(this);
		$self.bind('touchstart', function(evt){
			var $curTarget = $(evt.currentTarget);
			var event = evt.originalEvent;
			var startX = event['targetTouches'][0].pageX;
			var startY = event['targetTouches'][0].pageY;
			$curTarget.data({
				'startX': startX,
				'startY': startY
			});
		}).bind('touchend', function(evt){
			var curTarget = evt.currentTarget;
			var $curTarget = $(curTarget);
			var event = evt.originalEvent;
			var startX = $curTarget.data('startX');
			var startY = $curTarget.data('startY');
			var endX = event['changedTouches'][0].pageX;
			var endY = event['changedTouches'][0].pageY;
			if(Math.abs(startX - endX) + Math.abs(startY - endY) < 20){
				fn.apply(curTarget);
			}
		})
	};
})(jQuery);