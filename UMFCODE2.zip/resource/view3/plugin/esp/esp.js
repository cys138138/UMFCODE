(function($, window){
window.Esp = {
	oLastQuestion : null,

	type : {
		SINGLE_CHOICE : [1],
		MULTIPLE_CHOICE : [2],
		JUDGMENT : [3],
		FILL_BLANK : [4, 5],
		COMPLEX : [6, 7]
	}

	,isSingleChoice : function(type){
		return jsTools.inArray(type, this.type.SINGLE_CHOICE);
	}
	,isMultipleChoice : function(type){
		return jsTools.inArray(type, this.type.MULTIPLE_CHOICE);
	}
	,isJudgment : function(type){
		return jsTools.inArray(type, this.type.JUDGMENT);
	}
	,isFillBlank : function(type){
		return jsTools.inArray(type, this.type.FILL_BLANK);
	}
	,isComplex : function(type){
		return jsTools.inArray(type, this.type.COMPLEX);
	}

	/**
	 * 设置配置参数
	 */
	,config : function(aOptions){
		if(!jsTools.isObject(aOptions)){
			$.error('非法的设置');
		}
		for(var key in aOptions){
			if(_aConfig[key] !== undefined){
				_aConfig[key] = aOptions[key];
			}
		}

		if(!_isInit){
			_isInit = true;
		}

		//如果图片基础地址不是以 / 号结束的话就补上
		if(_aConfig.imageBaseUrl.length && _aConfig.imageBaseUrl.substr('-1') != '/'){
			_aConfig.imageBaseUrl += '/';
		}
	}

	/**
	 * 构造题目问题对象
	 * @param {type} aEs
	 * @returns {unresolved}
	 */
	,buildQuestion : function(aEs, isPreviewMode){
		if(isPreviewMode == undefined){
			isPreviewMode = false;
		}
		
		var $question = null,
			allowRemoveOption = false;	//这条题目是否允许移除选项,选择题才可以的
		if(self.isSingleChoice(aEs.type_id)){
			$question = self.buildSingleChoiceQuestion(aEs);
			allowRemoveOption = true;
		}else if(self.isMultipleChoice(aEs.type_id)){
			$question = self.buildMultipleChoiceQuestion(aEs);
			allowRemoveOption = true;
		}else if(self.isJudgment(aEs.type_id)){
			$question = self.buildJudgmentQuestion(aEs);
		}else if(self.isFillBlank(aEs.type_id)){
			$question = self.buildFillBlankQuestion(aEs);
		}else if(self.isComplex(aEs.type_id)){
			$question = self.buildComplexQuestion(aEs);
		}

		$question.isPreviewMode = isPreviewMode;

		if($question.allowRemoveOption == undefined){
			//这样判断是因为复合题已经在内部设定了 allowRemoveOption
			$question.allowRemoveOption = allowRemoveOption;
		}

		//题目返回选项正文
		if(!self.isSingleChoice(aEs.type_id)){
			$question.buildAnswerContent = $question.buildAnswerText;
		}

		if(aEs.subject_id == 2 || !aEs.subject_id){
			self.drawMathExpression($question);	//绘制数学公式
		}
		self.oLastQuestion = $question;

		$question.addClass('subject' + aEs.subject_id);

		return $question;
	}


	/**
	 * 绘制数学公式
	 */
	,drawMathExpression : function($oDom){
		if(window.MathJax){
			MathJax.Hub.Queue(['Typeset', MathJax.Hub, $oDom[0]]);
		}else{
			$.error('没有MathJax插件,无法渲染数学公式');
		}
	}

	/**
	 * 构建单选题题目问题对象
	 * @param aEs
	 */
	,buildSingleChoiceQuestion : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		//组装选项
		var aOptionsHtmlList = [], optionsHtml = '';
		for(var i = 0; i < aEs.es_content.option.length; i++){
			var aOption = aEs.es_content.option[i]
			,optionImageHtml = _buildImageListHtml(aOption.image, true);

			aOptionsHtmlList.push('<div class="esp_option_item J-esOptionItem" xid="esp_option_item">\
				<div class="esp_option_item_control"><input class="J-answerControl" name="esAnswer' + aEs.id + '" type="radio" value="' + i + '" /></div>\
				<div class="esp_option_item_index J-esOptionIndex" data-index="__optionIndex__">__optionIndex__</div>\
				<div class="esp_option_item_content J-esOptionContent">\
					<div class="esp_option_item_content_text">' + _buildHtmlContent(aOption.content) + '</div>\n\
					' + optionImageHtml + '\
				</div>\
			</div>');
		}

		//打乱答案选项的顺序
		if(_aConfig.shuffleChoise){
			var aOptionsHtmlList2 = jsTools.shuffle(aOptionsHtmlList)
			,aOptionsRelation = _getArrayRelation(aOptionsHtmlList, aOptionsHtmlList2);
			aEs.options_relation = aOptionsRelation;
			aOptionsHtmlList = aOptionsHtmlList2;
		}
		for(var i=0; i<aOptionsHtmlList.length; ++i){
			optionsHtml += aOptionsHtmlList[i].replace(/__optionIndex__/g, String.fromCharCode(65 + parseInt(i)));
		}

		//整体组装
		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		var $question = $('<div class="esp" id="question' + aEs.id + '" xid="wrapEsQuestion" data-type="' + aEs.type_id + '">\
			<div class="esp_main">\
				<div class="esp_main_text">' + htmlContent + '</div>\
				' + contentImageHtml + '\
			</div>\
			<div class="esp_option">' + optionsHtml + '</div>\
		</div>').data('es', jsTools.clone(aEs));

		$question.type = aEs.type_id;

		//选项点击交互
		$question.on('click', ':radio,[xid="esp_option_item"]', function(){
			if($question.isPreviewMode){
				return false;
			}

			var $this = $(this);
			if($(this).is(':radio')){
				var $optionItem = $this.closest('div[xid="esp_option_item"]');
			}else{
				var $optionItem = $this;
				$optionItem.find(':radio')[0].checked = true;
			}

			$optionItem.addClass('on').siblings().removeClass('on');	//高亮自己,"低亮他人"
		});

		/**
		 * 移除选项
		 * @param {type} index 选项的序号
		 */
		$question.removeOption = function(index){
			$(this).find('[xid="esp_option_item"]:eq(' + index + ')').slideUp(function(){
				$(this).remove();
			});
		};

		/**
		 * 获取选项数量
		 * @returns 选项数量
		 */
		$question.getOptionNums = function(){
			return $(this).find('[xid="esp_option_item"]').length;
		};

		/**
		 * 填写答案
		 */
		$question.writeAnswer = function(answerIndex){
			var $radio = $(this).find(':radio[value="' + answerIndex + '"]');
			$radio[0].checked = true;
			$radio.closest('div[xid="esp_option_item"]').addClass('on').siblings().removeClass('on');
		};

		/**
		 * 构建答案
		 */
		$question.buildAnswer = function(){
			var oCheckedDom = $(this).find(':radio:checked');
			return oCheckedDom.length ? oCheckedDom.val() : undefined;
		};

		$question.buildAnswerText = function(answer){
			var $optionItem = $(this).find('.J-answerControl[value="' + answer + '"]').closest('.J-esOptionItem');
			return $optionItem.find('.J-esOptionIndex').data('index');
		};

		$question.buildAnswerContent = function(answer){
			var $optionItem = $(this).find('.J-answerControl[value="' + answer + '"]').closest('.J-esOptionItem');
			return $optionItem.find('.J-esOptionContent').html();
		};

		$question.isEmptyAnswer = function(answerIndex){
			if(!/^\d+$/.test(answerIndex)){
				return true;
			}
			return false;
		};

		return $question;
	}

	,buildSingleChoiceDetail : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		//组装选项
		var aOptionsHtmlList = [];
		$(aEs.es_content.option).each(function(i){
			var optionImageHtml = _buildImageListHtml(this.image);

			var answerHtml = '';
			if(i == aEs.es_content.answer){
				answerHtml = '<span class="correct"><i title="正确答案">&radic;</i></span>';
			}
			aOptionsHtmlList.push('<div class="esOption c">\
				<label for="esAnswer' + aEs.id + i + '">\
					<div class="control">\
						' + answerHtml + '<span class="optionIndex">' + (String.fromCharCode(65 + parseInt(i))) + '. </span>\
					</div>\
					<div class="txt"><span style="position:relative; left:-999em; margin-left:-20px;">1</span>' + _buildHtmlContent(this.content) + '</div>\
					<div class="images">' + optionImageHtml + '<br class="both" /></div>\
				</label>\
			</div>');
		});

		//整体组装
		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		var $oDetail = $('<div class="wrapEs wrapEsDetail choose topic" xid="wrapEsDetail">\
			<div class="esContent">\
				<div class="txt" xid="wrapEsContent">' + htmlContent + '</div>\
				<div class="images">' + contentImageHtml + '<br class="both" /></div>\
			</div>\
			<div class="esOptions">' + aOptionsHtmlList.join('') + '</div>\
		</div>');

		return $oDetail;
	},

	//单选题表单
	buildSingleChoiceForm : function(aEs){
		var aEsContent = aEs.es_content,
		contentImageHtml = '',
		optionsHtml = ''
		,optionAddCount = 0;

		/**
		 * 构建单选题选项HTML
		 * @param {type} content 选项内容
		 * @param {type} optionIndex 选项序号
		 * @param {type} uniqueId 唯一ID
		 * @param {type} isShowAnimation 是否以动画形式展示出来
		 * @returns {String} 选项HTML
		 */
		function __buildOptionHtml(aOption, isAnswer, optionIndex, uniqueId, nameId, isShowAnimation){
			var hiddenStyle = isShowAnimation ? ' style="display:none;"' : '',
			optionImagesHtml = '';
			optionIndex = parseInt(optionIndex);

			if($.type(aOption.image) == 'array'){
				for(var i in aOption.image){
					optionImagesHtml += _buildImageItemHtml(aOption.image[i], i);
				}
			}


			var _html = '<div xid="option" class="optionItem"' + hiddenStyle + '>\
				<div class="itemHead">\
				<strong class="letter">' + String.fromCharCode(65 + optionIndex) + '</strong>\
					<label class="col-md-offset-9" for="isAnswer' + uniqueId + '" xid="setAnswer" class="setAnswer">\
					<input type="radio" class="answerCheckBox" xid="isAnswer" id="isAnswer' + uniqueId + '" name="answer' + nameId + '"' + (isAnswer ? ' checked="checked"' : '') + ' />\设为答案\
					</label>\
					<a xid="deleteOption" href="javascript:;" class="removeOption">删除</a>\
				</div>\
				<textarea xid="optionContent"  class="form-control" rows="3">' + aOption.content + '</textarea>\
				<div class="clear"></div>\
				<div xid="optionUpload" class="btnImageUpload">\
					<input type="file"  xid="btnImageUpload" />\
				</div>\
				<div  xid="wrapImages">' + optionImagesHtml + '</div>\
			</div>';
			return _html;
		}

		//组装题干图片
		aEsContent.answer = parseInt(aEsContent.answer);
		if(aEsContent.image != undefined && aEsContent.image.length){
			for(var i in aEsContent.image){
				contentImageHtml += _buildImageItemHtml(aEsContent.image[i], i);
			}
		}

		//组装选项
		for(var i in aEsContent.option){
			optionsHtml += __buildOptionHtml(aEsContent.option[i], (i == aEsContent.answer), i, aEs.id + '' + (++optionAddCount), aEs.id);
		}
		var oForm = $('<div  class="container-fluid form-upload" xid="wrapEs" itemid="' + aEs.id + '">\
			<div class="row">\
				<label class="col-md-1 text-right vignette">题干:</label>\
				<div class="col-md-6">\
						<textarea class="form-control" rows="5" xid="esContent">' + aEsContent.content + '</textarea>\
				</div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right drawing">附图:</label>\
				<div class="col-md-6">\
					<div xid="wrapImagesContent">' + contentImageHtml + '</div>\
					<div class="clear"></div>\
					<input class="btnUploadContentImage" type="file" xid="btnUploadContentImage" />\
					<div class="clear"></div>\
				</div>\
			</div>\
			<div class="row" style="margin-top:10px;">\
				<label class="col-md-1 text-center">选项: <a  href="javascript:;" xid="btnAddOption">添加</a></label>\
				<div class="col-md-6" xid="wrapOption">'  + optionsHtml +'</div>\
			</div>\
		</div>');


		oForm.data({
			es : jsTools.clone(aEs)
			,option_add_count : optionAddCount
		});

		/**
		 * 添加单选题选项
		 */
		oForm.find('a[xid="btnAddOption"]').click(function(){
			var optionAddCount = oForm.data('option_add_count');
			if(!optionAddCount){
				optionAddCount = 0;
			}
			var optionCount = oForm.find('[xid="option"]').length;
			var esId = oForm.data('es').id;
			var optionHtml = __buildOptionHtml({content : ''}, false, optionCount, esId + '' + (++optionAddCount), esId, true);

			var oLastOption = $(optionHtml).appendTo(oForm.find('[xid="wrapOption"]'));
			_buildUploadButton(oLastOption.find('[xid="btnImageUpload"]'), oLastOption.find('[xid="wrapImages"]'));
			oLastOption.slideDown('normal');

			oForm.data('option_add_count', optionAddCount);
		});

		/**
		 * 删除单选题选项
		 * @param {type} optionId
		 * @returns {Boolean}
		 */
		oForm.delegate('a[xid="deleteOption"]', 'click', _deleteChoiceOption);

		//初始化图片上传按钮
		_buildUploadButton(oForm.find('input[xid="btnUploadContentImage"]'), oForm.find('div[xid="wrapImagesContent"]'));
		oForm.find('[xid="option"]').each(function(){
			_buildUploadButton($(this).find('input[xid="btnImageUpload"]'), $(this).find('[xid="wrapImages"]'));
		});

		return oForm;
	},

	/**
	 * 构建单选题数据
	 * @param {type} oEs
	 * @returns {unresolved}
	 */
	buildSingleChoiseEsData : function(oEs){
		var aEs = oEs.data('es');
		aEs.es_content.content = oEs.find('textarea[xid="esContent"]').val();

		//收集题干图片
		var oContentImages = oEs.find('div[xid="wrapImagesContent"] [xid="imageItem"]');
		if(oContentImages.length){
			aEs.es_content.image = _buildImagesData(oContentImages);
		}else{
			aEs.es_content.image = undefined;
		}

		//收集题目选项
		aEs.es_content.option = [];
		oEs.find('[xid="option"]').each(function(){
			var aOption = {content : ''},
			oOption = $(this),
			oOptionImages = oOption.find('[xid="imageItem"]');

			//选项内容
			aOption.content = oOption.find('[xid="optionContent"]').val();

			//选项图片
			if(oOptionImages.length){
				aOption.image = _buildImagesData(oOptionImages);
			}

			aEs.es_content.option.push(aOption);
		});

		//收集正确答案
		oEs.find(':radio[xid="isAnswer"]').each(function(i){
			if(this.checked){
				aEs.es_content.answer = i;
				return false;
			}
		});
		return aEs;
	},

	/**
	 * 检查单选题数据是否可以提交
	 * @param {type} aEsContent
	 * @returns {Boolean}
	 */
	checkSingleChoiseEsData : function(aEsContent){
		if(!aEsContent.content && aEsContent.image === undefined){
			UBox.show('题干内容不能为空', -1);
			return false;
		}else if(/\\\[/.test(aEsContent.content)){
			if(!confirm('发现存在疑似非内联公式的符号，你真的选择了内联公式符号吗？ 确定继续保存吗？', -1)){
				return false;
			}
		}

		for(var i in aEsContent.option){
			i = parseInt(i);
			var optionId = i + 1;
			var oOption = aEsContent.option[i];
			if(!oOption.content && oOption.image === undefined){
				UBox.show('请填写第 ' + optionId + ' 个选项的内容或者上传图片', -1);
				return false;
			}
			if(/\\\[/.test(oOption.content)){
				if(!confirm('发现第' + (i + 1) + '个选项带有疑似非内联公式的符号，你确定选择了内联公式符号吗？确定继续保存吗？', -1)){
					return false;
				}
			}
		}

		if(isNaN(aEsContent.answer)){
			UBox.show('请选择一个正确答案', -1);
			return false;
		}

		return true;
	},

	//构建多选题题目问题对象
	buildMultipleChoiceQuestion : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		//组装选项
		var aOptionsHtmlList = [], optionsHtml = '';
		for(var i = 0; i < aEs.es_content.option.length; i++){
			var aOption = aEs.es_content.option[i]
			,optionImageHtml = _buildImageListHtml(aOption.image, true);

			aOptionsHtmlList.push('<div class="esp_option_item J-esOptionItem" xid="esp_option_item">\
				<div class="esp_option_item_control">\n\
					<input class="J-answerControl" name="b" type="checkbox" value="' + i + '" />\n\
				</div>\
				<div class="esp_option_item_index J-esOptionIndex" data-index="__optionIndex__">__optionIndex__</div>\
				<div class="esp_option_item_content">\
					<div class="esp_option_item_content_text">' + _buildHtmlContent(aOption.content) + '</div>\
					' + optionImageHtml + '\
				</div>\
			</div>');
		}

		//打乱答案选项的顺序
		if(_aConfig.shuffleChoise){
			var aOptionsHtmlList2 = jsTools.shuffle(aOptionsHtmlList)
			,aOptionsRelation = _getArrayRelation(aOptionsHtmlList, aOptionsHtmlList2);
			aEs.options_relation = aOptionsRelation;
			aOptionsHtmlList = aOptionsHtmlList2;
		}
		for(var i in aOptionsHtmlList){
			optionsHtml += aOptionsHtmlList[i].replace(/__optionIndex__/g, String.fromCharCode(65 + parseInt(i)));
		}
		//整体组装
		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		var $question = $('<div class="esp" id="question' + aEs.id + '" xid="wrapEsQuestion" data-type="' + aEs.type_id + '">\
			<div class="esp_main">\
				<div class="esp_main_text">' + htmlContent + '</div>\
				' + contentImageHtml + '\
			</div>\
		</div>\
		<div class="esp_option">' + optionsHtml + '</div>').data('es', jsTools.clone(aEs));

		$question.type = aEs.type_id;

		//选项点击交互
		$question.on('click', ':input,[xid="esp_option_item"]', function(oEvent){
			if($question.isPreviewMode){
				return false;
			}

			var $control = null,
				isStopEvent = false;	//是否停止事件向上冒泡
			if($(this).is(':input')){
				$control = this;
				var $optionItem = $(this).closest('div[xid="esp_option_item"]');
				isStopEvent = true;
			}else{
				var $optionItem = $(this);
				//如果点击外框,则改变内部控件的勾选状态
				var $control = $optionItem.find(':input')[0];
				$control.checked = !$control.checked;
			}

			//高亮切换
			if($control.checked){
				$optionItem.addClass('on');
			}else{
				$optionItem.removeClass('on');
			}

			isStopEvent && oEvent.stopPropagation();
		});

		/**
		 * 移除选项
		 * @param {type} aOptionIndex 选项的序号集合
		 */
		$question.removeOption = function(aOptionIndex){
			for(var i in aOptionIndex){
				$(this).find('[xid="esp_option_item"]:eq(' + aOptionIndex[i] + ')').slideUp(function(){
					$(this).remove();
				});
			}
		};

		/**
		 * 获取选项数量
		 * @returns 选项数量
		 */
		$question.getOptionNums = function(){
			return $(this).find('[xid="esp_option_item"]').length;
		};

		/**
		 * 填写答案
		 */
		$question.writeAnswer = function(aAnswerIndex){
			for(var i = 0, max = $question.getOptionNums(); i < max; i++){
				var checked = false;
				for(var j in aAnswerIndex){
					if(jsTools.inArray(i, aAnswerIndex)){
						checked = true;
						break;
					}
				}
				var $checkbox = $(this).find(':checkbox[value="' + i + '"]'),
				$optionItem = $checkbox.closest('div[xid="esp_option_item"]');
				$checkbox[0].checked = checked;
				if(checked){
					$optionItem.addClass('on');
				}else{
					$optionItem.removeClass('on');
				}
			}
		};

		/**
		 * 构建答案
		 */
		$question.buildAnswer = function(){
			var oCheckedDom = $(this).find(':checkbox:checked')
			,aAnswer = undefined;
			if(oCheckedDom.length > 0){
				aAnswer = [];
				oCheckedDom.each(function(){
					aAnswer.push(this.value);
				});
			}
			return aAnswer;
		};

		//获取正确答案
		$question.buildAnswerText = function(aAnswerIndexs){
			var aAnswerText = [];
			for (var index in aAnswerIndexs) {
				var $optionItem = $(this).find('.J-answerControl[value="' + aAnswerIndexs[index] + '"]').closest('.J-esOptionItem');
				aAnswerText.push($optionItem.find('.J-esOptionIndex').data('index'));
			}
			return aAnswerText.join('、');
		};

		/**
		 * 检查是否空答案
		 */
		$question.isEmptyAnswer = function(aAnswerIndexs){
			if(!$.isArray(aAnswerIndexs) || aAnswerIndexs.length == 0){
				return true;
			}

			for(var i in aAnswerIndexs){
				if(!/^\d+$/.test(aAnswerIndexs[i])){
					return true;
				}
			}
			return false;
		};

		return $question;
	},

	buildMultipleChoiceDetail : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		//组装选项
		var aOptionsHtmlList = [];
		$(aEs.es_content.option).each(function(i){
			var optionImageHtml = _buildImageListHtml(this.image);

			var answerHtml = '';
			for(var n in aEs.es_content.answer){
				if(i == aEs.es_content.answer[n]){
					answerHtml = '<span class="correct"><i title="正确答案">&radic;</i></span>';
				}
			}
			aOptionsHtmlList.push('<div class="esOption c">\
				<label for="esAnswer' + aEs.id + i + '">\
					<div class="control">\
						' + answerHtml + '<span class="optionIndex">' + (String.fromCharCode(65 + parseInt(i))) + '. </span>\
					</div>\
					<div class="txt"><span style="position:relative; left:-999em; margin-left:-20px;">1</span>' + _buildHtmlContent(this.content) + '</div>\
					<div class="images">' + optionImageHtml + '<br class="both" /></div>\
				</label>\
			</div>');
		});

		//整体组装
		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		var $oDetail = $('<div class="wrapEs wrapEsDetail choose" xid="wrapEsDetail">\
			<div class="esContent">\
				<div class="txt" xid="wrapEsContent">' + htmlContent + '</div>\
				<div class="images">' + contentImageHtml + '<br class="both" /></div>\
			</div>\
			<div class="esOptions">\
				' + aOptionsHtmlList.join('') + '\
			</div>\
		</div>');
		return $oDetail;
	},

	buildMultipleChoiceForm : function(aEs){
		var aEsContent = aEs.es_content,
		contentImageHtml = '',
		optionsHtml = ''
		,optionAddCount = 0;

		/**
		 * 构建多选题选项HTML
		 * @param {type} content 选项内容
		 * @param {type} optionIndex 选项序号
		 * @param {type} uniqueId 唯一ID
		 * @param {type} isShowAnimation 是否以动画形式展示出来
		 * @returns {String} 选项HTML
		 */
		function __buildOptionHtml(aOption, isAnswer, optionIndex, uniqueId, isShowAnimation){
			var hiddenStyle = isShowAnimation ? ' style="display:none;"' : '',
			optionImagesHtml = '';
			optionIndex = parseInt(optionIndex);
			if($.type(aOption.image) == 'array'){
				for(var i in aOption.image){
					optionImagesHtml += _buildImageItemHtml(aOption.image[i], i);
				}
			}

			var _html =  '<div xid="option" class="optionItem"' + hiddenStyle + '>\
				<div class="itemHead">\
				<strong class="letter">' + String.fromCharCode(65 + optionIndex) + '</strong>\
					<label class="col-md-offset-9" for="isAnswer' + uniqueId + '" xid="setAnswer" class="setAnswer">\
					<input type="checkbox" class="answerCheckBox" xid="isAnswer" id="isAnswer' + uniqueId + 'style="margin-top:2px;"' + (isAnswer ? ' checked="checked"' : '') + ' />\设为答案\
					</label>\
					<a xid="deleteOption" href="javascript:;" class="removeOption">删除</a>\
				</div>\
				<textarea xid="optionContent" class="form-control" rows="3">' + aOption.content + '</textarea>\
				<div class="clear"></div>\
				<div xid="optionUpload" class="btnImageUpload">\
					<input type="file" xid="btnImageUpload" />\
				</div>\
				<div  xid="wrapImages">' + optionImagesHtml + '</div>\
			</div>';
			return _html;
		}

		if(aEsContent.image != undefined && aEsContent.image.length){
			for(var i in aEsContent.image){
				contentImageHtml += _buildImageItemHtml(aEsContent.image[i], i);
			}
		}

		for(var i in aEsContent.option){
			optionsHtml += __buildOptionHtml(aEsContent.option[i], jsTools.inArray(i, aEsContent.answer), i, aEs.id + '' + (++optionAddCount));
		}
		oForm = $('<div  class="container-fluid form-upload" xid="wrapEs" itemid="' + aEs.id + '">\
			<div class="row">\
				<label class="col-md-1 text-right vignette">题干:</label>\
				<div class="col-md-6">\
						<textarea class="form-control" rows="5" xid="esContent">' + aEsContent.content + '</textarea>\
				</div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right" style="padding:0">附图:</label>\
				<div class="col-md-6">\
					<div xid="wrapImagesContent">' + contentImageHtml + '</div>\
					<div class="clear"></div>\
					<input type="file" style="display:none" xid="btnUploadContentImage" />\
					<div class="clear"></div>\
				</div>\
			</div>\
			<div class="row" style="margin-top:10px;">\
				<label class="col-md-1 text-center" style="padding:0;">选项: <a  href="javascript:;" xid="btnAddOption">添加</a></label>\
				<div class="col-md-6" xid="wrapOption">'  + optionsHtml +'</div>\
			</div>\
		</div>');
		oForm.data({
			es : jsTools.clone(aEs)
			,option_add_count : optionAddCount
		});

		/**
		 * 添加多选题选项
		 */
		oForm.find('a[xid="btnAddOption"]').click(function(){
			var optionAddCount = oForm.data('option_add_count');
			if(!optionAddCount){
				optionAddCount = 0;
			}
			var optionCount = oForm.find('[xid="option"]').length;
			var esId = oForm.data('es').id;
			var optionHtml = __buildOptionHtml({content : ''}, false, optionCount, esId + (++optionAddCount), true);
			var oLastOption = $(optionHtml).appendTo(oForm.find('[xid="wrapOption"]'));
			_buildUploadButton(oLastOption.find('[xid="btnImageUpload"]'), oLastOption.find('[xid="wrapImages"]'));
			oLastOption.slideDown('normal');

			oForm.data('option_add_count', optionAddCount);
		});

		/**
		 * 删除多选题选项
		 * @param {type} optionId
		 * @returns {Boolean}
		 */
		oForm.delegate('a[xid="deleteOption"]', 'click', _deleteChoiceOption);

		//初始化图片上传按钮
		_buildUploadButton(oForm.find('input[xid="btnUploadContentImage"]'), oForm.find('div[xid="wrapImagesContent"]'));
		oForm.find('[xid="option"]').each(function(){
			_buildUploadButton($(this).find('input[xid="btnImageUpload"]'), $(this).find('[xid="wrapImages"]'));
		});
		return oForm;
	},

	/**
	 * 构建多选题数据
	 * @param {type} oEs
	 * @returns {unresolved}
	 */
	buildMultipleChoiseEsData : function(oEs){
		var aEs = oEs.data('es');
		aEs.es_content.content = oEs.find('textarea[xid="esContent"]').val();

		//收集题干图片
		var oContentImages = oEs.find('[xid="wrapImagesContent"] [xid="imageItem"]');
		if(oContentImages.length){
			aEs.es_content.image = _buildImagesData(oContentImages);
		}else{
			aEs.es_content.image = undefined;
		}

		//收集题目选项
		aEs.es_content.option = [];
		oEs.find('[xid="option"]').each(function(){
			var aOption = {content : ''},
			oOption = $(this),
			oOptionImages = oOption.find('[xid="imageItem"]');

			//选项内容
			aOption.content = oOption.find('[xid="optionContent"]').val();

			//选项图片
			if(oOptionImages.length){
				aOption.image = _buildImagesData(oOptionImages);
			}

			aEs.es_content.option.push(aOption);
		});
		//收集正确答案
		aEs.es_content.answer = [];
		oEs.find(':checkbox[xid="isAnswer"]').each(function(i){
			if(this.checked){
				aEs.es_content.answer.push(i);
			}
		});
		return aEs;
	},

	/**
	 * 检查单选题数据是否可以提交
	 * @param {type} aEsContent
	 * @returns {Boolean}
	 */
	checkMultipleChoiseEsData : function(aEsContent){
		if(!aEsContent.content && aEsContent.image === undefined){
			UBox.show('题干内容不能为空');
			return false;
		}else if(/\\\[/.test(aEsContent.content)){
			if(!confirm('发现存在疑似非内联公式的符号，你真的选择了内联公式符号吗？ 确定继续保存吗？')){
				return false;
			}
		}

		for(var i in aEsContent.option){
			i = parseInt(i);
			var optionId = i + 1;
			var oOption = aEsContent.option[i];
			if(!oOption.content && oOption.image === undefined){
				UBox.show('请填写第 ' + optionId + ' 个选项的内容或者上传图片');
				return false;
			}
			if(/\\\[/.test(oOption.content)){
				if(!confirm('发现第' + (i + 1) + '个选项带有疑似非内联公式的符号，你确定选择了内联公式符号吗？确定继续保存吗？')){
					return false;
				}
			}
		}

		if(aEsContent.answer.length == 0){
			UBox.show('请至少选择一个正确答案');
			return false;
		}

		return true;
	}

	//构建判断题问题对象
	,buildJudgmentQuestion : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		//整体组装
		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		var $question = $('<div class="esp" id="question' + aEs.id + '" xid="wrapEsQuestion" data-type="' + aEs.type_id + '">\
			<div class="esp_main">\
				<div class="esp_main_text">' + htmlContent + '</div>\
				' + contentImageHtml + '\
			</div>\
		</div>\
		<div class="esp_option">\
			<input type="hidden" class="J-answer" value="" />\
			<div class="esp_option_item J-right">\
				<div class="esp_option_item_content">\
					<div class="esp_option_item_content_text">正确(是)</div>\
				</div>\
			</div>\
			<div class="esp_option_item J-wrong">\
				<div class="esp_option_item_content">\
					<div class="esp_option_item_content_text">错误(否)</div>\
				</div>\
			</div>\
		</div>').data('es', jsTools.clone(aEs));

		$question.writeAnswer = function(answer){
			$question.find('.J-' + (answer == 1 ? 'right' : 'wrong')).addClass('on');
			$question.find('.J-' + (answer == 0 ? 'right' : 'wrong')).removeClass('on');
			$question.find(':hidden.J-answer').val(answer);
		};

		$question.find('.J-right').click(function(){
			if($question.isPreviewMode){
				return false;
			}
			$question.writeAnswer(1);
		});

		$question.find('.J-wrong').click(function(){
			if($question.isPreviewMode){
				return false;
			}
			$question.writeAnswer(0);
		});

		/**
		 * 构建答案
		 */
		$question.buildAnswer = function(){
			var answer = parseInt($(this).find(':hidden.J-answer').val());
			return (answer === 0 || answer === 1) ? answer : undefined;
		};

		/**
		 * 解析答案
		 * @param {type} answer
		 * @returns {unresolved}
		 */
		$question.buildAnswerText = function(answer){
			return answer == 1 ? '正确' : '错误';
		};

		/**
		 * 判断是否空答案
		 */
		$question.isEmptyAnswer = function(answer){
			if(!/^[01]$/.test(answer)){
				return true;
			}
			return false;
		};

		return $question;
	},

	buildJudgmentDetail : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		//整体组装
		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		var answerHtml = '';
		answerHtml = '<div class="esOption c"><span class="correct">答案：<b>' + (aEs.es_content.answer == 1 ? '是(正确)' : '否(错误)') + '</b></span></div>';
		var $oDetail = $('<div class="wrapEs wrapEsDetail judge" xid="wrapEsDetail">\
			<div class="esContent">\
				<div class="txt" xid="wrapEsContent">' + htmlContent + '</div>\
				<div class="images">' + contentImageHtml + '<br class="both" /></div>\
			</div>\
			<div class="esOptions c">\
				<input type="hidden" xid="answer" value="">\
				' + answerHtml + '\
			</div>\
		</div>');
		return $oDetail;
	},

	/**
	 * 构造判断题表单
	 * @param {type} aEs
	 * @returns 表单DOM对象
	 */
	buildJudgmentForm : function(aEs){
		var aEsContent = aEs.es_content,
		contentImageHtml = '';
		aEsContent.answer = parseInt(aEsContent.answer);

		if(aEsContent.image != undefined && aEsContent.image.length){
			for(var i in aEsContent.image){
				contentImageHtml += _buildImageItemHtml(aEsContent.image[i], i);
			}
		}

		oForm= $('<div class="container-fluid form-upload" xid="wrapEs">\
			<div class="row">\
				<label  class="col-md-1 text-right vignette">题干:</label>\
				<div class="col-md-6">\
					<textarea class="form-control" rows="4" xid="esContent">' + aEsContent.content + '</textarea>\
				</div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right drawing">附图:</label>\
				<div class="col-md-9">\
					<input class="btnUploadContentImage" type="file" xid="btnUploadContentImage" />\
					<div>' + contentImageHtml + '</div>\
				</div>\
			</div>\
			<div class="row">\
				<div class="col-md-6 col-md-offset-1 wrapImagesContent" xid="wrapImagesContent"></div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right answer" >答案:</label>\
				<div class="col-md-6 choice">\
						<label>\
								<input type="radio"  id="rightAnswer' + aEs.id + '" name="answer' + aEs.id + '" xid="trueFalse" value="1"' + (aEsContent.answer === 1 ? ' checked="checked"' : '') + '/>是(正确)\
						</label>\
						<label>\
							<input type="radio" id="wrongAnswer' + aEs.id + '" name="answer' + aEs.id + '" xid="trueFalse" value="0"' + (aEsContent.answer === 0 ? ' checked="checked"' : '') + '/>否(错误)\
						</label>\
				</div>\
			</div>\
		</div>').data('es', jsTools.clone(aEs));
		//初始化图片上传按钮
		_buildUploadButton(oForm.find('input[xid="btnUploadContentImage"]'), oForm.find('div[xid="wrapImagesContent"]'));

		return oForm;
	},

	/**
	 * 构建判断题数据
	 */
	buildJudgmentEsData : function(oEs){
		var aEs = oEs.data('es');
		aEs.es_content.content = oEs.find('textarea[xid="esContent"]').val();
		var oAnswer = oEs.find(':radio:checked');

		if(oAnswer.length){
			aEs.es_content.answer = parseInt(oAnswer.val());
		}
		var oImages = oEs.find('[xid="imageItem"]');
		if(oImages.length){
			aEs.es_content.image = _buildImagesData(oImages);
		}else{
			aEs.es_content.image = undefined;
		}

		return aEs;
	},

	/**
	 * 检查判断题数据是否合法
	 * @param {type} aEsContent 题目数据
	 */
	checkJudgmentEsData : function(aEsContent){
		if(!aEsContent.content){
			UBox.show('题干不能为空');
			return false;
		}else if(/\\\[/.test(aEsContent.content)){
			if(!confirm('发现存在疑似非内联公式的符号，你真的选择了内联符号公式吗？ 确定继续保存吗？')){
				return false;
			}
		}

		if(aEsContent.answer !== 1 && aEsContent.answer !== 0){
			UBox.show('请选择题目的答案');
			return false;
		}
		return true;
	},


	//构建填空题问题对象
	buildFillBlankQuestion : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		htmlContent = htmlContent.replace(/[_]{4,}/g, '<input type="text" size="5" class="J-answer" />');

		//整体组装
		var $question = $('<div class="esp" id="question' + aEs.id + '" xid="wrapEsQuestion" data-type="' + aEs.type_id + '">\
			<div class="esp_main">\
				<div class="esp_main_text">' + htmlContent + '</div>\
				' + contentImageHtml + '\
			</div>\
		</div>').data('es', jsTools.clone(aEs));

		$question.find('.J-answer').keyup(_resetBlankLength);

		$question.writeAnswer = function(aAnswerList){
			$(this).find('.J-answer').each(function(i){
				var answer = '';
				if($question.isPreviewMode){
					answer = aAnswerList[i].join(' 或 ');
				}else{
					answer = aAnswerList[i][0];
				}
				$(this).val(answer).trigger('keyup');
			});
		};

		$question.on('keypress', ':text', function(){
			return !$question.isPreviewMode;
		});

		/**
		 * 构建答案
		 */
		$question.buildAnswer = function(){
			var aAnswer = [];
			$(this).find(':text.J-answer').each(function(){
				aAnswer.push([_convertFillBlankAnswer($.trim(this.value))]);
			});
			return aAnswer.length ? aAnswer : undefined;
		};

		/**
		 *解析答案
		 * @param {type} answer
		 * @returns {unresolved}
		 */
		$question.buildAnswerText = function(aAnswerList){
			var aAnswerHtml = [];
			for (var answerIndex in aAnswerList) {
				aAnswerHtml.push('<span class="blankAnswer">第' + (parseInt(answerIndex) + 1) + '空:' + aAnswerList[answerIndex].join('<span class="aor">或</span>') + '</span>');
			}
			return aAnswerHtml.join();
		};

		/**
		 * 判断是否空答案
		 */
		$question.isEmptyAnswer = function(aAnswerList){
			if(!$.isArray(aAnswerList)){
				return true;
			}

			var isDo = false;
			for(var i in aAnswerList){
				if(typeof(aAnswerList[i][0]) != 'string'){
					return true;
				}

				if($.trim(aAnswerList[i][0]) && !isDo){
					isDo = true;
				}
			}

			return !isDo;
		};

		return $question;
	},

	buildFillBlankDetail : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		var htmlContent = _buildHtmlContent(aEs.es_content.content);
		for(var j in aEs.es_content.answer){
			var blankAnswer = '<span class="isanswer">' + aEs.es_content.answer[j].join('<b>或</b>').replace(/&lt;u&gt;/g, '<u>').replace(/&lt;\/u&gt;/g, '</u>') + '</span>';
			htmlContent = htmlContent.replace(/[_]{4,}/, blankAnswer);
		}

		//整体组装
		var $oDetail = $('<div class="wrapEs wrapEsDetail fillblank topic">\
			<div class="esContent">\
				<div class="txt" xid="wrapEsContent">' + htmlContent + '</div>\
				<div class="images">' + contentImageHtml + '<br class="both" /></div>\
			</div>\
		</div>');

		return $oDetail;
	},

	/**
	 * 构建填空题表单对象
	 * @param {type} aEs
	 * @returns 填空题表单DOM对象
	 */
	buildFillBlankForm : function(aEs){
		var aEsContent = aEs.es_content,
		contentImageHtml = '';
		if(aEsContent.image != undefined && aEsContent.image.length){
			for(var i in aEsContent.image){
				contentImageHtml += _buildImageItemHtml(aEsContent.image[i], i);
			}
		}

		//组装填空答案项的HTML
		var blanksHtml = '',
		aAnswerGroupId = self.fillBlank.aAnswerGroupChineseId;
		for(i in aEsContent.answer){
			i = parseInt(i);
			var aAnswer = aEsContent.answer[i],
			allAnswerGroupHtml = '';
			if(aEsContent.answer_group){
				for(var j in aEsContent.answer_group){
					var answerGroupHtml = _buildAnswerGroupCheckBoxHtml(i, j, jsTools.inArray(i, aEsContent.answer_group[j]));
					if(i == 0){
						answerGroupHtml = '<span class="norderAction" xid="norderAction">\
							<span class="norderGroupNum" xid="norderGroupNum">' + aAnswerGroupId[j] + '</span>\
							<a class="delNorder" href="javascript:void(0)" data-colum="' + j + '" xid="delNorder">×</a>' + answerGroupHtml + '\
						</span>';
					}
					allAnswerGroupHtml += answerGroupHtml;
				}
			}

			blanksHtml += _getAnswerItemHtml(aAnswer, i, allAnswerGroupHtml);
		}

		var oForm= $('<div xid="wrapEs" class="container-fluid form-upload">\
			<div class="row">\
				<label class="col-md-1 text-right vignette" style="padding:0">题干:</label>\
				<div class="col-md-6">\
					<input class="select" type="checkbox" id="onlyUnderline"/><strong>仅将4个以上下划线视为答案区</strong>\
					<textarea class="form-control" rows="4" xid="esContent">' + aEsContent.content + '</textarea>\
				</div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right drawing">附图:</label>\
				<div class="col-md-6">\
						<input type="file" class="btnUploadContentImage" xid="btnUploadContentImage"/>\
				</div>\
			</div>\
			<div class="col-md-6 col-md-offset-1 wrapImagesContent" xid="wrapImagesContent">' + contentImageHtml + '</div>\
			<div class="row blanksHtml">\
				<label class="col-md-1 text-right">填空答案:</label>\
				<div xid="answerWrap" class="col-md-6">' + blanksHtml + '</div>\
			</div>\
			');


		oForm.data('es', jsTools.clone(aEs));
		oForm.find('textarea[xid="esContent"]').blur(function(){
			oForm.find('div[xid="answerItem"].currentItem').removeClass('currentItem');
		});

		/**
		 * 添加填空答案
		 */
		oForm.addAnswer = function(){
			var ANSWER_MARK = self.fillBlank.ANSWER_MARK;
			var content = oForm.find('textarea[xid=esContent]')[0],
			siteCursor = content.selectionStart;

			//扫描光标左右两边有没有填空标识
			for(var i = siteCursor; i < siteCursor + ANSWER_MARK.length + 1; i++){
				var checkValue = content.value.substr(i - ANSWER_MARK.length, ANSWER_MARK.length);
				if(checkValue == ANSWER_MARK){
					UBox.show('不可以连续填充两个答案', -1);
					content.focus();
					return;
				}
			}

			//分离光标左右两端的字符串
			var leftStr = content.value.substr(0, siteCursor),
			rightStr = content.value.substr(siteCursor);
			leftStr += ' ';
			rightStr = ' ' + rightStr;
			siteCursor++;

			//确定插入填空项的序列号
			var reg = new RegExp(ANSWER_MARK, 'g'),
			matchResult = leftStr.match(reg),
			itemIndex = matchResult == null ? 0 : matchResult.length;

			//开始插入填空项
			var answerItemHtml = _getAnswerItemHtml([], itemIndex, '');

			//根据光标周围的情况来确定如何添加填空项
			if(oForm.find('div[xid="answerItem"]').length == 0){ //当前没有填空项,则在框里直接append
				oForm.find('[xid="answerWrap"]').append(answerItemHtml);
			}else if(itemIndex==0){ //如果光标在所有填空项的前面,则在第一个填空项的前面添加
				oForm.find('div[xid="answerItem"][itemid="0"]').before(answerItemHtml);
			}else{  //如果光标位置的左边和右边都有填空项,则在光标左边那个填空项对应序号的后面追加填空项
				var obj = oForm.find('div[xid="answerItem"][itemid="' + (itemIndex - 1) + '"]');
				var $html = $(answerItemHtml);
				obj.after($html[0]);
			}

			leftStr += ANSWER_MARK;  //追加填空标识符
			content.value = leftStr + rightStr; //重置追加填空标识符后的题干内容
			siteCursor += ANSWER_MARK.length + 3;    //光标按照填空标识符长度偏移再设置光标起始和结束位置和空格长度
			content.selectionStart = siteCursor;
			content.selectionEnd = siteCursor;
			content.focus();
			oForm.find('div[xid="answerItem"][itemid="' + itemIndex + '"]').animate({opacity : 1});  //淡入动画
			_resetAnswerIndex(oForm); //重置各填空项的序号,即在1和2之间插入后,将原来的第2个序号重置为3之类的重置工作
		};

		/**
		 * 删除填空项
		 */
		oForm.delegate('a[xid="deleteBlank"]', 'click', function(){
			if(!confirm('确定要删除吗？')){
				return;
			}
			var ANSWER_MARK = self.fillBlank.ANSWER_MARK;
			var answerItem = $(this).parent(),
			itemIndex = answerItem.attr('itemid');
			answerItem.animate({opacity : 0}, function(){
				$(this).remove();
				var oContent = oForm.find('[xid="esContent"]'),
				contentArr = oContent.val().split(ANSWER_MARK);
				var result = contentArr[0];
				for(var i = 1; i < contentArr.length; i++){
					var tmpStr = contentArr[i];
					if(i - 1 != itemIndex){
						tmpStr = ANSWER_MARK + tmpStr;
					}
					result += tmpStr;
				}
				oContent.val(result);
				_resetAnswerIndex(oForm);
			});
			var answerNums = oForm.find('div[xid="answerItem"]').length;
			if(answerNums <= 2){
				var answerGroup = oForm.find('a[xid="delNorder"]');
				answerGroup.each(function(i){
					self.fillBlank.delNorder($(this));
				});
			}
		});

		/**
		 * 根据光标位置,高亮相应序号的答案选项
		 */
		oForm.find('textarea[xid=esContent]').bind('keyup click', function(){
			$('.currentItem').removeClass('currentItem');
			var siteCursor = this.selectionStart,
			contentText = this.value,
			ANSWER_MARK = self.fillBlank.ANSWER_MARK;

			//扫描光标是否处于填空标识符范围内
			var inAnswerMark = false;
			for(var i = siteCursor - 4; i <= siteCursor; i++){
				var tmpStr = contentText.slice(i, i + ANSWER_MARK.length);
				if(tmpStr == ANSWER_MARK){
					inAnswerMark = true;
				}
			}
			if(!inAnswerMark){
				return;
			}

			var lrString = _splitStringWithSite(contentText, siteCursor),
			reg = new RegExp('[' + ANSWER_MARK.substr(0, 1) + ']{4,}', 'g'),
			leftResult = lrString[0].match(reg);

			var currentIndex = 0;
			if(leftResult == null){
				currentIndex = 0;
			}else if(lrString[0].slice(siteCursor - ANSWER_MARK.length, siteCursor).match(reg)){
				currentIndex = leftResult.length - 1;
			}else if(leftResult || lrString[1].slice(0, ANSWER_MARK.length).match(reg)){
				currentIndex = leftResult.length;
			}

			var currentItem = oForm.find('div[xid="answerItem"][itemid="' + currentIndex + '"] .idCaption');
			if(currentItem.length){
				currentItem.addClass('currentItem');
			}

		}).keydown(function(e){
			//监听输入控件里是否按下了删除键来删除相应的填空项
			var event = e ? e : window.event,
			pressBackSpace = event.keyCode == 8,  //是否按下了退格键
			pressDelete = event.keyCode == 46;    //是否按下了回删键
			if(pressBackSpace){
				_deleteAnswerCharWidthBackSpace(this);
			}else if(pressDelete){
				_deleteAnswerCharWidthDelete(this);
			}
		});

		oForm.delegate('a[xid="delNorder"]', 'click', _delNorder);

		/**
		 * 答案组勾选唯一处理
		 */
		oForm.delegate('input[xid="norderOption"]', 'click', function(){
			var isChecked = this.checked;
			$('input[data-row="' + $(this).data('row') + '"]').each(function(){
				$(this).attr('checked', false);
			});
			this.checked = isChecked;
		});

		/**
		 * 点击答案高亮
		 */
		oForm.delegate('input[xid="answerBlank"]', 'click', function(){
			var oAnswer = $(this);
			oAnswer.closest('[xid="answerWrap"]').find('.currentItem').removeClass('currentItem');
			oAnswer.parent().find('span[xid="idCaption"]').addClass('currentItem');
		});

		oForm.resetAllAnswer = _resetAllFillBlankAnswer;
		oForm.addNorder = _addFillBlankNorder;

		//初始化图片上传按钮
		_buildUploadButton(oForm.find('input[xid="btnUploadContentImage"]'), oForm.find('div[xid="wrapImagesContent"]'));

		return oForm;
	},

	buildFillBlankEsData : function(oEs){
		var aEs = oEs.data('es');
		aEs.es_content.content = oEs.find('textarea[xid="esContent"]').val();
		aEs.es_content.answer = [];
		oEs.find(':text[xid="answerBlank"]').each(function(){
			aEs.es_content.answer.push($.trim(this.value).split('|'));
		});

		var oImages = oEs.find('[xid="imageItem"]');
		if(oImages.length){
			aEs.es_content.image = _buildImagesData(oImages);
		}else{
			aEs.es_content.image = undefined;
		}

		var aAnswerGroupList = [];
		oEs.find('[xid="wrapNoOrderChk"]').each(function(i){
			$(this).find('[xid="norderOption"]').each(function(j){
				if(this.checked){
					if(!aAnswerGroupList[j]){
						aAnswerGroupList[j] = [];
					}

					aAnswerGroupList[j].push(i);
					return false;
				}
			});
		});
		if(aAnswerGroupList.length){
			aEs.es_content.answer_group = aAnswerGroupList;
		}else{
			aEs.es_content.answer_group = undefined;
		}
		return aEs;
	},

	checkFillBlankEsData : function(aEsContent){
		if(!aEsContent.content){
			UBox.show('题干不能为空');
			return false;
		}else if(/\\\[/.test(aEsContent.content)){
			if(!confirm('发现存在疑似非内联公式的符号，你真的选择了内联符号公式吗？ 确定继续保存吗？')){
				return false;
			}
		}

		if(aEsContent.answer.length == 0){
			UBox.show('请添加题目的填空答案');
			return false;
		}else if(aEsContent.content.indexOf(self.fillBlank.ANSWER_MARK) == -1){
			UBox.show('发现填空答案,但题干里没有添加填空区');
			return false;
		}else if(aEsContent.content.match(new RegExp(self.fillBlank.ANSWER_MARK, 'g')).length != aEsContent.answer.length){
			UBox.show('题干里的填空区域与设置的填空答案数量不相等');
			return false;
		}else if((function hasEmptyAnswer(aAnswerList){
			for(var i in aAnswerList){
				for(var j in aAnswerList[i]){
					if(!$.trim(aAnswerList[i][j])){
						UBox.show('请填写第 ' + (parseInt(i) + 1) + ' 个空的答案');
						return true;
					}
				}
			}
			return false;
		})(aEsContent.answer)){
			return false;
		}else if(aEsContent.answer_group){
			if(!aEsContent.answer_group.length){
				UBox.show('请勾选答案选项组');
				return false;
			}
			for(var i in aEsContent.answer_group){
				if(aEsContent.answer_group[i].length == 1){
					UBox.show('第 ' + (parseInt(i) + 1) + ' 个答案组不能只有一个答案');
					return false;
				}
			}
		}
		return true;
	}

	//构建复合题问题对象
	,buildComplexQuestion : function(aEs){
		var $question = $('<div class="esp" id="question' + aEs.id + '" xid="wrapEsQuestion" data-type="' + aEs.type_id + '">\
			<div class="esp_main">\
				<div class="esp_main_text">' + _buildHtmlContent(aEs.es_content.content) + '</div>\
				' + _buildImageListHtml(aEs.es_content.image) + '\
			</div>\
			<div class="esp_sub" xid="wrapChildEsList"></div>\
		</div>');
		$question.allowRemoveOption = false;
		var aChildEsDomList = [];

		var aShowEsItem = [];	//要显示出来的子题
		if(_aConfig.showAllComplexItem){
			aShowEsItem = aEs.es_content.es_item;
		}else{
			var randomItemIndex = Math.floor(Math.random() * aEs.es_content.es_item.length);
			aShowEsItem = [aEs.es_content.es_item[randomItemIndex]];
		}

		for(var i in aShowEsItem){
			i = parseInt(i);
			var oChildEs = null
			,aEsItem = aShowEsItem[i],
			optionsHtml = '',
			isHasAnswer = aEsItem.content.answer != undefined;
			isHasAnswer = false;	//第三次改版的暂时控制

			if(self.isSingleChoice(aEsItem.type) || self.isMultipleChoice(aEsItem.type)){
				var aOptionsHtmlList = [];
				$(aEsItem.content.option).each(function(j){
					aOptionsHtmlList.push('<div class="esp_option_item J-esOptionItem">\
						<div class="esp_option_item_control"><input name="esAnswer' + (aEs.id + i) + '" type="' + (aEsItem.type == 1 ? 'radio' : 'checkbox') + '" value="' + j + '" class="J-answerControl" /></div>\
						<div class="esp_option_item_index J-esOptionIndex" data-index="__optionIndex__">__optionIndex__</div>\
						<div class="esp_option_item_content">\
							<div class="esp_option_item_content_text">' + _buildHtmlContent(this.content) + '</div>\
						</div>\
					</div>');
				});

				//打乱答案选项的顺序
				if(_aConfig.shuffleChoise){
					var aOptionsHtmlList2 = jsTools.shuffle(aOptionsHtmlList)
					,aOptionsRelation = _getArrayRelation(aOptionsHtmlList, aOptionsHtmlList2);
					aEsItem.content.options_relation = aOptionsRelation;
					aOptionsHtmlList = aOptionsHtmlList2;
				}
				for(var k in aOptionsHtmlList){
					aOptionsHtmlList[k] = aOptionsHtmlList[k].replace(/__optionIndex__/g, String.fromCharCode(65 + parseInt(k)));
				}
				optionsHtml = aOptionsHtmlList.join('');

				//整体组装
				oChildEs = $('<div class="esp J-childEs">\
					<div class="esp_main">\
						<div class="esp_main_text">' + _buildHtmlContent(aEsItem.content.content) + '</div>\
					</div>\
					<div class="esp_option">\
					' + optionsHtml + '\
					</div>\
				</div>');

				//选项点击交互
				oChildEs.on('click', '.J-esOptionItem,.J-answerControl', function(oEvent){
					if($question.isPreviewMode){
						return false;
					}

					var $this = $(this),
						oControl = $this[0],
						isCheckBox = $this.is(':checkbox'),
						isRadio = $this.is(':radio'),
						isStopEvent = false,	//是否停止事件向上冒泡
						$optionItem = null;

					if(isRadio || isCheckBox){
						$optionItem = $this.closest('div.J-esOptionItem');
						isStopEvent = true;
					}else{
						$optionItem = $this;
						oControl = $optionItem.find('input')[0];
						isRadio = $(oControl).is(':radio');
						oControl.checked = isRadio ? true : !oControl.checked;
					}

					if(isRadio){
						$optionItem.addClass('on').siblings().removeClass('on');	//单选:高亮自己,"低亮他人"
					}else{
						//多选子题高亮切换
						if(oControl.checked){
							$optionItem.addClass('on');
						}else{
							$optionItem.removeClass('on');
						}
					}

					isStopEvent && oEvent.stopPropagation();
				});

				//移除选项
				oChildEs.removeOption = function(aOptionIndexList){
					var $this = $(this);
					for(var i in aOptionIndexList){
						$this.find('.J-answerControl[value="' + aOptionIndexList[i] + '"]').closest('.J-esOptionItem').slideUp(function(){
							$(this).remove();
						});
					}
				};

				$question.allowRemoveOption = true;

			}else if(self.isJudgment(aEsItem.type)){
				optionsHtml = '<div class="esp_option" xid="judgeOption" itemid="' + aEs.id + i + '">\
					<input type="hidden" class="J-answer" />\
					<div class="esp_option_item J-right">\
						<div class="esp_option_item_content">\
							<div class="esp_option_item_content_text">正确(是)</div>\
						</div>\
					</div>\
					<div class="esp_option_item J-wrong">\
						<div class="esp_option_item_content">\
							<div class="esp_option_item_content_text">错误(否)</div>\
						</div>\
					</div>\
				</div>';

				oChildEs = $('<div class="esp J-childEs">\
					<div class="esp_main">\
						<div class="esp_main_text">' + _buildHtmlContent(aEsItem.content.content) + '</div>\
					</div>' + optionsHtml + '</div>\
				</div>');

				oChildEs.find('.J-right').click(function(){
					if($question.isPreviewMode){
						return false;
					}

					$question.find('.J-right').addClass('on');
					$question.find('.J-wrong').removeClass('on');
					$question.find(':hidden.J-answer').val(1);
				});

				oChildEs.find('.J-wrong').click(function(){
					if($question.isPreviewMode){
						return false;
					}

					$question.find('.J-wrong').addClass('on');
					$question.find('.J-right').removeClass('on');
					$question.find(':hidden.J-answer').val(0);
				});

			}else if(self.isFillBlank(aEsItem.type)){
				var fillBlankContent = _buildHtmlContent(aEsItem.content.content);
				fillBlankContent = fillBlankContent.replace(/[_]{4,}/g, '<input type="text" size="5" class="J-answer" />');

				oChildEs = $('<div class="esp J-childEs">\
					<div class="esp_main">\
						<div class="esp_main_text">' + fillBlankContent + '</div>\
					</div>\
				</div>');

				oChildEs.find('.J-answer').keyup(_resetBlankLength);

				oChildEs.on('keypress', ':text', function(){
					return !$question.isPreviewMode;
				});
			}

			oChildEs.data('index', randomItemIndex);
			oChildEs.data('type', aEsItem.type);
			oChildEs.data('is_has_answer', isHasAnswer);
			aChildEsDomList.push(oChildEs);
			$question.find('[xid="wrapChildEsList"]').append(oChildEs);
		}
		$question.data('child_es_list', aChildEsDomList);


		/**
		 * 填写答案
		 * @param {type} aAnswerList
		 * @returns {unresolved}
		 */
		$question.writeAnswer = function(aAnswerList){
			var originalPreviewMode = $question.isPreviewMode;
			$question.isPreviewMode = false;
			$($(this).data('child_es_list')).each(function(i){
				var $this = $(this);
				if($this.data('is_has_answer')){
					return;
				}
				var mAnswer = aAnswerList[i];

				var type = $this.data('type');
				if(self.isSingleChoice(type)){
					$this.find('.J-answerControl[value="' + mAnswer + '"]').trigger('click');					

				}else if(self.isMultipleChoice(type)){
					$this.find('.J-answerControl').each(function(){
						if(jsTools.inArray(this.value, mAnswer)){
							$(this).trigger('click');
							this.checked = true;
						}else{
							this.checked && $(this).trigger('click');
						}
					});

				}else if(self.isJudgment(type)){
					$this.find('.J-' + (mAnswer ? 'right' : 'wrong') + '').click();

				}else if(self.isFillBlank(type)){
					$this.find('.J-answer').each(function(j){
						if(typeof(mAnswer) != 'undefined'){
							$(this).val(mAnswer[j][0]).trigger('keyup');
						}
					});
				}
			});
			$question.isPreviewMode = originalPreviewMode;
		};

		/**
		 * 移除答案
		 * @param {type} aRemoveList
		 */
		$question.removeOption = function(aRemoveList){
			var aEsItemList = $(this).data('child_es_list');
			for(var esItemIndex in aRemoveList){
				var aEsItem = aEsItemList[esItemIndex],
					type = aEsItem.data('type');
				if(!self.isSingleChoice(type) && !self.isMultipleChoice(type)){
					continue;
				}
				aEsItem.removeOption(aRemoveList[esItemIndex]);
			}
		};

		/**
		 * 构建答案
		 */
		$question.buildAnswer = function(){
			var aAnswerList = {};
			$(this).find('div.J-childEs').each(function(i){
				var $oChildEs = $(this);
				if($oChildEs.data('is_has_answer')){
					//如果已经显示出答案就不取了
					return true;
				}
				var type = $oChildEs.data('type'),
				answer = null;
				//根据各题型取答案到answer变量
				if(self.isSingleChoice(type)){
					var oCheckedDom = $oChildEs.find(':radio:checked');
					answer = oCheckedDom.length ? oCheckedDom.val() : undefined;

				}else if(self.isMultipleChoice(type)){
					answer = (function(oEsDom){
						var oCheckedDom = oEsDom.find(':checkbox:checked'), aAnswer = [];
						if(oCheckedDom.length > 0){
							oCheckedDom.each(function(){
								aAnswer.push(this.value);
							});
						}
						return aAnswer.length ? aAnswer : undefined;
					})($oChildEs);

				}else if(self.isJudgment(type)){
					answer = $oChildEs.find('input.J-answer').val();
					if(answer == null || answer == '' || isNaN(answer)){
						answer = undefined;
					}

				}else if(self.isFillBlank(type)){
					answer = (function(oEsDom){
						var aAnswer = [];
						oEsDom.find('input.J-answer').each(function(){
							aAnswer.push([_convertFillBlankAnswer($.trim(this.value))]);
						});
						return aAnswer.length ? aAnswer : undefined;
					})($oChildEs);
				}
				aAnswerList[$oChildEs.data('index')] = answer;
			});

			return aAnswerList;
		};

		$question.buildAnswerText = function(aAnswerList){
			var aAnswerTextList = [];
			$(this.data('child_es_list')).each(function (i) {
				var type = this.data('type'),
					xAnswer = aAnswerList[i],
					itemNum = this.data('index') + 1;
				if(self.isSingleChoice(type)){
					var $optionItem = this.find('.J-answerControl[value="' + xAnswer + '"]').closest('.J-esOptionItem');
					aAnswerTextList.push('第' + itemNum + '小题:' + $optionItem.find('.J-esOptionIndex').data('index'));

				}else if(self.isMultipleChoice(type)){
					var aAnswerText = [];
					for (var index in xAnswer) {
						var $optionItem = this.find('.J-answerControl[value="' + xAnswer[index] + '"]').closest('.J-esOptionItem');
						aAnswerText.push($optionItem.find('.J-esOptionIndex').data('index'));
					}
					aAnswerTextList.push('第' + itemNum + '小题:' + aAnswerText.join('、'));

				}else if(self.isJudgment(type)){
					aAnswerTextList.push('第' + itemNum + '小题:' + (xAnswer == 1 ? '正确' : '错误'));

				}else if(self.isFillBlank(type)){
					var aAnswerHtml = [];
					for (var answerIndex in xAnswer) {
						aAnswerHtml.push('<span class="blankAnswer">第' + (parseInt(answerIndex) + 1) + '空:' + xAnswer[answerIndex].join('<span class="aor">或</span>') + '</span>');
					}
					aAnswerTextList.push('第' + itemNum + '小题:' + aAnswerHtml.join());
				}

				aAnswerTextList.push('\n');
			});

			return aAnswerTextList.join('');
		};

		/**
		 * 判断一个答案是否为没填写的答案
		 * @param {type} xAnswer
		 */
		$question.isEmptyAnswer = function(aAnswerList){
			if(!jsTools.isObject(aAnswerList)){
				return true;
			}

			for(var itemIndex in aAnswerList){
				var xAnswer = aAnswerList[itemIndex];
				var firstEsItemType = $(this).data('child_es_list')[0].data('type');
				if(self.isSingleChoice(firstEsItemType) || self.isJudgment(firstEsItemType)){
					if(xAnswer == undefined){
						return true;
					}

				}else if(self.isMultipleChoice(firstEsItemType)){
					if(xAnswer.length == 0){
						return true;
					}

				}else if(self.isFillBlank(firstEsItemType)){
					var hasOne = false;
					for(var i in xAnswer){
						//检查是否至少有一个填空答案
						if(xAnswer[i][0] != ''){
							hasOne = true;
							break;
						}
					}

					if(!hasOne){
						return true;
					}

				}
				return false;
			}
		};

		return $question.data('es', jsTools.clone(aEs));
	},

	buildComplexDetail : function(aEs){
		//组装题干图片
		var contentImageHtml = _buildImageListHtml(aEs.es_content.image);

		var childEsListHtml = '';
		for(var i in aEs.es_content.es_item){
			i = parseInt(i);
			var aEsItem = aEs.es_content.es_item[i]
			,title = '<h3>第' + (i + 1) + '小题：</h3>'
			,isHasAnswer = aEsItem.content.answer != undefined;

			if(self.isSingleChoice(aEsItem.type) || self.isMultipleChoice(aEsItem.type)){
				var aOptionsHtmlList = [];
				if(isHasAnswer){
					for(var j in aEsItem.content.option){
						j = parseInt(j);
						var aOption = aEsItem.content.option[j],
						isAnswer = _isChoiceAnswer(j, aEsItem.content.answer, aEsItem.type);
						aOptionsHtmlList.push('<div class="_option_' + (isAnswer ? ' negativeLeft' : '') + '">\
							<div class="_optionContent_">\
								' + (isAnswer ? '<span class="correct"><i title="正确答案">&radic;</i></span>' : '') + '<div class="_optionText_">' + String.fromCharCode(65 + j) + '<b></b>' + _buildHtmlContent(aOption.content) + '</div>\
							</div>\
						</div>');
					}
				}else{
					$(aEsItem.content.option).each(function(j){
						var answerId = 'esAnswer' + aEs.id + i + j;
						aOptionsHtmlList.push('<div class="esOption c">\
							<label for="' + answerId + '">\
								<div class="control">\
									<input type="' + (self.isSingleChoice(aEsItem.type) ? 'radio' : 'checkbox') + '" id="' + answerId + '" name="esAnswer" />\
									<span>' + (String.fromCharCode(65 + i)) + '. ' + '</span>\
								</div>\
								<div class="txt">' + _buildHtmlContent(this.content) + '</div>\
							</label>\
						</div>');
					});
				}

				//整体组装
				childEsListHtml += '<div class="wrapEsDetail choose topic">\
					<div class="hd">' + title + '</div>\
					' + (aEsItem.content.content ? '<div class="esContent">\
						<div class="txt">' + _buildHtmlContent(aEsItem.content.content) + '</div>\
					</div>' : '') + '\
					<div class="esOptions">\
					' + aOptionsHtmlList.join('') + '\
					</div>\
				</div>';

			}else if(self.isJudgment(aEsItem.type)){
				var optionsHtml = '';
				if(isHasAnswer){
					optionsHtml = '<div class="esOptions c">' + (aEsItem.content.answer == 1 ? '<span class="right">√</span>': '<span class="wrong">×</span>') + '</div>';
				}else{
					optionsHtml = '<div class="esOptions c" xid="judgeOption" itemid="' + aEs.id + i + '">\
						<input type="hidden" xid="answer" value="">\
						<div class="esOption c">\
							<div class="esOption_click" xid="right">是(正确)<i class="icon icon_cur"></i></div>\
						</div>\
						<div class="esOption c">\
							<div class="esOption_click" xid="wrong">否(错误)<i class="icon icon_cur"></i></div>\
						</div>\
					</div>';
				}

				childEsListHtml += '<div class="wrapEsDetail judge topic" xid="childEs">\
					<div class="hd">' + title + '</div>\
					<div class="esContent">\
						<div class="txt">' + _buildHtmlContent(aEsItem.content.content) + '</div>\
					</div>\
					' + optionsHtml + '\
				</div>';

			}else if(self.isFillBlank(aEsItem.type)){
				var fillBlankContent = '';
				if(isHasAnswer){
					fillBlankContent = aEsItem.content.content;
					for(var j in aEsItem.content.answer){
						var blankAnswer = '<span class="isanswer">' + aEsItem.content.answer[j].join('<b>或</b>').replace(/&lt;u&gt;/g, '<u>').replace(/&lt;\/u&gt;/g, '</u>') + '</span>';
						fillBlankContent = fillBlankContent.replace(/[_]{4,}/, blankAnswer);
					}
				}else{
					fillBlankContent = _buildHtmlContent(aEsItem.content.content);
					fillBlankContent = fillBlankContent.replace(/[_]{4,}/g, '<input type="text" size="5" xid="answer" />');
				}

				childEsListHtml += '<div class="wrapEsDetail fillblank topic" xid="childEs">\
					<div class="hd">' + title + '</div>\
					<div class="esContent">\
						<div class="txt">' + fillBlankContent + '</div>\
					</div>\
				</div>';
			}
		}
		childEsListHtml = '<div class="wrapChildEsList">' + childEsListHtml + '</div>';

		var $oDetail = $('<div class="wrapEs wrapEsDetail complex topic">\
			<div class="esContent">\
				<div class="txt" xid="wrapEsContent">' + _buildHtmlContent(aEs.es_content.content) + '</div>\
				<div class="images">' + contentImageHtml + '<br class="both" /></div>\
			</div>' + childEsListHtml + '\
		</div>');

		$oDetail.find('div[xid="childEs"] input[xid="answer"]').keyup(_resetBlankLength);

		$oDetail.find('div[xid="right"]').click(function(){
			var $this = $(this)
			,$oWrapOption = $this.closest('[xid="judgeOption"]');
			$this.addClass('esOption_current');
			$oWrapOption.find('[xid="wrong"]').removeClass('esOption_current');
		});

		$oDetail.find('div[xid="wrong"]').click(function(){
			var $this = $(this)
			,$oWrapOption = $this.closest('[xid="judgeOption"]');
			$this.addClass('esOption_current');
			$oWrapOption.find('[xid="right"]').removeClass('esOption_current');
		});

		return $oDetail;
	},

	buildComplexForm : function(aEs){
		var aEsContent = aEs.es_content,
		contentImageHtml = '';
		if(aEsContent.image != undefined && aEsContent.image.length){
			for(var i in aEsContent.image){
				contentImageHtml += _buildImageItemHtml(aEsContent.image[i], i);
			}
		}

		var childEsListHtml = '';
		self.complex.childEsCount = aEsContent.es_item.length;
		for(var i in aEsContent.es_item){
			if(self.isSingleChoice(aEsContent.es_item[i].type)){
				childEsListHtml += self.complex.buildChildSingleChoiceFormHtml(aEsContent.es_item[i].content, i);
			}else if(self.isMultipleChoice(aEsContent.es_item[i].type)){
				childEsListHtml += self.complex.buildChildMultipleChoiceFormHtml(aEsContent.es_item[i].content, i);
			}else if(self.isJudgment(aEsContent.es_item[i].type)){
				childEsListHtml += self.complex.buildChildJudgmentFormHtml(aEsContent.es_item[i].content, i);
			}else if(self.isFillBlank(aEsContent.es_item[i].type)){
				childEsListHtml += self.complex.buildChildFillBlankFormHtml(aEsContent.es_item[i].content, i);
			}
		}
		var oForm = $('<div xid="wrapEs container-fluid" class="form-upload">\
			<div class="row">\
				<label class="col-md-1 text-right vignette">题干:</label>\
				<div class="col-md-6">\
					<textarea class="form-control" rows="4" xid="mainContent">' + aEsContent.content + '</textarea>\
				</div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right class="pre_pic" style="padding:0;">图片预览:</label>\
				<div class="col-md-6" xid="wrapImagesContent" >' + contentImageHtml + '</div>\
			</div>\
			<div class="row">\
				<label class="col-md-1 text-right drawing" style="padding:0">附图:</label>\
				<div class="col-sm-6">\
					<input type="file" style="display:none;" xid="btnUploadContentImage" />\
				</div>\
			</div>\
			<div xid="wrapChildEs" class="wrapChildEs">' + childEsListHtml + '</div>\
			<div class="row" style="margin:15px 0;">\
				<label class="col-md-1 text-right">添加小题:</label>\
				<div class="col-md-8" style="padding:0;">\
					<button type="button" class="btn btn-default" xid="btnAddChildEs" data-type="1">单选题</button>\
					<button type="button" class="btn btn-default" xid="btnAddChildEs" data-type="2">多选题</button>\
					<button type="button" class="btn btn-default" xid="btnAddChildEs" data-type="3">判断题</button>\
					<button type="button" class="btn btn-default" xid="btnAddChildEs" data-type="4">填空题</button>\
					第 <input type="text" class="digit" onfocus="$(this).select();" xid="insertText"/> 题后面插入\
				</div>\
			</div>\
		</form></div>');




		//初始化图片上传按钮
		_buildUploadButton(oForm.find('input[xid="btnUploadContentImage"]'), oForm.find('div[xid="wrapImagesContent"]'));

		oForm.data('es', jsTools.clone(aEs));

		oForm.find('button[xid="btnAddChildEs"]').click(function(){
			var oChildEs = null
			,type = $(this).data('type')
			,aEs = self.getDefaultData(type)
			,childEsId = self.complex.childEsCount++;
			aEs = aEs.es_content;
			if(self.isSingleChoice(type)){
				oChildEs = $(self.complex.buildChildSingleChoiceFormHtml(aEs, childEsId));
			}else if(self.isMultipleChoice(type)){
				oChildEs = $(self.complex.buildChildMultipleChoiceFormHtml(aEs, childEsId));
			}else if(self.isJudgment(type)){
				oChildEs = $(self.complex.buildChildJudgmentFormHtml(aEs, childEsId));
			}else if(self.isFillBlank(type)){
				oChildEs = $(self.complex.buildChildFillBlankFormHtml(aEs, childEsId));
			}else{
				UBox.show.error('未知的子题目类型');
				return;
			}

			var oInsertIndex = oForm.find('input[xid="insertText"]'),
			insertIndex = oInsertIndex.val();
			if(insertIndex){
				if(!isNaN(insertIndex)){
					if(insertIndex == 0){
						oForm.find('[xid="childEs"]').eq(insertIndex).before(oChildEs);
					}else{
						var oTmpChildEs = oForm.find('[xid="childEs"]').eq(insertIndex - 1);
						if(!oTmpChildEs.length){
							UBox.show('抱歉,找不到第' + insertIndex + '题', -1);
							return false;
						}
						oTmpChildEs.after().append(oChildEs);
					}
					oInsertIndex.val('');
				}else{
					UBox.show('请输入一个数字!');
					return false;
				}
			}else{
				oForm.find('div[xid="wrapChildEs"]').append(oChildEs);
			}

			_resetChildEsCaptionIndex(oForm);

			//调用textarea自动高度
			oChildEs.find('textarea[xid="content"]').autoTextarea({
				minHeight : 'auto',
				maxHeight : 500
			});
		});

		/**
		 * 单选和多选题删除选项
		 */
		oForm.delegate('a[xid="btnDeleteOption"]', 'click', function(){
			var oOptionDom = $(this).closest('div[xid="wrapOption"]')
			,oChildEsDom = oOptionDom.closest('[xid="childEs"]');
			oOptionDom.slideUp('fast', function(){
				$(this).remove();
				oChildEsDom.find('[xid="optionCaption"]').each(function(i){
					$(this).text(i + 1);
				});
				oChildEsDom.find('[xid="isAnswer"]').each(function(i){
					$(this).val(i);
				});
			});
			return false;
		});

		/**
		 * 设置单选子题的选项数量
		 */
		oForm.delegate('button[xid="btnSetSingleOptionCount"]', 'click', function(){
			var oCount = $(this).parent().prev().find(':text');
			if(!oCount.length){
				UBox.show('未能找到数量设置');
			}
			var blankCount = parseInt(oCount.val());
			if(!blankCount){
				UBox.show('请输入正确的选项数量!', -1);
				return;
			}

			var addOptionHtml = ''
			,oChildEs = oCount.closest('div[xid="childEs"]')
			,childEsIndex = oChildEs.attr('itemid');
			for(var i = 0; i < blankCount; i++){
				addOptionHtml += '\
					<div class="item row" xid="wrapOption">\
						<div class="col-md-1 option"><label class="control-label">选项<span class="optionCaption" xid="optionCaption">' + (parseInt(i) + 1) + '</span>:</label></div>\
						<div class="col-md-8 textarea">\
							<textarea class="optionText form-control" style="" xid="option"></textarea>\
						</div>\
						<div class="col-md-1 radio_delete">\
							<label class="answerBox"><input id="type1Answer' + childEsIndex + i + '" class="setAnswer" name="type1Answer' + childEsIndex + '" type="radio" xid="isAnswer" value="' + i + '" /></label>\
							<div><a class="btnDeleteOption" xid="btnDeleteOption">删除</a></div>\
						</div>\
					</div>';
				
			}
			oChildEs.find('div[xid="wrapAnswer"]').html(addOptionHtml);
			return false;
		});

		/**
		 * 设置多选子题的选项数量
		 */
		oForm.delegate('button[xid="btnSetMultipleOptionCount"]', 'click', function(){
			var oCount = $(this).parent().prev().find(':text');
			if(!oCount.length){
				UBox.show('未能找到数量设置');
			}
			var blankCount = parseInt(oCount.val());
			if(!blankCount){
				UBox.show('请输入正确的选项数量!', -1);
				return;
			}

			var addOptionHtml = ''
			,oChildEs = oCount.closest('div[xid="childEs"]')
			,childEsIndex = oChildEs.attr('itemid');
//			for(var i = 0; i < blankCount; i++){
//				addOptionHtml += '<div class="item" xid="wrapOption">\
//					<div class="name">选项<span class="optionCaption" xid="optionCaption">' + (parseInt(i) + 1) + '</span>：</div>\
//					<div class="control">\
//						<textarea class="optionText" xid="option"></textarea>\
//						<div class="do">\
//							<label class="answerBox"><input id="type2Answer' + childEsIndex + i + '" class="setAnswer" name="type2Answer' + childEsIndex + '" type="checkbox" xid="isAnswer" value="' + i + '" /></label>\
//							<a class="btnDeleteOption" xid="btnDeleteOption">删除</a>\
//						</div>\
//					</div>\
//				</div>';
//			}
			for(var i = 0; i < blankCount; i++){
				addOptionHtml += '\
					<div class="item row" xid="wrapOption">\
						<div class="col-md-1 option"><label class="control-label">选项<span class="optionCaption" xid="optionCaption">' + (parseInt(i) + 1) + '</span>:</label></div>\
						<div class="col-md-8 textarea">\
							<textarea class="optionText form-control" style="" xid="option"></textarea>\
						</div>\
						<div class="col-md-1 radio_delete">\
							<label class="answerBox"><input id="type2Answer' + childEsIndex + i + '" class="setAnswer" name="type2Answer' + childEsIndex + '" type="checkbox" xid="isAnswer" value="' + i + '" /></label>\
							<div><a class="btnDeleteOption" xid="btnDeleteOption">删除</a></div>\
						</div>\
					</div>';
				
			}
			oChildEs.find('div[xid="wrapAnswer"]').html(addOptionHtml);
			return false;
		});

		/**
		 * 设置填空题填空数量
		 * @param {type} childEsIndex 子题序号
		 * @returns {undefined}
		 */
		oForm.delegate('button[xid="btnSetBlank"]', 'click', function(){
			var oCount = $(this).prev(':text');
			if(!oCount.length){
				UBox.show('未能找到数量设置');
			}
			var blankCount = parseInt(oCount.val());
			if(!blankCount){
				UBox.show('请输入正确的选项数量!', -1);
				return;
			}

			var allBlankHtml = '';
			for(var i = 0; i < blankCount; i++){
				allBlankHtml += _buildBlankItemHTML([], i);
			}

			oCount.closest('div[xid="childEs"]').find('div[xid="wrapAnswer"]').html(allBlankHtml);
			return false;
		});

		/**
		 * 增加一个填空区域
		 */
		oForm.delegate('button[xid="btnAddBlank"]', 'click', function(){
			var oChildEs = $(this).closest('div[xid="childEs"]')
			,oContent = oChildEs.find('textarea[xid="content"]')[0],
			siteCursor = oContent.selectionStart;

			//扫描光标左右两边有没有填空标识
			for(var i = siteCursor; i < siteCursor + self.fillBlank.ANSWER_MARK.length + 1; i++){
				var checkValue = oContent.value.substr(i - self.fillBlank.ANSWER_MARK.length, self.fillBlank.ANSWER_MARK.length);
				if(checkValue == self.fillBlank.ANSWER_MARK){
					UBox.show('不可以连续填充两个答案', -1);
					oContent.focus();
					return;
				}
			}

			//分离光标左右两端的字符串
			var leftStr = oContent.value.substr(0, siteCursor),
			rightStr = oContent.value.substr(siteCursor);
			leftStr += ' ';
			rightStr = ' ' + rightStr;
			siteCursor++;

			//确定插入填空项的序列号
			var reg = new RegExp(self.fillBlank.ANSWER_MARK, 'g'),
			matchResult = leftStr.match(reg),
			itemIndex = matchResult == null ? 0 : matchResult.length;

			//开始插入填空项
			var answerItemHTML = _buildBlankItemHTML([], itemIndex);
			//根据光标周围的情况来确定如何添加填空项
			if(oChildEs.find('[xid="blank"]').length == 0){
				////当前没有填空项,则在框里直接append
				oChildEs.find('[xid="wrapAnswer"]').append(answerItemHTML);
			}else if(itemIndex == 0){
				//如果光标在所有填空项的前面,则在第一个填空项的前面添加
				oChildEs.find('[xid="blank"]:first').before(answerItemHTML);
			}else{
				//如果光标位置的左边和右边都有填空项,则在光标左边那个填空项对应序号的后面追加填空项
				oChildEs.find('[xid="blank"]').eq(itemIndex - 1).after(answerItemHTML);
			}

			leftStr += ' ' + self.fillBlank.ANSWER_MARK + ' '; //追加填空标识符
			oContent.value = leftStr + rightStr; //重置追加填空标识符后的题干内容
			siteCursor += self.fillBlank.ANSWER_MARK.length + 3;    //光标按照填空标识符长度偏移再设置光标起始和结束位置和空格长度
			oContent.selectionStart = siteCursor;
			oContent.selectionEnd = siteCursor;
			oContent.focus();
			oChildEs.find('[xid="blankCaption"]').each(function(i){
				//重置各填空项的序号,即在1和2之间插入后,将原来的第2个序号重置为3之类的重置工作
				$(this).text(i + 1);
			});
			return false;
		});

		oForm.delegate('button[xid="btnResetBlankByText"]', 'click', function(){
			var oChildEs = $(this).closest('div[xid="childEs"]')
			,oContent = oChildEs.find('textarea[xid="content"]')[0],
			text = oContent.value;
			var reg = /[_]{4,}/g;
			var matchResult = text.match(reg),
			answerCount = matchResult == null ? 0 : matchResult.length;
			if(answerCount > 0){
				text = text.replace(reg, ' ' +	self.fillBlank.ANSWER_MARK + ' ');
				text = text.replace(/ {2,}_{4,}/g, ' ' + self.fillBlank.ANSWER_MARK);
				text = text.replace(/_{4,} {2,}/g, self.fillBlank.ANSWER_MARK + ' ');
				oContent.value = text;
			}
			var answerWrap = oChildEs.find('[xid="wrapAnswer"]').empty();
			for(var i = 0; i < answerCount; i++){
				var answerItemHTML = _buildBlankItemHTML([], i);
				answerWrap.append(answerItemHTML);
			}
			return false;
		});

		oForm.delegate('[xid="del"]', 'click', function(){
			var oChildEs = $(this).closest('[xid="childEs"]');
			UBox.confirm(
				'您确定要删除吗?',
				function(){
					oChildEs.slideUp('normal', function(){
						$(this).remove();
						_resetChildEsCaptionIndex(oForm);
					});
				}
			);
			return false;
		});

		_resetChildEsCaptionIndex(oForm);

		return oForm;
	},

	/**
	 * 构建复合题数据
	 * @param {type} oEs 题目DOM对象
	 * @returns 题目数据
	 */
	buildComplexEsData : function(oEs){
		var aEs = oEs.data('es');
		aEs.es_content.content = oEs.find('textarea[xid="mainContent"]').val().replace(/(\s*$)/g, '');

		//收集题干图片
		var oContentImages = oEs.find('[xid="wrapImagesContent"] [xid="imageItem"]');
		if(oContentImages.length){
			aEs.es_content.image = _buildImagesData(oContentImages);
		}else{
			aEs.es_content.image = undefined;
		}

		aEs.es_content.es_item = [];
		oEs.find('[xid="childEs"]').each(function(i){
			var oChildEsDom = $(this);

			//初步生成题目数据基础结构
			var aChildEs = {
				type : parseInt(oChildEsDom.find(':hidden[xid="type"]').val()),
				content : {
					content : '',
					answer : null
				}
			};

			//取子题的题干
			aChildEs.content.content = $.trim(oChildEsDom.find('textarea[xid="content"]').val());
			//用于辅助下面验证的临时数据变量
			if(self.isSingleChoice(aChildEs.type) || self.isMultipleChoice(aChildEs.type)){
				//取单选和多选题题选项
				aChildEs.content.option = [];
				oChildEsDom.find('textarea[xid="option"]').each(function(){
					aChildEs.content.option.push({
						content : $.trim(this.value)
					});
				});

				if(self.isSingleChoice(aChildEs.type)){
					//取单选子题答案
					aChildEs.content.answer = parseInt(oChildEsDom.find(':radio[xid="isAnswer"]:checked').val());
				}else if(self.isMultipleChoice(aChildEs.type)){
					//取多选子题答案
					aChildEs.content.answer = [];
					oChildEsDom.find(':checkbox[xid="isAnswer"]:checked').each(function(j){
						aChildEs.content.answer.push(this.value);
					});
				}
			}else if(self.isJudgment(aChildEs.type)){
				//取判断题答案
				aChildEs.content.answer = oChildEsDom.find(':radio:checked').val();

			}else if(self.isFillBlank(aChildEs.type)){
				//取填空题答案
				aChildEs.content.answer = [];
				oChildEsDom.find(':text[xid="option"]').each(function(){
					var answer = $.trim(this.value);
					if(answer){
						aChildEs.content.answer.push(answer.split('|'));
					}
				});
				if(!aChildEs.content.answer.length){
					aChildEs.content.answer = undefined;
				}
			}
			aEs.es_content.es_item.push(aChildEs);
		});
		return aEs;
	},

	/**
	 * 检查复合题的数据
	 * @param {type} aEsContent 题目数据
	 * @returns {Boolean} 是否合法
	 */
	checkComplexEsData : function(aEsContent){
		if(aEsContent.content.length == 0){
			UBox.show('请输入大题干内容', -1);
			return false;
		}
		if(!aEsContent.es_item.length){
			UBox.show('请添加小题', -1);
			return false;
		}

		for(var i in aEsContent.es_item){
			i = parseInt(i);
			var aEsItem = aEsContent.es_item[i];
			if(aEsItem.content.content.length == 0 && (aEsItem.type == 3 || aEsItem.type == 4)){
				//单选和多选可以没有题干只有选项
				UBox.show('请填写第' + (i + 1) + '题的题干', -1);
				return false;
			}

			if(aEsItem.type == 1 || aEsItem.type == 2){
				for(var j in aEsItem.content.option){
					j = parseInt(j);
					if(!$.trim(aEsItem.content.option[j].content)){
						UBox.show('请补充第' + (i + 1) + '小题的第' +  (j + 1) + '个选项', -1);
						return false;
					}
				}

				if(aEsItem.type == 1){
					if(aEsItem.content.answer === undefined){
						UBox.show('请选择第' + (i + 1) + '小题的正确答案', -1);
						return false;
					}
				}else if(aEsItem.type == 2){
					if(!aEsItem.content.answer.length){
						UBox.show('请选择第' + (i + 1) + '小题的正确答案', -1);
						return false;
					}
				}
			}else if(aEsItem.type == 3 && aEsItem.content.answer === undefined){
				UBox.show('请选择第' + (i + 1) + '小题的答案', -1);
				return false;
			}else if(aEsItem.type == 4){
				if(!aEsItem.content.answer.length){
					UBox.show('请补充第' + (i + 1) + '小题的填空', -1);
					return false;
				}

				for(var j in aEsItem.content.answer){
					j = parseInt(j);
					for(var k in aEsItem.content.answer[j][k]){
						if(!$.trim(aEsItem.content.answer[j][k])){
							UBox.show('请补充第' + (i + 1) + '小题的第' +  (j + 1) + '个空', -1);
							return false;
						}
					}
				}
			}
		}

		return true;
	}

	/**
	 * 获取用户的单选题作答
	 */
	,getUserAnswerFromSingleChoiseEs : function(oEsDom){
		var oCheckedDom = oEsDom.find(':radio:checked');
		return oCheckedDom.length ? oCheckedDom.val() : '';
	}

	/**
	 * 获取用户的多选题作答
	 */
	,getUserAnswerFromMultipleChoiseEs : function(oEsDom){
		var oCheckedDom = oEsDom.find(':checkbox:checked'), aAnswer = [];
		if(oCheckedDom.length > 0){
			oCheckedDom.each(function(){
				aAnswer.push(this.value);
			});
		}
		return aAnswer;
	}

	/**
	 * 获取用户的判断题作答
	 */
	,getUserAnswerFromJudgmentEs : function(oEsDom){
		return oEsDom.find('[xid="answer"]').val();
	}

	/**
	 * 获取用户的填空题作答
	 */
	,getUserAnswerFromFillBlankEs : function(oEsDom){
		var aAnswer = [];
		oEsDom.find('[xid="answer"]').each(function(){
			aAnswer.push($.trim(this.value));
		});
		return aAnswer;
	}

	/**
	 * 获取用户的复合题作答
	 */
	,getUserAnswerFromComplexEs : function(oEsDom){
		var aAnswerList = [];
		oEsDom.find('[xid="childEs"]').each(function(i){
			var oEsItemDom = $(this);
			if(oEsItemDom.data('is_has_answer')){
				return true;
			}
			var type = oEsItemDom.data('type'),
			answer = null;
			if(type == 1){
				answer = self.getUserAnswerFromSingleChoiseEs(oEsItemDom);
			}else if(type == 2){
				answer = self.getUserAnswerFromMultipleChoiseEs(oEsItemDom);
			}else if(type == 3){
				answer = self.getUserAnswerFromJudgmentEs(oEsItemDom);
			}else if(type == 4 || type == 5){
				answer = self.getUserAnswerFromFillBlankEs(oEsItemDom);
			}
			aAnswerList.push({
				index : i,
				answer : answer,
				type : type
			});
		});
		return aAnswerList;
	}

	,buildDetail : function(aEs){
		var $oDetail = null;
		if(self.isSingleChoice(aEs.type_id)){
			$oDetail = self.buildSingleChoiceDetail(aEs);
		}else if(self.isMultipleChoice(aEs.type_id)){
			$oDetail = self.buildMultipleChoiceDetail(aEs);
		}else if(self.isJudgment(aEs.type_id)){
			$oDetail = self.buildJudgmentDetail(aEs);
		}else if(self.isFillBlank(aEs.type_id)){
			$oDetail = self.buildFillBlankDetail(aEs);
		}else if(self.isComplex(aEs.type_id)){
			$oDetail = self.buildComplexDetail(aEs);
		}
		if(aEs.subject_id == 2){
			self.drawMathExpression($oDetail);	//绘制数学公式
		}
		return $oDetail;
	}

	/**
	 * 构建题目表单
	 * @param {type} aEs
	 */
	,buildForm : function(aEs){
		var $form = null;
		if(self.isSingleChoice(aEs.type_id)){
			$form = self.buildSingleChoiceForm(aEs);
		}else if(self.isMultipleChoice(aEs.type_id)){
			$form = self.buildMultipleChoiceForm(aEs);
		}else if(self.isJudgment(aEs.type_id)){
			$form = self.buildJudgmentForm(aEs);
		}else if(self.isFillBlank(aEs.type_id)){
			$form = self.buildFillBlankForm(aEs);
		}else if(self.isComplex(aEs.type_id)){
			$form = self.buildComplexForm(aEs);
		}

		/**
		 * 删除图片按钮的监听
		 */
		$form.delegate('[xid="btnDeleteImage"]', 'click', function(){
			_deleteUploadImage($(this));
		});

		$form.getAnswer = function () {
			var aEs = this.buildEsData();
			if(!self.isComplex(aEs.type_id)){
				return aEs.es_content.answer;
			}else{
				var aAnswerList = [];
				for(var i in aEs.es_content.es_item){
					var aEsItem = aEs.es_content.es_item[i].content;
					aAnswerList.push(aEsItem.answer);
				}
				return aAnswerList;
			}
		};
		return $form;
	}

	/**
	 * 填空题属性
	 */
	,fillBlank : {
		ANSWER_MARK : '____',
		ANSWER_CAPTION : '填空',
		aAnswerGroupChineseId : ['①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩']
	}

	/**
	 * 复合题辅助对象
	 */
	,complex : {
		childEsCount : 0,	//添加的子题数量

		/**
		 * 构建复合单选子题的HTML
		 * @param {type} aEs
		 * @param {type} childEsId
		 * @returns {String}
		 */
		buildChildSingleChoiceFormHtml : function(aEs, childEsId){
			var optionHtml = '';
			for(var i in aEs.option){
				var checked = aEs.answer == i ? 'checked="cheched"' : '';
				optionHtml += '\
					<div class="item row" xid="wrapOption">\
						<div class="col-md-1 option"><label class="control-label">选项<span class="optionCaption" xid="optionCaption">' + (parseInt(i) + 1) + '</span>:</label></div>\
						<div class="col-md-8 textarea">\
							<textarea class="optionText form-control" style="" xid="option">' + aEs.option[i].content + '</textarea>\
						</div>\
						<div class="col-md-1 radio_delete">\
							<label class="answerBox"><input id="type1Answer' + childEsId + i + '" class="setAnswer" name="type1Answer' + childEsId + '" type="radio" ' + checked + ' xid="isAnswer" value="' + i + '" /></label>\
							<div><a class="btnDeleteOption" xid="btnDeleteOption">删除</a></div>\
						</div>\
					</div>';
			}
			return '<div class="questions panel panel-default col-md-offset-1" id="childEs' + childEsId + '" xid="childEs" itemid="' + childEsId + '">\
				<input type="hidden" xid="type" value="1" />\
				<div class="panel-heading"><legend>第<b xid="childEsIndex"></b>小题：</legend></div>\
				<div class="panel-body">\
					<a  xid="del">删除</a>\
					<div class="container-fluid">\
						<div class="row">\
							<div class="col-md-1 vignette"><label class="control-label">题干：</label></div>\
							<div class="col-md-9 textarea"><textarea  class="form-control" rows="6" name="child[' + childEsId + '][content]" xid="content">' + aEs.content + '</textarea></div>\
						</div>\
					</div>\
					<div class="tip c"><span>选项内容</span><span class="col-md-offset-8">设为答案</span></div>\
					<div class="item wrapAnswer c container-fluid" xid="wrapAnswer">' + optionHtml + '</div>\
				</div>\
				<div class="item setnumber c panel-footer">\
					<div class="container-fluid">\
						<div class="row">\
							<div class="col-md-2  text-right" style="padding:0;"><label class="control-label">选项数量：</label></div>\
							<div class="col-md-1 item_text"><input class="form-control" type="text"/></div>\
							<div class="col-md-1 item_radio"><button class="btn btn-default" type="button" xid="btnSetSingleOptionCount">设置</button></div>\
						</div>\
					</div>\
				</div>\
			</div>';

		},

		buildChildMultipleChoiceFormHtml : function(aEs, childEsId){
			var optionHtml = '';
			for(var i in aEs.option){
				var checked = jsTools.inArray(i, aEs.answer) ? 'checked="checked"' : '';
				optionHtml += '\
					<div class="item row" xid="wrapOption">\
						<div class="col-md-1" style="padding:0;"><label class="control-label">选项<span class="optionCaption" xid="optionCaption">' + (parseInt(i) + 1) + '</span>:</label></div>\
						<div class="col-md-8" style="padding:0;">\
							<textarea class="optionText form-control" style="" xid="option">' + aEs.option[i].content + '</textarea>\
						</div>\
						<div class="col-md-1" style="padding:0;margin-left:15px;">\
							<label class="answerBox"><input id="type1Answer' + childEsId + i + '" class="setAnswer" name="type1Answer' + childEsId + '" type="checkbox" ' + checked + ' xid="isAnswer" value="' + i + '" /></label>\
							<div><a class="btnDeleteOption" xid="btnDeleteOption">删除</a></div>\
						</div>\
					</div>';
			}

			return '<div class="questions panel panel-default col-md-offset-1 MultipleChoice"  id="childEs' + childEsId + '" xid="childEs" itemid="' + childEsId + '">\
				<input type="hidden" xid="type" value="2" />\
				<div class="panel-heading"><legend>第<b xid="childEsIndex"></b>小题：</legend></div>\
				<div class="panel-body">\
					<a  xid="del">删除</a>\
					<div class="container-fluid">\
						<div class="row">\
							<div class="col-md-1"><label class="control-label">题干：</label></div>\
							<div class="col-md-9"><textarea  class="form-control" rows="6" name="child[' + childEsId + '][content]" xid="content">' + aEs.content + '</textarea></div>\
						</div>\
					</div>\
					<div class="tip c"><span>选项内容</span><span class="col-md-offset-8">设为答案</span></div>\
					<div class="item wrapAnswer c container-fluid" xid="wrapAnswer">' + optionHtml + '</div>\
				</div>\
				<div class="item setnumber c panel-footer">\
					<div class="container-fluid">\
						<div class="row">\
							<div class="col-md-2  text-right"><label class="control-label">选项数量：</label></div>\
							<div class="col-md-1 _text"><input class="form-control" type="text"/></div>\
							<div class="col-md-1" ><button class="btn btn-default" type="button" xid="btnSetMultipleOptionCount">设置</button></div>\
						</div>\
					</div>\
				</div>\
			</div>';
		},

		buildChildJudgmentFormHtml : function(aEs, childEsIndex){
			var isRight = '';
			var isWrong = '';
			if(aEs.answer == 1){
				isRight = 'checked="checked"';
			}else if(aEs.answer == 0){
				isWrong = 'checked="checked"';
			}

			return '<div  class="questions panel panel-default col-md-offset-1" id="childEs' + childEsIndex + '" xid="childEs" itemid="' + childEsIndex + '">\
				<input type="hidden" xid="type" value="3" />\
				<div class="panel-heading"><legend>第<b xid="childEsIndex"></b>小题：</legend></div>\
					<div class="panel-body">\
						<a class="questions_del" xid="del">删除</a>\
						<div class="container-fluid">\
							<div class="row">\
							<div class="col-md-1" style="padding:0;"><label class="control-label">题干：</label></div>\
							<div class="col-md-9" style="padding:0;"><textarea class="form-control" rows="5" name="child[' + childEsIndex + '][content]" xid="content">' + aEs.content + '</textarea></div>\
							</div>\
							<div class="row">\
								<div class="col-md-1" style="padding:0;"><label class="control-label">答案：</label></div>\
								<div class="col-md-5">\
									<div class="radio">\
										<label"><input type="radio" id="right' + childEsIndex + '" name="judge' + childEsIndex + '" value="1" ' + isRight + ' />是(正确)</label>\
										<label><input type="radio" id="wrong' + childEsIndex + '" name="judge' + childEsIndex + '" value="0" ' + isWrong + ' />否(错误)</label>\n\
									</div>\
								</div>\
							</div>\
						</div>\
				</div>\
			</div>';
		},

		buildChildFillBlankFormHtml : function(aEs, childEsIndex){
			var answerHtml = '';
			for(var i in aEs.answer){
				answerHtml += _buildBlankItemHTML(aEs.answer[i], i);
			}

			return '<div class="questions panel panel-default col-md-offset-1" id="childEs' + childEsIndex + '" xid="childEs" itemid="' + childEsIndex + '">\
				<input type="hidden" xid="type" value="4" />\
				<div class="panel-heading"><legend>第<b xid="childEsIndex"></b>小题：</legend></div>\
				<div class="panel-body">\
					<a class="" xid="del">删除</a>\
					<div class="container-fluid">\
						<div class="row">\
							<div class="col-md-1" style="padding:0;"><label class="control-label">题干：</label></div>\
							<div class="col-md-9" style="padding:0;"><textarea rows="5" class="form-control" xid="content">' + aEs.content + '</textarea></div>\</div>\
						</div>\
						<div class="row">\
							<div class="col-md-2" style="padding-right:0;"><label class="control-label">预览：</label1></div>\
							<div class="control" id="ImgPreview' + childEsIndex + '"></div>\
						</div>\
						<div class="row">\
							<div class="col-md-2 text-right" style="padding:0px;margin-left:15px;"><label class="control-label">填空数量：</label></div>\
							<div class="col-md-1" style="padding:0;"><input class="form-control" type="text"/></div>\
							<div class="col-md-1"><button class="btn" type="button" xid="btnSetBlank">设置</button></div>\
							<div class="col-md-1" style="margin-left:-5px;"><button class="btn" type="button" xid="btnAddBlank">添加填空区域</button></div>\
							<div class="col-md-1" style="margin-left:50px;"><button class="btn" type="button" xid="btnResetBlankByText">根据内容生成填空区域</button></div>\
							</div>\
						</div>\
						<div class="wrapAnswer" xid="wrapAnswer">' + answerHtml + '</div>\
					</div>\
				</div>\
			</div>';
		}
	},

	/**
	 * 获取默认的题目空数据结构
	 * @param {type} type 题型
	 * @returns {_L1.window.Esp.getDefaultData.Anonym$7}
	 */
	getDefaultData : function(type){
		var aEsContent = null;
		type = parseInt(type);
		if(jsTools.inArray(type, self.type.SINGLE_CHOICE)){
			aEsContent = {
				content : '',
				option : [
					{content : ''},
					{content : ''},
					{content : ''},
					{content : ''}
				],
				answer : null
			};
		}else if(jsTools.inArray(type, self.type.MULTIPLE_CHOICE)){
			aEsContent = {
				content : '',
				option : [
					{content : ''},
					{content : ''},
					{content : ''},
					{content : ''}
				],
				answer : []
			};

		}else if(jsTools.inArray(type, self.type.JUDGMENT)){
			aEsContent = {
				content : '',
				answer : null
			};

		}else if(jsTools.inArray(type, self.type.FILL_BLANK)){
			aEsContent = {
				content : '',
				answer : []
			};

		}else if(jsTools.inArray(type, self.type.COMPLEX)){
			aEsContent = {
				content : '',
				es_item : []
			};
		}
		return {
			id : 0,
			type_id : type,
			es_content : aEsContent
		};
	},

	/**
	 * 按指定科目重新渲染字体
	 * @param {dom} $SubjectDom 要渲染字体的jQuery DOM
	 * @param {int} subjectId 科目
	 */
	renderFont : function ($SubjectDom, subjectId) {
		var classType = '';
		switch (subjectId) {
			case 1:
				classType = 'subject1';
				break;
			case 2:
				classType = 'subject2';
				break;
			case 3:
				classType = 'subject3';
				break;
		}
		$SubjectDom.addClass(classType);
	},
	
	/**
	 * 过滤复合题的子题
	 * @param {object} aData 复合题数据结构
	 * @param {array<int>} aSaveItemIndexs 过滤后要保留的子题索引
	 * @return {object} 过滤后的数据
	 */
	filterComplexData : function(aData, aSaveItemIndexs){
		var aCloneData = jsTools.clone(aData);
		for(var i in aCloneData.es_content.es_item){
			if(!jsTools.inArray(i, aSaveItemIndexs)){
				delete aCloneData.es_content.es_item[i];
			}
		}
		return aCloneData;
	}
};

/**
 * JS辅助工具
 */
var jsTools = {
	/**
	 * 检测一个变量是否对象
	 */
	isObject : function(variable){
		return typeof(variable) == 'object' && Object.prototype.toString.call(variable).toLowerCase() == '[object object]' && !variable.length;
	},

	/**
	 * 合并两个数组或对象
	 */
	merge : function(obj1, obj2) {
		var oTmpObj1 = this.clone(obj1);
		if($.isArray(obj1) && $.isArray(obj2)){
			for(var i in obj2){
				if($.inArray(obj2[i], oTmpObj1) === -1){
					oTmpObj1.push(obj2[i]);
				}
			}
		}else if($.isPlainObject(obj1) && $.isPlainObject(obj2)){
			for(var key in obj2) {
				if(oTmpObj1.hasOwnProperty(key) || obj2.hasOwnProperty(key)){
					oTmpObj1[key] = obj2[key];
				}
			}
		}
		return this.clone(oTmpObj1);
	},

	/**
	 * 判断一个元素是否在数组内
	 * @param {type} value 元素值
	 * @param {type} array 数组
	 * @param {type} isStrict 是否严格模式
	 * @returns {Boolean}
	 */
	inArray : function(value, array, isStrict){
		for(var i in array){
			if(array[i] == value && !isStrict){
				return true;
			}else if(array[i] === value && isStrict){
				return true;
			}
		}
		return false;
	},

	/**
	 * 克隆一个数组或对象
	 */
	clone : function(oObj){
		if(oObj == null || typeof(oObj) !== 'object'){
			return oObj;
		}
		var oTempObj = new oObj.constructor();
		for(var key in oObj){
			oTempObj[key] = arguments.callee(oObj[key]);
		}
		return oTempObj;
	},

	shuffle : function(aArray){
		var aShuffleArray = this.clone(aArray);
		aShuffleArray.sort(function(key, value){
			return Math.random() > 0.5 ? -1 : 1;//用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
		});
		return aShuffleArray;
	}
};

/**
 * 构建题目数据
 * @returns {unresolved}
 */
$.fn.buildEsData = function(){
	var oEs = $(this),
	aEs = oEs.data('es');
	if(jsTools.inArray(aEs.type_id, self.type.SINGLE_CHOICE)){
		return self.buildSingleChoiseEsData(oEs);
	}else if(jsTools.inArray(aEs.type_id, self.type.MULTIPLE_CHOICE)){
		return self.buildMultipleChoiseEsData(oEs);
	}else if(jsTools.inArray(aEs.type_id, self.type.JUDGMENT)){
		return self.buildJudgmentEsData(oEs);
	}else if(jsTools.inArray(aEs.type_id, self.type.FILL_BLANK)){
		return self.buildFillBlankEsData(oEs);
	}else if(jsTools.inArray(aEs.type_id, self.type.COMPLEX)){
		return self.buildComplexEsData(oEs);
	}
};

/**
 * 验证题目数据是否可以提交
 * @param {type} aEs 数目数据
 * @returns {unresolved} 是否通过验证
 */
$.fn.validate = function(){
	var aEs = $(this).buildEsData();
	if(jsTools.inArray(aEs.type_id, self.type.SINGLE_CHOICE)){
		return self.checkSingleChoiseEsData(aEs.es_content);
	}else if(jsTools.inArray(aEs.type_id, self.type.MULTIPLE_CHOICE)){
		return self.checkMultipleChoiseEsData(aEs.es_content);
	}else if(jsTools.inArray(aEs.type_id, self.type.JUDGMENT)){
		return self.checkJudgmentEsData(aEs.es_content);
	}else if(jsTools.inArray(aEs.type_id, self.type.FILL_BLANK)){
		return self.checkFillBlankEsData(aEs.es_content);
	}else if(jsTools.inArray(aEs.type_id, self.type.COMPLEX)){
		return self.checkComplexEsData(aEs.es_content);
	}
};

/**
 *
 * @param {type} options
 * @returns {unresolved}textarea 高度自动增加
 */
$.fn.autoTextarea = function(options) {
	var defaults={
		maxHeight:null,//文本框是否自动撑高，默认：null，不自动撑高；如果自动撑高必须输入数值，该值作为文本框自动撑高的最大高度
		minHeight:$(this).height() //默认最小高度，也就是文本框最初的高度，当内容高度小于这个高度的时候，文本以这个高度显示
	};
	var opts = $.extend({},defaults,options);
	return $(this).each(function() {
		$(this).bind("paste cut keydown keyup focus blur",function(){
			var height,style = this.style;
			this.style.height =  opts.minHeight + 'px';
			if (this.scrollHeight > opts.minHeight) {
				if (opts.maxHeight && this.scrollHeight > opts.maxHeight) {
				height = opts.maxHeight;
				style.overflowY = 'scroll';
			} else {
				height = this.scrollHeight;
				style.overflowY = 'hidden';
			}
				style.height = height  + 'px';
			}
		});
	});
};



/**
 * 重置子题标题序号
 */
function _resetChildEsCaptionIndex(oForm){
	oForm.find('[xid="childEsIndex"]').each(function(j){
		$(this).html(j + 1);
	});
}

/**
 * 构建图片单元的HTML
 * @param {type} imagePath
 * @param {type} imageIndex
 * @returns {String}
 */
function _buildImageItemHtml(imagePath, imageIndex){
	imageIndex = parseInt(imageIndex);
	return '<div class="uploadPic" style="margin-bottom:10px;margin-right:35px;position:relative;width:105px;" xid="imageItem" itemid="' + imageIndex + '">\
		<a xid="btnDeleteImage" style="background: url(' + _aConfig.rootPath + 'image_del.gif) no-repeat scroll 0 0 transparent;display: block;height: 17px;position: absolute;top:-8px;left:97px;width: 17px;z-index: 100;"></a>\
		<div class="imageBox" style="border: 1px solid #0066CC;height: 105px;padding: 5px;width: 105px;border: 1px solid #0066CC;height: 105px;padding: 5px;width: 105px;">\
			<img style="width:100%;height:100%" src="' + _aConfig.imageBaseUrl + imagePath + '"/>\
		</div>\
		<input style="width:105px;margin-top:5px;" type="text" class="imgInput text-center" xid="imageText" disabled="disabled" value="图' + (imageIndex + 1) + '" />\
		<input type="hidden" xid="image" value="' + imagePath + '" />\
	</div><div class="clearfix visible-xs-block"></div>';
}

/**
 * 构造HTML的题目内容
 */
function _buildHtmlContent(content){
	var regMath = /((\\\[){1}[\W\w]+?(\\\]){1})|((\\\(){1}[\W\w]+?(\\\)){1})/g;
	var matchMath = content.match(regMath);
	content = content.replace(/ (?= )/g, '&nbsp;')
	.replace(regMath, '#####')
	.replace(/\n/g, '<br/>');
	if(matchMath){
		for(var i = 0; i < matchMath.length; i++){
			content = content.replace('#####', matchMath[i]);
		}
	}
	return content;
}

/**
 * 构建图片上传按钮
 * @param {type} uploadButtonId 上传按钮原始DOM的ID
 * @param {type} outputId 图片输出框的ID
 * @returns {unresolved}
 */
function _buildUploadButton($oFileInput, oWrapImageOutput){
	$('<button type="button" class="btn btn-xs btn-warning btn-upload">添加图片</button>')
	.insertAfter($oFileInput.attr('name', '_es_image'))
	.click(function(){
		$oFileInput.trigger('click');
	});
	$oFileInput.change(function(){
		var oCloneFile = $oFileInput.clone();
		oCloneFile[0].files = $oFileInput[0].files;	//兼容谷歌浏览器
		$('<iframe src="javascript:void(0);" style="display:block;" name="__tmpUploadIframe"></iframe>').appendTo('body').load(function(){
			var oPre = this.contentDocument.body.firstChild;
			if(!oPre){
				UBox.show('上传出错！相关信息：' + this.contentDocument.body.innerHTML);
			}
			var aResult = $.parseJSON(oPre.innerHTML);
			if(!jsTools.isObject(aResult)){
				UBox.show('上传出错！相关信息：' + this.contentDocument.body.innerHTML);
			}

			if(aResult.status != 1){
				UBox.show(aResult.msg);
			}else{
				var imageCount = oWrapImageOutput.find('[xid="imageItem"]').length;
				oWrapImageOutput.append(_buildImageItemHtml(aResult.data, imageCount));
				_resetImageIndex(oWrapImageOutput);
			}
			$oForm.remove();
			$(this).remove();
		});

		var $oForm = $('<form style="display:none;" action="' + _aConfig.imageUploadUrl + '" method="POST" enctype="multipart/form-data" target="__tmpUploadIframe">\
				<input type="hidden" name="_csrf" value="' + $('meta[name="csrf-token"]').attr('content') + '">\
				<input type="hidden" name="_is_ajax" value="1" />\
			</form>').append(oCloneFile).appendTo('body');
		$oForm.submit();
	});
}

/**
 * 重置指定区域内的所有图片标题序号
 * @param {fn_object} oWrapImageOutput 图片列表外框DOM对象
 */
function _resetImageIndex(oWrapImageOutput){
	oWrapImageOutput.find('input[xid="imageText"]').each(function(i){
		$(this).val('图 ' + (i + 1));
	});
}

function _deleteUploadImage(oBtnDelete){
	var oImagesWrap = oBtnDelete.closest('[xid^="wrapImages"]');
	oBtnDelete.closest('[xid="imageItem"]').remove();
	_resetImageIndex(oImagesWrap);
}

function _deleteChoiceOption(){
	var oOption = $(this).closest('[xid="option"]'),
	oSiblings = oOption.siblings('[xid="option"]');
	if(oSiblings.length == 1){
		UBox.show('至少要有2个选项', -1);
		return false;
	}
	oOption.slideUp('normal', function(){
		$(this).remove();
		oSiblings.each(function(i){
			$(this).find('strong').text(String.fromCharCode(65 + i));
		});
	});
	return false;
}

/**
 * 根据填空内容重置填空区长度
 */
function _resetBlankLength(){
	var length = this.value.replace(/[^\u0000-\u00ff]/g, 'aa').length;
	if(length > 6){
		this.size = length;
	}
}

/**
 * 通过退格键(BackSpace)删除答案
 * @param {type} content
 * @returns {undefined}
 */
 function _deleteAnswerCharWidthBackSpace(content){
	var siteCursor = content.selectionStart,
	contentStr = content.value,
	ANSWER_MARK = self.fillBlank.ANSWER_MARK,
	answerChar = ANSWER_MARK.substr(0, 1),
	rlStr = _splitStringWithSite(contentStr, siteCursor);

	if(contentStr.length < 4){
		return;
	}else if(contentStr.substr(siteCursor - 1, 1) != answerChar){
		var tmpRightFirstChar = rlStr[1].slice(0,1),
		tmpRightLastChar = rlStr[1].substr(rlStr[1].length - 1);

		if(tmpRightFirstChar == answerChar || tmpRightLastChar == answerChar){
			siteCursor = content.selectionEnd;
			rlStr = _splitStringWithSite(contentStr, siteCursor);
		}
	}

	if(contentStr.length < 4 || contentStr.substr(siteCursor - 1, 1) != answerChar){
		if(rlStr[1].slice(0, 1) == answerChar || rlStr[0].slice(0, 1) != answerChar){
			siteCursor = content.selectionEnd;
			rlStr = _splitStringWithSite(contentStr, siteCursor);
		}
		return;
	}

	var leftStr = rlStr[0], rightStr = rlStr[1];

	var tmpStr = leftStr.slice(leftStr.length - ANSWER_MARK.length),
	leftCount = 0;  //左边的下划线数量

	if(tmpStr == ANSWER_MARK){
		leftCount = ANSWER_MARK.length;
	}else if(tmpStr.substr(tmpStr.length - 1) == answerChar){
		for(var j = tmpStr.length; j >= 0; j--){
			var tmpChar = tmpStr.substr(j - 1, 1);
			if(tmpChar != answerChar){
				break;
			}else{
				leftCount++;
			}
		}
	}

	leftStr = leftStr.substr(0, leftStr.length - leftCount + 1);

	if(rightStr != '' && leftCount < ANSWER_MARK.length){
		rightStr = rightStr.substr(ANSWER_MARK.length - leftCount);
	}

	content.value = leftStr + rightStr;
	siteCursor = leftStr.length;

	content.selectionStart = siteCursor;
	content.selectionEnd = siteCursor;

	var regResult = leftStr.match(new RegExp(ANSWER_MARK, 'g'));
	var leftAnswerCount = regResult == null ? 1 : regResult.length + 1;
	_deleteAnswerItem($(content), leftAnswerCount - 1);
}

/**
 * 通过回删键(Delete)删除答案
 * @param {type} content
 * @returns {undefined}
 */
function _deleteAnswerCharWidthDelete(content){
	var siteCursor = content.selectionStart,	//光标位置
	contentStr = content.value,	//内容
	ANSWER_MARK = self.fillBlank.ANSWER_MARK,	//填空标识
	answerChar = ANSWER_MARK.substr(0, 1);

	if(contentStr.length < ANSWER_MARK.length || contentStr.substr(siteCursor, 1) != answerChar){
		//如果内容长度小于填空标识的长度或者光标右边一个字符不是标识符的符号则不作处理
		return;
	}

	//分割成左右两边的字符串
	var aStrings = _splitStringWithSite(contentStr, siteCursor),
	leftStr = aStrings[0],
	rightStr = aStrings[1],
	tmpStr = rightStr.slice(0, ANSWER_MARK.length),
	rightAnswerMarkCount = 0;  //左边下划线的数量

	//计算光标右边下划线的数量
	if(tmpStr == ANSWER_MARK){
		//如果光标处于标识符最左边
		rightAnswerMarkCount = ANSWER_MARK.length;
	}else if(tmpStr.substr(0, 1) == answerChar){
		//如果光标右边有一个是标识符
		for(var j = 0; j < tmpStr.length; j++){
			var tmpChar = tmpStr.substr(j, 1);
			if(tmpChar != answerChar){
				break;
			}else{
				rightAnswerMarkCount++;
			}
		}
	}

	var rightSliceStart = 0;	//裁剪右边字符串的起始位置
	if(rightAnswerMarkCount > 0){
		rightSliceStart = rightAnswerMarkCount;
	}
	rightStr = rightStr.substr(rightSliceStart, rightStr.length - rightSliceStart);	//去除答案标签后的右边字符串
	var leftAnswerMarkCount = ANSWER_MARK.length - rightAnswerMarkCount;
	if(leftStr != '' && leftAnswerMarkCount){
		//如果左边有文字并且左边还有答案标识符
		leftStr = leftStr.substr(0, leftStr.length - leftAnswerMarkCount);
	}

	//重新设置内容并定位光标
	content.value = leftStr + rightStr;
	content.selectionStart = content.selectionEnd = leftStr.length;

	//删除相应的填空项DOM
	var regResult = leftStr.match(new RegExp(ANSWER_MARK, 'g'));
	var deleteAnswerIndex = regResult == null ? 0 : regResult.length;
	_deleteAnswerItem($(content), deleteAnswerIndex);
}

/**
 * 根据题目内容重新生成所有填空项
 */
function _resetAllFillBlankAnswer(){
	var oForm = $(this)
	,oContent = oForm.find('textarea[xid="esContent"]');
	if(!$.trim(oContent.val())){
		return;
	}
	var text = oContent.val();
	var onlyUnderline = document.getElementById('onlyUnderline');
	if(onlyUnderline.checked){
		var reg = /[_]{4,}/g;
	}else{
		var reg = /[ _]{4,}/g;
	}
	var matchResult = text.match(reg);
	var oAnswerWrap = oForm.find('[xid="answerWrap"]').empty(),
	answerCount = matchResult == null ? 0 : matchResult.length;
	if(answerCount == 0){
		return false;
	}
	text = text.replace(reg, self.fillBlank.ANSWER_MARK);
	oContent.val(text);
	for(var i = 0; i < answerCount; i++){
		oAnswerWrap.append(_getAnswerItemHtml([], i, ''));
		oForm.find('div[xid="answerItem"][itemid="' + i + '"]').animate({opacity : 1});
	}
}

/**
 * 添加不按顺序作答选项
 */
function _addFillBlankNorder(){
	var oForm = $(this);

	if(oForm.find('div[xid="answerItem"]').length <= 1){
		UBox.show('填空个数最少 2 个才可以添加答案组', -1);
		return false;
	}

	var colum = oForm.find('span[xid="norderGroupNum"]').length;	//答案组的列数
	oForm.find('div[xid="answerItem"]').each(function(row){
		$(this).find('span[xid="wrapNoOrderChk"]').append(_buildAnswerGroupCheckBoxHtml(row, colum, false));
	});

	var firstOption = oForm.find('div[xid="answerItem"]:first');
	var i = firstOption.find('span[xid="norderAction"]').length;
	firstOption.find(':checkbox').last().wrap('<span xid="norderAction" class="norderAction"></span>');
	firstOption.find('span[xid="norderAction"]').last().prepend('<span xid="norderGroupNum" class="norderGroupNum">' +  self.fillBlank.aAnswerGroupChineseId[i] + '</span><a class="delNorder" xid="delNorder" data-colum=' + colum + ' href="javascript:void(0)">×</a>');
}

function _buildAnswerGroupCheckBoxHtml(rowIndex, columIndex, isCheck){
	return '<input type="checkbox" class="norderOption"' + (isCheck ? ' checked="checked"' : '') + ' data-row="' + rowIndex + '" data-colum="' + columIndex + '" xid="norderOption" />';
}

function _buildImagesData(oImages){
	var aImage = [];
	oImages.each(function(){
		aImage.push($(this).find(':hidden[xid="image"]').val());
	});
	return aImage;
}

function _buildImageListHtml(aImageList, isOption){
	if(aImageList == undefined){
		return '';
	}

	var itemClass = isOption == undefined ? 'esp_main_image_item' : 'esp_option_item_content_image_item',
		wrapClass = isOption == undefined ? 'esp_main_image' : 'esp_option_item_content_image',
		result = '',
		aContentImageHtml = [];
	for(var i = 0; i < aImageList.length; i++){
		var imageIndex = aImageList.length > 1 ? '图' + (parseInt(i) + 1) : '';

		aContentImageHtml.push('<div class="' + itemClass + '">\
			' + Ui1.buildImage(_aConfig.imageBaseUrl + aImageList[i]) + '\
			<span>' + imageIndex + '</span>\
		</div>');
	}

	if(aImageList.length){
		result = '<div class="' + wrapClass + '">' + aContentImageHtml.join('') + '</div>';
	}
	return result;
}

/**
 * 删除一个填空题答案组
 */
function _delNorder(){
	var oClick = $(this);
	var norderId = oClick.attr('data-colum'),
	oAnswerWrap = oClick.closest('[xid="answerWrap"]'),
	aAnswerGroupChineseId = self.fillBlank.aAnswerGroupChineseId;

	oAnswerWrap.find(':checkbox[data-colum="' + norderId + '"]').remove();	//删除勾勾
	oClick.parent().remove();	//删除叉叉
	oAnswerWrap.find('span[xid="norderAction"] span[xid="norderGroupNum"]').each(function(i){
		//重置序号标题
		$(this).html(aAnswerGroupChineseId[i]);
	});

	var oAnswerList = oAnswerWrap.find('div[xid="answerItem"]');
	oAnswerList.each(function(){
		$(this).find('input[xid="norderOption"]').each(function(j){
			$(this).attr('data-colum', j);
		});

		$(this).find('a[xid="delNorder"]').each(function(j){
			$(this).attr('data-colum', j);
		});
	});
}

/**
 * 删除指定答案选项
 * @param {type} oContent
 * @param {type} index
 */
function _deleteAnswerItem(oContent, index){
	var oEs = oContent.closest('[xid="wrapEs"]');
	oEs.find('div[xid="answerItem"][itemid="' + index + '"]').animate({opacity:0}, function(){
		$(this).remove();
		_resetAnswerIndex(oEs);
	});
}

/**
 * 重置答案索引号
 * @returns {undefined}
 */
function _resetAnswerIndex(oEs){
	var ANSWER_CAPTION = self.fillBlank.ANSWER_CAPTION;
	oEs.find('div[xid="answerItem"]').each(function(i){
		i = parseInt(i);
		var answerItem = $(this);
		answerItem.attr('itemid', i);
		answerItem.find('span[xid="idCaption"]').text(ANSWER_CAPTION + (i + 1) + '：');
		answerItem.find('input[xid="norderOption"]').val(i);
	});
}

function _getAnswerItemHtml(aAnswer, itemIndex, answerGroupHtml){
	itemIndex = parseInt(itemIndex);
	if(!answerGroupHtml){
		answerGroupHtml = '';
	}
	var answerItemHTML = '<div class="answerItem" xid="answerItem" itemid="' + itemIndex + '">\
		<a class="deleteBlank" xid="deleteBlank" href="javascript:;">×</a>\
		<span class="idCaption" xid="idCaption">' + self.fillBlank.ANSWER_CAPTION + (itemIndex + 1) + '：</span>\
		<input type="text" class="form-control" xid="answerBlank" class="answerBlank" value="' + aAnswer.join('|') + '" />\
		<span class="wrapNoOrderChk" xid="wrapNoOrderChk">' + answerGroupHtml + '</span>\
		<br class="clear" />\
	</div>';
	return answerItemHTML;
}

function _buildBlankItemHTML(aContent, itemIndex){
	var answerItemHTML = '<div class="item row" style="margin-left:8px;" xid="blank">\
		<div class="col-md-1" style="padding:0;"><label class="control-label">填空<span class="blankCaption" xid="blankCaption">'+ (parseInt(itemIndex) + 1) +'</span>：</label></div>\
		<div class="col-md-9" style="padding:0; margin-bottom:5px;"><input style="width:35%" class="blankText form-control" type="text" xid="option" value="' + aContent.join('|') + '" /></div>\
	</div>';
	return answerItemHTML;
}

/**
 * 根据指定位置将题干内容分割成两部分
 * @param {type} strong 分割的字符
 * @param {type} site 分割的位置
 * @returns 分割后的数组,第一个元素是前半,第二个元素是后半
 */
function _splitStringWithSite(string, site){
	if(site == 0 || string.length < site){
		return false;
	}
	var text = string;

	return [text.slice(0, site), text.slice(site, text.length)];
}

function _isChoiceAnswer(answerIndex, answer, esType){
	if(esType == 1){
		return answerIndex == answer;
	}else if(esType == 2){
		for(var k in answer){
			if(answerIndex == answer[k]){
				return true;
			}
		}
		return false;
	}
}

function _getArrayRelation(aArray1, aArray2){
	var aRelation = [];
	for(var i = 0; i < aArray1.length; i++){
		for(var j = 0; j < aArray2.length; j++){
			if(aArray1[i] == aArray2[j]){
				aRelation[i] = j;
			}
		}
	}
	return aRelation;
}

function _convertFillBlankAnswer(answer){
	answer = answer.replace(/[Ａ]/g, 'A');
	answer = answer.replace(/[Ｂ]/g, 'B');
	answer = answer.replace(/[Ｃ]/g, 'C');
	answer = answer.replace(/[Ｄ]/g, 'D');
	answer = answer.replace(/[Ｅ]/g, 'E');
	answer = answer.replace(/[Ｆ]/g, 'F');
	answer = answer.replace(/[Ｇ]/g, 'G');
	answer = answer.replace(/[Ｈ]/g, 'H');
	answer = answer.replace(/[Ｉ]/g, 'I');
	answer = answer.replace(/[Ｊ]/g, 'J');

	answer = answer.replace(/[？]/g, '?');
	answer = answer.replace(/[！]/g, '!');
	answer = answer.replace(/[，]/g, ',');
	answer = answer.replace(/[。]/g, '.');
	answer = answer.replace(/[：]/g, ':');
	answer = answer.replace(/[‘’]/g, "'");
	answer = answer.replace(/[“”]/g, '"');
	answer = answer.replace(/[（]/g, '(');
	return answer.replace(/[）]/g, ')');
}

var self = window.Esp,
	_isInit = false,	//是否初始化过
	_src = $('script[src*="esp.js"]').attr('src') || $('script[real*="esp.js"]').attr('real') || '',	//esp脚本地址
	_path = _src.match(/(http:\/\/[^\/]+\/).+\//i) || ['', ''];		//插件目录与，资源根路径
	_aConfig = {
		rootPath : _path[0],		//插件所在目录
		imageBaseUrl : _path[1],	//图片资源域名
		imageUploadUrl : '',	//编辑题目时的图片上传地址
		shuffleChoise : true,	//显示题目问题时是否打乱选项的显示顺序
		showAllComplexItem : false
	};
})(jQuery, window);