/**
 * 微型的声音播放引擎
 * @author zhou
 */
(function(container, $){
/*
 * @param {string} audio_url 声音的路径
 * @param {json} aOptions 对象配置，格式:{ preload : true/false , volume : 1 - 100 }，preload 是是否预加载,音量是从1-100增大
 */
container.UmAudio = function(audioUrl, aOptions) {
	var self = this;
	self.aOptions = _parseOption(aOptions);
	self.audioUrl = _parseAudioUrl(audioUrl);
	self.audio = null;
	_init();

	$.extend(self, new Component());

	/*
	 * 播放声音，到结束为止，如果是暂停状态，点击继续播放，如果是停止状态，则重新播放
	 */
	self.play = function(){
		self.audio.play();
	};

	/*
	 * 暂停播放
	 */
	self.pause = function(){
		self.audio.pause();
	};

	/*
	 * 停止播放
	 */
	self.stop = function(){
		self.pause();
		self.audio.currentTime = 0;
	};

	/*
	 * 初始化声音
	 */
	function _init(){
		self.audio = new Audio();
		self.audio.autoplay = false;
		self.audio.loop = false;
		self.audio.volume = self.aOptions.volume / 100;
		if(self.aOptions.preload === true){
			self.audio.preload = 'auto';
		} else {
			self.audio.preload = 'none';
		}
		self.audio.src = self.audioUrl;
	}

	/**
	 * 配置解析
	 * @param {json} aOption
	 */
	function _parseOption(aOption){
		if( aOption === undefined ){
			aOption = {
				preload : false,
				volume : 100
			};
		}

		if( aOption.preload === undefined ){
			aOption.preload = false;
		}

		if( aOption.volume === undefined ){
			aOption.volume = 100;
		}

		return aOption;
	}

	/*
	 * 路径解析
	 */
	function _parseAudioUrl(audioUrl){
		return audioUrl;
	}

	/**
	 * 监听播放完毕
	 */
	self.audio.onended = function(){
		self.triggerEvent(UmAudio.EVENT_ON_FINISHED);
	};
};

/*
 * 声音播放完毕时候触发
 */
container.UmAudio.EVENT_ON_FINISHED = 'event_on_finished';
})(window, jQuery);

