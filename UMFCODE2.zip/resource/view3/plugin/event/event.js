(function($, win){
	win.EventPage = {
		MARK : 21,						//签到动态
		PASS_MISSION : 22,				//过关动态
		EXCHANGE_CARD : 23,				//兑换卡牌动态
		FINISH_MATCH : 24,				//完成比赛动态
		WIN_MATCH_WITH_GOLD : 25,		//比赛获奖有金币
		WIN_MATCH_WITHOUT_GOLD : 26,	//比赛获奖无金币
		WIN_PK_WITH_GOLD : 27,			//PK获胜有金币
		WIN_PK_WITHOUT_GOLD : 28,		//PK获胜无金币
		OPEN_VIP_PACKAGE : 29,			//打开会员礼包
		BIND_EMAIL : 30,				//绑定邮箱
		BUY_PROP : 31,					//购买道具
		EXCHANGE_GOODS : 32,			//兑换物品
		FINISH_DAILY_TASK : 33,			//完成每日任务
		PUBLISH_THREAD : 34,			//发表话题
		RECOMMEND_THREAD : 35,			//话题加精
		BECOME_VIP : 36,				//开通会员（包括续费）
		BECOME_FRIEND : 37,				//成为好友
		FIRST_PASS_PROFILE_APPROVE : 38,//上传头像首次通过审核
		THREAD_SUPPORT : 39,	//话题点赞加金币
		FIRST_BUY_PROP : 41,	//首次买道具加金币
		BBS_AVTIVE_USER : 42,	//BBS活跃用户加金币
		FIRST_RECHARGE_VIP : 43,		//首次充值VIP送金币
		FIRST_BIND_PHONE : 44,		//首次绑定手机
		ES_ANALYSIS_PASS : 45,		//题目解析审核通过加金币
		ES_ANALYSIS_FAIL : 46,		//题目解析审核没通过
		WIN_ONLINE_PK_ONE : 47,		//在线PK1v1获胜
		WIN_ONLINE_PK_three : 48,		//在线PK3v3获胜
		WIN_PK_ARENA : 49,		//PK擂台
		WIN_ONLINE_PK_ONE_GOLD	: 50,	//在线PK1v1获胜有金币
		WIN_ONLINE_PK_TREE_GOLD	: 51,	//在线PK3v3获胜有金币
		
		page : 1,
		totalPage : 0,
		type : '',
		event_type : '',
		target_user_id : 0,
		evenListUrl : '',
		matchDetailUrl: '',
		exchangeGoodDetailUrl: '',
		threadDetailUrl: '',
		openVipUrl: '',
		bindEmailUrl: '',
		missionPracticUrl: '',
		userInfoUrl: '',
		applyFriendUrl: '',
		sendMessageUrl: '',
		isGetEventListAjaxIng : false,
		oJpagebar : '',
		oWrapDom : '',
		oJeventtype : '',
		oJeventtab : '',
		oJeventtypetab : '',
		oDialog : '',

		showPageBar : function(){
			var pageBarMaxNum = 10,
			first = 1,
			end = parseInt(this.totalPage),
			htmlStr = '';
			first = Math.max(0, this.page - parseInt(pageBarMaxNum / 2));
			if ((end = first + pageBarMaxNum - 1) >= this.totalPage) {
				end = this.totalPage - 1;
				first = Math.max(0, end - pageBarMaxNum + 1);
			}

			first = first + 1;
			end = end + 1;
			if(this.page == 1){
				htmlStr += '<li class="prev disabled"><span>«</span></li>';
			}else{
				var prvePage = 1;
				if(first - 1 > 0){
					prvePage = first - 1;
				}else{
					prvePage = 1;
				}
				htmlStr += '<li class="prev"><a data-page="' + prvePage + '">«</a></li>';
			}
			first = parseInt(first);
			end = parseInt(end);
			for(var i = first; i <= end; i++){
				if(i == this.page){
					htmlStr += '<li class="page active" data-page="' + i + '"><a>' + i + '</a></li>';
				}else{
					htmlStr += '<li class="page" data-page="' + i + '"><a>' + i + '</a></li>';
				}
			}

			if(this.page == this.totalPage){
				htmlStr += '<li class="next disabled"><span>»</span></li>';
			}else{
				var nextPage = 1;
				if(end + 1 < this.totalPage){
					nextPage = end + 1;
				}else{
					nextPage = this.totalPage;
				}
				htmlStr += '<li class="next"><a data-page="' + nextPage + '">»</a></li>';
			}

			self.oJpagebar.empty();
			self.oJpagebar.html(htmlStr);
			var oThis = this;
			self.oJpagebar.find('.page').on('click', function(){
				var page = parseInt($(this).attr('data-page'));
				if(page == oThis.page){
					return;
				}
				oThis.page = page;
				oThis.showEventList(oThis.page, oThis.type, oThis.event_type);
			});
			self.oJpagebar.find('.prev').on('click', function(){
				var page = oThis.page;
				page--; 
				if(page<1)
				{
					page=1;
					return;
				}
				oThis.page = page;
				oThis.showEventList(oThis.page, oThis.type, oThis.event_type);
			});
			self.oJpagebar.find('.next').data("max",this.totalPage).on('click', function(){
				var page = oThis.page;
				page++ ;
				var max = $(this).data("max");
				if(page>max)
				{
					page=max;
					return;
				}
				oThis.page = page;
				oThis.showEventList(oThis.page, oThis.type, oThis.event_type);
			});						
		},

		showEventList : function(page, type, eventType, callBack){
			var oThis = this;
			if(oThis.isGetEventListAjaxIng){
				return;
			}
			oThis.isGetEventListAjaxIng = true;
			ajax({
				url : oThis.evenListUrl,
				data : {
					page : page,
					type : type,
					event_type : eventType,
					target_user_id : oThis.target_user_id
				},
				success : function(aResult){
					oThis.isGetEventListAjaxIng = false;
					if(aResult.status == 1){
						_appendEventList(aResult.data);
						if(callBack){
							callBack(aResult.data);
						}
					}else{
						UBox.show(aResult.msg, aResult.status);
					}
				},
				error : function(){
					oThis.isGetEventListAjaxIng = false;
					UBox.show('抱歉，系统错误！', 0);
				}
			});
		}
	};

	function _appendEventList(aData){
		self.page = aData.page;
		self.totalPage = aData.totalPage;

		self.oWrapDom.html('');
		if(aData.list.length == 0 && self.oJpagebar != ''){
			self.oWrapDom.html('<center>暂无数据</center>');
			return ;
		}
		var htmlStr = _getEventListHtml(aData.list);
		self.oWrapDom.html(htmlStr);
		if(self.oJpagebar != '' && aData.list.length != 0){
			self.showPageBar();
		}

		App.isComputer && _bindShowUserCard($('.J-event-list-wraper img'));
	}

	function _getEventListHtml(aData){
		var htmlStr = '<ul class="J-event-list-wraper list-unstyled">';
		for(var i in aData){
			var aTempList = aData[i];
			var descriptionStr = '';
			if(aTempList.type == self.MARK){
				descriptionStr += '连续签到' + aTempList.data.day + '天，获得了' + aTempList.data.gold + '金币!';
			}else if(aTempList.type == self.PASS_MISSION){
				var url = self.missionPracticUrl.replace('_mission_id', aTempList.data.mission_id);
				if(aTempList.data.over_world_score == 0){
					descriptionStr += '完成了<a href="' + url + '">' + aTempList.data.mission_name + '</a>关卡的挑战，挑战得分' + (parseInt(aTempList.data.score) / 100) + '分!';
				}else{
					descriptionStr += '完成了<a href="' + url + '">' + aTempList.data.mission_name + '</a>关卡的挑战，挑战得分' + (parseInt(aTempList.data.score) / 100) + '分，破了世界纪录!';
				}
			}else if(aTempList.type == self.EXCHANGE_CARD){
				descriptionStr += '兑换了<a href="javascript:;">' + aTempList.data.card_group_title + '</a>卡牌，获得' + aTempList.data.gold + '金币!';
			}else if(aTempList.type == self.FINISH_MATCH){
				var url = self.matchDetailUrl.replace('_matchId', aTempList.data.match_id);
				descriptionStr += '参加了<a href="' + url + '">' + aTempList.data.match_name + '</a>比赛，得到了' + (parseInt(aTempList.data.score) / 100) + '分!';
			}else if(aTempList.type == self.WIN_MATCH_WITH_GOLD){
				var prizeName = '';
				var url = self.matchDetailUrl.replace('_matchId', aTempList.data.match_id);
				if(aTempList.data.ranking == 'rand'){
					prizeName = '幸运奖';
				}else{
					prizeName = aTempList.data.ranking + '等奖';
				}
				descriptionStr += '得到了<a href="' + url + '">' + aTempList.data.match_name + '</a>比赛' + prizeName + '，获得了' + aTempList.data.award.gold + '金币!';
			}else if(aTempList.type == self.WIN_MATCH_WITHOUT_GOLD){
				var prizeName = '';
				var url = self.matchDetailUrl.replace('_matchId', aTempList.data.match_id);
				if(aTempList.data.ranking == 'rand'){
					prizeName = '幸运奖';
				}else{
					prizeName = aTempList.data.ranking + '等奖';
				}
				descriptionStr += '得到了<a href="' + url + '">' + aTempList.data.match_name + '</a>比赛' + prizeName + '!';
			}else if(aTempList.type == self.WIN_PK_WITH_GOLD){
				descriptionStr += '跟<a href="javascript:;">' + Ui1.buildVipName(aTempList.data.pk_user_info, true) + '</a>PK获胜，获得了' + aTempList.data.win_gold + '金币!';
			}else if(aTempList.type == self.WIN_PK_WITHOUT_GOLD){
				descriptionStr += '跟<a href="javascript:;">' + Ui1.buildVipName(aTempList.data.pk_user_info, true) + '</a>PK获胜了!';
			}else if(aTempList.type == self.OPEN_VIP_PACKAGE){
				var url = self.openVipUrl;
				descriptionStr += '打开了会员每日大礼包获得了' + aTempList.data.gold + '金币!   <a href="' + url + '">我要开通</a>!';
			}else if(aTempList.type == self.BIND_EMAIL){
				var url = self.bindEmailUrl;
				descriptionStr += '绑定了邮箱，获得了' + aTempList.data.gold + '金币  <a href="' + url + '">我要绑定</a>!';
			}else if(aTempList.type == self.BUY_PROP){
				descriptionStr += '使用' + aTempList.data.gold + '金币购买了<a href="javascript:;">' + aTempList.data.prop_name + '</a>道具!';
			}else if(aTempList.type == self.EXCHANGE_GOODS){
				var url = self.exchangeGoodDetailUrl.replace('_exchangeGoodsId', aTempList.data.exchange_goods_id);
				descriptionStr += '使用' + aTempList.data.gold + '金币兑换了<a href="' + url + '">' + aTempList.data.exchange_goods_name + '</a>!';
			}else if(aTempList.type == self.FINISH_DAILY_TASK){
				descriptionStr += '完成了今日任务获得了' + aTempList.data.gold + '金币!';
			}else if(aTempList.type == self.PUBLISH_THREAD){
				var url = self.threadDetailUrl.replace('_threadId', aTempList.data_id);
				descriptionStr += '发表了“<a href="' + url + '" style="display: inline-block; max-width: 350px; overflow: hidden; text-overflow: ellipsis; vertical-align: middle;" title="' + aTempList.data.title +'">' + aTempList.data.title + '</a>“话题!';
			}else if(aTempList.type == self.RECOMMEND_THREAD){
				var url = self.threadDetailUrl.replace('_threadId', aTempList.data_id);
				descriptionStr += '发表的“<a href="' + url + '" style="display: inline-block; max-width: 220px; overflow: hidden; text-overflow: ellipsis; vertical-align: middle;" title="' + aTempList.data.title + '">' + aTempList.data.title + '</a>“话题加精，获得了' + aTempList.data.get_gold + '金币!';
			}else if(aTempList.type == self.BECOME_VIP){
				var url = self.openVipUrl;
				descriptionStr += '成为了VIP会员 <a href="' + url + '">我要开通</a>!';
			}else if(aTempList.type == self.BECOME_FRIEND){
				descriptionStr += '与<a href="javascript:;">' + aTempList.data.friend_user_info.name + '</a>成为了好友';
			}else if(aTempList.type == self.FIRST_PASS_PROFILE_APPROVE){
				descriptionStr += '首次上传头像并通过审核，获得了' + aTempList.data.get_gold + '金币！';
			}else if(aTempList.type == self.THREAD_SUPPORT){
				var url = self.threadDetailUrl.replace('_threadId', aTempList.data_id);
				descriptionStr += '发布的话题“<a href="' + url + '" style="display: inline-block; max-width: 150px; overflow: hidden; text-overflow: ellipsis; vertical-align: middle;" title="' + aTempList.data.title + '">' + aTempList.data.title + '</a>”得到了' + aTempList.data.support_times + '个赞，获得了' + aTempList.data.get_gold + '金币！';
			}else if(aTempList.type == self.FIRST_BUY_PROP){
				descriptionStr += '首次于道具商城购买道具，获得了' + aTempList.data.get_gold + '金币！';
			}else if(aTempList.type == self.FIRST_RECHARGE_VIP){
				descriptionStr += '首次充值VIP会员，获得了' + aTempList.data.get_gold + '金币！';
			}else if(aTempList.type == self.BBS_AVTIVE_USER){
				descriptionStr += '昨天话题活跃值排行前十名，获得了' + aTempList.data.get_gold + '金币！';
			}else if(aTempList.type == self.FIRST_BIND_PHONE){
				descriptionStr += '首次绑定手机，获得了' + aTempList.data.get_gold + '金币！';
			}else if(aTempList.type == self.ES_ANALYSIS_PASS){
				descriptionStr += '恭喜你，你在' + Ui1.date('m月d日', aTempList.data.create_time) + '写的题目解析已经审核通过，获得' + aTempList.data.gold + '个金币奖励！';
			}else if(aTempList.type == self.ES_ANALYSIS_FAIL){
				descriptionStr += '很遗憾，你在' + Ui1.date('m月d日', aTempList.data.create_time) + '写的题目解析未通过审核，请继续努力！';
			}else if(aTempList.type == self.WIN_ONLINE_PK_ONE){
				descriptionStr += '跟<a href="javascript:;">' + Ui1.buildVipName(aTempList.data.pk_user_info, true) + '</a>PK获胜了！';
			}else if(aTempList.type == self.WIN_ONLINE_PK_ONE_GOLD){
				descriptionStr += '跟<a href="javascript:;">' + Ui1.buildVipName(aTempList.data.pk_user_info, true) + '</a>PK获胜了，获得了' + aTempList.data.win_gold + '金币！';
			}else if(aTempList.type == self.WIN_ONLINE_PK_three){
				descriptionStr += '队伍跟<a href="javascript:;">' + Ui1.buildVipName(aTempList.data.pk_user_info, true) + '</a>队伍PK获胜了！';
			}else if(aTempList.type == self.WIN_ONLINE_PK_TREE_GOLD){
				descriptionStr += '队伍跟<a href="javascript:;">' + Ui1.buildVipName(aTempList.data.pk_user_info, true) + '</a>队伍PK获胜了，获得了' + aTempList.data.win_gold + '金币！';
			}else if(aTempList.type == self.WIN_PK_ARENA){
				descriptionStr += '在' + aTempList.data.arena_info.name + '擂台获得第' + aTempList.data.ranking + '名，获得' + aTempList.data.win_gold + '金币！';
			}else{
				continue;
			}

			htmlStr += '\
				<li>\
					<div class="list-info">\
						' + Ui1.buildProfile(aTempList.user_info, true, {addClass : 'circle'}) + '\
						' + Ui1.buildVipName(aTempList.user_info, true) + '\
						' + descriptionStr + '\
					</div> \
					<span class="date">' + Ui1.date('n-d H:i', aTempList.data.create_time) + '</span>\
				</li>\
			';
		}

		htmlStr += '</ul>';

		return htmlStr;
	}

	function _bindShowUserCard(oDom){
		UMDialogs.listenToShowStudentInfo(oDom, {
			user_info_url: self.userInfoUrl,
			add_friend_url : self.applyFriendUrl,
			send_message_url : self.sendMessageUrl
		});
	}

	var self = win.EventPage;
	$(function(){
		if(self.oJeventtab != ''){
			self.oJeventtab.on('click', function(){
				self.oJeventtab.removeClass('active');
				$(this).addClass('active');
				var type = $(this).attr('data-type');
				if(self.type == type){
					return;
				}
				self.page = 1;
				self.type = $(this).attr('data-type');
				self.showEventList(self.page, self.type, self.event_type);
			});
		}
		if(self.oJeventtype != ''){
			self.oJeventtype.on('click', function(){
				self.oJeventtypetab.find('li').removeClass('active');
				$(this).parent().addClass('active');
				var eventType = $(this).attr('data-event-type');
				if(self.event_type == eventType){
					return;
				}
				self.page = 1;
				self.event_type = $(this).attr('data-event-type');
				self.showEventList(self.page, self.type, self.event_type);
			});
		}
	});

})(jQuery, window);
