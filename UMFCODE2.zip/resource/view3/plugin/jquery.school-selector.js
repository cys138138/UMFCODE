(function(container, $){
container.SchoolSelector = function(aOptions){
	var self = this;
	$.extend(self, new Component());
	self.$province = aOptions.$province;	//省
	self.$city = aOptions.$city;	//市
	self.$area = aOptions.$area;	//区
	self.$schoolList = aOptions.$schoolList;	//学校
	self.schoolListUrl = aOptions.schoolListUrl;	//学校列表地址
	self.schoolListCache = {};	//学校列表缓存

	var defaultSchoolId = aOptions.defaultSchoolId ? aOptions.defaultSchoolId : 0,
	defaultSchoolAreaId = aOptions.defaultSchoolAreaId ? aOptions.defaultSchoolAreaId : 0;

	//加载某区的学校
	self.$schoolList.load = function(areaId){
		self.getSchoolList(this, areaId);
	};
	
	self.getSelectAreaId = function(){
		return self.$area.val();
	}
	
	self.getSelectSchoolId = function(){
		return self.$schoolList.val();
	}
	
	self.showSchoolList = function(oDom, aSchoolList){
		var hasSchool = false;
		for(var i in aSchoolList){
			if(aSchoolList[i].id == defaultSchoolId){
				hasSchool = true;
			}
			oDom.append('<option value="' + aSchoolList[i].id + '">' + aSchoolList[i].name + '</option>');
		}
		if(hasSchool){
			oDom.val(defaultSchoolId);
		}
	}
	
	self.getSchoolList = function(oDom, areaId){
		if(areaId == 0){
			return;
		}
		var key = 'school_list_' + areaId;
		if(typeof(self.schoolListCache[key]) != 'undefined'){
			self.showSchoolList(oDom, self.schoolListCache[key]);
			return;
		}
		oDom.empty();
		ajax({
			url : self.schoolListUrl,
			data : {areaId : areaId},
			success : function(aResult){
				if(aResult.status == 1){
					self.schoolListCache[key] = aResult.data;
					self.showSchoolList(oDom, aResult.data);
				}else{
					UBox.show(aResult.msg, aResult.status);
				}
			}
		});
	}

	//初始化
	self.init = function(){
		var oAreaSelector = new AreaSelector({
			$province : self.$province,
			$city : self.$city,
			$area : self.$area,
			defaultArea : defaultSchoolAreaId ? defaultSchoolAreaId : 0
		});
		oAreaSelector.init();
		
		self.$province.change(function(){
			self.$schoolList.empty();
			self.$city.change();
		});

		self.$city.change(function(){
			self.$schoolList.empty();
			self.$area.change();
		});
		
		self.$area.change(function(){
			self.$schoolList.empty();
			self.$schoolList.change();
			self.getSchoolList(self.$schoolList, this.value);
		});

		self.$schoolList.change(function(){
			//区域变更后
			aOptions.onSelectSchool && aOptions.onSelectSchool(this.value, $(this).find(':selected').text());
			var oEvent = new UmFunEvent();
			oEvent.schoolId = this.value;
			oEvent.schoolName = $(this).find(':selected').text();
			self.triggerEvent(self.EVENT_ON_SELECT_SCHOOL, oEvent);
		});

		if(defaultSchoolId && defaultSchoolAreaId){
			self.getSchoolList(self.$schoolList, defaultSchoolAreaId);
		}
	};
};

container.SchoolSelector.prototype.EVENT_ON_SELECT_SCHOOL = 1;

})(window, jQuery);